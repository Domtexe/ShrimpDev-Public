# -*- coding: utf-8 -*-
"""
Runner_1148b_ForceDetectionFix
- Repariert/ergänzt Intake-Erkennung **zwangsweise** (AST-basiert):
  * IntakeFrame._guess_name_from_text()
  * IntakeFrame._guess_ext_from_text()
- Unabhängig von vorhandener Formatierung / vorherigen Versionen.
- Backup -> Patch -> Syntaxcheck -> Headless-Livetests -> ggf. Rollback
- Report: _Reports/Runner_1148b_ForceDetectionFix_report.txt
"""
from __future__ import annotations
import io, os, sys, time, shutil, ast, importlib.util, types
from pathlib import Path
import py_compile, re

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1148b_ForceDetectionFix_report.txt"

def w(s=""):
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f: f.write(s.rstrip()+"\n")
    print(s)

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time()*1000)}.bak"; shutil.copy2(p, dst); return dst

NEW_NAME_SRC = r'''
def _guess_name_from_text(self, text: str) -> tuple[str, str]:
    """
    Robust: extrahiert Runner-Namen + ggf. Endung. Keine fehlerhaften Zeichenklassen.
    """
    import re
    t = text or ""
    m = re.search(r'(?i)tools[\\/](Runner_[0-9]{3,5}[_A-Za-z0-9\-]+)\.(py|bat|cmd)', t)
    if m: return m.group(1), "." + m.group(2).lower()
    m = re.search(r'(?i)\b(Runner_[0-9]{3,5}[_A-Za-z0-9\-]+)\.(py|bat|cmd)\b', t)
    if m: return m.group(1), "." + m.group(2).lower()
    m = re.search(r'(?i)\bpy(?:\s+-3)?\s+tools[\\/](Runner_[^\s\\/:*?"<>|]+)\.py\b', t)
    if m: return m.group(1), ".py"
    m = re.search(r'(?i)\bcall\s+tools[\\/](Runner_[^\s\\/:*?"<>|]+)\.(bat|cmd)\b', t)
    if m: return m.group(1), "." + m.group(2).lower()
    m = re.search(r'(?im)^\s*(?:[#;:\- ]*)name\s*[:=]\s*(Runner_[0-9]{3,5}[_A-Za-z0-9\-]+)(?:\.(py|bat|cmd))?\s*$', t)
    if m: return m.group(1), ("."+m.group(2).lower()) if m.group(2) else ""
    m = re.search(r'(?i)\b(Runner_[0-9]{3,5}[_A-Za-z0-9\-]+)\b', t)
    if m: return m.group(1), ""
    return "", ""
'''.strip("\n")

NEW_EXT_SRC = r'''
def _guess_ext_from_text(self, text: str) -> str:
    """
    Heuristik .py/.bat/.json/.yml(.yaml)/.ini/.md – konfliktfrei.
    """
    import re
    head = (text or "").lstrip()[:4000]
    if re.search(r'(?im)^\s*@echo\s+off\b', head) or re.search(r'(?im)^\s*rem\b', head):
        return ".bat"
    if re.search(r'(?im)^#!.*python', head):
        return ".py"
    if re.search(r'(?m)^\s*(?:from\s+\w+\s+import|import\s+\w+|def\s+\w+\(|class\s+\w+\(|if\s+__name__\s*==\s*[\'"]__main__[\'"])', " "+head):
        return ".py"
    try:
        import json
        s = head.strip()
        if s and s[0] in "{[":
            json.loads(s)
            return ".json"
    except Exception:
        pass
    if re.search(r'(?m)^\s*-\s+\w+', head) or re.search(r'(?m)^\s*\w+:\s+.+', head):
        return ".yml"
    if re.search(r'(?m)^\s*\[[^\]]+\]\s*$', head) and re.search(r'(?m)^\s*\w+\s*=\s*', head):
        return ".ini"
    if re.search(r'(?m)^\s*#\s+\w+', head):
        return ".md"
    return ""
'''.strip("\n")

def load() -> str:
    return io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

def save(txt: str) -> None:
    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(txt)

def ensure_methods(txt: str) -> tuple[str, list[str]]:
    """
    Sucht class IntakeFrame und ersetzt/fügt die beiden Methoden.
    Strategie:
      - per AST class-Position ermitteln
      - innerhalb des Klassen-Source via Regex Methodenblöcke ersetzen, sonst anhängen
    """
    tree = ast.parse(txt)
    cls: ast.ClassDef|None = None
    for n in tree.body:
        if isinstance(n, ast.ClassDef) and n.name == "IntakeFrame":
            cls = n; break
    if not cls: raise RuntimeError("class IntakeFrame nicht gefunden.")

    # Bereich der Klasse im Rohtext bestimmen
    # ast liefert lineno (1-based) und end_lineno (3.11+). Fallback via Regex wenn end_lineno fehlt.
    lines = txt.splitlines()
    start = cls.lineno-1
    if hasattr(cls, "end_lineno") and cls.end_lineno:
        end = cls.end_lineno
    else:
        # einfache Heuristik: von start+1 suchen bis nächste "class " am Zeilenanfang
        end = len(lines)
        for i in range(start+1, len(lines)):
            if re.match(r'^\s*class\s+\w+', lines[i]):
                end = i; break

    cls_src = "\n".join(lines[start:end])
    changed: list[str] = []

    def repl_or_append(src: str, fname: str, new_body: str) -> tuple[str,bool]:
        # suche def fname( ... ):
        rx = re.compile(r'(?ms)^\s*def\s+'+re.escape(fname)+r'\s*\([^)]*\):\s*(?:\n\s+.+?)(?=^\s*def\s+\w+\s*\(|\Z)')
        if rx.search(src):
            return rx.sub("\n    " + new_body.replace("\n", "\n    ") + "\n", src, count=1), True
        # sonst ans Ende der Klasse anhängen
        if not src.endswith("\n"): src += "\n"
        return src + "\n    " + new_body.replace("\n", "\n    ") + "\n", False

    cls_src2, r1 = repl_or_append(cls_src, "_guess_name_from_text", NEW_NAME_SRC)
    if r1: changed.append("replaced:_guess_name_from_text")
    else:  changed.append("added:_guess_name_from_text")

    cls_src3, r2 = repl_or_append(cls_src2, "_guess_ext_from_text", NEW_EXT_SRC)
    if r2: changed.append("replaced:_guess_ext_from_text")
    else:  changed.append("added:_guess_ext_from_text")

    # neue Gesamtquelle zusammensetzen
    new_txt = "\n".join(lines[:start]) + ("\n" if start else "") + cls_src3 + ("\n" if end < len(lines) else "") + "\n".join(lines[end:])
    return new_txt, changed

# --- Live-Test Helfer
def import_intake():
    sys.path.insert(0, str(ROOT))
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules")
        mod = types.ModuleType("modules.module_runner_exec")
        mod.run = lambda *a, **k: 0
        mod._log = lambda *a, **k: None
        sys.modules.setdefault("modules", pkg)
        sys.modules["modules.module_runner_exec"] = mod
    spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
    m = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(m)  # type: ignore[attr-defined]
    return m

def test_detection():
    import tkinter as tk
    m = import_intake()
    root = tk.Tk(); root.withdraw()
    fr = m.IntakeFrame(root)
    cases = [
        ("PY basic",       "import os\nprint('hi')\n", ".py"),
        ("PY runner call", "py -3 tools\\Runner_9999_Test.py\n", ".py"),
        ("BAT basic",      "@echo off\nrem test\n", ".bat"),
        ("BAT runner call","call tools\\Runner_8888_Task.bat\n", ".bat"),
        ("JSON",           "{ \"k\": 1 }\n", ".json"),
        ("YML",            "name: x\nsteps:\n  - run\n", ".yml"),
    ]
    fails = 0
    for title, text, want in cases:
        fr.txt.delete("1.0", "end")
        fr.txt.insert("1.0", text)
        fr.var_name_manual = False
        fr.var_ext_manual  = False
        ok = fr._detect()
        ext = (fr.var_ext.get() or "").lower()
        good = (ext in (".yml",".yaml")) if want == ".yml" else (ext == want)
        w(f"[Test] {title:16s} -> ok={ok} ext='{ext}' want='{want}' => {'OK' if good else 'FAIL'}")
        if not good: fails += 1
    root.destroy()
    return fails

def main() -> int:
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass
    w("[R1148b] ForceDetectionFix – Start")
    if not MODFILE.exists():
        w("[ERR] module_code_intake.py fehlt."); return 1

    bak = backup(MODFILE); w(f"[Backup] {bak.name}")
    src = load()

    try:
        new_txt, changed = ensure_methods(src)
    except Exception as e:
        w(f"[ERR] Patch-Vorbereitung: {e}")
        return 1

    save(new_txt)
    w("[Write] " + ", ".join(changed))

    try:
        py_compile.compile(str(MODFILE), doraise=True); w("[Syntax] OK")
    except Exception as e:
        w(f"[Syntax] Fehler: {e} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    try:
        fails = test_detection()
        if fails:
            w(f"[SUM] Detection-Tests FAIL: {fails}/6 -> Rollback")
            shutil.copy2(bak, MODFILE); return 1
        w("[SUM] Alle Detection-Tests OK.")
    except Exception as e:
        w(f"[Live] Fehler: {e} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    w("[R1148b] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
