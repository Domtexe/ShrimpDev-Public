"""
Runner_1049_Intake_ResizeNameExt
Ziel:
- Namensfeld deutlich breiter + mitwachsende Spalte.
- Endungsfeld kleiner (6 Zeichen), nicht mitwachsend.
- Ziel: bessere Nutzung der Kopfzeile auf breiten Fenstern.

Änderungen:
- head.columnconfigure: Name (col=4) bekommt hohes weight, Ext (col=7) kein weight.
- Entry-Widgets: ent_name sticky="ew", ent_ext sticky="w" + width=6.
- Target (col=9) behält weight für gute UX.

Version: v9.9.39
"""
from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1049] {ts} {msg}\n")
    except Exception:
        pass

def backup_write(path: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

def patch() -> int:
    with open(MOD, "r", encoding="utf-8") as f:
        src = f.read()

    changed = False

    # 1) columnconfigure-Block im Header: Name-Spalte (4) groß machen, Ext (7) nicht dehnen
    src2 = re.sub(
        r'for c in \(\s*1\s*,\s*3\s*,\s*7\s*,\s*9\s*\):\s*\n\s*head\.columnconfigure\(c,\s*weight=1\)',
        (
            'for c in (1,3,9):\n'
            '            head.columnconfigure(c, weight=1)\n'
            '        # Name-Spalte stark gewichten, Ext nicht dehnen\n'
            '        head.columnconfigure(4, weight=3)\n'
            '        head.columnconfigure(7, weight=0)'
        ),
        src, flags=re.MULTILINE
    )
    if src2 != src:
        src = src2
        changed = True

    # 2) ent_name: sticky="ew" (bleibt), Breite optional etwas größer initial
    src2 = re.sub(
        r'(ent_name\s*=\s*ttk\.Entry\(head,\s*textvariable=self\.var_name\)\s*\n\s*ent_name\.grid\(row=0,\s*column=4,\s*sticky=")ew(".*\)\n)',
        r'\1ew\2',  # belassen; nur falls jemand es umgestellt hatte
        src
    )
    if src2 != src:
        src = src2
        changed = True

    # 3) ent_ext: width=6 + sticky="w" (nicht dehnen)
    #    a) width-Anteil
    src2 = re.sub(
        r'ent_ext\s*=\s*ttk\.Entry\(head,\s*textvariable=self\.var_ext,\s*width=\d+\)',
        r'ent_ext = ttk.Entry(head, textvariable=self.var_ext, width=6)',
        src
    )
    if src2 == src:
        # falls vorher ohne width= gesetzt wurde
        src2 = re.sub(
            r'ent_ext\s*=\s*ttk\.Entry\(head,\s*textvariable=self\.var_ext\)',
            r'ent_ext = ttk.Entry(head, textvariable=self.var_ext, width=6)',
            src
        )
    if src2 != src:
        src = src2
        changed = True

    #    b) sticky-Anteil
    src2 = re.sub(
        r'ent_ext\.grid\(row=0,\s*column=7,\s*sticky="[^"]*",\s*padx=\([^)]+\)\)',
        r'ent_ext.grid(row=0, column=7, sticky="w", padx=(4,12))',
        src
    )
    if src2 == src:
        # falls anderes Grid-Muster
        src2 = re.sub(
            r'ent_ext\.grid\([^\)]*column=7[^\)]*\)',
            r'ent_ext.grid(row=0, column=7, sticky="w", padx=(4,12))',
            src
        )
    if src2 != src:
        src = src2
        changed = True

    if changed:
        backup_write(MOD, src)
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.39\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.39 (2025-10-18)
- Intake Header-Layout: Name-Spalte vergrößert (weight=3), Ext-Spalte verkleinert (width=6, kein Stretch).
""")
        log("Patch angewendet.")
        return 0
    else:
        log("Keine Änderungen nötig.")
        return 0

if __name__ == "__main__":
    raise SystemExit(patch())
