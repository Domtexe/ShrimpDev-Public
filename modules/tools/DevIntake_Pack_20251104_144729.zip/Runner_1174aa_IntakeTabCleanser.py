# -*- coding: utf-8 -*-
"""
[1174aa] IntakeTabCleanser:
Entfernt alle fehlerhaften / doppelten _safe_add_intake_tab-Definitionen
und setzt die stabile, geprüfte Fassung neu ein.
"""

import re, py_compile, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MAIN = ROOT / "main_gui.py"

def log(msg): print(f"[1174aa] {msg}")

def read(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="ignore")

def write(p: Path, s: str):
    p.write_text(s, encoding="utf-8", newline="\n")

src = read(MAIN)
orig = src

# --- 1) Alle mehrfachen oder defekten _safe_add_intake_tab-Blocks entfernen ---
pattern = re.compile(
    r'(?ms)^def\s+_safe_add_intake_tab\s*\([^)]*\)\s*:\s*.*?(?=^def\s|\Z)'
)
src = pattern.sub('', src)

# --- 2) Ein stabile, getestete Variante anhängen ---
new_impl = r'''
def _safe_add_intake_tab(nb):
    """
    [1174aa] Stabile Intake-Mount-Funktion
    - versucht direkten Mount
    - bei Fehlern Platzhalter + Lazy-Mount
    - garantiert immer Tab
    """
    import tkinter as tk
    from tkinter import ttk
    try:
        from modules.module_code_intake import IntakeFrame
        tab = IntakeFrame(nb)
        nb.add(tab, text="Code Intake")
        return
    except Exception as e:
        try:
            with open(r"D:\ShrimpDev\debug_output.txt","a",encoding="utf-8") as f:
                f.write("[1174aa] Intake mount failed: %r\n" % (e,))
        except Exception:
            pass

    tab = ttk.Frame(nb)
    nb.add(tab, text="Code Intake")
    body = ttk.Frame(tab)
    body.pack(fill="both", expand=True)
    try:
        tab.after(150, lambda: _mount_intake_tab_safe(body))
    except Exception as ex:
        msg = tk.Label(tab, text=f"Fehler beim Laden des Intake-Tabs: {ex}", fg="red")
        msg.pack(anchor="w", padx=10, pady=10)
'''

src = src.rstrip() + "\n\n" + new_impl + "\n"

# --- 3) Speichern und Syntax prüfen ---
write(MAIN, src)
py_compile.compile(str(MAIN), doraise=True)
log("Erfolgreich bereinigt & Syntax OK.")
