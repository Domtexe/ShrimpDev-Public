# tools/Runner_1097d_Reindent_Intake_Strict.py
from __future__ import annotations
import os, re, time, unicodedata

ROOT = os.path.abspath(os.path.dirname(__file__))
MOD  = os.path.normpath(os.path.join(ROOT, "..", "modules", "module_code_intake.py"))
ARCH = os.path.normpath(os.path.join(ROOT, "..", "_Archiv"))

def backup(path: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "rb") as fsrc, open(bak, "wb") as fdst:
        fdst.write(fsrc.read())
    print(f"[R1097d] Backup: {path} -> {bak}")

def normalize_ws(s: str) -> str:
    # Tabs -> 4 Spaces, CRLF/CR -> LF, Unicode Spaces -> normaler Space
    s = s.replace("\r\n", "\n").replace("\r", "\n").replace("\t", "    ")
    # Ersetze alle Zs-Kategorie-Zeichen (Unicode-Whitespace) durch ASCII-Space
    out = []
    for ch in s:
        if ch == "\n":
            out.append(ch)
        elif unicodedata.category(ch) == "Zs" and ch != " ":
            out.append(" ")
        else:
            out.append(ch)
    return "".join(out)

def read_lines(path: str) -> list[str]:
    with open(path, "rb") as f:
        raw = f.read().decode("utf-8", errors="replace")
    norm = normalize_ws(raw)
    return norm.split("\n")

def write_lines(path: str, lines: list[str]) -> None:
    txt = "\n".join(lines).rstrip() + "\n"
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(txt)

def sanity_compile(lines: list[str]) -> None:
    src = "\n".join(lines).rstrip() + "\n"
    try:
        compile(src, MOD, "exec")
    except SyntaxError as ex:
        print("[R1097d] SyntaxError nach Fix:")
        a = src.splitlines()
        lo = max(0, ex.lineno-6); hi = min(len(a), ex.lineno+6)
        for n in range(lo, hi):
            mark = ">>" if (n+1)==ex.lineno else "  "
            print(f"{mark} {n+1:04d}: {a[n]}")
        raise

def find_block(lines: list[str], pat: re.Pattern[str]) -> tuple[int,int] | None:
    try:
        i0 = next(i for i,l in enumerate(lines) if pat.match(l))
    except StopIteration:
        return None
    # Blockende = nächstes Top-Level class/def/import/EOF
    end_pat = re.compile(r"^(class |def |from |import )")
    i1 = len(lines)
    for k in range(i0+1, len(lines)):
        if lines[k] and not lines[k].startswith(" "):
            if end_pat.match(lines[k]):
                i1 = k; break
    return (i0, i1)

def strict_reindent_class(lines: list[str], class_name: str) -> None:
    blk = find_block(lines, re.compile(rf"^class\s+{class_name}\b"))
    if not blk: 
        return
    i0, i1 = blk

    # 1) Alles im Klassenblock min. 4 Spaces
    for i in range(i0+1, i1):
        t = lines[i]
        if t.strip()=="":
            continue
        if not t.startswith(" "):
            lines[i] = "    " + t

    # 2) Methode-Köpfe: exakt 4 Spaces
    pat_def = re.compile(r"^\s*def\s+[A-Za-z_]\w*\s*\(")
    def_idxs: list[int] = []
    for i in range(i0+1, i1):
        if pat_def.match(lines[i]):
            lines[i] = "    " + lines[i].lstrip()
            def_idxs.append(i)

    # 3) Bodies: exakt 8 Spaces bis zum nächsten def/class oder Blockende
    def next_cut(idx: int) -> int:
        for k in range(idx+1, i1):
            if pat_def.match(lines[k]) or lines[k].startswith("class "):
                return k
        return i1

    for head in def_idxs:
        end = next_cut(head)
        for j in range(head+1, end):
            t = lines[j]
            if t.strip()=="":
                continue
            # Kommentare etc. auch anheben
            lines[j] = "        " + t.lstrip()

def main() -> int:
    if not os.path.exists(MOD):
        print(f"[R1097d] Datei nicht gefunden: {MOD}")
        return 1
    backup(MOD)
    lines = read_lines(MOD)

    # Strikt für IntakeFrame (und Tooltip als Bonus)
    strict_reindent_class(lines, "IntakeFrame")
    strict_reindent_class(lines, "Tooltip")

    sanity_compile(lines)
    write_lines(MOD, lines)
    print("[R1097d] Striktes Reindent abgeschlossen, Syntax OK.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
