# file: tools/Runner_990_FixGUI.py
from __future__ import annotations
import sys, time
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
TARGET = ROOT / "main_gui.py"

NEW_MAIN = r'''from __future__ import annotations
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
DEBUG = ROOT / "debug_output.txt"

def _log(msg: str) -> None:
    try:
        DEBUG.open("a", encoding="utf-8", errors="ignore").write(f"[MAIN] {msg}\n")
    except Exception:
        pass

class ShrimpDevApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("🦐 ShrimpDev")
        self.geometry("1100x720+80+60")
        self._mk_menu()

        # Notebook + Status
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True)

        tab_info = ttk.Frame(self.nb)
        self.nb.add(tab_info, text="Info")
        ttk.Label(
            tab_info,
            text="ShrimpDev – Standalone Dev-Umgebung für ShrimpHub\nAlle Tools werden hier integriert.",
            anchor="center", justify="center"
        ).pack(expand=True, fill="both", padx=16, pady=16)

        self.status = tk.StringVar(value="Bereit.")
        ttk.Label(self, textvariable=self.status, anchor="w").pack(fill="x")

        _log("GUI ready")

    # ---------------- Menu ----------------
    def _mk_menu(self):
        menubar = tk.Menu(self); self.config(menu=menubar)
        m_file = tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="File", menu=m_file)
        m_tools= tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="Tools", menu=m_tools)
        m_view = tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="View",  menu=m_view)
        m_help = tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="Help",  menu=m_help)

        # File
        m_file.add_command(label="Exit", command=self._on_exit)

        # Tools
        m_tools.add_command(label="Code Intake", command=self.open_intake)
        m_tools.add_separator()
        m_tools.add_command(label="New Module…", command=self._new_module_dialog)
        m_tools.add_command(label="New Runner…", command=self._new_runner_dialog)

        # View
        m_view.add_command(label="Agent Monitor", command=self.open_agent_monitor)
        m_view.add_command(label="Project Map",   command=self.open_project_map)

        # Help
        m_help.add_command(label="About", command=lambda: messagebox.showinfo("ShrimpDev", "ShrimpDev – All-in-One Dev GUI"))

        # Shortcuts
        self.bind_all("<Control-i>", lambda e: self.open_intake())
        self.bind_all("<Control-m>", lambda e: self.open_agent_monitor())

    # ---------------- Actions ----------------
    def open_intake(self):
        try:
            from modules import module_code_intake as intake
            intake.open_intake(self)
            self.status.set("Intake geöffnet.")
        except Exception as ex:
            _log(f"Intake error: {ex}")
            messagebox.showerror("ShrimpDev", f"Intake Fehler:\n{ex}")

    def open_agent_monitor(self):
        try:
            from modules import module_agent_ui as agent_ui
            agent_ui.open_agent_monitor(self)
            self.status.set("Agent Monitor geöffnet.")
        except Exception as ex:
            _log(f"AgentUI error: {ex}")
            messagebox.showerror("ShrimpDev", f"Agent Monitor Fehler:\n{ex}")

    def open_project_map(self):
        try:
            from modules import module_project_ui as proj_ui
            proj_ui.open_project_map(self)
            self.status.set("Project Map geöffnet.")
        except Exception as ex:
            _log(f"ProjectUI error: {ex}")
            messagebox.showerror("ShrimpDev", f"Project Map Fehler:\n{ex}")

    def _new_module_dialog(self):
        # Platzhalter – verhindert AttributeError, kann später erweitert werden
        messagebox.showinfo("ShrimpDev", "‘New Module…’ – Placeholder. (Kommt gleich integriert)")

    def _new_runner_dialog(self):
        # Platzhalter – verhindert AttributeError, kann später erweitert werden
        messagebox.showinfo("ShrimpDev", "‘New Runner…’ – Placeholder. (Kommt gleich integriert)")

    def _on_exit(self):
        try:
            # optional: Agent sauber stoppen, falls vorhanden
            from modules import module_agent as agent
            if getattr(agent, "AGENT", None):
                try:
                    agent.AGENT.stop()
                except Exception:
                    pass
        except Exception:
            pass
        self.after(100, self.destroy)

if __name__ == "__main__":
    try:
        app = ShrimpDevApp()
        app.mainloop()
    except Exception as ex:
        _log(f"FATAL: {ex}")
        try:
            messagebox.showerror("ShrimpDev", f"Fataler Fehler:\n{ex}")
        except Exception:
            pass
'''

def main() -> int:
    TARGET.parent.mkdir(parents=True, exist_ok=True)
    if TARGET.exists():
        bak = TARGET.with_name(f"{TARGET.name}.{time.strftime('%Y%m%d_%H%M%S')}.bak")
        TARGET.replace(bak)
        print(f"[R990] Backup: {bak.name}")
    TARGET.write_text(NEW_MAIN, encoding="utf-8")
    print("[R990] main_gui.py ersetzt (stabile Baseline).")
    print("[R990] Starte mit: start_visible.bat oder start_quiet.bat")
    return 0

if __name__ == "__main__":
    sys.exit(main())
