# tools/Runner_913_Silence.py
from __future__ import annotations
import os, json, sys, time
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT/"modules"))

# Fallback-Agent-Client
def send_event(ev: dict):
    try:
        from modules.snippets.agent_client import send_event as _send
        _send({"runner":"R913", **ev})
    except Exception:
        try:
            # INBOX-Fallback
            inbox = ROOT/"_Reports"/"Agent"/"inbox"
            inbox.mkdir(parents=True, exist_ok=True)
            (inbox/f"{int(time.time())}.jsonl").open("a", encoding="utf-8").write(
                json.dumps({"runner":"R913", **ev}, ensure_ascii=False)+"\n"
            )
        except Exception:
            pass

def _env_choice(name: str, default: str, allowed: set[str]) -> str:
    v = os.getenv(name, default).strip().lower()
    return v if v in allowed else default

def main():
    popups  = _env_choice("SHRIMPDEV_POPUPS",  "errors", {"never","errors","always"})
    reports = _env_choice("SHRIMPDEV_REPORTS", "errors", {"none","errors","all"})

    # Scan beziehen
    try:
        from modules.module_project_scan import scan_project, write_reports
    except Exception as ex:
        print(f"[R913][FAIL] module_project_scan import: {ex}")
        send_event({"level":"FAIL","msg":f"Import module_project_scan: {ex}"})
        sys.exit(1)

    # Wurzel aus Config, sonst ShrimpHub
    try:
        from modules.config_mgr import load_config
        cfg = load_config()
        root = Path(cfg.get("workspace_root", r"D:\ShrimpHub")).resolve()
    except Exception:
        root = Path(r"D:\ShrimpHub").resolve()

    print(f"[R913] Scanning root: {root}")
    send_event({"level":"INFO","msg":f"Scan start: {root}"})

    # Scan ausführen
    result = scan_project(root, days_old_for_bak=30, log_max_bytes=5*1024*1024)
    # Erwartete Felder robust lesen
    errs  = int(result.get("stats",{}).get("errors",  0) or 0)
    warns = int(result.get("stats",{}).get("warnings",0) or 0)

    # Reports-Policy anwenden
    wrote = []
    if reports == "all" or (reports == "errors" and (errs>0 or warns>0)):
        try:
            rep = write_reports(result, ROOT/"_Reports"/"Project")
            wrote = [str(p) for p in rep] if isinstance(rep, (list,tuple)) else [str(rep)]
        except Exception as ex:
            print(f"[R913][WARN] write_reports: {ex}")

    # Zusammenfassung
    summary = {
        "root": str(root),
        "files_scanned": int(result.get("stats",{}).get("files_scanned",0) or 0),
        "duplicates": len(result.get("duplicates",{})) if isinstance(result.get("duplicates"), dict) else 0,
        "warnings": warns,
        "errors": errs,
        "reports": wrote,
    }
    print("[R913] Summary:", json.dumps(summary, ensure_ascii=False, indent=2))

    # Popups-Policy
    show_popup = (
        popups == "always" or
        (popups == "errors" and (errs>0 or warns>0))
    )

    # Agent-Event
    level = "OK" if (errs==0 and warns==0) else ("WARN" if errs==0 else "ERROR")
    send_event({"level":level,"msg":"Scan finished", "data":summary})

    # Optional minimaler GUI-Hinweis nur bei Bedarf
    if show_popup:
        try:
            import tkinter as tk
            from tkinter import messagebox
            root_tk = tk.Tk(); root_tk.withdraw()
            if errs>0:
                messagebox.showerror("ShrimpDev – Scan", f"Fehler: {errs}\nWarnungen: {warns}")
            elif warns>0:
                messagebox.showwarning("ShrimpDev – Scan", f"Warnungen: {warns}\nFehler: {errs}")
            else:
                messagebox.showinfo("ShrimpDev – Scan", "Alles OK.")
            root_tk.destroy()
        except Exception:
            pass

    # Exitcode gemäß Ergebnis
    if errs>0:
        sys.exit(2)
    elif warns>0:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == "__main__":
    main()
