# -*- coding: utf-8 -*-
"""
Runner_1171e_IntakeToolbarFix
- Behebt Überlappungen in der Intake-Toolbar ohne manuelle Code-Edits.
- Verschiebt lbl_ping -> Spalte 198 (stretch), setzt columnconfigure(198, weight=1).
- Schiebt btn_del -> Spalte 4 (statt 3).
- Entfernt Shortcut-Suffixe aus Buttontexten (z.B. "(Ctrl+S)", "(F5)").
- Idempotent: ändert nur, wenn nötig. Mit Backup, Syntax-Check, Rollback.
Exitcodes: 0 OK, 1 Fehler.
"""
from __future__ import annotations
import os, re, time, py_compile, traceback

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOG    = os.path.join(ROOT, "debug_output.txt")

def _log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1171e {ts}] {msg}\n"
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def _backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "r", encoding="utf-8") as fi, open(dst, "w", encoding="utf-8", newline="") as fo:
        fo.write(fi.read())
    return dst

def _apply(src: str) -> tuple[str, list[str]]:
    changes = []

    # 1) Toolbar-Stretch-Spalte: 3 -> 198
    pat_colcfg = re.compile(r'(?m)^(\s*bar\.columnconfigure\()\s*3(\s*,\s*weight\s*=\s*1\s*\))\s*$')
    if pat_colcfg.search(src):
        src = pat_colcfg.sub(r'\1' + '198' + r'\2', src)
        changes.append("bar.columnconfigure: stretch -> 198")

    # 2) lbl_ping nach Spalte 198
    pat_lbl = re.compile(r'(?m)^(\s*self\.lbl_ping\.grid\(\s*row\s*=\s*0\s*,\s*column\s*=\s*)\d+')
    if pat_lbl.search(src):
        src = pat_lbl.sub(r'\1' + '198', src)
        changes.append("lbl_ping.grid: column -> 198")

    # 3) btn_del von Spalte 3 -> 4 (damit keine Kollision mehr mit stretch-Spalte)
    pat_del = re.compile(r'(?m)^(\s*self\.btn_del\.grid\(\s*row\s*=\s*0\s*,\s*column\s*=\s*)\d+')
    if pat_del.search(src):
        src = pat_del.sub(r'\1' + '4', src)
        changes.append("btn_del.grid: column -> 4")

    # 4) Shortcut-Suffixe aus Button-Labels entfernen (nur diese vier, damit keine Nebenwirkungen)
    btn_text_rewrites = {
        r'(self\.btn_detect\s*=\s*ttk\.Button\([^)]*text\s*=\s*")Erkennen\s*\([^"]*\)"' : r'\1Erkennen"',
        r'(self\.btn_save\s*=\s*ttk\.Button\([^)]*text\s*=\s*")Speichern\s*\([^"]*\)"' : r'\1Speichern"',
        r'(self\.btn_del\s*=\s*ttk\.Button\([^)]*text\s*=\s*")Löschen\s*\([^"]*\)"'    : r'\1Löschen"',
        r'(self\.btn_run\s*=\s*ttk\.Button\([^)]*text\s*=\s*")Run\s*\([^"]*\)"'        : r'\1Run"',
    }
    for pat, rep in btn_text_rewrites.items():
        rx = re.compile(pat)
        if rx.search(src):
            src = rx.sub(rep, src)
            changes.append(f"Button-Text bereinigt: {pat.split('text')[0].strip()}")

    return src, changes

def main() -> int:
    try:
        if not os.path.exists(TARGET):
            _log(f"Zieldatei fehlt: {TARGET}")
            return 1
        src = open(TARGET, "r", encoding="utf-8").read()
        new_src, changes = _apply(src)

        if not changes:
            _log("Keine Änderung erforderlich (idempotent).")
            return 0

        bak = _backup(TARGET)
        _log(f"Backup erstellt: {bak}")
        with open(TARGET, "w", encoding="utf-8", newline="\n") as f:
            f.write(new_src)

        try:
            py_compile.compile(TARGET, doraise=True)
        except Exception as e:
            # Rollback
            with open(bak, "r", encoding="utf-8") as fi, open(TARGET, "w", encoding="utf-8", newline="\n") as fo:
                fo.write(fi.read())
            _log("Syntax-Check FEHLER -> Rollback auf Backup.")
            _log("Traceback:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 1

        for c in changes:
            _log("Änderung: " + c)
        _log("Patch erfolgreich eingefügt und Syntax-Check OK.")
        return 0

    except Exception as e:
        _log("UNERWARTETER FEHLER:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
