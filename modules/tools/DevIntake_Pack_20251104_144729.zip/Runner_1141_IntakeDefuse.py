# -*- coding: utf-8 -*-
"""
Runner_1141_IntakeDefuse
- Repariert module_code_intake.py:
  * entfernt fehlplatzierte Editor-Guard-Blöcke (1123/1124) außerhalb der Klasse
  * entfernt nachgelagerte doppelte _on_click_guard/_open_selected-Defs (außerhalb der Klasse)
  * injiziert korrekte Methoden in class IntakeFrame
  * erzwingt from __future__ an Dateianfang
  * Syntax-Check via py_compile
"""

from __future__ import annotations
import os, re, time, shutil, py_compile, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
ARCH.mkdir(exist_ok=True)

def read_text(p: Path) -> str:
    with p.open("r", encoding="utf-8", newline="") as f:
        return f.read()

def write_text(p: Path, s: str) -> None:
    with p.open("w", encoding="utf-8", newline="\n") as f:
        f.write(s)

def backup(p: Path) -> Path:
    ts = str(int(time.time()*1000))
    dst = ARCH / f"{p.name}.{ts}.bak"
    shutil.copy2(p, dst)
    print(f"[R1141] Backup -> {dst}")
    return dst

# --- Patch-Bausteine ---------------------------------------------------------

INJECT_BLOCK = r'''
    # --- Editor Event Guards (R1141 canonical) ------------------------------
    def _safe_write(self, prefix: str, message: str) -> None:
        try:
            from modules.snippets.logger_snippet import write_log as _w
            _w(prefix, message)
        except Exception:
            try:
                import time, os
                p = os.path.join(os.path.dirname(os.path.dirname(__file__)), "debug_output.txt")
                ts = time.strftime("%Y-%m-%d %H:%M:%S")
                with open(p, "a", encoding="utf-8", newline="\\n") as f:
                    f.write(f"[{prefix}] {ts} {message}\\n")
            except Exception:
                pass

    def _ensure_editor_bindings(self) -> None:
        """Genau ein Binding pro Event – Doppelbindungen vermeiden."""
        try:
            self.txt.unbind("<<Paste>>")
            self.txt.unbind("<Control-v>")
            self.txt.unbind("<<Modified>>")
            self.txt.unbind("<KeyRelease>")
        except Exception:
            pass
        self.txt.bind("<<Paste>>", self._on_editor_paste)
        self.txt.bind("<Control-v>", self._on_editor_paste)
        self.txt.bind("<<Modified>>", self._on_editor_modified)
        self.txt.bind("<KeyRelease>", self._on_editor_key)

    def _on_editor_paste(self, _evt=None):
        """Beim Einfügen keine Events re-triggern; nur Detect debouncen."""
        try:
            self._schedule_detect(220)
        except Exception as ex:
            self._safe_write("INTAKE", f"PASTE_ERR: {ex!r}")

    def _on_editor_key(self, _evt=None):
        try:
            self._schedule_detect(250)
        except Exception as ex:
            self._safe_write("INTAKE", f"KEY_ERR: {ex!r}")

    def _on_editor_modified(self, _evt=None):
        try:
            try:
                self.txt.edit_modified(False)
            except Exception:
                pass
            self._schedule_detect(300)
        except Exception as ex:
            self._safe_write("INTAKE", f"MODIFIED_ERR: {ex!r}")

    def _schedule_detect(self, delay_ms: int = 250):
        """Debounce für Detect – ältere Jobs abbrechen."""
        try:
            if getattr(self, "_detect_job", None):
                try:
                    self.after_cancel(self._detect_job)
                except Exception:
                    pass
            self._detect_job = self.after(delay_ms, self._auto_detect_if_needed)
        except Exception as ex:
            self._safe_write("INTAKE", f"SCHED_ERR: {ex!r}")

    def _auto_detect_if_needed(self):
        try:
            self._ping("Auto-Erkennung…")
        except Exception:
            pass
        self._safe_detect()

    def _safe_detect(self):
        try:
            if hasattr(self, "_detect"):
                self._detect()
        except Exception as ex:
            import traceback
            self._safe_write("INTAKE", "DETECT_ERR\\n" + "".join(
                traceback.format_exception(type(ex), ex, ex.__traceback__)))
            try:
                self._update_led(self.led_detect, "yellow")
            except Exception:
                pass
    # --- /Editor Event Guards (R1141) ---------------------------------------
'''

def ensure_future_header(src: str) -> str:
    """Stellt sicher, dass __future__-Import ganz oben steht (nach Shebang/encoding)."""
    lines = src.splitlines()
    idx_first_code = 0
    # skip shebang/encoding and blanks
    while idx_first_code < len(lines) and (
        lines[idx_first_code].startswith("#!") or
        lines[idx_first_code].startswith("# -*-") or
        not lines[idx_first_code].strip()
    ):
        idx_first_code += 1
    # wenn future nicht direkt danach kommt, verschieben/einfügen
    has_future = any(l.strip() == "from __future__ import annotations" for l in lines)
    if has_future:
        # entferne alle future-zeilen außer der ersten
        lines = [l for i,l in enumerate(lines) if l.strip() != "from __future__ import annotations" or i == idx_first_code]
        if lines[idx_first_code].strip() != "from __future__ import annotations":
            # einfügen an korrekter position
            # ggf. Leerzeile nach oben anpassen
            if idx_first_code < len(lines) and lines[idx_first_code].strip():
                lines.insert(idx_first_code, "from __future__ import annotations")
            else:
                lines[idx_first_code] = "from __future__ import annotations"
    else:
        lines.insert(idx_first_code, "from __future__ import annotations")
    return "\n".join(lines) + ("\n" if not src.endswith("\n") else "")

def remove_bad_blocks(src: str) -> str:
    # 1) Kompletten 1123/1124 Block entfernen (falsch platziert)
    src2 = re.sub(
        r"[ \t]*#\s*---\s*Editor-Event-Guards\s*\(1123\).*?#\s*---\s*/Editor-Event-Guards\s*\(1124\)\s*---\s*",
        "",
        src, flags=re.DOTALL | re.IGNORECASE
    )
    # 2) Nachträglich definierte, freistehende _on_click_guard/_open_selected (außerhalb Klasse) entfernen
    src2 = re.sub(r"\n[ \t]*def\s+_on_click_guard\(.*?\)\s*:\s*.*?(?=\n[ \t]*\n|\Z)", "\n", src2, flags=re.DOTALL)
    src2 = re.sub(r"\n[ \t]*def\s+_open_selected\(.*?\)\s*:\s*.*?(?=\n[ \t]*\n|\Z)", "\n", src2, flags=re.DOTALL)
    return src2

def inject_methods_into_class(src: str) -> str:
    # Anker: vor " # ---------------- Windows Recycle Bin helper ----------------"
    m = re.search(r"(?m)^\s*class\s+IntakeFrame\s*\(.*?\):", src)
    if not m:
        raise RuntimeError("class IntakeFrame nicht gefunden – Abbruch.")
    class_start = m.end()

    # Position für Injection: kurz vor 'Windows Recycle Bin helper'
    anchor = re.search(r"(?m)^\s*#\s*-{4,}\s*Windows\s+Recycle\s+Bin\s+helper\s*-{4,}\s*$", src)
    if not anchor:
        # Falls Anker fehlt, am Ende der Klasse bestmöglich suchen: nächster Top-Level 'def ' oder 'class ' nach class_start
        nxt = re.search(r"(?m)^\S", src[class_start:])
        insert_at = anchor.start() if anchor else (class_start + (nxt.start() if nxt else 0))
    else:
        insert_at = anchor.start()

    # Prüfen, ob bereits ein kanonischer Block existiert → nichts injizieren
    if "Editor Event Guards (R1141 canonical)" in src:
        return src

    # Einrücken auf Klassenebene (4 Leerzeichen)
    block = "\n" + "\n".join(("    " + ln if ln.strip() else ln) for ln in INJECT_BLOCK.strip("\n").split("\n")) + "\n"

    return src[:insert_at] + block + src[insert_at:]

def main() -> int:
    print("[R1141] IntakeDefuse – Start")
    if not MOD.exists():
        print(f"[R1141] Fehler: {MOD} nicht gefunden.")
        return 2
    backup(MOD)
    src = read_text(MOD)

    # Reihenfolge: kaputte Blöcke raus → Import-Header fix → Methoden injizieren
    src1 = remove_bad_blocks(src)
    src2 = ensure_future_header(src1)
    try:
        src3 = inject_methods_into_class(src2)
    except RuntimeError as ex:
        print(f"[R1141] {ex}")
        return 1

    # Nur schreiben, wenn sich etwas geändert hat
    if src3 != src:
        write_text(MOD, src3)
        print("[R1141] Patch angewendet.")
    else:
        print("[R1141] Keine Änderungen nötig.")

    # Syntax-Check
    try:
        py_compile.compile(str(MOD), doraise=True)
        print("[R1141] Syntax OK.")
        return 0
    except py_compile.PyCompileError as ex:
        print("[R1141] SyntaxError nach Patch – Rollback.")
        # Rollback aus letztem Backup
        last = max(ARCH.glob("module_code_intake.py.*.bak"), key=os.path.getmtime, default=None)
        if last:
            shutil.copy2(last, MOD)
            print(f"[R1141] Wiederhergestellt: {last.name}")
        print(str(ex))
        return 1

if __name__ == "__main__":
    sys.exit(main())
