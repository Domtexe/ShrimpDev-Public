# -*- coding: utf-8 -*-
"""
Runner_1177a_IntakeMountAdapter_Hotfix
Behebt den _e-NameError im vom Adapter generierten main_gui.py Code.
"""
import os, re, datetime

ROOT = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
MAIN = os.path.join(ROOT, "main_gui.py")
LOG = os.path.join(ROOT, "debug_output.txt")
ARCHIV = os.path.join(ROOT, "_Archiv")

def log(msg: str):
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[{ts}] [1177a-Hotfix] {msg}\n")

def backup(path: str):
    os.makedirs(ARCHIV, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    dst = os.path.join(ARCHIV, f"main_gui.py.{ts}.bak")
    with open(path, "rb") as src, open(dst, "wb") as out:
        out.write(src.read())
    log(f"Backup erstellt: {dst}")

def fix_main():
    if not os.path.exists(MAIN):
        print("main_gui.py nicht gefunden.")
        return 1
    src = open(MAIN, encoding="utf-8").read()
    backup(MAIN)
    fixed = re.sub(r"except Exception as _e:", "except Exception as e:", src)
    fixed = re.sub(r"f\"\\[1177a\\]\\[ERROR\\] call _safe_add_intake_tab: {_e}\"",
                   "f\"[1177a][ERROR] call _safe_add_intake_tab: {e}\"", fixed)
    if fixed != src:
        open(MAIN, "w", encoding="utf-8").write(fixed)
        log("Hotfix angewendet (NameError _e → e).")
        print("[1177a-Hotfix] OK – Syntax repariert.")
        return 0
    else:
        print("[1177a-Hotfix] Keine Änderung nötig.")
        return 0

if __name__ == "__main__":
    raise SystemExit(fix_main())
