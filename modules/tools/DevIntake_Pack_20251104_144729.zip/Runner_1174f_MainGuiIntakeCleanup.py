# -*- coding: utf-8 -*-
"""
Runner 1174f – MainGui Intake Cleanup (stabil, final)
Entfernt den alten 1129-Block aus main_gui.py und prüft Syntax.
Behält die gültigen [1173f]-Helper.
"""
import os, re, time, shutil, py_compile, traceback, sys

ROOT = r"D:\ShrimpDev"
TARGET = os.path.join(ROOT, "main_gui.py")
ARCHIV = os.path.join(ROOT, "_Archiv")
DBG = os.path.join(ROOT, "debug_output.txt")
os.makedirs(ARCHIV, exist_ok=True)

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1174f {ts}] {msg}"
    print(line)
    with open(DBG, "a", encoding="utf-8") as f:
        f.write(line + "\n")

def backup(src):
    ts = str(int(time.time()))
    dst = os.path.join(ARCHIV, f"main_gui.py.{ts}.bak")
    shutil.copy2(src, dst)
    log(f"Backup erstellt: {dst}")
    return dst

def read(p):
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def write(p, s):
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)

def main():
    if not os.path.exists(TARGET):
        log("FEHLER: main_gui.py nicht gefunden.")
        return 2

    src = read(TARGET)
    bak = backup(TARGET)

    # Entferne alten 1129 Intake-Block
    cleaned = re.sub(
        r"# === 1129 Intake Load Guard.*?# === /1129 ===",
        "# === 1129 Intake Load Guard (entfernt durch 1174f) ===",
        src,
        flags=re.S
    )

    if cleaned == src:
        log("Keine Änderung erforderlich – 1129-Block nicht gefunden.")
    else:
        log("Alter 1129-Block erfolgreich entfernt.")

    tmp = TARGET + ".1174f.tmp"
    write(tmp, cleaned)

    try:
        py_compile.compile(tmp, doraise=True)
    except Exception as ex:
        log("Syntaxfehler -> Rollback.")
        log("".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        shutil.copy2(bak, TARGET)
        os.remove(tmp)
        return 1

    write(TARGET, cleaned)
    os.remove(tmp)
    log("Patch übernommen, Syntax OK.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
