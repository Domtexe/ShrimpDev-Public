# -*- coding: utf-8 -*-
"""
Runner_1153k_DetectGuard
Ziel (safe & minimal): Alle Aufrufe von self._detect(...) in IntakeFrame
werden auf self._detect_guarded(...) umgeleitet. Die Guard-Methode fängt
ALLE Exceptions ab (inkl. re.error), pingt eine Warnung und liefert False.
Keine Regex-/String-Umbauten -> keine Syntax-Risiken.

Ablauf: Backup -> Patch -> Syntaxcheck -> Import-Smoke -> Rollback bei Fehler
Report: _Reports/Runner_1153k_DetectGuard_report.txt
"""
from __future__ import annotations
import io, os, sys, time, shutil, ast, importlib.util, types, re
from pathlib import Path
import py_compile

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1153k_DetectGuard_report.txt"

def w(s=""):
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f: f.write(s.rstrip()+"\n")
    print(s)

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time()*1000)}.bak"; shutil.copy2(p, dst); return dst

GUARD_METHOD = r'''
def _detect_guarded(self, *args, **kwargs):
    """
    Ruft _detect sicher auf. Fängt alle Exceptions (inkl. Regex-Fehler) ab,
    zeigt eine kurze Warnung und liefert False statt zu crashen.
    """
    try:
        return self._detect(*args, **kwargs)
    except Exception as ex:
        try:
            self._ping(f"DetectWarn: {ex}")
        except Exception:
            pass
        return False
'''.strip("\n")

def patch(src: str) -> tuple[str, list[str]]:
    """Fügt _detect_guarded in class IntakeFrame ein und routet Aufrufe um."""
    changes = []
    tree = ast.parse(src)
    cls = None
    for n in tree.body:
        if isinstance(n, ast.ClassDef) and n.name == "IntakeFrame":
            cls = n; break
    if not cls:
        raise RuntimeError("class IntakeFrame nicht gefunden.")

    lines = src.splitlines()
    start = cls.lineno - 1
    end   = getattr(cls, "end_lineno", None) or len(lines)
    cls_src = "\n".join(lines[start:end])

    # 1) Guard-Methode einfügen/ersetzen
    rx_guard = re.compile(r'(?ms)^\s*def\s+_detect_guarded\s*\([^)]*\):\s*(?:\n\s+.+?)(?=^\s*def\s+\w+\s*\(|\Z)')
    if rx_guard.search(cls_src):
        cls_src = rx_guard.sub("\n    " + GUARD_METHOD.replace("\n","\n    ") + "\n", cls_src, count=1)
        changes.append("replaced:_detect_guarded")
    else:
        if not cls_src.endswith("\n"): cls_src += "\n"
        cls_src += "\n    " + GUARD_METHOD.replace("\n","\n    ") + "\n"
        changes.append("added:_detect_guarded")

    # 2) Aufrufe self._detect( ... ) -> self._detect_guarded( ... )
    #    ACHTUNG: Definition 'def _detect(' darf NICHT ersetzt werden.
    #    Wir patchen nur im Klassenblock-Text ausserhalb der def-Zeile.
    #    Simple, aber sichere Heuristik:
    cls_lines = cls_src.splitlines()
    for i, L in enumerate(cls_lines):
        if re.match(r'^\s*def\s+_detect\s*\(', L):
            # diese Zeile überspringen
            continue
        # innerhalb der Zeilen alle Vorkommen ersetzen
        if "self._detect(" in L:
            cls_lines[i] = L.replace("self._detect(", "self._detect_guarded(")
    cls_src = "\n".join(cls_lines)

    new_src = "\n".join(lines[:start]) + ("\n" if start else "") + cls_src + ("\n" if end < len(lines) else "") + "\n".join(lines[end:])
    return new_src, changes

def import_smoke()->tuple[bool,str]:
    """Importiert das Modul und ruft Guard einmal minimal auf (ohne GUI-Start)."""
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    # Shim: optionales Modul
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules")
        mod = types.ModuleType("modules.module_runner_exec")
        mod.run = lambda *a, **k: 0
        mod._log = lambda *a, **k: None
        sys.modules.setdefault("modules", pkg)
        sys.modules["modules.module_runner_exec"] = mod

    try:
        spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
        m = importlib.util.module_from_spec(spec); assert spec and spec.loader
        spec.loader.exec_module(m)  # type: ignore[attr-defined]
        # prüfe, ob Guard vorhanden ist
        import tkinter as tk
        r = tk.Tk(); r.withdraw()
        fr = m.IntakeFrame(r)
        if not hasattr(fr, "_detect_guarded"):
            return False, "Guard fehlt"
        # Minimaler Aufruf (falls _detect existiert, wird er im Guard gerufen)
        ok = fr._detect_guarded()
        r.destroy()
        return True, "Import/Guard OK"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"

def main()->int:
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass
    w("[R1153k] DetectGuard – Start")

    if not MODFILE.exists():
        w("[ERR] module_code_intake.py fehlt.")
        return 1

    bak = backup(MODFILE); w(f"[Backup] {bak.name}")
    src = io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

    try:
        new_src, changes = patch(src)
    except Exception as e:
        w(f"[ERR] Patch: {e}")
        return 1

    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(new_src)
    w("[Write] " + (", ".join(changes) if changes else "keine Änderungen"))

    # Syntaxcheck
    try:
        py_compile.compile(str(MODFILE), doraise=True); w("[Syntax] OK")
    except Exception as e:
        w(f"[Syntax] Fehler: {e} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    ok, msg = import_smoke()
    if not ok:
        w(f"[Live] Probe-Fehler: {msg} -> Rollback"); shutil.copy2(bak, MODFILE); return 1
    w(f"[Live] {msg}")

    w("[SUM] Alle _detect-Aufrufe laufen jetzt über Guard. Regex-/Detect-Fehler crashen Intake nicht mehr.")
    w("[R1153k] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
