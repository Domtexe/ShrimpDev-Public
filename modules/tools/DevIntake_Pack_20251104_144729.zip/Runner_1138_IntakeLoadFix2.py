# -*- coding: utf-8 -*-
"""
Runner_1138_IntakeLoadFix2
- Fix 1: Guard-Button an vorhandenes 'bar' hängen (statt self.frm_actions).
- Fix 2: kaputten try/except-Block im Toolbar-Bereich reparieren.
Idempotent, erstellt Backup unter _Archiv\module_code_intake.py.<ts>.bak
"""
import io, os, re, time, shutil, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")

def backup(path):
    os.makedirs(ARCH, exist_ok=True)
    ts = str(int(time.time()))
    bak = os.path.join(ARCH, os.path.basename(path) + "." + ts + ".bak")
    shutil.copy2(path, bak)
    print(f"[R1138] Backup -> {bak}")

def load_text(path):
    with io.open(path, "r", encoding="utf-8", newline="") as f:
        return f.read()

def save_text(path, text):
    with io.open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

def patch_guard_parent(s):
    """
    Sucht die Zeile, die den Guard-Button erstellt und ersetzt ein
    'ttk.Button(self.frm_actions, ...' durch 'ttk.Button(bar, ...)'
    Zusätzlich: definiert self.frm_actions = bar, falls im Code später verwendet.
    """
    changed = False

    # 1) Direkter Austausch des Parents
    pat_parent = re.compile(r'(ttk\.Button\()\s*self\.frm_actions(\s*,)', re.M)
    if pat_parent.search(s):
        s = pat_parent.sub(r'\1bar\2', s)
        print("[R1138] btn_guard: Parent self.frm_actions -> bar")
        changed = True

    # 2) Falls der Button ohne frm_actions schon an bar hängt, aber es gibt KEIN self.frm_actions:
    #    setze defensiv eine Alias-Zuweisung 'self.frm_actions = bar' direkt nach der bar-Erzeugung.
    if "self.frm_actions" in s:
        # wurde schon ersetzt oder wird noch gebraucht -> Alias sicherstellen
        pat_bar_line = re.compile(r'^\s*bar\s*=\s*ttk\.Frame\(self\).*$', re.M)
        m = pat_bar_line.search(s)
        if m and "self.frm_actions = bar" not in s:
            insert_pos = m.end()
            s = s[:insert_pos] + "\n        self.frm_actions = bar  # alias for guard-parent" + s[insert_pos:]
            print("[R1138] Alias gesetzt: self.frm_actions = bar")
            changed = True
    return s, changed

def patch_try_block(s):
    """
    Repariert das Muster:
        try:
            <binds...>
        try:
            pass
        except Exception:
            pass
    -> zweites 'try:' wird zu 'except Exception:'
    """
    changed = False
    # Wir fassen nur den lokalen Toolbar-Block an (Zeile enthält binds und kurz darauf 'try:' 'pass' 'except')
    pat = re.compile(
        r'(\n\s*try:\s*\n(?:\s*.+\n){0,6})'  # erster try: mit ein paar Zeilen Inhalt (binds)
        r'(\s*)try:\s*\n'                    # das irrtümliche zweite 'try:'
        r'\s*pass\s*\n'
        r'\s*except\s+Exception\s*:\s*\n'
        r'\s*pass',
        re.M
    )
    def _fix(m):
        nonlocal changed
        changed = True
        head = m.group(1)
        indent = m.group(2)
        return f"{head}{indent}except Exception:\n{indent}    pass"
    s_new = pat.sub(_fix, s)

    if changed:
        print("[R1138] Toolbar-try/except repariert.")
    return s_new, changed

def main():
    print("[R1138] IntakeLoadFix2 - Start")
    if not os.path.isfile(MOD):
        print(f"[R1138] Datei fehlt: {MOD}")
        return 2

    backup(MOD)
    src = load_text(MOD)
    any_change = False

    src, ch1 = patch_guard_parent(src); any_change |= ch1
    src, ch2 = patch_try_block(src);    any_change |= ch2

    if not any_change:
        print("[R1138] Keine Änderungen nötig.")
        return 0

    # Syntaxcheck vor Schreiben (sofern möglich)
    tmp = MOD + ".tmp1138"
    save_text(tmp, src)
    try:
        compile(src, MOD, "exec")
    except SyntaxError as ex:
        print(f"[R1138] SyntaxError nach Patch -> Rollback: {ex}")
        try: os.remove(tmp)
        except OSError: pass
        return 1

    # Schreiben
    save_text(MOD, src)
    try: os.remove(tmp)
    except OSError: pass
    print("[R1138] Fix angewendet.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
