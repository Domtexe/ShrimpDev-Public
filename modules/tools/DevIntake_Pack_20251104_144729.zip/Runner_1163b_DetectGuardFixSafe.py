# -*- coding: utf-8 -*-
"""
R1163b DetectGuardFixSafe
- Repariert genau die Guard-Regex (vom R1162-Scanner gemeldet), ohne riskante Meta-Ersetzungen.
- Sucht r"...or\\t\\s*\\w+...class\\s+\\w+\\(...if\\s+..." in re.search()/re.match() String-Literalen
  und ersetzt NUR das Literal durch SAFE_LITERAL (balanciert, getestet).
- Safety: Backup, Syntax-Check, Rollback.
"""
from __future__ import annotations
import os, io, re, time, shutil, py_compile, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOGF = os.path.join(ROOT, "debug_output.txt")

SAFE_PATTERN = r'(?:\bor\t\s*\w+|\bdef\s+\w+\s*\(|\bclass\s+\w+\s*\(|\bif\s+)'
SAFE_LITERAL_DQ = 'r"' + SAFE_PATTERN.replace('"', r'\"') + '"'
SAFE_LITERAL_SQ = "r'" + SAFE_PATTERN.replace("'", r"\'") + "'"

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1163b] {ts} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f: f.write(line)
    except Exception: pass
    print(line, end="")

def backup(p: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, dst); log(f"Backup: {p} -> {dst}"); return dst

def patch(src: str) -> tuple[str, list[str]]:
    changes = []
    # Muster: re.search( r" ... or\t\s*\w+ ... class\s+\w+\( ... if\s+ ... ", text )
    # Wir matchen das LITERAL innerhalb des Aufrufs (doppelte oder einfache Quotes).
    rx_dq = re.compile(r'(re\.(?:search|match)\s*\(\s*)r"([^"]*or\\t\\s*\\w+[^"]*class\\s+\\w+\\([^"]*if\\s+[^"]*)"(\s*,)', re.DOTALL)
    rx_sq = re.compile(r"(re\.(?:search|match)\s*\(\s*)r'([^']*or\\t\\s*\\w+[^']*class\\s+\\w+\\([^']*if\\s+[^']*)'(\s*,)", re.DOTALL)

    def repl_dq(m: re.Match) -> str:
        changes.append("Replaced broken guard-regex literal (double-quote)")
        return m.group(1) + SAFE_LITERAL_DQ + m.group(3)

    def repl_sq(m: re.Match) -> str:
        changes.append("Replaced broken guard-regex literal (single-quote)")
        return m.group(1) + SAFE_LITERAL_SQ + m.group(3)

    new = rx_dq.sub(repl_dq, src, count=1)
    if new == src:
        new = rx_sq.sub(repl_sq, src, count=1)
    return new, changes

def main() -> int:
    try:
        if not os.path.isfile(MOD):
            log(f"[ERR] Not found: {MOD}"); return 2
        with io.open(MOD, "r", encoding="utf-8") as f: src = f.read()
        bak = backup(MOD)
        new, changes = patch(src)
        if not changes:
            log("No changes applied (target literal not found)."); return 0
        with io.open(MOD, "w", encoding="utf-8", newline="\n") as f: f.write(new)
        for c in changes: log(f"Change: {c}")
        try:
            py_compile.compile(MOD, doraise=True); log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}"); shutil.copy2(bak, MOD); log("Restored from backup."); return 3
        # Sanity des neuen Patterns:
        try: re.compile(SAFE_PATTERN); log("Probe-Compile of SAFE_PATTERN: OK")
        except re.error as ex:
            log(f"[ERR] SAFE_PATTERN compile failed: {ex}"); shutil.copy2(bak, MOD); log("Restored from backup."); return 4
        log("R1163b completed successfully."); return 0
    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}"); return 1

if __name__ == "__main__":
    raise SystemExit(main())
