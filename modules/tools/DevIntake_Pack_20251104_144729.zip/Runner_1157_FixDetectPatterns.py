# -*- coding: utf-8 -*-
"""
Runner_1157_FixDetectPatterns (R1157b)
- Fix für Regex-Ersetzungen ohne 'bad escape \s' in Replacement-Templates
- Repariert:
  1) Name-Detection: entfernt '...'-Artefakt vor Runner_
  2) Python-Heuristik: ersetzt defektes 'impo...name__' im Regex-String
  3) INI-Header-CharClass: stellt [^\]] sicher
  4) LED-Canvas-Parameter: width=14, height=14, highlightthickness=0
- Safety: Backup nach _Archiv/, Syntax-Check via py_compile, Logging
"""
from __future__ import annotations
import os, re, io, time, shutil, traceback, py_compile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOGF = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    line  = f"[R1157b] {stamp} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    ts = str(int(time.time()))
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    shutil.copy2(path, dst)
    log(f"Backup: {path} -> {dst}")
    return dst

def _fix_name_ellipsis(src: str) -> tuple[str, bool]:
    # Entfernt genau das '...' vor Runner_ hinter name :=, ohne \s im Replacement-Template
    pat = re.compile(r"(?im)(name\s*[:=]\s*)\.\.\.(Runner_[0-9]{3,5}[_A-Za-z0-9\-]+)")
    changed = False
    def repl(m: re.Match) -> str:
        nonlocal changed
        changed = True
        return m.group(1) + m.group(2)
    return pat.sub(repl, src), changed

def _fix_python_heuristic(src: str) -> tuple[str, bool]:
    """
    Ersetzt NUR das defekte Teilfragment 'impo...name__' innerhalb des Regex-Strings.
    Wir suchen konservativ nach dem Muster 'impo...name__' (inkl. Punkten) in Anführungszeichen,
    damit wir keine echten Code-Stellen anfassen.
    """
    # sehr zielgerichtet: innerhalb von r"....impo...name__...."
    pat = re.compile(r'(r["\'].*?)(impo\.\.\.name__)(.*?["\'])', re.DOTALL)
    changed = False
    def repl(m: re.Match) -> str:
        nonlocal changed
        changed = True
        head, bad, tail = m.group(1), m.group(2), m.group(3)
        # Ersetze durch robustere Variante (nur im Regex-String, daher Backslashes nötig)
        good = r"import\s+\w+|if\s+__name__\s*==\s*['\"]__main__['\"]|from\s+\w+\s+import"
        return head + good + tail
    return pat.sub(repl, src), changed

def _fix_ini_charclass(src: str) -> tuple[str, bool]:
    """
    Korrigiert kaputte Klassen wie [^ -]] oder [^\-]] auf [^\]]
    Wir arbeiten mit callable, um keine Template-Escapes zu triggern.
    """
    changed = False
    # mehrere Varianten konservativ abdecken
    variants = [
        r"[^\-]]",    # häufige kaputte Form
        r"[^ \-]]",   # mit Space
        r"[^\]]\]",   # doppelt schief
    ]
    for v in variants:
        pat = re.compile(re.escape(v))
        if pat.search(src):
            src = pat.sub(lambda _: r"[^\]]", src)
            changed = True
    return src, changed

def _normalize_led_canvas(src: str) -> tuple[str, bool]:
    """
    Normalisiert Canvas-Zeilen für LEDs.
    """
    changed = False
    def fix_canvas_line(line: str) -> str:
        nonlocal changed
        orig = line
        # Stelle sicher: width=14
        if "width=" in line:
            line = re.sub(r"width\s*=\s*\d+", "width=14", line)
        else:
            line = line.replace("tk.Canvas(", "tk.Canvas(width=14, ", 1)

        # Stelle sicher: height=14
        if "height=" in line:
            line = re.sub(r"height\s*=\s*\d+", "height=14", line)
        else:
            # nach width einsetzen
            line = line.replace("width=14", "width=14, height=14", 1)

        # Stelle sicher: highlightthickness=0
        if "highlightthickness" in line:
            line = re.sub(r"highlightthickness\s*=\s*\d+", "highlightthickness=0", line)
        else:
            # vor schließender Klammer einfügen
            line = line.rstrip()
            if line.endswith(")"):
                line = line[:-1] + ", highlightthickness=0)"
        if line != orig:
            changed = True
        return line

    out_lines = []
    for ln in src.splitlines(True):
        if re.search(r"self\.\w+\s*=\s*tk\.Canvas\(", ln):
            ln = fix_canvas_line(ln)
        out_lines.append(ln)
    return "".join(out_lines), changed

def patch_text(src: str) -> tuple[str, list[str]]:
    changelog: list[str] = []

    # 1) Name-Ellipsis entfernen
    src, ch = _fix_name_ellipsis(src)
    if ch: changelog.append("Removed '...' artifact in name detection")

    # 2) Python-Heuristik-Fragment reparieren
    src, ch = _fix_python_heuristic(src)
    if ch: changelog.append("Repaired python heuristic fragment inside regex string")

    # 3) INI-Header CharClass korrigieren
    src, ch = _fix_ini_charclass(src)
    if ch: changelog.append("Fixed INI header character class to [^\\]]")

    # 4) LED-Canvas normalisieren
    src, ch = _normalize_led_canvas(src)
    if ch: changelog.append("Normalized LED Canvas parameters")

    return src, changelog

def main() -> int:
    try:
        if not os.path.isfile(MOD):
            log(f"[ERR] Not found: {MOD}")
            return 2

        with io.open(MOD, "r", encoding="utf-8") as f:
            src = f.read()

        bak = backup(MOD)
        new, changes = patch_text(src)

        if changes:
            with io.open(MOD, "w", encoding="utf-8", newline="\n") as f:
                f.write(new)
            for c in changes:
                log(f"Change: {c}")
        else:
            log("No changes applied (patterns not found or already healthy).")

        # Syntax-Check
        try:
            py_compile.compile(MOD, doraise=True)
            log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}")
            shutil.copy2(bak, MOD)
            log("Restored from backup due to syntax error.")
            return 3

        log("R1157b completed successfully.")
        return 0

    except Exception as e:
        tb = traceback.format_exc()
        log(f"[EXC] {e}\n{tb}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
