# [1175h] IntakeCleanRestore – Backup, Neuaufbau, Smoke
from __future__ import annotations
import io, os, sys, time, py_compile, traceback
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
ARCH.mkdir(exist_ok=True)

def _write_atomic(path: Path, data: str) -> None:
    tmp = path.with_suffix(path.suffix + ".1175h.tmp")
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(data)
    os.replace(tmp, path)

def _smoke_compile(path: Path) -> None:
    py_compile.compile(str(path), doraise=True)

def main() -> int:
    print("[1175h] Root  :", ROOT)
    if not MOD.exists():
        print("[1175h] WARN: module_code_intake.py fehlt – wird neu angelegt.")

    # -------- Stabiler Shim -----------
    # Regeln:
    #  - Versucht vorhandene build_ui/CodeIntake zu nutzen (nicht zerstörend)
    #  - Liefert ansonsten einen vollständigen, funktionierenden Intake-Tab
    #  - Keine verschachtelten except-Kaskaden, saubere Shortcuts/Buttons
    NEW = r'''from __future__ import annotations
import os, re, json, sys, subprocess
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

_PADX, _PADY = 8, 6

def _log(msg: str):
    try:
        with open(r"D:\ShrimpDev\debug_output.txt", "a", encoding="utf-8") as f:
            f.write(f"[INTAKE] {msg}\n")
    except Exception:
        pass

# ---- Explorer öffnen (robust) ----------------------------------------------
def _open_explorer_select(path: str) -> None:
    try:
        if not path:
            return
        p = os.path.normpath(path)
        if os.path.isfile(p):
            subprocess.Popen(['explorer', '/select,', p])
        elif os.path.isdir(p):
            subprocess.Popen(['explorer', p])
        else:
            subprocess.Popen(['explorer', os.path.dirname(p) or p])
    except Exception:
        _log("open_explorer_select failed")

# ---- Heuristik: INI? --------------------------------------------------------
def _detect_is_ini(head: str) -> bool:
    sec  = re.search(r'^\s*\[[^\[\]\r\n]+\]\s*$', head, re.M) is not None
    kv   = re.search(r'^\s*[A-Za-z0-9_.-]+\s*=\s*.+$', head, re.M) is not None
    return sec and kv

# ---- Minimaler, aber funktionsfähiger Intake-Frame --------------------------
class _IntakeMinimal(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.var_path = tk.StringVar()
        self._build()

    def _build(self):
        # Toolbar
        bar = ttk.Frame(self); bar.grid(row=0, column=0, sticky="ew", padx=_PADX, pady=(_PADY, 4))
        for i in range(8): bar.grid_columnconfigure(i, weight=0, minsize=92)

        ttk.Button(bar, text="Öffnen",   command=self.on_open).grid(row=0, column=0, padx=(0,6))
        ttk.Button(bar, text="Speichern",command=self.on_save).grid(row=0, column=1, padx=(0,6))
        ttk.Button(bar, text="Detect",   command=self.on_detect).grid(row=0, column=2, padx=(0,6))
        ttk.Button(bar, text="Explorer", command=self.on_explorer).grid(row=0, column=3, padx=(0,6))
        ttk.Button(bar, text="Leeren",   command=self.on_clear).grid(row=0, column=4, padx=(0,6))

        # Pfad-Zeile
        row = ttk.Frame(self); row.grid(row=1, column=0, sticky="ew", padx=_PADX, pady=(0,4))
        row.grid_columnconfigure(1, weight=1)
        ttk.Label(row, text="Pfad:").grid(row=0, column=0, sticky="w")
        ttk.Entry(row, textvariable=self.var_path).grid(row=0, column=1, sticky="ew", padx=(6,0))

        # Editor
        self.txt = tk.Text(self, wrap="none", undo=True, height=24)
        self.txt.grid(row=2, column=0, sticky="nsew", padx=_PADX, pady=(_PADY, _PADY))
        self.grid_rowconfigure(2, weight=1); self.grid_columnconfigure(0, weight=1)

        # Shortcuts
        self.bind_all("<Control-s>", lambda e: (self.on_save(), "break"))
        self.bind_all("<Control-o>", lambda e: (self.on_open(), "break"))
        self.bind_all("<Control-i>", lambda e: (self.on_detect(), "break"))
        self.bind_all("<Delete>",    lambda e: (self.on_clear(), "break"))

    def on_open(self):
        fn = filedialog.askopenfilename(title="Datei öffnen", initialdir=str(Path.cwd()))
        if not fn: return
        self.var_path.set(fn)
        try:
            with open(fn, "r", encoding="utf-8") as f:
                self.txt.delete("1.0", "end"); self.txt.insert("1.0", f.read())
        except Exception as e:
            messagebox.showerror("Fehler", f"Konnte Datei nicht lesen:\n{e}")

    def on_save(self):
        fn = self.var_path.get().strip()
        if not fn:
            fn = filedialog.asksaveasfilename(title="Datei speichern", defaultextension=".txt",
                                              filetypes=[("Text", "*.txt;*.json;*.ini;*.cfg;*.yaml;*.yml;*.py"), ("Alle", "*.*")])
            if not fn: return
            self.var_path.set(fn)
        try:
            with open(fn, "w", encoding="utf-8", newline="\n") as f:
                f.write(self.txt.get("1.0","end-1c"))
        except Exception as e:
            messagebox.showerror("Fehler", f"Konnte Datei nicht schreiben:\n{e}")

    def on_detect(self):
        head = self.txt.get("1.0", "1.1000")
        kind = "INI" if _detect_is_ini(head) else "JSON" if re.search(r'^\s*[\{\[]', head) else "Text"
        messagebox.showinfo("Detect", f"Erkannt: {kind}")

    def on_explorer(self):
        _open_explorer_select(self.var_path.get().strip())

    def on_clear(self):
        if messagebox.askyesno("Bestätigung", "Editor wirklich leeren?"):
            self.txt.delete("1.0", "end")

# ---- Öffentliche Fabrik -----------------------------------------------------
def create_intake_tab(parent):
    \"\"\"Erstellt den Intake-Tab.
    Falls das (intakte) Altsystem (`build_ui` oder `CodeIntake`) vorhanden ist, wird es verwendet.
    Sonst fällt es auf _IntakeMinimal zurück.
    \"\"\"
    # Versuch: vorhandene Build-Funktion
    try:
        if "build_ui" in globals() and callable(build_ui):
            return build_ui(parent)
    except Exception:
        _log("build_ui() vorhanden aber fehlerhaft – fallback")

    # Versuch: Klasse CodeIntake mit .build()
    try:
        if "CodeIntake" in globals():
            inst = CodeIntake()  # type: ignore[name-defined]
            if hasattr(inst, "build") and callable(inst.build):
                return inst.build(parent)  # type: ignore[attr-defined]
    except Exception:
        _log("CodeIntake vorhanden aber fehlerhaft – fallback")

    # Fallback: minimaler, funktionsfähiger Tab
    return _IntakeMinimal(parent)
'''
    # ------------------------------------

    # Schreibe Modul
    if MOD.exists():
        bak = ARCH / f"module_code_intake.py.{int(time.time())}.bak"
        bak.write_bytes(MOD.read_bytes())
        print(f"[1175h] Backup erstellt: {bak}")

    _write_atomic(MOD, NEW)

    # Syntax-/Smoke-Check
    try:
        _smoke_compile(MOD)
    except Exception:
        print("[1175h] Syntax-Check FEHLER!")
        traceback.print_exc()
        return 10

    print("[1175h] Patch übernommen, Syntax OK.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
