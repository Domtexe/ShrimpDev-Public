# -*- coding: utf-8 -*-
"""
Runner_1173d: Fix fuer fehlende return-Anweisungen in Fallback-Frames
- patched idempotent in D:\ShrimpDev\main_gui.py
- Fuegt 'return frm' ans Ende der Fallback-Funktionen:
  IntakeFrame(...), AgentFrame(...), ProjectFrame(...)
- Erstellt Backup unter _Archiv\main_gui.py.<timestamp>.bak
"""
import io, os, re, shutil, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "main_gui.py")
ARCH  = os.path.join(ROOT, "_Archiv")
os.makedirs(ARCH, exist_ok=True)

def _read(p):
    with io.open(p, "r", encoding="utf-8", errors="replace") as f:
        return f.read()

def _write_backup_then(p, content):
    ts = str(int(time.time()))
    bak = os.path.join(ARCH, f"main_gui.py.{ts}.bak")
    shutil.copy2(p, bak)
    with io.open(p + ".1173d.tmp", "w", encoding="utf-8") as f:
        f.write(content)
    # Syntax-Check (kompiliert Bytecode)
    import py_compile
    py_compile.compile(p + ".1173d.tmp", doraise=True)
    os.replace(p + ".1173d.tmp", p)
    return bak

src = _read(TARGET)
orig = src

def patch_return_for(func_name: str) -> None:
    global src
    # grob: finde den Fallback-Body und pruefe auf 'return frm'
    pat = (
        r"(?ms)^def\s+{fn}\s*\(\s*master\b.*?\):\s*"
        r"(?:.*?\n)*?"                      # bis zur Erstellung des Frames
        r"(\s*)frm\s*=\s*ttk\.Frame\(.*?\)\s*\n"
        r"(?:.*?\n)*?"                      # innerhalb des Fallbacks
        r"(?:^def\s+__auto_fix_return__\s*\(.*?\)|^def\s+\w+\s*\(.*?\)|^class\s+\w+|\Z)"
    ).format(fn=re.escape(func_name))
    m = re.search(pat, src)
    if not m:
        return
    block_start = m.start()
    block_end   = m.end()
    block = src[block_start:block_end]
    if re.search(r"(?m)^\s*return\s+frm\s*$", block):
        return  # bereits ok
    # Fuege 'return frm' direkt vorm Blockende (vor naechster def/class) ein
    indent = m.group(1) or "    "
    insert_at = block_end - (len(block) - len(block.rstrip("\n")))
    new_block = block.rstrip("\n") + f"\n{indent}return frm\n"
    src = src[:block_start] + new_block + src[block_end:]

for fn in ("IntakeFrame", "AgentFrame", "ProjectFrame"):
    patch_return_for(fn)

if src != orig:
    try:
        bak = _write_backup_then(TARGET, src)
        print(f"[1173d] Backup erstellt: {bak}")
        print("[1173d] Patch erfolgreich eingefuegt und Syntax-Check OK.")
    except Exception as ex:
        # Rollback auf Original
        with io.open(TARGET, "w", encoding="utf-8") as f:
            f.write(orig)
        print("[1173d] FEHLER: Syntax-Check schlug fehl – Original wiederhergestellt.")
        raise
else:
    print("[1173d] Keine Aenderung notwendig (return frm bereits vorhanden).")
