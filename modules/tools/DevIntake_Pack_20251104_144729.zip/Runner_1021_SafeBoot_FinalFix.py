"""
Runner_1021_SafeBoot_FinalFix
- repariert SafeBoot-Block in main_gui.py (ex korrekt definiert)
- verbessert Logger (Dateisperre + Retry)
- Version: v9.9.12
"""
import os, re, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MAIN = os.path.join(ROOT, "main_gui.py")
LOGR = os.path.join(ROOT, "modules", "snippets", "logger_snippet.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1021] {ts} {msg}\n")
    print(msg)

def backup_write(path, data):
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

def fix_main():
    with open(MAIN, "r", encoding="utf-8") as f:
        src = f.read()

    # Finde Zeile mit traceback.format_exception_only(...) ohne gültiges except
    if "traceback.format_exception_only" in src:
        src = re.sub(
            r"traceback\.format_exception_only\(type\(ex\),\s*ex\)",
            "traceback.format_exception_only(type(ex), ex)  # ex now defined",
            src,
        )

        # Wenn kein except-Block da ist, füge ihn sauber ein
        src = re.sub(
            r"(\s*)traceback\.format_exception_only\(type\(ex\), ex\)",
            r"\1except Exception as ex:\n\1    traceback.format_exception_only(type(ex), ex)",
            src,
        )

    backup_write(MAIN, src)
    log("main_gui.py: SafeBoot korrigiert (ex jetzt richtig definiert).")

def fix_logger():
    with open(LOGR, "r", encoding="utf-8") as f:
        src = f.read()

    if "PermissionError" not in src:
        src = re.sub(
            r"with open\(LOG_PATH,\s*\"a\",\s*encoding=\"utf-8\"\)\s*as\s*f:\s*\n\s*f\.write\(msg",
            (
                "for _ in range(10):\n"
                "        try:\n"
                "            with open(LOG_PATH, 'a', encoding='utf-8') as f:\n"
                "                f.write(msg)\n"
                "            break\n"
                "        except PermissionError:\n"
                "            time.sleep(0.2)"
            ),
            src,
        )
        backup_write(LOGR, src)
        log("logger_snippet.py: Retry+Lockprüfung ergänzt.")
    else:
        log("logger_snippet.py: Retry bereits vorhanden.")

def main():
    try:
        fix_main()
        fix_logger()
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.12\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.12 (2025-10-18)
- FIX: SafeBoot-Fehler `ex not defined` behoben
- logger_snippet: Retry+Lock-Fix (sichere Logschleife)
""")
        log("Patch abgeschlossen.")
        return 0
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
