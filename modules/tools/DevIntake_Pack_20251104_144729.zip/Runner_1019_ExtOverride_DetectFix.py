"""
Runner_1019_ExtOverride_DetectFix
- _detect() respektiert var_ext_manual (manuelle Endung bleibt unverändert)
- Robustere QA prüft Logik in _detect
- Version -> v9.9.10
"""
from __future__ import annotations
import os, re, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1019] {ts} {msg}\n")
    print(msg, flush=True)

def backup_write(path: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    log(f"Backup: {path} -> {bck}")
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

DETECT_BLOCK = r'''
    def _detect(self):
        name = (self.var_name.get() or "").strip()
        nm, ext = os.path.splitext(name) if name else ("", "")
        # Nur automatisch setzen, wenn Nutzer die Endung NICHT manuell geändert hat
        if not getattr(self, "var_ext_manual", False):
            self.var_ext.set((ext or "").lower())
        else:
            # Manuelle Eingabe normalisieren (Punkt & kleinschreiben)
            try:
                self._normalize_ext()
            except Exception:
                pass
            ext = (self.var_ext.get() or "").lower()
        ok = bool(ext) and ext.lower() in {".py",".bat",".cmd",".json",".txt",".yml",".yaml",".ini",".md",".shcut"}
        self._update_led(self.led_detect, "green" if ok else "yellow")
        return ok
'''

def patch_detect(src: str) -> str:
    # Ersetze existierende _detect Implementierung durch die oben definierte
    new = re.sub(
        r"def\s+_detect\([\s\S]+?^\s*return\s+ok\s*$",
        DETECT_BLOCK.strip(),
        src,
        flags=re.MULTILINE
    )
    return new

def ensure_ext_bindings(src: str) -> str:
    # Falls var_ext_manual/Bindings fehlen (zur Sicherheit)
    if "self.var_ext_manual" not in src:
        src = src.replace(
            "self.var_ext = tk.StringVar(value=\"\")",
            "self.var_ext = tk.StringVar(value=\"\")\n        self.var_ext_manual = False"
        )
    src = re.sub(
        r'(ent_ext\s*=\s*ttk\.Entry\(head,\s*textvariable=self\.var_ext,\s*width=7\))',
        r'\1\n        ent_ext.bind("<KeyRelease>", self._on_ext_changed)\n        ent_ext.bind("<FocusOut>", self._normalize_ext)',
        src
    )
    if "def _on_ext_changed(" not in src:
        insert_pt = src.find("\n    # ---------- actions ----------")
        if insert_pt != -1:
            helper = r'''
    # --- ext override helpers ---
    def _on_ext_changed(self, _evt=None):
        self.var_ext_manual = True

    def _normalize_ext(self, _evt=None):
        ext = (self.var_ext.get() or "").strip()
        if ext and not ext.startswith("."):
            ext = "." + ext
        self.var_ext.set(ext.lower())
'''
            src = src[:insert_pt] + helper + src[insert_pt:]
    return src

def qa(src: str) -> bool:
    ok = True
    # 1) Prüfen, dass _detect den Guard hat
    has_guard = bool(re.search(r"def\s+_detect\([^\)]*\):[\s\S]+?if\s+not\s+getattr\(self,\s*\"var_ext_manual\"", src))
    log(f"[QA] Detect respektiert Override: {'OK' if has_guard else 'FEHLT'}"); ok &= has_guard
    # 2) Buttons-Callbacks weiterhin da
    for lbl in ("Erkennen (Ctrl+I)", "Speichern (Ctrl+S)", "Löschen (Entf)"):
        present = lbl in src
        log(f"[QA] Button '{lbl}': {'OK' if present else 'FEHLT'}"); ok &= present
    return ok

def main() -> int:
    try:
        with open(MOD, "r", encoding="utf-8") as f:
            src = f.read()
        patched = ensure_ext_bindings(patch_detect(src))
        if patched != src:
            backup_write(MOD, patched)
            log("module_code_intake.py: _detect überschrieben (Override-sicher) & Bindings abgesichert.")
        else:
            log("module_code_intake.py: keine Änderungen erforderlich.")

        # Meta & QA
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.10\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.10 (2025-10-18)
- FIX: _detect() überschreibt manuelle Endung nicht mehr (var_ext_manual-Guard)
""")

        with open(MOD, "r", encoding="utf-8") as f:
            now = f.read()
        ok = qa(now)
        return 0 if ok else 1
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
