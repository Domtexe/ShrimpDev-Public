from __future__ import annotations
import sys, json, traceback, py_compile, time
from pathlib import Path

ROOT   = Path(r"D:\ShrimpDev")
MODS   = ROOT / "modules"
TOOLS  = ROOT / "tools"
OUTDIR = ROOT / "_Reports" / "Preflight"
OUTDIR.mkdir(parents=True, exist_ok=True)

def _send(ev: dict):
    try:
        from modules.snippets.agent_client import send_event
        send_event({"runner":"R941", "level":"INFO", **ev})
    except Exception:
        try:
            inbox = ROOT/"_Reports"/"Agent"/"inbox"
            inbox.mkdir(parents=True, exist_ok=True)
            (inbox/f"{int(time.time())}.jsonl").open("a", encoding="utf-8").write(json.dumps({"runner":"R941", **ev}, ensure_ascii=False)+"\n")
        except Exception:
            pass

def _compile_all(paths: list[Path]):
    ok=0; bad=0; errs=[]
    for base in paths:
        if not base.exists(): continue
        for p in base.rglob("*.py"):
            try:
                py_compile.compile(str(p), doraise=True)
                ok+=1
            except Exception:
                bad+=1
                errs.append({"file": str(p), "err": traceback.format_exc(limit=1).strip()})
    return ok, bad, errs

def _registry_check():
    miss=[]
    try:
        from modules.module_registry import load_registry
        reg = load_registry()
        for m in reg.get("modules", []):
            if not Path(m.get("path","")).exists(): miss.append({"type":"module","name":m.get("name"),"path":m.get("path")})
        for r in reg.get("runners", []):
            if not Path(r.get("path","")).exists(): miss.append({"type":"runner","id":r.get("id"),"path":r.get("path")})
    except Exception as ex:
        return {"error": f"registry check failed: {ex}", "missing":[]}
    return {"missing": miss}

def main():
    ok, bad, errs = _compile_all([MODS, TOOLS])
    reg = _registry_check()
    rep = {
        "stats": {"ok": ok, "bad": bad},
        "errors": errs,
        "registry": reg,
        "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    }
    (OUTDIR/"report.json").write_text(json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
    level = "OK" if bad==0 and not reg.get("error") and not reg.get("missing") else ("WARN" if bad==0 else "ERROR")
    _send({"level": level, "msg": f"Preflight: OK={ok} BAD={bad}, missing={len(reg.get('missing',[]))}"})
    print(json.dumps(rep["stats"], ensure_ascii=False))
    if bad>0: sys.exit(2)
    if reg.get("error") or reg.get("missing"): sys.exit(1)
    sys.exit(0)

if __name__ == "__main__":
    main()
