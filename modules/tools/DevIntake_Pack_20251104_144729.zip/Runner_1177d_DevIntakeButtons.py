# -*- coding: utf-8 -*-
"""
Runner_1177d_DevIntakeButtons
Ziel:
- Dev-Intake Toolbar (Analyse, Master, Gate, Logs, Runner) zuverlässig herstellen,
  ohne bestehende Logik zu zerstören.
- module_code_intake.py: Hook auf attach_toolbar(self) einfügen (falls fehlt)
- Fehlende Handler minimal & kompatibel ergänzen.
- Alle Änderungen mit Backup + Log.
"""
from __future__ import annotations
import os, re, datetime, shutil

ROOT   = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
MOD    = os.path.join(ROOT, "modules")
SNIP   = os.path.join(MOD, "snippets")
TARGET = os.path.join(MOD, "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOGF   = os.path.join(ROOT, "debug_output.txt")

def ts(): return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def log(msg: str):
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(f"[{ts()}] [R1177d] {msg}\n")
    except Exception:
        pass

TOOLBAR_SNIPPET = r'''# -*- coding: utf-8 -*-
"""
snippet_dev_intake_toolbar – R1177d (ShrimpDev ONLY)
Baut die Dev-Toolbar im IntakeFrame:
- Analyse jetzt
- Master-Sanity
- Gate-Check
- Logs aktualisieren
- Runner starten (neuester)
Nutzt vorhandene Methoden, ergänzt ansonsten sanfte Fallbacks.
"""
from __future__ import annotations
import tkinter as tk
from tkinter import ttk, messagebox

def _bind_or_warn(frame, method_name, fallback_text):
    fn = getattr(frame, method_name, None)
    if callable(fn):
        return fn
    def _fallback():
        try:
            messagebox.showinfo("Nicht verfügbar", fallback_text)
        except Exception:
            pass
    return _fallback

def attach_toolbar(frame) -> None:
    # doppelte Anlage vermeiden
    if getattr(frame, "_dev_toolbar_ready", False):
        return
    tb = ttk.Frame(frame); tb.pack(fill="x")
    frame.btn_analyse = ttk.Button(tb, text="Analyse jetzt",
        command=_bind_or_warn(frame, "_run_analysis", "Analyse-Handler fehlt in diesem Intake."))
    frame.btn_master  = ttk.Button(tb, text="Master-Sanity",
        command=_bind_or_warn(frame, "_run_master_sanity", "Master-Sanity-Handler fehlt in diesem Intake."))
    frame.btn_gate    = ttk.Button(tb, text="Gate-Check",
        command=_bind_or_warn(frame, "_gate_check", "Gate-Check-Handler fehlt in diesem Intake."))
    frame.btn_refresh = ttk.Button(tb, text="Logs aktualisieren",
        command=_bind_or_warn(frame, "_restart_tail", "Log-Tail-Handler fehlt in diesem Intake."))
    frame.btn_runlast = ttk.Button(tb, text="Runner starten (neuester)",
        command=_bind_or_warn(frame, "_run_latest_runner", "Runner-Start-Handler fehlt in diesem Intake."))

    for w in (frame.btn_analyse, frame.btn_master, frame.btn_gate, frame.btn_refresh, frame.btn_runlast):
        w.pack(side="left", padx=4, pady=4)

    # Statuszeile – falls Intake keine hat, eine leichte hinzufügen
    if not hasattr(frame, "lbl_status"):
        frame.lbl_status = ttk.Label(frame, text="Bereit (Dev-Intake).", anchor="w")
        frame.lbl_status.pack(fill="x")

    frame._dev_toolbar_ready = True
'''

FALLBACK_METHODS = r'''
# ---- R1177d: sanfte Fallback-Methoden (nur anfügen, wenn im Intake fehlen) ----
def _r1177d_log(_msg: str):
    try:
        import os, datetime
        root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        logfile = os.path.join(root, "debug_output.txt")
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(logfile, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] [DevIntake] {_msg}\\n")
    except Exception:
        pass

def _r1177d_infobox(title: str, msg: str):
    try:
        from tkinter import messagebox
        messagebox.showinfo(title, msg)
    except Exception:
        pass

# Analyse (Syntax-Check) – minimal
def _run_analysis(self):
    try:
        import os
        from tkinter import ttk
        if not hasattr(self, "tree"):
            # lege minimalen Tree an, falls der alte Intake keinen hat
            self.nb = getattr(self, "nb", ttk.Notebook(self)); self.nb.pack(fill="both", expand=True)
            self.pg_an = ttk.Frame(self.nb); self.nb.add(self.pg_an, text="🧠 Analyse")
            self.tree = ttk.Treeview(self.pg_an, columns=("file","status","detail"), show="headings")
            for c in ("file","status","detail"):
                self.tree.heading(c, text=c.title()); self.tree.column(c, width=400 if c=="detail" else 240, anchor="w")
            self.tree.pack(fill="both", expand=True)
        # sehr einfacher Syntax-Check über modules/ + tools/
        roots = [os.path.join(os.path.dirname(__file__), ".."), os.path.join(os.path.dirname(__file__), "..","tools")]
        files = []
        for base in roots:
            b = os.path.abspath(base)
            if not os.path.isdir(b): continue
            for r,_,fns in os.walk(b):
                for fn in fns:
                    if fn.lower().endswith(".py"):
                        files.append(os.path.join(r, fn))
        # Tabelle leeren
        try:
            for iid in self.tree.get_children(""):
                self.tree.delete(iid)
        except Exception:
            pass
        ok = bad = 0
        for p in sorted(files):
            try:
                src = open(p, "r", encoding="utf-8").read()
                compile(src, p, "exec")
                st, detail = "OK", ""
                ok += 1
            except SyntaxError as e:
                st, detail = "SYNTAX", f"{e.msg} @ {e.lineno}:{e.offset}"
                bad += 1
            except Exception as e:
                st, detail = "ERROR", str(e)
                bad += 1
            try:
                self.tree.insert("", "end", values=(p, st, detail))
            except Exception:
                pass
        if hasattr(self, "lbl_status"):
            self.lbl_status.config(text=f"Analyse: {ok} OK, {bad} Probleme, gesamt {len(files)}.")
        _r1177d_log(f"Analyse done: {ok} ok / {bad} bad / {len(files)} files")
    except Exception as e:
        _r1177d_log(f"Analyse error: {e}")

# Master-Sanity (derzeit: Alias auf Analyse)
def _run_master_sanity(self):
    try:
        self._run_analysis()
        _r1177d_infobox("Master-Sanity", "Master-Sanity ausgeführt (Basis: Syntax-Check).")
    except Exception as e:
        _r1177d_log(f"MasterSanity error: {e}")

# Gate-Check (Shim-API vollständig?)
def _gate_check(self):
    try:
        from modules import module_shim_intake as shim
        ok = all(hasattr(shim, n) for n in ("mount_intake_tab","_mount_intake_tab_shim","_remount_intake_tab_shim"))
        txt = "OK – Shim API vollständig." if ok else "FEHLER – Shim API unvollständig."
        if hasattr(self, "lbl_status"): self.lbl_status.config(text="Gate: " + txt)
        _r1177d_log("Gate " + txt)
    except Exception as e:
        _r1177d_log(f"Gate error: {e}")

# Logs tail neu starten (sanft)
def _restart_tail(self):
    try:
        if hasattr(self, "_stop_tail") and hasattr(self, "_tail_thread"):
            try:
                if self._tail_thread and self._tail_thread.is_alive():
                    self._stop_tail.set()
                    self._tail_thread.join(timeout=1.0)
            except Exception:
                pass
        import threading, time, os
        self._stop_tail = threading.Event()
        # einfachster Tail: Textfeld anlegen, wenn fehlt
        if not hasattr(self, "txt_log"):
            from tkinter import ttk, Text
            if not hasattr(self, "nb"):
                self.nb = ttk.Notebook(self); self.nb.pack(fill="both", expand=True)
            self.pg_log = ttk.Frame(self.nb); self.nb.add(self.pg_log, text="📄 Logs")
            self.txt_log = Text(self.pg_log, wrap="none", height=18)
            self.txt_log.pack(fill="both", expand=True)
        LOG = os.path.join(os.path.dirname(__file__), "..", "debug_output.txt")
        LOG = os.path.abspath(LOG)
        def _tail():
            pos = 0
            while not self._stop_tail.is_set():
                try:
                    with open(LOG, "r", encoding="utf-8") as f:
                        f.seek(pos); chunk = f.read(); pos = f.tell()
                    if chunk:
                        try:
                            self.txt_log.insert("end", chunk); self.txt_log.see("end")
                        except Exception:
                            pass
                except FileNotFoundError:
                    pass
                except Exception as e:
                    _r1177d_log(f"tail error: {e}")
                time.sleep(0.3)
        self._tail_thread = threading.Thread(target=_tail, daemon=True)
        self._tail_thread.start()
        if hasattr(self, "lbl_status"): self.lbl_status.config(text="Log-Tail läuft.")
    except Exception as e:
        _r1177d_log(f"restart_tail error: {e}")

# Neuesten Runner_*.bat starten und Ausgabe zeigen (sanft)
def _run_latest_runner(self):
    try:
        import re, subprocess, os
        tools = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "tools"))
        latest = None; best = -1.0
        if os.path.isdir(tools):
            for fn in os.listdir(tools):
                if re.match(r"Runner_\\d+.*\\.bat$", fn, flags=re.I):
                    p = os.path.join(tools, fn); mt = os.path.getmtime(p)
                    if mt > best: best, latest = mt, p
        if not latest:
            _r1177d_infobox("Runner", "Kein Runner_*.bat gefunden."); return
        # Textausgabe-Feld anlegen, wenn fehlt
        if not hasattr(self, "txt_run"):
            from tkinter import ttk, Text
            if not hasattr(self, "nb"):
                self.nb = ttk.Notebook(self); self.nb.pack(fill="both", expand=True)
            self.pg_run = ttk.Frame(self.nb); self.nb.add(self.pg_run, text="⚙️ Runner")
            self.txt_run = Text(self.pg_run, wrap="none", height=16); self.txt_run.pack(fill="both", expand=True)
        self.txt_run.insert("end", f"\n--- Starte: {latest} ---\n"); self.txt_run.see("end")
        proc = subprocess.Popen(latest, cwd=os.path.abspath(os.path.join(os.path.dirname(__file__), "..")),
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, shell=True)
        for line in proc.stdout:
            try:
                self.txt_run.insert("end", line); self.txt_run.see("end")
            except Exception:
                pass
        rc = proc.wait()
        try:
            self.txt_run.insert("end", f"--- Runner Ende (rc={rc}) ---\n"); self.txt_run.see("end")
        except Exception:
            pass
        _r1177d_log(f"Runner finished rc={rc}: {latest}")
    except Exception as e:
        _r1177d_log(f"run_latest_runner error: {e}")
'''

def read(p): return open(p, "r", encoding="utf-8").read()
def write(p, s):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f: f.write(s)

def backup(p):
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(p)}.{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.bak")
    shutil.copy2(p, bak)
    log(f"Backup: {bak}")
    return bak

def ensure_snippet():
    os.makedirs(SNIP, exist_ok=True)
    tgt = os.path.join(SNIP, "snippet_dev_intake_toolbar.py")
    write(tgt, TOOLBAR_SNIPPET)
    log("snippet_dev_intake_toolbar.py written.")

def patch_intake():
    if not os.path.exists(TARGET):
        raise FileNotFoundError("module_code_intake.py nicht gefunden")
    src = read(TARGET)
    orig = src

    # 1) Import hinzufügen
    if "snippet_dev_intake_toolbar" not in src:
        src = src.replace("\nfrom tkinter import", "\nfrom tkinter import")
        insert_point = 0
        m = re.search(r"import\s+tkinter\s+as\s+tk[\s\S]*?from\s+tkinter\s+import\s+ttk", src)
        if m:
            insert_point = m.end()
        imp = "\nfrom modules.snippets.snippet_dev_intake_toolbar import attach_toolbar\n"
        src = src[:insert_point] + imp + src[insert_point:]

    # 2) attach_toolbar(self) im IntakeFrame.__init__ aufrufen
    if "attach_toolbar(self)" not in src:
        m = re.search(r"class\s+IntakeFrame\s*\([\w\.]+\)\s*:\s*[\s\S]*?def\s+__init__\s*\(\s*self[^)]*\)\s*:\s*[\s\S]*?^\s*super\(\)\.__init__\(\s*master\s*\)", src, flags=re.M)
        if m:
            # einfügen direkt nach super().__init__(master)
            insert_pos = m.end()
            call = "\n        try:\n            attach_toolbar(self)\n        except Exception as _e:\n            try:\n                _log(f\"[R1177d] toolbar attach failed: {_e}\")\n            except Exception:\n                pass\n"
            src = src[:insert_pos] + call + src[insert_pos:]
        else:
            # Fallback: am Anfang der Klasse nach __init__
            src = re.sub(r"(class\s+IntakeFrame\s*\([\w\.]+\)\s*:\s*\n\s*def\s+__init__\s*\(\s*self[^)]*\)\s*:\s*\n)",
                         r"\1        try:\n            attach_toolbar(self)\n        except Exception:\n            pass\n", src, count=1)

    # 3) Fehlende Methoden sanft ergänzen (nur wenn wirklich fehlen)
    need_any = False
    for meth in ("_run_analysis","_run_master_sanity","_gate_check","_restart_tail","_run_latest_runner"):
        if re.search(rf"def\s+{meth}\s*\(", src) is None:
            need_any = True
            break
    if need_any:
        src = src + "\n" + FALLBACK_METHODS

    if src != orig:
        backup(TARGET)
        write(TARGET, src)
        log("module_code_intake.py patched.")
    else:
        log("module_code_intake.py unchanged (already had toolbar & handlers).")

def main():
    ensure_snippet()
    patch_intake()
    print("[R1177d] Dev-Intake toolbar + handlers ensured.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
