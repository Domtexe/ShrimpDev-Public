# -*- coding: utf-8 -*-
"""
Runner_1171m_IntakeToolbarReflowFix
- Repariert "unexpected indent" nach fehlerhaften Toolbar-Patches
- Erzeugt/aktualisiert modules/snippets/intake_toolbar_reflow_helper.py
- Verdrahtet Import+Call in module_code_intake.py::_build_ui(self) (idempotent)
- Sichert Backup und rollt bei Fehlern zurück
"""
from __future__ import annotations
import io, os, re, sys, time, shutil, py_compile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
MOD  = ROOT / "modules" / "module_code_intake.py"
SNIP_DIR = ROOT / "modules" / "snippets"
SNIP = SNIP_DIR / "intake_toolbar_reflow_helper.py"
ARCH = ROOT / "_Archiv"
ARCH.mkdir(exist_ok=True, parents=True)
SNIP_DIR.mkdir(exist_ok=True, parents=True)

HELPER_SRC = r'''# -*- coding: utf-8 -*-
"""
Helper: intake_toolbar_reflow_helper
- Keine Layout-Änderungen, die brechen könnten.
- Stelle bereit, damit der Call in _build_ui(self) sicher ist.
"""
from __future__ import annotations
from typing import Any

def intake_toolbar_reflow(self: Any) -> None:
    try:
        # TODO (optional): hier später Reflow/Anordnung implementieren.
        # Aktuell defensiv "no-op", damit nichts kaputt geht.
        return
    except Exception:
        # nie propagieren – UI darf nicht crashen
        return
'''

IMPL_IMPORT_LINE = 'from modules.snippets.intake_toolbar_reflow_helper import intake_toolbar_reflow as _sd_toolbar_reflow'
IMPL_CALL_BLOCK = (
    '        try:\n'
    '            _sd_toolbar_reflow(self)\n'
    '        except Exception:\n'
    '            pass\n'
)

TOPLEVEL_BAD_PREFIX = re.compile(r'^(?P<indent>[ \t]+)(?P<head>(try:|except\b|finally:|def\b|class\b|from\b|import\b))', re.M)

def _read(p: Path) -> str:
    return p.read_text(encoding='utf-8')

def _write(p: Path, s: str) -> None:
    p.write_text(s, encoding='utf-8', newline='\n')

def _backup(p: Path) -> Path:
    ts = str(int(time.time()))
    dst = ARCH / f"{p.name}.{ts}.bak"
    shutil.copy2(p, dst)
    return dst

def _syntax_check(p: Path) -> None:
    py_compile.compile(str(p), doraise=True)

def _dedent_toplevel_candidates(src: str) -> str:
    """
    Dedentet nur wirklich Top-Level-Kandidaten, die fälschlich eingerückt sind.
    (Greift NICHT innerhalb von Funktionen/Klassen.)
    Heuristik: Alle Zeilen, die mit indent + (try:|except|finally:|def|class|from|import) beginnen
    UND bei denen die vorherige nicht-leere Zeile NICHT mit ':' endet und keine fortgesetzte Klammerung hat.
    """
    lines = src.splitlines(True)
    out = []
    for i, line in enumerate(lines):
        m = TOPLEVEL_BAD_PREFIX.match(line)
        if not m:
            out.append(line); continue
        # Kontext prüfen – vorhergehende "relevante" Zeile
        j = i - 1
        prev = ""
        while j >= 0:
            prev = lines[j].rstrip('\r\n')
            if prev.strip() != "":
                break
            j -= 1
        prev_stripped = prev.strip()
        cont = (prev_stripped.endswith(':') or prev_stripped.endswith('\\')
                or prev_stripped.endswith(',') or prev_stripped.endswith('(')
                or prev_stripped.endswith('[') or prev_stripped.endswith('{'))
        if not cont:
            # sicherer Kandidat: Einrückung entfernen
            out.append(line[len(m.group('indent')):])
        else:
            out.append(line)
    return ''.join(out)

def _ensure_helper_file():
    if not SNIP.exists():
        _write(SNIP, HELPER_SRC)
        return True
    # idempotent aktualisieren (nur wenn leer/anders)
    existing = _read(SNIP)
    if 'def intake_toolbar_reflow' not in existing:
        _write(SNIP, HELPER_SRC)
        return True
    return False

def _inject_import(src: str) -> str:
    if IMPL_IMPORT_LINE in src:
        return src
    # nach den bestehenden Imports einsortieren
    imp_block = re.search(r'^(?:from\s+\S+\s+import\s+.*|import\s+.*)(?:\r?\n)+', src, re.M)
    if imp_block:
        end = imp_block.end()
        return src[:end] + IMPL_IMPORT_LINE + '\n' + src[end:]
    # fallback: ganz am Anfang nach Shebang/encoding
    first_code = re.search(r'^(?!#).+', src, re.M)
    insert_at = first_code.start() if first_code else 0
    return src[:insert_at] + IMPL_IMPORT_LINE + '\n' + src[insert_at:]

def _inject_call_into_build_ui(src: str) -> str:
    """
    hänge am Ende von def _build_ui(self): den try/except-Call an, falls nicht vorhanden.
    """
    if '_build_ui(' not in src:
        return src
    if '_sd_toolbar_reflow(self)' in src:
        return src

    # Position der Funktion finden
    m = re.search(r'^\s*def\s+_build_ui\s*\(\s*self\s*[^\)]*\)\s*:', src, re.M)
    if not m:
        return src
    start = m.end()
    # Einrückung der Funktion ermitteln
    func_indent = re.match(r'(\s*)def', src[m.start():]).group(1)
    # Ende der Funktion finden (erste Zeile <= func_indent, die nicht leer/Kommentar ist)
    lines = src[start:].splitlines(True)
    pos = start
    body_indent = None
    end_idx = None
    for idx, ln in enumerate(lines):
        if body_indent is None:
            # erste Body-Zeile -> deren indent ist body_indent
            m2 = re.match(r'(\s*)\S', ln)
            if not m2:
                pos += len(ln); continue
            body_indent = m2.group(1)
        # Funktionsende?
        if ln.strip() and not ln.startswith(body_indent):
            end_idx = idx
            break
        pos += len(ln)
    end = pos if end_idx is not None else len(src)

    # Call mit richtiger Einrückung
    call_block = IMPL_CALL_BLOCK
    # sicherstellen, dass die Einrückung zur Funktion passt (wir nutzen 8 Spaces für Body)
    call_block = call_block.replace('        ', body_indent)

    return src[:end] + call_block + src[end:]

def main():
    if not MOD.exists():
        print(f"[1171m] Datei nicht gefunden: {MOD}")
        sys.exit(2)

    backup = _backup(MOD)
    changed = False

    # 1) Helper sicherstellen
    if _ensure_helper_file():
        print("[1171m] Helper aktualisiert/erstellt:", SNIP)
        changed = True

    # 2) Quelltext laden
    src = _read(MOD)

    # 3) Offensichtliche fehlerhafte Top-Level-Einrückungen korrigieren
    fixed = _dedent_toplevel_candidates(src)
    if fixed != src:
        src = fixed
        changed = True

    # 4) Import einspritzen (idempotent)
    new_src = _inject_import(src)
    if new_src != src:
        src = new_src
        changed = True

    # 5) Call in _build_ui(self) einspritzen (idempotent, am Ende der Funktion)
    new_src = _inject_call_into_build_ui(src)
    if new_src != src:
        src = new_src
        changed = True

    # 6) Schreiben & Syntax-Check
    if changed:
        _write(MOD, src)
    try:
        _syntax_check(MOD)
    except Exception as exc:
        # Rollback
        shutil.copy2(backup, MOD)
        print("[1171m] Syntax-Check FEHLER -> Rollback auf Backup.")
        raise

    print("[1171m] Patch erfolgreich und Syntax-Check OK.")
    sys.exit(0)

if __name__ == "__main__":
    main()
