# -*- coding: utf-8 -*-
"""
R1164c ClearExt & OptionalConfirm
- Hängt eine Wrapper-Methode _on_clear_editor_clicked(self) in module_code_intake.py an:
    * optionaler Confirm-Dialog (Checkbox "Nicht wieder anzeigen" -> self._skip_confirm_clear)
    * ruft vorhandenen Clear-Handler auf (falls vorhanden)
    * leert zusätzlich 'Endung' (self.var_ext / self.entry_ext)
- Koppelt diese Methode an den Button mit text="Editor leeren" (ohne bestehende Handler zu löschen),
  indem nach der Button-Zeile eine .configure(command=...) Zeile eingeschoben wird.
- 0-Risiko: Wenn Button nicht gefunden wird, macht der Runner nichts.
"""
from __future__ import annotations
import os, io, time, shutil, py_compile, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOGF = os.path.join(ROOT, "debug_output.txt")

INJECT_HELPER = r'''
# --- R1164c helper: clear wrapper with optional confirm & ext clear ---
def _on_clear_editor_clicked(self):
    try:
        import tkinter as tk
        from tkinter import ttk, messagebox
        # optional: nicht wieder anzeigen
        if not getattr(self, "_skip_confirm_clear", False):
            dlg = tk.Toplevel(self)
            dlg.title("Bestätigung")
            dlg.transient(self.winfo_toplevel()); dlg.grab_set()
            ttk.Label(dlg, text="Editor wirklich leeren?").grid(row=0, column=0, columnspan=2, padx=10, pady=8, sticky="w")
            var_skip = tk.BooleanVar(value=False)
            ttk.Checkbutton(dlg, text="Nicht wieder anzeigen", variable=var_skip).grid(row=1, column=0, columnspan=2, padx=10, pady=(0,8), sticky="w")
            res = {"ok": False}
            def _ok(): res["ok"]=True; dlg.destroy()
            def _cancel(): dlg.destroy()
            ttk.Button(dlg, text="Ja", command=_ok).grid(row=2, column=0, padx=10, pady=8)
            ttk.Button(dlg, text="Nein", command=_cancel).grid(row=2, column=1, padx=10, pady=8)
            dlg.bind("<Return>", lambda e: _ok()); dlg.bind("<Escape>", lambda e: _cancel()); dlg.wait_window()
            if res["ok"] and var_skip.get():
                setattr(self, "_skip_confirm_clear", True)
            if not res["ok"]:
                return
        # existierenden Clear-Handler suchen/aufrufen (best effort)
        called = False
        for name in ("clear_editor","on_clear_editor"):
            fn = getattr(self, name, None)
            if callable(fn):
                try: fn()
                except TypeError: fn(self)  # falls als Funktion definiert
                called = True
                break
        # Extension-Feld leeren
        try:
            getattr(self, 'var_ext').set('')
        except Exception:
            try:
                ent = getattr(self, 'entry_ext'); ent.delete(0, 'end')
            except Exception:
                pass
        # Falls kein Handler existierte: versuche, Textwidget zu leeren (best effort)
        if not called:
            for attr in ("txt","text","editor","txt_editor"):
                w = getattr(self, attr, None)
                if getattr(w, "delete", None):
                    try: w.delete("1.0","end"); break
                    except Exception: pass
    except Exception:
        pass
'''

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with io.open(LOGF, "a", encoding="utf-8") as f: f.write(f"[R1164c] {ts} {msg}\n")
    print(f"[R1164c] {ts} {msg}")

def backup(p: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, dst); log(f"Backup: {p} -> {dst}"); return dst

def attach_to_button(src: str) -> tuple[str, bool]:
    """
    Sucht die Zeile mit text="Editor leeren" (oder 'Editor leeren').
    Nimmt an, dass davor in der Zeile ein Variablenname steht: <name> = ttk.Button(...)
    Fügt direkt NACH dieser Zeile: <name>.configure(command=self._on_clear_editor_clicked)
    """
    lines = src.splitlines(True)
    for i, ln in enumerate(lines):
        if 'text="Editor leeren"' in ln or "text='Editor leeren'" in ln:
            # Variable links vom '=' abschneiden
            eq = ln.find("=")
            if eq == -1: continue
            var = ln[:eq].strip()
            # Sicherheitscheck: plausible Variablenbezeichnung
            if not var or any(ch in var for ch in " ()[]{}.,"):
                continue
            insert = f"{var}.configure(command=self._on_clear_editor_clicked)\n"
            # nur einfügen, wenn nicht schon vorhanden
            j = i+1
            if j < len(lines) and insert == lines[j]:
                return src, True
            lines.insert(i+1, insert)
            return "".join(lines), True
    return src, False

def inject_helper(src: str) -> tuple[str, bool]:
    if "_on_clear_editor_clicked" in src:
        return src, True
    return (src.rstrip() + "\n\n" + INJECT_HELPER + "\n"), True

def main() -> int:
    try:
        if not os.path.isfile(MOD): log(f"[ERR] Not found: {MOD}"); return 2
        with io.open(MOD, "r", encoding="utf-8") as f: src = f.read()
        bak = backup(MOD)

        new_src, ok1 = attach_to_button(src)
        new_src, ok2 = inject_helper(new_src if ok1 else src)

        if not (ok1 and ok2):
            log("No changes applied (button not found)."); return 0

        with io.open(MOD, "w", encoding="utf-8", newline="\n") as f: f.write(new_src)
        try: py_compile.compile(MOD, doraise=True); log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}"); shutil.copy2(bak, MOD); log("Restored from backup."); return 3
        log("R1164c completed successfully.")
        return 0
    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}"); return 1

if __name__ == "__main__":
    raise SystemExit(main())
