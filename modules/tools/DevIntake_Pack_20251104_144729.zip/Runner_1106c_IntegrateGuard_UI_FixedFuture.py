# -*- coding: utf-8 -*-
"""
Runner_1106c_IntegrateGuard_UI_FixedFuture
Repariert den Fehler 'from __future__ imports must occur at the beginning of the file'
und fügt den Guard-Button sauber nach allen from/__future__ Imports ein.
"""

from __future__ import annotations
import os, re, sys, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")

def backup(path: str) -> str:
    ts = int(time.time())
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    with open(path, "rb") as fsrc, open(dst, "wb") as fdst:
        fdst.write(fsrc.read())
    print(f"[R1106c] Backup: {path} -> {dst}")
    return dst

def read(p: str) -> str:
    with open(p, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def write(p: str, txt: str):
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(txt)

def insert_imports_after_future(src: str) -> tuple[str, bool]:
    """Fügt neue Imports *nach* from __future__ ein."""
    need = ["import tempfile", "import subprocess", "import sys", "import os"]
    changed = False

    # Position NACH dem letzten "from __future__" suchen
    lines = src.splitlines(True)
    last_future = -1
    for i, line in enumerate(lines[:20]):
        if "from __future__" in line:
            last_future = i

    insert_idx = last_future + 1
    # Prüfen, ob die Imports schon vorhanden sind
    missing = [imp for imp in need if imp not in src]
    if not missing:
        return src, False

    block = "".join(imp + "\n" for imp in missing) + "\n"
    lines.insert(insert_idx + 1, block)
    changed = True
    return "".join(lines), changed

def inject_guard_button_and_handler(src: str) -> tuple[str, bool]:
    """Fügt den Guard-Button und Handler nur ein, wenn nicht vorhanden."""
    if "_on_click_guard" in src:
        return src, False
    add_block = (
        "\n"
        "    def _on_click_guard(self, _evt=None):\n"
        "        try:\n"
        "            import tempfile, subprocess, sys, os\n"
        "            guard = os.path.join('tools', 'Runner_1106_ShrimpGuard_Integriert.py')\n"
        "            tmp = tempfile.NamedTemporaryFile(prefix='shrimp_runner_', suffix='.txt', delete=False)\n"
        "            tmp.write(self.txt.get('1.0', 'end-1c').encode('utf-8'))\n"
        "            tmp.close()\n"
        "            cmd = [sys.executable, '-3', guard, '--check-text', tmp.name]\n"
        "            proc = subprocess.run(cmd, capture_output=True, text=True)\n"
        "            out = (proc.stdout or '') + (proc.stderr or '')\n"
        "            with open('debug_output.txt', 'w', encoding='utf-8') as f:\n"
        "                f.write(out)\n"
        "            if proc.returncode == 0:\n"
        "                self.lbl_ping.configure(text='✅ Guard OK')\n"
        "            elif proc.returncode == 1:\n"
        "                self.lbl_ping.configure(text='⚠️ Guard Warnungen')\n"
        "            else:\n"
        "                self.lbl_ping.configure(text='❌ Guard Fehler')\n"
        "        except Exception as e:\n"
        "            self.lbl_ping.configure(text=f'❌ {e}')\n"
    )
    if "class IntakeFrame" not in src:
        print("[R1106c] WARN: Klasse IntakeFrame nicht gefunden.")
        return src, False

    pos = src.find("class IntakeFrame")
    nextline = src.find("\n", pos)
    src = src[:nextline + 1] + add_block + src[nextline + 1:]
    return src, True

def main():
    if not os.path.exists(MOD):
        print("[R1106c] Datei nicht gefunden.")
        return 1

    txt = read(MOD)
    orig = txt
    txt, ch1 = insert_imports_after_future(txt)
    txt, ch2 = inject_guard_button_and_handler(txt)
    if not (ch1 or ch2):
        print("[R1106c] Keine Änderungen nötig.")
        return 0

    backup(MOD)
    try:
        compile(txt, MOD, "exec")
    except SyntaxError as e:
        print(f"[R1106c] SyntaxError nach Patch: Zeile {e.lineno}: {e.msg}")
        print("[R1106c] Datei bleibt unverändert.")
        return 2

    write(MOD, txt)
    print("[R1106c] Guard erfolgreich integriert.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
