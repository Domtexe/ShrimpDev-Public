# tools/Runner_1097b_FixIntake_Reindent2.py
from __future__ import annotations
import os, re, time

ROOT = os.path.abspath(os.path.dirname(__file__))
MOD  = os.path.normpath(os.path.join(ROOT, "..", "modules", "module_code_intake.py"))
ARCH = os.path.normpath(os.path.join(ROOT, "..", "_Archiv"))

def backup(path: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "rb") as fsrc, open(bak, "wb") as fdst:
        fdst.write(fsrc.read())
    print(f"[R1097b] Backup: {path} -> {bak}")

def read_norm(path: str) -> list[str]:
    with open(path, "rb") as f:
        s = f.read().decode("utf-8", errors="replace")
    s = s.replace("\r\n", "\n").replace("\r", "\n").replace("\t", "    ")
    return s.split("\n")

def write_back(path: str, lines: list[str]) -> None:
    s = "\n".join(lines).rstrip() + "\n"
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)

def find_block(lines: list[str], start_pat: re.Pattern[str]) -> tuple[int,int] | None:
    try:
        i0 = next(i for i,l in enumerate(lines) if start_pat.match(l))
    except StopIteration:
        return None
    # Ende: nächstes Top-Level class/def/import/from/#---- oder Dateiende
    end_pat = re.compile(r"^(class |def |from |import |#\s*-{2,})")
    i1 = len(lines)
    for k in range(i0+1, len(lines)):
        if lines[k] and not lines[k].startswith(" "):
            if end_pat.match(lines[k]):
                i1 = k
                break
    return (i0, i1)

def ensure_min_indent(lines: list[str], i0: int, i1: int, n: int = 4) -> None:
    pad = " " * n
    for i in range(i0, i1):
        t = lines[i]
        if not t:               # leer
            continue
        if t.startswith("#!"):  # shebang/top header unangetastet
            continue
        if t.strip() == "":     # whitespace-only
            continue
        if not t.startswith(" "):
            lines[i] = pad + t

def set_def_heads_to(lines: list[str], i0: int, i1: int, n: int = 4) -> None:
    """Alle def-Köpfe im Bereich exakt auf n Spaces setzen (nur erste Ebene)."""
    pat_def = re.compile(r"^(\s*)def\s+([A-Za-z_][A-Za-z_0-9]*)\s*\(")
    for i in range(i0, i1):
        m = pat_def.match(lines[i])
        if not m:
            continue
        # nur solche defs, die NICHT tiefer (>=8) eingerückt sind – also Methoden der Klasse
        if len(m.group(1)) < 8:
            rest = lines[i].lstrip()
            lines[i] = (" " * n) + rest

def indent_block(lines: list[str], start: int, stop: int, add: int = 4) -> None:
    pad = " " * add
    for i in range(start, stop):
        if lines[i].strip():
            lines[i] = pad + lines[i]

def fix_tooltip(lines: list[str]) -> None:
    # class Tooltip
    b = find_block(lines, re.compile(r"^class\s+Tooltip\b"))
    if not b: return
    i0, i1 = b
    # Falls _show/_hide fälschlich top-level stehen, mind. auf 4 Spaces ziehen
    ensure_min_indent(lines, i0+1, i1, 4)
    # und def-Köpfe in diesem Bereich exakt auf 4 setzen
    set_def_heads_to(lines, i0+1, i1, 4)

def fix_intake_frame(lines: list[str]) -> None:
    b = find_block(lines, re.compile(r"^class\s+IntakeFrame\b"))
    if not b: return
    i0, i1 = b
    # 1) Alles im Klassen-Body min. auf 4 Spaces (glättet vereinzelte 0-Indent-Zeilen)
    ensure_min_indent(lines, i0+1, i1, 4)
    # 2) Alle Methoden-Köpfe in der Klasse exakt auf 4 setzen
    set_def_heads_to(lines, i0+1, i1, 4)

def fix_send_to_recycle_bin(lines: list[str]) -> None:
    # kompletten Funktions-Body einrücken, falls top-level-Zeilen drin sind
    pat = re.compile(r"^def\s+_send_to_recycle_bin\s*\(")
    try:
        i = next(i for i,l in enumerate(lines) if pat.match(l))
    except StopIteration:
        return
    # Body bis zum nächsten Top-Level-Statement
    end_pat = re.compile(r"^(class |def |from |import |#\s*-{2,})")
    j = len(lines)
    for k in range(i+1, len(lines)):
        if lines[k] and not lines[k].startswith(" "):
            if end_pat.match(lines[k]):
                j = k
                break
    need = any(lines[t] and not lines[t].startswith(" ") for t in range(i+1, j))
    if need:
        indent_block(lines, i+1, j, 4)

def sanity_compile(lines: list[str]) -> None:
    src = "\n".join(lines).rstrip() + "\n"
    try:
        compile(src, MOD, "exec")
    except SyntaxError as ex:
        print("[R1097b] SyntaxError nach Fix:")
        a = src.splitlines()
        lo = max(0, ex.lineno-5)
        hi = min(len(a), ex.lineno+5)
        for n in range(lo, hi):
            mark = ">>" if (n+1)==ex.lineno else "  "
            print(f"{mark} {n+1:04d}: {a[n]}")
        raise

def main() -> int:
    if not os.path.exists(MOD):
        print(f"[R1097b] Datei nicht gefunden: {MOD}")
        return 1
    backup(MOD)
    lines = read_norm(MOD)

    # Reparaturen
    fix_tooltip(lines)
    fix_intake_frame(lines)
    fix_send_to_recycle_bin(lines)

    # Final-Check
    sanity_compile(lines)
    write_back(MOD, lines)
    print("[R1097b] Reindent abgeschlossen, Syntax OK.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
