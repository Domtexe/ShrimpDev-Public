# -*- coding: utf-8 -*-
"""
Runner_1177f_DevIntakeVisualFix
- Behebt den kaputten tkinter-Import in module_code_intake.py
- Erzwingt attach_toolbar(self) NACH _build_ui()
- Aktualisiert den Toolbar-Snippet auf grid-fähiges Mounting (sichtbar im Notebook)
- Backups -> _Archiv/, Logging -> debug_output.txt
"""
from __future__ import annotations
import os, re, shutil, datetime

ROOT   = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
MOD    = os.path.join(ROOT, "modules")
SNIP   = os.path.join(MOD, "snippets")
INTAKE = os.path.join(MOD, "module_code_intake.py")
TOOLBAR= os.path.join(SNIP, "snippet_dev_intake_toolbar.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOGF   = os.path.join(ROOT, "debug_output.txt")

def ts(): return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def log(msg: str):
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(f"[{ts()}] [R1177f] {msg}\n")
    except Exception:
        pass

def backup(path: str):
    if not os.path.exists(path): return
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(path)}.{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.bak")
    shutil.copy2(path, bak)
    log(f"Backup: {bak}")

NEW_SNIPPET = r'''# -*- coding: utf-8 -*-
"""
snippet_dev_intake_toolbar – R1177e/f (ShrimpDev ONLY)
- Grid-aware sichtbarer Mount: Toolbar in row=0; vorhandene Grid-Widgets -> +1 Row
- Fallback: pack(top) falls kein Grid verwendet wird
- Buttons: Analyse / Master-Sanity / Gate-Check / Logs / Runner
"""
from __future__ import annotations
import tkinter as tk
from tkinter import ttk, messagebox

def _bind_or_warn(frame, method_name, fallback_text):
    fn = getattr(frame, method_name, None)
    if callable(fn):
        return fn
    def _fallback():
        try:
            messagebox.showinfo("Nicht verfügbar", fallback_text)
        except Exception:
            pass
    return _fallback

def _uses_grid(w):
    try:
        for child in w.winfo_children():
            if child.winfo_manager() == "grid":
                return True
    except Exception:
        pass
    return False

def _shift_grid_rows_down(w):
    try:
        for child in w.winfo_children():
            if child.winfo_manager() != "grid":
                continue
            info = child.grid_info()
            r = int(info.get("row", 0) or 0)
            c = int(info.get("column", 0) or 0)
            sticky = info.get("sticky", "")
            child.grid_forget()
            child.grid(row=r+1, column=c, sticky=sticky)
    except Exception:
        pass

def attach_toolbar(frame) -> None:
    if getattr(frame, "_dev_toolbar_ready", False):
        return

    tb = ttk.Frame(frame)

    for text, mtd, fb in (
        ("Analyse jetzt", "_run_analysis", "Analyse-Handler fehlt in diesem Intake."),
        ("Master-Sanity", "_run_master_sanity", "Master-Sanity-Handler fehlt in diesem Intake."),
        ("Gate-Check", "_gate_check", "Gate-Check-Handler fehlt in diesem Intake."),
        ("Logs aktualisieren", "_restart_tail", "Log-Tail-Handler fehlt in diesem Intake."),
        ("Runner starten (neuester)", "_run_latest_runner", "Runner-Start-Handler fehlt in diesem Intake."),
    ):
        ttk.Button(tb, text=text, command=_bind_or_warn(frame, mtd, fb)).pack(side="left", padx=4, pady=4)

    if not hasattr(frame, "lbl_status"):
        frame.lbl_status = ttk.Label(frame, text="Bereit (Dev-Intake).", anchor="w")

    try:
        if _uses_grid(frame):
            _shift_grid_rows_down(frame)
            frame.grid_columnconfigure(0, weight=1)
            tb.grid(row=0, column=0, sticky="ew")
            if hasattr(frame, "lbl_status"):
                # sehr hohe row, damit die Statuszeile unten bleibt
                frame.lbl_status.grid(row=9999, column=0, sticky="ew")
        else:
            tb.pack(side="top", fill="x")
            if hasattr(frame, "lbl_status"):
                frame.lbl_status.pack(fill="x")
    except Exception:
        tb.pack(side="top", fill="x")
        if hasattr(frame, "lbl_status"):
            frame.lbl_status.pack(fill="x")

    frame._dev_toolbar_ready = True
'''

def patch_snippet():
    if not os.path.exists(TOOLBAR):
        raise FileNotFoundError("snippet_dev_intake_toolbar.py nicht gefunden")
    src = open(TOOLBAR, "r", encoding="utf-8").read()
    if "R1177e" in src or "R1177e/f" in src:
        # bereits modern – trotzdem überschreiben wir für Konsistenz
        pass
    backup(TOOLBAR)
    with open(TOOLBAR, "w", encoding="utf-8") as f:
        f.write(NEW_SNIPPET)
    log("Toolbar-Snippet aktualisiert (grid-aware).")

def patch_module():
    if not os.path.exists(INTAKE):
        raise FileNotFoundError("module_code_intake.py nicht gefunden")
    src = open(INTAKE, "r", encoding="utf-8").read()
    orig = src

    # 1) Tkinter-Import-Zeile reparieren:
    #    - stelle sicher: "from tkinter import ttk, filedialog, messagebox"
    #    - entferne versehentlich abgetrennte Zeilen wie ", filedialog, messagebox"
    src = re.sub(r"from\s+tkinter\s+import\s+ttk\s*\n\s*,\s*filedialog\s*,\s*messagebox", 
                 "from tkinter import ttk, filedialog, messagebox", src)
    src = re.sub(r"from\s+tkinter\s+import\s+ttk(?!,)", 
                 "from tkinter import ttk, filedialog, messagebox", src)

    # 2) Stelle sicher, dass der attach_toolbar-Import existiert
    if "from modules.snippets.snippet_dev_intake_toolbar import attach_toolbar" not in src:
        # Import nach den tkinter-Imports einfügen
        src = re.sub(r"(from\s+tkinter\s+import\s+ttk[^\n]*\n)", 
                     r"\1from modules.snippets.snippet_dev_intake_toolbar import attach_toolbar\n", src, count=1)

    # 3) Hook NACH _build_ui() in __init__
    if not re.search(r"_build_ui\(\)\s*\n\s*try:\s*attach_toolbar\(self\)", src):
        src = re.sub(
            r"(def\s+__init__\s*\(\s*self[^\)]*\)\s*:\s*[\s\S]*?_build_ui\(\)\s*)",
            r"\1\n        try:\n            attach_toolbar(self)\n        except Exception as _e:\n            try:\n                _log(f\"[R1177f] toolbar attach post-build failed: {_e}\")\n            except Exception:\n                pass\n",
            src, count=1
        )

    if src != orig:
        backup(INTAKE)
        with open(INTAKE, "w", encoding="utf-8") as f:
            f.write(src)
        log("module_code_intake.py gefixt (Import & Hook).")
    else:
        log("module_code_intake.py unverändert (bereits korrekt).")

def main() -> int:
    patch_snippet()
    patch_module()
    print("[R1177f] DevIntake Visual Fix applied.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
