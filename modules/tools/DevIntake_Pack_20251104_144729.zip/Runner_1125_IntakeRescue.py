# -*- coding: utf-8 -*-
"""
Runner_1125_IntakeRescue
- Repariert module_code_intake.py (Editor-Guards sauber in die Klasse, Duplicates raus)
- Opportunistische Härtung main_gui.py (nur falls altes fehlerhaftes Muster erkannt)
- Backups mit Zeitstempel -> _Archiv/
- Syntax-Check via compile(); Rollback bei Fehler
"""
import os, re, sys, time, traceback, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]  # .../ShrimpDev
ARCH = ROOT / "_Archiv"
MOD  = ROOT / "modules" / "module_code_intake.py"
MAIN = ROOT / "main_gui.py"

def ts() -> str:
    return str(int(time.time()))

def backup(p: Path) -> Path:
    ARCH.mkdir(parents=True, exist_ok=True)
    dst = ARCH / f"{p.name}.{ts()}.bak"
    shutil.copy2(p, dst)
    return dst

def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8")

def write_text(p: Path, s: str) -> None:
    p.write_text(s, encoding="utf-8", newline="\n")

def compile_check(label: str, code: str, filename: str) -> None:
    try:
        compile(code, filename, "exec")
    except Exception as ex:
        raise RuntimeError(f"[{label}] SyntaxError: {ex}")

def patch_intake(src: str) -> str:
    # 1) Doppelte/alte Guard-Blöcke entfernen
    pat_block = re.compile(
        r"\n[ \t]*#\s*---\s*Editor-Event-Guards\s*\(1123\).*?#\s*---\s*/Editor-Event-Guards\s*\(1123\)\s*---\s*\n",
        re.DOTALL)
    src = pat_block.sub("\n", src)

    pat_block2 = re.compile(
        r"\n[ \t]*#\s*---\s*Editor-Event-Guards\s*\(1124\).*?#\s*---\s*/Editor-Event-Guards\s*\(1124\)\s*---\s*\n",
        re.DOTALL)
    src = pat_block2.sub("\n", src)

    # 2) Einfügepunkt: direkt vor "Windows Recycle Bin helper"-Sektionskommentar
    anchor = re.search(r"\n#\s*-+\s*Windows Recycle Bin helper\s*-+\s*\n", src)
    if not anchor:
        raise RuntimeError("Anker 'Windows Recycle Bin helper' nicht gefunden – Abbruch.")
    insert_at = anchor.start()

    # 3) Sicherstellen: wir befinden uns vor dem Ende der Klasse IntakeFrame
    #    (Der Block wird als Klassen-Methoden eingefügt -> 4 Spaces indent)
    guards = """
    # --- Editor-Event-Guards (1125) -----------------------------------------
    def _safe_write(self, prefix: str, message: str) -> None:
        \"\"\"Sicher ins zentrale Log schreiben; bei Fehler Temp-Fallback.\"\"\"
        try:
            from modules.snippets.logger_snippet import write_log as _w
            _w(prefix, message)
        except Exception:
            try:
                p = os.path.join(os.path.dirname(os.path.dirname(__file__)), "debug_output.txt")
                _ts = time.strftime("%Y-%m-%d %H:%M:%S")
                with open(p, "a", encoding="utf-8", newline="\\n") as f:
                    f.write(f"[{prefix}] {_ts} {message}\\n")
            except Exception:
                pass

    def _ensure_editor_bindings(self) -> None:
        \"\"\"Genau ein Binding pro Event – Doppelbindungen vermeiden.\"\"\"
        try:
            self.txt.unbind("<<Paste>>")
            self.txt.unbind("<Control-v>")
            self.txt.unbind("<<Modified>>")
            self.txt.unbind("<KeyRelease>")
        except Exception:
            pass
        self.txt.bind("<<Paste>>", self._on_editor_paste)
        self.txt.bind("<Control-v>", self._on_editor_paste)
        self.txt.bind("<<Modified>>", self._on_editor_modified)
        self.txt.bind("<KeyRelease>", self._on_editor_key)

    def _on_editor_paste(self, _evt=None):
        \"\"\"Beim Einfügen nur Detect debouncen – kein erneutes Event-Feuern.\"\"\"
        try:
            self._schedule_detect(220)
        except Exception as ex:
            self._safe_write("INTAKE", f"PASTE_ERR: {ex!r}")

    def _on_editor_key(self, _evt=None):
        try:
            self._schedule_detect(250)
        except Exception as ex:
            self._safe_write("INTAKE", f"KEY_ERR: {ex!r}")

    def _on_editor_modified(self, _evt=None):
        try:
            try:
                self.txt.edit_modified(False)
            except Exception:
                pass
            self._schedule_detect(300)
        except Exception as ex:
            self._safe_write("INTAKE", f"MODIFIED_ERR: {ex!r}")

    def _schedule_detect(self, delay_ms: int = 250):
        \"\"\"Debounce für Detect – ältere Jobs abbrechen.\"\"\"
        try:
            if getattr(self, "_detect_job", None):
                try:
                    self.after_cancel(self._detect_job)
                except Exception:
                    pass
            self._detect_job = self.after(delay_ms, self._auto_detect_if_needed)
        except Exception as ex:
            self._safe_write("INTAKE", f"SCHED_ERR: {ex!r}")

    def _auto_detect_if_needed(self):
        try:
            self._ping("Auto-Erkennung…")
        except Exception:
            pass
        self._safe_detect()

    def _safe_detect(self):
        try:
            if hasattr(self, "_detect"):
                self._detect()
        except Exception as ex:
            import traceback
            self._safe_write("INTAKE", "DETECT_ERR\\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
            try:
                self._update_led(self.led_detect, "yellow")
            except Exception:
                pass
    # --- /Editor-Event-Guards (1125) ----------------------------------------
"""
    # 4) Guards in die Klasse IntakeFrame einsetzen (mit 4 Spaces indent)
    #    Wir finden das Ende der Klasse über den Anchor und suchen rückwärts die Class-Definition:
    class_m = re.search(r"class\\s+IntakeFrame\\b.*?:\\s*\\n", src)
    if not class_m:
        raise RuntimeError("class IntakeFrame nicht gefunden – Abbruch.")
    # Wir nehmen an: der Anchor liegt NACH der Klasse; dadurch ist Insert vor Anchor immer noch in der Klasse.
    # Sicherheitsnetz: prüfen die Einrückung der Zeile vor Anchor
    before = src[:insert_at]
    # letzte nicht-leere Zeile vor anchor
    lines = [ln for ln in before.splitlines() if ln.strip() != ""]
    last = lines[-1] if lines else ""
    # Wenn letzte Zeile mit 4 Spaces beginnt, sind wir im Klassenkörper – gut.
    # Falls nicht, versuchen wir den Insert kurz VOR der RecycleBin-Überschrift, aber innerhalb der Klasse:
    # Wir erzwingen Einrückung von 4 Spaces.
    guards_indented = "\n".join(("    " + ln if ln.strip() != "" else ln) for ln in guards.splitlines())

    # Einsetzen
    new_src = src[:insert_at] + guards_indented + src[insert_at:]
    return new_src

def maybe_patch_main(src: str) -> str:
    # Nur minimal: alte _ex-Verwechslung korrigieren, falls vorhanden.
    src = src.replace("type(_ex), _ex", "type(ex), ex")
    src = src.replace("format_exception_only(type(ex), ex)", "format_exception(type(ex), ex, ex.__traceback__)")
    return src

def main() -> int:
    print("[R1125] IntakeRescue – Start")

    if not MOD.exists():
        print(f"[R1125] FEHLT: {MOD}")
        return 2

    # --- Intake patchen ---
    b_mod = backup(MOD); print(f"[R1125] Backup: {MOD} -> {b_mod}")
    s_mod = read_text(MOD)
    try:
        s_mod_new = patch_intake(s_mod)
        compile_check("module_code_intake.py", s_mod_new, str(MOD))
        write_text(MOD, s_mod_new)
        print("[R1125] Intake gepatcht & Syntax OK.")
    except Exception as ex:
        print("[R1125] Intake-Patch FEHLER -> Rollback.")
        write_text(MOD, s_mod)  # original zurück
        print("".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        return 1

    # --- main_gui (opportunistisch) ---
    if MAIN.exists():
        s_main = read_text(MAIN)
        s_main_new = maybe_patch_main(s_main)
        if s_main_new != s_main:
            b_main = backup(MAIN); print(f"[R1125] Backup: {MAIN} -> {b_main}")
            try:
                compile_check("main_gui.py", s_main_new, str(MAIN))
                write_text(MAIN, s_main_new)
                print("[R1125] main_gui minimal korrigiert.")
            except Exception as ex:
                print("[R1125] main_gui-Patch FEHLER -> Rollback.")
                write_text(MAIN, s_main)
                print("".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
                return 1
        else:
            print("[R1125] main_gui: Keine Änderung nötig.")
    else:
        print("[R1125] Hinweis: main_gui.py nicht gefunden – übersprungen.")

    print("[R1125] OK – Runner abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
