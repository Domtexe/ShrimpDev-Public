# -*- coding: utf-8 -*-
r"""
Runner_1119_TkGuardTopLevel
- Injiziert einen Top-Level-Tkinter-Guard ganz oben in main_gui.py
  (NACH evtl. 'from __future__ import ...', aber VOR allen anderen Imports/Code).
- Der Guard überschreibt:
    * tkinter.Misc.report_callback_exception
    * tkinter.BaseWidget._report_exception
  → Kein Messagebox-Aufruf, keine Rekursion, nur sicherer Log-Append.
- Idempotent: fügt nichts doppelt ein.
- Legt Backups in _Archiv/ an und schreibt Bericht in _Reports/.
"""

from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
REPO = os.path.join(ROOT, "_Reports")
os.makedirs(ARCH, exist_ok=True)
os.makedirs(REPO, exist_ok=True)
REPORT = os.path.join(REPO, "Runner_1119_TkGuardTopLevel_report.txt")

def _logrep(msg: str) -> None:
    with open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip() + "\n")

def _backup(path: str) -> str:
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, dst)
    _logrep(f"[Backup] {path} -> {dst}")
    return dst

_GUARD_TAG = "# === 1119 TopLevel Tk Guard (auto) ==="

def _guard_snippet() -> str:
    return (
        f"\n{_GUARD_TAG}\n"
        "def __install_toplevel_tk_guard__():\n"
        "    import tkinter as _tk, sys, traceback, time, os\n"
        "    LOG = os.path.join(os.path.dirname(__file__), 'debug_output.txt')\n"
        "    busy = {'v': False}\n"
        "    def _safe_write(txt: str):\n"
        "        try:\n"
        "            with open(LOG, 'a', encoding='utf-8') as f:\n"
        "                f.write(txt)\n"
        "        except Exception:\n"
        "            pass\n"
        "    def _handler(exc, val, tb):\n"
        "        if busy['v']:\n"
        "            return\n"
        "        busy['v'] = True\n"
        "        try:\n"
        "            ts = time.strftime('%Y-%m-%d %H:%M:%S')\n"
        "            lines = ''.join(traceback.format_exception(exc, val, tb))\n"
        "            _safe_write(f\"[TK-EXC] {ts}\\n\" + lines + \"\\n\")\n"
        "        finally:\n"
        "            busy['v'] = False\n"
        "    try:\n"
        "        _tk.Misc.report_callback_exception = _handler  # type: ignore[attr-defined]\n"
        "    except Exception:\n"
        "        pass\n"
        "    try:\n"
        "        def _safe__report_exception(self):\n"
        "            et, ev, tb = sys.exc_info()\n"
        "            if et is not None:\n"
        "                _handler(et, ev, tb)\n"
        "        _tk.BaseWidget._report_exception = _safe__report_exception  # type: ignore[attr-defined]\n"
        "    except Exception:\n"
        "        pass\n"
        "    try:\n"
        "        from tkinter import messagebox as _mb\n"
        "        def _silent(*_a, **_k):\n"
        "            return None\n"
        "        for _n in ('showerror','showwarning','showinfo','askyesno','askokcancel'):\n"
        "            if hasattr(_mb, _n):\n"
        "                setattr(_mb, _n, _silent)\n"
        "    except Exception:\n"
        "        pass\n"
        "\n"
        "__install_toplevel_tk_guard__()\n"
        f"# === /1119 ===\n"
    )

def patch_main_gui() -> None:
    p = os.path.join(ROOT, "main_gui.py")
    if not os.path.exists(p):
        _logrep("[main_gui] nicht gefunden – Abbruch.")
        return

    with open(p, "r", encoding="utf-8") as f:
        src = f.read()

    if _GUARD_TAG in src:
        _logrep("[main_gui] Guard bereits vorhanden – keine Änderung.")
        return

    # Position: NACH allen future-Imports, aber VOR sonstigen Imports/Code
    # 1) block aller from __future__-Imports
    pos = 0
    m = re.match(r'^(?:\s*from\s+__future__\s+import[^\n]*\n)+', src, flags=re.MULTILINE)
    if m:
        pos = m.end()

    # 2) Einfügen direkt nach den future-Imports (oder Dateibeginn)
    new_src = src[:pos] + _guard_snippet() + src[pos:]

    _backup(p)
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(new_src)
    _logrep("[main_gui] Top-Level-Tk-Guard injiziert.")

def main():
    with open(REPORT, "w", encoding="utf-8", newline="\n") as f:
        f.write("Runner_1119_TkGuardTopLevel – Start\n")
    try:
        patch_main_gui()
        _logrep("OK – Runner abgeschlossen.")
    except Exception as ex:
        _logrep("FEHLER: " + repr(ex))

if __name__ == "__main__":
    main()
