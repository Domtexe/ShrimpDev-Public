# -*- coding: utf-8 -*-
"""
[R1143b] IntakeToolbarGuardFix_Safe
- Repariert Guard-Button (self.frm_actions -> bar)
- Repariert kaputten try/except-Block (Button-Bindings)
- Keine Named Groups im Regex mehr (Fehlerquelle beseitigt)
"""
import os, re, io, sys, time, shutil, py_compile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
os.makedirs(ARCH, exist_ok=True)

def backup(path):
    ts = str(int(time.time()*1000))
    dst = os.path.join(ARCH, os.path.basename(path) + "." + ts + ".bak")
    shutil.copy2(path, dst)
    print(f"[R1143b] Backup -> {dst}")
    return dst

def read(path):
    with io.open(path, "r", encoding="utf-8", newline="") as f:
        return f.read()

def write(path, text):
    with io.open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

def main():
    print("[R1143b] IntakeToolbarGuardFix_Safe – Start")

    if not os.path.isfile(MOD):
        print(f"[R1143b] FEHLER: Datei nicht gefunden: {MOD}")
        sys.exit(2)

    src = read(MOD)
    backup(MOD)
    changed = False
    text = src

    # --- Fix 1: frm_actions -> bar beim Guard-Button ---
    pat_guard = re.compile(
        r'(self\.btn_guard\s*=\s*ttk\.Button\()\s*self\.frm_actions(\s*,\s*text\s*=\s*".*?")',
        re.DOTALL
    )
    if pat_guard.search(text):
        text = pat_guard.sub(r'\1bar\2', text)
        changed = True
        print("[R1143b] Guard-Button-Container geändert auf 'bar'")

    # --- Fix 2: defekter doppelter try/except bei den Bindings ---
    # Wir suchen nach einem Muster mit zwei aufeinanderfolgenden 'try:' und machen daraus ein korrektes try/except.
    pat_double_try = re.compile(
        r'(^[ \t]*try:\s*\n'           # erstes try:
        r'(?:(?:^[ \t].*\n){0,25}?)'   # Bindings
        r'^[ \t]*try:\s*\n'            # zweites try:
        r'^[ \t]*pass\s*\n'            # pass
        r'^[ \t]*except\s+Exception:\s*\n'  # except Exception:
        r'^[ \t]*pass\s*\n',           # pass
        re.MULTILINE
    )

    def replace_double_try(m):
        body = m.group(0)
        lines = body.splitlines()
        indent = ""
        for ln in lines:
            if ln.strip():
                indent = re.match(r"^(\s*)", ln).group(1)
                break
        # Neuen except-Block anhängen
        return body.split("try:")[0] + "try:\n" + \
               "\n".join([l for l in lines if not l.strip().startswith("try") and not l.strip().startswith("except")]) + \
               f"\n{indent}except Exception:\n{indent}    pass\n"

    new_text, n = pat_double_try.subn(replace_double_try, text)
    if n > 0:
        text = new_text
        changed = True
        print(f"[R1143b] Doppelter try/except repariert ({n} Vorkommen)")

    if not changed:
        print("[R1143b] Keine Änderungen nötig.")
        sys.exit(0)

    write(MOD, text)
    print("[R1143b] Datei geschrieben.")

    try:
        py_compile.compile(MOD, doraise=True)
        print("[R1143b] Syntax OK.")
        sys.exit(0)
    except Exception as ex:
        print("[R1143b] SyntaxError:", ex)
        print("[R1143b] Rollback...")
        write(MOD, src)
        sys.exit(1)

if __name__ == "__main__":
    main()
