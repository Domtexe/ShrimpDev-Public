# -*- coding: utf-8 -*-
"""
Sicherer Intake-Mount-Fix:
- Backup von main_gui.py nach _Archiv\main_gui.py.<ts>.bak
- Import von _mount_intake_tab_shim sicherstellen
- Mount-Aufruf direkt nach Notebook-Erzeugung einfügen (idempotent)
- Syntax-Smoketest mit py_compile
"""
import os, re, time, io, py_compile, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
os.makedirs(ARCH, exist_ok=True)

MAIN = os.path.join(ROOT, "main_gui.py")
DBG  = os.path.join(ROOT, "debug_output.txt")

def log(msg):
    print(msg)
    try:
        with open(DBG, "a", encoding="utf-8") as f:
            f.write(f"[1176b {time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")
    except Exception:
        pass

def backup(path):
    ts = time.strftime("%Y%m%d_%H%M%S")
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    with open(path, "r", encoding="utf-8") as r, open(dst, "w", encoding="utf-8") as w:
        w.write(r.read())
    log(f"Backup erstellt: {dst}")

def read(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def write(path, data):
    with open(path, "w", encoding="utf-8") as f:
        f.write(data)

def ensure_import(src):
    if "from modules.module_shim_intake import _mount_intake_tab_shim" in src:
        return src, False
    # Import am Dateikopf nach anderen imports einsortieren
    lines = src.splitlines()
    insert_at = 0
    for i, line in enumerate(lines[:200]):
        if line.strip().startswith("import ") or line.strip().startswith("from "):
            insert_at = i + 1
    lines.insert(insert_at, "from modules.module_shim_intake import _mount_intake_tab_shim")
    return "\n".join(lines)+"\n", True

def ensure_mount_after_notebook(src):
    # Falls der Mount bereits existiert, nichts tun
    if re.search(r"_mount_intake_tab_shim\s*\(", src):
        return src, False

    # Versuche die Notebook-Variable (nb/whatever) zu erkennen
    m = re.search(r"^(\s*)([A-Za-z_]\w*)\s*=\s*ttk\.Notebook\s*\(", src, re.M)
    if not m:
        raise RuntimeError("Notebook-Erzeugung nicht gefunden (ttk.Notebook).")

    indent = m.group(1)
    nb_var = m.group(2)

    # Füge nach der Notebook-Erzeugung eine sichere Mount-Zeile ein
    # Wir suchen die nächste Zeile nach dem Matchende und injizieren dort.
    insert_pos = m.end()
    # springe ans Zeilenende
    insert_pos = src.find("\n", insert_pos)
    if insert_pos == -1:
        insert_pos = len(src)
    mount_line = f"{indent}_mount_intake_tab_shim({nb_var})  # injected by 1176b\n"
    new_src = src[:insert_pos+1] + mount_line + src[insert_pos+1:]
    return new_src, True

def main():
    if not os.path.exists(MAIN):
        log("main_gui.py nicht gefunden.")
        sys.exit(2)

    backup(MAIN)
    src = read(MAIN)

    changed_any = False
    src, imp_changed = ensure_import(src)
    changed_any |= imp_changed

    try:
        src, mnt_changed = ensure_mount_after_notebook(src)
        changed_any |= mnt_changed
    except RuntimeError as e:
        log(f"Mount-Analyse fehlgeschlagen: {e}")
        sys.exit(3)

    if not changed_any:
        log("Bereits korrekt – keine Anpassung erforderlich.")
        return

    write(MAIN, src)

    try:
        py_compile.compile(MAIN, doraise=True)
        log("Syntax OK.")
    except Exception as ex:
        log(f"Syntax-Check FEHLER -> Rollback. {ex}")
        # Rollback
        # Neuestes Backup zurückholen
        latest = sorted([p for p in os.listdir(ARCH) if p.startswith("main_gui.py.")])[-1]
        with open(os.path.join(ARCH, latest), "r", encoding="utf-8") as r, open(MAIN, "w", encoding="utf-8") as w:
            w.write(r.read())
        sys.exit(4)

if __name__ == "__main__":
    main()
