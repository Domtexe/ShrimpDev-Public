# -*- coding: utf-8 -*-
"""
Runner_1193_IntakeDetectUpgrade
- Legt robustes Erkennungs-Snippet an (snippet_intake_detect_v2.py)
- Patched module_code_intake.py minimal (Delegation _detect/_detect_ext)
- Sichert Backups und loggt in debug_output.txt
"""

import re, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MOD = ROOT / "modules" / "module_code_intake.py"
SNIP_DIR = ROOT / "modules" / "snippets"
SNIP = SNIP_DIR / "snippet_intake_detect_v2.py"
ARCH = ROOT / "_Archiv"
LOG = ROOT / "debug_output.txt"

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    LOG.write_text((LOG.read_text(encoding="utf-8", errors="ignore") if LOG.exists() else "")
                   + f"[R1193] {ts} {msg}\n", encoding="utf-8")

def bail(msg: str, rc: int = 1):
    log("FAIL: " + msg)
    print(msg)
    sys.exit(rc)

def ensure_dirs():
    for p in (SNIP_DIR, ARCH):
        p.mkdir(parents=True, exist_ok=True)

SNIP_SRC = r'''# -*- coding: utf-8 -*-
"""
snippet_intake_detect_v2
Robuste Intake-Erkennung:
- Endung .py/.bat via Heuristik + Compile-Fallback für Python
- Name aus Runner_####_* oder Fallback snippet_YYYYMMDD_HHMMSS
- LEDs/Status werden über vorhandene Variablen der Host-Instanz gesetzt:
    self.var_name (StringVar), self.var_ext (StringVar)
    self.led_name, self.led_ext, self.led_syntax, self.led_all  (BooleanVars)
    self.var_stat (StringVar)
    self.editor (Text)
    self._hilite_err(line_no|None)
    self._update_leds()
"""
from __future__ import annotations
import re, time

def detect_ext(text: str) -> str:
    t = (text or "")
    tl = t.lstrip().lower()

    # .bat sehr eindeutig
    if tl.startswith("@echo off") or any(
        kw in tl for kw in ("\nrem ", "\r\nrem ", "\n::", "\r\n::", "\ngoto ", "\r\ngoto ", "\n set ", "\r\n set ")
    ):
        return ".bat"

    # .py heuristisch
    if tl.startswith("#!") and "python" in tl[:80]:
        return ".py"
    if any(k in t for k in ("import ", "from ", "def ", "class ", "print(", "__name__")):
        return ".py"

    # Compile-Fallback: kompilierbar => .py
    try:
        compile(t, "<detect>", "exec")
        return ".py"
    except Exception:
        pass

    return ".txt"

def _detect_name(text: str, current: str | None) -> str:
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("#") or s.lower().startswith(("rem", "::")):
            continue
        m = re.search(r"(Runner_[0-9]{3,5}_[A-Za-z0-9_]+)", s)
        if m:
            return m.group(1)
    if current and current.strip():
        return current.strip()
    return "snippet_" + time.strftime("%Y%m%d_%H%M%S")

def run_detect(self) -> None:
    txt = self.editor.get("1.0", "end-1c")
    if not txt.strip():
        self.var_stat.set("Nichts zu erkennen.")
        return

    ext = detect_ext(txt)
    name = _detect_name(txt, self.var_name.get())

    # Syntax-Check nur bei .py
    syntax_ok = True
    err_line = None
    if ext == ".py":
        try:
            compile(txt, "<intake>", "exec")
        except SyntaxError as e:
            syntax_ok = False
            err_line = getattr(e, "lineno", None)
        except Exception:
            syntax_ok = False

    # UI aktualisieren
    try:
        self._hilite_err(err_line)
    except Exception:
        pass

    self.var_ext.set(ext)
    self.var_name.set(name)

    try:
        # LEDs setzen
        self.led_name.set(bool(name))
        self.led_ext.set(bool(ext))
    except Exception:
        pass

    try:
        self.led_syntax.set(bool(syntax_ok))
        self.led_all.set(bool(name and ext and syntax_ok))
    except Exception:
        pass

    try:
        self._update_leds()
    except Exception:
        pass

    self.var_stat.set(("Alles OK" if (name and ext and syntax_ok) else
                       ("Syntaxfehler" if not syntax_ok else "Name/Endung prüfen")))
'''

PATCH_DETECT_EXT_WRAPPER = r'''
def _detect_ext(text: str) -> str:
    """
    Delegiert auf robuste V2-Erkennung (snippet_intake_detect_v2).
    """
    try:
        from modules.snippets.snippet_intake_detect_v2 import detect_ext as _v2_detect_ext
        return _v2_detect_ext(text)
    except Exception:
        # Fallback: sehr einfache Heuristik wie früher
        t = (text or "").lower()
        if "@echo off" in t or "\nrem " in t or "\n::" in t:
            return ".bat"
        try:
            compile(text, "<detect>", "exec")
            return ".py"
        except Exception:
            return ".txt"
'''

PATCH_DETECT_WRAPPER = r'''
def _detect(self) -> None:
    """
    Delegiert auf robuste V2-Erkennung (snippet_intake_detect_v2).
    """
    try:
        from modules.snippets.snippet_intake_detect_v2 import run_detect as _v2_run_detect
        return _v2_run_detect(self)
    except Exception as e:
        # Fallback: minimal
        txt = self.editor.get("1.0", "end-1c")
        self.var_ext.set(".py")
        self.var_name.set("snippet_" + time.strftime("%Y%m%d_%H%M%S"))
        try:
            compile(txt, "<intake>", "exec")
            ok = True; line=None
        except SyntaxError as se:
            ok = False; line=getattr(se, "lineno", None)
        except Exception:
            ok = False; line=None
        try:
            self._hilite_err(line)
        except Exception:
            pass
        try:
            self.led_syntax.set(ok)
            self.led_all.set(ok and bool(self.var_name.get()))
        except Exception:
            pass
'''

def patch_module():
    if not MOD.exists():
        bail(f"Datei fehlt: {MOD}")

    src = MOD.read_text(encoding="utf-8", errors="ignore")
    bak = ARCH / f"{MOD.name}.{time.strftime('%Y%m%d_%H%M%S')}.bak"
    bak.write_text(src, encoding="utf-8")
    log(f"Backup: {bak}")

    # 1) _detect_ext ersetzen oder hinzufügen
    if re.search(r"^\s*def\s+_detect_ext\s*\(", src, flags=re.MULTILINE):
        src = re.sub(
            r"^\s*def\s+_detect_ext\s*\([^)]*\)\s*:[\s\S]*?(?=^\s*def\s|\Z)",
            PATCH_DETECT_EXT_WRAPPER.strip() + "\n\n",
            src,
            count=1,
            flags=re.MULTILINE
        )
        log("Patched: _detect_ext")
    else:
        src += "\n\n" + PATCH_DETECT_EXT_WRAPPER.strip() + "\n"
        log("Appended: _detect_ext")

    # 2) _detect ersetzen oder hinzufügen
    if re.search(r"^\s*def\s+_detect\s*\(", src, flags=re.MULTILINE):
        src = re.sub(
            r"^\s*def\s+_detect\s*\([^)]*\)\s*:[\s\S]*?(?=^\s*def\s|\Z)",
            PATCH_DETECT_WRAPPER.strip() + "\n\n",
            src,
            count=1,
            flags=re.MULTILINE
        )
        log("Patched: _detect")
    else:
        src += "\n\n" + PATCH_DETECT_WRAPPER.strip() + "\n"
        log("Appended: _detect")

    MOD.write_text(src, encoding="utf-8")
    log("module_code_intake.py geschrieben.")

def main():
    try:
        ensure_dirs()
        SNIP.write_text(SNIP_SRC, encoding="utf-8")
        log(f"Snippet geschrieben: {SNIP}")
        patch_module()
        print("[R1193] Done.")
    except Exception as e:
        bail(str(e), rc=2)

if __name__ == "__main__":
    main()
