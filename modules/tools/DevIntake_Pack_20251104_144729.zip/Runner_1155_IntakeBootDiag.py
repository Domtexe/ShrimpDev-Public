# -*- coding: utf-8 -*-
"""
Runner_1155_IntakeBootDiag.py
Ziel: Sicher (headless) prüfen, warum Intake nicht lädt:
- Import von modules.module_code_intake
- Klasse IntakeFrame auffinden
- Pflicht-Methoden & Toolbar-Hooks vorhanden?
- Headless-Tk anlegen, Frame instanziieren
- build_ui / build_ui_safe / guarded-Build ausführen (falls vorhanden)
- Alle Exceptions mit Traceback in _Reports schreiben
- Zentral-Log debug_output.txt mit Appendix
"""

from __future__ import annotations
import io, os, sys, types, importlib, traceback, datetime, contextlib

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
REPORT_DIR = os.path.join(PROJECT_ROOT, "_Reports")
REPORT = os.path.join(REPORT_DIR, "Runner_1155_IntakeBootDiag_report.txt")
DEBUG_LOG = os.path.join(PROJECT_ROOT, "debug_output.txt")

def _append_debug(msg: str) -> None:
    try:
        with open(DEBUG_LOG, "a", encoding="utf-8", newline="\n") as f:
            ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            f.write(f"[R1155] {ts} {msg}\n")
    except Exception:
        pass

def _writerep(text: str) -> None:
    os.makedirs(REPORT_DIR, exist_ok=True)
    with open(REPORT, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

def _fmt_exc(title: str) -> str:
    return f"\n[EXC] {title}\n" + ("-"*80) + "\n" + traceback.format_exc() + ("-"*80) + "\n"

def main() -> int:
    out = io.StringIO()
    writeln = lambda s="": out.write(s + "\n")
    writeln("="*78)
    writeln("[R1155] IntakeBootDiag – Start")
    writeln("="*78)
    _append_debug("BootDiag start")

    # 1) Import des Intake-Moduls
    try:
        sys.path.insert(0, PROJECT_ROOT)  # robust sicherstellen
        mod = importlib.import_module("modules.module_code_intake")
        importlib.reload(mod)
        writeln("[Import] OK: modules.module_code_intake")
    except Exception:
        msg = _fmt_exc("Beim Import von modules.module_code_intake")
        writeln(msg)
        _append_debug("ImportError module_code_intake")
        _writerep(out.getvalue())
        return 1

    # 2) Klasse IntakeFrame auffinden
    cls = None
    try:
        for name in dir(mod):
            obj = getattr(mod, name)
            if isinstance(obj, type) and ("IntakeFrame" == name or name.endswith("IntakeFrame")):
                cls = obj
                break
        if not cls:
            writeln("[ERR] Keine Klasse 'IntakeFrame' gefunden.")
            _writerep(out.getvalue()); return 1
        writeln(f"[Class] Gefunden: {cls.__module__}.{cls.__name__}")
    except Exception:
        writeln(_fmt_exc("Suche nach IntakeFrame"))
        _writerep(out.getvalue()); return 1

    # 3) Pflicht-Methoden prüfen (sanft)
    REQUIRED = ["build_ui", "on_run", "_detect_guarded"]  # _detect_guarded seit R1153k
    MAYBE = ["build_ui_safe", "_guarded_build", "toolbar_buttons_at_build_ui_end",
             "_on_editor_key", "_on_editor_paste", "_on_editor_modified",
             "_on_clear_editor", "_on_delete_selected_file"]
    try:
        miss = [m for m in REQUIRED if not hasattr(cls, m)]
        writeln(f"[Check] Pflicht-Methoden ok? fehlend={miss}")
        writeln(f"[Check] Optionale Hooks: " +
                ", ".join([m for m in MAYBE if hasattr(cls, m)]) )
        if miss:
            writeln("[WARN] Pflichtmethoden fehlen -> UI wird vermutlich nicht gebaut.")
    except Exception:
        writeln(_fmt_exc("Methoden-Check"))

    # 4) Headless-Tk und Instanziierung
    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        ctx = types.SimpleNamespace()  # leichter Context ersatz
        frame = cls(root, ctx) if "__init__" in cls.__dict__ else cls(root)
        writeln("[Tk] Frame-Instanz erstellt.")
    except Exception:
        writeln(_fmt_exc("Instanziierung von IntakeFrame"))
        _writerep(out.getvalue()); return 1

    # 5) UI-Build ausführen – sicherer Pfad mit Fallbacks
    try:
        built = False
        # Bevorzugt sichere Varianten
        for cand in ("build_ui_safe", "_guarded_build"):
            if hasattr(frame, cand):
                writeln(f"[UI] Versuche {cand}()")
                getattr(frame, cand)()
                built = True
                break
        if not built:
            if hasattr(frame, "build_ui"):
                writeln("[UI] Versuche build_ui()")
                frame.build_ui()
                built = True

        if built:
            writeln("[UI] Aufbau OK.")
        else:
            writeln("[WARN] Keine Build-Methode gefunden/ausgeführt.")

    except Exception:
        writeln(_fmt_exc("UI-Build (build_ui/build_ui_safe/_guarded_build)"))
        _writerep(out.getvalue()); return 1

    # 6) Mini-Smoke: Guard prüfen (kein echter Regex-Lauf)
    try:
        if hasattr(frame, "_detect_guarded"):
            writeln("[Smoke] _detect_guarded() callable – OK (ohne echten Textlauf).")
        else:
            writeln("[Smoke] _detect_guarded fehlt – bitte R1153k prüfen.")
    except Exception:
        writeln(_fmt_exc("Smoke-Test _detect_guarded"))

    # 7) Abschluss
    try:
        root.destroy()
    except Exception:
        pass

    writeln("\n[SUM] Diagnose abgeschlossen – siehe Details oben.")
    txt = out.getvalue()
    _writerep(txt)
    _append_debug("BootDiag done")
    return 0

if __name__ == "__main__":
    sys.exit(main())
