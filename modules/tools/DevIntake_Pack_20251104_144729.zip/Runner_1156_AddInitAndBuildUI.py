# -*- coding: utf-8 -*-
"""
Runner_1156_AddInitAndBuildUI
Ziel (idempotent, minimal-invasiv):
- __init__(self, master, ctx=None) sicherstellen (falls ctx-Arg fehlt)
- build_ui(self) anlegen, wenn nicht vorhanden (kleines Gerüst)
- on_run(self) anlegen, wenn nicht vorhanden (stub)
- Backup, Syntax-Check, Import-Smoke, Rollback
"""
from __future__ import annotations
import io, sys, time, shutil, re, ast, importlib.util, types, py_compile
from pathlib import Path

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1156_AddInitAndBuildUI_report.txt"

def log(s=""):
    print(s)
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(s.rstrip()+"\n")

def backup(p: Path) -> Path:
    dst = ARCH / (p.name + "." + str(int(time.time()*1000)) + ".bak")
    shutil.copy2(p, dst); return dst

def import_smoke()->tuple[bool,str]:
    if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
    # Notfall-Stub für runner_exec
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules"); sys.modules.setdefault("modules", pkg)
        mod = types.ModuleType("modules.module_runner_exec")
        mod.run = lambda *a, **k: 0
        mod._log = lambda *a, **k: None
        sys.modules["modules.module_runner_exec"]=mod
    try:
        spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
        m = importlib.util.module_from_spec(spec); assert spec and spec.loader
        spec.loader.exec_module(m)  # type: ignore[attr-defined]
        # Prüfen, ob IntakeFrame instanziierbar ist
        cls = getattr(m, "IntakeFrame", None)
        if isinstance(cls, type):
            import tkinter as tk
            root = tk.Tk(); root.withdraw()
            try:
                _ = cls(root, None)  # ctx optional
            finally:
                root.destroy()
        return True, "Import & Instanziierung OK"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"

def find_class_span(lines:list[str], class_name:str="IntakeFrame")->tuple[int,int]:
    start=None
    for i,l in enumerate(lines):
        if re.match(rf'^\s*class\s+{class_name}\b', l):
            start=i; break
    if start is None: raise RuntimeError("class IntakeFrame nicht gefunden")
    # Ende: nächste un-eingerückte Top-Level-Zeile oder EOF
    for j in range(start+1,len(lines)):
        if re.match(r'^\S', lines[j]) and not lines[j].lstrip().startswith("#"):
            return start, j
    return start, len(lines)

def patch_init_signature(src:str)->tuple[str,bool]:
    """
    Sucht def __init__ in IntakeFrame und erweitert Signatur auf (self, master, ctx=None),
    falls kein ctx-Argument vorhanden ist.
    """
    tree = ast.parse(src)
    cls = next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name=="IntakeFrame"), None)
    if not cls: raise RuntimeError("IntakeFrame nicht gefunden")
    fn  = next((b for b in cls.body if isinstance(b, ast.FunctionDef) and b.name=="__init__"), None)
    if not fn:
        return src, False
    argnames = [a.arg for a in fn.args.args]  # inkl. self
    if "ctx" in argnames:
        return src, False

    # Header-Zeile im Quelltext ersetzen
    lines = src.splitlines(True)
    s = fn.lineno-1
    header = lines[s]
    # robuste Ersetzung des Kopfes
    new_header = re.sub(
        r'^\s*def\s+__init__\s*\(\s*self\s*,\s*([^)]+)\)\s*:',
        lambda m: f"    def __init__(self, {m.group(1).strip()}, ctx=None):",
        header
    )
    if new_header == header:
        # einfache Fallback-Variante: alle Varianten auf ctx erweitern
        new_header = re.sub(r'\)\s*:\s*$', ', ctx=None):', header)
    lines[s] = new_header
    return "".join(lines), True

def ensure_method(src:str, name:str, body_lines:list[str])->tuple[str,bool]:
    tree = ast.parse(src)
    cls = next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name=="IntakeFrame"), None)
    if not cls: raise RuntimeError("IntakeFrame nicht gefunden")
    if any(isinstance(b, ast.FunctionDef) and b.name==name for b in cls.body):
        return src, False

    # Einfügen am Ende der Klasse (vor nächstem Top-Level)
    lines = src.splitlines(True)
    s,e = find_class_span(lines, "IntakeFrame")
    indent = "    "
    method_src = indent + f"def {name}(self):\n" + "".join(indent*2 + l for l in body_lines)
    if not lines[e-1].endswith("\n"):
        lines[e-1] = lines[e-1] + "\n"
    insertion = method_src
    lines[e-1:e-1] = [insertion]  # direkt vor Klassenende (letzte Zeile der Klasse)
    return "".join(lines), True

def main()->int:
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass
    log("[R1156] Start AddInitAndBuildUI")

    if not MODFILE.exists():
        log("[ERR] modules/module_code_intake.py fehlt."); return 1

    bak = backup(MODFILE); log(f"[Backup] {bak.name}")
    src0 = io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

    # 1) __init__-Signatur erweitern (ctx=None), falls notwendig
    try:
        src1, changed_init = patch_init_signature(src0)
        if changed_init:
            log("[Write] __init__-Signatur auf (self, master, ctx=None) erweitert.")
    except Exception as ex:
        log(f"[ERR] __init__-Analyse/Rewrite: {ex}"); return 1

    # 2) build_ui() sicherstellen (nur wenn fehlt)
    build_ui_body = [
        "# Minimaler UI-Aufbau (nur falls build_ui fehlte) – idempotent.\n",
        "try:\n",
        "    import tkinter.ttk as ttk\n",
        "    if not hasattr(self, 'toolbar'):\n",
        "        self.toolbar = ttk.Frame(self)\n",
        "        self.toolbar.grid(row=0, column=0, sticky='ew')\n",
        "except Exception:\n",
        "    pass\n",
    ]
    try:
        src2, added_build = ensure_method(src1, "build_ui", build_ui_body)
        if added_build:
            log("[Write] build_ui() hinzugefügt (Gerüst).")
    except Exception as ex:
        log(f"[ERR] build_ui()-Insert: {ex}"); return 1

    # 3) on_run() sicherstellen (nur wenn fehlt)
    on_run_body = [
        "try:\n",
        "    self._ping('Run invoked') if hasattr(self, '_ping') else None\n",
        "except Exception:\n",
        "    pass\n",
    ]
    try:
        src3, added_run = ensure_method(src2, "on_run", on_run_body)
        if added_run:
            log("[Write] on_run() hinzugefügt (Stub).")
    except Exception as ex:
        log(f"[ERR] on_run()-Insert: {ex}"); return 1

    # Nichts zu tun?
    if not any([changed_init, added_build, added_run]):
        log("[Info] Keine Änderungen erforderlich.")
        return 0

    # Schreiben
    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(src3)

    # Syntax-Check
    try:
        py_compile.compile(MODFILE, doraise=True)
        log("[Syntax] OK")
    except Exception as e:
        log(f"[Syntax] Fehler: {e} -> Rollback")
        shutil.copy2(bak, MODFILE)
        return 1

    # Import-Smoke
    ok, msg = import_smoke()
    if not ok:
        log(f"[Live] Import-Fehler: {msg} -> Rollback")
        shutil.copy2(bak, MODFILE)
        return 1
    log(f"[Live] {msg}")

    log(f"[SUM] changed_init={changed_init}, added_build_ui={added_build}, added_on_run={added_run}")
    log("[R1156] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
