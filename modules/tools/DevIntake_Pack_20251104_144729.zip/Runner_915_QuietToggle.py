from __future__ import annotations
from pathlib import Path
import re, json, time, shutil

ROOT = Path(r"D:\ShrimpDev")
CFG  = ROOT / "config.json"
UI   = ROOT / "main_gui.py"

def ts(): return time.strftime("%Y%m%d_%H%M%S")
def backup(p: Path) -> Path:
    b = p.with_suffix(p.suffix + f".{ts()}.bak")
    shutil.copy2(p, b); return b

def ensure_config_key():
    cfg = {}
    if CFG.exists():
        try: cfg = json.loads(CFG.read_text(encoding="utf-8") or "{}")
        except Exception: cfg={}
    if "quiet_mode" not in cfg:
        cfg["quiet_mode"] = True
        CFG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        print("[R915] config.json: quiet_mode=True (default)")
    else:
        print(f"[R915] config.json: quiet_mode={cfg['quiet_mode']}")

def patch_menu():
    txt = UI.read_text(encoding="utf-8", errors="ignore")
    if "Quiet Mode" in txt and "toggle_quiet" in txt:
        print("[R915] Quiet-Menu bereits vorhanden.")
        return

    b = backup(UI)

    # 1) import config_mgr falls nicht vorhanden
    if "from modules import module_agent" in txt and "modules.config_mgr" not in txt:
        txt = txt.replace(
            "from modules import module_agent as agent",
            "from modules import module_agent as agent\nfrom modules.config_mgr import load_config, save_config"
        )

    # 2) state var + init laden
    txt = re.sub(
        r"(class\s+ShrimpDevApp\(tk\.Tk\):\s+def\s+__init__\(self\):\s+super\(\)\.__init__\(\)\s+)",
        r"\1self.conf = load_config(); self.quiet = bool(self.conf.get('quiet_mode', True))\n",
        txt, flags=re.S
    )

    # 3) Menüeintrag „View > Quiet Mode“
    pattern = r"(def\s+_mk_menu\(self\):\s+.*?m_view\s*=\s*tk\.Menu\(menubar.*?add_cascade\(label=\"View\".*?\)\s*)"
    m = re.search(pattern, txt, flags=re.S)
    if not m:
        print("[R915] WARN: _mk_menu nicht gefunden – Abbruch.")
        return
    block = m.group(1)
    if "Quiet Mode" not in block:
        block2 = block + (
            "\n        # Quiet Mode Toggle\n"
            "        self.var_quiet = tk.BooleanVar(value=self.quiet)\n"
            "        m_view.add_checkbutton(label=\"Quiet Mode\", onvalue=True, offvalue=False,\n"
            "                               variable=self.var_quiet, command=self.toggle_quiet)\n"
        )
        txt = txt.replace(block, block2)

    # 4) toggle_quiet Methode
    if "def toggle_quiet(" not in txt:
        txt = re.sub(
            r"(class\s+ShrimpDevApp\(tk\.Tk\):.*?def\s+_on_exit\(self\):.*?self\.after\(150, self\.destroy\)\s*)",
            r"\1\n    def toggle_quiet(self):\n"
            r"        try:\n"
            r"            self.quiet = bool(self.var_quiet.get())\n"
            r"            self.conf['quiet_mode'] = self.quiet\n"
            r"            save_config(self.conf)\n"
            r"            self.status.set(f\"Quiet Mode: {'ON' if self.quiet else 'OFF'}\")\n"
            r"            try:\n"
            r"                from modules.snippets.agent_client import send_event\n"
            r"                send_event({'runner':'ShrimpDev','level':'INFO','msg':f'Quiet Mode set to {self.quiet}'})\n"
            r"            except Exception:\n"
            r"                pass\n"
            r"        except Exception:\n"
            r"            pass\n",
            txt, flags=re.S
        )

    UI.write_text(txt, encoding="utf-8")
    print(f"[R915] Quiet-Mode in Menü eingebaut. Backup: {b.name}")

def main():
    if not UI.exists():
        print("[R915] main_gui.py nicht gefunden.")
        return 2
    ensure_config_key()
    patch_menu()
    return 0

if __name__ == "__main__":
    main()
