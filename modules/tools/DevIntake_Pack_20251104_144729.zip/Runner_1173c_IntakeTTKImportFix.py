# -*- coding: utf-8 -*-
"""
Runner_1173c_IntakeTTKImportFix
Behebt 'SyntaxError: name ttk is used prior to global declaration' durch:
 - Entfernen aller 'global ttk' im Funktionskörper
 - Sicherstellen der Modul-Imports: 'import tkinter as tk' und 'from tkinter import ttk'
 - Sanitize alter Artefakte '=\'
Mit Backup, Syntax-Check, Rollback. Idempotent.
"""
from __future__ import annotations
import os, re, time, shutil, traceback, py_compile

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOGF   = os.path.join(ROOT, "debug_output.txt")

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1173c {ts}] {msg}\n"
    print(line, end="")
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, dst)
    return dst

def syntax_ok(path: str) -> bool:
    try:
        py_compile.compile(path, doraise=True)
        return True
    except Exception as e:
        log("Syntax-Fehler:\n" + "".join(traceback.format_exception_only(type(e), e)))
        return False

def ensure_tk_imports(code: str) -> str:
    """Fügt oben im Modul die Imports hinzu, falls fehlend. Idempotent."""
    have_tk   = re.search(r"^\s*import\s+tkinter\s+as\s+tk\b", code, flags=re.M)
    have_ttk1 = re.search(r"^\s*from\s+tkinter\s+import\s+ttk\b", code, flags=re.M)
    have_ttk2 = re.search(r"^\s*import\s+tkinter\.ttk\s+as\s+ttk\b", code, flags=re.M)

    if have_tk and (have_ttk1 or have_ttk2):
        return code

    # nach dem ersten Block von Imports einfügen
    insert_pos = 0
    m = re.search(r"^(?:\s*#.*\n)*((?:\s*from\s+\S+\s+import\s+\S+|\s*import\s+\S+).*\n)+", code, flags=re.M)
    if m:
        insert_pos = m.end()
    imp_lines = []
    if not have_tk:
        imp_lines.append("import tkinter as tk")
    if not (have_ttk1 or have_ttk2):
        imp_lines.append("from tkinter import ttk")
    ins = "\n" + "\n".join(imp_lines) + "\n"
    return code[:insert_pos] + ins + code[insert_pos:]

def strip_global_ttk(code: str) -> str:
    """
    Entfernt 'global ttk' nur innerhalb von Funktionen.
    (global ttk ist hier sinnlos und führt zu 'used prior to global declaration')
    """
    # Grob: in Def-Blöcken 'global ttk' Zeilen killen
    def repl(block: str) -> str:
        return re.sub(r"(?m)^\s*global\s+ttk\s*\n", "", block)

    # Zerlege in Funktionsblöcke
    parts = []
    last = 0
    for m in re.finditer(r"(?m)^\s*def\s+\w+\s*\(.*\)\s*:\s*", code):
        start = m.start()
        if start > last:
            parts.append(code[last:start])  # Vorbereich
        # finde Ende des Blocks heuristisch bis zur nächsten def/EOF
        next_m = re.search(r"(?m)^\s*def\s+\w+\s*\(.*\)\s*:\s*", code[m.end():])
        end = len(code) if not next_m else m.end() + next_m.start()
        block = code[m.start():end]
        parts.append(repl(block))
        last = end
    parts.append(code[last:])
    return "".join(parts)

def sanitize_eq_backslash(code: str) -> str:
    """Fix für frühere Artefakte: '=\ ' -> ' = '"""
    return re.sub(r"=\s*\\\s*", " = ", code)

def main() -> int:
    if not os.path.exists(TARGET):
        log(f"Zieldatei nicht gefunden: {TARGET}")
        return 2

    bak = backup(TARGET)
    log(f"Backup erstellt: {bak}")

    with open(TARGET, "r", encoding="utf-8") as f:
        src = f.read()

    new = src
    new = ensure_tk_imports(new)
    new = strip_global_ttk(new)
    new = sanitize_eq_backslash(new)

    if new == src:
        log("Keine Änderungen erforderlich (idempotent).")
        return 0

    tmp = TARGET + ".1173c.tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(new)

    if not syntax_ok(tmp):
        log("Rollback: Syntax-Check fehlgeschlagen.")
        try: os.remove(tmp)
        except Exception: pass
        shutil.copy2(bak, TARGET)
        return 1

    shutil.move(tmp, TARGET)
    if not syntax_ok(TARGET):
        log("Rollback: End-Syntax-Check fehlgeschlagen.")
        shutil.copy2(bak, TARGET)
        return 1

    log("Patch erfolgreich, Syntax OK.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
