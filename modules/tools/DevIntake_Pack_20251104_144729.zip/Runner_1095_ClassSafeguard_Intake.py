# Runner_1095_ClassSafeguard_Intake.py
# Quick rescue: stellt sicher, dass nach der Klassendefinition von IntakeFrame
# mindestens eine eingerückte Zeile existiert (fügt 'pass' ein, falls nötig).

import os, re, time, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")

def backup(path: str):
    os.makedirs(ARCH, exist_ok=True)
    b = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "rb") as f_in, open(b, "wb") as f_out:
        f_out.write(f_in.read())
    print(f"[R1095] Backup: {path} -> {b}")

def main() -> int:
    if not os.path.exists(MOD):
        print(f"[R1095] Datei nicht gefunden: {MOD}")
        return 1
    src = open(MOD, "r", encoding="utf-8", errors="replace").read()

    # Finde die Zeile mit der Klassendefinition.
    m = re.search(r"^class\s+IntakeFrame\s*\([^)]*\)\s*:\s*(?:#.*)?\r?\n", src, re.M)
    if not m:
        print("[R1095] Keine IntakeFrame-Klasse gefunden – keine Änderungen nötig.")
        return 0

    # Position unmittelbar nach der Klassendefinition
    pos = m.end()

    # Hole die nächste physische Zeile
    rest = src[pos:]
    next_line_match = re.match(r"([ \t]*)(\S.*)?\r?\n?", rest)
    if not next_line_match:
        # Datei endet direkt nach class – sicherheitshalber 'pass' anhängen
        patch = src + "    pass  # R1095: safeguard\n"
        backup(MOD)
        open(MOD, "w", encoding="utf-8").write(patch)
        print("[R1095] 'pass' nach class am Dateiende eingefügt.")
        return 0

    indent, content = next_line_match.group(1), next_line_match.group(2) or ""

    # Prüfen: steht dort eine eingerückte Zeile?
    # gültig: mindestens ein Space/Tab ODER eine leere/Kommentarzeile, die eingerückt ist
    needs_fix = False
    if indent == "":
        # nichts eingerückt → sicherheits-pass einfügen
        needs_fix = True
    elif content.strip() == "" and indent == "":
        needs_fix = True

    if not needs_fix:
        print("[R1095] Nach class ist bereits ein eingerückter Block vorhanden – keine Änderung.")
        return 0

    # 'pass' direkt nach class einfügen
    patched = src[:pos] + "    pass  # R1095: safeguard\n" + src[pos:]
    backup(MOD)
    open(MOD, "w", encoding="utf-8").write(patched)
    print("[R1095] Safeguard-‘pass’ eingefügt – Syntaxfehler behoben.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
