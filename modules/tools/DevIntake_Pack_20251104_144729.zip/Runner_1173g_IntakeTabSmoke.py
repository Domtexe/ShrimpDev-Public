# -*- coding: utf-8 -*-
"""
1173g: Minimaler Smoke-Test ohne echtes GUI-Runloop.
- Import main_gui.py
- Erzeuge Tk + Notebook
- rufe _safe_add_intake_tab(nb)
- erwarte: keine Exception; Intake-Tab existiert
"""
import tkinter as tk
from tkinter import ttk
import importlib.util, os, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
import main_gui as mg  # noqa

root = tk.Tk()
root.withdraw()
nb = ttk.Notebook(root)
nb.pack()
# Muss existieren (Runner 1173f fügt es ein)
if not hasattr(mg, "_safe_add_intake_tab"):
    raise RuntimeError("_safe_add_intake_tab fehlt nach Patch.")

mg._safe_add_intake_tab(nb)

# prüfen, ob ein Tab mit Text 'Code Intake' existiert
found = False
for i, tid in enumerate(nb.tabs()):
    try:
        if nb.tab(i, "text") == "Code Intake":
            found = True
            break
    except Exception:
        pass

if not found:
    raise RuntimeError("Intake-Tab wurde nicht angelegt.")

print("[1173g] Smoke OK.")
