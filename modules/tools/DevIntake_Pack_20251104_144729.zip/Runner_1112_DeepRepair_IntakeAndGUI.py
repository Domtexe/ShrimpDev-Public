# -*- coding: utf-8 -*-
"""
Runner_1112_DeepRepair_IntakeAndGUI.py
- Repariert typische Brüche in modules\module_code_intake.py & main_gui.py
- Normalisiert Zeilenenden/Einrückungen
- Positioniert __future__-Imports an den Dateianfang
- Reindented sicher den class IntakeFrame-Block
- Heilt einsame try:-Blöcke (fügt except Exception: pass hinzu)
- Verhindert 'return outside function' auf Top-Level (vorsichtige Umhüllung)
- Schreibt nur, wenn der reparierte Code wieder kompiliert

Aufruf:
    py -3 tools\Runner_1112_DeepRepair_IntakeAndGUI.py
Optional:
    --dry    : nur prüfen, nichts schreiben
    --file X : nur diese Datei reparieren
"""

from __future__ import annotations
import os, sys, re, io, time, ast, shutil, argparse

ROOT = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
ARCH = os.path.join(ROOT, "_Archiv")
MODS = os.path.join(ROOT, "modules")

TARGETS = [
    os.path.join(MODS, "module_code_intake.py"),
    os.path.join(ROOT, "main_gui.py"),
]

def log(msg: str):
    print(f"[R1112] {msg}")

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    ts = int(time.time())
    bak = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    shutil.copy2(path, bak)
    log(f"Backup: {path} -> {bak}")
    return bak

def read_text(path: str) -> str:
    with open(path, "rb") as f:
        b = f.read()
    # tolerant decodes
    try:
        s = b.decode("utf-8")
    except UnicodeDecodeError:
        s = b.decode("latin-1", errors="replace")
    return s

def write_text(path: str, text: str):
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

def normalize_eol_and_tabs(src: str) -> str:
    s = src.replace("\r\n", "\n").replace("\r", "\n")
    s = s.replace("\t", "    ")
    # trailing spaces
    s = "\n".join(line.rstrip() for line in s.split("\n"))
    return s

def split_header_body_for_future(s: str):
    """Lässt Shebang/Coding/Docstring oben, rest in body."""
    i = 0
    lines = s.split("\n")
    out = []
    # Shebang
    if i < len(lines) and lines[i].startswith("#!"):
        out.append(lines[i]); i += 1
    # Coding
    if i < len(lines) and re.match(r"^#\s*-\*-\s*coding:", lines[i]):
        out.append(lines[i]); i += 1
    # Leerzeilen
    while i < len(lines) and lines[i].strip() == "":
        out.append(lines[i]); i += 1
    # Docstring?
    if i < len(lines) and re.match(r"^\s*[ru]?['\"]{3}", lines[i]):
        qs = lines[i].lstrip()[:3]
        out.append(lines[i]); i += 1
        while i < len(lines) and not lines[i].strip().endswith('"""') and not lines[i].strip().endswith("'''"):
            out.append(lines[i]); i += 1
        if i < len(lines):
            out.append(lines[i]); i += 1
    head = "\n".join(out)
    body = "\n".join(lines[i:])
    return head, body

def hoist_future_imports(s: str) -> str:
    head, body = split_header_body_for_future(s)
    fut = []
    rest = []
    for line in body.split("\n"):
        if re.match(r"^\s*from\s+__future__\s+import\s+", line):
            fut.append(line.strip())
        else:
            rest.append(line)
    if not fut:
        return s
    new = head.rstrip("\n") + "\n" + "\n".join(fut) + "\n" + "\n".join(rest)
    return new

def fix_lonely_try_blocks(s: str) -> str:
    """Fügt 'except Exception: pass' ein, wenn in gleicher Einrückung kein except/finally folgt."""
    lines = s.split("\n")
    i = 0
    out = []
    while i < len(lines):
        line = lines[i]
        out.append(line)
        if re.match(r"^\s*try:\s*$", line):
            indent = len(line) - len(line.lstrip())
            j = i + 1
            saw_except_finally = False
            while j < len(lines):
                l2 = lines[j]
                if l2.strip() == "": 
                    j += 1; continue
                ind2 = len(l2) - len(l2.lstrip())
                if ind2 < indent:  # Block verlassen
                    break
                if ind2 == indent and re.match(r"^\s*(except|finally)\b", l2):
                    saw_except_finally = True
                    break
                j += 1
            if not saw_except_finally:
                out.append(" " * indent + "except Exception:")
                out.append(" " * (indent + 4) + "pass")
        i += 1
    return "\n".join(out)

def fix_top_level_return(s: str) -> str:
    """Sporadische 'return' auf Top-Level in sinnvolle Form bringen (nur triviale Fälle)."""
    lines = s.split("\n")
    out = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if re.match(r"^return\b", line.strip()):
            out.append("def __auto_fix_return__():")
            out.append("    " + line.strip())
        else:
            out.append(line)
        i += 1
    return "\n".join(out)

def reindent_class_block(s: str, class_name="IntakeFrame") -> str:
    """
    Reindented den kompletten Klassenblock: alle Zeilen unmittelbar im Klassenkörper
    müssen mindestens 4 Spaces Einzug besitzen. Innere Strukturen bleiben relativ erhalten.
    """
    lines = s.split("\n")
    out = []
    i = 0
    while i < len(lines):
        line = lines[i]
        m = re.match(rf"^(\s*)class\s+{class_name}\b.*:\s*$", line)
        if not m:
            out.append(line); i += 1; continue
        base_indent = len(m.group(1))
        out.append(line); i += 1
        # reindent bis nächster Top-Level-Knoten (Indent <= base_indent)
        block = []
        while i < len(lines):
            l2 = lines[i]
            ind2 = len(l2) - len(l2.lstrip())
            if l2.strip() == "":
                block.append(l2); i += 1; continue
            if ind2 <= base_indent and not l2.lstrip().startswith("#"):
                break
            # Mindestindent im Klassenkörper = base_indent + 4
            if ind2 <= base_indent and l2.strip():
                # harte Korrektur
                l2 = " " * (base_indent + 4) + l2.lstrip()
            elif ind2 == base_indent + 0:
                l2 = " " * (base_indent + 4) + l2.lstrip()
            block.append(l2); i += 1
        out.extend(block)
    return "\n".join(out)

def safe_compile_py(src: str, path_hint: str) -> tuple[bool,str]:
    try:
        ast.parse(src, filename=path_hint)
        return True, ""
    except SyntaxError as ex:
        # Kontext extrahieren
        msg = f"{ex.__class__.__name__}: {ex} (line {ex.lineno})"
        start = max(1, (ex.lineno or 1)-5)
        lines = src.split("\n")
        ctx = "\n".join(f"{n:04d}: {lines[n-1]}" for n in range(start, min(len(lines), start+10)))
        return False, msg + "\n--- context ---\n" + ctx

def process_file(path: str, dry: bool=False) -> bool:
    if not os.path.exists(path):
        log(f"SKIP: {path} nicht gefunden.")
        return False
    src0 = read_text(path)
    src = normalize_eol_and_tabs(src0)
    src = hoist_future_imports(src)
    # spezifische Fixes
    if os.path.basename(path) == "module_code_intake.py":
        src = reindent_class_block(src, "IntakeFrame")
    src = fix_lonely_try_blocks(src)
    src = fix_top_level_return(src)

    ok, why = safe_compile_py(src, path)
    if not ok:
        log(f"Sanity-Check FEHLGESCHLAGEN – Datei wurde NICHT überschrieben.\n{why}")
        return False

    if src != src0:
        if not dry:
            backup(path)
            write_text(path, src)
            log(f"Repariert & gespeichert: {path}")
        else:
            log(f"[DRY] Änderungen erkannt – würden geschrieben: {path}")
        return True
    else:
        log("Keine Änderungen nötig.")
        return True

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry", action="store_true", help="nur prüfen, nichts schreiben")
    ap.add_argument("--file", default="", help="nur angegebene Datei reparieren")
    args = ap.parse_args()

    ok_all = True
    files = TARGETS if not args.file else [args.file]
    for p in files:
        log(f"== Repariere: {p}")
        ok = process_file(p, dry=args.dry)
        ok_all = ok_all and ok
    sys.exit(0 if ok_all else 1)

if __name__ == "__main__":
    main()
