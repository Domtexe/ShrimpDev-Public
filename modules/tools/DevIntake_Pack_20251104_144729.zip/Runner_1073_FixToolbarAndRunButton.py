# -*- coding: utf-8 -*-
"""
Runner_1073_FixToolbarAndRunButton
- Repariert fehlerhafte Toolbar-Referenz (self.frm_actions -> bar)
- Fügt Button "Ausführen (F5)" RECHTS vom Guard-Button ein
- Bindet F5 auf _on_click_run()
- Ergänzt _on_click_run(), falls noch nicht vorhanden (save -> run via sys.executable)
- Backup + AST-Check
"""

from __future__ import annotations
import os, re, time, shutil, ast

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1073] {ts} {msg}\n")
    except Exception:
        pass

def rd(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f: return f.read()

def wr_with_backup(p: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bak)
    log(f"Backup: {p} -> {bak}")
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

def norm(src: str) -> str:
    src = src.replace("\r\n", "\n").replace("\r", "\n")
    src = "\n".join(ln.rstrip(" \t") for ln in src.split("\n"))
    src = src.replace("\t", "    ")
    if not src.endswith("\n"): src += "\n"
    return src

# -- patches ------------------------------------------------------------------

def patch_toolbar_ref(src: str) -> tuple[str, int]:
    """
    Ersetzt self.frm_actions -> bar im __init__-Toolbarbereich (nicht global),
    damit der Guard-Button wieder gebaut werden kann.
    """
    changed = 0
    m_cls = re.search(r'^\s*class\s+IntakeFrame\s*\(.*?\):', src, re.MULTILINE)
    if not m_cls:
        log("WARN: class IntakeFrame nicht gefunden.")
        return src, 0
    start = m_cls.end()
    m_init = re.search(r'^\s*def\s+__init__\s*\(self.*?\):', src[start:], re.MULTILINE)
    if not m_init:
        log("WARN: __init__ in IntakeFrame nicht gefunden.")
        return src, 0
    i0 = start + m_init.end()
    # bis vor body = ttk.Panedwindow(...), das begrenzt die Toolbar
    m_body = re.search(r'^\s*body\s*=\s*ttk\.Panedwindow\(', src[i0:], re.MULTILINE)
    i1 = i0 + (m_body.start() if m_body else 0)
    seg = src[i0:i1]
    if "self.frm_actions" in seg:
        seg2 = seg.replace("self.frm_actions", "bar")
        if seg2 != seg:
            src = src[:i0] + seg2 + src[i1:]
            changed += 1
            log("frm_actions -> bar im Toolbar-Segment ersetzt.")
    return src, changed

def insert_run_button_right_of_guard(src: str) -> tuple[str, int]:
    """
    Fügt den Run-Button **rechts** vom Guard-Button ein.
    Sucht Guard.grid(...) und injiziert direkt danach self.btn_run + grid().
    """
    if "self.btn_run" in src:
        return src, 0

    # Guard-GRID suchen (bevorzugt), sonst Guard-Definition
    pat_grid = re.compile(r'^([ \t]*)self\.btn_guard\s*\.\s*grid\s*\([^)]*\)\s*$', re.MULTILINE)
    pat_make = re.compile(r'^([ \t]*)self\.btn_guard\s*=\s*ttk\.Button\([^)]*\)\s*$', re.MULTILINE)

    m = pat_grid.search(src)
    insert_pos = None
    indent = ""
    if m:
        indent = m.group(1)
        insert_pos = m.end()
    else:
        m2 = pat_make.search(src)
        if m2:
            indent = m2.group(1)
            insert_pos = m2.end()
    if insert_pos is None:
        log("WARN: Guard-Button nicht gefunden – Run-Button kann nicht platziert werden.")
        return src, 0

    code = (
        "\n"
        f"{indent}self.btn_run = ttk.Button(bar, text=\"Ausführen (F5)\", command=self._on_click_run)\n"
        f"{indent}self.btn_run.grid(row=0, column=100, padx=(4,0))\n"
    )
    src2 = src[:insert_pos] + code + src[insert_pos:]
    log("Run-Button rechts vom Guard eingefügt.")
    return src2, 1

def ensure_f5_binding(src: str) -> tuple[str, int]:
    if re.search(r'self\.txt\.bind\(\s*\"<F5>\"', src):
        return src, 0
    # Einfügepunkt: nach irgendeinem self.txt.bind(...)
    m = re.search(r'^([ \t]*)self\.txt\.bind\([^)]*\)\s*$', src, re.MULTILINE)
    if not m:
        log("WARN: Kein Einfügepunkt für F5-Binding gefunden.")
        return src, 0
    indent = m.group(1)
    inject = f'\n{indent}self.txt.bind("<F5>", lambda _e: self._on_click_run())\n'
    src2 = src[:m.end()] + inject + src[m.end():]
    log("F5-Binding ergänzt.")
    return src2, 1

def ensure_on_click_run(src: str) -> tuple[str, int]:
    if re.search(r'^\s*def\s+_on_click_run\s*\(', src, re.MULTILINE):
        return src, 0
    # in IntakeFrame einfügen – vor nächster Klasse
    m_cls = re.search(r'^\s*class\s+IntakeFrame\s*\(.*?\):', src, re.MULTILINE)
    if not m_cls:
        log("WARN: IntakeFrame nicht gefunden – _on_click_run() kann nicht eingefügt werden.")
        return src, 0
    cls_start = m_cls.end()
    m_next = re.search(r'^\s*class\s+[A-Za-z_]\w*\s*\(', src[cls_start:], re.MULTILINE)
    insert_pos = cls_start + (m_next.start() if m_next else len(src) - cls_start)

    code = (
        "\n"
        "    def _on_click_run(self):\n"
        "        \"\"\"Speichert und führt den aktuellen Runner (.py) aus.\"\"\"\n"
        "        try:\n"
        "            import os, sys, subprocess\n"
        "            try:\n"
        "                self._on_click_save()\n"
        "            except Exception:\n"
        "                pass\n"
        "            name = getattr(self, 'var_name', None)\n"
        "            name = name.get().strip() if name else ''\n"
        "            extv = getattr(self, 'var_ext', None)\n"
        "            ext = extv.get().strip() if extv else '.py'\n"
        "            if not ext.startswith('.'): ext = '.' + ext\n"
        "            tgt = getattr(self, 'var_target', None)\n"
        "            folder = tgt.get().strip() if (tgt and tgt.get().strip()) else os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tools'))\n"
        "            if not name:\n"
        "                self._ping('Kein Dateiname – bitte Name angeben.')\n"
        "                return\n"
        "            path = os.path.join(folder, name + ext)\n"
        "            self._ping('Starte…')\n"
        "            rc = subprocess.call([sys.executable, path], cwd=folder)\n"
        "            self._ping(f'Fertig (RC={rc})')\n"
        "        except Exception as ex:\n"
        "            try:\n"
        "                self._ping(f'Ausführen-Fehler: {ex}')\n"
        "            except Exception:\n"
        "                pass\n"
    )
    src2 = src[:insert_pos] + code + src[insert_pos:]
    log("_on_click_run() ergänzt.")
    return src2, 1

def main() -> int:
    if not os.path.exists(MOD):
        log(f"Datei fehlt: {MOD}")
        return 2

    src0 = rd(MOD)
    s = norm(src0)

    total = 0
    s, n = patch_toolbar_ref(s);                 total += n
    s, n = insert_run_button_right_of_guard(s);  total += n
    s, n = ensure_f5_binding(s);                 total += n
    s, n = ensure_on_click_run(s);               total += n

    # AST-Check
    try:
        ast.parse(s)
    except SyntaxError as e:
        log(f"SyntaxError nach Patch: {e} (line {e.lineno}, col {getattr(e,'offset',0)})")
        lines = s.split("\n")
        a, b = max(1, (e.lineno or 1)-10), min(len(lines), (e.lineno or 1)+10)
        log("--- DUMP ---")
        for i in range(a, b+1):
            vis = lines[i-1].replace("\t", "→").replace(" ", "·")
            log(f"{i:04d}: {vis}")
        log("--- END DUMP ---")
        return 3

    if total == 0 and s == src0:
        log("Keine Änderungen nötig.")
        return 0

    wr_with_backup(MOD, s)
    log(f"Patch gespeichert. Änderungen: {total}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
