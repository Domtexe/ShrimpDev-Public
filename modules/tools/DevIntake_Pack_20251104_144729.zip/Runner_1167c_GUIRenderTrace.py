# -*- coding: utf-8 -*-
"""
Runner_1167c_GUIRenderTrace
- Read-only Diagnose: Instanziiert den echten IntakeFrame headless.
- Fängt alle Exceptions aus __init__ / _build_ui.
- Prüft Kern-Widgets und schreibt Ergebnis in debug_output.txt.
Exitcodes:
 0 = OK (Frame erstellt, Kern-Widgets vorhanden)
 1 = Build/Init-Fehler oder Kern-Widgets fehlen
 2 = Import-Fehler / unerwarteter Fehler
"""
from __future__ import annotations
import os, sys, time, traceback, importlib

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
LOGFILE = os.path.join(ROOT, "debug_output.txt")

def _log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1167c {ts}] {msg}\n"
    try:
        with open(LOGFILE, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def main() -> int:
    os.chdir(ROOT)
    sys.path.insert(0, ROOT)
    os.environ.setdefault("TK_SILENCE_DEPRECATION", "1")

    _log("=== GUI Render Trace START ===")
    _log(f"Root: {ROOT}")

    # 1) Import der echten IntakeFrame-Klasse
    try:
        intake_mod = importlib.import_module("modules.module_code_intake")
        RealIntakeFrame = getattr(intake_mod, "IntakeFrame")
    except Exception as e:
        _log(f"Import-ERR: {e}")
        _log(traceback.format_exc())
        _log("=== GUI Render Trace ENDE (IMPORT ERR) ===")
        return 2

    # 2) Tk headless aufsetzen
    try:
        import tkinter as tk
        from tkinter import ttk  # noqa: F401
        root = tk.Tk()
        root.withdraw()  # kein Fenster zeigen
    except Exception as e:
        _log(f"Tk-Init-ERR: {e}")
        _log(traceback.format_exc())
        _log("=== GUI Render Trace ENDE (TK ERR) ===")
        return 2

    # 3) Frame instanziieren & Build-Trace
    try:
        frame = RealIntakeFrame(root)
        # Idle-Events abarbeiten, um Widget-Erzeugung zu vollenden
        try:
            root.update_idletasks()
        except Exception:
            pass
        _log("IntakeFrame.__init__ ausgeführt.")
    except Exception as e:
        _log(f"Frame-Init-ERR: {e}")
        _log(traceback.format_exc())
        try:
            root.destroy()
        except Exception:
            pass
        _log("=== GUI Render Trace ENDE (FRAME INIT ERR) ===")
        return 1

    # 4) Kern-Widget-Checks (weisen Rendering nach)
    checks = {
        "var_ws": hasattr(frame, "var_ws"),
        "var_name": hasattr(frame, "var_name"),
        "var_ext": hasattr(frame, "var_ext"),
        "frm_actions(Toolbar)": hasattr(frame, "frm_actions"),
        "txt(Editor)": hasattr(frame, "txt"),
        "tbl(Table)": hasattr(frame, "tbl"),
        "btn_detect": hasattr(frame, "btn_detect"),
        "btn_save": hasattr(frame, "btn_save"),
        "lbl_ping": hasattr(frame, "lbl_ping"),
    }
    ok = all(checks.values())
    for k, v in checks.items():
        _log(f"Check {k}: {'OK' if v else 'FEHLT'}")

    if ok:
        _log("RESULT: OK – Intake UI-Elemente verfügbar.")
        rc = 0
    else:
        _log("RESULT: FEHLER – Mindestens ein Kern-Widget fehlt.")
        rc = 1

    # 5) Cleanup
    try:
        frame.destroy()
    except Exception:
        pass
    try:
        root.destroy()
    except Exception:
        pass

    _log("=== GUI Render Trace ENDE ===")
    return rc

if __name__ == "__main__":
    sys.exit(main())
