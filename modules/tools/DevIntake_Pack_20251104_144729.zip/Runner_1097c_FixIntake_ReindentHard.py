# tools/Runner_1097c_FixIntake_ReindentHard.py
from __future__ import annotations
import os, re, time

ROOT = os.path.abspath(os.path.dirname(__file__))
MOD  = os.path.normpath(os.path.join(ROOT, "..", "modules", "module_code_intake.py"))
ARCH = os.path.normpath(os.path.join(ROOT, "..", "_Archiv"))

def backup(path: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "rb") as fsrc, open(bak, "wb") as fdst:
        fdst.write(fsrc.read())
    print(f"[R1097c] Backup: {path} -> {bak}")

def read_norm(path: str) -> list[str]:
    with open(path, "rb") as f:
        s = f.read().decode("utf-8", errors="replace")
    s = s.replace("\r\n", "\n").replace("\r", "\n").replace("\t", "    ")
    return s.split("\n")

def write_back(path: str, lines: list[str]) -> None:
    s = "\n".join(lines).rstrip() + "\n"
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)

def find_block(lines: list[str], start_pat: re.Pattern[str]) -> tuple[int,int] | None:
    try:
        i0 = next(i for i,l in enumerate(lines) if start_pat.match(l))
    except StopIteration:
        return None
    end_pat = re.compile(r"^(class |def |from |import |#\s*-{2,})")
    i1 = len(lines)
    for k in range(i0+1, len(lines)):
        if lines[k] and not lines[k].startswith(" "):
            if end_pat.match(lines[k]):
                i1 = k
                break
    return (i0, i1)

def sanity_compile(lines: list[str]) -> None:
    src = "\n".join(lines).rstrip() + "\n"
    try:
        compile(src, MOD, "exec")
    except SyntaxError as ex:
        print("[R1097c] SyntaxError nach Fix:")
        a = src.splitlines()
        lo = max(0, ex.lineno-6); hi = min(len(a), ex.lineno+6)
        for n in range(lo, hi):
            mark = ">>" if (n+1)==ex.lineno else "  "
            print(f"{mark} {n+1:04d}: {a[n]}")
        raise

def fix_tooltip(lines: list[str]) -> None:
    b = find_block(lines, re.compile(r"^class\s+Tooltip\b"))
    if not b: return
    i0, i1 = b
    # min. 4 Spaces für jede nicht-leere Zeile in der Klasse
    for i in range(i0+1, i1):
        t = lines[i]
        if t.strip()=="" or t.startswith("#!"): continue
        if not t.startswith(" "): lines[i] = "    " + t
    # def-Köpfe exakt 4
    pat_def = re.compile(r"^(\s*)def\s+[A-Za-z_]\w*\s*\(")
    for i in range(i0+1, i1):
        if pat_def.match(lines[i]):
            lines[i] = "    " + lines[i].lstrip()

def fix_intake_frame(lines: list[str]) -> None:
    b = find_block(lines, re.compile(r"^class\s+IntakeFrame\b"))
    if not b: return
    i0, i1 = b

    # (1) Klassen-Zeilen min. 4
    for i in range(i0+1, i1):
        t = lines[i]
        if t.strip()=="" or t.startswith("#!"): continue
        if not t.startswith(" "):
            lines[i] = "    " + t

    # (2) Alle Methoden-Köpfe exakt 4
    pat_def = re.compile(r"^\s*def\s+[A-Za-z_]\w*\s*\(")
    for i in range(i0+1, i1):
        if pat_def.match(lines[i]):
            lines[i] = "    " + lines[i].lstrip()

    # (3) Harte Regel: innerhalb jeder Methode jede nicht-leere Zeile min. 8 Spaces
    in_method = False
    for i in range(i0+1, i1):
        line = lines[i]
        if pat_def.match(line):           # neuer Methoden-Kopf
            in_method = True
            continue
        if line.startswith("    def ") or line.startswith("class "):
            in_method = False             # Sicherheits-Aus
        if in_method:
            if line.strip()=="":
                continue
            if not line.startswith("        "):   # < 8 Spaces → auf 8 heben
                lines[i] = "        " + line.lstrip()

def fix_send_to_recycle_bin(lines: list[str]) -> None:
    pat = re.compile(r"^\s*def\s+_send_to_recycle_bin\s*\(")
    try:
        i = next(i for i,l in enumerate(lines) if pat.match(l))
    except StopIteration:
        return
    # bis zum nächsten Top-Level def/class
    end_pat = re.compile(r"^(class |def )")
    j = len(lines)
    for k in range(i+1, len(lines)):
        if end_pat.match(lines[k]):
            j = k; break
    for t in range(i+1, j):
        if lines[t].strip() and not lines[t].startswith(" "):
            lines[t] = "    " + lines[t]

def main() -> int:
    if not os.path.exists(MOD):
        print(f"[R1097c] Datei nicht gefunden: {MOD}")
        return 1
    backup(MOD)
    lines = read_norm(MOD)

    fix_tooltip(lines)
    fix_intake_frame(lines)
    fix_send_to_recycle_bin(lines)

    sanity_compile(lines)
    write_back(MOD, lines)
    print("[R1097c] Reindent-Hard abgeschlossen, Syntax OK.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
