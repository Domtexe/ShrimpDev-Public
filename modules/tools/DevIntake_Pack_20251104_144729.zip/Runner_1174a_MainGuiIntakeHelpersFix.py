# -*- coding: utf-8 -*-
"""
[1174a] Reparatur: Intake-Tab-Helfer in main_gui.py
- Entfernt evtl. vorhandene, fehlerhafte/doppelte _safe_add_intake_tab/_mount_intake_tab_safe
- Fügt einen sauberen, getesteten Helper-Block VOR dem __main__-Block ein
- Lässt bestehenden _safe_main-Aufruf ( _safe_add_intake_tab(nb) ) unverändert
- Backups + Syntax-Check + Rollback
"""
import io, os, re, time, py_compile, sys, shutil

ROOT = r"D:\ShrimpDev"
TARGET = os.path.join(ROOT, "main_gui.py")
ARCHIV = os.path.join(ROOT, "_Archiv")
os.makedirs(ARCHIV, exist_ok=True)

def _ts():
    return str(int(time.time()))

HELPER_BLOCK = """
# === Intake Tab Safe Helpers (auto, 1174a) ===
def _mount_intake_tab_safe(parent):
    \"\"\"Isoliert den Aufbau des Intake-Tabs.
    Gibt bei Fehlern einen neutralen Frame zurück, damit die GUI weiter startet.
    \"\"\"
    try:
        from tkinter import ttk
        try:
            from modules.module_code_intake import IntakeFrame
            try:
                return IntakeFrame(parent)
            except Exception:
                # Fallback auf leeren Frame, wenn IntakeFrame intern crasht
                return ttk.Frame(parent)
        except Exception:
            # Import scheitert -> neutraler Frame
            return ttk.Frame(parent)
    except Exception:
        # ttk notfalls spät importiert – allerletzte Sicherung
        import tkinter.ttk as ttk
        return ttk.Frame(parent)

def _safe_add_intake_tab(nb):
    \"\"\"Hängt den Intake-Tab sicher an das Notebook an.\"\"\"
    try:
        tab = _mount_intake_tab_safe(nb)
        try:
            nb.add(tab, text="Code Intake")
        except Exception:
            # Notebook.add fehlgeschlagen – nichts hart abbrechen
            pass
    except Exception:
        pass
# === /Intake Tab Safe Helpers (1174a) ===
""".lstrip("\n")

# Muster zum Entfernen alter/defekter Helfer
PAT_SAFE_ADD = re.compile(r"\n\s*def\s+_safe_add_intake_tab\s*\([^)]*\)\s*:[\s\S]*?(?=\n\s*def\s+|\nif\s+__name__|$)", re.M)
PAT_MOUNT    = re.compile(r"\n\s*def\s+_mount_intake_tab_safe\s*\([^)]*\)\s*:[\s\S]*?(?=\n\s*def\s+|\nif\s+__name__|$)", re.M)

def main():
    with io.open(TARGET, "r", encoding="utf-8") as f:
        src = f.read()

    bak = os.path.join(ARCHIV, f"main_gui.py.{_ts()}.bak")
    with io.open(bak, "w", encoding="utf-8") as f:
        f.write(src)
    print(f"[1174a] Backup erstellt: {bak}")

    # 1) Alle alten Helferblöcke rausschneiden (sauberer Neuaufbau)
    new_src = PAT_SAFE_ADD.sub("\n", src)
    new_src = PAT_MOUNT.sub("\n", new_src)

    # 2) Helper VOR __main__-Block einsetzen; falls keiner existiert, ans Ende
    m = re.search(r"\nif\s+__name__\s*==\s*['\"]__main__['\"]\s*:", new_src)
    if m:
        insert_at = m.start()
        new_src = new_src[:insert_at] + "\n" + HELPER_BLOCK + new_src[insert_at:]
        print("[1174a] Helper-Block vor __main__ eingefügt.")
    else:
        new_src = new_src.rstrip() + "\n\n" + HELPER_BLOCK
        print("[1174a] __main__-Block nicht gefunden – Helper-Block ans Ende angehängt.")

    # 3) Schreiben + Syntax-Check (Rollback falls Fehler)
    tmp = TARGET + ".1174a.tmp"
    with io.open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(new_src)

    try:
        py_compile.compile(tmp, doraise=True)
        # ok -> übernehmen
        shutil.copyfile(tmp, TARGET)
        print("[1174a] Patch übernommen, Syntax OK.")
    except Exception as e:
        print("[1174a] Syntax-Check FEHLER -> Rollback.", e)
        shutil.copyfile(bak, TARGET)
        sys.exit(1)
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass

    # 4) Sanity: Existiert der Aufruf in _safe_main?
    if "_safe_add_intake_tab(nb)" in new_src:
        print("[1174a] Aufruf in _safe_main vorhanden.")
    else:
        print("[1174a] Hinweis: _safe_add_intake_tab(nb) nicht gefunden – _safe_main ruft evtl. etwas anderes auf.")

if __name__ == "__main__":
    main()
