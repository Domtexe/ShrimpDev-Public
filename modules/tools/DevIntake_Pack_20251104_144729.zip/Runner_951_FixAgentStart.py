from __future__ import annotations
from pathlib import Path
import re, time, shutil, py_compile, sys

ROOT = Path(r"D:\ShrimpDev")
MAIN = ROOT / "main_gui.py"

GOOD_BLOCK = (
    "        # Agent starten\n"
    "        try:\n"
    "            if not getattr(agent.AGENT, '_started', False):\n"
    "                agent.AGENT.start(); setattr(agent.AGENT, '_started', True)\n"
    "        except Exception:\n"
    "            pass\n"
)

def ts(): return time.strftime("%Y%m%d_%H%M%S")

def backup(p: Path):
    if p.exists():
        b = p.with_suffix(p.suffix + f".{ts()}.bak")
        shutil.copy2(p, b)
        print(f"[R951] Backup: {b.name}")

def compile_check(p: Path) -> tuple[bool,str]:
    try:
        py_compile.compile(str(p), doraise=True)
        return True, ""
    except Exception as ex:
        return False, str(ex)

def patch_agent_block(txt: str) -> tuple[str,bool]:
    # 1) Wenn bereits ein sauberer Block vorhanden ist → nichts tun
    if GOOD_BLOCK in txt:
        return txt, False

    # 2) Versuche den fehlerhaften R944-Guard zu finden und ersetzen
    # Muster: "# Agent starten" ... dann mehrfach try/except oder "R944 guard" Kommentar
    pat = re.compile(
        r"(^\s*#\s*Agent starten\s*\n)"          # Start-Kommentar
        r"(?:(?:.|\n){0,200})?"                  # kleiner Bereich
        r"^\s*try:\s*\n"                         # erstes try:
        r"(?:(?:.|\n){0,200})?",                 # evtl. Kommentar/Fehlversuch
        re.M
    )

    m = pat.search(txt)
    if not m:
        # Fallback: Wir suchen die Stelle, an der agent.AGENT.start() aufgerufen wird
        call_pat = re.compile(r"^\s*#\s*Agent starten\s*\n(?:(?:.|\n){0,200}?)(agent\.AGENT\.start\(\))", re.M)
        if call_pat.search(txt):
            # Ersetze großzügig den Abschnitt zwischen "# Agent starten" und der nächsten Leerzeile/Nachbarblock
            slab_pat = re.compile(r"(^\s*#\s*Agent starten\s*\n)(?:(?:.|\n){0,300}?)(?=^\s*\S|\Z)", re.M)
            txt = slab_pat.sub(GOOD_BLOCK, txt, count=1)
            return txt, True
        else:
            # Letzte Option: Wir fügen nach "# Agent starten" unseren Block ein und entfernen ein direkt folgendes try: ohne Suite
            ins_pat = re.compile(r"(^\s*#\s*Agent starten\s*\n)", re.M)
            if ins_pat.search(txt):
                txt = ins_pat.sub(GOOD_BLOCK, txt, count=1)
                return txt, True
            else:
                return txt, False

    start = m.start(1)
    # Ersetze von "# Agent starten" bis zum nächsten dedent oder Ende
    slab_pat = re.compile(r"(^\s*#\s*Agent starten\s*\n)(?:(?:.|\n){0,300}?)(?=^\s*\S|\Z)", re.M)
    txt2, n = slab_pat.subn(GOOD_BLOCK, txt, count=1)
    return (txt2, n > 0)

def main() -> int:
    if not MAIN.exists():
        print("[R951] FEHLT: main_gui.py"); return 2
    backup(MAIN)
    txt = MAIN.read_text(encoding="utf-8", errors="ignore")
    new_txt, changed = patch_agent_block(txt)
    if not changed:
        print("[R951] Kein ersetzbarer Agent-Block gefunden – keine Änderung.")
    else:
        MAIN.write_text(new_txt, encoding="utf-8")
        print("[R951] Agent-Startblock ersetzt.")

    ok, err = compile_check(MAIN)
    if ok:
        print("[R951] Syntax OK – main_gui.py kompiliert.")
        return 0
    else:
        print(f"[R951] FEHLER bleibt: {err}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
