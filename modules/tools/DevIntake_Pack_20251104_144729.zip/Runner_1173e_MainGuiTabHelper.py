# -*- coding: utf-8 -*-
"""
Runner_1173e: Sicherer Helper _safe_add_intake_tab(nb) fuer main_gui.py
- Fuegt Import 'import tkinter as tk' + 'from tkinter import ttk' ein (falls nicht vorhanden).
- Definiert _safe_add_intake_tab(nb) nur, wenn noch nicht vorhanden.
- Ersetzt problematische direkte Aufrufe optional NICHT; der bestehende Call
  _safe_add_intake_tab(nb) bleibt bestehen bzw. kann danach genutzt werden.
"""
import io, os, re, shutil, time, py_compile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "main_gui.py")
ARCH  = os.path.join(ROOT, "_Archiv")
os.makedirs(ARCH, exist_ok=True)

def read(p):  return io.open(p, "r", encoding="utf-8", errors="replace").read()
def write(p,s): io.open(p, "w", encoding="utf-8").write(s)

src0 = read(TARGET)
src = src0

# 1) sicherstellen: tkinter-Imports vorhanden
if not re.search(r"(?m)^\s*import\s+tkinter\s+as\s+tk\s*$", src):
    src = re.sub(r"(?m)^(\s*from\s+tkinter\s+import\s+ttk\s*$)",
                 r"import tkinter as tk\n\1", src, count=1) \
          if re.search(r"(?m)^from\s+tkinter\s+import\s+ttk\s*$", src) \
          else "import tkinter as tk\nfrom tkinter import ttk\n" + src

if not re.search(r"(?m)^from\s+tkinter\s+import\s+ttk\s*$", src):
    # fuege ttk-Import nach tk-Import ein
    src = re.sub(r"(?m)^\s*import\s+tkinter\s+as\s+tk\s*$",
                 "import tkinter as tk\nfrom tkinter import ttk", src, count=1)

# 2) Helper nur einfuegen, wenn er fehlt
if "_safe_add_intake_tab" not in src:
    helper = r'''
def _safe_add_intake_tab(nb):
    """
    Fuegt den Intake-Tab sicher in ein ttk.Notebook ein.
    Gibt das angelegte Tab-Widget zurueck.
    """
    try:
        tab = None
        try:
            tab = IntakeFrame(nb)
        except Exception:
            # Fallback-Frame anzeigen, damit das UI nicht bricht
            tab = ttk.Frame(nb)
            try:
                import traceback, io
                with io.open("debug_output.txt","a",encoding="utf-8") as _f:
                    _f.write("\n[IntakeTab] Fehler beim Erzeugen von IntakeFrame:\n")
                    _f.write(traceback.format_exc())
            except Exception:
                pass
            ttk.Label(tab, text="Fehler beim Laden des Intake-Tabs. Details siehe debug_output.txt").pack(padx=12, pady=8)

        if tab is None or not isinstance(tab, (tk.Frame, ttk.Frame)):
            # harte Sicherung, falls der Fallback in der Vergangenheit 'None' geliefert hat
            tab = ttk.Frame(nb)
            ttk.Label(tab, text="Intake-Tab (Fallback)").pack(padx=12, pady=8)

        nb.add(tab, text="Code Intake")
        return tab
    except Exception:
        # absoluter Fallback: leerer Tab, aber kein Crash
        tab = ttk.Frame(nb)
        ttk.Label(tab, text="Intake-Tab konnte nicht eingehängt werden.").pack(padx=12, pady=8)
        try:
            nb.add(tab, text="Code Intake")
        finally:
            import traceback, io
            try:
                with io.open("debug_output.txt","a",encoding="utf-8") as _f:
                    _f.write("\n[IntakeTab] Unbekannter Fehler beim Einhaengen des Tabs:\n")
                    _f.write(traceback.format_exc())
            except Exception:
                pass
        return tab
'''
    # Einfuegen vor _safe_main oder am Dateiende
    if re.search(r"(?m)^def\s+_safe_main\s*\(", src):
        src = re.sub(r"(?m)^def\s+_safe_main\s*\(",
                     helper + "\n\ndef _safe_main(", src, count=1)
    else:
        src = src.rstrip() + "\n\n" + helper

# 3) Backup + Syntaxcheck
ts = str(int(time.time()))
bak = os.path.join(ARCH, f"main_gui.py.{ts}.bak")
shutil.copy2(TARGET, bak)
tmp = TARGET + ".1173e.tmp"
write(tmp, src)
py_compile.compile(tmp, doraise=True)
os.replace(tmp, TARGET)
print(f"[1173e] Backup erstellt: {bak}")
print("[1173e] Patch erfolgreich eingefuegt und Syntax-Check OK.")
