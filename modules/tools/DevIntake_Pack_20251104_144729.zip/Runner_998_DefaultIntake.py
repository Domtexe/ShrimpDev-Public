# file: tools/Runner_998_DefaultIntake.py
from __future__ import annotations
from pathlib import Path
import re, sys

ROOT = Path(r"D:\ShrimpDev")
MAIN = ROOT / "main_gui.py"

INJECT = (
    "\n        # [R998] Default-Tab 'Code Intake' auswählen\n"
    "        try:\n"
    "            def _r998_pick():\n"
    "                try:\n"
    "                    # 1. Versuch: sofort nach idle\n"
    "                    for t in self.nb.tabs():\n"
    "                        if self.nb.tab(t, 'text') == 'Code Intake':\n"
    "                            self.nb.select(t)\n"
    "                            return\n"
    "                    # 2. Versuch: nach 200ms (falls Tabs später hinzugefügt wurden)\n"
    "                    def _retry():\n"
    "                        try:\n"
    "                            for t in self.nb.tabs():\n"
    "                                if self.nb.tab(t, 'text') == 'Code Intake':\n"
    "                                    self.nb.select(t)\n"
    "                                    return\n"
    "                        except Exception:\n"
    "                            pass\n"
    "                    self.after(200, _retry)\n"
    "                except Exception:\n"
    "                    pass\n"
    "            self.after_idle(_r998_pick)\n"
    "        except Exception:\n"
    "            pass\n"
)

def main() -> int:
    if not MAIN.exists():
        print("[R998] main_gui.py nicht gefunden"); return 1
    src = MAIN.read_text(encoding="utf-8", errors="ignore")
    MAIN.with_suffix(".py.r998_default.bak").write_text(src, encoding="utf-8")

    # In __init__-Methode der App einfügen (vor Ende des Blocks)
    m = re.search(r"class\s+\w+\(tk\.Tk\)\s*:\s*[\s\S]*?def\s+__init__\s*\([\s\S]*?\):", src)
    if not m:
        print("[R998] __init__ nicht gefunden"); return 1

    if "[R998] Default-Tab" in src or "[R998] Default-Tab 'Code Intake'" in src:
        print("[R998] Bereits gepatcht."); return 0

    insert_pos = src.find("self.status", m.end())
    if insert_pos == -1:
        insert_pos = m.end()
    src = src[:insert_pos] + INJECT + src[insert_pos:]
    MAIN.write_text(src, encoding="utf-8")

    # Schnell-Compilecheck
    compile(src, str(MAIN), "exec")
    print("[R998] Default-Intake-Patch installiert.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
