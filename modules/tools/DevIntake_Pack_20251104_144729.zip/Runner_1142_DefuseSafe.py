# -*- coding: utf-8 -*-
"""
Runner_1142_DefuseSafe
Ziel: Intake syntaktisch stabilisieren, ohne riskante Muster.
- __future__-Imports an den Anfang
- tkinter/ttk-Imports sicherstellen (nach __future__)
- Fehlplatzierte Editor-Handler ausserhalb der Klasse entfernen
- Minimalen, sauberen Handler-Block am Klassenende injizieren
- AST-Compile-Syntaxcheck; bei Fehler: Rollback + Report mit Kontext
"""
from __future__ import annotations

import ast
import io
import os
import re
import sys
import time
import shutil
from pathlib import Path
from textwrap import indent

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"; ARCH.mkdir(exist_ok=True)
REPO = ROOT / "_Reports"; REPO.mkdir(exist_ok=True)
REPORT = REPO / "Runner_1142_DefuseSafe_report.txt"

def w(s: str):
    with open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(s.rstrip()+"\n")
    print(s, flush=True)

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time()*1000)}.bak"
    shutil.copy2(p, dst)
    w(f"[Backup] {p} -> {dst}")
    return dst

def read(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="ignore")

def write(p: Path, s: str):
    p.write_text(s, encoding="utf-8", newline="\n")

# ---------- Helpers ----------
def normalize_newlines(s: str) -> str:
    return s.replace("\r\n", "\n").replace("\r", "\n")

def move_future_to_top(src: str) -> str:
    src = normalize_newlines(src)
    lines = src.split("\n")
    shebang = []
    i = 0
    while i < len(lines) and (lines[i].startswith("#!") or lines[i].startswith("# -*-") or not lines[i].strip()):
        shebang.append(lines[i]); i += 1

    future_lines = [ln for ln in lines if ln.strip().startswith("from __future__ import ")]
    body_lines   = [ln for ln in lines if ln not in future_lines]

    # Deduplizieren in Originalreihenfolge
    seen=set(); fut=[]
    for ln in future_lines:
        if ln not in seen:
            seen.add(ln); fut.append(ln)

    head = shebang
    rest = body_lines[i:]
    new = head + fut + ([""] if fut and (not head or head[-1]!="") else []) + body_lines[i:]
    return "\n".join(new)

def ensure_imports(src: str) -> str:
    src = normalize_newlines(src)
    lines = src.split("\n")
    # Position: nach letztem __future__ bzw. nach Header
    insert_pos = 0
    for idx, ln in enumerate(lines):
        if ln.strip().startswith("from __future__ import"):
            insert_pos = idx+1
    need_tk  = all("import tkinter as tk"     not in ln for ln in lines)
    need_ttk = all("from tkinter import ttk"  not in ln for ln in lines)
    to_insert = []
    if need_tk:  to_insert.append("import tkinter as tk")
    if need_ttk: to_insert.append("from tkinter import ttk")
    if to_insert:
        # eine Leerzeile nach den Inserts
        lines = lines[:insert_pos] + to_insert + [""] + lines[insert_pos:]
    return "\n".join(lines)

def strip_bad_free_functions(src: str) -> str:
    """Entfernt offensichtliche, frei schwebende Handler-Defs ausserhalb von Klassen."""
    src = normalize_newlines(src)
    # Entferne bekannte Kandidaten: _on_editor_*, _ensure_editor_bindings, _schedule_detect, _auto_detect_if_needed, _safe_detect
    patterns = [
        r"\n[ \t]*def\s+_on_editor_paste\s*\([^)]*\)\s*:\s*[\s\S]*?(?=\n[ \t]*def\s|\n[ \t]*class\s|\Z)",
        r"\n[ \t]*def\s+_on_editor_key\s*\([^)]*\)\s*:\s*[\s\S]*?(?=\n[ \t]*def\s|\n[ \t]*class\s|\Z)",
        r"\n[ \t]*def\s+_on_editor_modified\s*\([^)]*\)\s*:\s*[\s\S]*?(?=\n[ \t]*def\s|\n[ \t]*class\s|\Z)",
        r"\n[ \t]*def\s+_ensure_editor_bindings\s*\([^)]*\)\s*:\s*[\s\S]*?(?=\n[ \t]*def\s|\n[ \t]*class\s|\Z)",
        r"\n[ \t]*def\s+_schedule_detect\s*\([^)]*\)\s*:\s*[\s\S]*?(?=\n[ \t]*def\s|\n[ \t]*class\s|\Z)",
        r"\n[ \t]*def\s+_auto_detect_if_needed\s*\([^)]*\)\s*:\s*[\s\S]*?(?=\n[ \t]*def\s|\n[ \t]*class\s|\Z)",
        r"\n[ \t]*def\s+_safe_detect\s*\([^)]*\)\s*:\s*[\s\S]*?(?=\n[ \t]*def\s|\n[ \t]*class\s|\Z)",
    ]
    out = src
    for pat in patterns:
        out = re.sub(pat, "\n", out, flags=re.MULTILINE)
    return out

def find_class_block(src: str, class_name="IntakeFrame") -> tuple[int,int]:
    """
    Liefert (start_index, end_index) des Textbereichs der Klasse anhand von Einrückungen.
    Robust gegen andere Klassen.
    """
    src = normalize_newlines(src)
    lines = src.split("\n")
    class_pat = re.compile(rf"^\s*class\s+{class_name}\s*\(.*\)\s*:\s*$")
    start = None
    for i, ln in enumerate(lines):
        if class_pat.match(ln):
            start = i
            break
    if start is None:
        raise RuntimeError("class IntakeFrame nicht gefunden.")

    # Klassen-Indentation (Anzahl führender Spaces der nächsten Zeile mit Code)
    indent_base = None
    for j in range(start+1, len(lines)):
        if lines[j].strip()=="":
            continue
        indent_base = len(lines[j]) - len(lines[j].lstrip(" "))
        break
    if indent_base is None:
        # leere Klasse
        return (start, len(lines))

    # Ende der Klasse: nächste Top-Level-Zeile mit Indent < indent_base
    end = len(lines)
    for k in range(start+1, len(lines)):
        ln = lines[k]
        if ln.strip()=="":
            continue
        ind = len(ln) - len(ln.lstrip(" "))
        if ind < indent_base:
            end = k
            break
    return (start, end)

INJECT_BLOCK = """
# --- R1142: Canonical editor handlers (minimal) -----------------
def _ensure_editor_bindings(self):
    try:
        self.txt.unbind('<<Paste>>')
        self.txt.unbind('<Control-v>')
        self.txt.unbind('<<Modified>>')
        self.txt.unbind('<KeyRelease>')
    except Exception:
        pass
    self.txt.bind('<<Paste>>', self._on_editor_paste)
    self.txt.bind('<Control-v>', self._on_editor_paste)
    self.txt.bind('<<Modified>>', self._on_editor_modified)
    self.txt.bind('<KeyRelease>', self._on_editor_key)

def _on_editor_paste(self, _evt=None):
    try:
        self._schedule_detect(220)
    except Exception:
        pass

def _on_editor_key(self, _evt=None):
    try:
        self._schedule_detect(250)
    except Exception:
        pass

def _on_editor_modified(self, _evt=None):
    try:
        try:
            self.txt.edit_modified(False)
        except Exception:
            pass
        self._schedule_detect(300)
    except Exception:
        pass

def _schedule_detect(self, delay_ms=250):
    try:
        if getattr(self, '_detect_job', None):
            try:
                self.after_cancel(self._detect_job)
            except Exception:
                pass
        self._detect_job = self.after(int(delay_ms), self._auto_detect_if_needed)
    except Exception:
        pass

def _auto_detect_if_needed(self):
    try:
        if hasattr(self, '_detect'):
            self._detect()
    except Exception:
        pass
# --- /R1142 ------------------------------------------------------
""".strip("\n")

def inject_into_class_end(src: str) -> str:
    """Fügt INJECT_BLOCK sauber (4-Spaces) am Klassenende ein, wenn noch nicht vorhanden."""
    if "_ensure_editor_bindings(self)" in src and "_on_editor_paste(self" in src:
        return src  # schon vorhanden (irgendeine Variante)
    start, end = find_class_block(src)
    lines = normalize_newlines(src).split("\n")
    # Klassen-Indent bestimmen
    indent_base = None
    for j in range(start+1, len(lines)):
        if lines[j].strip()=="":
            continue
        indent_base = len(lines[j]) - len(lines[j].lstrip(" "))
        break
    if indent_base is None:
        indent_base = 4
    block = indent(INJECT_BLOCK+"\n", " "*indent_base)
    new_lines = lines[:end] + [""] + block.split("\n") + [""] + lines[end:]
    return "\n".join(new_lines)

def compile_ok(code: str) -> tuple[bool, str, int]:
    try:
        ast.parse(code)
        return True, "", -1
    except SyntaxError as e:
        return False, f"{e.msg}", e.lineno or -1

def context(code: str, lineno: int, radius: int = 8) -> str:
    lines = normalize_newlines(code).split("\n")
    start = max(1, lineno - radius)
    end   = min(len(lines), lineno + radius)
    fr = []
    for i in range(start, end+1):
        mark = ">>" if i == lineno else "  "
        fr.append(f"{mark} {i:04d}: {lines[i-1]}")
    return "\n".join(fr)

def main() -> int:
    print("[R1142] DefuseSafe – Start")
    if not MOD.exists():
        w(f"[FEHLER] Datei fehlt: {MOD}")
        return 2

    backup(MOD)
    src0 = read(MOD)

    # 1) Normalize + Future + Imports
    s = normalize_newlines(src0)
    s = move_future_to_top(s)
    s = ensure_imports(s)

    # 2) Bad free functions raus
    s = strip_bad_free_functions(s)

    # 3) In Class-Ende injizieren
    try:
        s = inject_into_class_end(s)
    except RuntimeError as ex:
        w(f"[FEHLER] {ex}")
        return 1

    # 4) Syntaxcheck
    ok, err, line = compile_ok(s)
    if not ok:
        w(f"[SYNTAX] {err} (line {line})")
        w("----- Kontext -----")
        w(context(s, line))
        w("--------------------")
        w("[Rollback] Wiederherstellung der Originaldatei.")
        write(MOD, src0)
        return 1

    # 5) Schreiben
    write(MOD, s)
    w("[OK] Patch geschrieben und Syntax geprüft.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
