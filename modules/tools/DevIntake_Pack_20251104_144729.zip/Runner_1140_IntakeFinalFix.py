# -*- coding: utf-8 -*-
"""
Runner_1140_IntakeFinalFix.py
Repariert Intake-Startprobleme:
 - Future-Import an den Dateianfang
 - Toolbar: btn_guard sicher auf 'bar' verankern, frm_actions-Verweise entschärfen
 - Zentrales Logging (robust) & Sanity-Guards
 - Syntax-Check & Rollback bei Fehler
"""
from __future__ import annotations

import io
import os
import re
import sys
import time
import shutil
import traceback
from datetime import datetime
from pathlib import Path
import tokenize

ROOT = Path(__file__).resolve().parent.parent
MODULE = ROOT / "modules" / "module_code_intake.py"
ARCHIV = ROOT / "_Archiv"
ARCHIV.mkdir(exist_ok=True)

REPORT = ROOT / f"Runner_1140_IntakeFinalFix_report.txt"
DEBUG  = ROOT / "debug_output.txt"

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1140] {ts} {msg}\n"
    sys.stdout.write(line)
    # robuster Zentral-Logger (kleines Retry gegen Datei-Locks)
    for _ in range(3):
        try:
            with open(DEBUG, "a", encoding="utf-8", newline="\n") as f:
                f.write(line)
            break
        except Exception:
            time.sleep(0.05)

def write_report(text: str) -> None:
    with open(REPORT, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

def backup_file(src: Path) -> Path:
    ts = int(time.time() * 1000)
    dst = ARCHIV / f"{src.name}.{ts}.bak"
    shutil.copy2(src, dst)
    log(f"Backup -> {dst}")
    return dst

def normalize_newlines(s: str) -> str:
    return s.replace("\r\n", "\n").replace("\r", "\n")

def move_future_imports_to_top(code: str) -> str:
    """
    Sammelt alle from __future__ ... Imports und platziert sie als ersten Block.
    Entfernt Duplikate.
    """
    code = normalize_newlines(code)
    lines = code.split("\n")

    future_lines = []
    keep_lines   = []

    for ln in lines:
        if re.match(r"^\s*from\s+__future__\s+import\s+", ln):
            future_lines.append(ln.strip())
        else:
            keep_lines.append(ln)

    # eindeutige Reihenfolge beibehalten
    seen = set()
    ordered = []
    for fl in future_lines:
        if fl not in seen:
            seen.add(fl)
            ordered.append(fl)

    if ordered:
        # ggf. Shebang / coding Header ganz oben respektieren
        head = []
        body = []
        for i, ln in enumerate(keep_lines):
            if i <= 2 and re.match(r"^\s*#\!|^\s*#\s*-\*-\s*coding", ln):
                head.append(ln)
            else:
                body = keep_lines[i:]
                break
        else:
            body = []

        new_code = "\n".join(
            head
            + ordered
            + [""]
            + body
        )
        return new_code
    return code

def fix_toolbar(code: str) -> str:
    """
    Stellt sicher, dass btn_guard auf 'bar' erzeugt wird und keine harten Abhängigkeiten
    zu 'self.frm_actions' existieren.
    """
    code = normalize_newlines(code)

    # 1) Alle Vorkommen von self.frm_actions im Button-Constructor -> bar
    code = re.sub(
        r"(ttk\.Button\()\s*self\.frm_actions\b",
        r"\1 bar",
        code
    )

    # 2) Falls irgendwo grid/place/pack für btn_guard auf einem falschen Container steht, normalisieren
    # (hier genügt der Constructor-Fix, zusätzliche grid()-Aufrufe bleiben unverändert)

    # 3) Sanity-Guard: Wenn es eine Hilfs-Funktion gibt, die 'frm_actions' erwartet, entkoppeln
    code = code.replace("self.frm_actions", "bar")

    return code

def inject_sanity_guards(code: str) -> str:
    """
    Ergänzt eine schlanke Guard-Funktion in IntakeFrame._build_ui, die
    dafür sorgt, dass 'bar' existiert und btn_guard notfalls ersetzt wird.
    """
    code = normalize_newlines(code)

    pattern = r"(def\s+_build_ui\s*\(\s*self\s*,.*?\):)"
    if not re.search(pattern, code, flags=re.S):
        return code  # nichts zu tun

    guard_snippet = r"""
        # --- Sanity Guard (R1140): Toolbar/Buttons sicherstellen ---
        try:
            # 'bar' sollte die Toolbar-Frame-Variable sein; andernfalls fallback suchen/erzeugen
            if 'bar' not in locals():
                # heuristische Suche nach einer Frame-Variable in der Methode
                bar = None
                for _name, _val in list(locals().items()):
                    if hasattr(_val, 'winfo_class') and callable(getattr(_val, 'winfo_class', None)):
                        try:
                            if _val.winfo_class() in ('Frame','TFrame','Labelframe','TLabelframe'):
                                bar = _val
                                break
                        except Exception:
                            pass
                if bar is None:
                    import tkinter as tk
                    from tkinter import ttk
                    bar = ttk.Frame(self)
                    bar.grid(row=0, column=0, sticky="ew")

            # btn_guard vorhanden? – andernfalls neutralen Button anlegen
            if not hasattr(self, 'btn_guard') or self.btn_guard is None:
                from tkinter import ttk
                self.btn_guard = ttk.Button(bar, text="Repair", command=lambda: None)
                try:
                    self.btn_guard.grid(row=0, column=99, padx=2, pady=2, sticky="w")
                except Exception:
                    pass
        except Exception:
            # Guard schluckt Fehler, damit die GUI nicht hart stirbt
            pass
    """

    def inject_after_signature(match: re.Match) -> str:
        head = match.group(1)
        return head + guard_snippet

    code = re.sub(pattern, inject_after_signature, code, count=1, flags=re.S)
    return code

def ast_syntax_ok(code: str, filename: str) -> tuple[bool, str]:
    try:
        compile(code, filename, "exec")
        return True, ""
    except SyntaxError as e:
        return False, f"{e.__class__.__name__}: {e}"

def main() -> int:
    lines = []
    rep = io.StringIO()
    try:
        if not MODULE.exists():
            print(f"[R1140] Datei fehlt: {MODULE}")
            return 2

        orig = MODULE.read_text(encoding="utf-8")
        backup = backup_file(MODULE)

        s = orig

        # 1) Future-Imports nach oben ziehen
        s = move_future_imports_to_top(s)

        # 2) Toolbar fixen (btn_guard -> bar; frm_actions loswerden)
        s = fix_toolbar(s)

        # 3) Sanity-Guards injizieren
        s = inject_sanity_guards(s)

        ok, err = ast_syntax_ok(s, str(MODULE))
        if not ok:
            log(f"SyntaxError nach Patch -> Rollback. {err}")
            shutil.copy2(backup, MODULE)
            write_report(f"SYNTAX_FAIL\n{err}\nBackup: {backup}\n")
            return 1

        # schreiben
        MODULE.write_text(s, encoding="utf-8", newline="\n")
        log("Schreibe Datei – OK")

        # Mini-Laufzeitprüfung: Tokenisieren zum Aufdecken versteckter CR
        with open(MODULE, "rb") as f:
            try:
                for _ in tokenize.tokenize(f.readline):
                    pass
            except tokenize.TokenError:
                pass

        rep.write("OK: Patch angewendet.\n")
        rep.write(f"Backup: {backup}\n")
        write_report(rep.getvalue())
        return 0

    except Exception as ex:
        tb = traceback.format_exc()
        log("FEHLER im Runner – Rollback.")
        try:
            # Wenn Backup existiert, wiederherstellen
            if 'backup' in locals() and Path(backup).exists():
                shutil.copy2(backup, MODULE)
        except Exception:
            pass
        write_report(f"EXCEPTION\n{ex}\n\n{tb}")
        return 1

if __name__ == "__main__":
    rc = main()
    sys.exit(rc)
