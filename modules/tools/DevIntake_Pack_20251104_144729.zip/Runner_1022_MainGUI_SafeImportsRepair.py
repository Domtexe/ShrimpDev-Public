"""
Runner_1022_MainGUI_SafeImportsRepair
- Repariert den Safe-Import-Block in main_gui.py (defekte 'except'-Fragmente entfernen)
- Schreibt einen sauberen, gültigen Fallback-Block (Intake/Agent/Project)
- Hebt Version auf v9.9.13
"""
from __future__ import annotations
import os, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
GUI  = os.path.join(ROOT, "main_gui.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

SAFE_BLOCK = r'''# ---- Safe imports for frames (with fallbacks) ----
try:
    from modules.module_code_intake import IntakeFrame
except Exception as ex:
    def IntakeFrame(master):
        import tkinter as tk, tkinter.ttk as ttk, traceback
        frm = ttk.Frame(master)
        txt = tk.Text(frm, height=12, wrap="word")
        txt.pack(fill="both", expand=True, padx=8, pady=8)
        msg = "Fehler: IntakeFrame konnte nicht geladen werden.\\n\\n" + "".join(
            traceback.format_exception_only(type(ex), ex)
        )
        txt.insert("end", msg)
        return frm

try:
    from modules.module_agent_ui import AgentFrame
except Exception as ex:
    def AgentFrame(master):
        import tkinter as tk, tkinter.ttk as ttk, traceback
        frm = ttk.Frame(master)
        ttk.Label(frm, text="Agent-UI konnte nicht geladen werden.").pack(padx=10, pady=10)
        tk.Message(frm, text="".join(traceback.format_exception_only(type(ex), ex)), width=900).pack(padx=10, pady=4)
        return frm

try:
    from modules.module_project_ui import ProjectFrame
except Exception as ex:
    def ProjectFrame(master):
        import tkinter as tk, tkinter.ttk as ttk, traceback
        frm = ttk.Frame(master)
        ttk.Label(frm, text="Project-UI konnte nicht geladen werden.").pack(padx=10, pady=10)
        tk.Message(frm, text="".join(traceback.format_exception_only(type(ex), ex)), width=900).pack(padx=10, pady=4)
        return frm
# -----------------------------------------------'''

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1022] {ts} {msg}\n")
    except Exception:
        pass
    print(msg, flush=True)

def backup_write(path: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

def patch_main() -> None:
    with open(GUI, "r", encoding="utf-8") as f:
        src = f.read()

    # Versionstitel anheben (falls vorhanden)
    src = src.replace("ShrimpDev – v9.9.12", "ShrimpDev – v9.9.13")\
             .replace("ShrimpDev – v9.9.11", "ShrimpDev – v9.9.13")\
             .replace("ShrimpDev – v9.9.10", "ShrimpDev – v9.9.13")\
             .replace("ShrimpDev – v9.9.6",  "ShrimpDev – v9.9.13")

    start_tag = "# ---- Safe imports for frames"
    end_tag   = "# -----------------------------------------------"
    s = src.find(start_tag)
    e = src.find(end_tag, s if s != -1 else 0)
    if s == -1 or e == -1:
        # Kein klarer Block gefunden → wir fügen unseren Safe-Block vor dem ConfigMgr-Import ein
        insert_point = src.find("from modules.config_mgr import ConfigMgr")
        if insert_point == -1:
            raise RuntimeError("Konnte Einfügepunkt nicht finden (ConfigMgr-Import fehlt).")
        new_src = src[:insert_point] + SAFE_BLOCK + "\n\n" + src[insert_point:]
    else:
        # Block ersetzen (inkl. End-Tag)
        new_src = src[:s] + SAFE_BLOCK + src[e+len(end_tag):]

    backup_write(GUI, new_src)

def bump_meta() -> None:
    with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
        f.write("ShrimpDev v9.9.13\n")
    with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
        f.write("""
## v9.9.13 (2025-10-18)
- main_gui: Safe-Import-Block vollständig repariert (gültige except-Blöcke, korrekte Fallback-Frames)
""")

def main() -> int:
    try:
        patch_main()
        bump_meta()
        log("Patch erfolgreich.")
        return 0
    except Exception as ex:
        log(f"FEHLER: {ex}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
