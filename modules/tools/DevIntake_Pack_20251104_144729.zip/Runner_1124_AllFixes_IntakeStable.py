# -*- coding: utf-8 -*-
r"""
Runner_1124_AllFixes_IntakeStable
- Stellt zentrales Logging sicher (modules/snippets/logger_snippet.write_log)
- Patcht main_gui.py: entfernt alte Guard-Blöcke (1118/1118b/1119/1121/1122)
  und fügt einen reentrancy-sicheren Central Tk Guard direkt NACH den
  `from __future__ import ...`-Imports ein (idempotent).
- Patcht modules/module_code_intake.py: Editor-Guards (Paste/Key/Modified),
  debounce Detect-Scheduler, keine Doppel-Bindings, logging mit Fallback.
- Schreibt Backups in _Archiv/, Report in _Reports/.
- Syntaxprobe; bei Fehlern: automatischer Rollback.

Start: py -3 -u tools\Runner_1124_AllFixes_IntakeStable.py
"""

from __future__ import annotations
import os, re, time, shutil, traceback

ROOT      = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
P_MAIN    = os.path.join(ROOT, "main_gui.py")
P_INTAKE  = os.path.join(ROOT, "modules", "module_code_intake.py")
P_LOGGER  = os.path.join(ROOT, "modules", "snippets", "logger_snippet.py")
ARCH      = os.path.join(ROOT, "_Archiv")
REPORTS   = os.path.join(ROOT, "_Reports")
os.makedirs(ARCH, exist_ok=True)
os.makedirs(REPORTS, exist_ok=True)
REPORT    = os.path.join(REPORTS, "Runner_1124_AllFixes_IntakeStable_report.txt")

def rep(msg: str) -> None:
    with open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip() + "\n")

def backup(path: str) -> str:
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, dst)
    rep(f"[Backup] {path} -> {dst}")
    return dst

# --------------------------------------------------------------------------- #
# 1) Logger sicherstellen
LOGGER_SRC = r'''# -*- coding: utf-8 -*-
from __future__ import annotations
import os, time, io

_MAX_BYTES = 1_000_000

def _target_path() -> str:
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    return os.path.join(root, "debug_output.txt")

def _rotate_if_needed(p: str) -> None:
    try:
        if os.path.exists(p) and os.path.getsize(p) > _MAX_BYTES:
            bak = p + ".1"
            try:
                if os.path.exists(bak):
                    os.remove(bak)
            except Exception:
                pass
            try:
                os.replace(p, bak)
            except Exception:
                pass
    except Exception:
        pass

def write_log(prefix: str, message: str) -> None:
    try:
        p = _target_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        _rotate_if_needed(p)
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        with io.open(p, "a", encoding="utf-8", newline="\n") as f:
            f.write(f"[{prefix}] {ts} {message}\n")
    except Exception:
        pass
'''

def ensure_logger() -> None:
    os.makedirs(os.path.dirname(P_LOGGER), exist_ok=True)
    if not os.path.exists(P_LOGGER):
        with open(P_LOGGER, "w", encoding="utf-8", newline="\n") as f:
            f.write(LOGGER_SRC)
        rep(f"[Logger] erstellt: {P_LOGGER}")
    else:
        rep("[Logger] vorhanden – unverändert.")

# --------------------------------------------------------------------------- #
# 2) main_gui.py – Central Tk Guard (nach __future__)
TAG_OLD_BLOCKS = [
    "# === 1119 TopLevel Tk Guard (auto) ===", "# === /1119 ===",
    "# === 1121 Central Tk Guard (auto) ===", "# === /1121 ===",
    "# === 1122 Central Tk Guard (auto) ===", "# === /1122 ===",
]
TAG_1124_S = "# === 1124 Central Tk Guard (auto) ==="
TAG_1124_E = "# === /1124 ==="

def central_guard_snippet() -> str:
    return (
        f"\n{TAG_1124_S}\n"
        "def __shrimpdev__central_tk_guard__():\n"
        "    import sys, traceback, time, os\n"
        "    try:\n"
        "        from modules.snippets.logger_snippet import write_log as _write\n"
        "    except Exception:\n"
        "        LOG = os.path.join(os.path.dirname(__file__), 'debug_output.txt')\n"
        "        def _write(prefix: str, message: str) -> None:\n"
        "            try:\n"
        "                ts = time.strftime('%Y-%m-%d %H:%M:%S')\n"
        "                with open(LOG, 'a', encoding='utf-8', newline='\\n') as f:\n"
        "                    f.write(f\"[{prefix}] {ts} {message}\\n\")\n"
        "            except Exception:\n"
        "                pass\n"
        "    busy = {'v': False}\n"
        "    def _handler(exc, val, tb):\n"
        "        if busy['v']:\n"
        "            return\n"
        "        busy['v'] = True\n"
        "        try:\n"
        "            try:\n"
        "                msg = ''.join(traceback.format_exception(exc, val, tb))\n"
        "            except Exception:\n"
        "                msg = '<unformatable exception>'\n"
        "            try:\n"
        "                _write('TK', 'EXC\\n' + msg)\n"
        "            except Exception:\n"
        "                pass\n"
        "        finally:\n"
        "            busy['v'] = False\n"
        "    try:\n"
        "        import tkinter as _tk\n"
        "        _tk.Misc.report_callback_exception = _handler  # type: ignore[attr-defined]\n"
        "        def _safe__report_exception(self):\n"
        "            et, ev, tb = sys.exc_info()\n"
        "            if et is not None:\n"
        "                _handler(et, ev, tb)\n"
        "        _tk.BaseWidget._report_exception = _safe__report_exception  # type: ignore[attr-defined]\n"
        "    except Exception:\n"
        "        pass\n"
        "    try:\n"
        "        orig = sys.excepthook\n"
        "        def _safe_hook(et, ev, tb):\n"
        "            try:\n"
        "                _write('PY', 'EXC\\n' + ''.join(traceback.format_exception(et, ev, tb)))\n"
        "            except Exception:\n"
        "                pass\n"
        "            try:\n"
        "                orig(et, ev, tb)\n"
        "            except Exception:\n"
        "                pass\n"
        "        sys.excepthook = _safe_hook\n"
        "    except Exception:\n"
        "        pass\n"
        "__shrimpdev__central_tk_guard__()\n"
        f"{TAG_1124_E}\n"
    )

def patch_main_gui() -> None:
    if not os.path.exists(P_MAIN):
        rep("[main_gui] nicht gefunden – übersprungen.")
        return
    with open(P_MAIN, "r", encoding="utf-8") as f:
        src = f.read()

    orig = src

    # alte Guard-Blöcke entfernen
    for i in range(0, len(TAG_OLD_BLOCKS), 2):
        start, end = TAG_OLD_BLOCKS[i], TAG_OLD_BLOCKS[i+1]
        src, n = re.subn(re.escape(start) + r"[\s\S]*?" + re.escape(end), "", src)
        if n:
            rep(f"[main_gui] alter Guard entfernt: {start}..{end}")

    # eigenen 1124-Block entfernen (idempotent)
    src, _ = re.subn(re.escape(TAG_1124_S) + r"[\s\S]*?" + re.escape(TAG_1124_E), "", src)

    # Position nach __future__-Block finden
    m = re.match(r'^(?:\s*from\s+__future__\s+import[^\n]*\n)+', src, flags=re.MULTILINE)
    ins = m.end() if m else 0

    src = src[:ins] + central_guard_snippet() + src[ins:]

    # Schreiben + Syntaxprobe
    backup(P_MAIN)
    with open(P_MAIN, "w", encoding="utf-8", newline="\n") as f:
        f.write(src)
    try:
        compile(src, P_MAIN, "exec")
        rep("[main_gui] Patch OK (Syntax).")
    except Exception as ex:
        rep("[main_gui] SYNTAX-ERR: " + repr(ex))
        # Rollback
        with open(P_MAIN, "w", encoding="utf-8", newline="\n") as f:
            f.write(orig)
        rep("[main_gui] ROLLBACK ausgeführt.")

# --------------------------------------------------------------------------- #
# 3) module_code_intake.py – Editor-Guards + Scheduler
EDITOR_SNIPPET = r'''
    # --- Editor-Event-Guards (1124) -----------------------------------------
    def _safe_write(self, prefix: str, message: str) -> None:
        try:
            from modules.snippets.logger_snippet import write_log as _w
            _w(prefix, message)
        except Exception:
            try:
                import time
                p = os.path.join(os.path.dirname(os.path.dirname(__file__)), "debug_output.txt")
                ts = time.strftime("%Y-%m-%d %H:%M:%S")
                with open(p, "a", encoding="utf-8", newline="\n") as f:
                    f.write(f"[{prefix}] {ts} {message}\n")
            except Exception:
                pass

    def _ensure_editor_bindings(self) -> None:
        """Genau ein Binding pro Event – Doppelbindungen vermeiden."""
        try:
            self.txt.unbind("<<Paste>>")
            self.txt.unbind("<Control-v>")
            self.txt.unbind("<<Modified>>")
            self.txt.unbind("<KeyRelease>")
        except Exception:
            pass
        self.txt.bind("<<Paste>>", self._on_editor_paste)
        self.txt.bind("<Control-v>", self._on_editor_paste)
        self.txt.bind("<<Modified>>", self._on_editor_modified)
        self.txt.bind("<KeyRelease>", self._on_editor_key)

    def _on_editor_paste(self, _evt=None):
        """Beim Einfügen keine Events re-triggern; nur Detect debouncen."""
        try:
            self._schedule_detect(220)
        except Exception as ex:
            self._safe_write("INTAKE", f"PASTE_ERR: {ex!r}")

    def _on_editor_key(self, _evt=None):
        try:
            self._schedule_detect(250)
        except Exception as ex:
            self._safe_write("INTAKE", f"KEY_ERR: {ex!r}")

    def _on_editor_modified(self, _evt=None):
        try:
            try:
                self.txt.edit_modified(False)
            except Exception:
                pass
            self._schedule_detect(300)
        except Exception as ex:
            self._safe_write("INTAKE", f"MODIFIED_ERR: {ex!r}")

    def _schedule_detect(self, delay_ms: int = 250):
        """Debounce für Detect – ältere Jobs abbrechen."""
        try:
            if getattr(self, "_detect_job", None):
                try:
                    self.after_cancel(self._detect_job)
                except Exception:
                    pass
            self._detect_job = self.after(delay_ms, self._auto_detect_if_needed)
        except Exception as ex:
            self._safe_write("INTAKE", f"SCHED_ERR: {ex!r}")

    def _auto_detect_if_needed(self):
        try:
            self._ping("Auto-Erkennung…")
        except Exception:
            pass
        self._safe_detect()

    def _safe_detect(self):
        try:
            if hasattr(self, "_detect"):
                self._detect()
        except Exception as ex:
            import traceback
            self._safe_write("INTAKE", "DETECT_ERR\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
            try:
                self._update_led(self.led_detect, "yellow")
            except Exception:
                pass
    # --- /Editor-Event-Guards (1124) ----------------------------------------
'''

def patch_intake() -> None:
    if not os.path.exists(P_INTAKE):
        rep("[intake] Datei fehlt – übersprungen.")
        return
    with open(P_INTAKE, "r", encoding="utf-8") as f:
        src = f.read()
    orig = src

    m = re.search(r'(?ms)class\s+IntakeFrame\s*\([^)]*\)\s*:\s*(.*?)\n(?=[^\n]+\nclass\s|\Z)', src)
    if not m:
        rep("[intake] IntakeFrame-Klasse nicht gefunden – übersprungen.")
        return
    block = m.group(1)

    # Alte Handler grob entfernen
    def kill(name: str, b: str) -> str:
        pat = rf'\n[ \t]*def[ \t]+{name}\s*\([^)]*\)\s*:[\s\S]*?(?=\n[ \t]*def[ \t]+|\n[ \t]*# ---|^\s*\Z)'
        return re.sub(pat, "\n", b, flags=re.MULTILINE)

    for fn in ("_on_editor_paste","_on_editor_key","_on_editor_modified",
               "_schedule_detect","_auto_detect_if_needed","_safe_detect",
               "_ensure_editor_bindings","_safe_write"):
        block = kill(fn, block)

    if "Editor-Event-Guards (1124)" not in block:
        block = block.rstrip() + "\n" + EDITOR_SNIPPET

    # nach Text-Widget-Erzeugung: detect_job + bindings setzen
    block = re.sub(
        r'(\bself\.txt\s*=\s*tk\.Text\([^)]*\)\s*\n)',
        r'\1        self._detect_job = None\n        self._ensure_editor_bindings()\n',
        block, count=1
    )

    new_src = src[:m.start(1)] + block + src[m.end(1):]

    # Schreiben + Syntaxprobe
    backup(P_INTAKE)
    with open(P_INTAKE, "w", encoding="utf-8", newline="\n") as f:
        f.write(new_src)
    try:
        compile(new_src, P_INTAKE, "exec")
        rep("[intake] Patch OK (Syntax).")
    except Exception as ex:
        rep("[intake] SYNTAX-ERR: " + repr(ex))
        # Rollback
        with open(P_INTAKE, "w", encoding="utf-8", newline="\n") as f:
            f.write(orig)
        rep("[intake] ROLLBACK ausgeführt.")

# --------------------------------------------------------------------------- #

def main() -> None:
    with open(REPORT, "w", encoding="utf-8", newline="\n") as f:
        f.write("Runner_1124_AllFixes_IntakeStable – Start\n")
    try:
        ensure_logger()
        patch_main_gui()
        patch_intake()
        rep("OK – Runner abgeschlossen.")
    except Exception as ex:
        rep("FEHLER: " + repr(ex))
        rep("TRACE:\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))

if __name__ == "__main__":
    main()
