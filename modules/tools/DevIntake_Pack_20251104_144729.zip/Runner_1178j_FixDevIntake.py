# -*- coding: utf-8 -*-
from __future__ import annotations
import os, sys, time, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]  # ...\ShrimpDev
ARCH = ROOT / "_Archiv"
MODS = ROOT / "modules"
SNIP = MODS / "snippets"
LOG  = ROOT / "debug_output.txt"

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    LOG.write_text("", encoding="utf-8", errors="ignore") if not LOG.exists() else None
    with LOG.open("a", encoding="utf-8", newline="\n") as f:
        f.write(f"[R1178j] {ts} {msg}\n")

def write_file(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")

def backup(path: Path) -> None:
    try:
        if path.exists():
            ARCH.mkdir(parents=True, exist_ok=True)
            bak = ARCH / f"{path.name}.{time.strftime('%Y%m%d_%H%M%S')}.bak"
            bak.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
            log(f"Backup erstellt: {bak}")
    except Exception as e:
        log(f"Backup-Fehler: {e}")

def ensure_snippet_toolbar():
    """Nur anlegen, wenn nicht vorhanden – minimale, kompatible Toolbar."""
    path = SNIP / "snippet_dev_intake_toolbar.py"
    if path.exists():
        return
    code = (
        "# -*- coding: utf-8 -*-\n"
        "from __future__ import annotations\n"
        "import tkinter as tk\n"
        "from tkinter import ttk\n"
        "def attach_toolbar(parent, on_action):\n"
        "    bar = ttk.Frame(parent)\n"
        "    def _btn(txt, key):\n"
        "        b = ttk.Button(bar, text=txt, command=lambda: on_action(key))\n"
        "        b.pack(side='left', padx=(0,6))\n"
        "    _btn('Neu (Runner)', 'new_runner')\n"
        "    _btn('Öffnen…', 'open_file')\n"
        "    _btn('Ordner…', 'open_folder')\n"
        "    _btn('Reload', 'reload')\n"
        "    bar.pack(side='top', fill='x', padx=8, pady=6)\n"
        "    return bar\n"
    )
    write_file(path, code)
    log("Snippet-Toolbar minimal erstellt (fehlte).")

def main() -> int:
    try:
        log("Starting FixDevIntake…")

        # 1) Snippet ggf. sicherstellen
        ensure_snippet_toolbar()

        # 2) module_code_intake.py ersetzen (sauber/stabil)
        target = MODS / "module_code_intake.py"
        backup(target)

        code_path = ROOT / "_tmp_R1178j_module_code_intake.py"
        # Der eigentliche Codeblock wird im Chat geliefert – nimm den von oben 1:1.
        # Hier wird er nur zur Sicherheit aus einer temporären Datei gelesen, falls du ihn dort speicherst.
        # Alternativ: direkt Embedded – hier minimal:
        code = """REPLACE_WITH_CHAT_CODE"""
        if "REPLACE_WITH_CHAT_CODE" in code:
            log("WARN: Bitte den Code aus der Lieferung in module_code_intake.py schreiben (Runner optional).")

        # Schreibe nur, wenn der Platzhalter ersetzt wurde – sonst abort mit Rückgabe 2
        if "REPLACE_WITH_CHAT_CODE" in code:
            return 2

        write_file(target, code)

        # 3) Syntax-Check (import)
        sys.path.insert(0, str(ROOT))
        try:
            import importlib
            mod = importlib.import_module("modules.module_code_intake")
            importlib.reload(mod)
            log("ImportCheck OK: modules.module_code_intake")
        except Exception as e:
            log("ImportCheck FAIL:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 4

        log("Done.")
        return 0
    except Exception as e:
        log("Runner-FAIL:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    rc = main()
    sys.exit(rc)
