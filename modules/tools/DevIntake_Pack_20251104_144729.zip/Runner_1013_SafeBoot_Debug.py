"""
Runner_1013_SafeBoot_Debug
- Patches main_gui.py für Safe-Boot & Diagnose:
  * Fallback-Frames bei Importfehlern
  * Startfehler blockieren die GUI nicht; Fehler werden angezeigt+geloggt
  * Exit-Code bleibt 0 bei abgefangenen Startfehlern
- Version -> v9.9.4
"""
from __future__ import annotations
import os, time, shutil, traceback, re

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
GUI  = os.path.join(ROOT, "main_gui.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1013] {ts} {msg}\n")
    print(msg)

SAFE_IMPORT_BLOCK = r'''
# ---- Safe imports for frames (with fallbacks) ----
try:
    from modules.module_code_intake import IntakeFrame
except Exception as _ex:
    def IntakeFrame(master):
        import tkinter as tk, tkinter.ttk as ttk, traceback
        frm = ttk.Frame(master)
        txt = tk.Text(frm, height=10)
        txt.pack(fill="both", expand=True, padx=8, pady=8)
        txt.insert("end", "Fehler: IntakeFrame konnte nicht geladen werden.\n\n" + "".join(traceback.format_exception_only(type(_ex), _ex)))
        return frm

try:
    from modules.module_agent_ui import AgentFrame
except Exception as _ex:
    def AgentFrame(master):
        import tkinter as tk, tkinter.ttk as ttk, traceback
        frm = ttk.Frame(master)
        lbl = ttk.Label(frm, text="Agent-UI konnte nicht geladen werden.")
        lbl.pack(padx=10, pady=10)
        tk.Message(frm, text="".join(traceback.format_exception_only(type(_ex), _ex)), width=800).pack(padx=10, pady=4)
        return frm

try:
    from modules.module_project_ui import ProjectFrame
except Exception as _ex:
    def ProjectFrame(master):
        import tkinter as tk, tkinter.ttk as ttk, traceback
        frm = ttk.Frame(master)
        lbl = ttk.Label(frm, text="Project-UI konnte nicht geladen werden.")
        lbl.pack(padx=10, pady=10)
        tk.Message(frm, text="".join(traceback.format_exception_only(type(_ex), _ex)), width=800).pack(padx=10, pady=4)
        return frm
# -----------------------------------------------
'''

SAFE_MAIN_WRAPPER = r'''
def _safe_main() -> None:
    root = tk.Tk()
    root.title("ShrimpDev – v9.9.4")
    root.geometry("1100x740")

    # Styles
    style = ttk.Style()
    try:
        style.theme_use("clam")
    except Exception:
        pass
    style.configure("TButton", padding=(8,4))
    style.configure("TLabel",  padding=(2,0))

    cfg = ConfigMgr()

    # Always-on-Top Setting
    var_top = tk.BooleanVar(value=cfg.get_bool("general", "always_on_top", False))
    def _apply_top():
        try:
            root.attributes("-topmost", bool(var_top.get()))
            cfg.set_str("general", "always_on_top", "true" if var_top.get() else "false")
        except Exception as ex:
            write_log("GUI", f"TOPMOST_ERR: {ex}")

    nb = ttk.Notebook(root)
    nb.pack(fill="both", expand=True)

    # Tab-Erzeugung mit Safe-Fallbacks
    try:
        tab_intake = IntakeFrame(nb)
    except Exception as ex:
        write_log("GUI", "INTAKE_INIT_ERROR\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        tab_intake = ttk.Frame(nb)
        ttk.Label(tab_intake, text="Fehler beim Laden des Intake-Tabs. Details siehe debug_output.txt").pack(padx=10, pady=10)

    try:
        tab_agent  = AgentFrame(nb)
    except Exception as ex:
        write_log("GUI", "AGENT_INIT_ERROR\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        tab_agent = ttk.Frame(nb)
        ttk.Label(tab_agent, text="Fehler beim Laden des Agent-Tabs.").pack(padx=10, pady=10)

    try:
        tab_proj   = ProjectFrame(nb)
    except Exception as ex:
        write_log("GUI", "PROJECT_INIT_ERROR\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        tab_proj = ttk.Frame(nb)
        ttk.Label(tab_proj, text="Fehler beim Laden des Project-Tabs.").pack(padx=10, pady=10)

    nb.add(tab_intake, text="Code Intake")
    nb.add(tab_agent,  text="Agent")
    nb.add(tab_proj,   text="Project")
    nb.select(0)

    # Menü (schlank)
    menubar = tk.Menu(root)
    m_file = tk.Menu(menubar, tearoff=0)
    m_file.add_checkbutton(label="Always on Top", onvalue=True, offvalue=False,
                           variable=var_top, command=_apply_top)
    m_file.add_separator()
    m_file.add_command(label="Beenden", command=root.destroy)
    menubar.add_cascade(label="File", menu=m_file)

    m_help = tk.Menu(menubar, tearoff=0)
    m_help.add_command(label="Info", command=lambda: messagebox.showinfo("ShrimpDev","Standalone Dev-Umgebung für ShrimpHub"))
    menubar.add_cascade(label="Help", menu=m_help)
    root.config(menu=menubar)

    # Shortcuts (global)
    root.bind_all("<Control-t>", lambda e: (var_top.set(not var_top.get()), _apply_top()))

    # Statusbar
    status = tk.StringVar(value="Bereit.")
    bar = ttk.Label(root, textvariable=status, anchor="w")
    bar.pack(side="bottom", fill="x")

    def report_callback_exception(*exc):
        msg = "".join(traceback.format_exception(*exc))
        write_log("GUI", "CRASH\n" + msg)
        if os.environ.get("SHRIMPDEV_DEBUG") == "1":
            print("--- Tk callback exception ---")
            print(msg, flush=True)
        status.set(f"Fehler: {exc[-1]}")
    root.report_callback_exception = report_callback_exception

    _apply_top()
    root.mainloop()
'''

def patch():
    with open(GUI, "r", encoding="utf-8") as f:
        src = f.read()

    # 1) Version anheben
    src = src.replace("ShrimpDev – v9.9.3", "ShrimpDev – v9.9.4")\
             .replace("ShrimpDev – v9.9.2", "ShrimpDev – v9.9.4")\
             .replace("ShrimpDev – v9.9.1", "ShrimpDev – v9.9.4")

    # 2) Sicherstellen, dass Safe-Imports verwendet werden
    #    Ersetze die direkten Imports der Frames durch Safe-Block
    src = re.sub(
        r"from modules\.module_code_intake import IntakeFrame\s*\n"
        r"from modules\.module_agent_ui import AgentFrame\s*\n"
        r"from modules\.module_project_ui import ProjectFrame",
        SAFE_IMPORT_BLOCK.strip(),
        src,
        count=1,
        flags=re.MULTILINE
    )

    # 3) Safe _safe_main einfügen (ersetzt bestehende Definition)
    src = re.sub(
        r"def _safe_main\([\s\S]+?^if __name__ == \"__main__\":",
        SAFE_MAIN_WRAPPER.strip() + "\n\nif __name__ == \"__main__\":",
        src,
        flags=re.MULTILINE
    )

    # 4) __main__-Block: bei Exceptions nicht mehr sys.exit(1), sondern Konsole + RC=0
    src = re.sub(
        r"if __name__ == \"__main__\":\s*\n\s*try:\s*\n\s*_safe_main\(\)\s*\n\s*except Exception:\s*\n\s*tb = traceback\.format_exc\(\)\s*\n\s*write_log\(\"GUI\", \"CRASH\\n\" \+ tb\)\s*\n\s*sys\.exit\(1\)",
        "if __name__ == \"__main__\":\n"
        "    try:\n"
        "        _safe_main()\n"
        "    except Exception:\n"
        "        tb = traceback.format_exc()\n"
        "        write_log(\"GUI\", \"CRASH\\n\" + tb)\n"
        "        print(tb, flush=True)\n"
        "        # Safe exit (RC=0) – GUI konnte nicht starten, aber wir beenden nicht mit Fehlercode\n"
        "        pass",
        src,
        flags=re.MULTILINE
    )

    # Backup + schreiben
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"main_gui.py.{int(time.time())}.bak")
    shutil.copy2(GUI, bck)
    with open(GUI, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(src)

    # Version & Changelog
    with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
        f.write("ShrimpDev v9.9.4\n")
    with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
        f.write("""
## v9.9.4 (2025-10-18)
- Safe-Boot: Import-/Init-Fehler stoppen die GUI nicht (Platzhalter-Tabs mit Details)
- Diagnose: Fehler in Konsole + debug_output.txt, SHRIMPDEV_DEBUG=1 aktiviert
- Exit-Code 0 bei abgefangenen Startfehlern
""")

    log("main_gui.py gepatcht (Safe-Boot & Debug).")
    return 0

if __name__ == "__main__":
    raise SystemExit(patch())
