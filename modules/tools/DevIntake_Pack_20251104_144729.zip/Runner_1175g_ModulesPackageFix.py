from __future__ import annotations
import os, re
from patchlib_guard import guarded_apply, FileCtx

ROOT = r"D:\ShrimpDev"
MODULES = os.path.join(ROOT, "modules")
INIT = os.path.join(MODULES, "__init__.py")
MAIN = os.path.join(ROOT, "main_gui.py")

# 1) __init__.py sicherstellen
if not os.path.exists(INIT):
    with open(INIT, "w", encoding="utf-8") as f:
        f.write("# modules package marker\n")

def _transform(ctx: FileCtx):
    src = ctx.modified

    # Korrigiere Importpfade
    src = re.sub(
        r"import\s+module_code_intake",
        "from modules import module_code_intake",
        src,
    )
    src = re.sub(
        r"import\s+module_code_intake\s+as\s+intake",
        "from modules import module_code_intake as intake",
        src,
    )
    src = re.sub(
        r"import\s+modules\.module_code_intake\s+as\s+intake",
        "from modules import module_code_intake as intake",
        src,
    )

    ctx.modified = src

ok, msg = guarded_apply(MAIN, _transform)
print(("[1175g] " + (msg or "")).strip())
raise SystemExit(0 if ok else 1)
