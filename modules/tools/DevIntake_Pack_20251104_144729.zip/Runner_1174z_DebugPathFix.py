# -*- coding: utf-8 -*-
"""
[1174z] Robust DebugPathFix:
Korrigiert alle fehlerhaften open("D:\ShrimpDev\debug_output.txt"...)
zu open(r"D:\ShrimpDev\debug_output.txt", ...)
"""
import re, sys, argparse, py_compile
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True)
    args = ap.parse_args()
    p = Path(args.file)
    src = p.read_text(encoding="utf-8", errors="ignore")

    # Muster mit oder ohne doppelte Backslashes
    pat = re.compile(
        r'with\s+open\(\s*"D:(?:\\\\|\\)ShrimpDev(?:\\\\|\\)debug_output\.txt"\s*,'
    )
    repl = r'with open(r"D:\\ShrimpDev\\debug_output.txt",'
    src2 = pat.sub(repl, src)

    if src2 == src:
        print("[1174z] Keine Änderung nötig (bereits r-String oder kein Treffer).")
        sys.exit(0)

    tmp = p.with_suffix(p.suffix + ".1174z.tmp")
    tmp.write_text(src2, encoding="utf-8")

    try:
        py_compile.compile(str(tmp), doraise=True)
    except Exception as e:
        print(f"[1174z] Syntaxfehler nach Änderung: {e}", file=sys.stderr)
        sys.exit(1)

    tmp.replace(p)
    print("[1174z] Pfadfix erfolgreich, Syntax OK.")

if __name__ == "__main__":
    try:
        main()
        sys.exit(0)
    except Exception as e:
        print(f"[1174z] Fehler: {e}", file=sys.stderr)
        sys.exit(1)
