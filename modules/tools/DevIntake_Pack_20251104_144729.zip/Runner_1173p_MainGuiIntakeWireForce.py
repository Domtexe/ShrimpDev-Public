# -*- coding: utf-8 -*-
"""
1173p - MainGui Intake Wiring Force-Fix
- Erzwingt _safe_add_intake_tab(nb)
- Härtet/ergänzt _mount_intake_tab_safe(container)
- Backup + Syntax-Check + Rollback + ausführliches Logging
"""
import os, io, re, sys, time, traceback, py_compile

MAIN_NAME = "main_gui.py"
ARCH_DIR  = "_Archiv"
TS        = str(int(time.time()))

def log(root, msg):
    try:
        p = os.path.join(root, "debug_output.txt")
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        with io.open(p, "a", encoding="utf-8", newline="\n") as f:
            f.write(f"[1173p {ts}] {msg}\n")
    except Exception:
        pass
    print(msg)

def find_root():
    # Starte von tools/ aus, gehe bis 6 Ebenen hoch
    cur = os.path.abspath(os.path.dirname(__file__))
    for _ in range(6):
        cand = os.path.join(cur, MAIN_NAME)
        if os.path.isfile(cand):
            return cur
        nxt = os.path.dirname(cur)
        if nxt == cur:
            break
        cur = nxt
    raise FileNotFoundError("main_gui.py nicht gefunden (Aufwärtssuche).")

def rd(p):
    with io.open(p, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def wr(p, s):
    with io.open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)

def backup(root, src):
    os.makedirs(os.path.join(root, ARCH_DIR), exist_ok=True)
    dst = os.path.join(root, ARCH_DIR, f"{os.path.basename(src)}.{TS}.bak")
    wr(dst, rd(src))
    log(root, f"Backup erstellt: {dst}")
    return dst

SAFE_ADD_FUNC = r'''
def _safe_add_intake_tab(nb):
    """
    Fügt den Code-Intake-Tab robust hinzu und protokolliert Fehler.
    """
    import traceback
    try:
        tab = IntakeFrame(nb)
    except Exception as ex:
        try:
            from tkinter import ttk  # falls ttk lokal nicht sichtbar ist
        except Exception:
            pass
        try:
            write_log("GUI", "INTAKE_INIT_ERROR\\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        except Exception:
            pass
        try:
            tab = ttk.Frame(nb)
            ttk.Label(tab, text="Fehler beim Laden des Intake-Tabs. Details siehe debug_output.txt").pack(padx=10, pady=10)
        except Exception:
            return
    try:
        nb.add(tab, text="Code Intake")
    except Exception as ex:
        try:
            write_log("GUI", f"INTAKE_TAB_ADD_ERR: {ex}")
        except Exception:
            pass
'''.lstrip("\n")

MOUNT_FUNC = r'''
def _mount_intake_tab_safe(container):
    """
    Mountet IntakeFrame in den gegebenen Container (ohne self-Abhängigkeit).
    """
    import traceback
    try:
        inner = IntakeFrame(container)
    except Exception as ex:
        try:
            from tkinter import ttk
            inner = ttk.Frame(container)
            ttk.Label(inner, text="Fehler beim Laden des Intake-Tabs. Details siehe debug_output.txt").pack(padx=10, pady=10)
        except Exception:
            return
        try:
            write_log("GUI", "INTAKE_INIT_ERROR\\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        except Exception:
            pass
    try:
        inner.pack(fill="both", expand=True)
    except Exception as ex:
        try:
            write_log("GUI", f"INTAKE_MOUNT_ERR: {ex}")
        except Exception:
            pass
'''.lstrip("\n")

def ensure_helper(text, root):
    changed = False

    # 1) _safe_add_intake_tab erzwingen, wenn fehlt
    if not re.search(r"^\s*def\s+_safe_add_intake_tab\s*\(", text, re.M):
        # Einfügeposition: VOR _safe_main, sonst am Dateiende
        m = re.search(r"^\s*def\s+_safe_main\s*\(", text, re.M)
        if m:
            i = m.start()
            text = text[:i] + SAFE_ADD_FUNC + "\n" + text[i:]
            log(root, "Helper _safe_add_intake_tab hinzugefügt (vor _safe_main).")
        else:
            text = text + "\n\n" + SAFE_ADD_FUNC
            log(root, "Helper _safe_add_intake_tab angehängt (Dateiende).")
        changed = True
    else:
        log(root, "_safe_add_intake_tab bereits vorhanden.")

    # 2) _mount_intake_tab_safe bereinigen/ergänzen
    if not re.search(r"^\s*def\s+_mount_intake_tab_safe\s*\(", text, re.M):
        m = re.search(r"^\s*def\s+_safe_main\s*\(", text, re.M)
        if m:
            i = m.start()
            text = text[:i] + MOUNT_FUNC + "\n" + text[i:]
            log(root, "Helper _mount_intake_tab_safe hinzugefügt (vor _safe_main).")
        else:
            text = text + "\n\n" + MOUNT_FUNC
            log(root, "Helper _mount_intake_tab_safe angehängt (Dateiende).")
        changed = True
    else:
        # vorhandene, evtl. defekte Fassung durch saubere ersetzen
        pat = re.compile(r"^\s*def\s+_mount_intake_tab_safe\s*\([^\)]*\)\s*:\n(?:[ \t].*\n)+", re.M)
        new_text, n = pat.subn(MOUNT_FUNC, text, count=1)
        if n > 0:
            text = new_text
            changed = True
            log(root, "_mount_intake_tab_safe ersetzt (saubere Version).")
        else:
            log(root, "_mount_intake_tab_safe unverändert (keine Ersetzung nötig).")

    return text, changed

def main():
    root = find_root()
    src  = os.path.join(root, MAIN_NAME)
    bak  = backup(root, src)

    text = rd(src)
    text2, changed = ensure_helper(text, root)

    if not changed:
        log(root, "Keine Änderungen nötig. (Wiring scheint bereits vollständig.)")
        # Trotzdem verifizieren, dass der Name jetzt resolvbar ist:
        # (Kompiliert die Datei – schlägt NICHT auf Runtime-Namen fehl)
    else:
        wr(src + ".1173p.tmp", text2)
        try:
            py_compile.compile(src + ".1173p.tmp", doraise=True)
        except Exception as ex:
            log(root, "Syntax-Check FEHLER -> Rollback auf Backup.")
            log(root, "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
            try:
                os.remove(src + ".1173p.tmp")
            except Exception:
                pass
            # Rollback: Original aus Backup zurückschreiben
            wr(src, rd(bak))
            return 1
        # Syntax OK -> übernehmen
        wr(src, text2)
        try:
            os.remove(src + ".1173p.tmp")
        except Exception:
            pass
        log(root, "Patch übernommen, Syntax OK.")

    # Zusatz: Sichtprüfung, ob Signaturen vorhanden sind
    current = rd(src)
    have_add  = bool(re.search(r"^\s*def\s+_safe_add_intake_tab\s*\(", current, re.M))
    have_mount= bool(re.search(r"^\s*def\s+_mount_intake_tab_safe\s*\(", current, re.M))
    log(root, f"Presence: _safe_add_intake_tab={have_add}, _mount_intake_tab_safe={have_mount}")
    return 0 if (have_add and have_mount) else 2

if __name__ == "__main__":
    sys.exit(main())
