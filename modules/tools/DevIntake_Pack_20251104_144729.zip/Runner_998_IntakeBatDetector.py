# file: tools/Runner_998_IntakeBatDetector.py
from __future__ import annotations
from pathlib import Path
import re, sys

ROOT = Path(r"D:\ShrimpDev")
MOD = ROOT / "modules" / "module_code_intake.py"

EXTRACT = r'''
def _extract(code: str) -> tuple[str|None, str|None]:
    """
    Ermittelt (name_ohne_ext, .ext) aus dem Snippet.
    1) Explizite Marker (# file:, // file:, ; file:, YAML fm, fenced)
    2) Heuristik: BAT vor PY, wenn typische Batch-Tokens dominieren
    3) Runner_/module_-Namensheuristik
    """
    import re
    from pathlib import Path

    def _split(n: str) -> tuple[str,str]:
        n = Path(n).name.strip()
        if '.' in n:
            a,b = n.rsplit('.',1)
            return a, '.'+b.lower()
        return n, ''

    head = code[:8000]

    # --- 1) Marker ---
    markers = [
        r'(?im)^\s*#\s*file\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        r'(?im)^\s*//\s*file\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        r'(?im)^\s*;\s*file\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        r'(?ism)^---\s*\n.*?\bfile\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt)).*?\n---\s*',
        r'(?ism)^[`]{3,}.*?\n(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))[^`]{0,200}?\n[`]{3,}',
        r'(?im)^\s*[-#/* ]*filename\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        r'(?im)^\s*###\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
    ]
    for rx in markers:
        m = re.search(rx, head)
        if m and m.group('p'):
            stem,ext = _split(m.group('p'))
            return (stem or None, ext or None)

    # --- 2) Heuristik ---
    # BAT: @echo off am Anfang → sofort .bat
    if re.search(r'(?im)^\s*@echo\s+off\b', head):
        ext = '.bat'
    else:
        bat_tokens = 0
        for rx in (
            r'(?im)^\s*(?:rem\b|::)',
            r'(?im)\bgoto\s+\w+\b',
            r'(?im)\bif\s+(?:not\s+)?exist\b',
            r'(?im)\bset(?:local|)\b',
            r'(?im)\bendlocal\b',
            r'(?im)\bcall\b',
            r'(?im)\bfor\s+/?[flr]\b',
            r'(?im)\bpause\b',
        ):
            if re.search(rx, head): bat_tokens += 1
        ext = '.bat' if bat_tokens >= 2 else None

    # Python-Erkennung (nicht mehr „blockierend“)
    if not ext:
        py_tokens = 0
        for rx in (r'(?m)^\s*from\s+\w+', r'(?m)^\s*import\s+\w+', r'(?m)^\s*def\s+\w+\s*\(', r'(?m)^\s*class\s+\w+\s*\('):
            if re.search(rx, head): py_tokens += 1
        if py_tokens >= 1:
            ext = '.py'

    # Namensheuristik
    m = re.search(r'(?i)\bRunner_(\d{3,6})(?:[_\-]([A-Za-z0-9]+))?', head)
    if m:
        suffix = m.group(2) or 'Script'
        name = f"Runner_{m.group(1)}{('_'+suffix) if suffix else ''}"
        return name, (ext or '.bat')

    m = re.search(r'(?i)\bmodule_([A-Za-z0-9_]+)\b', head)
    if m:
        return f"module_{m.group(1)}", (ext or '.py')

    return (None, ext)
'''

DETECT = r'''
def _detect(self, auto: bool=False):
    code = self.txt.get("1.0", "end-1c")
    name, ext = _extract(code)

    if name: self.var_name.set(name)
    if ext:  self.var_ext.set(ext)

    # LED + Zielordner
    nm = self.var_name.get().strip()
    ex = self.var_ext.get().strip().lower()
    if nm and ex:
        self._set_led(self.led_detect, "green", "Erkennung OK")
        self.var_target.set(str(_map_target(self.workspace, nm + ex, ex)))
    elif ex:
        self._set_led(self.led_detect, "yellow", "Nur Endung erkannt")
    else:
        self._set_led(self.led_detect, "red", "Keine Erkennung")

    if not auto:
        self.status.set(f"Erkannt: name={nm or '-'} ext={ex or '-'} → {self.var_target.get() or '-'}")
'''

LED_HELPER = r'''
    def _set_led(self, lbl, color: str, text: str=""):
        try:
            colors = {"green":"#27ae60","yellow":"#e2b93d","red":"#e74c3c","grey":"#808080"}
            lbl.config(background=colors.get(color,"#808080"))
            try: self.lbl_detect_text.config(text=text)
            except Exception: pass
        except Exception:
            pass
'''

def patch() -> int:
    if not MOD.exists():
        print("[R998] module_code_intake.py fehlt"); return 1
    src = MOD.read_text(encoding="utf-8", errors="ignore")
    MOD.with_suffix(".py.r998_bat.bak").write_text(src, encoding="utf-8")

    # _extract ersetzt
    src = re.sub(r"def\s+_extract\(\s*code\s*:\s*str\s*\)[\s\S]*?(?=\n\s*def\s+|$)", EXTRACT, src, count=1)

    # _detect ersetzt
    src = re.sub(r"def\s+_detect\(\s*self,\s*auto\s*:\s*bool\s*=\s*False\s*\)[\s\S]*?(?=\n\s*def\s+|$)", DETECT, src, count=1)

    # _set_led hinzufügen falls fehlt
    if "_set_led(self, lbl" not in src:
        m = re.search(r"class\s+IntakeWindow\s*\([^\)]*\)\s*:\s*", src)
        if m:
            src = src[:m.end()] + LED_HELPER + src[m.end():]

    MOD.write_text(src, encoding="utf-8")
    compile(src, str(MOD), "exec")
    print("[R998] Intake: BAT-Erkennung & LED-Logik aktualisiert.")
    return 0

if __name__ == "__main__":
    raise SystemExit(patch())
