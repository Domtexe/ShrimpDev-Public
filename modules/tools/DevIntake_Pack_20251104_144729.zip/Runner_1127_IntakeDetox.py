# -*- coding: utf-8 -*-
"""
Runner_1127_IntakeDetox (ASCII clean)
- Repariert modules/module_code_intake.py so, dass Intake stabil laedt.
- Schritte:
  1) Backup nach _Archiv
  2) Entfernt def __auto_fix_return__()-Artefakte
  3) Entfernt ALLE alten "Editor-Event-Guards" Bloecke (1123/1124), egal wo eingerueckt
  4) Schreibt einen sauberen Guard-Block (modulweit, nicht eingerueckt)
  5) Erzwingt self._ensure_editor_bindings() einmalig im __init__
  6) Syntax-Check; bei Fehlern: Rollback

Exitcodes: 0=OK, 1=Rollback (Fehler)
"""
from __future__ import annotations

import re
import sys
import time
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
LOG  = ROOT / "debug_output.txt"

def log(prefix: str, msg: str) -> None:
    """Best-effort Log nach debug_output.txt (wirft nie)."""
    try:
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        with LOG.open("a", encoding="utf-8", newline="\n") as f:
            f.write(f"[{prefix}] {ts} {msg}\n")
    except Exception:
        pass

def backup() -> Path:
    ARCH.mkdir(exist_ok=True)
    ts = str(int(time.time()))
    dst = ARCH / f"module_code_intake.py.{ts}.bak"
    shutil.copy2(MOD, dst)
    log("R1127", f"Backup: {dst}")
    return dst

def read_text() -> str:
    return MOD.read_text(encoding="utf-8", errors="ignore")

def write_text(s: str) -> None:
    MOD.write_text(s, encoding="utf-8", newline="\n")

def remove_auto_fix_return(s: str) -> str:
    # def __auto_fix_return__():\n    return frm
    pattern = r"\n\s*def\s+__auto_fix_return__\s*\(\s*\)\s*:\s*\n\s*return\s+frm\s*\n"
    return re.sub(pattern, "\n", s)

def strip_old_guard_blocks(s: str) -> str:
    """
    Entfernt JEDE Variante von 1123/1124 Guard-Bloecken – auch wenn eingerueckt
    (z. B. versehentlich innerhalb anderer Methoden).
    """
    pattern = r"""
        \n[ \t]*\#\s*---\s*Editor-Event-Guards.*?       # Start-Marker
        \#\s*---\s*/Editor-Event-Guards\s*\(.*?\)\s*---\s*   # End-Marker
    """
    return re.sub(pattern, "\n", s, flags=re.DOTALL | re.IGNORECASE | re.VERBOSE)

CLEAN_GUARD_BLOCK = r"""
# --- Editor-Event-Guards (1127 clean) -----------------------------------------
def _safe_write(self, prefix: str, message: str) -> None:
    try:
        from modules.snippets.logger_snippet import write_log as _w
        _w(prefix, message)
    except Exception:
        try:
            import time, os
            p = os.path.join(os.path.dirname(os.path.dirname(__file__)), "debug_output.txt")
            ts = time.strftime("%Y-%m-%d %H:%M:%S")
            with open(p, "a", encoding="utf-8", newline="\n") as f:
                f.write(f"[{prefix}] {ts} {message}\n")
        except Exception:
            pass

def _ensure_editor_bindings(self) -> None:
    \"\"\"Genau ein Binding pro Event - Doppelbindungen vermeiden.\"\"\"
    try:
        self.txt.unbind("<<Paste>>")
        self.txt.unbind("<Control-v>")
        self.txt.unbind("<<Modified>>")
        self.txt.unbind("<KeyRelease>")
    except Exception:
        pass
    self.txt.bind("<<Paste>>", self._on_editor_paste)
    self.txt.bind("<Control-v>", self._on_editor_paste)
    self.txt.bind("<<Modified>>", self._on_editor_modified)
    self.txt.bind("<KeyRelease>", self._on_editor_key)

def _on_editor_paste(self, _evt=None):
    \"\"\"Beim Einfuegen keine Events re-triggern; nur Detect debouncen.\"\"\"
    try:
        self._schedule_detect(220)
    except Exception as ex:
        _safe_write(self, "INTAKE", f"PASTE_ERR: {ex!r}")

def _on_editor_key(self, _evt=None):
    try:
        self._schedule_detect(250)
    except Exception as ex:
        _safe_write(self, "INTAKE", f"KEY_ERR: {ex!r}")

def _on_editor_modified(self, _evt=None):
    try:
        try:
            self.txt.edit_modified(False)
        except Exception:
            pass
        self._schedule_detect(300)
    except Exception as ex:
        _safe_write(self, "INTAKE", f"MODIFIED_ERR: {ex!r}")

def _schedule_detect(self, delay_ms: int = 250):
    \"\"\"Debounce fuer Detect - aeltere Jobs abbrechen.\"\"\"
    try:
        if getattr(self, "_detect_job", None):
            try:
                self.after_cancel(self._detect_job)
            except Exception:
                pass
        self._detect_job = self.after(delay_ms, self._auto_detect_if_needed)
    except Exception as ex:
        _safe_write(self, "INTAKE", f"SCHED_ERR: {ex!r}")

def _auto_detect_if_needed(self):
    try:
        self._ping("Auto-Erkennung...")
    except Exception:
        pass
    _safe_detect(self)

def _safe_detect(self):
    try:
        if hasattr(self, "_detect"):
            self._detect()
    except Exception as ex:
        import traceback
        _safe_write(self, "INTAKE", "DETECT_ERR\n" + "".join(
            traceback.format_exception(type(ex), ex, ex.__traceback__)))
        try:
            self._update_led(self.led_detect, "yellow")
        except Exception:
            pass
# --- /Editor-Event-Guards (1127 clean) ---------------------------------------
""".lstrip("\n")

def ensure_init_calls_binding(s: str) -> str:
    """
    Sorgt dafuer, dass in IntakeFrame.__init__() nach _bind_shortcuts()
    genau einmal self._ensure_editor_bindings() aufgerufen wird.
    """
    init_pat = r"(class\s+IntakeFrame\s*\([^)]+\)\s*:\s*.*?def\s+__init__\s*\(self,[^\)]*\)\s*:\s*.*?)(\n\s*def\s+|\Z)"
    m = re.search(init_pat, s, flags=re.DOTALL)
    if not m:
        return s
    init_block = m.group(1)
    if re.search(r"\bself\._ensure_editor_bindings\s*\(\s*\)", init_block):
        return s
    new_init = re.sub(
        r"(self\._bind_shortcuts\s*\(\s*\)\s*)",
        r"\1\n        self._ensure_editor_bindings()\n",
        init_block,
        count=1
    )
    if new_init == init_block:
        new_init = init_block + "\n        self._ensure_editor_bindings()\n"
    start, end = m.span(1)
    return s[:start] + new_init + s[end:]

def append_clean_guard_block(s: str) -> str:
    if "Editor-Event-Guards (1127 clean)" in s:
        return s
    return s.rstrip() + "\n\n" + CLEAN_GUARD_BLOCK

def syntax_check(s: str) -> None:
    compile(s, str(MOD), "exec")

def main() -> int:
    print("[R1127] IntakeDetox - Start")
    if not MOD.exists():
        print(f"[R1127] FEHLER: {MOD} nicht gefunden.")
        return 1

    bak = backup()
    src = read_text()
    orig = src

    src = remove_auto_fix_return(src)
    src = strip_old_guard_blocks(src)
    src = append_clean_guard_block(src)
    src = ensure_init_calls_binding(src)

    try:
        syntax_check(src)
    except Exception as ex:
        print("[R1127] SyntaxError nach Patch -> Rollback.")
        log("R1127", f"SyntaxError: {ex!r}")
        shutil.copy2(bak, MOD)
        return 1

    if src != orig:
        write_text(src)
        print("[R1127] Patch angewendet.")
        log("R1127", "Patch angewendet (1127 clean).")
    else:
        print("[R1127] Keine Aenderungen erforderlich.")
        log("R1127", "Keine Aenderungen - bereits sauber.")

    print("[R1127] Fertig.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
