# tools/Runner_1097_FixIntake_Reindent.py
# Repariert fehlerhafte Einrückungen in modules/module_code_intake.py
from __future__ import annotations
import os, re, time, io, sys

ROOT = os.path.abspath(os.path.dirname(__file__))
MOD  = os.path.normpath(os.path.join(ROOT, "..", "modules", "module_code_intake.py"))
ARCH = os.path.normpath(os.path.join(ROOT, "..", "_Archiv"))

METHODS_INTAKE = {
    "_build_ui","_bind_shortcuts","_popup_menu","_update_led","_ping",
    "_prepare_new_intake","_clear_editor_and_fields","_copy_text","_paste_name",
    "_pick_ws","_pick_target","_on_ext_changed","_normalize_ext","_on_name_edited",
    "_guess_name_from_text","_guess_ext_from_text","_apply_ext_to_name","_detect",
    "_on_editor_paste","_on_click_clear_code","_on_click_delete_selected",
    "_run_py","_path_from_selection_or_fields","_after_paste_refresh",
    # ggf. zukünftige:
    "_on_click_guard","_on_click_run","_refresh_file_list",
}

def backup(path: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "rb") as fsrc, open(bak, "wb") as fdst:
        fdst.write(fsrc.read())
    print(f"[R1097] Backup: {path} -> {bak}")

def read_text(path: str) -> str:
    with open(path, "rb") as f:
        b = f.read()
    # CRLF -> LF, Tabs -> 4 Spaces
    src = b.decode("utf-8", errors="replace").replace("\r\n", "\n").replace("\r", "\n")
    src = src.replace("\t", "    ")
    return src

def write_text(path: str, s: str) -> None:
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)

def find_next_toplevel(lines: list[str], start: int) -> int:
    """Erstes nächstes Top-Level-Statement (def/class/# ---) oder Dateiende."""
    pat = re.compile(r"^(def |class |#\s*-{2,}|from |import )")
    i = start
    while i < len(lines):
        if lines[i] and not lines[i].startswith(" "):
            if pat.match(lines[i]):
                break
        i += 1
    return i

def indent_block(lines: list[str], start: int, stop: int, spaces: int = 4) -> None:
    pad = " " * spaces
    for i in range(start, stop):
        if lines[i].strip() == "":
            continue
        lines[i] = pad + lines[i]

def fix_tooltip(lines: list[str]) -> None:
    # class Tooltip: ...  danach def _show/_hide auf Top-Level -> reindenten
    try:
        idx = next(i for i,l in enumerate(lines) if l.startswith("class Tooltip"))
    except StopIteration:
        return
    for name in ("_show","_hide"):
        # def _show(self, ...
        pat = re.compile(rf"^def\s+{name}\s*\(")
        for i in range(idx+1, len(lines)):
            if pat.match(lines[i]):
                j = find_next_toplevel(lines, i+1)
                indent_block(lines, i, j, 4)    # in die Klasse rücken
                break

def fix_intake_methods(lines: list[str]) -> None:
    # Alle bekannten IntakeFrame-Methoden, die fälschlich auf Top-Level stehen, in die Klasse rücken
    try:
        cls = next(i for i,l in enumerate(lines) if l.startswith("class IntakeFrame"))
    except StopIteration:
        return
    # Finde Ende der Klasse heuristisch: nächstes Top-Level 'class ' (nicht zwingend vorhanden)
    end_cls = len(lines)
    for i in range(cls+1, len(lines)):
        if lines[i].startswith("class ") and i != cls:
            end_cls = i
            break
    # Jede Top-Level-Def, die zu METHODS_INTAKE gehört, reindenten
    pat_def = re.compile(r"^def\s+([A-Za-z_][A-Za-z_0-9]*)\s*\(")
    i = cls+1
    while i < end_cls:
        m = pat_def.match(lines[i])
        if m and m.group(1) in METHODS_INTAKE and not lines[i].startswith("    "):
            j = find_next_toplevel(lines, i+1)
            indent_block(lines, i, j, 4)
            # durch das Reindenten verschiebt sich end_cls nicht, da Länge gleich bleibt
            i = j
        else:
            i += 1

def fix_recycle_bin(lines: list[str]) -> None:
    # kompletter Body von def _send_to_recycle_bin(...) soll eingerückt sein
    pat_head = re.compile(r"^def\s+_send_to_recycle_bin\s*\(")
    try:
        i = next(i for i,l in enumerate(lines) if pat_head.match(l))
    except StopIteration:
        return
    j = find_next_toplevel(lines, i+1)
    # Falls innerhalb [i+1:j) Top-Level-Zeilen existieren, rücke gesamten Bereich ein
    need = any(lines[k] and not lines[k].startswith(" ") for k in range(i+1, j))
    if need:
        indent_block(lines, i+1, j, 4)

def sanity_compile(src: str) -> None:
    try:
        compile(src, MOD, "exec")
    except SyntaxError as ex:
        # Zeige Kontext wie Guard
        start = max(0, ex.lineno-5)
        end   = min(len(src.splitlines()), ex.lineno+5)
        print("[R1097] SyntaxError nach Fix:")
        for n, L in enumerate(src.splitlines()[start:end], start+1):
            mark = ">>" if n == ex.lineno else "  "
            print(f"{mark} {n:04d}: {L}")
        raise

def main() -> int:
    if not os.path.exists(MOD):
        print(f"[R1097] Datei nicht gefunden: {MOD}")
        return 1
    backup(MOD)
    src = read_text(MOD)
    lines = src.split("\n")

    fix_tooltip(lines)
    fix_intake_methods(lines)
    fix_recycle_bin(lines)

    new_src = "\n".join(lines).rstrip() + "\n"
    sanity_compile(new_src)
    write_text(MOD, new_src)
    print("[R1097] Einrückungen repariert und Syntax geprüft. OK.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
