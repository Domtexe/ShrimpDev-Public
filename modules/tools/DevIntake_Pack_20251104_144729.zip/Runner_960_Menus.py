# tools/Runner_960_Menus.py
from __future__ import annotations
import re, sys, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MG   = ROOT / "main_gui.py"

MENU_SNIPPET = (
    "m_tools.add_command(label=\"Neues Modul…\", command=self._new_module_dialog)\n"
    "        m_tools.add_command(label=\"Neuer Runner…\", command=self._new_runner_dialog)"
)

METHODS_SNIPPET = r'''
    # --- ShrimpDev: Tools-Aktionen -------------------------------------------------
    from tkinter import simpledialog as _sd, messagebox as _mb
    import re, subprocess
    from pathlib import Path

    def _safe_module_filename(self, raw: str) -> str:
        name = re.sub(r"\W+", "_", (raw or "").strip().lower())
        if not name:
            raise ValueError("Leerer Name")
        if not name.startswith("module_"):
            name = "module_" + name
        if not name.endswith(".py"):
            name += ".py"
        return name

    def _write_if_absent(self, path: Path, content: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            path.write_text(content, encoding="utf-8")

    def _module_template(self, mod_name: str) -> str:
        return f"""# {mod_name}
# erstellt mit ShrimpDev
from __future__ import annotations

def main():
    print("Hello from {mod_name}")

if __name__ == "__main__":
    main()
"""

    def _runner_template(self, runner_name: str) -> str:
        return f"""# tools/{runner_name}
# erstellt mit ShrimpDev
from __future__ import annotations
import sys

def main() -> int:
    print("[{runner_name}] Hello")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
"""

    def _open_in_editor(self, p: Path):
        try:
            subprocess.Popen(["cmd", "/c", "start", "", str(p)], cwd=str(Path(r"D:\\ShrimpDev)"), shell=False)
        except Exception:
            pass

    def _new_module_dialog(self):
        raw = _sd.askstring("Neues Modul", "Name (ohne 'module_' und .py):", parent=self)
        if not raw:
            return
        try:
            fname = self._safe_module_filename(raw)
            target = Path(r"D:\\ShrimpDev") / "modules" / fname
            self._write_if_absent(target, self._module_template(fname))
            try: _mb.showinfo("ShrimpDev", f"Neues Modul erstellt:\n{target}")
            except Exception: pass
            self._open_in_editor(target)
        except Exception as ex:
            try: _mb.showerror("ShrimpDev", f"Fehler beim Erstellen:\n{ex}")
            except Exception: pass

    def _new_runner_dialog(self):
        raw = _sd.askstring("Neuer Runner", "Name (ohne 'Runner_' und .py/.bat):", parent=self)
        if not raw:
            return
        base = re.sub(r"\W+", "_", raw.strip())
        if not base:
            try: _mb.showerror("ShrimpDev", "Ungültiger Name.")
            except Exception: pass
            return
        base = f"Runner_{base}"
        py  = Path(r"D:\\ShrimpDev") / "tools" / f"{base}.py"
        bat = Path(r"D:\\ShrimpDev") / "tools" / f"{base}.bat"
        try:
            self._write_if_absent(py,  self._runner_template(f"{base}.py"))
            bat.write_text(
                f"@echo off\r\ncd /d \"D:\\ShrimpDev\"\r\npy -3 -u tools\\{base}.py\r\n"
                "echo [END ] RC=%errorlevel%\r\npause\r\n",
                encoding="utf-8"
            )
            try: _mb.showinfo("ShrimpDev", f"Neuer Runner erstellt:\n{py}\n{bat}")
            except Exception: pass
            self._open_in_editor(py)
        except Exception as ex:
            try: _mb.showerror("ShrimpDev", f"Fehler beim Erstellen:\n{ex}")
            except Exception: pass
'''

def backup(p: Path) -> Path:
    dst = p.with_suffix(p.suffix + ".bak")
    i = 1
    while dst.exists():
        dst = p.with_suffix(p.suffix + f".{i}.bak")
        i += 1
    dst.write_text(p.read_text(encoding="utf-8", errors="ignore"), encoding="utf-8")
    return dst

def ensure_imports(src: str) -> str:
    need = [
        ("import tkinter as tk", r"(^|\n)import\s+tkinter\s+as\s+tk\b"),
        ("from tkinter import ttk, messagebox", r"(^|\n)from\s+tkinter\s+import\s+ttk,\s*messagebox\b"),
        ("from pathlib import Path", r"(^|\n)from\s+pathlib\s+import\s+Path\b"),
        ("import subprocess", r"(^|\n)import\s+subprocess\b"),
        ("import re", r"(^|\n)import\s+re\b"),
    ]
    out = src
    inserted = []
    for line, pat in need:
        if not re.search(pat, out):
            inserted.append(line)
    if inserted:
        out = "\n".join(inserted) + "\n" + out
    return out

def patch_menu(src: str) -> str:
    # finde _mk_menu(self) und m_tools-Block
    mk = re.search(r"def\s+_mk_menu\s*\(\s*self\s*\)\s*:\s*(?:\n[^\n]*)*", src)
    if not mk:
        return src  # nichts tun – Klasse evtl. anders aufgebaut
    block = mk.group(0)
    if "Neues Modul…" in block and "Neuer Runner…" in block:
        return src  # schon vorhanden

    # versuche nach "m_tools = tk.Menu(" einzuhängen
    new_block = re.sub(
        r"(m_tools\s*=\s*tk\.Menu\(.*\)\s*\n\s*menubar\.add_cascade\(.*?m_tools\)\s*)",
        r"\1        " + MENU_SNIPPET + "\n",
        block,
        count=1,
        flags=re.S,
    )
    if new_block == block:
        # fallback: am Ende der _mk_menu einfügen
        new_block = block + "\n        " + MENU_SNIPPET + "\n"
    return src.replace(block, new_block)

def insert_methods(src: str) -> str:
    if "_new_module_dialog(self)" in src and "_new_runner_dialog(self)" in src:
        return src  # schon vorhanden
    # innerhalb der Klasse ShrimpDevApp einfügen – vor "def _on_exit" oder vor Klassenende
    cls = re.search(r"class\s+ShrimpDevApp\s*\(.*?\)\s*:\s*(?P<body>[\s\S]+?)\n(?=if\s+__name__\s*==\s*[\"']__main__)", src)
    if not cls:
        # Notfall: ganz am Ende der Klasse einsetzen
        cls2 = re.search(r"class\s+ShrimpDevApp\s*\(.*?\)\s*:\s*(?P<body>[\s\S]+)", src)
        if not cls2:
            return src
        start = cls2.start("body")
        end = len(src)
    else:
        start = cls.start("body")
        end   = cls.end("body")
    body = src[start:end]

    if "_new_module_dialog(self)" in body and "_new_runner_dialog(self)" in body:
        return src

    body += METHODS_SNIPPET
    return src[:start] + body + src[end:]

def main() -> int:
    if not MG.exists():
        print(f"[R960] ERROR: {MG} nicht gefunden.")
        return 2
    bak = backup(MG)
    src = MG.read_text(encoding="utf-8", errors="ignore")

    src = ensure_imports(src)
    src = patch_menu(src)
    src = insert_methods(src)

    MG.write_text(src, encoding="utf-8")
    # Syntaxcheck
    try:
        compile(src, str(MG), "exec")
    except Exception as ex:
        print(f"[R960] WARN: Syntaxfehler nach Patch: {ex}")
        print(f"[R960] Backup: {bak}")
        return 1

    print(f"[R960] OK – Menüs & Methoden eingehängt. Backup: {bak.name}")
    print("[R960] Starte GUI zum Test …")
    try:
        subprocess.Popen(["cmd", "/c", "start", "", str(ROOT / "tools" / "start_visible.bat")], cwd=str(ROOT), shell=False)
    except Exception:
        pass
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
