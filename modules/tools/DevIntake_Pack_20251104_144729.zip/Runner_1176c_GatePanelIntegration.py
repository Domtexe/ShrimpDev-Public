# -*- coding: utf-8 -*-
"""
Integriert einen "Dev Gates"-Tab:
- legt modules/module_gate_panel.py an/aktualisiert
- importiert build_gate_panel_tab in main_gui.py
- fügt nb.add(build_gate_panel_tab(...), text="Dev Gates") nach Intake-Mount ein
- Backups + Syntax-Smoke
"""
import os, re, time, py_compile, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
os.makedirs(ARCH, exist_ok=True)

MAIN = os.path.join(ROOT, "main_gui.py")
PANEL = os.path.join(ROOT, "modules", "module_gate_panel.py")
DBG   = os.path.join(ROOT, "debug_output.txt")

def log(msg):
    print(msg)
    try:
        with open(DBG, "a", encoding="utf-8") as f:
            f.write(f"[1176c {time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")
    except Exception:
        pass

def backup(path):
    ts = time.strftime("%Y%m%d_%H%M%S")
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    with open(path, "r", encoding="utf-8") as r, open(dst, "w", encoding="utf-8") as w:
        w.write(r.read())

def write(path, data):
    with open(path, "w", encoding="utf-8") as f:
        f.write(data)

def ensure_panel_module():
    code = r'''# -*- coding: utf-8 -*-
"""
Dev-Gates-Panel: zeigt einfachen Status, Log-Buttons und optional Smoke-Recheck.
Defensiv implementiert: funktioniert auch ohne module_gate_smoke.
"""
import os, tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from pathlib import Path

def _tail_debug(root_dir, n=60):
    p = Path(root_dir) / "debug_output.txt"
    if not p.exists():
        return "(debug_output.txt nicht gefunden)"
    try:
        data = p.read_text(encoding="utf-8", errors="ignore").splitlines()
        return "\n".join(data[-n:])
    except Exception as e:
        return f"(Fehler beim Lesen von debug_output.txt: {e})"

def build_gate_panel_tab(nb, root_dir=None):
    root_dir = root_dir or os.getcwd()
    frame = ttk.Frame(nb)

    # Kopf
    hdr = ttk.Label(frame, text="ShrimpDev – Dev Gates", font=("Segoe UI", 11, "bold"))
    hdr.pack(anchor="w", padx=12, pady=(10,4))

    # Statusbox
    box = tk.Text(frame, height=18, width=120)
    box.configure(state="normal")
    box.insert("1.0", _tail_debug(root_dir, 80))
    box.configure(state="disabled")
    box.pack(fill="both", expand=True, padx=12, pady=(0,8))

    # Buttons
    btn_row = ttk.Frame(frame)
    btn_row.pack(fill="x", padx=12, pady=(0,10))

    def do_refresh():
        box.configure(state="normal")
        box.delete("1.0", "end")
        box.insert("1.0", _tail_debug(root_dir, 80))
        box.configure(state="disabled")

    def do_open_log():
        try:
            import subprocess, sys
            log_path = os.path.join(root_dir, "debug_output.txt")
            if os.name == "nt":
                os.startfile(log_path)
            else:
                subprocess.Popen(["xdg-open", log_path])
        except Exception as e:
            messagebox.showerror("Open Log", str(e))

    def do_reload_intake():
        try:
            from modules.module_shim_intake import _remount_intake_tab_shim, _mount_intake_tab_shim
        except Exception:
            messagebox.showwarning("Reload Intake", "Shim-APIs nicht verfügbar.")
            return
        try:
            _remount_intake_tab_shim(nb)
            messagebox.showinfo("Reload Intake", "Intake-Tab neu geladen.")
        except Exception:
            # Fallback: nur mount versuchen
            try:
                _mount_intake_tab_shim(nb)
                messagebox.showinfo("Reload Intake", "Intake-Tab (Neu) montiert.")
            except Exception as e:
                messagebox.showerror("Reload Intake", str(e))

    ttk.Button(btn_row, text="Refresh Status", command=do_refresh).pack(side="left", padx=(0,8))
    ttk.Button(btn_row, text="Open debug_output.txt", command=do_open_log).pack(side="left", padx=(0,8))
    ttk.Button(btn_row, text="Reload Intake", command=do_reload_intake).pack(side="left", padx=(0,8))

    # Optional: module_gate_smoke quick-check
    try:
        import importlib
        m = importlib.import_module("modules.module_gate_smoke")
        if hasattr(m, "quick_status"):
            st = "\n\n--- quick_status ---\n" + str(m.quick_status())
            box.configure(state="normal"); box.insert("end", st); box.configure(state="disabled")
    except Exception:
        pass

    return frame
'''
    write(PANEL, code)

def patch_main():
    backup(MAIN)
    with open(MAIN, "r", encoding="utf-8") as f:
        src = f.read()

    changed = False

    # 1) Import sicherstellen
    if "from modules.module_gate_panel import build_gate_panel_tab" not in src:
        # Nach Importblock einfügen
        lines = src.splitlines()
        pos = 0
        for i, line in enumerate(lines[:200]):
            if line.strip().startswith(("import ","from ")):
                pos = i + 1
        lines.insert(pos, "from modules.module_gate_panel import build_gate_panel_tab")
        src = "\n".join(lines) + "\n"
        changed = True

    # 2) Notebook-Variable + Intake-Mount finden
    m_nb = re.search(r"^(\s*)([A-Za-z_]\w*)\s*=\s*ttk\.Notebook\s*\(", src, re.M)
    if not m_nb:
        raise RuntimeError("Notebook-Erzeugung (ttk.Notebook) in main_gui.py nicht gefunden.")
    nb_indent = m_nb.group(1)
    nb_var = m_nb.group(2)

    # Stelle nach Intake-Mount suchen
    mount_pattern = r"_mount_intake_tab_shim\s*\(\s*"+re.escape(nb_var)+r"\s*\)"
    m_mount = re.search(mount_pattern, src)
    if not m_mount:
        # Falls Intake noch nicht gemountet ist, füge Dev Gates direkt nach Notebook an (trotzdem funktionsfähig)
        insert_after = m_nb.end()
    else:
        insert_after = src.find("\n", m_mount.end())
        if insert_after == -1:
            insert_after = m_mount.end()

    # Prüfen ob Dev Gates bereits vorhanden
    if re.search(r"build_gate_panel_tab\s*\(", src):
        pass
    else:
        add_line = f"{nb_indent}{nb_var}.add(build_gate_panel_tab({nb_var}, root_dir=os.path.dirname(__file__)), text=\"Dev Gates\")  # injected by 1176c\n"
        src = src[:insert_after+1] + add_line + src[insert_after+1:]
        changed = True

    if changed:
        with open(MAIN, "w", encoding="utf-8") as f:
            f.write(src)

    # Syntax-Smoketest
    py_compile.compile(PANEL, doraise=True)
    py_compile.compile(MAIN, doraise=True)

def main():
    ensure_panel_module()
    patch_main()
    log("GatePanel integriert und Syntax OK.")

if __name__ == "__main__":
    main()
