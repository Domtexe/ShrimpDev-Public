# -*- coding: utf-8 -*-
import io, os, re, time, shutil, py_compile

ROOT = r"D:\ShrimpDev"
TARGET = os.path.join(ROOT, "main_gui.py")
ARCHIV = os.path.join(ROOT, "_Archiv")

def ts(): return str(int(time.time()))
def rd(p): 
    with io.open(p, "r", encoding="utf-8") as f: return f.read()
def wr(p, s):
    with io.open(p, "w", encoding="utf-8", newline="") as f: f.write(s)

def backup(p):
    os.makedirs(ARCHIV, exist_ok=True)
    b = os.path.join(ARCHIV, f"{os.path.basename(p)}.{ts()}.bak")
    shutil.copy2(p, b); print("[1174t] Backup:", b); return b

def ensure_safe_import(src):
    """Erzwingt robusten Import (mit Fallback) gleich nach dem letzten Importblock."""
    # Falls bereits ein robuster Import existiert, nichts tun
    if re.search(r"def\s+_intakeframe_import\(\):", src):
        return src, False
    block = (
        "def _intakeframe_import():\n"
        "    try:\n"
        "        from modules.module_code_intake import IntakeFrame\n"
        "        return IntakeFrame\n"
        "    except Exception:\n"
        "        try:\n"
        "            import modules.module_code_intake as _m\n"
        "            return getattr(_m, 'IntakeFrame')\n"
        "        except Exception as _e:\n"
        "            raise\n"
    )
    # nach Import-Header einfügen
    m = re.search(r"(?s)^(?:from\s+\S+\s+import\s+.*\n|import\s+\S+(?:\s+as\s+\S+)?\n)+", src)
    if m: 
        ins = m.end()
        src = src[:ins] + "\n" + block + "\n" + src[ins:]
    else:
        src = block + "\n" + src
    print("[1174t] Sicherer IntakeFrame-Import-Helper eingefügt.")
    return src, True

def replace_safe_add(src):
    pat = re.compile(r"(?s)\ndef\s+_safe_add_intake_tab\s*\(\s*nb\s*\)\s*:\s*.*?(?=\n\s*def\s+|\Z)")
    body = (
        "def _safe_add_intake_tab(nb):\n"
        "    \"\"\"Mountet Intake direkt; bei Fehler Lazy-Fallback.\n"
        "    \"\"\"\n"
        "    try:\n"
        "        IntakeFrame = _intakeframe_import()\n"
        "        tab = IntakeFrame(nb)\n"
        "        nb.add(tab, text=\"Code Intake\")\n"
        "    except Exception:\n"
        "        import tkinter.ttk as ttk\n"
        "        tab = ttk.Frame(nb)\n"
        "        nb.add(tab, text=\"Code Intake\")\n"
        "        body = ttk.Frame(tab)\n"
        "        body.pack(fill=\"both\", expand=True)\n"
        "        try:\n"
        "            tab.after(120, lambda: _mount_intake_tab_safe(body))\n"
        "        except Exception:\n"
        "            pass\n"
    )
    if pat.search(src):
        src2 = pat.sub("\n"+body+"\n", src, count=1)
        print("[1174t] _safe_add_intake_tab ersetzt.")
        return src2, True
    # Falls komplett fehlt: vor __main__ einfügen
    mm = re.search(r"\nif\s+__name__\s*==\s*['\"]__main__['\"]\s*:\s*\n", src)
    pos = mm.start() if mm else len(src)
    src2 = src[:pos] + "\n"+body+"\n" + src[pos:]
    print("[1174t] _safe_add_intake_tab hinzugefügt.")
    return src2, True

def syntax_ok(path):
    try:
        py_compile.compile(path, doraise=True)
        return True
    except Exception as e:
        print("[1174t] Syntax-Fehler:", e); return False

def main():
    if not os.path.isfile(TARGET):
        print("[1174t] main_gui.py fehlt."); return 2
    bak = backup(TARGET)
    src = rd(TARGET); changed = False
    src, c1 = ensure_safe_import(src); changed |= c1
    src, c2 = replace_safe_add(src); changed |= c2
    if not changed:
        print("[1174t] Keine Änderung nötig."); return 0
    wr(TARGET, src)
    if syntax_ok(TARGET):
        print("[1174t] Patch übernommen, Syntax OK."); return 0
    print("[1174t] ROLLBACK…"); shutil.copy2(bak, TARGET); return 1

if __name__ == "__main__":
    raise SystemExit(main())
