# file: tools/Runner_996_IntakeFix_And_Default.py
# Fix: Intake-Detektion (ersetzt _extract / _detect sicher per callable-re.sub)
#      + GUI: "Code Intake" als Standard-Tab selektieren

from __future__ import annotations
from pathlib import Path
import re

ROOT = Path(r"D:\ShrimpDev")
MOD_INTAKE = ROOT / "modules" / "module_code_intake.py"
MAIN_GUI   = ROOT / "main_gui.py"

EXTRACT_BODY = r'''
def _extract(code: str) -> tuple[str|None, str|None]:
    """
    Liefert (name_ohne_ext, .ext) oder (None, None).
    Marker (# file:, // file:, ; file:, YAML file:, fenced) > Heuristik.
    """
    import re
    from pathlib import Path

    def _split_name(n: str) -> tuple[str, str]:
        n = Path(n).name
        if '.' in n:
            stem, ext = n.rsplit('.', 1)
            return stem, '.' + ext.lower()
        return n, ''

    head = code[:4000]

    # 1) Explizite Marker
    markers = [
        r'(?im)^\s*#\s*file\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        r'(?im)^\s*//\s*file\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        r'(?im)^\s*;\s*file\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        r'(?im)^\s*[-#/* ]*filename\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        r'(?ism)^---\s*\n.*?\nfile\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt)).*?\n---\s*',
        r'(?ism)^[`]{3,}.*?\n(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))[^`]{0,200}?\n[`]{3,}',
        r'(?im)^\s*###\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
    ]
    for rx in markers:
        m = re.search(rx, head)
        if m and m.group('p'):
            stem, ext = _split_name(m.group('p'))
            return (stem, ext or None)

    # 2) Heuristik Endung
    bat_like = any([
        re.search(r'(?im)^\s*@?echo\s+off\b', head),
        re.search(r'(?im)^\s*(?:rem\b|::)', head),
        re.search(r'(?im)\bsetlocal\b|\bendlocal\b|\bgoto\s+\w+|\bif\s+exist\b|\bcall\s+', head),
        re.search(r'(?im)\.(?:bat|cmd)\b', head),
    ])
    py_like = any([
        re.search(r'(?m)^#!.*\bpython[0-9.]*\b', head),
        re.search(r'(?m)^\s*(?:from\s+\w+|import\s+\w+|def\s+\w+\(|class\s+\w+\()', head),
    ])
    ext = None
    if bat_like and not py_like:
        ext = '.bat'
    elif py_like and not bat_like:
        ext = '.py'

    # 3) Namensheuristik
    name = None
    m = re.search(r'(?i)\bRunner_(\d{3,5})[_-]?([A-Za-z0-9]*)', head)
    if m:
        suffix = m.group(2) or 'Script'
        stem = f"Runner_{m.group(1)}{('_' + suffix) if suffix else ''}"
        return stem, (ext or '.bat' if bat_like else ext)

    m = re.search(r'(?i)\bmodule_([A-Za-z0-9_]+)\b', head)
    if m:
        stem = f"module_{m.group(1)}"
        return stem, (ext or '.py')

    return (None, ext)
'''

DETECT_BODY = r'''
def _detect(self, auto: bool=False):
    code = self.txt.get("1.0", "end-1c")
    name, ext = _extract(code)

    # Name OHNE Endung, Endung separat
    if name:
        self.var_name.set(str(name))
    if ext:
        self.var_ext.set(ext)

    ok_name = bool(self.var_name.get().strip())
    ok_ext  = bool(self.var_ext.get().strip())

    if ok_name and ok_ext:
        self._set_led(self.led_detect, "green", "Erkennung OK")
    elif ok_ext:
        self._set_led(self.led_detect, "yellow", "Nur Endung erkannt – Name prüfen")
    else:
        self._set_led(self.led_detect, "red", "Keine sichere Erkennung")

    nm = self.var_name.get().strip()
    ex = self.var_ext.get().strip().lower()
    if nm and ex:
        self.var_target.set(str(_map_target(self.workspace, nm + ex, ex)))

    if not auto:
        self.status.set(f"Erkannt: name={nm or '-'} ext={ex or '-'} → {self.var_target.get() or '-'}")
'''

SET_LED_HELPER = r'''
    def _set_led(self, lbl, color: str, text: str=""):
        try:
            colors = {"green":"#27ae60","yellow":"#e2b93d","red":"#e74c3c","grey":"#808080"}
            lbl.config(background=colors.get(color,"#808080"))
            if text:
                try:
                    self.lbl_detect_text.config(text=text)
                except Exception:
                    pass
        except Exception:
            pass
'''

def patch_with_callable(pattern: str, body: str, src: str) -> tuple[str, bool]:
    m = re.search(pattern, src, flags=re.S)
    if not m:
        return src, False
    start = m.start()
    end   = m.end()
    return src[:start] + body + src[end:], True

def patch_intake():
    if not MOD_INTAKE.exists():
        print("[R996] module_code_intake.py nicht gefunden.")
        return False
    src = MOD_INTAKE.read_text(encoding="utf-8", errors="ignore")
    bak = MOD_INTAKE.with_suffix(".py.r996.bak")
    bak.write_text(src, encoding="utf-8")

    # _extract ersetzen
    p1 = r"def\s+_extract\(\s*code\s*:\s*str\s*\)[\s\S]*?(?=\n\s*def\s+|$)"
    src, ok1 = patch_with_callable(p1, EXTRACT_BODY, src)

    # _detect ersetzen
    p2 = r"def\s+_detect\(\s*self,\s*auto\s*:\s*bool\s*=\s*False\s*\)[\s\S]*?(?=\n\s*def\s+|$)"
    src, ok2 = patch_with_callable(p2, DETECT_BODY, src)

    # _set_led helper ergänzen (falls nicht vorhanden)
    if "_set_led(self, lbl" not in src:
        p_class = r"class\s+IntakeWindow\s*\([^\)]*\)\s*:\s*"
        src, ok3 = patch_with_callable(p_class, lambda: None, src)  # Nur finden
        if ok3:
            # nach der Klasse direkt einfügen
            m = re.search(p_class, src)
            if m:
                insert_at = m.end()
                src = src[:insert_at] + SET_LED_HELPER + src[insert_at:]

    MOD_INTAKE.write_text(src, encoding="utf-8")
    # Syntax prüfen
    compile(src, str(MOD_INTAKE), "exec")
    print("[R996] Intake-Detektor + LED-Logik aktualisiert.")
    return True

def patch_default_tab():
    if not MAIN_GUI.exists():
        print("[R996] main_gui.py nicht gefunden.")
        return False
    src = MAIN_GUI.read_text(encoding="utf-8", errors="ignore")
    bak = MAIN_GUI.with_suffix(".py.r996.bak")
    bak.write_text(src, encoding="utf-8")

    # Wir suchen den Notebook-Add für den Intake-Tab und selektieren ihn danach.
    # Beispiel: self.nb.add(tab_intake, text="Code Intake")
    m = re.search(r"self\.nb\.add\(\s*(?P<tab>\w+)\s*,\s*text\s*=\s*[\"']Code Intake[\"']\s*\)", src)
    if m:
        tabvar = m.group("tab")
        # Prüfen, ob bereits eine select-Zeile folgt
        if not re.search(rf"self\.nb\.select\(\s*{re.escape(tabvar)}\s*\)", src[m.end():m.end()+200]):
            inject = f"\n        # [R996] Intake als Default-Tab\n        self.nb.select({tabvar})\n"
            src = src[:m.end()] + inject + src[m.end():]
            MAIN_GUI.write_text(src, encoding="utf-8")
            print("[R996] Default-Tab auf 'Code Intake' gesetzt.")
            return True

    # Fallback: nach GUI-Init per after_idle letzten Tab mit diesem Titel wählen
    if "Code Intake" in src and "self.nb.select(" not in src:
        add = ("\n        # [R996] Fallback: Intake-Tab als Default wählen\n"
               "        try:\n"
               "            for t in self.nb.tabs():\n"
               "                if self.nb.tab(t, 'text') == 'Code Intake':\n"
               "                    self.after_idle(lambda tt=t: self.nb.select(tt))\n"
               "                    break\n"
               "        except Exception: pass\n")
        # Einfügen am Ende von __init__
        m2 = re.search(r"class\s+\w+\(tk\.Tk\)\s*:\s*.*?def\s+__init__\s*\([\s\S]*?\):", src)
        if m2:
            # nach der ersten Zeile im __init__
            p = re.search(r"def\s+__init__\s*\([\s\S]*?\):\s*\n", src[m2.start():], flags=re.S)
            if p:
                pos = m2.start() + p.end()
                src = src[:pos] + add + src[pos:]
                MAIN_GUI.write_text(src, encoding="utf-8")
                print("[R996] Default-Tab per Fallback gesetzt.")
                return True

    print("[R996] Default-Tab Patch: nichts zu tun (bereits aktiv?).")
    return True

def main():
    ok1 = patch_intake()
    ok2 = patch_default_tab()
    return 0 if (ok1 and ok2) else 1

if __name__ == "__main__":
    raise SystemExit(main())
