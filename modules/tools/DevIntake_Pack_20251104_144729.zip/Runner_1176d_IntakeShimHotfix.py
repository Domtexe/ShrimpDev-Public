# -*- coding: utf-8 -*-
import os, re, io, traceback, datetime, py_compile

ROOT = r"D:\ShrimpDev"
DBG  = os.path.join(ROOT, "debug_output.txt")

def log(msg):
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(DBG, "a", encoding="utf-8") as f:
            f.write(f"[1176d {ts}] {msg}\n")
    except Exception:
        pass
    print(msg)

def write_file(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

def read_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def ensure_gate_smoke():
    path = os.path.join(ROOT, "modules", "module_gate_smoke.py")
    need = True
    if os.path.isfile(path):
        try:
            src = read_file(path)
            if "def smoke_compile" in src and "def gate_try_import" in src:
                need = False
        except Exception:
            pass
    if not need:
        return
    code = r'''# -*- coding: utf-8 -*-
"""
Minimaler Smoke-Gate (nicht-destruktiv).
"""
from __future__ import annotations
import ast, importlib, py_compile, traceback, io, datetime

def _ts():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def _log(msg, dbg_path=r"D:\ShrimpDev\debug_output.txt"):
    try:
        with open(dbg_path, "a", encoding="utf-8") as f:
            f.write(f"[GATE { _ts() }] {msg}\n")
    except Exception:
        print(f"[GATE { _ts() }] {msg}")

def smoke_compile(path: str):
    try:
        with open(path, "r", encoding="utf-8") as f:
            src = f.read()
        ast.parse(src)
        py_compile.compile(path, doraise=True)
        _log(f"SMOKE OK: {path}")
        return True, "OK"
    except Exception as e:
        _log(f"SMOKE FAIL: {path} :: {e}")
        return False, str(e)

def gate_try_import(fullname: str):
    try:
        importlib.invalidate_caches()
        mod = importlib.import_module(fullname)
        _log(f"IMPORT OK: {fullname}")
        return True, mod
    except Exception as e:
        buf = io.StringIO()
        traceback.print_exc(file=buf)
        _log(f"IMPORT FAIL: {fullname}\n{buf.getvalue()}")
        return False, buf.getvalue()
'''
    write_file(path, code)
    log("[1176d] GateSmoke: minimal implementiert/aktualisiert.")

def ensure_shim():
    path = os.path.join(ROOT, "modules", "module_shim_intake.py")
    code = r'''# -*- coding: utf-8 -*-
"""
Shim für den Intake-Tab:
- kapselt Import/Fehlerbehandlung
- sorgt für immer sichtbaren Tab (auch bei Fehlern)
"""
from __future__ import annotations
import traceback, io
from typing import Optional
try:
    import tkinter as tk
    from tkinter import ttk
except Exception:
    # Fallbacks (CLI)
    tk = None
    ttk = None

def _safe_error_frame(parent, message: str) -> "tk.Frame|None":
    if ttk is None:
        return None
    frame = ttk.Frame(parent)
    ttk.Label(frame, text=message, foreground="red").pack(anchor="w", padx=10, pady=10)
    return frame

def mount_intake_tab(nb) -> "tk.Frame|None":
    """
    Erzeugt den Intake-Tab-Frame. Scheitert der Import, wird ein Fehlerframe angezeigt,
    aber der Tab bleibt bestehen.
    """
    if ttk is None:
        return None

    frame = ttk.Frame(nb)
    try:
        # Späte Imports, damit Fehler sauber gefangen werden:
        from modules.module_code_intake import CodeIntakeUI
        ui = CodeIntakeUI(frame)
        ui.build_ui()
        return frame
    except Exception:
        buf = io.StringIO()
        traceback.print_exc(file=buf)
        try:
            with open(r"D:\ShrimpDev\debug_output.txt", "a", encoding="utf-8") as f:
                f.write("[INTAKE_SHIM] Import/Build-Fehler:\\n" + buf.getvalue() + "\\n")
        except Exception:
            pass
        # Fehlerframe statt Crash:
        err = _safe_error_frame(frame, "Fehler beim Import von Intake (module_code_intake). Details in debug_output.txt")
        return err if err is not None else frame
'''
    write_file(path, code)
    log("[1176d] Shim aktualisiert: modules\\module_shim_intake.py")

def patch_main_gui():
    path = os.path.join(ROOT, "main_gui.py")
    src = read_file(path)

    # 1) Sicherstellen, dass der Shim importiert wird
    if "from modules.module_shim_intake import mount_intake_tab" not in src:
        src = re.sub(r"(?m)^from modules[.].*$", r"\g<0>\nfrom modules.module_shim_intake import mount_intake_tab", src, count=1) \
              if "from modules" in src else \
              "from modules.module_shim_intake import mount_intake_tab\n" + src

    # 2) Safe-Helper einfügen (einmalig)
    if "_safe_add_intake_tab" not in src:
        helper = '''
def _safe_add_intake_tab(nb):
    \"\"\"Mountet den Intake-Tab über den Shim und hängt ihn an das Notebook.\"\"\"
    try:
        tab = mount_intake_tab(nb)
    except Exception:
        import traceback, io
        buf = io.StringIO(); traceback.print_exc(file=buf)
        try:
            with open(r"D:\\ShrimpDev\\debug_output.txt","a",encoding="utf-8") as f:
                f.write("[MAIN] _safe_add_intake_tab Exception\\n"+buf.getvalue()+"\\n")
        except Exception:
            pass
        tab = None
    if tab is None:
        from tkinter import ttk
        tab = ttk.Frame(nb)
    nb.add(tab, text="Code Intake")
'''
        # vor __main__ einfügen
        pos = src.rfind("if __name__")
        if pos == -1:
            src += "\n" + helper + "\n"
        else:
            src = src[:pos] + helper + "\n" + src[pos:]

    # 3) Aufruf erzwingen: ersetze alte Varianten zu Notebook-Add
    src = re.sub(r"nb\.add\s*\(\s*tab_intake\s*,\s*text\s*=\s*[\"']Code Intake[\"']\s*\)", "_safe_add_intake_tab(nb)", src)
    src = re.sub(r"nb\.add\s*\(\s*__mount_intake_tab_shim\s*\(\s*nb\s*\)\s*,\s*text\s*=\s*[\"']Code Intake[\"']\s*\)", "_safe_add_intake_tab(nb)", src)
    src = re.sub(r"nb\.add\s*\(\s*__mount_intake_tab\s*\(\s*nb\s*\)\s*,\s*text\s*=\s*[\"']Code Intake[\"']\s*\)", "_safe_add_intake_tab(nb)", src)
    # Falls bisher gar kein Intake-Add existiert, bauen wir ihn direkt vor __main__ ein:
    if "Code Intake" not in src:
        # Suche Notebook-Init
        src = re.sub(r"(nb\s*=\s*ttk\.Notebook\(.*?\)\s*\n)", r"\1    _safe_add_intake_tab(nb)\n", src, count=1, flags=re.S)

    write_file(path, src)
    log("[1176d] main_gui.py gepatcht (Import + _safe_add_intake_tab + Call).")

def smoke():
    ok1 = ok2 = ok3 = True
    try:
        py_compile.compile(os.path.join(ROOT,"main_gui.py"), doraise=True)
    except Exception as e:
        log(f"SMOKE main_gui FAIL: {e}"); ok1=False
    try:
        py_compile.compile(os.path.join(ROOT,"modules","module_shim_intake.py"), doraise=True)
    except Exception as e:
        log(f"SMOKE shim FAIL: {e}"); ok2=False
    try:
        py_compile.compile(os.path.join(ROOT,"modules","module_code_intake.py"), doraise=True)
    except Exception as e:
        log(f"SMOKE intake FAIL: {e}"); ok3=False
    if not (ok1 and ok2 and ok3):
        raise SystemExit(2)

if __name__ == "__main__":
    try:
        ensure_gate_smoke()
        ensure_shim()
        patch_main_gui()
        smoke()
        log("[1176d] Done.")
    except SystemExit as e:
        raise
    except Exception:
        log(traceback.format_exc())
        raise SystemExit(1)
