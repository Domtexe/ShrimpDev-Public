# -*- coding: utf-8 -*-
"""
R1181 – Intake De-Duplicate:
- Patcht module_shim_intake.mount_intake_tab() auf idempotent (find/select).
- Entfernt Mehrfachaufrufe und alte Fallbacks in main_gui.py.
- Backups nach _Archiv, Syntax-Check, Log.
"""
from __future__ import annotations
import os, re, time, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")
MAIN = os.path.join(ROOT, "main_gui.py")
SHIM = os.path.join(ROOT, "modules", "module_shim_intake.py")

def log(msg: str) -> None:
    try:
        with open(LOG, "a", encoding="utf-8", newline="\n") as f:
            f.write(f"[R1181] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    except Exception:
        pass
    print(f"[R1181] {msg}")

def backup(path: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    base  = path.replace(ROOT+os.sep, "").replace(os.sep, "_")
    dst   = os.path.join(ARCH, f"{base}.{stamp}.bak")
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        data = f.read()
    with open(dst, "w", encoding="utf-8") as f:
        f.write(data)
    log(f"Backup: {dst}")

def patch_shim() -> None:
    if not os.path.isfile(SHIM):
        log("module_shim_intake.py nicht gefunden.")
        return
    src = open(SHIM, "r", encoding="utf-8", errors="replace").read()
    orig = src

    # Kern: idempotenter Mount – wenn Tab "Intake" existiert: select, sonst create_intake_tab()
    IDP = r'''
def mount_intake_tab(nb):
    """
    Idempotenter Mount:
    - Falls Tab 'Intake' bereits existiert -> nur auswählen.
    - Sonst über module_code_intake.create_intake_tab(nb) anlegen.
    """
    try:
        from tkinter import ttk
        # 1) Bereits vorhandenen Tab finden
        try:
            for i, tid in enumerate(nb.tabs()):
                try:
                    if nb.tab(tid, "text") == "Intake":
                        nb.select(i)
                        return True
                except Exception:
                    pass
        except Exception:
            pass
        # 2) Neu anlegen
        from modules import module_code_intake as dev_intake
        dev_intake.create_intake_tab(nb)
        # Nach Anlage erneut selektieren
        try:
            for i, tid in enumerate(nb.tabs()):
                if nb.tab(tid, "text") == "Intake":
                    nb.select(i)
                    break
        except Exception:
            pass
        return True
    except Exception:
        # keine Exception nach oben lassen
        try:
            import traceback, os, time
            root = os.path.abspath(os.path.dirname(__file__))
            logf = os.path.join(os.path.dirname(root), "debug_output.txt")
            with open(logf, "a", encoding="utf-8") as f:
                f.write("[Shim] Intake mount failed:\\n")
                traceback.print_exc(file=f)
        except Exception:
            pass
        return False

# Backward-Compat Aliases
def _mount_intake_tab_shim(nb):  # alt
    return mount_intake_tab(nb)

def _remount_intake_tab_shim(nb):  # alt
    return mount_intake_tab(nb)
'''.lstrip("\n")

    # Ersetze existierende mount_* Implementierung(en)
    if re.search(r"\ndef\s+mount_intake_tab\s*\(", src):
        src = re.sub(r"\ndef\s+mount_intake_tab\s*\([\s\S]*?\n(?=def\s+|$)", "\n"+IDP, src, count=1)
    else:
        # kein mount vorhanden -> hinzufügen am Ende
        src = src.rstrip() + "\n\n" + IDP

    if src != orig:
        backup(SHIM)
        open(SHIM, "w", encoding="utf-8").write(src)
        log("Shim patched (idempotent mount).")
    else:
        log("Shim: keine Änderungen nötig.")

    # Syntaxprobe
    compile(open(SHIM, "r", encoding="utf-8").read(), "module_shim_intake.py", "exec")

def patch_main() -> None:
    if not os.path.isfile(MAIN):
        log("main_gui.py nicht gefunden.")
        return
    src = open(MAIN, "r", encoding="utf-8", errors="replace").read()
    orig = src

    # 1) Sicherstellen, dass _safe_add_intake_tab(nb) nur EINMAL nach Notebook-Erstellung steht
    #    -> Entferne Mehrfachaufrufe
    src = re.sub(r"\n\s*_safe_add_intake_tab\s*\(\s*nb\s*\)\s*(#.*)?", "", src)
    # füge genau einen Aufruf unmittelbar nach der Notebook-Erzeugung ein
    src = re.sub(
        r"(nb\s*=\s*ttk\.Notebook\(root\)[^\n]*\n)",
        r"\1    _safe_add_intake_tab(nb)\n",
        src,
        count=1
    )

    # 2) Entferne alte harte Fallback-Anlage eines „Intake“-Tabs (rote Fehlermeldung)
    #    -> Pattern: ttk.Frame + Label("Intake – Fehler ...") + nb.add(..., text="Intake")
    src = re.sub(
        r"\n\s*#?\s*sichtbare Fehlermeldung.*?(?=\n\s*\w|\Z)",
        "\n",
        src,
        flags=re.DOTALL
    )
    src = re.sub(
        r"\n\s*f\s*=\s*ttk\.Frame\(nb\)[\s\S]*?nb\.add\(\s*f\s*,\s*text\s*=\s*[\"']Intake[\"']\s*\)\s*",
        "\n",
        src
    )

    if src != orig:
        backup(MAIN)
        open(MAIN, "w", encoding="utf-8").write(src)
        log("main_gui.py patched (single safe mount, removed fallback).")
    else:
        log("main_gui.py: keine Änderungen nötig.")

    # Syntaxprobe
    compile(open(MAIN, "r", encoding="utf-8").read(), "main_gui.py", "exec")

def main() -> int:
    try:
        patch_shim()
        patch_main()
        return 0
    except Exception as e:
        log(f"Runner-Error: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
