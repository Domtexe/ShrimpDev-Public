# -*- coding: utf-8 -*-
"""
Runner_1131_FixIntakeToolbar
Repariert zwei blockierende Fehler im Toolbar-/Bindings-Bereich von module_code_intake.py:
  1) btn_guard-Container: self.frm_actions -> bar
  2) "try:"-Doppelung ohne except im Bindings-Block -> sauberes try/except
Idempotent, mit Backup und Syntax-Check. Rollback bei Fehler.
"""
from __future__ import annotations
import re, time, shutil, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"; ARCH.mkdir(exist_ok=True)
REPO = ROOT / "_Reports"; REPO.mkdir(exist_ok=True)
REPORT = REPO / "Runner_1131_FixIntakeToolbar_report.txt"

def rep(msg: str) -> None:
    with REPORT.open("a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip()+"\n")

def patch_toolbar(src: str) -> tuple[str,int]:
    changes = 0

    # (1) Guard-Button in 'bar' statt 'self.frm_actions'
    pat_btn = r'''(self\.btn_guard\s*=\s*ttk\.Button\()\s*self\.frm_actions(\s*,\s*text=.*?command=.*?\))'''
    new_src, n = re.subn(pat_btn, r"\1bar\2", src, flags=re.DOTALL)
    if n: changes += n
    src = new_src

    # (2) Doppel-try: nach einem try: folgen Bindings, danach fälschlich wieder "try:\n pass\n except Exception:\n pass"
    # -> Ersetze die zweite "try:"-Sequenz durch ein korrektes "except Exception:\n    pass"
    pat_try = (
        r'(\n[ \t]*try:\n'                                   # erster try:
        r'(?:[ \t]*self\.btn_detect\.bind[^\n]*\n)'          # bind 1
        r'(?:[ \t]*self\.btn_save\.bind[^\n]*\n)'            # bind 2
        r'(?:[ \t]*self\.btn_del\.bind[^\n]*\n))'            # bind 3
        r'[ \t]*try:\n[ \t]*pass\n[ \t]*except[^\n]*\n[ \t]*pass'
    )
    def _fix(m):
        prefix = m.group(1)
        return f"{prefix}        except Exception:\n            pass"
    new_src, n = re.subn(pat_try, _fix, src)
    if n: changes += n
    src = new_src

    return src, changes

def main() -> int:
    with REPORT.open("w", encoding="utf-8", newline="\n") as f:
        f.write("Runner_1131_FixIntakeToolbar – Start\n")

    if not MOD.exists():
        rep(f"[FEHLER] Datei fehlt: {MOD}")
        return 2

    original = MOD.read_text(encoding="utf-8", errors="ignore")
    backup = ARCH / f"module_code_intake.py.{int(time.time())}.bak"
    shutil.copy2(MOD, backup)
    rep(f"[Backup] {MOD} -> {backup}")

    try:
        patched, changes = patch_toolbar(original)
        if changes == 0:
            rep("[Info] Keine relevanten Stellen gefunden – nichts geändert.")
            return 0

        # Syntax-Test
        compile(patched, str(MOD), "exec")

        MOD.write_text(patched, encoding="utf-8", newline="\n")
        rep(f"[OK] Patch angewendet. Änderungen: {changes}")
        return 0
    except Exception as ex:
        rep("[FEHLER] Patch fehlgeschlagen – Rollback.")
        rep("TRACE:\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        MOD.write_text(original, encoding="utf-8", newline="\n")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
