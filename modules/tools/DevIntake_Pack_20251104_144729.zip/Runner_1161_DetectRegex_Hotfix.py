# -*- coding: utf-8 -*-
"""
Runner_1161_DetectRegex_Hotfix
- Safe-only Patch gegen 'DetectWarn: missing ), unterminated subpattern at position 61'
- Patcht NUR exakt bekannte Fragmente in modules/module_code_intake.py:
  1) r"(?im)^[;#:\ -]+\s*name\s*[:=]\s*...Runner_"  ->  r"(?im)^[;#:\-\s]+\s*name\s*[:=]\s*(Runner_"
     (Entfernt '...', balanciert Klammern, normiert Zeichenklasse)
  2) "[^\\-]]" (und Varianten mit einfachem Backslash) -> "[^\\]]"
- Kein Patch, wenn die Muster nicht gefunden werden.
- Safety: Backup -> _Archiv/, Syntax-Check via py_compile, automatischer Rollback bei Fehler.
"""
from __future__ import annotations
import os, io, re, time, shutil, py_compile, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOGF = os.path.join(ROOT, "debug_output.txt")

FULL_OK_NAME_REGEX = r"(?im)^[;#:\-\s]+\s*name\s*[:=]\s*(Runner_[0-9]{3,5}[_A-Za-z0-9\-]+)(?:\.(py|bat|cmd))?\s*$"

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1161] {ts} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, dst)
    log(f"Backup: {path} -> {dst}")
    return dst

def patch_text(src: str) -> tuple[str, list[str]]:
    changes: list[str] = []
    new = src

    # 1) Name-Regex: exakt das kaputte Fragment mit Ellipse '...' fixen.
    #    Wir patchen NUR String-Literale, daher arbeiten wir auf der escaped-Form, wie sie im Source steht.
    #    Ziel: Zeichenklasse normieren ([;#:\-\s]) und Gruppe balancieren ( (Runner_ ... ) )
    targets = [
        r"(?im)\^\[;#:\\ \-\]\+\\s\*name\\s\*[:=]\\s\*\.{3}Runner_",          # Variante mit Space in der Klasse
        r"(?im)\^\[;#:\\ \-\]\+\\s\*name\\s\*[:=]\\s\*\.{3}\s*Runner_",      # evtl. Space vor Runner_
        r"(?im)\^\[;#:\\-\]\+\\s\*name\\s\*[:=]\\s\*\.{3}Runner_",            # ohne Space
    ]
    replaced_any = False
    for t in targets:
        if t in new:
            new = new.replace(t, r"(?im)^[;#:\-\s]+\s*name\s*[:=]\s*(Runner_")
            replaced_any = True
    if replaced_any:
        changes.append("Fixed name-detect regex prefix ('...Runner_' + class/paren)")

    # 2) Character-Class Bug: [^\\-]]  -> [^\\]]
    #    Wir ersetzen vorsichtig die beiden häufigsten Schreibweisen
    if r"[^\-]]" in new:
        new = new.replace(r"[^\-]]", r"[^\]]")
        changes.append("Fixed char class '[^\\-]]' -> '[^\\]]'")
    if r"[^\\-]]" in new:
        new = new.replace(r"[^\\-]]", r"[^\]]")
        if "Fixed char class '[^\\-]]' -> '[^\\]]'" not in changes:
            changes.append("Fixed char class '[^\\\\-]]' -> '[^\\]]'")

    # 3) OPTIONAL (non-destructive): Falls der Name-Regex rumpfig formatiert ist,
    #    ersetzen wir eine sehr typische alte Gesamtkonstruktion durch den sauberen FULL_OK_NAME_REGEX.
    #    Nur anwenden, wenn ein klar erkennbares, unbalanciertes Restmuster existiert.
    #    Beispiel-Trigger: 'name\\s*[:=]\\s*Runner_' ohne öffnende Klammer vor Runner_ UND gefolgt von '(?:\.(py|bat|cmd))?'
    rough_pat = re.compile(
        r"(?:\(\?im\))?\^\[;#:\\\-\s\]\+\\s\*name\\s\*[:=]\\s*Runner_[^\n\"']+?\(\?:\\\.\(py\|bat\|cmd\)\)\?\s*\$\s*"
    )
    def _full_replace(m: re.Match) -> str:
        changes.append("Rewrote full name-detect regex to safe canonical form")
        return FULL_OK_NAME_REGEX
    new, n_full = rough_pat.subn(_full_replace, new)
    if n_full == 0:
        # nichts
        pass

    return new, changes

def main() -> int:
    try:
        if not os.path.isfile(MOD):
            log(f"[ERR] Not found: {MOD}")
            return 2

        with io.open(MOD, "r", encoding="utf-8") as f:
            src = f.read()

        bak = backup(MOD)
        new, changes = patch_text(src)

        if not changes:
            log("No changes applied (patterns not found) – leaving file untouched.")
        else:
            with io.open(MOD, "w", encoding="utf-8", newline="\n") as f:
                f.write(new)
            for c in changes:
                log(f"Change: {c}")

        # Syntax-Check
        try:
            py_compile.compile(MOD, doraise=True)
            log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}")
            shutil.copy2(bak, MOD)
            log("Restored from backup due to syntax error.")
            return 3

        log("R1161 completed successfully.")
        return 0

    except Exception as e:
        tb = traceback.format_exc()
        log(f"[EXC] {e}\n{tb}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
