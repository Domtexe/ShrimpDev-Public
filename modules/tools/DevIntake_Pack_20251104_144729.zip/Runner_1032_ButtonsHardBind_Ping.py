"""
Runner_1032_ButtonsHardBind_Ping
- Verdrahtet Intake-Buttons doppelt: command + <ButtonRelease-1>-Bind
- Fügt sichtbares Ping-Label hinzu (zeigt letzte Aktion)
- Wrapper (_on_click_detect/_save/_delete) nutzen Ping + Log + bell()
- Version -> v9.9.22
"""
from __future__ import annotations
import os, re, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1032] {ts} {msg}\n")
    except Exception:
        pass
    print(msg)

def patch():
    with open(MOD, "r", encoding="utf-8") as f:
        src = f.read()

    changed = False

    # 1) Sicherstellen: Wrapper-Methoden vorhanden; mit Ping UI
    if "def _ping(" not in src:
        insert_pt = src.find("\n    # ---------- actions ----------")
        ping_block = r'''
    # --- UI ping / status ---
    def _ping(self, text: str):
        try:
            self.lbl_ping.configure(text=text)
        except Exception:
            pass
        try:
            self.bell()
        except Exception:
            pass
'''
        src = src[:insert_pt] + ping_block + src[insert_pt:]
        changed = True

    if "def _on_click_detect(" not in src or "def _on_click_save(" not in src or "def _on_click_delete(" not in src:
        wrapper_block = r'''
    # --- button wrappers with ping & logging ---
    def _on_click_detect(self):
        ts = time.strftime("%H:%M:%S")
        self._ping(f"Erkennen gedrückt ({ts})")
        try:
            from modules.snippets.logger_snippet import write_log as _wl
        except Exception:
            def _wl(p,m): pass
        _wl("INTAKE","BTN Detect click")
        try:
            return self._detect()
        except Exception as ex:
            from tkinter import messagebox
            messagebox.showerror("Fehler", f"Erkennen fehlgeschlagen:\n{ex}")

    def _on_click_save(self):
        ts = time.strftime("%H:%M:%S")
        self._ping(f"Speichern gedrückt ({ts})")
        try:
            from modules.snippets.logger_snippet import write_log as _wl
        except Exception:
            def _wl(p,m): pass
        _wl("INTAKE","BTN Save click")
        try:
            self._save()
        except Exception as ex:
            from tkinter import messagebox
            messagebox.showerror("Fehler", f"Speichern fehlgeschlagen:\n{ex}")

    def _on_click_delete(self):
        ts = time.strftime("%H:%M:%S")
        self._ping(f"Löschen gedrückt ({ts})")
        try:
            from modules.snippets.logger_snippet import write_log as _wl
        except Exception:
            def _wl(p,m): pass
        _wl("INTAKE","BTN Delete click")
        try:
            self._delete_selected()
        except Exception as ex:
            from tkinter import messagebox
            messagebox.showerror("Fehler", f"Löschen fehlgeschlagen:\n{ex}")
'''
        # Vor Actions einfügen
        ins = src.find("\n    # ---------- actions ----------")
        src = src[:ins] + wrapper_block + src[ins:]
        changed = True

    # 2) Toolbar-Block: Buttons doppelt anbinden + Ping-Label
    toolbar_pattern = re.compile(
        r"\n\s*#\s*Toolbar[\s\S]+?body\s*=\s*ttk\.Panedwindow",
        re.MULTILINE,
    )
    toolbar_block = r'''
        # Toolbar (hard bind + ping)
        bar = ttk.Frame(self)
        bar.grid(row=2, column=0, sticky="ew", padx=_PADX, pady=(0,4))
        for c in (0,1,2,3): bar.columnconfigure(c, weight=0)
        bar.columnconfigure(4, weight=1)

        self.btn_detect = ttk.Button(bar, text="Erkennen (Ctrl+I)", command=self._on_click_detect)
        self.btn_save   = ttk.Button(bar, text="Speichern (Ctrl+S)", command=self._on_click_save)
        self.btn_del    = ttk.Button(bar, text="Löschen (Entf)",    command=self._on_click_delete)
        self.btn_detect.grid(row=0, column=0, padx=(0,6), sticky="w")
        self.btn_save.grid(  row=0, column=1, padx=(0,6), sticky="w")
        self.btn_del.grid(   row=0, column=2, padx=(0,6), sticky="w")

        # Doppelte Bindung: zusätzlich MouseUp -> Wrapper
        try:
            self.btn_detect.bind("<ButtonRelease-1>", lambda e: self._on_click_detect())
            self.btn_save.bind(  "<ButtonRelease-1>", lambda e: self._on_click_save())
            self.btn_del.bind(   "<ButtonRelease-1>", lambda e: self._on_click_delete())
        except Exception:
            pass

        # Ping-Label (rechts, dezent)
        self.lbl_ping = ttk.Label(bar, text="", anchor="w")
        self.lbl_ping.grid(row=0, column=3, padx=(12,0), sticky="w")
        ttk.Label(bar, text="").grid(row=0, column=4, sticky="ew")  # spacer

        try:
            Tooltip(self.btn_detect, "Erkennt Endung aus dem Namensfeld (respektiert manuelle Eingabe)")
            Tooltip(self.btn_save,   "Speichert den Editor-Inhalt in Zielordner/Name+Endung")
            Tooltip(self.btn_del,    "Löscht die markierte Datei (oder nur aus der Liste)")
        except Exception:
            pass

        body = ttk.Panedwindow
'''
    src2 = toolbar_pattern.sub("\n" + toolbar_block, src)
    if src2 != src:
        src = src2
        changed = True

    # 3) Shortcuts -> Wrapper
    src2 = re.sub(
        r"def\s+_bind_shortcuts\s*\([\s\S]+?^\s*def\s+_popup_menu",
        r'''
    def _bind_shortcuts(self):
        root = self.winfo_toplevel()
        try:
            root.unbind_all("<Control-s>")
            root.unbind_all("<Control-i>")
        except Exception:
            pass
        root.bind_all("<Control-s>", lambda e: self._on_click_save())
        root.bind_all("<Control-i>", lambda e: self._on_click_detect())
        self.tbl.bind("<Control-c>", lambda e: self._copy_selected())
        self.tbl.bind("<Delete>",    lambda e: self._on_click_delete())

    def _popup_menu''',
        src,
        flags=re.MULTILINE
    )
    if src2 != src:
        src = src2
        changed = True

    if not changed:
        log("Keine Änderungen nötig – Buttons sind bereits hart verdrahtet.")
        return 0

    # Backup & schreiben
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"module_code_intake.py.{int(time.time())}.bak")
    shutil.copy2(MOD, bck)
    with open(MOD, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(src)
    log(f"Backup: {MOD} -> {bck}")
    log("Buttons doppelt angebunden, Ping-Label hinzugefügt.")

    # Meta
    with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
        f.write("ShrimpDev v9.9.22\n")
    with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
        f.write("""
## v9.9.22 (2025-10-18)
- Intake: Buttons hart verdrahtet (command + MouseUp), Ping-Label, Wrapper mit Log+bell
""")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(patch())
    except Exception:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write("[R1032] FEHLER:\n" + traceback.format_exc() + "\n")
        print("FEHLER:\n" + traceback.format_exc())
        raise
