# -*- coding: utf-8 -*-
"""
R1166f Intake DeepRepair  (Mastermodus: nur _build_ui() analysieren und reparieren)
Ziele (minimal, idempotent, einrückungssicher):
  1) In _build_ui(): 'global ttk' entfernen.
  2) In _build_ui(): lokale 'import tkinter.ttk as ttk' / 'ttk = None' Blöcke entfernen.
  3) Nach 'bar = ttk.Frame(self)' Aliase setzen (falls fehlen): self.toolbar = bar; self.frm_actions = bar.
  4) Den fehlerhaften helpers-Block korrigieren:
       '# ---------- helpers ----------'
         (zu tief eingerückter) 'self._intake_post_build_bind_clear()'
     -> dedent & an das FUNKTIONSENDE verschieben (Basisindent + 4 Spaces), einmalig.
  5) Backup -> _Archiv, Syntax-Check, Rollback on error.
  6) Master-Regeln-Addendum schreiben/aktualisieren.

Hinweis: Keine großflächigen Block-Rewrites, nur gezielte Reparaturen innerhalb _build_ui().
"""
from __future__ import annotations
import io, re, time, shutil, py_compile, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
DOCS = ROOT / "docs"
RULE = DOCS / "MASTERREGELN_ADDENDUM_2025-10-23.md"
LOGF = ROOT / "debug_output.txt"

ADDENDUM = """# Masterregeln – Addendum (2025-10-23)

## 1.4 GUI-Imports (verbindlich)
- GUI-Toolkit-Imports (`tkinter`, `ttk`, `messagebox`, `filedialog`) ausschließlich im **Modulkopf**.
- In Funktionen/Methoden **keine** lokalen Re-Imports/Zuweisungen dieser Namen (verhindert Shadowing/UnboundLocalError).

## 1.5 Toolbar-Referenzen (verbindlich)
- Der Toolbar-Container wird zentral referenziert: `self.toolbar = bar`.
- Legacy-Attribute (z. B. `self.frm_actions`) dürfen als **Alias** auf **dieselbe Instanz** gesetzt werden.

## 12.4 Patch-Sorgfalt & Einrückungen (NEU)
- Patches sind **einrückungssicher**: Einrückung aus dem Quelltext übernehmen (Tabs/Spaces unverändert).
- Minimalprinzip: Nur notwendige Zeilen ändern; keine blinden Regex-Massenersetzungen.
- Idempotenz: Mehrfachausführung darf keine Doppel-Injektionen erzeugen.
"""

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1166f] {ts} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f: f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(p: Path) -> Path:
    ARCH.mkdir(parents=True, exist_ok=True)
    dst = ARCH / f"{p.name}.{int(time.time())}.bak"
    shutil.copy2(p, dst)
    log(f"Backup: {p} -> {dst}")
    return dst

def _find_block(src: str, pat: str, start: int=0) -> tuple[int, int, re.Match|None]:
    """finde Funktionsblock: Beginn (inkl. Zeile mit def), Ende (vor nächstem def), Match auf def-Zeile"""
    m = re.search(pat, src[start:], re.M)
    if not m: return -1, -1, None
    abs_def = start + m.start()
    abs_eol = start + m.end()
    m_next = re.search(r"^\s*def\s+\w+\s*\(", src[abs_eol:], re.M)
    end = abs_eol + (m_next.start() if m_next else len(src) - abs_eol)
    return abs_eol, end, m  # wir liefern den Blockbereich NACH der def-Zeile

def _remove_global_ttk(block: str) -> tuple[str, bool]:
    new = re.sub(r"^\s*global\s+ttk\s*\r?\n", "", block, flags=re.M)
    return new, new != block

def _remove_local_ttk_imports(block: str) -> tuple[str, bool]:
    changed = False
    # Entferne 'import tkinter.ttk as ttk' innerhalb _build_ui
    new = re.sub(r"^\s*import\s+tkinter\.ttk\s+as\s+ttk\s*\r?\n", "", block, flags=re.M)
    if new != block:
        changed = True
        block = new
    # Entferne 'ttk = None' o.ä. Sicherheitszweige
    new = re.sub(r"^\s*ttk\s*=\s*None\s*\r?\n", "", block, flags=re.M)
    if new != block:
        changed = True
        block = new
    return block, changed

def _ensure_toolbar_aliases(block: str) -> tuple[str, bool]:
    """nach 'bar = ttk.Frame(self)' self.toolbar/self.frm_actions setzen (idempotent, gleiche Einrückung)"""
    m = re.search(r"^(\s*)bar\s*=\s*ttk\.Frame\(\s*self\s*\)\s*$", block, re.M)
    if not m: return block, False
    indent = m.group(1)
    pos = m.end()
    tail = block[pos:pos+400]
    lines = []
    if "self.toolbar = bar" not in tail:
        lines.append(f"{indent}self.toolbar = bar  # R1166f")
    if "self.frm_actions = bar" not in tail:
        lines.append(f"{indent}self.frm_actions = bar  # R1166f (compat)")
    if not lines:
        return block, False
    inject = "\n" + "\n".join(lines) + "\n"
    return block[:pos] + inject + block[pos:], True

def _fix_helpers(block: str, func_indent: str) -> tuple[str, bool]:
    """
    Problemstelle:
        # ---------- helpers ----------
            self._intake_post_build_bind_clear()
    -> den gesamten Bereich entfernen und EINEN Aufruf am Funktionsende (func_indent + 4) einsetzen.
    """
    changed = False
    # Entferne die fehlerhafte Kombination Kommentar + (zu tief) Aufruf
    pattern = re.compile(
        r"^\s*#\s*-{2,}\s*helpers\s*-{2,}\s*$"
        r"(?:\s*^\s*#.*$)?"
        r"\s*^\s*self\._intake_post_build_bind_clear\(\)\s*$",
        re.M
    )
    new = re.sub(pattern, "", block)
    if new != block:
        changed = True
        block = new

    # Sauberer Aufruf am Funktionsende (einmalig)
    call_line = f"{func_indent}    self._intake_post_build_bind_clear()\n"
    if "self._intake_post_build_bind_clear()" not in block:
        block = block.rstrip() + "\n\n" + call_line
        changed = True
    return block, changed

def write_rules():
    DOCS.mkdir(parents=True, exist_ok=True)
    RULE.write_text(ADDENDUM, encoding="utf-8")

def main() -> int:
    try:
        if not MOD.exists():
            log(f"[ERR] Not found: {MOD}"); return 2

        src = MOD.read_text(encoding="utf-8")
        bak = backup(MOD)

        # 1) _build_ui finden (Blockgrenzen)
        block_start, block_end, m_def = _find_block(src, r"^(\s*)def\s+_build_ui\s*\(\s*self[^\)]*\)\s*:\s*$")
        if block_start == -1:
            log("[ERR] _build_ui() not found.")
            return 2
        func_indent = m_def.group(1)
        block = src[block_start:block_end]

        # 2) Reparaturen
        any_change = False

        block, ch = _remove_global_ttk(block);                any_change |= ch and log("Change: removed 'global ttk'") is None
        block, ch = _remove_local_ttk_imports(block);         any_change |= ch and log("Change: removed local ttk-imports/assignments") is None
        block, ch = _ensure_toolbar_aliases(block);           any_change |= ch and log("Change: ensured toolbar aliases (toolbar/frm_actions)") is None
        block, ch = _fix_helpers(block, func_indent);         any_change |= ch and log("Change: fixed misplaced helpers-call") is None

        if not any_change:
            log("No changes applied (already healthy).")
            return 0

        # 3) Zusammenbauen und schreiben
        new_src = src[:block_start] + block + src[block_end:]
        MOD.write_text(new_src, encoding="utf-8", newline="\n")

        # 4) Syntax-Check
        try:
            py_compile.compile(str(MOD), doraise=True)
            log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}")
            shutil.copy2(bak, MOD)
            log("Restored from backup.")
            return 3

        # 5) Regeln schreiben
        try:
            write_rules(); log(f"Wrote rules addendum: {RULE}")
        except Exception as ex:
            log(f"[WARN] Could not write rules addendum: {ex}")

        log("R1166f completed successfully.")
        return 0

    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
