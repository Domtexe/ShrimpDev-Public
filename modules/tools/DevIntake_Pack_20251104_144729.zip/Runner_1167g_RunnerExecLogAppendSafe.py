# -*- coding: utf-8 -*-
"""
Runner_1167g_RunnerExecLogAppendSafe
Hängt am Ende von modules/module_runner_exec.py eine robuste _log()-Neudefinition an,
ohne die bestehende Funktion per Regex zu verändern (kein Risiko).
- Idempotent (Markerprüfung)
- Backup + Syntax-Check + Rollback
Exitcodes: 0 OK, 1 Fehler
"""
from __future__ import annotations
import os, time, py_compile, traceback

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_runner_exec.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOG    = os.path.join(ROOT, "debug_output.txt")
MARK   = "# R1167g: safe _log wrapper (append, no-replace)"

APPEND_BLOCK = f"""

{MARK}
# Diese Neudefinition überschreibt die vorherige _log()-Funktion sicher.
def _log(msg: str) -> None:  # noqa: F811 (absichtliche Neudefinition)
    try:
        # Sicherstellen, dass LOGFILE-Verzeichnis existiert, Fehler still tolerieren
        try:
            os.makedirs(os.path.dirname(LOGFILE), exist_ok=True)
        except Exception:
            pass
        # Best-effort schreiben; Import im GUI darf niemals crashen
        try:
            with open(LOGFILE, "a", encoding="utf-8", newline="") as f:
                f.write((msg or "").rstrip() + "\\n")
        except Exception:
            pass
    except Exception:
        pass
"""

def _log_local(s: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1167g {ts}] {s}\n"
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def _backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    ts = int(time.time())
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    with open(path, "r", encoding="utf-8") as fi, open(dst, "w", encoding="utf-8", newline="") as fo:
        fo.write(fi.read())
    return dst

def main() -> int:
    try:
        if not os.path.exists(TARGET):
            _log_local(f"Zieldatei fehlt: {TARGET}")
            return 1

        with open(TARGET, "r", encoding="utf-8") as f:
            src = f.read()

        if MARK in src:
            _log_local("Patch bereits vorhanden – keine Änderung notwendig.")
            return 0

        bak = _backup(TARGET)
        _log_local(f"Backup erstellt: {bak}")

        with open(TARGET, "a", encoding="utf-8", newline="") as f:
            f.write(APPEND_BLOCK)

        try:
            py_compile.compile(TARGET, doraise=True)
        except Exception as e:
            # Rollback
            with open(bak, "r", encoding="utf-8") as fi, open(TARGET, "w", encoding="utf-8", newline="") as fo:
                fo.write(fi.read())
            _log_local("Syntax-Check FEHLER -> Rollback auf Backup.")
            _log_local("Traceback:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 1

        _log_local("Append erfolgreich, Syntax-Check OK.")
        return 0

    except Exception as e:
        _log_local("UNERWARTETER FEHLER:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
