# -*- coding: utf-8 -*-
"""
Runner_1171p_IntakeIndentHeal.py
Ziel: Unerwartete Einrückungen & verwaiste try/except-Artefakte in modules/module_code_intake.py heilen.
Sicher, idempotent, mit Backup + Syntax-Check + Rollback.
"""
import io, os, re, sys, time, shutil, py_compile
from datetime import datetime
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def _log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1171p {ts}] {msg}"
    print(line)
    try:
        with io.open(LOG, "a", encoding="utf-8") as f: f.write(line+"\n")
    except Exception:
        pass

def _backup() -> str:
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"module_code_intake.py.{int(time.time())}.bak")
    shutil.copy2(MOD, bak)
    _log(f"Backup erstellt: {bak}")
    return bak

def _load() -> list[str]:
    with io.open(MOD, "r", encoding="utf-8", errors="ignore") as f:
        return f.read().replace("\t", "    ").splitlines(True)

def _save(lines: list[str]):
    with io.open(MOD, "w", encoding="utf-8") as f:
        f.writelines(lines)

def _prev_code_line(lines, idx):
    j = idx-1
    while j>=0 and (lines[j].strip()=="" or lines[j].lstrip().startswith("#")):
        j -= 1
    return j

def _indent_of(s: str) -> int:
    return len(s) - len(s.lstrip(" "))

def _heal_indents(lines: list[str]) -> list[str]:
    """
    Heilt typische Patch-Artefakte:
    - 'unexpected indent' bei alleinstehenden 'try:'/'except'/'finally' auf zu tiefer Stufe
    - fehlendes 'except' direkt nach 'try:' → minimaler except-Block
    Regeln sind konservativ & idempotent.
    """
    out = lines[:]
    n   = len(out)

    # 1) Alleinstehende Steuerzeilen auf gültige Stufe zurückholen
    for i in range(n):
        t = out[i]
        s = t.lstrip(" ")
        if not s: continue
        if re.match(r"^(try|except\b.*|finally:)\s*$", s):
            pi = _prev_code_line(out, i)
            if pi >= 0:
                want = _indent_of(out[pi])
                # Wenn Vorzeile KEIN Block-Opener ist, rücke aktuelle Steuerzeile auf deren Stufe.
                if not out[pi].rstrip().endswith(":") and _indent_of(t) > want:
                    out[i] = " " * want + s
            else:
                # Datei-Beginn: ganz nach links
                out[i] = s

    # 2) Fehlendes except/finally direkt nach try:
    i = 0
    while i < len(out):
        line = out[i]
        if line.lstrip(" ").startswith("try:"):
            base = _indent_of(line)
            # Schau nächste relevante Zeile
            k = i + 1
            while k < len(out) and out[k].strip()=="":
                k += 1
            # Falls die nächste Steuerzeile dedentet ist und kein 'except/finally' kommt:
            # (d.h. der try-Block war leer/kaputt) → minimalen except anhängen
            if k < len(out):
                nxt = out[k].lstrip(" ")
                if re.match(r"^(try|except|finally)\b", nxt) is None and _indent_of(out[k]) <= base:
                    patch = " " * base + "except Exception:\n" + " " * (base+4) + "pass\n"
                    out.insert(i+1, patch)  # direkt nach dem try:
                    i += 1
        i += 1

    return out

def _syntax_ok() -> bool:
    try:
        py_compile.compile(MOD, doraise=True)
        return True
    except Exception as ex:
        _log(f"Syntax-Check FEHLER: {ex}")
        return False

def main():
    _log("IntakeIndentHeal: starte Reparatur...")
    bak = _backup()
    src = _load()
    patched = _heal_indents(src)
    _save(patched)
    if _syntax_ok():
        _log("Indent/Syntax-Heal OK.")
        sys.exit(0)
    else:
        shutil.copy2(bak, MOD)
        _log("Rollback auf Backup wegen Fehler.")
        sys.exit(2)

if __name__ == "__main__":
    main()
