# -*- coding: utf-8 -*-
from __future__ import annotations
import sys, os, ast

def _read_crlf(path: str) -> str:
    with open(path, "rb") as f:
        raw = f.read()
    try:
        txt = raw.decode("utf-8")
    except UnicodeDecodeError:
        txt = raw.decode("latin-1", errors="replace")
    return txt

def _has_unclosed_triple_quotes(s: str) -> bool:
    # einfache Heuristik: prüft, ob ungerade Anzahl von ''' oder """ vorkommt
    c1 = s.count('"""')
    c2 = s.count("'''")
    return (c1 % 2 != 0) or (c2 % 2 != 0)

def check_file(path: str) -> bool:
    if not os.path.exists(path):
        print(f"[GUARD] Datei nicht gefunden: {path}")
        return False
    try:
        src = _read_crlf(path)
    except Exception as ex:
        print(f"[GUARD] Lesen fehlgeschlagen: {ex}")
        return False

    if _has_unclosed_triple_quotes(src):
        print("[GUARD] Unausgeglichenes Triple-Quote erkannt.")
        return False

    try:
        ast.parse(src)
    except SyntaxError as ex:
        print(f"[GUARD] SyntaxError: {ex}")
        return False
    except Exception as ex:
        print(f"[GUARD] Parser-Fehler: {ex}")
        return False

    return True

def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if len(argv) >= 2 and argv[0] == "--check":
        path = argv[1]
        ok = check_file(path)
        return 0 if ok else 1
    print("Usage: py -3 tools\\Runner_1063_Intake_SanityGuard.py --check <file.py>")
    return 2

if __name__ == "__main__":
    raise SystemExit(main())
