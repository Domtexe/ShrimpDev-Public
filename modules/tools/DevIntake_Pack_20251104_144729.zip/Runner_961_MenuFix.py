# tools/Runner_961_MenuFix.py
from __future__ import annotations
import re, sys, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MG   = ROOT / "main_gui.py"

def backup(p: Path) -> Path:
    i, dst = 1, p.with_suffix(p.suffix + ".bak")
    while dst.exists():
        dst = p.with_suffix(p.suffix + f".{i}.bak"); i += 1
    dst.write_text(p.read_text(encoding="utf-8", errors="ignore"), encoding="utf-8")
    return dst

def ensure_imports(src: str) -> str:
    needed = [
        ("import tkinter as tk", r"(^|\n)import\s+tkinter\s+as\s+tk\b"),
        ("from tkinter import ttk, messagebox, simpledialog", r"(^|\n)from\s+tkinter\s+import\s+ttk,\s*messagebox.*simpledialog|(^|\n)from\s+tkinter\s+import\s+ttk,\s*messagebox\b"),
        ("from pathlib import Path", r"(^|\n)from\s+pathlib\s+import\s+Path\b"),
        ("import subprocess", r"(^|\n)import\s+subprocess\b"),
        ("import re", r"(^|\n)import\s+re\b"),
    ]
    head = []
    for line, pat in needed:
        if not re.search(pat, src, re.M):
            head.append(line)
    return ("\n".join(head) + "\n" + src) if head else src

def detect_class_block(src: str, cls_name="ShrimpDevApp"):
    m = re.search(rf"^(\s*)class\s+{cls_name}\s*\([^)]*\)\s*:\s*\n", src, re.M)
    if not m: return None
    cls_indent = m.group(1)
    # finde Ende des Klassenblocks: nächstes Top-Level (gleiche oder kleinere Einrückung) „class “ oder „if __name__ …“
    start = m.end()
    tail = src[start:]
    end_rel = re.search(rf"^\s*(class\s+|if\s+__name__\s*==\s*[\"']__main__[\"'])", tail, re.M)
    end = start + (end_rel.start() if end_rel else len(tail))
    body = src[start:end]
    # typische Methoden-Indent erkennen
    mdef = re.search(r"^(\s*)def\s+\w+\s*\(", body, re.M)
    method_indent = (mdef.group(1) if mdef else cls_indent + (" " * 4))
    return dict(cls_indent=cls_indent, method_indent=method_indent, start=start, end=end, body=body)

def insert_methods(body: str, method_indent: str) -> str:
    if "_new_module_dialog(self)" in body and "_new_runner_dialog(self)" in body:
        return body  # schon da
    tpl = f"""\n{method_indent}# --- ShrimpDev: Tools-Aktionen ---
{method_indent}from tkinter import simpledialog as _sd, messagebox as _mb
{method_indent}import re, subprocess
{method_indent}from pathlib import Path
{method_indent}
{method_indent}def _safe_module_filename(self, raw: str) -> str:
{method_indent}    name = re.sub(r"\\W+", "_", (raw or "").strip().lower())
{method_indent}    if not name: raise ValueError("Leerer Name")
{method_indent}    if not name.startswith("module_"): name = "module_" + name
{method_indent}    if not name.endswith(".py"): name += ".py"
{method_indent}    return name
{method_indent}
{method_indent}def _write_if_absent(self, path: Path, content: str) -> None:
{method_indent}    path.parent.mkdir(parents=True, exist_ok=True)
{method_indent}    if not path.exists():
{method_indent}        path.write_text(content, encoding="utf-8")
{method_indent}
{method_indent}def _module_template(self, mod_name: str) -> str:
{method_indent}    return f\"\"\"# {{mod_name}}
{method_indent}# erstellt mit ShrimpDev
{method_indent}from __future__ import annotations
{method_indent}
{method_indent}def main():
{method_indent}    print("Hello from {{mod_name}}")
{method_indent}
{method_indent}if __name__ == "__main__":
{method_indent}    main()
{method_indent}\"\"\"
{method_indent}
{method_indent}def _runner_template(self, runner_name: str) -> str:
{method_indent}    return f\"\"\"# tools/{{runner_name}}
{method_indent}# erstellt mit ShrimpDev
{method_indent}from __future__ import annotations
{method_indent}import sys
{method_indent}
{method_indent}def main() -> int:
{method_indent}    print("[{{runner_name}}] Hello")
{method_indent}    return 0
{method_indent}
{method_indent}if __name__ == "__main__":
{method_indent}    raise SystemExit(main())
{method_indent}\"\"\"
{method_indent}
{method_indent}def _open_in_editor(self, p: Path):
{method_indent}    try:
{method_indent}        subprocess.Popen(["cmd","/c","start","", str(p)], shell=False)
{method_indent}    except Exception:
{method_indent}        pass
{method_indent}
{method_indent}def _new_module_dialog(self):
{method_indent}    raw = _sd.askstring("Neues Modul", "Name (ohne 'module_' und .py):", parent=self)
{method_indent}    if not raw: return
{method_indent}    try:
{method_indent}        fname = self._safe_module_filename(raw)
{method_indent}        target = Path(r"D:\\ShrimpDev") / "modules" / fname
{method_indent}        self._write_if_absent(target, self._module_template(fname))
{method_indent}        try: _mb.showinfo("ShrimpDev", f"Neues Modul erstellt:\\n{{target}}")
{method_indent}        except Exception: pass
{method_indent}        self._open_in_editor(target)
{method_indent}    except Exception as ex:
{method_indent}        try: _mb.showerror("ShrimpDev", f"Fehler beim Erstellen:\\n{{ex}}")
{method_indent}        except Exception: pass
{method_indent}
{method_indent}def _new_runner_dialog(self):
{method_indent}    raw = _sd.askstring("Neuer Runner", "Name (ohne 'Runner_' und .py/.bat):", parent=self)
{method_indent}    if not raw: return
{method_indent}    base = re.sub(r"\\W+", "_", raw.strip())
{method_indent}    if not base:
{method_indent}        try: _mb.showerror("ShrimpDev", "Ungültiger Name.")
{method_indent}        except Exception: pass
{method_indent}        return
{method_indent}    base = f"Runner_{{base}}"
{method_indent}    py  = Path(r"D:\\ShrimpDev") / "tools" / f"{{base}}.py"
{method_indent}    bat = Path(r"D:\\ShrimpDev") / "tools" / f"{{base}}.bat"
{method_indent}    try:
{method_indent}        self._write_if_absent(py,  self._runner_template(f"{{base}}.py"))
{method_indent}        bat.write_text(
{method_indent}            f"@echo off\\r\\ncd /d \\"D:\\\\ShrimpDev\\"\\r\\npy -3 -u tools\\\\{{base}}.py\\r\\n"
{method_indent}            "echo [END ] RC=%errorlevel%\\r\\npause\\r\\n",
{method_indent}            encoding="utf-8"
{method_indent}        )
{method_indent}        try: _mb.showinfo("ShrimpDev", f"Neuer Runner erstellt:\\n{{py}}\\n{{bat}}")
{method_indent}        except Exception: pass
{method_indent}        self._open_in_editor(py)
{method_indent}    except Exception as ex:
{method_indent}        try: _mb.showerror("ShrimpDev", f"Fehler beim Erstellen:\\n{{ex}}")
{method_indent}        except Exception: pass
"""
    return body + tpl

def patch_menu(src: str) -> str:
    # _mk_menu finden
    m = re.search(r"^(\s*)def\s+_mk_menu\s*\(\s*self\s*\)\s*:\s*\n", src, re.M)
    if not m: return src
    fn_start = m.end()
    # Ende der Funktion: nächste def mit gleicher Einrückung
    func_indent = m.group(1)
    tail = src[fn_start:]
    end_rel = re.search(rf"^\{func_indent}def\s+\w+\s*\(", tail, re.M)
    fn_end = fn_start + (end_rel.start() if end_rel else len(tail))
    block = src[fn_start:fn_end]

    if "Neues Modul" in block and "Neuer Runner" in block:
        return src  # schon drin

    # nach m_tools.add_cascade einfügen; Indent der m_tools-Zeile übernehmen
    mt = re.search(r"^(\s*)m_tools\s*=\s*tk\.Menu\(.*\)\s*\n.*?add_cascade\(.*m_tools.*\)\s*$",
                   block, re.M|re.S)
    if mt:
        ins_indent = mt.group(1) + " " * 4
        insertion = (
            f"{ins_indent}m_tools.add_command(label=\"Neues Modul…\", command=self._new_module_dialog)\n"
            f"{ins_indent}m_tools.add_command(label=\"Neuer Runner…\", command=self._new_runner_dialog)\n"
        )
        block = re.sub(r"(\n\s*menubar\.add_cascade\(.*m_tools.*\)\s*\n?)",
                       r"\1" + insertion, block, count=1, flags=re.S)
    else:
        # Fallback: am Ende der Funktion einfügen
        ins_indent = func_indent + " " * 8
        insertion = (
            f"\n{ins_indent}m_tools.add_command(label=\"Neues Modul…\", command=self._new_module_dialog)\n"
            f"{ins_indent}m_tools.add_command(label=\"Neuer Runner…\", command=self._new_runner_dialog)\n"
        )
        block += insertion

    return src[:fn_start] + block + src[fn_end:]

def main() -> int:
    if not MG.exists():
        print("[R961] ERROR: main_gui.py nicht gefunden.")
        return 2

    bak = backup(MG)
    src = MG.read_text(encoding="utf-8", errors="ignore")

    src = ensure_imports(src)

    # Klassenblock finden
    cls = detect_class_block(src, "ShrimpDevApp")
    if not cls:
        print("[R961] ERROR: Klasse ShrimpDevApp nicht gefunden.")
        print(f"[R961] Backup: {bak}")
        return 2

    # Methoden einfügen
    body_new = insert_methods(cls["body"], cls["method_indent"])
    src = src[:cls["start"]] + body_new + src[cls["end"]:]

    # Menü patchen
    src = patch_menu(src)

    # schreiben & Syntax testen
    MG.write_text(src, encoding="utf-8")
    try:
        compile(src, str(MG), "exec")
    except SyntaxError as ex:
        print(f"[R961] FAIL: Syntaxfehler nach Patch: {ex}")
        print(f"[R961] Backup: {bak}")
        return 1

    print(f"[R961] OK – Menüs & Methoden korrekt eingehängt. Backup: {bak.name}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
