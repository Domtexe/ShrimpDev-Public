# -*- coding: utf-8 -*-
"""
Runner_1092_FixRecycleBinIndent
Repariert fehlende Einrückung der Funktion send_to_recycle_bin()
in modules/module_code_intake.py. (Indent der Funktions-zeilen bis zum
nächsten top-level 'def ' / 'class ' wird um 4 Spaces eingerückt.)
"""

from __future__ import annotations
import os, time, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"

def backup(path: Path) -> Path:
    ARCH.mkdir(exist_ok=True)
    bak = ARCH / f"{path.name}.{int(time.time())}.bak"
    shutil.copy2(path, bak)
    print(f"[R1092] Backup: {path} -> {bak}")
    return bak

def fix_function_indent(src: str, func_name: str) -> tuple[str, bool]:
    lines = src.splitlines()
    n = len(lines)
    changed = False

    # top-level Funktionskopf suchen
    start = None
    for i, ln in enumerate(lines):
        if ln.startswith(f"def {func_name}("):
            start = i
            break
    if start is None:
        return src, False

    # Bereich bis zur nächsten top-level def/class ermitteln
    end = n
    for j in range(start + 1, n):
        s = lines[j]
        if s.startswith("def ") or s.startswith("class "):
            end = j
            break

    # Alle nicht-leeren Zeilen zwischen start+1 .. end-1 einrücken,
    # die aktuell NICHT mit Space/TAB beginnen.
    fixed = lines[:]
    for k in range(start + 1, end):
        s = fixed[k]
        if s.strip() == "":
            continue
        if not (s.startswith(" ") or s.startswith("\t")):
            fixed[k] = "    " + s
            changed = True

    return "\n".join(fixed), changed

def main() -> int:
    if not MOD.exists():
        print(f"[R1092] Datei nicht gefunden: {MOD}")
        return 1

    backup(MOD)
    src = MOD.read_text(encoding="utf-8", errors="ignore")

    new, c1 = fix_function_indent(src, "send_to_recycle_bin")
    # Falls du _on_click_clear_code schon separat hast und er ebenfalls top-level fehlerhaft ist, optional:
    new, c2 = fix_function_indent(new, "_on_click_clear_code")

    if not (c1 or c2):
        print("[R1092] Keine Änderungen nötig.")
        return 0

    MOD.write_text(new, encoding="utf-8", newline="\n")
    print("[R1092] Einrückung repariert (send_to_recycle_bin / ggf. _on_click_clear_code).")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
