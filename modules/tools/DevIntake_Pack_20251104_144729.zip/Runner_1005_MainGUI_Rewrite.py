"""
Runner_1005_MainGUI_Rewrite
Schreibt eine saubere, gültige main_gui.py (v9.8.7) – behebt Syntax-/Indent-Fehler
und stellt sys.path-Safeguard + Fallback-Logger sicher.
"""
from __future__ import annotations
import os, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1005] {ts} {msg}\n")
    print(msg, flush=True)

def safe_write(path: str, data: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        os.makedirs(ARCH, exist_ok=True)
        bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
        shutil.copy2(path, bck)
        log(f"Backup: {path} -> {bck}")
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

MAIN_GUI = r'''"""ShrimpDev main_gui (v9.8.7)
- Ein-Fenster-Notebook: Intake / Agent / Project
- Always-on-Top Toggle (persistiert in intake.ini, Ctrl+T)
- sys.path-Safeguard + Fallback-Logger
"""
from __future__ import annotations
import os, sys, traceback, tkinter as tk
from tkinter import ttk

# --- sys.path Safeguard ---
ROOT = os.path.abspath(os.path.dirname(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# --- Logger-Import mit robustem Fallback ---
try:
    from modules.snippets.logger_snippet import write_log
except Exception:
    def _fallback_write_log(prefix: str, msg: str) -> None:
        try:
            logp = os.path.join(ROOT, "debug_output.txt")
            ts = __import__("time").strftime("%Y-%m-%d %H:%M:%S", __import__("time").localtime())
            with open(logp, "a", encoding="utf-8") as f:
                f.write(f"[{prefix}] {ts} {msg}\n")
        except Exception:
            pass
    write_log = _fallback_write_log

# --- restliche Imports (nach Safeguard/Fallback) ---
from modules.module_code_intake import IntakeFrame
from modules.module_agent_ui import AgentFrame
from modules.module_project_ui import ProjectFrame
from modules.config_mgr import ConfigMgr

def _safe_main() -> None:
    root = tk.Tk()
    root.title("ShrimpDev – v9.8.7")
    root.geometry("1000x700")

    cfg = ConfigMgr()

    # Topbar mit Always-on-Top
    topbar = ttk.Frame(root)
    topbar.pack(side="top", fill="x")

    var_top = tk.BooleanVar(value=cfg.get_bool("general", "always_on_top", False))

    def _apply_topmost():
        try:
            root.attributes("-topmost", bool(var_top.get()))
            cfg.set_str("general", "always_on_top", "true" if var_top.get() else "false")
            write_log("GUI", f"TOPMOST_TOGGLE={var_top.get()}")
        except Exception as ex:
            write_log("GUI", f"TOPMOST_ERR: {ex}")

    chk = ttk.Checkbutton(topbar, text="Always on Top", variable=var_top, command=_apply_topmost)
    chk.pack(side="left", padx=8, pady=6)

    def _toggle_event(_evt=None):
        var_top.set(not var_top.get()); _apply_topmost()
    root.bind_all("<Control-t>", _toggle_event)

    _apply_topmost()

    # Notebook
    nb = ttk.Notebook(root)
    nb.pack(fill="both", expand=True)

    tab_intake = IntakeFrame(nb)
    tab_agent  = AgentFrame(nb)
    tab_proj   = ProjectFrame(nb)

    nb.add(tab_intake, text="Intake")
    nb.add(tab_agent,  text="Agent")
    nb.add(tab_proj,   text="Project")
    nb.select(0)  # Default: Intake

    # Statusbar
    status = tk.StringVar(value="Bereit.")
    bar = ttk.Label(root, textvariable=status, anchor="w")
    bar.pack(side="bottom", fill="x")

    def on_exception(exc: BaseException):
        write_log("GUI", f"FEHLER: {exc}")
        status.set(f"Fehler: {exc}")

    def report_callback_exception(*exc):
        on_exception(exc[-1])

    root.report_callback_exception = report_callback_exception
    root.mainloop()

if __name__ == "__main__":
    try:
        _safe_main()
    except Exception:
        tb = traceback.format_exc()
        write_log("GUI", "CRASH\n" + tb)
        sys.exit(1)
'''

def patch() -> int:
    try:
        safe_write(os.path.join(ROOT, "main_gui.py"), MAIN_GUI)
        # Meta
        safe_write(os.path.join(ROOT, "CURRENT_VERSION.txt"), "ShrimpDev v9.8.7\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.8.7 (2025-10-18)
- FIX: main_gui.py vollständig neu aufgebaut (gültiger try/except, Fallback-Logger)
- FEATURE: Always-on-Top bleibt erhalten; sys.path-Safeguard konsolidiert
""")
        log("main_gui.py neu geschrieben (v9.8.7).")
        return 0
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(patch())
