# -*- coding: utf-8 -*-
"""
R1170d_UXLayoutPolish
- Fügt Helper _intake_layout_polish(self) ein (sanfte Layout-Korrekturen)
- Aufruf nach __init__->_build_ui(self)
- Verändert KEINE Manager (kein pack/grid Wechsel), nur weights/sticky/Stretch
"""
from __future__ import annotations
import os, re, time, py_compile, traceback

ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),".."))
TARGET=os.path.join(ROOT,"modules","module_code_intake.py")
ARCH=os.path.join(ROOT,"_Archiv")
LOG=os.path.join(ROOT,"debug_output.txt")

HELPER_MARK="# R1170d: layout polish helper"
CALL_MARK  ="# R1170d: layout polish call"

HELPER_CODE=f"""
{HELPER_MARK}
def _intake_layout_polish(self)->None:
    \"\"\"Sanfte Layout-Korrektur: column/row weights, sticky, Treeview-Stretch, Minbreiten.\"\"\"
    try:
        import tkinter as tk
        from tkinter import ttk
    except Exception:
        return
    try:
        # Root-Frame streckbar
        try:
            self.grid_columnconfigure(0, weight=1)
            self.grid_rowconfigure(0, weight=1)
        except Exception:
            pass
        # Actions/Toolbar: Buttons gleichmäßig, minimale Breite
        for name in dir(self):
            if name.startswith("btn_"):
                try:
                    getattr(self, name).configure(width=16)  # einheitlich
                except Exception:
                    pass
        # Texteditor strecken
        txt=getattr(self,"txt",None)
        if txt:
            try: txt.grid_configure(sticky="nsew")
            except Exception: pass
        # Tabellenbereich strecken
        tbl=getattr(self,"tbl",None)
        if tbl:
            try:
                # Spalten auf Stretch
                cols=tbl["columns"] if "columns" in tbl.keys() else ()
                for c in cols:
                    try: tbl.column(c, stretch=True, minwidth=80, width=120)
                    except Exception: pass
                # Tree selbst strecken (falls grid)
                try: tbl.grid_configure(sticky="nsew")
                except Exception: pass
            except Exception:
                pass
        # Falls linke/rechte Pane vorhanden: Sash minimal positionieren
        try:
            pw=getattr(self,"paned",None) or getattr(self,"pw",None)
            if pw and hasattr(pw,"sashpos"):
                try: pw.sashpos(0, 320)
                except Exception: pass
        except Exception:
            pass
        # Container-Gewichte (üblich: 2 Spalten – links Eingabe, rechts Tabelle)
        try:
            parent=self
            for i in range(3):
                try: parent.grid_columnconfigure(i, weight=(1 if i>0 else 0))
                except Exception: pass
            for i in range(3):
                try: parent.grid_rowconfigure(i, weight=(1 if i>0 else 0))
                except Exception: pass
        except Exception:
            pass
    except Exception:
        pass
"""

def log(m):
    import time
    with open(LOG,"a",encoding="utf-8",newline="") as f:
        f.write(f"[1170d {time.strftime('%Y-%m-%d %H:%M:%S')}] {m}\n")
    print(m)

def backup(path)->str:
    os.makedirs(ARCH,exist_ok=True)
    dst=os.path.join(ARCH,f"{os.path.basename(path)}.{int(time.time())}.bak")
    open(dst,"w",encoding="utf-8",newline="").write(open(path,"r",encoding="utf-8").read())
    return dst

def main()->int:
    try:
        if not os.path.exists(TARGET):
            log(f"Zieldatei fehlt: {TARGET}"); return 1
        src=open(TARGET,"r",encoding="utf-8").read()
        changed=False
        if HELPER_MARK not in src:
            m=re.search(r"(?m)^\\s*#\\s*-{2,}\\s*helpers\\s*-{2,}\\s*$",src)
            ins=m.end() if m else len(src)
            src=src[:ins]+"\n"+HELPER_CODE+src[ins:]
            changed=True
        if CALL_MARK not in src:
            pat=r"(?s)(def\\s+__init__\\s*\\(.*?\\):.*?\\n)([\\t ]*self\\._build_ui\\(self\\)\\s*\\n)"
            m=re.search(pat,src)
            if m:
                insert_at=m.end(2)
                call=f"{' '*(len(m.group(2))-len(m.group(2).lstrip()))}{CALL_MARK}\n{' '*(len(m.group(2))-len(m.group(2).lstrip()))}_intake_layout_polish(self)\\n"
                src=src[:insert_at]+call+src[insert_at:]
                changed=True
            else:
                log("Warnung: Stelle nach _build_ui(self) in __init__ nicht gefunden – kein Call injiziert.")
        if not changed:
            log("Keine Änderung notwendig (bereits gepatcht)."); return 0
        bak=backup(TARGET); log(f"Backup erstellt: {bak}")
        open(TARGET,"w",encoding="utf-8",newline="\n").write(src)
        try:
            py_compile.compile(TARGET,doraise=True)
        except Exception as e:
            open(TARGET,"w",encoding="utf-8",newline="\n").write(open(bak,"r",encoding="utf-8").read())
            log("Syntax-Check FEHLER -> Rollback."); log("Traceback:\n"+ "".join(traceback.format_exception(type(e),e,e.__traceback__))); return 1
        log("Patch erfolgreich eingefügt und Syntax-Check OK."); return 0
    except Exception as e:
        log("UNERWARTETER FEHLER:\n"+ "".join(traceback.format_exception(type(e),e,e.__traceback__))); return 1

if __name__=="__main__": raise SystemExit(main())
