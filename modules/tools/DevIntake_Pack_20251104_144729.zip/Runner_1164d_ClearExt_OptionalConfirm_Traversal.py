# -*- coding: utf-8 -*-
"""
R1164d ClearExt & OptionalConfirm (Traversal)
- Fügt Helfer ein:
    _intake_on_clear_editor_clicked(self, prior_command=None)
    _intake_post_build_bind_clear(self)  -> traversiert Widgets, bindet Buttons mit text "Editor leeren"
- Hängt _intake_post_build_bind_clear() ans Ende von _build_ui(), falls vorhanden.
- Endung wird zusätzlich geleert (var_ext/entry_ext); Checkbox "Nicht wieder anzeigen" ist session-weit.
- Safety: Backup, Syntax-Check, Rollback.
"""
from __future__ import annotations
import os, io, re, time, shutil, py_compile, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOGF = os.path.join(ROOT, "debug_output.txt")

HELPERS = r'''
# --- R1164d helpers: traversal bind for "Editor leeren" ---
def _intake_on_clear_editor_clicked(self, prior_command=None):
    try:
        import tkinter as tk
        from tkinter import ttk
        if not getattr(self, "_skip_confirm_clear", False):
            dlg = tk.Toplevel(self); dlg.title("Bestätigung")
            dlg.transient(self.winfo_toplevel()); dlg.grab_set()
            ttk.Label(dlg, text="Editor wirklich leeren?").grid(row=0, column=0, columnspan=2, padx=10, pady=8, sticky="w")
            var_skip = tk.BooleanVar(value=False)
            ttk.Checkbutton(dlg, text="Nicht wieder anzeigen", variable=var_skip).grid(row=1, column=0, columnspan=2, padx=10, pady=(0,8), sticky="w")
            res={"ok":False}
            def _ok(): res["ok"]=True; dlg.destroy()
            def _cancel(): dlg.destroy()
            ttk.Button(dlg, text="Ja", command=_ok).grid(row=2, column=0, padx=10, pady=8)
            ttk.Button(dlg, text="Nein", command=_cancel).grid(row=2, column=1, padx=10, pady=8)
            dlg.bind("<Return>", lambda e: _ok()); dlg.bind("<Escape>", lambda e: _cancel()); dlg.wait_window()
            if res["ok"] and var_skip.get(): setattr(self, "_skip_confirm_clear", True)
            if not res["ok"]: return
        if callable(prior_command):
            try: prior_command()
            except TypeError:
                try: prior_command(self)
                except Exception: pass
        try:
            getattr(self, 'var_ext').set('')
        except Exception:
            try:
                ent = getattr(self, 'entry_ext'); ent.delete(0, 'end')
            except Exception:
                pass
    except Exception:
        pass

def _intake_post_build_bind_clear(self):
    try:
        import tkinter as tk
        from tkinter import ttk
        def _walk(w):
            try:
                for c in w.winfo_children():
                    yield c; yield from _walk(c)
            except Exception:
                return
        for w in _walk(self):
            try:
                if str(w.winfo_class()) in ("TButton","Button") and w.cget("text") == "Editor leeren":
                    try:
                        prior = w.cget("command")
                    except Exception:
                        prior = None
                    try:
                        w.configure(command=lambda p=prior: _intake_on_clear_editor_clicked(self, p))
                    except Exception:
                        w.configure(command=lambda: _intake_on_clear_editor_clicked(self, None))
            except Exception:
                continue
    except Exception:
        pass
'''

def log(msg):
    ts=time.strftime("%Y-%m-%d %H:%M:%S")
    with io.open(LOGF,"a",encoding="utf-8") as f: f.write(f"[R1164d] {ts} {msg}\n")
    print(f"[R1164d] {ts} {msg}")

def backup(p):
    os.makedirs(ARCH, exist_ok=True)
    dst=os.path.join(ARCH,f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p,dst); log(f"Backup: {p} -> {dst}"); return dst

def inject(src: str):
    changes=[]
    new=src
    if "_intake_on_clear_editor_clicked" not in new:
        new=new.rstrip()+"\n\n"+HELPERS+"\n"
        changes.append("Added traversal helpers for 'Editor leeren'")
    m=re.search(r"^\s*def\s+_build_ui\s*\(\s*self[^\)]*\)\s*:\s*$", new, re.M)
    if m:
        start=m.end(); tail=new[start:]
        nxt=re.search(r"^\s*def\s+\w+\s*\(", tail, re.M)
        insert_pos=start+(nxt.start() if nxt else len(tail))
        if "self._intake_post_build_bind_clear()" not in new[start:insert_pos]:
            new=new[:insert_pos]+"\n        # R1164d: bind clear button by traversal\n        self._intake_post_build_bind_clear()\n"+new[insert_pos:]
            changes.append("Hooked _intake_post_build_bind_clear() at end of _build_ui()")
    else:
        changes.append("No _build_ui() found; helpers added but not hooked")
    return new, changes

def main():
    try:
        if not os.path.isfile(MOD): log(f"[ERR] Not found: {MOD}"); return 2
        src=io.open(MOD,"r",encoding="utf-8").read()
        bak=backup(MOD)
        new, changes=inject(src)
        if not changes: log("No changes applied."); return 0
        io.open(MOD,"w",encoding="utf-8",newline="\n").write(new)
        try: py_compile.compile(MOD,doraise=True); log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}"); shutil.copy2(bak,MOD); log("Restored from backup."); return 3
        log("R1164d completed successfully."); return 0
    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}"); return 1

if __name__=="__main__": raise SystemExit(main())
