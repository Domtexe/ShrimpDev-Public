# -*- coding: utf-8 -*-
"""
Runner_1127_IntakeFix_All
Ziel: Intake-Tab stabilisieren und Toolbar-/Binding-Fehler beheben.
- ersetzt Verweise auf self.frm_actions durch 'bar' (tatsächlicher Toolbar-Frame),
- entfernt den doppelten 'try:'-Block vor den Button-Bindings (SyntaxError),
- kapselt Button-Bindings korrekt in einen einzigen try/except,
- stellt einmalige Editor-Bindings sicher (falls 1126 nicht griff),
- Backup, Syntax-Check, Rollback,
- zentrales Logging (write_log) mit stillem Fallback.
"""

from __future__ import annotations
import re, time, shutil, traceback
from pathlib import Path

ROOT   = Path(__file__).resolve().parents[1]
TARGET = ROOT / "modules" / "module_code_intake.py"
ARCH   = ROOT / "_Archiv"
REPO   = ROOT / "_Reports"
ARCH.mkdir(exist_ok=True); REPO.mkdir(exist_ok=True)
REPORT = REPO / "Runner_1127_IntakeFix_All_report.txt"

def rep(msg: str) -> None:
    with open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip() + "\n")

def log(prefix: str, msg: str) -> None:
    """Zentral loggen – schluckender Fallback."""
    try:
        from modules.snippets.logger_snippet import write_log as _w
        _w(prefix, msg)
    except Exception:
        try:
            p = ROOT / "debug_output.txt"
            ts = time.strftime("%Y-%m-%d %H:%M:%S")
            with open(p, "a", encoding="utf-8", newline="\n") as f:
                f.write(f"[{prefix}] {ts} {msg}\n")
        except Exception:
            pass

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time())}.bak"
    shutil.copy2(p, dst)
    rep(f"[Backup] {p} -> {dst}")
    return dst

# --- Helfer: Klassenblock IntakeFrame lokalisieren ---------------------------
def find_intake_bounds(src: str) -> tuple[int, int]:
    m = re.search(r'^[ \t]*class[ \t]+IntakeFrame\b[^\n]*:\s*\n', src, flags=re.MULTILINE)
    if not m:
        raise RuntimeError("class IntakeFrame nicht gefunden.")
    start = m.start()
    m2 = re.search(r'^[ \t]*class[ \t]+\w+[^\n]*:\s*\n', src[m.end():], flags=re.MULTILINE)
    end = (m.end() + m2.start()) if m2 else len(src)
    return start, end

def ensure_editor_bind_injection(cls_block: str) -> str:
    """
    Nach der Textwidget-Erzeugung self.txt=... folgende Zeilen einmalig injizieren:
        self._detect_job = None
        self._ensure_editor_bindings()
    (falls noch nicht vorhanden)
    """
    if "_ensure_editor_bindings(" in cls_block and "self._detect_job" in cls_block:
        return cls_block  # bereits vorhanden

    pattern = r'(\bself\.txt\s*=\s*tk\.Text\([^)]*\)\s*\n)'
    repl = r'\1        self._detect_job = None\n        self._ensure_editor_bindings()\n'
    new, n = re.subn(pattern, repl, cls_block, count=1)
    return new if n else cls_block

def insert_guard_methods_if_missing(cls_block: str) -> str:
    """Stabile Editor-Guard-Methoden (aus 1126) nur ergänzen, falls nicht vorhanden."""
    need = not all(name in cls_block for name in [
        "_ensure_editor_bindings", "_on_editor_paste", "_on_editor_key",
        "_on_editor_modified", "_schedule_detect", "_auto_detect_if_needed"
    ])
    if not need:
        return cls_block

    guards = r'''
    # --- Editor-Event-Guards (1127 mirror 1126) -------------------------
    def _ensure_editor_bindings(self) -> None:
        try:
            self.txt.unbind("<<Paste>>"); self.txt.unbind("<Control-v>")
            self.txt.unbind("<<Modified>>"); self.txt.unbind("<KeyRelease>")
        except Exception:
            pass
        self.txt.bind("<<Paste>>", self._on_editor_paste)
        self.txt.bind("<Control-v>", self._on_editor_paste)
        self.txt.bind("<<Modified>>", self._on_editor_modified)
        self.txt.bind("<KeyRelease>", self._on_editor_key)

    def _on_editor_paste(self, _evt=None):
        try: self._schedule_detect(220)
        except Exception as ex: pass

    def _on_editor_key(self, _evt=None):
        try: self._schedule_detect(250)
        except Exception as ex: pass

    def _on_editor_modified(self, _evt=None):
        try:
            try: self.txt.edit_modified(False)
            except Exception: pass
            self._schedule_detect(300)
        except Exception as ex: pass

    def _schedule_detect(self, delay_ms: int = 250):
        try:
            if getattr(self, "_detect_job", None):
                try: self.after_cancel(self._detect_job)
                except Exception: pass
            self._detect_job = self.after(delay_ms, self._auto_detect_if_needed)
        except Exception as ex: pass

    def _auto_detect_if_needed(self):
        try: self._detect()
        except Exception: pass
    # --- /Editor-Event-Guards (1127) ------------------------------------
'''.lstrip("\n")
    return cls_block.rstrip() + "\n" + guards

def fix_toolbar_and_bindings(cls_block: str) -> str:
    """
    1) self.frm_actions -> bar (Eltern-Frame der Toolbar)
    2) Doppelte try:-Sequenz eliminiert; sauberer Try/Except um Bindings.
    """
    # 1) alle Vorkommen innerhalb Klasse ersetzen (nur GUI-Aufbau betrifft das sinnvoll)
    cls_block = re.sub(r'\bself\.frm_actions\b', 'bar', cls_block)

    # 2) Bindings-Blöcke reparieren: zwischen Button-Grid und Beginn 'body = ttk.Panedwindow'
    # Wir fassen die drei bind-Zeilen in EINEN Try/Except-Block zusammen.
    bind_pat = (
        r'(\n[ \t]*#?\s*.*?\bself\.btn_detect\.grid[^\n]*\n'      # grid detect
        r'[ \t]*self\.btn_save\.grid[^\n]*\n'                      # grid save
        r'[ \t]*self\.btn_del\.grid[^\n]*\n'                       # grid del
        r')[ \t]*(?:try:\s*\n)?'                                   # optional kaputtes try:
        r'(?:[ \t]*self\.btn_detect\.bind[^\n]*\n[ \t]*self\.btn_save\.bind[^\n]*\n[ \t]*self\.btn_del\.bind[^\n]*\n)?'
        r'(?:[ \t]*try:\s*\n[ \t]*pass\s*\n[ \t]*except\s+Exception:\s*\n[ \t]*pass\s*\n)?'
    )
    bind_repl = (
        r'\1'
        r'        # Button-Bindings (einmalig, nicht rekursiv)\n'
        r'        try:\n'
        r'            self.btn_detect.bind("<ButtonRelease-1>", lambda e: self._on_click_detect())\n'
        r'            self.btn_save.bind(  "<ButtonRelease-1>", lambda e: self._on_click_save())\n'
        r'            self.btn_del.bind(   "<ButtonRelease-1>", lambda e: self._on_click_delete())\n'
        r'        except Exception:\n'
        r'            pass\n'
    )
    cls_block = re.sub(bind_pat, bind_repl, cls_block, flags=re.DOTALL)

    return cls_block

def patch_source(src: str) -> str:
    start, end = find_intake_bounds(src)
    pre, cls, post = src[:start], src[start:end], src[end:]

    # Toolbar / Elternframe / Bindings aufräumen
    cls = fix_toolbar_and_bindings(cls)

    # Editor-Bindings sicherstellen (falls 1126 noch nicht gegriffen)
    cls = ensure_editor_bind_injection(cls)

    # Guard-Methoden bei Bedarf ergänzen
    cls = insert_guard_methods_if_missing(cls)

    return pre + cls + post

def main() -> int:
    rep("Runner_1127_IntakeFix_All – Start")
    if not TARGET.exists():
        rep(f"[FEHLER] Datei fehlt: {TARGET}")
        return 2
    original = TARGET.read_text(encoding="utf-8", errors="ignore")
    backup(TARGET)

    try:
        new_src = patch_source(original)
        # Syntaxprobe
        compile(new_src, str(TARGET), "exec")
        TARGET.write_text(new_src, encoding="utf-8", newline="\n")
        rep("[OK] Patch geschrieben, Syntax OK.")
        log("R1127", "IntakeFix angewendet")
        return 0
    except Exception as ex:
        rep("[FEHLER] Patch fehlgeschlagen, Rollback …")
        TARGET.write_text(original, encoding="utf-8", newline="\n")
        rep("TRACE:\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        log("R1127", f"FAIL: {ex!r}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
