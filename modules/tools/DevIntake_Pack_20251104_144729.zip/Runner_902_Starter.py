from pathlib import Path

ROOT  = Path(r"D:\ShrimpDev")
TOOLS = ROOT / "tools"
TOOLS.mkdir(parents=True, exist_ok=True)

def write(p: Path, content: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content.replace("\r\n", "\n"), encoding="utf-8")
    print(f"[R902] wrote {p.relative_to(ROOT)}")

start_visible = r"""@echo off
setlocal
cd /d "D:\ShrimpDev"
set PYTHONUTF8=1
where py >nul 2>nul && (set "PY=py -3") || (set "PY=python")
echo [START] ShrimpDev visible (%date% %time%)
%PY% -u main_gui.py
echo [END  ] RC=%errorlevel%
endlocal
"""

start_quiet_vbs = r"""Dim sh, cmd
Set sh = CreateObject("WScript.Shell")
sh.CurrentDirectory = "D:\ShrimpDev"
cmd = "cmd /c set PYTHONUTF8=1 & (where py >nul 2>nul && (set PY=py -3) || (set PY=python)) & %PY% -u main_gui.py >> debug_output.txt 2>&1"
sh.Run cmd, 0, False
"""

start_quiet_bat = r"""@echo off
setlocal
cd /d "D:\ShrimpDev"
set "LOG=debug_output.txt"
if exist "%LOG%" for %%F in ("%LOG%") do if %%~zF gtr 2097152 (
  for /f "tokens=1-4 delims=/:. " %%a in ("%date% %time%") do set TS=%%d%%b%%a_%%c
  ren "%LOG%" "debug_output_%TS%.log"
)
cscript //nologo "tools\start_quiet.vbs"
echo [INFO ] ShrimpDev quiet gestartet – siehe debug_output.txt
endlocal
"""

start_debug = r"""@echo off
setlocal
cd /d "D:\ShrimpDev"
set PYTHONUTF8=1
where py >nul 2>nul && (set "PY=py -3") || (set "PY=python")
echo === ShrimpDev DEBUG (%date% %time%) ===>> debug_output.txt
start "" notepad "debug_output.txt"
%PY% -u main_gui.py >> debug_output.txt 2>&1
endlocal
"""

# schreiben
write(TOOLS / "start_visible.bat", start_visible)
write(TOOLS / "start_quiet.vbs",   start_quiet_vbs)
write(TOOLS / "start_quiet.bat",   start_quiet_bat)
write(TOOLS / "start_debug.bat",   start_debug)

print("[R902] DONE. Use tools\\start_visible.bat or tools\\start_quiet.bat")
