from __future__ import annotations
import os, re
from patchlib_guard import guarded_apply, FileCtx

ROOT = r"D:\ShrimpDev"
MAIN = os.path.join(ROOT, "main_gui.py")

def _transform(ctx: FileCtx):
    src = ctx.modified

    # Entferne komplette def nb.add(...)-Blöcke
    src = re.sub(
        r'(?ms)^def\s+nb\.add\s*\([^)]*\):\s*\n(?:\s+.*\n)*?(?=^def\s|\Z)', 
        '', 
        src
    )

    # Falls der Aufruf fehlt, korrekt einfügen nach Notebook-Erstellung
    if "nb.add(__mount_intake_tab_shim(nb)" not in src:
        src = re.sub(
            r'(nb\s*=\s*ttk\.Notebook\(.*\)\s*\n)',
            r'\1    nb.add(__mount_intake_tab_shim(nb), text="Code Intake")\n',
            src
        )

    ctx.modified = src

ok, msg = guarded_apply(MAIN, _transform)
print(("[1175i] " + (msg or "")).strip())
raise SystemExit(0 if ok else 1)
