"""
Runner_1039_IndentFix_TryExcept
- Normalisiert modules/module_code_intake.py:
  * Tabs -> 4 Spaces, CRLF
  * richtet 'except' / 'finally' Einrückungen auf das letzte 'try:' aus
- Ziel: IndentationError an 'except Exception:' (Zeile ~261) beseitigen,
        ohne Logik zu verändern.
- Version -> v9.9.28
"""
from __future__ import annotations
import os, time, shutil, re

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def wlog(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1039] {ts} {msg}\n")
    except Exception:
        pass

def load_text(p: str) -> str:
    with open(p, "r", encoding="utf-8", errors="replace") as f:
        return f.read()

def save_text(p: str, s: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bck)
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(s)
    wlog(f"Backup: {p} -> {bck}")

def indent_of(line: str) -> int:
    return len(line) - len(line.lstrip(" "))

def fix_try_blocks(src: str) -> str:
    # Tabs entfernen
    src = src.replace("\t", "    ")
    lines = src.splitlines()
    out: list[str] = []

    # Stack der try-Einrückungen (Indent-Level in Spaces)
    try_stack: list[int] = []

    for i, raw in enumerate(lines):
        line = raw

        # Kommentar-/Leerzeilen unverändert
        stripped = line.lstrip(" ")
        indent = indent_of(line)

        # Pop Try-Stack, wenn wir dedenten
        while try_stack and indent < try_stack[-1]:
            try_stack.pop()

        # Neue try: gefunden -> aktuellen Indent merken
        if re.match(r"^\s*try\s*:\s*(#.*)?$", line):
            # Wenn vor diesem try bereits tiefer eingerückt ist, lassen wir es so,
            # der except muss aber zum selben indent wie dieses try.
            try_stack.append(indent)

        # except/finally auf das letzte try-Indent justieren
        if re.match(r"^\s*except\b.*:\s*(#.*)?$", line) or re.match(r"^\s*finally\s*:\s*(#.*)?$", line):
            if try_stack:
                correct = try_stack[-1]
                if indent != correct:
                    line = " " * correct + stripped
            else:
                # Orphan 'except' -> hebe eine Stufe an (sicherheitsweise 0)
                line = stripped

        out.append(line)

    return "\n".join(out)

def main() -> int:
    src = load_text(MOD)
    fixed = fix_try_blocks(src)
    if fixed != src:
        save_text(MOD, fixed)
        wlog("Indentation von try/except/finally normalisiert (Tabs->Spaces, Align).")
    else:
        wlog("Keine Änderung nötig (Indent bereits konsistent).")

    # Version/Changelog
    with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
        f.write("ShrimpDev v9.9.28\n")
    with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
        f.write("""
## v9.9.28 (2025-10-18)
- Intake: Einrückungen normalisiert; 'except/finally' auf 'try' ausgerichtet (IndentationError behoben).
""")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
