import os, re, py_compile
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MAIN = os.path.join(ROOT, "main_gui.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def wlog(msg):
    try:
        with open(LOG, "a", encoding="utf-8", newline="\n") as f:
            f.write("[R1178i] " + msg + "\n")
    except Exception:
        pass

def patch_main(text: str) -> str:
    # 1) Sicherstellen: from modules.module_shim_intake import mount_intake_tab
    text = re.sub(
        r"from\s+modules\.module_shim_intake\s+import\s+.*",
        "from modules.module_shim_intake import mount_intake_tab",
        text, count=1
    )

    # 2) Intake-Tab via Shim montieren – _safe_add_intake_tab(nb) muss existieren
    if "_safe_add_intake_tab(" not in text:
        inject = """
def _safe_add_intake_tab(nb):
    try:
        from tkinter import ttk
        if not isinstance(nb, ttk.Notebook):
            return False
        from modules.module_shim_intake import mount_intake_tab
        mount_intake_tab(nb)
        return True
    except Exception as e:
        try:
            with open(r"%s","a",encoding="utf-8") as f:
                f.write("[R1178i] IntakeMountERR: %s\\n" % e)
        except Exception:
            pass
        return False
""" % LOG.replace("\\", "\\\\")
        # vor __start_guard oder am Ende einfügen
        anchor = re.search(r"\ndef\s+__start_guard", text)
        pos = anchor.start() if anchor else len(text)
        text = text[:pos] + "\n" + inject + "\n" + text[pos:]

    # 3) Syntax aufräumen: führende "try:"-Zeilen ohne Block (Fehler aus vorigem Patch)
    #    -> Entferne isolierte 'try:' an Zeilenanfängen, wenn KEIN Einrückungsblock folgt.
    text = re.sub(r"\n[ \t]*try:\s*\n(?=[^\t ]|$)", "\n", text)

    return text

def main():
    with open(MAIN, "r", encoding="utf-8") as f:
        src = f.read()
    new = patch_main(src)
    with open(MAIN, "w", encoding="utf-8", newline="\n") as f:
        f.write(new)
    py_compile.compile(MAIN, doraise=True)
    wlog("main_gui.py import/mount patched and syntax-checked.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
