"""
Runner_1055_FixIndent_OnEditorModified
Repariert die Einrückung/Implementierung von _on_editor_modified() in
modules/module_code_intake.py (IndentationError nach R1054).

Wir ersetzen die Funktion blockweise durch eine kanonische, korrekt
eingerückte Version innerhalb der Klasse IntakeFrame.

Version: v9.9.45
"""
from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1055] {ts} {msg}\n")
    except Exception:
        pass

def read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def write_backup(path: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

CANON = (
    "    def _on_editor_modified(self, _evt=None):\n"
    "        try:\n"
    "            self.txt.edit_modified(False)\n"
    "        except Exception:\n"
    "            pass\n"
    "        self._schedule_detect(300)\n"
    "\n"
)

def patch() -> int:
    src = read_text(MOD)
    original = src

    # Stelle sicher, dass wir im Klassenblock arbeiten
    cls = re.search(r"class\s+IntakeFrame\(ttk\.Frame\):", src)
    if not cls:
        log("Klasse IntakeFrame nicht gefunden – Abbruch.")
        return 1

    # Ersetze den gesamten vorhandenen Block der Funktion (egal welche Einrückung) durch CANON
    # Suche: def _on_editor_modified(...): bis VOR dem nächsten 'def ' auf derselben Einrückungsebene
    pattern = re.compile(
        r"\n\s*def\s+_on_editor_modified\([^\)]*\):[\s\S]*?(?=\n\s*def\s+|\n\s*#|\Z)",
        re.MULTILINE,
    )
    if pattern.search(src):
        src = pattern.sub("\n" + CANON, src, count=1)
    else:
        # Falls die Funktion fehlt, hängen wir sie hinter _on_editor_key() an
        anchor = re.search(r"\n\s*def\s+_on_editor_key\([^\)]*\):[\s\S]*?(?=\n\s*def\s+|\Z)", src, re.MULTILINE)
        if anchor:
            insert_at = anchor.end()
            src = src[:insert_at] + "\n" + CANON + src[insert_at:]
        else:
            # Letzter Fallback: direkt nach _on_editor_paste()
            anchor = re.search(r"\n\s*def\s+_on_editor_paste\([^\)]*\):[\s\S]*?(?=\n\s*def\s+|\Z)", src, re.MULTILINE)
            if anchor:
                insert_at = anchor.end()
                src = src[:insert_at] + "\n" + CANON + src[insert_at:]
            else:
                log("Kein geeigneter Anker gefunden – Abbruch.")
                return 1

    if src != original:
        write_backup(MOD, src)
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.45\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.45 (2025-10-18)
- Intake: _on_editor_modified() korrigiert (Indentation + zuverlässiger Body).
""")
        log("Patch angewendet.")
    else:
        log("Keine Änderungen nötig.")
    return 0

if __name__ == "__main__":
    raise SystemExit(patch())
