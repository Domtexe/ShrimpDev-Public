# -*- coding: utf-8 -*-
"""
R1177m_MainGuiFix
- Behebt IndentationError um nb.add(...).
- Ersetzt defekte _safe_add_intake_tab(...) komplett durch eine saubere, idempotente Version.
- Stellt sicher, dass beide Zeilen
      nb.add(tab_agent, text='Agent')
      nb.add(tab_proj,  text='Project')
  korrekt eingerückt innerhalb von _safe_main() stehen.
Backups -> _Archiv/, Log -> debug_output.txt
"""
from __future__ import annotations
import os, re, shutil, datetime

ROOT   = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
ARCH   = os.path.join(ROOT, "_Archiv")
LOGF   = os.path.join(ROOT, "debug_output.txt")
TARGET = os.path.join(ROOT, "main_gui.py")

def ts(): return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def log(msg: str):
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(f"[{ts()}] [R1177m] {msg}\n")
    except Exception:
        pass

SAFE_FUNC = r'''
# ----- R1177l: zentraler Intake-Mount (idempotent) -----
def _safe_add_intake_tab(nb):
    """Hängt den Intake-Tab an das gegebene ttk.Notebook nb.
    - idempotent (wenn schon vorhanden -> nur select)
    - sauberes Fehler-Logging
    """
    try:
        from tkinter import ttk
        if not isinstance(nb, ttk.Notebook):
            try:
                _log("IntakeMount: nb ist kein Notebook.")
            except Exception:
                pass
            return False
        # Intake schon vorhanden?
        try:
            for i in range(len(nb.tabs())):
                if nb.tab(i, "text") == "Intake":
                    nb.select(i)
                    try: _log("IntakeMount: Tab existiert -> select.")
                    except Exception: pass
                    return True
        except Exception:
            pass
        # Neu montieren
        try:
            from modules.module_shim_intake import mount_intake_tab
        except Exception as e:
            try: _log(f"IntakeMount: Shim-Import fehlgeschlagen: {e}")
            except Exception: pass
            return False
        try:
            mount_intake_tab(nb)
            try: _log("IntakeMount: Tab montiert.")
            except Exception: pass
            return True
        except Exception as e:
            try: _log(f"IntakeMount: Montage-Fehler: {e}")
            except Exception: pass
            return False
    except Exception as e:
        try: _log(f"IntakeMount: Unerwarteter Fehler: {e}")
        except Exception: pass
        return False
# ----- /R1177l -----
'''.lstrip("\n")

def backup(p: str):
    if not os.path.exists(p): return
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(p)}.{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.bak")
    shutil.copy2(p, bak); log(f"Backup: {bak}")

def replace_safe_func(src: str) -> str:
    # Ersetze vorhandenen _safe_add_intake_tab()-Block vollständig
    if re.search(r"def\s+_safe_add_intake_tab\s*\(", src):
        src = re.sub(
            r"(?s)def\s+_safe_add_intake_tab\s*\([\s\S]*?\)\s*:\s*[\s\S]*?#\s*-{5,}\s*/R1177l\s*-{0,}\s*",
            SAFE_FUNC, src, count=1)
    else:
        # Insert vor _safe_main oder am Ende der Imports
        m = re.search(r"def\s+_safe_main\s*\(", src)
        pos = m.start() if m else len(src)
        src = src[:pos] + SAFE_FUNC + src[pos:]
    return src

def fix_nb_add_block(src: str) -> str:
    """
    Stellt sicher, dass innerhalb von _safe_main() die beiden nb.add-Zeilen korrekt
    eingerückt folgen, direkt NACH dem try/except-Block für tab_proj.
    """
    # 1) Entferne evtl. entkoppelte / falsch eingerückte Varianten
    src = re.sub(r"\n# \[R1177l\] \(alt\) Intake-Mount.*", "\n", src)
    src = re.sub(r"\nnb\.add\(tab_agent,[^\n]*\)\s*\n\s*nb\.add\(tab_proj,[^\n]*\)", "", src)

    # 2) Füge korrekten Block an der passenden Stelle ein:
    pattern_after_proj = re.compile(
        r"(ttk\.Label\(tab_proj[^\n]*\)\.pack\([^\n]*\)\s*\n\s*)(?P<indent>\s*)", re.M)
    def repl(m):
        indent = m.group("indent")
        tail = f"{indent}nb.add(tab_agent, text='Agent')\n{indent}nb.add(tab_proj, text='Project')\n"
        return m.group(1) + tail
    src, n = pattern_after_proj.subn(repl, src, count=1)
    if n == 0:
        # Fallback: wenn oben nicht gefunden, setze vor nb.select(0)
        src = re.sub(r"(\n\s*)nb\.select\(0\)", r"\1nb.add(tab_agent, text='Agent')\n\1nb.add(tab_proj, text='Project')\n\1nb.select(0)", src, count=1)
    return src

def main() -> int:
    if not os.path.exists(TARGET):
        print("[R1177m] main_gui.py nicht gefunden."); return 2
    src = open(TARGET, "r", encoding="utf-8").read()
    orig = src
    src = replace_safe_func(src)
    src = fix_nb_add_block(src)
    if src != orig:
        backup(TARGET)
        with open(TARGET, "w", encoding="utf-8") as f: f.write(src)
        log("main_gui.py patched (safe_add_intake_tab replaced + nb.add block fixed).")
    else:
        log("main_gui.py unverändert (Patch nicht notwendig).")
    print("[R1177m] MainGuiFix applied.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
