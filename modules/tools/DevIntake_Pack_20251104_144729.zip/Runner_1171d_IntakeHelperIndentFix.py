# -*- coding: utf-8 -*-
"""
R1171d_IntakeHelperIndentFix
- Sucht den eingefügten R1171a/1171c-Helper-Block.
- Dedentiert den Block auf Top-Level (Einrückung 0) und verschiebt ihn ans Datei-Ende.
- Lässt den R1170e-Lifecycle-Block unberührt.
- Idempotent, mit Backup, Syntax-Check und Rollback.
Exit: 0 OK / 1 Fehler
"""
from __future__ import annotations
import os, re, time, py_compile, traceback

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOG    = os.path.join(ROOT, "debug_output.txt")

MARKERS = [
    "# R1171c: helpers (detect+clean)",
    "# R1171a: helpers (UX & detect)",
]

def _log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1171d {ts}] {msg}\n"
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def _backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "r", encoding="utf-8") as fi, open(dst, "w", encoding="utf-8", newline="") as fo:
        fo.write(fi.read())
    return dst

def _find_helper_block(src: str):
    # Finde Start des Helper-Blocks anhand Marker
    for mk in MARKERS:
        m = re.search(r"(?m)^([ \t]*)" + re.escape(mk) + r"\s*$", src)
        if not m:
            continue
        base_indent = m.group(1)
        start = m.start()
        # Block reicht bis zur nächsten def/class auf Einrückung 0 ODER EOF
        # Robust: suche Ende über zwei aufeinanderfolgende Leerzeilen + nächste Top-Level-Def/Class
        pat_end = re.compile(r"(?m)^(def|class)\b")
        m_end = pat_end.search(src, m.end())
        end = m_end.start() if m_end else len(src)
        return (mk, base_indent, start, end)
    return None

def _dedent_block(block: str) -> str:
    lines = block.splitlines(True)
    # Bestimme minimale gemeinsame Einrückung (Spaces/Tabs gemischt -> zähle führende Spaces/Tabs als Zeichen)
    indents = []
    for ln in lines:
        if ln.strip() == "":
            continue
        pref = len(ln) - len(ln.lstrip(" \t"))
        # nur Zeilen, die mit 'def ' oder nicht Kommentar beginnen, werten
        indents.append(pref)
    min_ind = min(indents) if indents else 0
    if min_ind <= 0:
        return "".join(lines)
    new = []
    for ln in lines:
        if ln.strip() == "":
            new.append(ln.lstrip("\r\n"))  # pure blank lines
        else:
            new.append(ln[min_ind:])
    return "".join(new)

def main() -> int:
    try:
        if not os.path.exists(TARGET):
            _log(f"Zieldatei fehlt: {TARGET}")
            return 1

        src = open(TARGET, "r", encoding="utf-8").read()
        found = _find_helper_block(src)
        if not found:
            _log("Kein R1171a/c-Helper-Block gefunden – keine Änderung notwendig.")
            return 0

        mk, base_indent, start, end = found
        block = src[start:end]
        # Wenn Marker bereits Top-Level ist (keine führenden Whitespaces), nur ans Datei-Ende verschieben.
        need_dedent = len(base_indent) > 0
        new_block = _dedent_block(block) if need_dedent else block

        # Entferne Original-Block
        src_without = src[:start] + src[end:]

        # Trenne mit zwei NL und füge Block am Dateiende ein (Top-Level)
        new_src = src_without.rstrip("\n") + "\n\n" + new_block.lstrip("\n")

        # Zusatz: harte Sicherheit – stelle sicher, dass jede Def-Zeile im Helper bei Spalte 0 beginnt
        def fix_top_level_defs(s: str) -> str:
            return re.sub(r"(?m)^[ \t]+(def[ \t]+_intake_(?:actions_bar_polish|setup_detection)\s*\()", r"\1", s)
        new_src = fix_top_level_defs(new_src)

        # Backup + Schreiben + Syntax-Check
        bak = _backup(TARGET)
        _log(f"Backup erstellt: {bak}")
        with open(TARGET, "w", encoding="utf-8", newline="\n") as f:
            f.write(new_src)

        try:
            py_compile.compile(TARGET, doraise=True)
        except Exception as e:
            with open(bak, "r", encoding="utf-8") as fi, open(TARGET, "w", encoding="utf-8", newline="\n") as fo:
                fo.write(fi.read())
            _log("Syntax-Check FEHLER -> Rollback auf Backup.")
            _log("Traceback:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 1

        _log(f"Helper-Block '{mk}' dedentiert & ans Datei-Ende verschoben. Syntax-Check OK.")
        return 0

    except Exception as e:
        _log("UNERWARTETER FEHLER:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
