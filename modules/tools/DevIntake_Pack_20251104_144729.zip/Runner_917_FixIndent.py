from __future__ import annotations
from pathlib import Path
import re, shutil, time

ROOT = Path(r"D:\ShrimpDev")
MAIN = ROOT / "main_gui.py"

def ts(): return time.strftime("%Y%m%d_%H%M%S")
def backup(p: Path) -> Path:
    b = p.with_suffix(p.suffix + f".{ts()}.bak")
    shutil.copy2(p, b); return b

def fix_indent():
    if not MAIN.exists():
        print("[R917] main_gui.py fehlt")
        return 2

    txt = MAIN.read_text(encoding="utf-8", errors="ignore")

    # --- 1. Doppelte / falsche Einrückungen nach class / def prüfen ---
    lines = txt.splitlines()
    fixed = []
    for i, ln in enumerate(lines):
        if i == 0:
            fixed.append(ln)
            continue
        # normalize indentation: max 8 spaces for methods
        if re.match(r"^\s{12,}self\.", ln):
            ln = re.sub(r"^\s{12,}", "        ", ln)
        fixed.append(ln)

    new_txt = "\n".join(fixed)

    # --- 2. falls class ShrimpDevApp def __init__ block defekt ---
    new_txt = re.sub(
        r"class\s+ShrimpDevApp\(tk\.Tk\):\s*\n\s*def\s+__init__",
        "class ShrimpDevApp(tk.Tk):\n    def __init__",
        new_txt
    )

    # --- 3. prüfen ob das Quiet-Mode-Menü noch korrekt ist ---
    if "m_view.add_checkbutton" in new_txt and "Quiet Mode" not in new_txt:
        new_txt = new_txt.replace(
            "m_view.add_checkbutton",
            'm_view.add_checkbutton(label="Quiet Mode", '
            'onvalue=True, offvalue=False, '
            'variable=self.var_quiet, command=self.toggle_quiet)'
        )

    # --- 4. Backup und schreiben ---
    b = backup(MAIN)
    MAIN.write_text(new_txt, encoding="utf-8")
    print(f"[R917] Fix angewendet. Backup: {b.name}")
    return 0

if __name__ == "__main__":
    fix_indent()
