# -*- coding: utf-8 -*-
"""
Runner_1074_DeleteButtons_WithRecycleBin
- Fügt zwei Buttons hinzu:
  * "Code löschen"  -> Editor leeren, Felder resetten
  * "Datei löschen" -> selektierte Items der rechten Liste in Windows-Papierkorb
- Kontextsensitiv: Entf auf Text löscht Code, Entf auf Liste löscht Datei(en)
- Fügt Helper send_to_recycle_bin() via ctypes.SHFileOperationW hinzu (keine Fremdpakete)
- Sichert Datei, prüft AST
"""

from __future__ import annotations
import os, re, time, shutil, ast

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1074] {ts} {msg}\n")
    except Exception:
        pass

def rd(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f: return f.read()

def wr_with_backup(p: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bak)
    log(f"Backup: {p} -> {bak}")
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

def norm(src: str) -> str:
    src = src.replace("\r\n", "\n").replace("\r", "\n")
    src = "\n".join(ln.rstrip(" \t") for ln in src.split("\n"))
    src = src.replace("\t", "    ")
    if not src.endswith("\n"): src += "\n"
    return src

# ---------------------------------------------------------------------------

def ensure_helper_recycle(src: str) -> tuple[str, int]:
    if "def send_to_recycle_bin(" in src:
        return src, 0
    code = (
        "\n"
        "def send_to_recycle_bin(path: str) -> bool:\n"
        "    \"\"\"Verschiebt Datei/Ordner unter Windows in den Papierkorb (Recycle Bin).\"\"\"\n"
        "    try:\n"
        "        import ctypes, ctypes.wintypes as wt\n"
        "        FO_DELETE = 3\n"
        "        FOF_ALLOWUNDO = 0x0040\n"
        "        FOF_NOCONFIRMATION = 0x0010\n"
        "        class SHFILEOPSTRUCTW(ctypes.Structure):\n"
        "            _fields_ = [\n"
        "                (\"hwnd\", wt.HWND), (\"wFunc\", wt.UINT),\n"
        "                (\"pFrom\", wt.LPCWSTR), (\"pTo\", wt.LPCWSTR),\n"
        "                (\"fFlags\", wt.USHORT), (\"fAnyOperationsAborted\", wt.BOOL),\n"
        "                (\"hNameMappings\", wt.LPVOID), (\"lpszProgressTitle\", wt.LPCWSTR),\n"
        "            ]\n"
        "        op = SHFILEOPSTRUCTW()\n"
        "        op.hwnd = None\n"
        "        op.wFunc = FO_DELETE\n"
        "        # doppelt Null-terminiert (Mehrfachauswahl-Format)\n"
        "        op.pFrom = path + \"\\x00\\x00\"\n"
        "        op.pTo = None\n"
        "        op.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION\n"
        "        res = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))\n"
        "        return res == 0 and not bool(op.fAnyOperationsAborted)\n"
        "    except Exception:\n"
        "        return False\n"
    )
    # vor dem Ende der Datei einfügen
    return src + code, 1

def inject_buttons_and_binds(src: str) -> tuple[str, int]:
    changed = 0
    # Toolbar-Frame 'bar' finden
    m_bar = re.search(r'^\s*bar\s*=\s*ttk\.Frame\(self\)', src, re.MULTILINE)
    if not m_bar:
        log("WARN: Toolbar 'bar = ttk.Frame(self)' nicht gefunden.")
        return src, 0

    # Stelle der vorhandenen Buttons finden (Guard/Save/Delete etc.)
    # Wir hängen unsere Buttons hinter existierende Grid-Zeilen an.
    insert_pos = m_bar.end()
    block_end = re.search(r'^\s*body\s*=\s*ttk\.Panedwindow\(', src[m_bar.end():], re.MULTILINE)
    if block_end:
        insert_pos = m_bar.end() + block_end.start()
    inject = (
        "\n"
        "        # --- Delete-Buttons ---\n"
        "        # Code löschen (Editor leeren)\n"
        "        if not hasattr(self, 'btn_clear_code'):\n"
        "            self.btn_clear_code = ttk.Button(bar, text=\"Code löschen\", command=self._on_click_clear_code)\n"
        "            self.btn_clear_code.grid(row=0, column=101, padx=(4,0), sticky=\"w\")\n"
        "        # Datei löschen (rechte Liste -> Papierkorb)\n"
        "        if not hasattr(self, 'btn_del_file'):\n"
        "            self.btn_del_file = ttk.Button(bar, text=\"Datei löschen\", command=self._on_click_delete_file)\n"
        "            self.btn_del_file.grid(row=0, column=102, padx=(4,0), sticky=\"w\")\n"
        "\n"
        "        # Entf kontextsensitiv binden\n"
        "        try:\n"
        "            self.txt.bind(\"<Delete>\", lambda e: self._on_click_clear_code() or \"break\")\n"
        "        except Exception:\n"
        "            pass\n"
        "        try:\n"
        "            if hasattr(self, 'tv'):\n"
        "                self.tv.bind(\"<Delete>\", lambda e: self._on_click_delete_file() or \"break\")\n"
        "        except Exception:\n"
        "            pass\n"
    )
    src = src[:insert_pos] + inject + src[insert_pos:]
    changed += 1
    return src, changed

def ensure_clear_code_handler(src: str) -> tuple[str, int]:
    if re.search(r'^\s*def\s+_on_click_clear_code\s*\(', src, re.MULTILINE):
        return src, 0
    code = (
        "\n"
        "    def _on_click_clear_code(self):\n"
        "        \"\"\"Leert den Editor und setzt Name/Endung zurück.\"\"\"\n"
        "        try:\n"
        "            try:\n"
        "                self.txt.delete('1.0', 'end')\n"
        "            except Exception:\n"
        "                pass\n"
        "            try:\n"
        "                if hasattr(self, 'var_name'): self.var_name.set('')\n"
        "                if hasattr(self, 'var_ext'): self.var_ext.set('.py')\n"
        "            except Exception:\n"
        "                pass\n"
        "            self._ping('Editor geleert.')\n"
        "        except Exception as ex:\n"
        "            try: self._ping(f'Clear-Fehler: {ex}')\n"
        "            except Exception: pass\n"
    )
    # Vor Klassenende einfügen
    m_cls = re.search(r'^\s*class\s+IntakeFrame\s*\(.*?\):', src, re.MULTILINE)
    insert_at = len(src)
    if m_cls:
        m_next = re.search(r'^\s*class\s+\w+\s*\(', src[m_cls.end():], re.MULTILINE)
        if m_next:
            insert_at = m_cls.end() + m_next.start()
    src = src[:insert_at] + code + src[insert_at:]
    return src, 1

def ensure_delete_file_handler(src: str) -> tuple[str, int]:
    if re.search(r'^\s*def\s+_on_click_delete_file\s*\(', src, re.MULTILINE):
        return src, 0
    code = (
        "\n"
        "    def _on_click_delete_file(self):\n"
        "        \"\"\"Löscht markierte Datei(en) der rechten Liste in den Papierkorb und aktualisiert die Liste.\"\"\"\n"
        "        try:\n"
        "            if not hasattr(self, 'tv'):\n"
        "                self._ping('Liste nicht verfügbar.')\n"
        "                return\n"
        "            items = self.tv.selection()\n"
        "            if not items:\n"
        "                self._ping('Keine Auswahl in der Liste.')\n"
        "                return\n"
        "            import os\n"
        "            tgt = getattr(self, 'var_target', None)\n"
        "            base = tgt.get().strip() if (tgt and tgt.get().strip()) else os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tools'))\n"
        "            ok_all = True\n"
        "            for iid in items:\n"
        "                vals = self.tv.item(iid, 'values')\n"
        "                # erwartete Spalten: name, ext, subfolder, date, time\n"
        "                try:\n"
        "                    name = vals[0]\n"
        "                    ext  = vals[1]\n"
        "                    sub  = vals[2] if len(vals) > 2 else ''\n"
        "                except Exception:\n"
        "                    continue\n"
        "                if not ext.startswith('.'): ext = '.' + ext\n"
        "                rel = os.path.join(sub, name + ext) if sub else name + ext\n"
        "                path = os.path.join(base, rel)\n"
        "                if os.path.exists(path):\n"
        "                    if not send_to_recycle_bin(path):\n"
        "                        ok_all = False\n"
        "                else:\n"
        "                    ok_all = False\n"
        "            # Refresh Liste\n"
        "            try:\n"
        "                if hasattr(self, '_refresh_saved_files'):\n"
        "                    self._refresh_saved_files()\n"
        "            except Exception:\n"
        "                pass\n"
        "            self._ping('Gelöscht.' if ok_all else 'Einige Dateien konnten nicht gelöscht werden.')\n"
        "        except Exception as ex:\n"
        "            try: self._ping(f'Löschen-Fehler: {ex}')\n"
        "            except Exception: pass\n"
    )
    # Vor Klassenende einfügen
    m_cls = re.search(r'^\s*class\s+IntakeFrame\s*\(.*?\):', src, re.MULTILINE)
    insert_at = len(src)
    if m_cls:
        m_next = re.search(r'^\s*class\s+\w+\s*\(', src[m_cls.end():], re.MULTILINE)
        if m_next:
            insert_at = m_cls.end() + m_next.start()
    src = src[:insert_at] + code + src[insert_at:]
    return src, 1

# ---------------------------------------------------------------------------

def main() -> int:
    if not os.path.exists(MOD):
        log(f"Datei fehlt: {MOD}")
        return 2
    s0 = rd(MOD)
    s = norm(s0)

    total = 0
    s, n = ensure_helper_recycle(s);           total += n
    s, n = inject_buttons_and_binds(s);        total += n
    s, n = ensure_clear_code_handler(s);       total += n
    s, n = ensure_delete_file_handler(s);      total += n

    # AST-Check
    try:
        ast.parse(s)
    except SyntaxError as e:
        log(f"SyntaxError nach Patch: {e} (line {e.lineno}, col {getattr(e,'offset',0)})")
        lines = s.split("\n")
        a, b = max(1, (e.lineno or 1)-10), min(len(lines), (e.lineno or 1)+10)
        log("--- DUMP ---")
        for i in range(a, b+1):
            vis = lines[i-1].replace("\t", "→").replace(" ", "·")
            log(f"{i:04d}: {vis}")
        log("--- END DUMP ---")
        return 3

    if total == 0 and s == s0:
        log("Keine Änderungen nötig.")
        return 0

    wr_with_backup(MOD, s)
    log(f"Patch gespeichert. Änderungen: {total}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
