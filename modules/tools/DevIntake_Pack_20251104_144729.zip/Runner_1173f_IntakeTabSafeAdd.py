# -*- coding: utf-8 -*-
"""
1173f: Patcht main_gui.py idempotent:
- Fügt _mount_intake_tab_safe(parent) + _safe_add_intake_tab(nb) ein, falls nicht vorhanden
- Führt KEINE destruktiven Änderungen an anderen Tabs durch
- Syntax-Check + Rollback wird über .bat gehandhabt
"""
import io, os, re, sys, traceback, py_compile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC  = os.path.join(ROOT, "main_gui.py")
DBG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str):
    try:
        with io.open(DBG, "a", encoding="utf-8") as f:
            f.write(f"[1173f] {msg}\n")
    except Exception:
        pass

def read(p): 
    with io.open(p, "r", encoding="utf-8") as f: 
        return f.read()

def write(p, s):
    with io.open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)

code = read(SRC)

# 1) Bereits vorhanden?
has_mount = re.search(r"def\s+_mount_intake_tab_safe\s*\(\s*parent\s*\)\s*:", code)
has_add   = re.search(r"def\s+_safe_add_intake_tab\s*\(\s*nb\s*\)\s*:", code)

insertion_block = r'''
def _mount_intake_tab_safe(parent):
    """
    Lazy-Mount des IntakeFrames in 'parent'.
    Fehler robust abfangen und Diagnose in debug_output.txt schreiben.
    """
    import traceback
    import tkinter as tk
    from tkinter import ttk
    try:
        from modules.module_code_intake import IntakeFrame  # späte Bindung
        child = IntakeFrame(parent)
        try:
            child.pack(fill="both", expand=True)
        except Exception:
            # Falls Widget eine andere Attach-Methode nutzt, zumindest anzeigen
            for meth in ("pack", "grid", "place"):
                if hasattr(child, meth):
                    try:
                        getattr(child, meth)(**({"fill":"both","expand":True} if meth=="pack" else {}))
                        break
                    except Exception:
                        pass
        _msg = "GUI: IntakeFrame geladen (lazy)."
        try:
            with open(r"''' + DBG.replace("\\","\\\\") + r'''", "a", encoding="utf-8") as _f:
                _f.write("[1173f] " + _msg + "\n")
        except Exception:
            pass
    except Exception as ex:
        _text = "Fehler beim Laden des Intake-Tabs. Details siehe debug_output.txt"
        lbl = tk.Label(parent, text=_text, fg="red", justify="left", anchor="w")
        lbl.pack(fill="both", expand=True, padx=12, pady=12)
        try:
            with open(r"''' + DBG.replace("\\","\\\\") + r'''", "a", encoding="utf-8") as _f:
                _f.write("[1173f] Intake-Load-ERR:\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)) + "\n")
        except Exception:
            pass

def _safe_add_intake_tab(nb):
    """
    Hängt den Intake-Tab korrekt ans Notebook und mountet den Inhalt verzögert.
    Idempotent: legt genau EINEN Tab mit Titel 'Code Intake' an, falls fehlend.
    """
    from tkinter import ttk
    # Prüfen, ob es bereits einen 'Code Intake'-Tab gibt
    try:
        for i in range(len(nb.tabs())):
            # ttk.Notebook liefert Tab-Ids; text holen:
            try:
                if nb.tab(i, "text") == "Code Intake":
                    return  # schon vorhanden
            except Exception:
                pass
    except Exception:
        pass

    tab = ttk.Frame(nb)
    nb.add(tab, text="Code Intake")    # wichtig: echtes Fenster als 'child'
    body = ttk.Frame(tab)
    body.pack(fill="both", expand=True)
    # Lazy-Mount erst NACH dem Add, damit parent ein echtes, gemountetes Widget ist
    try:
        tab.after(50, lambda: _mount_intake_tab_safe(body))
    except Exception:
        # Fallback ohne after
        _mount_intake_tab_safe(body)
'''

# 2) Einfügen hinter den bestehenden lokalen Helper-Bereich (vor _safe_main),
#    ansonsten nahe vor dem Ende.
insert_pos = None
m = re.search(r"(?:def\s+_shrimpdev__central_tk_guard__\s*\(.*?\)\s*:\s*.*?)(?=\n\S)", code, re.S)
if m: 
    insert_pos = m.end()
else:
    insert_pos = len(code)

new_code = code
changed = False
if not has_mount or not has_add:
    new_code = new_code[:insert_pos] + "\n\n" + insertion_block + "\n\n" + new_code[insert_pos:]
    changed = True

# 3) Sicherstellen, dass im _safe_main die Intake-Tab-Erzeugung über _safe_add_intake_tab(nb) läuft.
#    (Call soll existieren; wir erzwingen ihn idempotent direkt NACH Notebook-Erzeugung.)
safe_main_pat = re.compile(r"def\s+_safe_main\s*\(\s*\)\s*:\s*(.*?)\Z", re.S)
m2 = safe_main_pat.search(new_code)
if m2:
    block = m2.group(1)
    # Notebook-Objekt-Name ermitteln (sehr defensiv)
    nb_name = "nb"
    if "ttk.Notebook(" in block:
        # wir gehen von 'nb =' aus, andernfalls nutzen wir 'nb' als Default
        mnb = re.search(r"(\w+)\s*=\s*ttk\.Notebook\(", block)
        if mnb:
            nb_name = mnb.group(1)

    # Gewährleisten, dass der Call vorkommt
    if f"_safe_add_intake_tab({nb_name})" not in block:
        # Einfügen direkt nach Notebook-Erzeugung
        block = re.sub(r"(ttk\.Notebook\(.*?\)\)\s*\n)", r"\1    _safe_add_intake_tab(" + nb_name + r")\n", block, count=1)
        new_code = new_code[:m2.start(1)] + block + new_code[m2.end(1):]
        changed = True

if not changed:
    print("[1173f] Keine Änderung notwendig (idempotent).")
    sys.exit(0)

write(SRC, new_code)

# 4) Syntax-Check
try:
    py_compile.compile(SRC, doraise=True)
    print("[1173f] Syntax OK.")
except Exception as ex:
    log("Syntax-Check FEHLER:\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
    raise
