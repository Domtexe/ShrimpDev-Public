# -*- coding: utf-8 -*-
"""
Runner_1135_ModulesInitAndDiagnose
Ziel:
- Sicherstellen, dass 'modules' ein importierbares Paket ist (mit __init__.py).
- Sicherstellen, dass 'modules/module_runner_exec.py' existiert (Stub, falls fehlt).
- Danach: Import von modules.module_code_intake und Instanziierung von IntakeFrame testen.
- Report schreibt nach _Reports/Runner_1135_ModulesInitAndDiagnose_report.txt

Exitcodes:
  0 = OK (IntakeFrame instanziiert)
  1 = Fehler (siehe Report)
  2 = Grundlegende Struktur fehlt
"""

from __future__ import annotations
import sys, os, time, traceback, importlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD_DIR = ROOT / "modules"
MOD_FILE = MOD_DIR / "module_code_intake.py"
PKG_INIT = MOD_DIR / "__init__.py"
RUNNER_EXEC = MOD_DIR / "module_runner_exec.py"

REPORTS = ROOT / "_Reports"
REPORTS.mkdir(exist_ok=True)
REPORT = REPORTS / "Runner_1135_ModulesInitAndDiagnose_report.txt"

def w(msg: str) -> None:
    with open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip() + "\n")

def ensure_pkg_and_stub() -> None:
    """legt __init__.py und Stub fuer module_runner_exec an, falls sie fehlen"""
    if not PKG_INIT.exists():
        PKG_INIT.write_text("# auto-created package marker\n", encoding="utf-8", newline="\n")
        w(f"[Create] {PKG_INIT}")

    if not RUNNER_EXEC.exists():
        RUNNER_EXEC.write_text(
            "# auto-created stub for module_runner_exec\n"
            "def subst(*args, **kwargs):\n"
            "    # simple passthrough of first arg, used by callers that expect string substitution\n"
            "    return args[0] if args else \"\"\n",
            encoding="utf-8",
            newline="\n",
        )
        w(f"[Create] {RUNNER_EXEC}")

def diagnose() -> int:
    with open(REPORT, "w", encoding="utf-8", newline="\n") as f:
        f.write(f"Runner_1135_ModulesInitAndDiagnose {time.strftime('%Y-%m-%d %H:%M:%S')}\n")

    if not MOD_FILE.exists():
        w(f"[FAIL] Datei fehlt: {MOD_FILE}")
        return 2

    # Projekt-Root an den Anfang des sys.path setzen
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
        w(f"[sys.path+] {ROOT}")

    ensure_pkg_and_stub()

    # Sauber importieren
    try:
        if "modules.module_code_intake" in sys.modules:
            del sys.modules["modules.module_code_intake"]
        m = importlib.import_module("modules.module_code_intake")
        w("[Import] OK: modules.module_code_intake")
    except Exception:
        w("[Import-Error]\n" + "".join(traceback.format_exc()))
        return 1

    # Klasse pruefen
    IntakeFrame = getattr(m, "IntakeFrame", None)
    if IntakeFrame is None:
        w("[FAIL] 'IntakeFrame' nicht in module_code_intake gefunden.")
        return 1

    # Instanzierungsprobe headless
    try:
        import tkinter as tk
        root = tk.Tk(); root.withdraw()
        host = tk.Frame(root); host.pack()
        IntakeFrame(host)  # __init__ darf nicht werfen
        try:
            root.destroy()
        except Exception:
            pass
        w("[OK] IntakeFrame erfolgreich instanziiert.")
        return 0
    except Exception:
        w("[Instantiate-Error]\n" + "".join(traceback.format_exc()))
        return 1

def main() -> int:
    rc = diagnose()
    if rc == 0:
        print("[R1135] Intake OK.")
    else:
        print("[R1135] Intake weiterhin defekt – siehe Report.")
    return rc

if __name__ == "__main__":
    raise SystemExit(main())
