# -*- coding: utf-8 -*-
"""
[1174h] IntakeHardReset
- Sichert modules/module_code_intake.py nach _Archiv
- Schreibt eine stabile, kompakte IntakeFrame-Implementierung
- Syntax-Check via py_compile; bei Fehler: Rollback
"""
from __future__ import annotations
import os, time, shutil, py_compile, tempfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
MODS = os.path.join(ROOT, "modules")
TARGET = os.path.join(MODS, "module_code_intake.py")
ARCHIV = os.path.join(ROOT, "_Archiv")
os.makedirs(ARCHIV, exist_ok=True)

SAFE_SRC = r'''# -*- coding: utf-8 -*-
from __future__ import annotations
import os, time
import tkinter as tk
from tkinter import ttk, filedialog

_PADX, _PADY = 8, 6

class IntakeFrame(ttk.Frame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self._build_ui()

    def _build_ui(self):
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        head = ttk.Frame(self)
        head.grid(row=0, column=0, sticky="ew", padx=_PADX, pady=(_PADY,4))
        head.columnconfigure(1, weight=1)

        ttk.Label(head, text="Zielordner:").grid(row=0, column=0, sticky="w")
        self.var_target = tk.StringVar(value=os.path.join(os.getcwd(), "tools"))
        ent = ttk.Entry(head, textvariable=self.var_target)
        ent.grid(row=0, column=1, sticky="ew", padx=(4,8))
        ttk.Button(head, text="...", width=3, command=self._pick_target).grid(row=0, column=2)

        bar = ttk.Frame(self)
        bar.grid(row=1, column=0, sticky="ew", padx=_PADX, pady=(0,4))
        ttk.Button(bar, text="Aktualisieren", command=self._on_click_refresh).grid(row=0, column=0, padx=(0,6))
        ttk.Button(bar, text="Ordner öffnen", command=self._open_target).grid(row=0, column=1)
        self.lbl_status = ttk.Label(bar, text="Bereit."); self.lbl_status.grid(row=0, column=2, padx=12)

        body = ttk.Panedwindow(self, orient="horizontal")
        body.grid(row=2, column=0, sticky="nsew", padx=_PADX, pady=(0,_PADY))

        left = ttk.Frame(body); left.rowconfigure(0, weight=1); left.columnconfigure(0, weight=1)
        self.txt = tk.Text(left, wrap="none", font=("Consolas", 10), undo=True)
        self.txt.grid(row=0, column=0, sticky="nsew")
        y1 = ttk.Scrollbar(left, orient="vertical", command=self.txt.yview)
        self.txt.configure(yscrollcommand=y1.set); y1.grid(row=0, column=1, sticky="ns")
        body.add(left, weight=3)

        right = ttk.Frame(body); right.rowconfigure(0, weight=1); right.columnconfigure(0, weight=1)
        cols = ("name","ext","subfolder","date","time")
        self.tbl = ttk.Treeview(right, columns=cols, show="headings", selectmode="browse")
        for c,w,a in (("name",240,"w"),("ext",70,"center"),("subfolder",180,"w"),("date",110,"center"),("time",90,"center")):
            self.tbl.heading(c, text=c)
            self.tbl.column(c, width=w, anchor=a, stretch=(c!="ext"))
        self.tbl.grid(row=0, column=0, sticky="nsew")
        y2 = ttk.Scrollbar(right, orient="vertical", command=self.tbl.yview)
        self.tbl.configure(yscrollcommand=y2.set); y2.grid(row=0, column=1, sticky="ns")
        body.add(right, weight=2)

        self._on_click_refresh()

    # --- helpers ---
    def _pick_target(self):
        d = filedialog.askdirectory(title="Zielordner wählen", initialdir=self.var_target.get() or os.getcwd())
        if d:
            self.var_target.set(d)

    def _open_target(self):
        p = self.var_target.get().strip() or "."
        try:
            os.startfile(p)
        except Exception:
            pass

    def _on_click_refresh(self):
        base = self.var_target.get().strip()
        rows = []
        if os.path.isdir(base):
            ALLOWED = {".py",".bat",".cmd",".json",".yml",".yaml",".ini",".md"}
            for root, dirs, files in os.walk(base):
                depth = os.path.relpath(root, base).count(os.sep)
                if depth > 3:
                    del dirs[:]; continue
                sub = "" if os.path.samefile(root, base) else os.path.relpath(root, base)
                for fn in files:
                    name, ext = os.path.splitext(fn); ext = ext.lower()
                    if ext not in ALLOWED: continue
                    fp = os.path.join(root, fn)
                    ts = time.localtime(os.path.getmtime(fp))
                    d  = time.strftime("%Y-%m-%d", ts)
                    t  = time.strftime("%H:%M:%S", ts)
                    rows.append((name, ext, sub, d, t))
        # table fill
        try:
            self.tbl.delete(*self.tbl.get_children())
            for r in sorted(rows, key=lambda r:(r[2], r[0], r[1])):
                self.tbl.insert("", "end", values=r)
            self.lbl_status.configure(text=f"{len(rows)} Einträge")
        except Exception:
            pass
'''

def log(msg: str):
    try:
        with open(os.path.join(ROOT, "debug_output.txt"), "a", encoding="utf-8") as f:
            ts = time.strftime("%Y-%m-%d %H:%M:%S")
            f.write(f"[1174h] {ts} {msg}\n")
    except Exception:
        pass

def main() -> int:
    log("Beginne HardReset für module_code_intake.py")
    if not os.path.isfile(TARGET):
        log("WARN: module_code_intake.py fehlt – lege neu an.")

    # Backup
    try:
        if os.path.exists(TARGET):
            ts = str(int(time.time()))
            bak = os.path.join(ARCHIV, f"module_code_intake.py.{ts}.bak")
            shutil.copy2(TARGET, bak)
            log(f"Backup erstellt: {bak}")
    except Exception as ex:
        log(f"Backup-Fehler: {ex}")

    # Schreibe TMP + Syntax-Check
    tmp_fd, tmp_path = tempfile.mkstemp(prefix="module_code_intake.py.", suffix=".tmp", dir=MODS)
    os.close(tmp_fd)
    try:
        with open(tmp_path, "w", encoding="utf-8", newline="\n") as f:
            f.write(SAFE_SRC)
        # Syntax-Check
        py_compile.compile(tmp_path, doraise=True)
    except Exception as ex:
        log(f"Syntax-Check FEHLER: {ex}")
        try:
            os.remove(tmp_path)
        except Exception:
            pass
        return 2

    # Austausch
    try:
        shutil.move(tmp_path, TARGET)
        log("Neue Intake-Version übernommen (stabile Minimal-UI).")
    except Exception as ex:
        log(f"Move/Rename-Fehler: {ex}")
        try:
            os.remove(tmp_path)
        except Exception:
            pass
        return 3

    return 0

if __name__ == "__main__":
    import sys
    sys.exit(main())
