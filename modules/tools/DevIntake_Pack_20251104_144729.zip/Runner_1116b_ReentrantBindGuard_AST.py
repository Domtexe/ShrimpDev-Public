# -*- coding: utf-8 -*-
"""
Runner_1116b_ReentrantBindGuard_AST.py

- Fügt _reentrant_guard-Decorator ein (falls fehlt).
- Dekoriert vorhandene Click-Handler (@_reentrant_guard).
- Entfernt doppelte ButtonRelease-1 Binds an bekannten Buttons.
- Ergänzt command=self._on_click_* an ttk.Button(...), falls nicht vorhanden.
- Idempotent + Syntax-Check + Backup.
"""
from __future__ import annotations
import os, re, ast, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
os.makedirs(ARCH, exist_ok=True)

def read(p): 
    with open(p,"r",encoding="utf-8") as f: return f.read()
def write(p,s):
    with open(p,"w",encoding="utf-8",newline="\n") as f: f.write(s)
def backup(p):
    q=os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak"); shutil.copy2(p,q); return q
def syntax_ok(code): 
    try: ast.parse(code); return True
    except Exception as ex: print("[R1116b] SyntaxError:", ex); return False

src = read(MOD)
orig = src

changed = False

# 1) Decorator einfügen (falls fehlt)
if "_reentrant_guard" not in src:
    # nach __future__-Imports einsetzen
    m = re.search(r"(?ms)^(from __future__.+?\n)+", src)
    insert_at = m.end() if m else 0
    guard = r'''
def _reentrant_guard(fn):
    """Verhindert re-entrante Aufrufe desselben Handlers; setzt Flag nach idle zurück."""
    name = getattr(fn, "__name__", "handler")
    flag_attr = f"_busy__{name}"
    def _wrap(self, *a, **kw):
        try:
            if getattr(self, flag_attr, False):
                return
        except Exception:
            return fn(self, *a, **kw)
        setattr(self, flag_attr, True)
        try:
            return fn(self, *a, **kw)
        finally:
            try:
                self.after_idle(lambda: setattr(self, flag_attr, False))
            except Exception:
                setattr(self, flag_attr, False)
    return _wrap
'''
    src = src[:insert_at] + guard + src[insert_at:]
    changed = True

# 2) Handler mit Decorator versehen
handlers = [
    "_on_click_detect",
    "_on_click_save",
    "_on_click_delete",
    "_on_click_guard",
    "_on_click_run",
]
for h in handlers:
    patt_def = rf"(?ms)^\s*def\s+{h}\s*\("
    patt_deco = rf"(?ms)^\s*@_reentrant_guard\s*\n\s*def\s+{h}\s*\("
    if re.search(patt_def, src) and not re.search(patt_deco, src):
        src = re.sub(patt_def, f"@_reentrant_guard\ndef {h}(", src, count=1)
        changed = True

# 3) Doppelte ButtonRelease-1-Binds raus
btn_map = {
    "btn_detect": "_on_click_detect",
    "btn_save":   "_on_click_save",
    "btn_del":    "_on_click_delete",
    "btn_guard":  "_on_click_guard",
    "btn_run":    "_on_click_run",
}
for btn, _ in btn_map.items():
    bind_rx = rf'(?m)^\s*self\.{btn}\.bind\(\s*["\']<ButtonRelease-1>["\']\s*,.*?\)\s*$'
    if re.search(bind_rx, src):
        src = re.sub(bind_rx, "", src)
        changed = True

# 4) command= an ttk.Button(...) ergänzen (falls fehlt)
for btn, handler in btn_map.items():
    rx = rf'(?ms)(self\.{btn}\s*=\s*ttk\.Button\((?P<args>.*?)\))'
    def _fix(m):
        call = m.group(0)
        args = m.group("args")
        if "command=" in args:
            return call
        # robust hinten anhängen (vor letzter Klammer)
        return call[:-1] + f', command=self.{handler})'
    new_src, n = re.subn(rx, _fix, src)
    if n:
        src = new_src
        changed = True

# 5) kosmetik: überflüssige Leerzeilen zusammenziehen
if changed:
    src = re.sub(r"\n{3,}", "\n\n", src)

if changed:
    if syntax_ok(src):
        bak = backup(MOD)
        write(MOD, src)
        print(f"[R1116b] Guard/Binds repariert. Backup: {bak}")
    else:
        print("[R1116b] Abgebrochen (Syntax). Datei unverändert.")
else:
    print("[R1116b] Keine Änderungen nötig.")
