"""
Runner_1002_SnippetsRestore
- Stellt fehlende Snippets wieder her: logger_snippet.py, file_detect_snippet.py
- Version -> v9.8.4
"""
from __future__ import annotations
import os, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1002] {ts} {msg}\n")
    print(msg, flush=True)

def safe_write(path: str, data: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        os.makedirs(ARCH, exist_ok=True)
        bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
        shutil.copy2(path, bck)
        log(f"Backup: {path} -> {bck}")
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

LOGGER_SNIPPET = r'''"""Zentraler Logger für ShrimpDev."""
from __future__ import annotations
import os, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
LOG_PATH = os.path.join(ROOT, "debug_output.txt")

def write_log(prefix: str, msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(f"[{prefix}] {ts} {msg}\n")
'''

FILE_DETECT_SNIPPET = r'''"""Robuste Dateiname/Endung-Erkennung."""
from __future__ import annotations
import os
from typing import Tuple

ALLOWED_EXTS = {".py", ".bat", ".cmd", ".json", ".txt", ".yml", ".yaml", ".ini", ".md", ".shcut"}

def split_name_ext(path: str) -> Tuple[str, str]:
    base = os.path.basename(path).strip()
    name, ext = os.path.splitext(base)
    return name, ext.lower()

def classify(path: str) -> str:
    _, ext = split_name_ext(path)
    if not ext:
        return "unknown"
    if ext in {".py"}: return "python"
    if ext in {".bat", ".cmd"}: return "batch"
    if ext in {".json", ".shcut"}: return "plan"
    if ext in {".ini"}: return "config"
    if ext in {".md", ".txt"}: return "doc"
    return "other"

def is_supported(path: str) -> bool:
    return split_name_ext(path)[1] in ALLOWED_EXTS
'''

MAIN_GUI_MIN_LOG_FALLBACK = r'''# --- Minimaler Fallback-Logger, falls Snippet nicht importierbar ist ---
def _fallback_write_log(prefix: str, msg: str) -> None:
    import os, time
    root = os.path.abspath(os.path.dirname(__file__))
    logp = os.path.join(root, "debug_output.txt")
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(logp, "a", encoding="utf-8") as f:
            f.write(f"[{prefix}] {ts} {msg}\n")
    except Exception:
        pass
'''

def patch() -> int:
    try:
        # Snippets wiederherstellen
        safe_write(os.path.join(ROOT, "modules", "snippets", "logger_snippet.py"), LOGGER_SNIPPET)
        safe_write(os.path.join(ROOT, "modules", "snippets", "file_detect_snippet.py"), FILE_DETECT_SNIPPET)

        # main_gui: Fallback-Logger einbauen, falls noch nicht vorhanden; Versionsbump
        gpath = os.path.join(ROOT, "main_gui.py")
        with open(gpath, "r", encoding="utf-8") as f:
            gui = f.read()

        if "_fallback_write_log" not in gui:
            gui = gui.replace(
                "from modules.snippets.logger_snippet import write_log",
                "try:\n    from modules.snippets.logger_snippet import write_log\nexcept Exception:\n    " + MAIN_GUI_MIN_LOG_FALLBACK + "\n    write_log = _fallback_write_log"
            )
        gui = gui.replace("ShrimpDev – v9.8.3", "ShrimpDev – v9.8.4")
        safe_write(gpath, gui)

        # Meta
        safe_write(os.path.join(ROOT, "CURRENT_VERSION.txt"), "ShrimpDev v9.8.4\n")
        chg = os.path.join(ROOT, "CHANGELOG.md")
        with open(chg, "a", encoding="utf-8") as f:
            f.write("""
## v9.8.4 (2025-10-18)
- FIX: Snippets automatisch wiederhergestellt (logger_snippet, file_detect_snippet)
- GUI: Fallback-Logger in main_gui (startet auch ohne Snippet), Versionsbump
""")

        log("Patch erfolgreich.")
        return 0
    except Exception:
        import traceback
        log("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(patch())
