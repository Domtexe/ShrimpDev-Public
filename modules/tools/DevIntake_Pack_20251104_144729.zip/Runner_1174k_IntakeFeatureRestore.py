# -*- coding: utf-8 -*-
"""
[1174k] IntakeFeatureRestore
- Repariert modules/module_code_intake.py:
  * _open_explorer_select() sauber neu
  * Fehlplatzierten Reflow-Aufruf im _build_ui-Header entfernen
  * Reflow-Hook NACH UI-Build failsafe einfügen
  * try/pass-Kaskaden um Toolbar/Refresh bereinigen
- Backup + Syntax-Check + Rollback
"""
import os, re, sys, time, shutil, traceback, py_compile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str):
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(f"[1174k {time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")
    except Exception:
        pass
    print(msg, flush=True)

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, os.path.basename(path) + f".{int(time.time())}.bak")
    shutil.copy2(path, bak)
    log(f"Backup erstellt: {os.path.relpath(bak, ROOT)}")
    return bak

def read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def write(path: str, text: str):
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

OPEN_EXPLORER_FIXED = r'''
def _open_explorer_select(path: str) -> None:
    """
    Öffnet den Windows-Explorer am Zielort; selektiert die Datei, wenn vorhanden.
    Fail-safe: niemals Exceptions nach außen werfen.
    """
    try:
        p = os.path.normpath(path or "")
        if not p:
            return
        if os.path.exists(p):
            try:
                os.system(f'explorer /select,"{p}"')
            except Exception:
                os.system(f'explorer "{os.path.dirname(p) or "."}"')
        else:
            os.system(f'explorer "{os.path.dirname(p) or "."}"')
    except Exception:
        pass
'''.strip()

def patch_open_explorer(src: str) -> str:
    pat = re.compile(
        r"def\s+_open_explorer_select\s*\(\s*path\s*:\s*str\s*\)\s*->\s*None\s*:[\s\S]*?(?=\n\s*def\s+|\n\s*class\s+|\Z)",
        re.M,
    )
    if pat.search(src):
        src = pat.sub(OPEN_EXPLORER_FIXED + "\n\n", src, count=1)
        log("Fix: _open_explorer_select ersetzt.")
    return src

def remove_inline_reflow_call_in_build_ui(src: str) -> str:
    pat = re.compile(
        r"(\n\s*def\s+_build_ui\s*\(\s*self\s*\)\s*:[\s\S]*?ent_tgt\.bind\(.+?\)\s*\)\s*\n)"
        r"\s*try:\s*\n\s*intake_toolbar_reflow_helper\(self\)\s*\n\s*except\s+Exception\s*:\s*\n\s*pass\s*\n",
        re.M
    )
    if pat.search(src):
        src = pat.sub(r"\1", src, count=1)
        log("Fix: Fehlplatzierten Reflow-Aufruf aus _build_ui entfernt.")
    return src

def ensure_post_build_reflow_hook(src: str) -> str:
    hook = (
        "\n        # [1174k] Reflow-Helper nach UI-Build (failsafe)\n"
        "        try:\n"
        "            from modules.snippets.intake_toolbar_reflow_helper import intake_toolbar_reflow_helper\n"
        "            try:\n"
        "                intake_toolbar_reflow_helper(self)\n"
        "            except Exception:\n"
        "                pass\n"
        "        except Exception:\n"
        "            pass\n\n"
    )
    markers = []
    for mk in (r"\n\s*#\s*R1154g", r"\n\s*self\._update_led\(", r"\n\s*#\s*\[1174g\]"):
        m = re.search(mk, src)
        if m:
            markers.append(m.start())
    if markers:
        insert_at = min(markers)
        src = src[:insert_at] + hook + src[insert_at:]
        log("Fix: Reflow-Hook nach UI-Build eingefügt.")
    else:
        m = re.search(r"(\n\s*def\s+_build_ui\s*\(\s*self\s*\)\s*:[\s\S]*?)\n\s*def\s+", src, re.M)
        if not m:
            m = re.search(r"(\n\s*def\s+_build_ui\s*\(\s*self\s*\)\s*:[\s\S]*)\Z", src, re.M)
        if m and hook not in m.group(1):
            src = src.replace(m.group(1), m.group(1)+hook, 1)
            log("Fix: Reflow-Hook fallback-weise ans Ende von _build_ui angehängt.")
    return src

def scrub_greedy_try_pass_around_toolbar(src: str) -> str:
    bad = re.compile(
        r"\n\s*try:\s*pass\s*\n\s*except\s+Exception:\s*pass\s*\n\s*(self\._on_click_refresh\(\)|self\._schedule_detect\([^)]+\))\s*\n\s*except\s+Exception:\s*pass",
        re.M
    )
    cnt = 0
    while True:
        src2, n = bad.subn(r"\n        \1", src)
        if n == 0:
            break
        src = src2
        cnt += n
    if cnt:
        log(f"Fix: {cnt} defekte try/pass-Kaskaden um Toolbar/Refresh bereinigt.")
    return src

def syntax_check(path: str):
    py_compile.compile(path, doraise=True)

def main():
    print("[1174k] Analyse & Patch ...")
    if not os.path.exists(MOD):
        print("[1174k] FEHLER: module_code_intake.py nicht gefunden.")
        sys.exit(2)

    bak = backup(MOD)
    src = read(MOD)

    try:
        orig = src
        src = patch_open_explorer(src)
        src = remove_inline_reflow_call_in_build_ui(src)
        src = ensure_post_build_reflow_hook(src)
        src = scrub_greedy_try_pass_around_toolbar(src)

        if src == orig:
            log("Hinweis: Keine relevanten Änderungen nötig (Datei scheint bereits repariert).")

        tmp = MOD + ".1174k.tmp"
        write(tmp, src)
        try:
            syntax_check(tmp)
        except Exception as ex:
            log("Syntax-Check FEHLER -> Rollback auf Backup.")
            log("Traceback:\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
            if os.path.exists(tmp):
                os.remove(tmp)
            print('"." kann syntaktisch an dieser Stelle nicht verarbeitet werden.')
            sys.exit(1)

        write(MOD, src)
        if os.path.exists(tmp):
            os.remove(tmp)
        log("Patch übernommen, Syntax OK.")
        print("[1174k] Patch erfolgreich, Syntax OK.")
        sys.exit(0)

    except SystemExit:
        raise
    except Exception as ex:
        try:
            shutil.copy2(bak, MOD)
        except Exception:
            pass
        log("UNERWARTETER FEHLER -> Rollback.")
        log("Traceback:\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        print('"." kann syntaktisch an dieser Stelle nicht verarbeitet werden.')
        sys.exit(3)

if __name__ == "__main__":
    main()
