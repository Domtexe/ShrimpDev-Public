from __future__ import annotations
import sys, json, time
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
MODS = ROOT/"modules"
SNIP = MODS/"snippets"
MODS.mkdir(parents=True, exist_ok=True); SNIP.mkdir(parents=True, exist_ok=True)

NAME = (sys.argv[1] if len(sys.argv)>1 else "module_new").strip()
DESC = (sys.argv[2] if len(sys.argv)>2 else "New module").strip()
VER  = (sys.argv[3] if len(sys.argv)>3 else "0.1.0").strip()

if not NAME.startswith("module_") or not NAME.endswith(".py"):
    if not NAME.startswith("module_"): NAME = "module_" + NAME
    if not NAME.endswith(".py"): NAME = NAME + ".py"

TARGET = MODS / NAME

SKELETON = f'''"""
{DESC}

SemVer: {VER}
Created: {time.strftime('%Y-%m-%d')}
"""
from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, Optional

def run(**kwargs) -> Dict[str, Any]:
    """
    Entry point for {NAME}.
    Returns a dict with 'ok' and optional 'data'.
    """
    try:
        return {{"ok": True, "data": kwargs}}
    except Exception as ex:
        return {{"ok": False, "error": str(ex)}}

if __name__ == "__main__":
    print(run(example=True))
'''

def _send(ev: dict):
    try:
        from modules.snippets.agent_client import send_event
        send_event({"runner":"R942", **ev})
    except Exception:
        pass

if TARGET.exists():
    print(f"[R942] EXISTS: {TARGET}")
else:
    TARGET.write_text(SKELETON, encoding="utf-8")
    print(f"[R942] CREATED: {TARGET}")

# Registry upsert
try:
    from modules.module_registry import upsert_module
    upsert_module(NAME.replace(".py",""), str(TARGET), version=VER, description=DESC, owner="dev", tags=["auto"])
    print("[R942] Registry updated.")
except Exception as ex:
    print(f"[R942] Registry update failed: {ex}")

_send({"level":"OK","msg":f"new module {TARGET.name}"})
