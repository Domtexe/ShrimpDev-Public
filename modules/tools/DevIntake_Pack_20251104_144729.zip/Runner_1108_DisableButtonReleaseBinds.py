# -*- coding: utf-8 -*-
"""
Runner_1108_DisableButtonReleaseBinds
- Entfernt/kommentiert <ButtonRelease-1>-Bindings für Detect/Save/Delete,
  um rekursive Event-Schleifen zu verhindern.
"""
from __future__ import annotations
import os, re, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")

def backup(src):
    ts = int(time.time())
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(src)}.{ts}.bak")
    with open(src, "rb") as f, open(dst, "wb") as g:
        g.write(f.read())
    print(f"[R1108] Backup: {src} -> {dst}")
    return dst

def read(p):  # text
    with open(p, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def write(p, t):
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(t)

def main():
    if not os.path.exists(MOD):
        print("[R1108] module_code_intake.py nicht gefunden.")
        return 1
    src = read(MOD)

    # Muster für Bindings auf ButtonRelease-1 -> detect/save/delete
    pat = re.compile(
        r'^\s*self\.(btn_detect|btn_save|btn_del)\.bind\(\s*"<ButtonRelease-1>"\s*,\s*lambda\s+e\s*:\s*self\._on_click_(detect|save|delete)\(\)\s*\)\s*$',
        re.M
    )

    if not pat.search(src):
        print("[R1108] Keine ButtonRelease-1 Bindings gefunden – nichts zu tun.")
        return 0

    new = pat.sub(lambda m: f"# R1108 disabled: {m.group(0)}", src)

    # Sanity: kompilieren
    try:
        compile(new, MOD, "exec")
    except SyntaxError as e:
        print(f"[R1108] SyntaxError nach Patch (Zeile {e.lineno}): {e.msg}")
        print("[R1108] Datei bleibt UNVERÄNDERT.")
        return 2

    backup(MOD)
    write(MOD, new)
    print("[R1108] ButtonRelease-Bindings deaktiviert. Verwende nur 'command=' der Buttons.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
