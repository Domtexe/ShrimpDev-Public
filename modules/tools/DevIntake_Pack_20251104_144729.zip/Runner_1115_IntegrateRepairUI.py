# -*- coding: utf-8 -*-
"""
Runner_1115_IntegrateRepairUI.py
Fügt in modules/module_code_intake.py einen Toolbar-Button "Reparieren (Tief)"
hinzu und implementiert den Handler _on_click_repair_deep().
Der Button startet die vorhandenen Repair-Runner und pingt den Status.
Idempotent (sicher mehrfach auszuführen).
"""
from __future__ import annotations
import os, io, re, time, shutil

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(BASE, "modules", "module_code_intake.py")
ARCH = os.path.join(BASE, "_Archiv")
os.makedirs(ARCH, exist_ok=True)

def _read(p:str)->str:
    with open(p,"rb") as f: b=f.read()
    try: return b.decode("utf-8")
    except: return b.decode("utf-8","replace")

def _write(p:str,s:str)->None:
    with open(p,"w",encoding="utf-8",newline="\n") as f: f.write(s)

def _backup(p:str)->str:
    ts = int(time.time())
    bak = os.path.join(ARCH, f"{os.path.basename(p)}.{ts}.bak")
    shutil.copy2(p,bak); return bak

src = _read(MOD)

# 1) Prüfen: Button existiert schon?
if "self.btn_repair" in src and "_on_click_repair_deep" in src:
    print("[R1115] Reparatur-UI bereits integriert. Nichts zu tun.")
    raise SystemExit(0)

bak = _backup(MOD)
print(f"[R1115] Backup: {bak}")

new = src

# 2) Handler _on_click_repair_deep() einfügen (falls nicht vorhanden)
if "_on_click_repair_deep(self" not in new:
    # robust nach Klasse/irgendeiner Methode suchen; wir hängen ans Ende der Klasse
    # Suche nach letzter Methode 'def _on_editor_key' oder 'def _ping' als Anker
    m = re.search(r"\nclass\s+\w+\(.*?\):", new)
    if not m:
        print("[R1115] WARN: Konnte Klassenkopf nicht sicher finden – versuche dennoch am Dateiende anzuhängen.")
        insert_at = len(new)
    else:
        # ans Dateiende anhängen – sicherste Variante (idempotent durch oben)
        insert_at = len(new)

    handler = r'''
def _on_click_repair_deep(self, _evt=None):
    """Startet tiefe Reparatur: SanityRepair + UnexpectedIndent-Fix, dann Status aktualisieren."""
    try:
        self._ping("Repariere…")
    except Exception:
        pass
    try:
        import sys, os, subprocess
        base = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        tools = os.path.join(base, "tools")
        cmds = [
            [sys.executable, "-3", os.path.join(tools, "Runner_1114_DeepSanityAndRepair.py")],
            [sys.executable, "-3", os.path.join(tools, "Runner_1114b_FixUnexpectedIndent_MainGUI.py")],
        ]
        # Im Projekt-Stamm ausführen, damit Backups/relative Pfade stimmen
        for cmd in cmds:
            try:
                subprocess.run(cmd, cwd=base, check=False)
            except Exception as ex:
                print("[Repair] Fehler beim Ausführen:", ex)
    except Exception as ex:
        print("[Repair] Unerwarteter Fehler:", ex)
    try:
        # Nach der Reparatur die LED/Statusleiste aktualisieren
        self._ping("Reparatur fertig ✓")
    except Exception:
        pass
'''
    new = new + ("\n" if not new.endswith("\n") else "") + handler

# 3) Button in Toolbar einfügen – wir versuchen ihn direkt neben Guard zu platzieren
if "self.btn_guard" in new and "self.btn_repair" not in new:
    # Finde Grid-Zeile von btn_guard
    # Beispiel: self.btn_guard = ttk.Button(bar, text="Prüfen (Guard)", command=self._on_click_guard)
    #           self.btn_guard.grid(row=0, column=..., padx=..)
    btn_guard_decl = re.search(r'(self\.btn_guard\s*=\s*ttk\.Button\(.*?\)\s*\n\s*self\.btn_guard\.grid\(.*?\)\s*)', new, re.S)
    if btn_guard_decl:
        block = btn_guard_decl.group(1)
        # Wir erzeugen den Repair-Button mit gleicher Zeile, Spalte + 1
        # Spalte heuristisch auslesen
        col_m = re.search(r'column\s*=\s*(\d+)', block)
        col = int(col_m.group(1)) if col_m else 1
        rep = f'''
self.btn_repair = ttk.Button(bar, text="Reparieren (Tief)", command=self._on_click_repair_deep)
self.btn_repair.grid(row=0, column={col+1}, padx=(4,0), sticky="w")'''
        new = new.replace(block, block + rep)
    else:
        # Fallback: hinter btn_detect/save/del/ping einfügen
        bar_row = re.search(r'(self\.lbl_ping\s*=\s*ttk\.Label\(.*?\)\s*.*?grid\(row=0,.*?\)\s*)', new, re.S)
        ins = bar_row.end() if bar_row else len(new)
        rep = f'''
self.btn_repair = ttk.Button(bar, text="Reparieren (Tief)", command=self._on_click_repair_deep)
self.btn_repair.grid(row=0, column=99, padx=(4,0), sticky="w")'''
        new = new[:ins] + rep + new[ins:]

# 4) F7-Hotkey binden (idempotent)
if 'bind("<F7>"' not in new and "_on_click_repair_deep" in new:
    # Suche eine Stelle, wo andere Binds gesetzt werden (z.B. für <Control-v>)
    bind_anchor = re.search(r'(self\.txt\.bind\(.*?_on_editor_paste\)\s*)', new)
    add = '\n        self.txt.bind("<F7>", self._on_click_repair_deep)'
    if bind_anchor:
        new = new[:bind_anchor.end()] + add + new[bind_anchor.end():]
    else:
        # Fallback: im __init__ nach dem Text-Widget
        init_anchor = re.search(r'(self\.txt\s*=\s*tk\.Text\(.*?\)\s*.*?)\n', new, re.S)
        if init_anchor:
            pos = init_anchor.end()
            new = new[:pos] + add + new[pos:]

if new != src:
    _write(MOD, new)
    print("[R1115] Reparatur-UI integriert.")
else:
    print("[R1115] Keine Änderungen nötig.")
