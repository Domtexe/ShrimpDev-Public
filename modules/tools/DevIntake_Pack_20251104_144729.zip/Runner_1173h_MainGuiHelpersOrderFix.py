# -*- coding: utf-8 -*-
"""
1173h: Ordnungs-/Duplikat-Fix fuer main_gui.py (idempotent, sicher)
- Entfernt alte _mount_intake_tab_safe(self, ...) Varianten komplett
- Positioniert die "gute" _mount_intake_tab_safe(parent) + _safe_add_intake_tab(nb)
  direkt NACH dem Header (Shebang/Encoding/Docstring) und NACH allen __future__-Imports
  sowie NACH den Top-Level-Imports (tkinter/ttk etc.) -> niemals vor __future__!
- Gewaehrleistet, dass _safe_main erst NACH diesen Definitionen steht
- Laesst vorhandene Aufrufe unveraendert
"""

import io, os, re, sys, traceback, py_compile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC  = os.path.join(ROOT, "main_gui.py")

def R(path): 
    return io.open(path, "r", encoding="utf-8", errors="replace").read()

def W(path, txt):
    io.open(path, "w", encoding="utf-8", newline="\n").write(txt)

code0 = R(SRC)
code  = code0

# ---------- Helpers zum Parsen ----------
def find_func_block(src, name):
    """Finde Block: 'def name(...):' bis vor naechstes 'def ' oder 'class ' am Spaltenanfang."""
    pat = re.compile(rf"(?ms)^[ \t]*def[ \t]+{re.escape(name)}[ \t]*\([^\)]*\)[ \t]*:[\s\S]*?(?=^[ \t]*def[ \t]+|^[ \t]*class[ \t]+|\Z)")
    m = pat.search(src)
    return (m.start(), m.end()) if m else (None, None)

def cut(src, start, end):
    return src[:start] + src[end:]

def header_insertion_index(src):
    """
    Ermittelt eine sichere Einfuegestelle:
    - ueberspringt Shebang/Encoding
    - ueberspringt Modul-Docstring
    - ueberspringt __future__-Imports
    - ueberspringt die ersten zusammenhaengenden Import-Blöcke
    """
    idx = 0
    # Shebang/encoding
    m = re.match(r"(?s)^(?:\s*#\!.*\n)?(?:\s*#\s*-\*-[^\n]*-\*-\s*\n)?", src)
    if m: idx = m.end()

    # Docstring
    m = re.match(r'(?s)(\s*(?:[ruRU]{0,2}["\']{3}.*?["\']{3}\s*\n))', src[idx:])
    if m: idx += m.end()

    # __future__ imports
    fut_pat = re.compile(r"(?m)^\s*from\s+__future__\s+import\s+.+$")
    last = idx
    for fm in fut_pat.finditer(src, idx):
        last = fm.end()
    if last != idx:
        idx = last

    # Import-Block (normale Imports); wir erlauben mehrere Zeilenblocks hintereinander
    imp_pat = re.compile(r"(?m)^\s*(?:import\s+\w[^\n]*|from\s+\w[^\n]*import[^\n]*)\s*$")
    advanced = True
    while advanced:
        advanced = False
        last = idx
        for im in imp_pat.finditer(src, idx):
            last = im.end()
            advanced = True
        if advanced:
            idx = last
    # eine Leerzeile danach erlaubt
    m = re.match(r"[ \t]*\n", src[idx:])
    if m: idx += m.end()
    return idx

# ---------- 1) Alte self-Variante der Mount-Funktion entfernen ----------
# Kandidaten finden
old_mount_pat = re.compile(
    r"(?ms)^[ \t]*def[ \t]+_mount_intake_tab_safe[ \t]*\(\s*self\b[^)]*\)[ \t]*:[\s\S]*?(?=^[ \t]*def[ \t]+|^[ \t]*class[ \t]+|\Z)"
)
m_old = old_mount_pat.search(code)
if m_old:
    code = cut(code, m_old.start(), m_old.end())

# ---------- 2) Gute parent-Variante + _safe_add_intake_tab finden ----------
s_mount_start, s_mount_end = find_func_block(code, "_mount_intake_tab_safe")
s_add_start,   s_add_end   = find_func_block(code, "_safe_add_intake_tab")

# falls nicht vorhanden: nichts destruktives tun -> sauber beenden (fruehere Runner sollten sie geliefert haben)
if s_mount_start is None or s_add_start is None:
    print("[1173h] Hinweis: erwartete Intake-Helper nicht gefunden; keine Änderung.")
    # trotzdem Syntax pruefen (bricht bei Fehler)
    py_compile.compile(SRC, doraise=True)
    sys.exit(0)

mount_block = code[s_mount_start:s_mount_end]
add_block   = code[s_add_start:s_add_end]

# ---------- 3) Beide Helper aus der aktuellen Position ausschneiden ----------
# Achtung: Reihenfolge beim Ausschneiden (hinteren Block zuerst)
starts = sorted([ (s_mount_start, s_mount_end), (s_add_start, s_add_end) ], key=lambda t: t[0], reverse=True)
for st, en in starts:
    code = cut(code, st, en)

# Doppelte Leerzeilen normalisieren
code = re.sub(r"\n{3,}", "\n\n", code)

# ---------- 4) Einfügepunkt bestimmen (nach Header + __future__ + Import-Block) ----------
ins = header_insertion_index(code)

insertion = "\n\n" + mount_block.strip() + "\n\n" + add_block.strip() + "\n\n"

code = code[:ins] + insertion + code[ins:]

# ---------- 5) Idempotenz: etwaige zweite Duplikate loeschen (falls durch manuelle Historie vorhanden) ----------
# (nach Einfügen erneut suchen und nur das ERSTE Paar behalten)
def kill_duplicates(src, name):
    first = re.search(rf"(?ms)^[ \t]*def[ \t]+{re.escape(name)}\b[^\n]*\n", src)
    if not first:
        return src
    keep_start = first.start()
    # zum Ende des Blocks laufen
    _, keep_end = find_func_block(src, name)
    # alle weiteren Kopien killen
    pat_dup = re.compile(rf"(?ms)^[ \t]*def[ \t]+{re.escape(name)}\b[^\n]*\n[\s\S]*?(?=^[ \t]*def[ \t]+|^[ \t]*class[ \t]+|\Z)")
    out = src[:keep_end]
    pos = keep_end
    for dm in pat_dup.finditer(src, keep_end):
        # ueberspringen -> nichts anfügen
        pos = dm.end()
    out += src[pos:]
    return out

code = kill_duplicates(code, "_mount_intake_tab_safe")
code = kill_duplicates(code, "_safe_add_intake_tab")

# ---------- 6) Syntax-Check ----------
tmp = SRC + ".1173h.tmp"
W(tmp, code)
py_compile.compile(tmp, doraise=True)
os.replace(tmp, SRC)
print("[1173h] Ordnung/Definitionen vor _safe_main hergestellt, Syntax OK.")
