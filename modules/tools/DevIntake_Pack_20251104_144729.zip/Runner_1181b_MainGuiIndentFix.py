# -*- coding: utf-8 -*-
"""
R1181b – Repariert leere try:-Blöcke in main_gui.py
- Findet Stellen ohne eingerückten Block.
- Fügt '    pass' als Fallback ein.
- Legt Backup an, prüft Syntax, loggt Ergebnis.
"""
from __future__ import annotations
import os, re, time, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")
MAIN = os.path.join(ROOT, "main_gui.py")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG, "a", encoding="utf-8", newline="\n") as f:
        f.write(f"[R1181b] {ts} {msg}\n")
    print(f"[R1181b] {msg}")

def backup(path: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    base = os.path.basename(path)
    dst = os.path.join(ARCH, f"{base}.{stamp}.bak")
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        src = f.read()
    with open(dst, "w", encoding="utf-8") as f:
        f.write(src)
    log(f"Backup: {dst}")

def patch_indent() -> None:
    src = open(MAIN, "r", encoding="utf-8", errors="replace").read()
    orig = src

    # 1) finde 'try:' Zeilen ohne eingerückte Folgezeile
    #    (typischer Fall: "try:\nnb.select(...)" => fix)
    fixed = []
    lines = src.splitlines()
    i = 0
    while i < len(lines):
        ln = lines[i]
        fixed.append(ln)
        if re.match(r"^\s*try:\s*$", ln):
            # Nächste Zeile prüfen
            if i + 1 < len(lines):
                nxt = lines[i + 1]
                if not re.match(r"^\s+", nxt):
                    fixed.append("    pass  # auto-fix: leeres try")
            else:
                fixed.append("    pass  # auto-fix: leeres try (EOF)")
        i += 1
    src = "\n".join(fixed)

    if src != orig:
        backup(MAIN)
        with open(MAIN, "w", encoding="utf-8", newline="\n") as f:
            f.write(src)
        log("Indentation fix applied.")
    else:
        log("Keine leeren try:-Blöcke gefunden.")

    # Syntax-Check
    try:
        compile(src, MAIN, "exec")
        log("SyntaxCheck OK.")
    except SyntaxError as e:
        log(f"SyntaxError: line {e.lineno} col {e.offset} {e.msg}")
        sys.exit(2)

def main():
    patch_indent()

if __name__ == "__main__":
    main()
