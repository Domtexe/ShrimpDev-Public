# -*- coding: utf-8 -*-
"""
[R1116f] DumpSyntaxContext
- Prüft D:\ShrimpDev\modules\module_code_intake.py per compile()
- Bei SyntaxError: dump Kontext (±20 Zeilen) in _Archiv
- NIMMT KEINE ÄNDERUNGEN an der Zieldatei vor.
"""

import os, sys, time

TAG   = "[R1116f]"
ROOT  = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD   = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH  = os.path.join(ROOT, "_Archiv")

def read_text(p):
    with open(p, "rb") as f:
        return f.read().decode("utf-8", "replace")

def dump_context(src, lineno, around=20):
    lines = src.splitlines()
    i0 = max(0, lineno - 1 - around)
    i1 = min(len(lines), lineno - 1 + around)
    out = []
    out.append(f"--- Kontext zu lineno={lineno} ---")
    for idx in range(i0, i1 + 1):
        mark = ">>" if idx == lineno - 1 else "  "
        ln   = idx + 1
        out.append(f"{mark} {ln:04d}: {lines[idx] if idx < len(lines) else ''}")
    return "\n".join(out)

def main():
    if not os.path.isfile(MOD):
        print(TAG, "Zieldatei fehlt:", MOD)
        sys.exit(2)

    src = read_text(MOD)
    try:
        compile(src, MOD, "exec")
        print(TAG, "Syntax OK – nichts zu tun.")
        return
    except SyntaxError as e:
        print(TAG, f"SyntaxError: {e.msg} (line {e.lineno})")
        ctx = dump_context(src, e.lineno or 1, around=20)
        os.makedirs(ARCH, exist_ok=True)
        ts   = str(int(time.time()))
        dump = os.path.join(ARCH, f"SYNTAX_CONTEXT_module_code_intake.py.L{e.lineno}.{ts}.txt")
        with open(dump, "w", encoding="utf-8") as f:
            f.write(ctx + "\n")
        print(TAG, "Kontext gedumpt nach:", dump)
        print(TAG, "Bitte Datei öffnen und die Zeilen hier posten – dann liefere ich den zielgenauen Fix-Runner.")
        # Zur Bequemlichkeit gleich noch auf stdout ausgeben:
        print()
        print(ctx)

if __name__ == "__main__":
    main()
