# -*- coding: utf-8 -*-
import os, sys, importlib, tkinter as tk
from tkinter import ttk

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
mod = importlib.import_module("main_gui")

root = tk.Tk()
nb = ttk.Notebook(root)
nb.pack()
# nutzen, was in main_gui vorhanden ist
if hasattr(mod, "_safe_add_intake_tab"):
    mod._safe_add_intake_tab(nb)
else:
    # direkter Call (sollte jetzt funktionieren, da IntakeFrame ein Frame liefert)
    tab = mod.IntakeFrame(nb)
    nb.add(tab, text="Code Intake")

# sofort wieder schliessen – es ist nur ein Konstruktionstest
root.update_idletasks()
root.destroy()
print("[1173z] Notebook/Intake-Tab erfolgreich konstruiert.")
