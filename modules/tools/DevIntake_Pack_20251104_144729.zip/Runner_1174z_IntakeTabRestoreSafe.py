# [1174z] IntakeTabRestoreSafe – ersetzt die „zweite“ _safe_add_intake_tab-Def
# durch eine robuste Version mit garantiertem Tab + Lazy-Mount.

import io, os, re, sys, time, py_compile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "main_gui.py")
ARCH   = os.path.join(ROOT, "_Archiv")

def _read(p):
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def _write(p, s):
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)

src = _read(TARGET)
orig = src

# --- 1) zweite _safe_add_intake_tab entfernen/ersetzen ---
# Erkenne Block ab Marker oder zweite Def mit gleicher Signatur.
pat_block = r"""(?ms)
\#\s*\[INTAKE_TAB_HELPER_1174x\].*?          # Marker-Zeile
^def\s+_safe_add_intake_tab\s*\(.*?\)\s*:\s* # Funktionskopf
.*?(?=^\s*\n|^\s*def\s|\Z)                   # bis vor nächstes def/EOF
"""

if not re.search(pat_block, src, re.VERBOSE):
    # Fallback: zweite Definition anhand von „def“-Wiederholung finden
    defs = list(re.finditer(r"(?ms)^\s*def\s+_safe_add_intake_tab\s*\(.*?\)\s*:\s*", src))
    if len(defs) >= 2:
        start = defs[-1].start()
        # bis vor nächstes def oder EOF
        mnext = re.search(r"(?ms)^\s*def\s+\w+\s*\(", src[start+1:])
        end = len(src) if not mnext else start + 1 + mnext.start()
        src = src[:start] + "__1174z_REPLACED__\n" + src[end:]
else:
    src = re.sub(pat_block, "__1174z_REPLACED__\n", src, flags=re.VERBOSE)

# --- 2) robuste Implementierung einsetzen ---
safe_impl = r'''
def _safe_add_intake_tab(nb):
    """
    Robuste Tab-Erzeugung:
    - versucht direkten Mount von IntakeFrame
    - bei Fehlern immer Platzhalter + Lazy-Mount über _mount_intake_tab_safe
    - niemals „return“ ohne Tab-Erzeugung
    """
    import tkinter as tk
    from tkinter import ttk
    # 1) Direkt versuchen
    try:
        from modules.module_code_intake import IntakeFrame
        tab = IntakeFrame(nb)
        nb.add(tab, text="Code Intake")
        return
    except Exception as e:
        # hartes Debug ins File – ohne harte Abhängigkeit
        try:
            with open(r"D:\ShrimpDev\debug_output.txt","a",encoding="utf-8") as f:
                f.write("[1174z] Intake direct mount failed: %r\n" % (e,))
        except Exception:
            pass

    # 2) Platzhalter + Lazy-Mount
    tab = ttk.Frame(nb)
    nb.add(tab, text="Code Intake")
    body = ttk.Frame(tab)
    body.pack(fill="both", expand=True)
    try:
        tab.after(120, lambda: _mount_intake_tab_safe(body))
    except Exception:
        # Wenn sogar das schiefgeht, wenigstens eine Meldung anzeigen
        msg = tk.Label(tab, text="Fehler beim Laden des Intake-Tabs. Details siehe debug_output.txt", fg="red")
        msg.pack(anchor="w", padx=12, pady=12)
'''

src = src.replace("__1174z_REPLACED__", safe_impl.strip()+"\n")

# --- 3) Aufräumen: doppelte Leerzeilen etwas eindampfen (kosmetisch) ---
src = re.sub(r"\n{4,}", "\n\n\n", src, flags=re.M)

# --- 4) Schreiben + Syntax-Check ---
_write(TARGET, src)
py_compile.compile(TARGET, doraise=True)

print("[1174z] Patch OK.")
