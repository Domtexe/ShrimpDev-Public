# tools/Runner_1116d_FixRecycleBinHelper_Only.py
import os, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
TAG  = "[R1116d]"

def read(p):
    with open(p, "rb") as f:
        return f.read().decode("utf-8", "replace").replace("\r\n","\n").replace("\r","\n")

def write(p, t):
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(t)

def main():
    os.makedirs(ARCH, exist_ok=True)
    ts = str(int(time.time()))
    bak = os.path.join(ARCH, f"module_code_intake.py.{ts}.bak")
    shutil.copy2(MOD, bak)
    print(TAG, "Backup:", bak)

    src = read(MOD)
    new = src
    new = new.replace('"\\\\x00\\\\x00"', '"\\x00\\x00"')
    new = new.replace('"\\\\0\\\\0"',     '"\\x00\\x00"')
    new = new.replace("'\\\\x00\\\\x00'", "'\\x00\\x00'")
    new = new.replace("'\\\\0\\\\0'",     "'\\x00\\x00'")

    if new != src:
        write(MOD, new)
        print(TAG, "Recycle-Bin-Helper repariert.")
    else:
        print(TAG, "Keine Änderungen nötig.")

if __name__ == "__main__":
    main()
