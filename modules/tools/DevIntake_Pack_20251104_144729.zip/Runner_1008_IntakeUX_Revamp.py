"""
Runner_1008_IntakeUX_Revamp
- Bringt Intake-UI optisch/funktional auf Screenshot-Niveau
- Menüleiste in main_gui + Tabtitel "Code Intake"
- Config: + target_folder, suppress_save_ok
- Version -> v9.9.0
"""
from __future__ import annotations
import os, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1008] {ts} {msg}\n")
    print(msg, flush=True)

def safe_write(path: str, data: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        os.makedirs(ARCH, exist_ok=True)
        bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
        shutil.copy2(path, bck)
        log(f"Backup: {path} -> {bck}")
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

def patch():
    try:
        # 1) config_mgr erweitern
        cfgp = os.path.join(ROOT, "modules", "config_mgr.py")
        with open(cfgp, "r", encoding="utf-8") as f:
            src = f.read()
        changed = False
        if "target_folder" not in src:
            src = src.replace('"default_path": "."',
                              '"default_path": ".",\n        "target_folder": ".",\n        "suppress_save_ok": "false"')
            changed = True
        if "suppress_save_ok" not in src:
            src = src.replace('"history_limit": "50"',
                              '"history_limit": "50",\n        "suppress_save_ok": "false"')
            changed = True
        if changed:
            safe_write(cfgp, src)
            log("config_mgr.py erweitert (target_folder, suppress_save_ok)")
        else:
            log("config_mgr.py bereits aktuell.")

        # 2) module_code_intake neu schreiben
        safe_write(os.path.join(ROOT, "modules", "module_code_intake.py"), MODULE_CODE_INTAKE)

        # 3) main_gui: Menü + „Code Intake“-Titel + Version bump
        gpath = os.path.join(ROOT, "main_gui.py")
        with open(gpath, "r", encoding="utf-8") as f:
            gui = f.read()

        if "### MENUBAR ###" not in gui:
            gui = gui.replace(
                "def _safe_main() -> None:",
                "def _safe_main() -> None:\n    # ### MENUBAR ###\n    pass"
            )
        # Eingreifen: wir ersetzen komplette Datei-Kopf bis Notebook durch Variante mit Menü
        gui = MAIN_GUI_PATCH(gui)

        # 4) Meta
        safe_write(gpath, gui)
        safe_write(os.path.join(ROOT, "CURRENT_VERSION.txt"), "ShrimpDev v9.9.0\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.0 (2025-10-18)
- Intake-UI: Kopfzeile (Workspace/Datei/Endung/Zielordner), Editor links, Treeview rechts (name/ext/subfolder)
- Aktionen: Speichern (Ctrl+S), Erkennen (Ctrl+I), Kopieren (Ctrl+C), Löschen (Entf), Explorer im Kontextmenü
- LED „Erkennung OK“ oben rechts; Checkbox „Nicht wieder anzeigen (Speicher-OK)“ (suppress_save_ok)
- Menüleiste: File / Tools / Help / Info
""")
        log("Patch erfolgreich.")
        return 0
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

# --------- new module_code_intake ----------
MODULE_CODE_INTAKE = r'''"""Intake-UI (v9.9.0) im Screenshot-Layout"""
from __future__ import annotations
import os, shutil, tkinter as tk
from tkinter import ttk, filedialog, messagebox
from modules.config_mgr import ConfigMgr
from modules.snippets.file_detect_snippet import split_name_ext, classify, is_supported

def _open_explorer_select(path: str) -> None:
    try:
        if os.path.exists(path):
            os.system(f'explorer /select,"{path}"')
        else:
            os.system(f'explorer "{os.path.dirname(path) or "."}"')
    except Exception:
        pass

class IntakeFrame(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.cfg = ConfigMgr()
        self._build_ui()
        self._load_table()
        self._update_led("yellow", "Erkennung…")
        self._bind_shortcuts(self)

    # ---------- UI ----------
    def _build_ui(self):
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        # Kopfzeile (Workspace/Datei/Endung/Zielordner)
        head = ttk.Frame(self)
        head.grid(row=0, column=0, sticky="ew", padx=8, pady=(6,4))
        for i in (1,3): head.columnconfigure(i, weight=1)

        ttk.Label(head, text="Workspace:").grid(row=0, column=0, sticky="w")
        self.var_ws = tk.StringVar(value=self.cfg.get_str("general", "default_path", os.getcwd()))
        ent_ws = ttk.Entry(head, textvariable=self.var_ws)
        ent_ws.grid(row=0, column=1, sticky="ew", padx=(4,8))
        ttk.Button(head, text="...", width=3, command=self._pick_ws).grid(row=0, column=2, padx=(0,14))

        ttk.Label(head, text="Datei:").grid(row=0, column=3, sticky="w")
        self.var_path = tk.StringVar(value="")
        self.ent_path = ttk.Entry(head, textvariable=self.var_path)
        self.ent_path.grid(row=0, column=4, sticky="ew", padx=(4,8))
        ttk.Button(head, text="...", width=3, command=self._pick_file).grid(row=0, column=5, padx=(0,14))

        ttk.Label(head, text="Endung:").grid(row=0, column=6, sticky="w")
        self.var_ext = tk.StringVar(value="")
        ttk.Entry(head, textvariable=self.var_ext, state="readonly", width=6).grid(row=0, column=7, padx=(4,14))

        ttk.Label(head, text="Zielordner:").grid(row=0, column=8, sticky="w")
        self.var_target = tk.StringVar(value=self.cfg.get_str("general", "target_folder", os.path.join(os.getcwd(), "tools")))
        ent_tgt = ttk.Entry(head, textvariable=self.var_target)
        ent_tgt.grid(row=0, column=9, sticky="ew", padx=(4,8))
        ttk.Button(head, text="...", width=3, command=self._pick_target).grid(row=0, column=10)

        # LED/Status
        ledwrap = ttk.Frame(self)
        ledwrap.grid(row=0, column=0, sticky="e", padx=8)
        self.led = tk.Canvas(ledwrap, width=14, height=14, highlightthickness=0)
        self.led.pack(side="left", padx=(0,6))
        self.var_ledtext = tk.StringVar(value="")
        ttk.Label(ledwrap, textvariable=self.var_ledtext).pack(side="left")

        # Body mit PanedWindow (Editor links / Tabelle rechts)
        body = ttk.Panedwindow(self, orient="horizontal")
        body.grid(row=1, column=0, sticky="nsew", padx=8, pady=(0,4))
        self.rowconfigure(1, weight=1)

        # Editor
        left = ttk.Frame(body); left.columnconfigure(0, weight=1); left.rowconfigure(0, weight=1)
        self.txt = tk.Text(left, wrap="none")
        self.txt.grid(row=0, column=0, sticky="nsew")
        body.add(left, weight=3)

        # Tabelle rechts
        right = ttk.Frame(body); right.columnconfigure(0, weight=1); right.rowconfigure(0, weight=1)
        cols = ("name","ext","subfolder")
        self.tbl = ttk.Treeview(right, columns=cols, show="headings", height=10, selectmode="browse")
        self.tbl.heading("name", text="name"); self.tbl.column("name", width=220, anchor="w")
        self.tbl.heading("ext", text="ext"); self.tbl.column("ext", width=60, anchor="center")
        self.tbl.heading("subfolder", text="subfolder"); self.tbl.column("subfolder", width=140, anchor="w")
        ysb = ttk.Scrollbar(right, orient="vertical", command=self.tbl.yview)
        self.tbl.configure(yscrollcommand=ysb.set)
        self.tbl.grid(row=0, column=0, sticky="nsew"); ysb.grid(row=0, column=1, sticky="ns")

        # Kontextmenü
        self.menu = tk.Menu(self, tearoff=0)
        self.menu.add_command(label="Öffnen im Explorer", command=self._open_selected)
        self.menu.add_command(label="Pfad kopieren", command=self._copy_selected)
        self.menu.add_separator()
        self.menu.add_command(label="Löschen", command=self._delete_selected)
        self.tbl.bind("<Button-3>", self._context)

        # DblClick -> laden/erkennen
        self.tbl.bind("<Double-Button-1>", self._dbl_open)

        body.add(right, weight=2)

        # Footer: Status + Checkbox + Buttons
        footer = ttk.Frame(self)
        footer.grid(row=2, column=0, sticky="ew", padx=8, pady=(4,8))
        footer.columnconfigure(0, weight=1)

        self.var_suppress_ok = tk.BooleanVar(value=self.cfg.get_bool("general", "suppress_save_ok", False))
        ttk.Checkbutton(footer, text="Nicht wieder anzeigen (Speicher-OK)", variable=self.var_suppress_ok,
                        command=lambda: self.cfg.set_str("general", "suppress_save_ok", "true" if self.var_suppress_ok.get() else "false")).grid(row=0, column=0, sticky="w")

        ttk.Button(footer, text="Speichern (Ctrl+S)", command=self._save).grid(row=0, column=1, padx=(8,0))
        ttk.Button(footer, text="Erkennen (Ctrl+I)", command=self._detect).grid(row=0, column=2, padx=(8,0))

    # ---------- helpers ----------
    def _bind_shortcuts(self, w: tk.Misc):
        w.bind_all("<Control-s>", lambda e: self._save())
        w.bind_all("<Control-i>", lambda e: self._detect())
        self.tbl.bind("<Control-c>", lambda e: self._copy_selected())
        self.tbl.bind("<Delete>", lambda e: self._delete_selected())

    def _update_led(self, color: str, text: str):
        self.led.delete("all")
        self.led.create_oval(2,2,12,12, fill=color, outline="")
        self.var_ledtext.set(text)

    def _pick_ws(self):
        d = filedialog.askdirectory(title="Workspace wählen", initialdir=self.var_ws.get() or os.getcwd())
        if d:
            self.var_ws.set(d)
            self.cfg.set_str("general", "default_path", d)

    def _pick_file(self):
        f = filedialog.askopenfilename(title="Datei wählen", initialdir=self.var_ws.get() or os.getcwd())
        if f:
            self.var_path.set(f)
            try:
                with open(f, "r", encoding="utf-8", errors="ignore") as fh:
                    self.txt.delete("1.0","end"); self.txt.insert("1.0", fh.read())
            except Exception:
                pass
            self._detect()

    def _pick_target(self):
        d = filedialog.askdirectory(title="Zielordner wählen", initialdir=self.var_target.get() or os.getcwd())
        if d:
            self.var_target.set(d)
            self.cfg.set_str("general", "target_folder", d)

    def _context(self, evt):
        try:
            self.tbl.selection_set(self.tbl.identify_row(evt.y))
            self.menu.tk_popup(evt.x_root, evt.y_root)
        finally:
            self.menu.grab_release()

    def _path_of_item(self, item_id: str) -> str:
        vals = self.tbl.item(item_id, "values")
        if not vals: return ""
        name, ext, sub = vals
        folder = self.var_target.get() or "."
        if sub:
            folder = os.path.join(folder, sub)
        return os.path.join(folder, f"{name}{ext}")

    # ---------- actions ----------
    def _detect(self):
        path = self.var_path.get().strip()
        content = self.txt.get("1.0", "end").rstrip("\n")
        if not path and not content:
            self._update_led("red", "Keine Quelle")
            return
        # Endung bestimmen
        name, ext = split_name_ext(path) if path else ("", "")
        self.var_ext.set(ext or "(n/a)")
        ok = bool((path and is_supported(path)) or ext or content)
        typ = classify(path) if path else "unknown"
        self._update_led("green" if ok else "yellow", "Erkennung OK" if ok else f"Typ: {typ}")
        return ok

    def _save(self):
        # Zielpfad bestimmen
        tgt_dir = self.var_target.get().strip() or "."
        os.makedirs(tgt_dir, exist_ok=True)
        # Name aus Dateifeld oder Fallback
        src = self.var_path.get().strip()
        nm, ext = split_name_ext(src) if src else ("snippet", ".txt")
        # Unterordner leer (GUI-Feld im Screenshot ist informativ) – wir schreiben direkt nach target
        target_path = os.path.join(tgt_dir, f"{os.path.basename(nm)}{ext}")
        data = self.txt.get("1.0","end").encode("utf-8")
        try:
            with open(target_path, "wb") as f:
                f.write(data)
            # History über ConfigMgr
            self.cfg.append_history(target_path)
            self._load_table()
            if not self.cfg.get_bool("general", "suppress_save_ok", False):
                # kein Popup-Sturm – nur Infoanzeige simulieren
                self._update_led("green", "Gespeichert")
        except Exception as ex:
            messagebox.showerror("Fehler", f"Konnte nicht speichern:\n{ex}")
            self._update_led("red", "Fehler")

    def _load_table(self):
        # Tabelle aus INI-History befüllen; Subfolder aus Pfad relativ zum Zielordner ableiten
        for i in self.tbl.get_children(): self.tbl.delete(i)
        tgt = os.path.abspath(self.var_target.get() or ".")
        for p in self.cfg.get_history():
            base = os.path.basename(p)
            name, ext = os.path.splitext(base)
            try:
                rel = os.path.relpath(os.path.dirname(os.path.abspath(p)), tgt)
                sub = "" if rel in (".", "") else rel
            except Exception:
                sub = ""
            self.tbl.insert("", "end", values=(name, ext.lower(), sub))

    def _dbl_open(self, _evt=None):
        sel = self.tbl.selection()
        if not sel: return
        path = self._path_of_item(sel[0])
        if not os.path.isfile(path): return
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                self.txt.delete("1.0","end"); self.txt.insert("1.0", f.read())
            self.var_path.set(path); self._detect()
        except Exception:
            pass

    def _copy_selected(self):
        sel = self.tbl.selection()
        if not sel: return
        path = self._path_of_item(sel[0])
        try:
            self.clipboard_clear(); self.clipboard_append(path)
        except Exception:
            pass

    def _delete_selected(self):
        sel = self.tbl.selection()
        if not sel: return
        path = self._path_of_item(sel[0])
        if not os.path.isfile(path):
            self.cfg.remove_history(path); self._load_table(); return
        if not messagebox.askyesno("Löschen bestätigen", f"Datei endgültig löschen?\n\n{path}"):
            return
        try:
            os.remove(path)
        except Exception:
            try:
                trash = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "_Archiv", "_Trash"))
                os.makedirs(trash, exist_ok=True)
                shutil.move(path, os.path.join(trash, os.path.basename(path) + ".del"))
            except Exception:
                messagebox.showerror("Fehler", "Löschen fehlgeschlagen.")
                return
        self.cfg.remove_history(path)
        self._load_table()

    def _open_selected(self):
        sel = self.tbl.selection()
        if not sel: return
        _open_explorer_select(self._path_of_item(sel[0]))
'''

# --------- patcher for main_gui adding menu & code intake tab name ----------
def MAIN_GUI_PATCH(src: str) -> str:
    # Titel auf v9.9.0 + Tabtitel anpassen + Menüleiste einfügen
    src = src.replace("ShrimpDev – v9.8.9", "ShrimpDev – v9.9.0")\
             .replace("ShrimpDev – v9.8.8", "ShrimpDev – v9.9.0")\
             .replace("ShrimpDev – v9.8.7", "ShrimpDev – v9.9.0")\
             .replace("ShrimpDev – v9.8.6", "ShrimpDev – v9.9.0")

    # Menüleiste (einfach, ohne externe Abhängigkeiten)
    if "menubar =" not in src:
        insert_after = "root.geometry(\"1000x700\")"
        menu_code = (
            "\n    # Menüleiste\n"
            "    menubar = tk.Menu(root)\n"
            "    m_file = tk.Menu(menubar, tearoff=0)\n"
            "    m_file.add_command(label='Speichern (Ctrl+S)', command=lambda: tab_intake._save())\n"
            "    m_file.add_separator(); m_file.add_command(label='Beenden', command=root.destroy)\n"
            "    menubar.add_cascade(label='File', menu=m_file)\n"
            "    m_tools = tk.Menu(menubar, tearoff=0)\n"
            "    m_tools.add_command(label='Erkennen (Ctrl+I)', command=lambda: tab_intake._detect())\n"
            "    menubar.add_cascade(label='Tools', menu=m_tools)\n"
            "    m_help = tk.Menu(menubar, tearoff=0)\n"
            "    m_help.add_command(label='Info', command=lambda: tk.messagebox.showinfo('ShrimpDev','Standalone Dev-Umgebung für ShrimpHub'))\n"
            "    menubar.add_cascade(label='Help', menu=m_help)\n"
            "    root.config(menu=menubar)\n"
        )
        src = src.replace(insert_after, insert_after + menu_code)

    # Tabtitel „Code Intake“
    src = src.replace("nb.add(tab_intake, text=\"Intake\")", "nb.add(tab_intake, text=\"Code Intake\")")
    return src

if __name__ == "__main__":
    raise SystemExit(patch())
