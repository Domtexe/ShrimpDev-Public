# tools/Runner_1102_FixIntake_ReindentAndScope.py
# Repariert Einrückungen/Scope in modules\module_code_intake.py
# - rückt IntakeFrame-Methoden in die Klasse ein
# - rückt Tooltip._show/_hide in die Klasse ein
# - dedentet irrtümlich in SHFILEOPSTRUCTW platzierte Codezeilen
# - sanity-compile am Ende
from __future__ import annotations
import io, os, re, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
ARCH.mkdir(exist_ok=True)

METHODS_INTake = {
    "_build_ui","_bind_shortcuts","_popup_menu","_update_led","_ping",
    "_prepare_new_intake","_clear_editor_and_fields","_copy_text",
    "_paste_name","_pick_ws","_pick_target",
    "_on_ext_changed","_normalize_ext","_on_name_edited",
    "_guess_name_from_text","_guess_ext_from_text","_apply_ext_to_name",
    "_detect","_on_editor_paste","_on_click_clear_code","_on_click_delete_selected",
}
TOOLTIP_METHODS = {"_show","_hide"}

def backup(p: Path) -> Path:
    ts = str(int(time.time()))
    dst = ARCH / f"{p.name}.{ts}.bak"
    dst.write_bytes(p.read_bytes())
    return dst

def block_iter(lines, start_idx):
    """liefert [start, end_exclusive] Blockgrenze ab start_idx (gleiche/outdent)"""
    head = lines[start_idx]
    indent = len(head) - len(head.lstrip())
    j = start_idx + 1
    while j < len(lines):
        L = lines[j]
        if L.strip()=="":
            j += 1
            continue
        cur = len(L) - len(L.lstrip())
        if cur <= indent and not L.lstrip().startswith(("#","@")) and not L.startswith("\n"):
            break
        j += 1
    return start_idx, j

def indent_block(lines, i0, i1, add=4):
    pad = " " * add
    for i in range(i0, i1):
        if lines[i].strip():
            lines[i] = pad + lines[i]
    return lines

def dedent_block(lines, i0, i1, sub=4):
    for i in range(i0, i1):
        s = lines[i]
        cut = min(sub, len(s) - len(s.lstrip()))
        lines[i] = s[cut:]
    return lines

def reindent_tooltip(lines):
    # finde class Tooltip:
    pat_cls = re.compile(r'^\s*class\s+Tooltip\b')
    i = next((i for i,l in enumerate(lines) if pat_cls.match(l)), -1)
    if i < 0:
        return lines
    # Korrigiere _show/_hide auf Top-Level => in Klasse indentieren
    pat_def = re.compile(r'^def\s+(_show|_hide)\s*\(')
    j = 0
    while j < len(lines):
        if pat_def.match(lines[j]):
            a,b = block_iter(lines, j)
            lines = indent_block(lines, a, b, 8)  # in Klasse (typisch +8 weil class + def)
            j = b + 1
        else:
            j += 1
    return lines

def reindent_intake_methods(lines):
    # finde class IntakeFrame:
    pat_cls = re.compile(r'^\s*class\s+IntakeFrame\b')
    icls = next((i for i,l in enumerate(lines) if pat_cls.match(l)), -1)
    if icls < 0:
        return lines
    # ab Klasse alle top-level defs, die METHODS_INTake heißen, in Klasse indentieren
    pat_def = re.compile(r'^def\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(')
    j = icls + 1
    while j < len(lines):
        m = pat_def.match(lines[j])
        if m:
            name = m.group(1)
            a,b = block_iter(lines, j)
            if name in METHODS_INTake:
                lines = indent_block(lines, a, b, 8)  # Klasse + übliche 4er-Einrückung => +8
                j = b + 1
                continue
            j = b
        else:
            j += 1
    return lines

def fix_recycle_struct(lines):
    # Stelle sicher: class SHFILEOPSTRUCTW {...} danach folgen pFrom/sh/rc AUßERHALB der Klasse
    pat_cls = re.compile(r'^\s*class\s+SHFILEOPSTRUCTW\b')
    i = next((i for i,l in enumerate(lines) if pat_cls.match(l)), -1)
    if i < 0:
        return lines
    # Finde Klasse-Ende:
    a, b = block_iter(lines, i)
    # Suche innerhalb des Blocks nach 'pFrom =' – wenn gefunden: dedent bis vor nächstes return/rc
    pat_pFrom = re.compile(r'^\s+pFrom\s*=')
    k = next((k for k in range(a, b) if pat_pFrom.match(lines[k])), -1)
    if k >= 0:
        # dedentiere ab pFrom bis Blockende um 4
        lines = dedent_block(lines, k, b, 4)
    return lines

def sanity_compile(txt: str):
    code = compile(txt, str(SRC), "exec")  # wirft SyntaxError bei Problemen
    return True

def main():
    if not SRC.exists():
        print("[R1102] Datei fehlt:", SRC)
        sys.exit(1)
    bak = backup(SRC)
    orig = SRC.read_text(encoding="utf-8", errors="replace").splitlines(True)

    lines = orig[:]
    lines = reindent_tooltip(lines)
    lines = reindent_intake_methods(lines)
    lines = fix_recycle_struct(lines)

    # Doppelte messagebox-Imports optional bereinigen
    txt = "".join(lines)
    txt = re.sub(r'from tkinter import messagebox\s*\n', '', txt, count=1)

    # Sanity-Compile
    try:
        sanity_compile(txt)
    except SyntaxError as ex:
        # bei Fehler: nicht schreiben, Backup belassen
        print("[R1102] SyntaxError nach Fix:", ex)
        print("[R1102] Datei bleibt unverändert. Backup:", bak)
        sys.exit(2)

    SRC.write_text(txt, encoding="utf-8")
    print(f"[R1102] OK. Repariert und gespeichert. Backup: {bak}")

if __name__ == "__main__":
    main()
