"""
Runner_1024_LoggerAtomicFix
- macht logger_snippet.write_log() fehlertolerant und thread-safe
- verhindert PermissionError-Loop (GUI/Agent parallel)
- Version -> v9.9.15
"""
import os, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")
LOGR = os.path.join(ROOT, "modules", "snippets", "logger_snippet.py")

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1024] {ts} {msg}\n")
    print(msg)

def backup_write(path, data):
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

def patch_logger():
    with open(LOGR, "r", encoding="utf-8") as f:
        src = f.read()

    if "Atomic write" in src:
        log("logger_snippet.py bereits gepatcht.")
        return

    # neue robuste write_log-Funktion
    safe_fn = r'''
def write_log(prefix: str, msg: str) -> None:
    """Atomic write mit Retry & Fallback."""
    import time, tempfile, os
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{prefix}] {ts} {msg}\n"
    LOG_PATH = os.path.join(os.path.abspath(os.path.dirname(__file__)), "..", "..", "debug_output.txt")
    LOG_PATH = os.path.abspath(LOG_PATH)
    tmp = None
    for attempt in range(10):
        try:
            with open(LOG_PATH, "a", encoding="utf-8") as f:
                f.write(line)
            return
        except PermissionError:
            time.sleep(0.2)
        except Exception:
            break
    # Fallback in temporäre Datei, falls dauerhaft blockiert
    try:
        tmp = tempfile.gettempdir()
        with open(os.path.join(tmp, "ShrimpDev_fallback.log"), "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass
'''
    new_src = safe_fn
    backup_write(LOGR, new_src)
    log("logger_snippet.py ersetzt (Atomic write + Retry + Temp-Fallback).")

def main():
    try:
        patch_logger()
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.15\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.15 (2025-10-18)
- logger_snippet: atomarer Write, Retry + Temp-Fallback (kein PermissionError mehr)
""")
        log("Patch abgeschlossen.")
        return 0
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
