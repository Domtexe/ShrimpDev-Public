from __future__ import annotations
from pathlib import Path
import re, shutil, time

ROOT = Path(r"D:\ShrimpDev")
SCAN_UI = ROOT / "modules" / "module_project_ui.py"

def ts() -> str:
    return time.strftime("%Y%m%d_%H%M%S")

def backup(p: Path) -> Path:
    b = p.with_suffix(p.suffix + f".{ts()}.bak")
    shutil.copy2(p, b)
    return b

def main():
    if not SCAN_UI.exists():
        print("[R914] FEHLT:", SCAN_UI)
        return 2
    txt = SCAN_UI.read_text(encoding="utf-8", errors="ignore")

    # typische Varianten der Abschlussmeldung finden
    patts = [
        r'messagebox\.showinfo\s*\(\s*["\']ShrimpDev["\']\s*,\s*["\']Scan abgeschlossen["\']\s*\)',
        r'messagebox\.showinfo\s*\(.*?Scan abgeschlossen.*?\)',
        r'messagebox\.showinfo\s*\(.*?Scan\s+abgeschlossen.*?\)',
    ]

    found = False
    for p in patts:
        if re.search(p, txt, re.IGNORECASE):
            txt = re.sub(p, "# [R914 removed popup]", txt)
            found = True

    if not found:
        print("[R914] Kein Popup gefunden oder bereits entfernt.")
        return 0

    backup(SCAN_UI)
    SCAN_UI.write_text(txt, encoding="utf-8")
    print("[R914] Popup entfernt – Backup angelegt.")
    return 0

if __name__ == "__main__":
    main()
