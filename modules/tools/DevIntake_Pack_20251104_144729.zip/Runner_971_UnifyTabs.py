from __future__ import annotations
from pathlib import Path
import time, shutil, re

ROOT = Path(r"D:\ShrimpDev")
MODS = ROOT / "modules"
TOOLS = ROOT / "tools"
LOG  = ROOT / "debug_output.txt"

def log(msg: str):
    try: LOG.open("a", encoding="utf-8", errors="ignore").write(f"[R971] {msg}\n")
    except Exception: pass

def w(p: Path, s: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(s, encoding="utf-8")
    log(f"wrote {p.relative_to(ROOT)}")

def backup(p: Path):
    if p.exists():
        b = p.with_suffix(p.suffix + "." + time.strftime("%Y%m%d_%H%M%S") + ".bak")
        shutil.copy2(p, b)
        log(f"backup {b.name}")

COMMON_TABS = r'''from __future__ import annotations
import tkinter as tk
from tkinter import ttk

def ensure_tab(app: tk.Tk, key: str, title: str, builder):
    """
    Stellt sicher, dass ein Tab mit Schlüssel `key` existiert.
    - `builder(parent)` muss ein Frame zurückgeben.
    - Reaktiviert bestehenden Tab, statt neue Fenster zu öffnen.
    """
    if not hasattr(app, "_tab_registry"):
        app._tab_registry = {}
    nb = getattr(app, "nb", None)
    if nb is None:
        # Fallback: Kein Notebook -> baue Toplevel
        win = tk.Toplevel(app); win.title(title)
        frm = builder(win); frm.pack(fill="both", expand=True)
        return True
    if key in app._tab_registry:
        idx = app._tab_registry[key]["index"]
        nb.select(idx); return True
    # Neu bauen
    container = ttk.Frame(nb)
    frame = builder(container)
    frame.pack(fill="both", expand=True)
    nb.add(container, text=title)
    app._tab_registry[key] = {"frame": container, "index": nb.index("end") - 1}
    nb.select(app._tab_registry[key]["index"])
    return True
'''

AGENT_UI = r'''from __future__ import annotations
import json, tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from .common_tabs import ensure_tab

ROOT   = Path(r"D:\ShrimpDev")
EVENTS = ROOT / "_Reports" / "Agent" / "events.jsonl"

def _tail(n: int = 500):
    if not EVENTS.exists(): return []
    lines = EVENTS.read_text(encoding="utf-8", errors="ignore").splitlines()[-n:]
    out=[]
    for ln in lines:
        try: out.append(json.loads(ln))
        except Exception: out.append({"ts":"", "runner":"?", "level":"INFO", "msg": ln})
    return out

def _build_tree(parent):
    frm = ttk.Frame(parent)
    bar = ttk.Frame(frm); bar.pack(fill="x", pady=6)
    ttk.Label(bar, text="Level:").pack(side="left")
    var_level = tk.StringVar(value="ALL")
    ttk.Combobox(bar, textvariable=var_level, values=["ALL","OK","INFO","WARN","ERROR","FAIL"], width=8, state="readonly").pack(side="left", padx=6)
    cols=("ts","runner","level","msg"); tree=ttk.Treeview(frm, columns=cols, show="headings")
    for c,w in zip(cols,(170,180,90,540)): tree.heading(c, text=c); tree.column(c, width=w, anchor="w")
    tree.pack(fill="both", expand=True)
    def _f(rows):
        lv = var_level.get().upper()
        if lv=="ALL": return rows
        return [r for r in rows if str(r.get("level","")).upper()==lv]
    def refresh():
        rows = _f(_tail())
        for i in tree.get_children(): tree.delete(i)
        for r in rows: tree.insert("", "end", values=(r.get('ts',''), r.get('runner',''), r.get('level',''), r.get('msg','')))
        frm.after(2000, refresh)
    refresh()
    return frm

def open_agent_monitor(app: tk.Tk) -> bool:
    try: return ensure_tab(app, "agent", "Agent Monitor", _build_tree)
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Agent Monitor Fehler:\n{ex}")
        except Exception: pass
        return False
'''

CODE_INTAKE = r'''from __future__ import annotations
import re, tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from .common_tabs import ensure_tab

ROOT = Path(r"D:\ShrimpDev")

def _detect_name_and_ext(code: str):
    head = code[:4000]
    pats = [
        r"(?im)^\s*#\s*file\s*:\s*(?P<p>[\w\-/\\\. ]+\.(py|bat|cmd|vbs|ps1|json|md|txt))\s*$",
        r"(?ism)^[`\"']{3}[^`\"']*?(?P<p>[\w\-/\\\. ]+\.(py|bat|cmd|vbs|ps1|json|md|txt))[^`\"']*?[`\"']{3}",
        r"(?im)^\s*//\s*(?P<p>[\w\-/\\\. ]+\.(py|bat|cmd|vbs|ps1|json|md|txt))\s*$",
        r"(?im)^\s*;\s*(?P<p>[\w\-/\\\. ]+\.(py|bat|cmd|vbs|ps1|json|md|txt))\s*$",
        r"(?i)\b(Runner_\w+\.(py|bat|cmd|vbs))\b",
        r"(?i)\b(module_[\w\-]+\.py)\b",
    ]
    for pat in pats:
        m = re.search(pat, head)
        if m:
            from pathlib import Path as P
            p = m.group("p") if "p" in m.groupdict() else m.group(0)
            n = P(p).name; e = P(n).suffix.lower()
            return n, e
    return None, None

def _map_target(ws: Path, name: str, ext: str) -> Path:
    n = name.lower()
    if ext==".py" and n.startswith("runner_"): return ws/"tools"
    if ext in {".bat",".cmd",".vbs",".ps1"}:   return ws/"tools"
    if ext==".py" and n.startswith("module_"): return ws/"modules"
    if ext==".py":                             return ws/"modules"/"snippets"
    return ws

def _build_tab(parent):
    frm = ttk.Frame(parent)
    try:
        from modules.config_mgr import load_config, save_config
        conf = load_config()
    except Exception:
        conf, save_config = {"workspace_root": r"D:\ShrimpHub"}, lambda c: None
    ws = Path(conf.get("workspace_root", r"D:\ShrimpHub"))

    top = ttk.Frame(frm); top.pack(fill="x", pady=6)
    ttk.Label(top, text="Workspace:").pack(side="left")
    var_ws = tk.StringVar(value=str(ws))
    ttk.Entry(top, textvariable=var_ws, width=60).pack(side="left", padx=6)
    def _pick():
        d = filedialog.askdirectory(title="Workspace wählen", initialdir=str(ws))
        if d: var_ws.set(d)
    ttk.Button(top, text="…", command=_pick).pack(side="left")

    bar = ttk.Frame(frm); bar.pack(fill="x", pady=4)
    var_name = tk.StringVar(); var_ext = tk.StringVar(); var_target = tk.StringVar()
    for lbl, var, w in (("Dateiname:", var_name, 40), ("Endung:", var_ext, 8), ("Zielordner:", var_target, 50)):
        ttk.Label(bar, text=lbl).pack(side="left"); ttk.Entry(bar, textvariable=var, width=w).pack(side="left", padx=6)

    txt = tk.Text(frm, wrap="none", undo=True); txt.pack(fill="both", expand=True)

    status = tk.StringVar(value="Bereit."); ttk.Label(frm, textvariable=status, anchor="w").pack(fill="x", pady=6)

    def _detect(auto=False):
        code = txt.get("1.0", "end-1c")
        name, ext = _detect_name_and_ext(code)
        if name: var_name.set(name)
        if ext:  var_ext.set(ext)
        nm, ex = var_name.get().strip(), var_ext.get().strip().lower()
        if nm and ex: var_target.set(str(_map_target(Path(var_ws.get() or r"D:\ShrimpHub"), nm, ex)))
        if not auto: status.set(f"Erkannt: name={nm!r}, ext={ex!r}, target={var_target.get()!r}")

    def _save():
        nm, ex, target = var_name.get().strip(), var_ext.get().strip().lower(), var_target.get().strip()
        code = txt.get("1.0", "end-1c")
        if not nm or not ex or not target:
            messagebox.showwarning("ShrimpDev", "Bitte Name/Endung/Target prüfen."); return
        if not nm.lower().endswith(ex): nm = Path(nm).stem + ex; var_name.set(nm)
        out_dir = Path(target); out_dir.mkdir(parents=True, exist_ok=True)
        out = out_dir / nm
        if out.exists():
            for i in range(4,0,-1):
                pi = out.with_name(out.name + f".{i}.bak"); pj = out.with_name(out.name + f".{i+1}.bak")
                if pi.exists(): pi.replace(pj)
            try: out.with_name(out.name + ".bak").replace(out.with_name(out.name + ".1.bak"))
            except Exception: pass
        out.write_text(code, encoding="utf-8")
        try: messagebox.showinfo("ShrimpDev", f"Gespeichert:\n{out}")
        except Exception: pass
        status.set(f"Gespeichert: {out}")

    b = ttk.Frame(frm); b.pack(fill="x", pady=6)
    ttk.Button(b, text="Erkennen (Ctrl+I)", command=_detect).pack(side="left")
    ttk.Button(b, text="Speichern (Ctrl+S)", command=_save).pack(side="right")
    frm.bind_all("<Control-i>", lambda e: _detect())
    frm.bind_all("<Control-s>", lambda e: _save())

    def _on_mod(_=None):
        txt.edit_modified(0)
        if not var_name.get() or not var_ext.get(): _detect(auto=True)
    txt.bind("<<Modified>>", _on_mod)

    return frm

def open_intake(app: tk.Tk) -> bool:
    try: return ensure_tab(app, "intake", "Code Intake", _build_tab)
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Intake Fehler:\n{ex}")
        except Exception: pass
        return False
'''

PROJECT_UI = r'''from __future__ import annotations
import os, json, tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from .common_tabs import ensure_tab

def _scan(ws: Path) -> dict:
    out = {"root": str(ws), "modules": [], "tools": [], "snippets": [], "other": []}
    if not ws.exists(): return out
    for p in ws.rglob("*"):
        if p.is_dir(): continue
        rel = p.relative_to(ws).as_posix()
        if rel.startswith("modules/snippets/"): out["snippets"].append(rel)
        elif rel.startswith("modules/"):        out["modules"].append(rel)
        elif rel.startswith("tools/"):          out["tools"].append(rel)
        else:                                   out["other"].append(rel)
    return out

def _build_tab(parent):
    from modules.config_mgr import load_config
    frm = ttk.Frame(parent)
    try: conf = load_config()
    except Exception: conf = {"workspace_root": r"D:\ShrimpHub"}
    ws = Path(conf.get("workspace_root", r"D:\ShrimpHub"))

    top = ttk.Frame(frm); top.pack(fill="x", pady=6)
    ttk.Label(top, text="Workspace:").pack(side="left")
    var_ws = tk.StringVar(value=str(ws))
    ttk.Entry(top, textvariable=var_ws, width=60).pack(side="left", padx=6)
    cols=("type","path"); tree=ttk.Treeview(frm, columns=cols, show="headings")
    for c,w in zip(cols,(120,820)): tree.heading(c, text=c); tree.column(c, width=w, anchor="w")
    tree.pack(fill="both", expand=True)
    def refresh():
        wsr = Path(var_ws.get().strip() or r"D:\ShrimpHub")
        data = _scan(wsr)
        for i in tree.get_children(): tree.delete(i)
        for k in ("modules","snippets","tools","other"):
            for rel in data.get(k, []): tree.insert("", "end", values=(k, rel))
    ttk.Button(top, text="Scan", command=refresh).pack(side="left", padx=6)
    refresh()
    return frm

def open_project_map(app: tk.Tk) -> bool:
    try: return ensure_tab(app, "project", "Project Map", _build_tab)
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Project Map Fehler:\n{ex}")
        except Exception: pass
        return False
'''

RUNNER_BOARD = r'''from __future__ import annotations
import subprocess, tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from .common_tabs import ensure_tab

ROOT = Path(r"D:\ShrimpDev")

def _list():
    t = ROOT/"tools"
    out=[]
    if t.exists():
        for p in sorted(t.glob("Runner_*.*")):
            if p.suffix.lower() in {".py",".bat",".cmd"}:
                out.append((p.name, p.suffix.lower().lstrip(".")))
    return out

def _build_tab(parent):
    frm = ttk.Frame(parent)
    bar = ttk.Frame(frm); bar.pack(fill="x", pady=6)
    ttk.Button(bar, text="Refresh", command=lambda: refresh()).pack(side="left")
    tree = ttk.Treeview(frm, columns=("file","type"), show="headings")
    for c,w in (("file",650),("type",160)): tree.heading(c, text=c); tree.column(c, width=w, anchor="w")
    tree.pack(fill="both", expand=True)

    def refresh():
        for i in tree.get_children(): tree.delete(i)
        for name, typ in _list(): tree.insert("", "end", values=(name, typ))
    def run_sel(_evt=None):
        sel = tree.focus()
        if not sel: return
        name, typ = tree.item(sel, "values")
        cmd = ["cmd","/c","start","", str(ROOT/"tools"/name)]
        try: subprocess.Popen(cmd, cwd=str(ROOT), shell=False)
        except Exception as ex:
            try: messagebox.showerror("ShrimpDev", f"Startfehler:\n{ex}")
            except Exception: pass
    tree.bind("<Double-1>", run_sel)
    refresh()
    return frm

def open_runner_board(app: tk.Tk) -> bool:
    try: return ensure_tab(app, "runners", "Runner Board", _build_tab)
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Runner Board Fehler:\n{ex}")
        except Exception: pass
        return False
'''

SETTINGS_UI = r'''from __future__ import annotations
import json, tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from .common_tabs import ensure_tab

ROOT = Path(r"D:\ShrimpDev")
CFG  = ROOT / "config.json"

def _load() -> dict:
    if not CFG.exists(): return {"workspace_root": r"D:\ShrimpHub", "quiet_mode": True}
    try: return json.loads(CFG.read_text(encoding="utf-8", errors="ignore") or "{}") or {}
    except Exception: return {"workspace_root": r"D:\ShrimpHub", "quiet_mode": True}

def _save(conf: dict):
    try: CFG.write_text(json.dumps(conf, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception: pass

def _build_tab(parent):
    frm = ttk.Frame(parent)
    conf = _load()
    ttk.Label(frm, text="Workspace Root:").grid(row=0, column=0, sticky="w", padx=10, pady=10)
    var_ws = tk.StringVar(value=conf.get("workspace_root", r"D:\ShrimpHub"))
    ttk.Entry(frm, textvariable=var_ws, width=46).grid(row=0, column=1, sticky="we", padx=6, pady=10)
    def _pick():
        d = filedialog.askdirectory(title="Workspace wählen", initialdir=str(Path(var_ws.get() or r"D:\\")))
        if d: var_ws.set(d)
    ttk.Button(frm, text="…", command=_pick).grid(row=0, column=2)
    var_quiet = tk.BooleanVar(value=bool(conf.get("quiet_mode", True)))
    ttk.Checkbutton(frm, text="Quiet Mode (Popup-Reduktion)", variable=var_quiet).grid(row=1, column=1, sticky="w", padx=6)
    def _save_btn():
        conf["workspace_root"] = var_ws.get().strip() or r"D:\ShrimpHub"
        conf["quiet_mode"] = bool(var_quiet.get())
        _save(conf)
        try: messagebox.showinfo("ShrimpDev", "Gespeichert.")
        except Exception: pass
    ttk.Button(frm, text="Speichern", command=_save_btn).grid(row=2, column=1, sticky="e", padx=6, pady=12)
    return frm

def open_settings(app: tk.Tk) -> bool:
    try: return ensure_tab(app, "settings", "Settings", _build_tab)
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Settings Fehler:\n{ex}")
        except Exception: pass
        return False
'''

PREFLIGHT = r'''from __future__ import annotations
import sys, tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
import time
from .common_tabs import ensure_tab

ROOT = Path(r"D:\ShrimpDev")
OUT  = ROOT / "_Reports" / "Preflight"
OUT.mkdir(parents=True, exist_ok=True)

def _checks():
    rows=[]
    rows.append(("python", sys.version.split()[0], "OK" if sys.version_info >= (3,10) else "WARN"))
    try:
        import tkinter as t
        rows.append(("tkinter", "available", "OK"))
    except Exception as ex:
        rows.append(("tkinter", f"error: {ex}", "FAIL"))
    for d in (ROOT/"modules", ROOT/"tools", ROOT/"_Reports"):
        rows.append((f"dir:{d.name}", "exists" if d.exists() else "missing", "OK" if d.exists() else "WARN"))
    return rows

def _build_tab(parent):
    frm = ttk.Frame(parent)
    b = ttk.Frame(frm); b.pack(fill="x", pady=6)
    tree = ttk.Treeview(frm, columns=("item","value","status"), show="headings")
    for c,w in zip(("item","value","status"),(300,280,80)): tree.heading(c, text=c); tree.column(c, width=w, anchor="w")
    tree.pack(fill="both", expand=True)
    def run():
        rows = _checks()
        for i in tree.get_children(): tree.delete(i)
        for r in rows: tree.insert("", "end", values=r)
        rep = OUT / f"Preflight_{time.strftime('%Y%m%d_%H%M%S')}.txt"
        rep.write_text("\n".join([f\"{a}\t{b}\t{c}\" for a,b,c in rows]), encoding="utf-8")
    ttk.Button(b, text="Run Checks", command=run).pack(side="right", padx=10)
    run()
    return frm

def open_preflight(app: tk.Tk) -> bool:
    try: return ensure_tab(app, "preflight", "Preflight", _build_tab)
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Preflight Fehler:\n{ex}")
        except Exception: pass
        return False
'''

PATCH_RELEASE = r'''from __future__ import annotations
import zipfile, tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
import time
from .common_tabs import ensure_tab

ROOT = Path(r"D:\ShrimpDev")
OUT  = ROOT / "_Exports"
OUT.mkdir(parents=True, exist_ok=True)

def _include(p: Path) -> bool:
    rel = p.relative_to(ROOT).as_posix()
    if rel.startswith("_Reports/") or rel.startswith("_Exports/") or rel.startswith("dist/"): return False
    if "/__pycache__/" in rel: return False
    return True

def _build_tab(parent):
    frm = ttk.Frame(parent)
    ttk.Label(frm, text="Erstellt ein ZIP der aktuellen ShrimpDev-Struktur.").pack(anchor="w", padx=10, pady=8)
    def build():
        name = f"ShrimpDev_patch_{time.strftime('%Y%m%d_%H%M%S')}.zip"
        target = OUT / name
        with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for p in ROOT.rglob("*"):
                if p.is_file() and _include(p):
                    z.write(p, p.relative_to(ROOT))
        try: messagebox.showinfo("ShrimpDev", f"Export:\n{target}")
        except Exception: pass
    ttk.Button(frm, text="Build ZIP", command=build).pack(pady=10)
    return frm

def open_patch_release(app: tk.Tk) -> bool:
    try: return ensure_tab(app, "patch", "Patch / Export", _build_tab)
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Patch/Release Fehler:\n{ex}")
        except Exception: pass
        return False
'''

def patch_main_gui():
    mg = ROOT / "main_gui.py"
    backup(mg)
    txt = mg.read_text(encoding="utf-8", errors="ignore")

    # sicherstellen: Imports auf Module (bleiben gleich), MENÜ ruft open_* auf
    # Bindings bleiben, aber jetzt landen sie als Tabs über ensure_tab().
    # Hier nur minimaler Guard: nichts tun, wenn bereits ein _tab_registry existiert.
    if "_tab_registry" in txt and "ensure_tab" in txt:
        return

    # Nach Klassendefinition: Init-Registry
    txt = re.sub(
        r"(class\s+ShrimpDevApp\s*\([^)]*\)\s*:\s*\n\s*def\s+__init__\s*\(\s*self\s*\)\s*:\s*\n)",
        r"\1        self._tab_registry = {}\n",
        txt, count=1
    )

    # oben: Imports der open_* bleiben – Module liefern nun Tabs via ensure_tab

    mg.write_text(txt, encoding="utf-8")

def main():
    w(MODS / "common_tabs.py", COMMON_TABS)
    w(MODS / "module_agent_ui.py", AGENT_UI)
    w(MODS / "module_code_intake.py", CODE_INTAKE)
    w(MODS / "module_project_ui.py", PROJECT_UI)
    w(MODS / "module_runner_board.py", RUNNER_BOARD)
    w(MODS / "module_settings_ui.py", SETTINGS_UI)
    w(MODS / "module_preflight.py", PREFLIGHT)
    w(MODS / "module_patch_release.py", PATCH_RELEASE)
    patch_main_gui()
    print("[R971] Tabs vereinheitlicht – alles läuft in EINEM Fenster.")

if __name__ == "__main__":
    main()
