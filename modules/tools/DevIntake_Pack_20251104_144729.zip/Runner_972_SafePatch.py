from __future__ import annotations
import time, shutil, sys, os
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
TOOLS = ROOT / "tools"
PENDING = ROOT / "_Pending"
LOGF = ROOT / "debug_output.txt"

def log(msg: str):
    try: LOGF.open("a", encoding="utf-8", errors="ignore").write(f"[R972] {msg}\n")
    except Exception: pass
    print(msg)

def write_text_atomic(target: Path, content: str) -> bool:
    tmp = target.with_suffix(target.suffix + f".tmp.{int(time.time()*1000)}")
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp.write_text(content, encoding="utf-8")
    try:
        os.replace(tmp, target)  # atomic if same volume
        return True
    except PermissionError:
        try: tmp.unlink(missing_ok=True)
        except Exception: pass
        return False

def try_rename(p: Path) -> bool:
    probe = p.with_suffix(p.suffix + ".lockprobe")
    try:
        p.rename(probe)
        probe.rename(p)
        return True
    except Exception:
        return False

def defer_patch(relpath: str, content: str):
    p = Path(relpath)
    pend = PENDING / p
    pend.parent.mkdir(parents=True, exist_ok=True)
    pend_tmp = pend.with_suffix(pend.suffix + ".new")
    pend_tmp.write_text(content, encoding="utf-8")
    log(f"deferred -> {pend.relative_to(ROOT)}")

def ensure_apply_hook():
    # apply_pending_patches.bat
    bat = TOOLS / "apply_pending_patches.bat"
    if not bat.exists():
        bat.write_text(rf"""@echo off
setlocal
cd /d "D:\ShrimpDev"
set PENDING=_Pending
if not exist "%PENDING%" exit /b 0
for /r "%PENDING%" %%F in (*) do (
  set "REL=%%F"
  setlocal enabledelayedexpansion
  set "REL=!REL:D:\ShrimpDev\_Pending\=!"
  for %%# in ("!REL!") do (
    if not exist "D:\ShrimpDev\%%~dp#" mkdir "D:\ShrimpDev\%%~dp#"
    copy /y "%%F" "D:\ShrimpDev\!REL!" >nul
  )
  endlocal
)
rem Cleanup nur leere Ordner löschen:
for /f "delims=" %%D in ('dir /b /s /ad "%PENDING%" ^| sort /r') do rd "%%D" 2>nul
exit /b 0
""", encoding="utf-8")

    # start_visible.bat einmalig vorschalten
    start_bat = TOOLS / "start_visible.bat"
    if start_bat.exists():
        txt = start_bat.read_text(encoding="utf-8", errors="ignore")
        mark = "REM [R972] APPLY-PENDING"
        if mark not in txt:
            lines = []
            inserted = False
            for line in txt.splitlines():
                if not inserted and line.strip().lower().startswith(("py -3 -u", "python", "py ")):
                    lines.append('call tools\\apply_pending_patches.bat')
                    lines.append(mark)
                    inserted = True
                lines.append(line)
            start_bat.write_text("\r\n".join(lines) + "\r\n", encoding="utf-8")
            log("start_visible.bat: apply_pending hook inserted")
    else:
        log("WARN: tools\\start_visible.bat nicht gefunden – Hook nicht gesetzt")

def main():
    ensure_apply_hook()

    # DEMO: Hier definierst du DEINEN Patch-Inhalt (z. B. safe Fix für main_gui.py).
    # Für die Demonstration patchen wir NICHT destruktiv, sondern hängen eine Kommentarzeile an.
    targets: dict[str, str] = {
        r"main_gui.py": "\n# [R972] safe-patch marker\n",
        # weitere Ziele (Beispiel):
        # r"modules\\module_project_ui.py": "...dein inhalt...\n",
        # r"modules\\module_code_intake.py": "...dein inhalt...\n",
    }

    rc = 0
    for rel, addition in targets.items():
        tgt = ROOT / rel
        if not tgt.exists():
            log(f"SKIP (not found): {rel}")
            continue

        # 1) Sperrtest via Rename-Probe
        if not try_rename(tgt):
            log(f"LOCKED: {rel} – wird deferred")
            # Deferred: kompletten Zieltext neu erstellen (anhängen)
            content = tgt.read_text(encoding="utf-8", errors="ignore") + addition
            defer_patch(rel, content)
            rc = max(rc, 1)
            continue

        # 2) Atomic append (read + write_atomic)
        old = tgt.read_text(encoding="utf-8", errors="ignore")
        new = old if old.endswith(addition) else (old + addition)
        if write_text_atomic(tgt, new):
            log(f"PATCHED: {rel}")
        else:
            log(f"FAILED (atomic): {rel} – wird deferred")
            defer_patch(rel, new)
            rc = max(rc, 1)

    if rc == 0:
        log("OK – alle Patches angewendet.")
    else:
        log("INFO – einige Patches sind deferred und werden beim nächsten Start angewendet.")
    return rc

if __name__ == "__main__":
    raise SystemExit(main())
