# -*- coding: utf-8 -*-
"""
Runner_1101_FixIntake_ReindentAll.py
- Repariert Einrückungen/verschachtelte Methoden in modules/module_code_intake.py
- Setzt Tooltip._show/_hide in die Klasse
- Ersetzt def _send_to_recycle_bin(...) durch saubere Implementierung
- Sanity-Compile prüft Syntax; bei Fehler bleibt Datei unverändert
"""

from __future__ import annotations
import os, re, sys, time, io

ROOT = os.path.dirname(os.path.abspath(__file__))
MOD  = os.path.normpath(os.path.join(ROOT, "..", "modules", "module_code_intake.py"))
ARCH = os.path.normpath(os.path.join(ROOT, "..", "_Archiv"))

def read(p): 
    with open(p, "rb") as f: return f.read().decode("utf-8", "replace")

def write(p, s): 
    with open(p, "wb") as f: f.write(s.encode("utf-8", "utf-8"))

def backup(p):
    os.makedirs(ARCH, exist_ok=True)
    b = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    write(b, read(p))
    return b

def indent_block(lines: list[str], start: int, end: int, n=4):
    pad = " " * n
    for i in range(start, end):
        if lines[i].strip():
            lines[i] = pad + lines[i]

def dedent_to(col: int, s: str) -> str:
    out = []
    for ln in s.splitlines(True):
        if ln.strip():
            out.append(ln[col:] if ln.startswith(" " * col) else ln.lstrip("\t"))
        else:
            out.append(ln)
    return "".join(out)

def find_idx(lines, patt, start=0):
    rx = re.compile(patt)
    for i in range(start, len(lines)):
        if rx.search(lines[i]): return i
    return -1

def sanity_compile(src: str):
    ns = {}
    try:
        compile(src, MOD, "exec")
        return True, ""
    except SyntaxError as ex:
        # Umgebung dumpen
        ln = ex.lineno or 0
        lo = max(1, ln - 10); hi = min(len(src.splitlines()), ln + 10)
        buf = io.StringIO()
        print(f"SyntaxError: {ex.msg} (line {ln})", file=buf)
        print("---- context ----", file=buf)
        for no, line in enumerate(src.splitlines()[lo-1:hi], start=lo):
            print(f"{no:04d}: {line}", file=buf)
        print("--------------", file=buf)
        return False, buf.getvalue()

def fix():
    txt = read(MOD)
    lines = txt.splitlines(True)

    changed = False

    # 1) Tooltip._show/_hide in Klasse einrücken
    i_tool = find_idx(lines, r"^\s*class\s+Tooltip\b")
    if i_tool >= 0:
        # finde __init__ Ende
        i_after_init = find_idx(lines, r"^\s*def\s+__init__\s*\(", i_tool)
        if i_after_init >= 0:
            # falls _show/_hide auf Spalte 0 stehen, einrücken
            i_show = find_idx(lines, r"^def\s+_show\(", i_after_init)
            i_hide = find_idx(lines, r"^def\s+_hide\(", i_after_init)
            if i_show != -1:
                j = i_show
                while j < len(lines) and not re.match(r"^\s*(class|def)\s+", lines[j]) or j == i_show:
                    j += 1
                indent_block(lines, i_show, j, 4)
                changed = True
            if i_hide != -1:
                j = i_hide
                while j < len(lines) and not re.match(r"^\s*(class|def)\s+", lines[j]) or j == i_hide:
                    j += 1
                indent_block(lines, i_hide, j, 4)
                changed = True

    # 2) IntakeFrame-Methoden: ab _bind_shortcuts bis _on_click_delete_selected einrücken
    i_class = find_idx(lines, r"^\s*class\s+IntakeFrame\b")
    if i_class >= 0:
        i_bind = find_idx(lines, r"^def\s+_bind_shortcuts\(", i_class)  # Spalte 0?
        if i_bind == -1:
            i_bind = find_idx(lines, r"^\s*def\s+_bind_shortcuts\(", i_class)
            # trotzdem prüfen ob zu wenig Einrückung:
            if i_bind >= 0 and not lines[i_bind].startswith(" " * 8):
                pass
        i_after = find_idx(lines, r"^\s*import\s+re\s+as\s+_re1089")
        if i_bind >= 0 and i_after > i_bind:
            # alles dazwischen auf Klasse-Niveau (8 Leerzeichen) bringen
            for k in range(i_bind, i_after):
                if lines[k].strip():
                    # mindestens 8 Leerzeichen voranstellen, aber nicht doppelt
                    if not lines[k].startswith("        "):
                        lines[k] = "        " + lines[k].lstrip()
            changed = True

        # 2a) _ping darf NICHT in _update_led verschachtelt sein -> auf Klassenebene (8)
        i_ping = find_idx(lines, r"^\s{4}def\s+_ping\(")  # fälschlich mit 4
        if i_ping != -1:
            lines[i_ping] = "        " + lines[i_ping].lstrip()
            changed = True

        # 2b) _run_py, _path_from_selection_or_fields, _after_paste_refresh ebenfalls Klassenmethoden
        for name in ("_run_py", "_path_from_selection_or_fields", "_after_paste_refresh"):
            i_fn = find_idx(lines, rf"^def\s+{name}\(")
            if i_fn != -1:
                j = i_fn + 1
                while j < len(lines) and not re.match(r"^\s*(def|class|# --- R1089: Windows Recycle Bin helper)", lines[j]):
                    j += 1
                indent_block(lines, i_fn, j, 8)  # an Klasse angleichen
                changed = True

    # 3) Recycle-Bin-Helper komplett ersetzen (robust, Windows)
    rx_bin = re.compile(r"(?s)#\s*---\s*R1089:\s*Windows Recycle Bin helper.*?\Z")
    if rx_bin.search("".join(lines)):
        repl = r'''# --- R1089: Windows Recycle Bin helper ---------------------------------------
def _send_to_recycle_bin(path: str) -> bool:
    try:
        import ctypes
        from ctypes import wintypes
    except Exception:
        return False
    if not os.path.exists(path):
        return False
    FO_DELETE = 3
    FOF_ALLOWUNDO = 0x0040
    FOF_NOCONFIRMATION = 0x0010

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [
            ("hwnd", wintypes.HWND),
            ("wFunc", wintypes.UINT),
            ("pFrom", wintypes.LPCWSTR),
            ("pTo", wintypes.LPCWSTR),
            ("fFlags", ctypes.c_uint16),
            ("fAnyOperationsAborted", wintypes.BOOL),
            ("hNameMappings", ctypes.c_void_p),
            ("lpszProgressTitle", wintypes.LPCWSTR),
        ]

    pFrom = path + "\x00\x00"
    sh = SHFILEOPSTRUCTW(
        hwnd=None, wFunc=FO_DELETE, pFrom=pFrom, pTo=None,
        fFlags=FOF_ALLOWUNDO | FOF_NOCONFIRMATION,
        fAnyOperationsAborted=False, hNameMappings=None, lpszProgressTitle=None,
    )
    rc = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(sh))
    return rc == 0 and not sh.fAnyOperationsAborted
# -----------------------------------------------------------------------------'''
        newtxt = rx_bin.sub(repl, "".join(lines))
        if newtxt != "".join(lines):
            lines = newtxt.splitlines(True)
            changed = True

    if not changed:
        print("[R1101] Keine Änderungen nötig.")
        return 0

    # Vor dem Schreiben: Sanity-Compile
    new_src = "".join(lines)
    ok, info = sanity_compile(new_src)
    bkp = backup(MOD)
    print(f"[R1101] Backup: {MOD} -> {bkp}")
    if not ok:
        print("[R1101] Syntaxprüfung FEHLGESCHLAGEN – Datei bleibt unverändert.")
        print(info)
        return 2
    write(MOD, new_src)
    print("[R1101] Reparaturen geschrieben.")
    return 0

if __name__ == "__main__":
    raise SystemExit(fix())
