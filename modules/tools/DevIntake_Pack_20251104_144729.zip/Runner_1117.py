# -*- coding: utf-8 -*-
"""
Runner_1117 – Deep Sanity Framework für ShrimpDev Intake-Toolbar
- Führt automatisch Runner_1116g aus
- Syntaxprüfung + Kontextauszug
- Startet main_gui.py mit Timeout, detektiert RecursionError
- Statische Analysen: Tkinter-Bindings, doppelte Aufrufe, zirkuläre Verweise
- Zentrale Logs in debug_output.txt + Detailberichte in _Reports/

Kompatibel: Python 3.10+ (empfohlen 3.12)
"""
from __future__ import annotations
import os, sys, re, io, time, shutil, subprocess, textwrap, traceback, ast
from datetime import datetime
from typing import Dict, List, Tuple, Set, Optional

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TOOLS = os.path.join(ROOT, "tools")
MODULES = os.path.join(ROOT, "modules")
ARCHIV = os.path.join(ROOT, "_Archiv")
REPORTS = os.path.join(ROOT, "_Reports")
LOGFILE = os.path.join(ROOT, "debug_output.txt")

TARGET_FILE = os.path.join(MODULES, "module_code_intake.py")
MAIN_GUI = os.path.join(ROOT, "main_gui.py")
RUNNER_1116G = os.path.join(TOOLS, "Runner_1116g_FixToolbarBlock.py")

TIMEOUT_GUI_SEC = 25  # GUI-Laufzeitfenster
CONTEXT_LINES = 12    # Syntax-Kontext

# ---------- Logging ----------
def _log(msg: str) -> None:
    os.makedirs(os.path.dirname(LOGFILE), exist_ok=True)
    with open(LOGFILE, "a", encoding="utf-8", newline="") as f:
        f.write(msg.rstrip() + "\n")
    print(msg)

def _section(title: str) -> None:
    bar = "=" * 70
    _log(f"{bar}\n[R1117] {title}\n{bar}")

def _write_report(path: str, content: str) -> None:
    os.makedirs(REPORTS, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(content)

# ---------- Hilfsfunktionen ----------
def _timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def _read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def _safe_backup(path: str) -> Optional[str]:
    if not os.path.exists(path):
        return None
    os.makedirs(ARCHIV, exist_ok=True)
    dst = os.path.join(ARCHIV, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, dst)
    return dst

def _run_cmd(cmd: List[str], cwd: Optional[str] = None, timeout: Optional[int] = None) -> Tuple[int, str]:
    try:
        p = subprocess.Popen(cmd, cwd=cwd or ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8")
        out, _ = p.communicate(timeout=timeout)
        return p.returncode, out
    except subprocess.TimeoutExpired:
        p.kill()
        out = ""
        return 124, out

def _python_exe() -> List[str]:
    # bevorzugt py -3
    return ["py", "-3"]

def _surrounding_context(src: str, lineno: int, ctx: int = CONTEXT_LINES) -> str:
    lines = src.splitlines()
    start = max(1, lineno - ctx)
    end = min(len(lines), lineno + ctx)
    out = []
    for i in range(start, end + 1):
        mark = ">>" if i == lineno else "  "
        out.append(f"{mark} {i:5d}: {lines[i-1]}")
    return "\n".join(out)

# ---------- 1) 1116g ausführen ----------
def run_1116g() -> Tuple[int, str]:
    if not os.path.exists(RUNNER_1116G):
        return (0, "[HINWEIS] Runner_1116g_FixToolbarBlock.py nicht gefunden – Überspringe.")
    _section("Runner_1116g ausführen")
    cmd = _python_exe() + ["-u", os.path.relpath(RUNNER_1116G, ROOT)]
    rc, out = _run_cmd(cmd)
    _log(f"[1116g] RC={rc}")
    for line in out.splitlines():
        _log(f"[1116g] {line}")
    return rc, out

# ---------- 2) Syntaxprüfung mit Kontext ----------
def syntax_check_with_context(path: str) -> Tuple[bool, str]:
    _section(f"Syntaxprüfung: {os.path.relpath(path, ROOT)}")
    report_lines = []
    ok = True
    try:
        src = _read(path)
        compile(src, path, "exec")
        _log("[Syntax] OK")
        report_lines.append(f"[Syntax] OK: {path}")
    except SyntaxError as e:
        ok = False
        _log(f"[Syntax] ERROR: {e.__class__.__name__}: {e}")
        try:
            src = _read(path)
            ctx = _surrounding_context(src, e.lineno or 1, CONTEXT_LINES)
        except Exception:
            ctx = "<Kontext konnte nicht gelesen werden>"
        report_lines.append(f"[Syntax] ERROR in {path}: {e.__class__.__name__}: {e}")
        report_lines.append("\n-- Kontext --\n" + ctx)
    except Exception as e:
        ok = False
        _log(f"[Syntax] ERROR: {e.__class__.__name__}: {e}")
        report_lines.append(f"[Syntax] ERROR in {path}: {e.__class__.__name__}: {e}")
        report_lines.append(traceback.format_exc())

    report = "\n".join(report_lines) + "\n"
    _write_report(os.path.join(REPORTS, "Runner_1117_syntax_report.txt"), report)
    return ok, report

# ---------- 3) GUI-Start & Recursion-Erkennung ----------
def start_gui_and_capture(timeout_sec: int = TIMEOUT_GUI_SEC) -> Tuple[int, str]:
    _section("GUI-Start: main_gui.py")
    if not os.path.exists(MAIN_GUI):
        msg = "[GUI] main_gui.py nicht gefunden – Überspringe."
        _log(msg)
        return (0, msg)
    cmd = _python_exe() + ["-u", os.path.relpath(MAIN_GUI, ROOT)]
    rc, out = _run_cmd(cmd, timeout=timeout_sec)
    cap_path = os.path.join(REPORTS, "Runner_1117_main_gui_capture.txt")
    _write_report(cap_path, out or "")
    _log(f"[GUI] RC={rc}, Output gespeichert: _Reports\\{os.path.basename(cap_path)}")

    # RecursionError-Signaturen detektieren
    recursion_hit = False
    for line in (out or "").splitlines():
        if "RecursionError:" in line:
            recursion_hit = True
            break
    if recursion_hit:
        _log("[GUI] RecursionError erkannt – Details siehe Capture.")
    return rc, out or ""

# ---------- 4) Deep Sanity Analysen ----------
class MethodInfo:
    def __init__(self, name: str, lineno: int):
        self.name = name
        self.lineno = lineno
        self.calls: Set[str] = set()

def _collect_method_calls(src: str) -> Dict[str, MethodInfo]:
    """
    Sehr robuste, aber einfache Analyse:
    - Methoden-Defs: def name(self, ...)
    - Aufrufe: self.name(
    """
    methods: Dict[str, MethodInfo] = {}
    for m in re.finditer(r'^\s*def\s+([A-Za-z_]\w*)\s*\(\s*self\b[^)]*\):', src, flags=re.MULTILINE):
        name = m.group(1)
        lineno = src[:m.start()].count("\n") + 1
        methods[name] = MethodInfo(name, lineno)

    for name, info in methods.items():
        # Suche im Body dieser Methode bis zur nächsten Def/Klassenende
        start = re.search(rf'^\s*def\s+{re.escape(name)}\s*\(\s*self\b[^)]*\):', src, flags=re.MULTILINE).end()
        nxt = re.search(r'^\s*def\s+[A-Za-z_]\w*\s*\(\s*self\b', src[start:], flags=re.MULTILINE)
        end = start + (nxt.start() if nxt else len(src) - start)
        body = src[start:end]

        for c in re.finditer(r'\bself\.([A-Za-z_]\w*)\s*\(', body):
            callee = c.group(1)
            info.calls.add(callee)
    return methods

def _find_binds_and_commands(src: str) -> Tuple[List[Tuple[int,str,str]], List[Tuple[int,str]]]:
    """
    Returns:
      binds: List[(lineno, sequence, callback)]
      cmds:  List[(lineno, callback)]
    """
    binds = []
    cmds = []
    for m in re.finditer(r'\.bind\s*\(\s*([\'"])(.+?)\1\s*,\s*([A-Za-z_][\w\.]*)', src):
        lineno = src[:m.start()].count("\n") + 1
        seq = m.group(2)
        cb = m.group(3)
        binds.append((lineno, seq, cb))

    # Button(..., command=cb)
    for m in re.finditer(r'Button\s*\([^)]*?\bcommand\s*=\s*([A-Za-z_][\w\.]*)', src, flags=re.DOTALL):
        lineno = src[:m.start()].count("\n") + 1
        cb = m.group(1)
        cmds.append((lineno, cb))
    return binds, cmds

def deep_sanity(path: str) -> str:
    _section("Deep Sanity Analyse (Bindings/Calls/Zyklen)")
    if not os.path.exists(path):
        msg = "[Sanity] Ziel-Datei nicht gefunden."
        _log(msg)
        return msg

    src = _read(path)
    report = io.StringIO()
    report.write(f"Datei: {os.path.relpath(path, ROOT)}\nZeit : {datetime.now()}\n\n")

    # Heuristik: Fokusbereich Toolbar (~120–180) + umgebende Klasse
    lines = src.splitlines()
    approx_slice = "\n".join(lines[max(0,120-40):min(len(lines), 180+40)])

    binds, cmds = _find_binds_and_commands(src)
    report.write("[Bindings]\n")
    for ln, seq, cb in binds:
        report.write(f"  Zeile {ln:>5}: bind({seq!r}, {cb})\n")
    if not binds:
        report.write("  (keine gefunden)\n")
    report.write("\n[Button-Commands]\n")
    for ln, cb in cmds:
        report.write(f"  Zeile {ln:>5}: command={cb}\n")
    if not cmds:
        report.write("  (keine gefunden)\n")

    # Doppelte Aufrufe: Gleichnamiger Callback in bind UND command
    report.write("\n[Verdacht: doppelte Callback-Verwendung]\n")
    bind_cbs = {(cb) for _,_,cb in binds}
    dup = []
    for ln, cb in cmds:
        if cb in bind_cbs:
            dup.append((ln, cb))
    if dup:
        for ln, cb in dup:
            report.write(f"  ⚠ Callback '{cb}' taucht in command und bind auf (z.B. Zeile {ln}).\n")
        report.write("  → Empfehlung: bind-Handler auf Button mit lambda e: button.invoke(); return 'break'\n")
        report.write("    oder nur eine Quelle beibehalten (command ODER bind-basiert), um Doppeltrigger zu vermeiden.\n")
    else:
        report.write("  (kein offensichtlicher Doppeltrigger gefunden)\n")

    # Callgraph / Rekursion
    methods = _collect_method_calls(src)
    report.write("\n[Methoden & Aufrufe]\n")
    for name, info in methods.items():
        calls = ", ".join(sorted(info.calls)) if info.calls else "-"
        report.write(f"  def {name} (Z {info.lineno}) -> [{calls}]\n")

    # Direkte Rekursion
    report.write("\n[Direkte Rekursion]\n")
    direct = [m for m in methods.values() if m.name in m.calls]
    if direct:
        for m in direct:
            report.write(f"  ⚠ {m.name} ruft sich selbst auf (Z {m.lineno}).\n")
    else:
        report.write("  (keine direkte Rekursion)\n")

    # Einfache Zyklen (Länge 2 / 3)
    report.write("\n[Zirkuläre Verweise]\n")
    name_idx = {n:i for i,n in enumerate(methods.keys())}
    cyc_lines = []
    # Länge 2
    for a, A in methods.items():
        for b in A.calls:
            if b in methods and a in methods[b].calls and a < b:
                cyc_lines.append(f"  ⚠ 2er-Zyklus: {a} ↔ {b}")
    # Länge 3 (einfach)
    names = list(methods.keys())
    for i,a in enumerate(names):
        for b in methods[a].calls:
            if b not in methods: continue
            for c in methods[b].calls:
                if c not in methods: continue
                if a in methods[c].calls and len({a,b,c})==3:
                    trio = " → ".join([a,b,c,a])
                    cyc_lines.append(f"  ⚠ 3er-Zyklus: {trio}")
    if cyc_lines:
        report.write("\n".join(sorted(set(cyc_lines))) + "\n")
    else:
        report.write("  (keine Zyklen 2/3 erkannt)\n")

    # Auszug des vermuteten Toolbar-Fensters für schnelle Sichtprüfung
    report.write("\n[Toolbar-Kontext ~Z120–180 ±40]\n")
    report.write(textwrap.indent(approx_slice if approx_slice.strip() else "(kein Auszug)", "  "))

    findings = report.getvalue()
    _write_report(os.path.join(REPORTS, "Runner_1117_sanity_findings.txt"), findings)

    # Zusätzlich Callgraph Roh-Ausgabe
    cg = io.StringIO()
    for name, info in methods.items():
        for callee in sorted(info.calls):
            cg.write(f"{name} -> {callee}\n")
    _write_report(os.path.join(REPORTS, "Runner_1117_callgraph.txt"), cg.getvalue())
    _log("[Sanity] Analyseberichte geschrieben.")
    return findings

# ---------- 5) Orchestrierung ----------
def main() -> int:
    _section("Start Runner_1117")
    _log(f"[Info] ROOT={ROOT}")

    # 1116g ausführen
    rc_1116g, out_1116g = run_1116g()

    # Backups
    _section("Backups")
    b1 = _safe_backup(TARGET_FILE)
    if b1: _log(f"[Backup] {os.path.relpath(TARGET_FILE, ROOT)} -> {os.path.relpath(b1, ROOT)}")
    else:  _log(f"[Backup] {os.path.relpath(TARGET_FILE, ROOT)} nicht gefunden (kein Backup).")

    # Syntaxprüfungen
    ok1, rep1 = syntax_check_with_context(TARGET_FILE)

    # GUI-Start
    rc_gui, out_gui = start_gui_and_capture(TIMEOUT_GUI_SEC)

    # Deep Sanity
    findings = deep_sanity(TARGET_FILE)

    _section("Zusammenfassung")
    _log(f"[Sum] 1116g RC={rc_1116g}")
    _log(f"[Sum] Syntax module_code_intake.py: {'OK' if ok1 else 'FEHLER'} (siehe _Reports\\Runner_1117_syntax_report.txt)")
    if "RecursionError:" in (out_gui or ""):
        _log("[Sum] GUI: RecursionError erkannt (siehe _Reports\\Runner_1117_main_gui_capture.txt)")
        _log("[Sum] Nächster Schritt: gezielte Entschärfung der Doppeltrigger/Zyklen laut Sanity-Bericht.")
        return 2
    else:
        _log("[Sum] GUI: kein RecursionError detektiert (innerhalb Zeitfenster).")
    _log("[Sum] Sanity-Analyse: siehe _Reports\\Runner_1117_sanity_findings.txt")
    _log("[Ende] Runner_1117 abgeschlossen.")
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        _section("UNERWARTETER FEHLER")
        _log(traceback.format_exc())
        sys.exit(99)
