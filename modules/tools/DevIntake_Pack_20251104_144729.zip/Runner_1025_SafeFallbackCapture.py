"""
Runner_1025_SafeFallbackCapture
- FIX: Safe-Import-Fallbacks kapseln das Traceback direkt im except-Block,
       damit nicht 'NoneType: None' angezeigt wird.
- Version -> v9.9.16
"""
from __future__ import annotations
import os, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
GUI  = os.path.join(ROOT, "main_gui.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

SAFE_BLOCK = r'''# ---- Safe imports for frames (with fallbacks) ----
try:
    from modules.module_code_intake import IntakeFrame
except Exception:
    import traceback as _tb_intake
    _INTAKE_ERR = _tb_intake.format_exc()
    def IntakeFrame(master, _err=_INTAKE_ERR):
        import tkinter as tk, tkinter.ttk as ttk
        frm = ttk.Frame(master)
        txt = tk.Text(frm, height=12, wrap="word")
        txt.pack(fill="both", expand=True, padx=8, pady=8)
        txt.insert("end", "Fehler: IntakeFrame konnte nicht geladen werden.\\n\\n" + (_err or ""))
        return frm

try:
    from modules.module_agent_ui import AgentFrame
except Exception:
    import traceback as _tb_agent
    _AGENT_ERR = _tb_agent.format_exc()
    def AgentFrame(master, _err=_AGENT_ERR):
        import tkinter as tk, tkinter.ttk as ttk
        frm = ttk.Frame(master)
        tk.Label(frm, text="Agent-UI konnte nicht geladen werden.").pack(padx=10, pady=10)
        tk.Message(frm, text=_err or "", width=900).pack(padx=10, pady=4)
        return frm

try:
    from modules.module_project_ui import ProjectFrame
except Exception:
    import traceback as _tb_proj
    _PROJ_ERR = _tb_proj.format_exc()
    def ProjectFrame(master, _err=_PROJ_ERR):
        import tkinter as tk, tkinter.ttk as ttk
        frm = ttk.Frame(master)
        tk.Label(frm, text="Project-UI konnte nicht geladen werden.").pack(padx=10, pady=10)
        tk.Message(frm, text=_err or "", width=900).pack(padx=10, pady=4)
        return frm
# -----------------------------------------------'''

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1025] {ts} {msg}\n")
    except Exception:
        pass
    print(msg, flush=True)

def backup_write(path: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

def patch_main() -> None:
    with open(GUI, "r", encoding="utf-8") as f:
        src = f.read()

    start_tag = "# ---- Safe imports for frames"
    end_tag   = "# -----------------------------------------------"
    s = src.find(start_tag)
    e = src.find(end_tag, s if s != -1 else 0)
    if s == -1 or e == -1:
        raise RuntimeError("Safe-Import-Block nicht gefunden.")
    new_src = src[:s] + SAFE_BLOCK + src[e+len(end_tag):]

    backup_write(GUI, new_src)

def bump_meta() -> None:
    with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
        f.write("ShrimpDev v9.9.16\n")
    with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
        f.write("""
## v9.9.16 (2025-10-18)
- main_gui: Safe-Fallbacks erfassen Tracebacks im except-Block (kein 'NoneType: None' mehr)
""")

def main() -> int:
    patch_main()
    bump_meta()
    log("Patch erfolgreich.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
