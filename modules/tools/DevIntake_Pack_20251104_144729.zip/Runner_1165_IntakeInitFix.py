# -*- coding: utf-8 -*-
"""
R1165 IntakeInitFix
Ziel: Intake-UI lädt wieder. Fix: Weist das vorhandene Toolbar-Frame 'bar'
als Fallback auf self.frm_actions zu, direkt nach dessen Erstellung.
So funktionieren alle nachfolgenden Button-Erzeugungen, egal ob sie 'bar'
oder 'self.frm_actions' als Parent verwenden.

Sicherheitsnetz:
- Präzises Einfügen nach der ersten 'bar = ttk.Frame(' Zeile in _build_ui()
- Backup -> _Archiv
- Syntax-Check, Rollback on error
"""
from __future__ import annotations
import io, re, time, shutil, py_compile, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
LOGF = ROOT / "debug_output.txt"

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1165] {ts} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f: f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(p: Path) -> Path:
    ARCH.mkdir(parents=True, exist_ok=True)
    dst = ARCH / f"{p.name}.{int(time.time())}.bak"
    shutil.copy2(p, dst)
    log(f"Backup: {p} -> {dst}")
    return dst

def inject_fix(src: str) -> tuple[str, list[str]]:
    """
    Sucht _build_ui(), findet die Zeile 'bar = ttk.Frame(...' und fügt direkt
    darunter 'self.frm_actions = bar' mit gleicher Einrückung ein, falls noch nicht vorhanden.
    """
    changes = []
    # 1) _build_ui-Block lokalisieren
    m = re.search(r"^\s*def\s+_build_ui\s*\(\s*self[^\)]*\)\s*:\s*$", src, re.M)
    if not m:
        return src, changes
    block_start = m.end()
    tail = src[block_start:]
    # 2) erste Zeile mit 'bar = ttk.Frame(' finden
    mbar = re.search(r"^(\s*)bar\s*=\s*ttk\.Frame\([^)]*\)\s*$", tail, re.M)
    if not mbar:
        return src, changes
    indent = mbar.group(1)
    insert_pos = block_start + mbar.end()
    # 3) prüfen, ob bereits ein Zuweisung exists
    block_until_next_def = re.split(r"^\s*def\s+\w+\s*\(", tail[mbar.start():], maxsplit=1, flags=re.M)[0]
    if "self.frm_actions = bar" in block_until_next_def:
        changes.append("Assignment already present; nothing to do")
        return src, changes
    # 4) Einfügen
    fix_line = f"\n{indent}self.frm_actions = bar  # R1165: map toolbar frame to frm_actions for compatibility\n"
    new_src = src[:insert_pos] + fix_line + src[insert_pos:]
    changes.append("Inserted 'self.frm_actions = bar' after toolbar creation")
    return new_src, changes

def main() -> int:
    try:
        if not MOD.exists():
            log(f"[ERR] Not found: {MOD}")
            return 2
        src = MOD.read_text(encoding="utf-8")
        bak = backup(MOD)
        new_src, changes = inject_fix(src)
        if not changes:
            log("No changes applied (pattern not found).")
            return 0

        MOD.write_text(new_src, encoding="utf-8", newline="\n")
        for c in changes: log(f"Change: {c}")

        try:
            py_compile.compile(str(MOD), doraise=True)
            log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}")
            shutil.copy2(bak, MOD)
            log("Restored from backup.")
            return 3

        log("R1165 completed successfully.")
        return 0

    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
