"""
Runner_1026_IntakeIndentFix
Behebt IndentationError in module_code_intake.py (Zeile ~258)
Version -> v9.9.17
"""
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1026] {ts} {msg}\n")
    print(msg)

def backup_write(path: str, data: str):
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

def fix_indent(src: str) -> str:
    lines = src.splitlines()
    fixed = []
    inside_save = False
    for line in lines:
        if re.match(r"^\s*def\s+_save\s*\(", line):
            inside_save = True
            fixed.append(line)
            continue
        if inside_save:
            if re.match(r"^\s*def\s+", line) and not line.startswith("        "):
                inside_save = False
            elif re.match(r"^\s*\S", line) and not line.startswith(" " * 8):
                # korrekte Einrückung sicherstellen
                line = "        " + line.lstrip()
        fixed.append(line)
    return "\n".join(fixed)

def patch():
    with open(MOD, "r", encoding="utf-8") as f:
        src = f.read()
    new_src = fix_indent(src)
    if new_src != src:
        backup_write(MOD, new_src)
        log("module_code_intake.py: Einrückungen korrigiert (IndentFix).")
    else:
        log("module_code_intake.py: keine Änderung erforderlich.")

    with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
        f.write("ShrimpDev v9.9.17\n")
    with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
        f.write("""
## v9.9.17 (2025-10-18)
- module_code_intake: IndentationError in _save() behoben
""")

if __name__ == "__main__":
    raise SystemExit(patch())
