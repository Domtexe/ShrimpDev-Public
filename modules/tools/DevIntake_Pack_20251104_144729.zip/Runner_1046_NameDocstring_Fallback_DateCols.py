"""
Runner_1046_NameDocstring_Fallback_DateCols
- _guess_name_from_text: erkennt jetzt auch 'Runner_XXXX_...' OHNE Endung (z.B. im Docstring).
- _detect: letzter Fallback setzt snippet_YYYYMMDD_HHMMSS, wenn Name weiterhin leer ist.
- Treeview: Spalten auf ('name','ext','subfolder','date','time') erweitert und _load_table füllt sie.
- Version -> v9.9.36
"""
from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1046] {ts} {msg}\n")
    except Exception:
        pass

def _read(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def _write_backup(p: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bck)
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {p} -> {bck}")

def patch() -> int:
    src = _read(MOD)
    changed = False

    # 1) _guess_name_from_text: Bare-Runner ohne Endung unterstützen
    if "Bare Runner" not in src:
        src = src.replace(
            "def _guess_name_from_text(self, text):",
            "def _guess_name_from_text(self, text):  # + Bare Runner (Docstring/Kommentar)"
        )
    # Einfügen eines zusätzlichen Regex-Zweigs (nur falls noch nicht vorhanden)
    if "Bare Runner (ohne Endung)" not in src:
        src = re.sub(
            r"(def\s+_guess_name_from_text\([^\)]*\):[\s\S]+?return \"\", \"\"\s*)",
            r"""\1
        # Bare Runner (ohne Endung) z.B. im Docstring: 'Runner_1045_NameDetect'
        m = re.search(r'(?i)\\b(Runner_[0-9]{3,5}[_A-Za-z0-9\\-]+)\\b', t)
        if m:
            return m.group(1), ""  # Endung fehlt -> später aus Heuristik/Ext-Feld
""",
            src, count=1, flags=re.MULTILINE
        )
        changed = True

    # 2) _detect: wenn Name nach allen Schritten leer -> snippet_YYYYMMDD_HHMMSS
    if "snippet_" not in src:
        src = re.sub(
            r"(def\s+_detect\([^\)]*\):[\s\S]+?self\._ping\([^\n]+\)\n\s*return ok\s*)",
            r"""\1
        # finaler Fallback: Name generieren, falls leer und nicht manuell
        if not self.var_name_manual and not (self.var_name.get() or "").strip():
            ts = time.strftime("%Y%m%d_%H%M%S")
            self.var_name.set(f"snippet_{ts}{ext or ''}")
""",
            src, count=1, flags=re.MULTILINE
        )
        changed = True

    # 3) Treeview: Spalten um date/time erweitern (wenn nicht vorhanden)
    src2 = re.sub(
        r'cols\s*=\s*\(\s*"name"\s*,\s*"ext"\s*,\s*"subfolder"\s*\)',
        'cols = ("name","ext","subfolder","date","time")',
        src
    )
    if src2 != src:
        src = src2
        changed = True

    src2 = re.sub(
        r'for c,w,a in \(\("name",\s*240,\s*"w"\),\("ext",\s*70,\s*"center"\),\("subfolder",\s*180,\s*"w"\)\):\s*\n\s*self\.tbl\.heading\(c,\s*text=c\);\s*self\.tbl\.column\(c,\s*anchor=a,\s*width=w,\s*stretch=\(c!="ext"\)\)',
        'for c,w,a in (("name",240,"w"),("ext",70,"center"),("subfolder",180,"w"),("date",110,"center"),("time",90,"center")):\n            self.tbl.heading(c, text=c); self.tbl.column(c, anchor=a, width=w, stretch=(c!="ext"))',
        src
    )
    if src2 != src:
        src = src2
        changed = True

    # 4) _load_table: date/time befüllen
    if "strftime(\"%Y-%m-%d\"" not in src:
        src = re.sub(
            r'self\.tbl\.insert\(\"\", \"end\", values=\(name, \(ext or \"\"\)\.lower\(\), sub\)\)',
            '                try:\n                    ts = os.path.getmtime(p)\n                    dt = time.strftime("%Y-%m-%d", time.localtime(ts))\n                    tm = time.strftime("%H:%M:%S", time.localtime(ts))\n                except Exception:\n                    dt, tm = "", ""\n                self.tbl.insert("", "end", values=(name, (ext or "").lower(), sub, dt, tm))',
            src
        )
        changed = True

    if changed:
        _write_backup(MOD, src)
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.36\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.36 (2025-10-18)
- Name-Detect: erkennt jetzt auch 'Runner_XXXX_*' ohne Endung (z.B. in Docstrings).
- Fallback: generiert snippet_YYYYMMDD_HHMMSS, wenn kein Name gefunden und nicht manuell.
- Tabelle: neue Spalten 'date' und 'time', gefüllt aus Datei-mtime.
""")
        log("Patch angewendet.")
    else:
        log("Keine Änderungen nötig.")
    return 0

if __name__ == "__main__":
    raise SystemExit(patch())
