from __future__ import annotations
from pathlib import Path
import re, time, shutil, py_compile, sys

ROOT = Path(r"D:\ShrimpDev")
MAIN = ROOT / "main_gui.py"

def ts(): return time.strftime("%Y%m%d_%H%M%S")
def backup(p: Path):
    if p.exists():
        b = p.with_suffix(p.suffix + f".{ts()}.bak")
        shutil.copy2(p, b)
        print(f"[R954] Backup: {b.name}")

GOOD_AGENT_BLOCK = (
    "        # Agent starten\n"
    "        try:\n"
    "            if not getattr(agent.AGENT, '_started', False):\n"
    "                agent.AGENT.start(); setattr(agent.AGENT, '_started', True)\n"
    "        except Exception:\n"
    "            pass\n"
)

def normalize_agent_block(txt: str) -> tuple[str, bool]:
    """
    Ersetzt die komplette Agent-Start-Zone in __init__ zwischen
    '# Agent starten' und der Zeile mit 'log(\"GUI ready\")' durch
    einen sauberen, idempotenten Block.
    """
    if "# Agent starten" not in txt:
        return txt, False

    # Ersetze Bereich zwischen Kommentar und 'log("GUI ready")'
    slab = re.compile(
        r'(^[ \t]*#\s*Agent starten\s*\n)'      # Startmarke
        r'(?:(?:.|\n)*?)'                       # beliebiger Inhalt (non-greedy)
        r'(^[ \t]*log\("GUI ready"\)\s*$)',     # Endmarke
        re.M
    )
    def _repl(m: re.Match[str]) -> str:
        return m.group(1) + GOOD_AGENT_BLOCK + m.group(2) + "\n"

    new, n = slab.subn(_repl, txt, count=1)
    return (new, n > 0)

def squash_double_excepts(txt: str) -> tuple[str, int]:
    """
    Faltet direkt aufeinanderfolgende 'except Exception:'-Blöcke mit nur 'pass'
    zu einem einzigen Block zusammen.
    """
    pattern = re.compile(
        r'(?m)^([ \t]*)except\s+Exception\s*:\s*\n\1[ \t]{4}pass[^\S\r\n]*#.*?\n'
        r'\1except\s+Exception\s*:\s*\n\1[ \t]{4}pass[^\S\r\n]*(?:#.*)?\n'
    )
    cnt = 0
    while True:
        new, n = pattern.subn(r'\1except Exception:\n\1    pass\n', txt)
        txt = new
        cnt += n
        if n == 0:
            break
    return txt, cnt

def compile_ok(p: Path) -> tuple[bool, str]:
    try:
        py_compile.compile(str(p), doraise=True)
        return True, ""
    except Exception as ex:
        return False, str(ex)

def main() -> int:
    if not MAIN.exists():
        print("[R954] FEHLT: main_gui.py"); return 2

    backup(MAIN)
    txt = MAIN.read_text(encoding="utf-8", errors="ignore")

    changed = False

    # 1) Agent-Startblock normalisieren
    txt, ch1 = normalize_agent_block(txt); changed |= ch1
    if ch1: print("[R954] Agent-Startblock normalisiert.")

    # 2) Doppelte except/ pass -Reste zusammenfalten
    txt, squashed = squash_double_excepts(txt)
    if squashed:
        changed = True
        print(f"[R954] Doppelte 'except Exception: pass' gefaltet: {squashed}")

    if changed:
        MAIN.write_text(txt, encoding="utf-8")
    else:
        print("[R954] Keine Änderungen nötig.")

    ok, err = compile_ok(MAIN)
    if ok:
        print("[R954] Syntax OK – main_gui.py kompiliert.")
        return 0
    else:
        print(f"[R954] FEHLER bleibt: {err}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
