# -*- coding: utf-8 -*-
"""
R1163f FixPyHeadRegex
- Repariert die fehlerhafte Regex in modules/module_code_intake.py (_guess_ext_from_text),
  die vom Scanner als "unterminated subpattern" gemeldet wurde.
- Ersetzt die problematische Zeile:
      if re.search(r"...def\s+\w+\(|class\s+\w+\(|if\s+__name__...", " "+head): return ".py"
  durch eine robuste, vorkompilierte Variante:
      if RE_PY_HEAD.search(" "+head): return ".py"
- Fügt einmalig (falls noch nicht vorhanden) oben eine Konstante RE_PY_HEAD hinzu.
- Safety: Backup, Syntax-Check, Rollback.
"""
from __future__ import annotations
import os, io, re, time, shutil, py_compile, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
LOGF = ROOT / "debug_output.txt"

HEADER_SNIPPET = (
    "\n# --- R1163f: precompiled regex for python head detection ---\n"
    "RE_PY_HEAD = re.compile(\n"
    "    r\"(?m)^\\s*(?:\" \n"
    "    r\"from\\s+\\w+\\s+import|\"\n"
    "    r\"import\\s+\\w+|\"\n"
    "    r\"def\\s+\\w+\\s*\\(|\"\n"
    "    r\"class\\s+\\w+\\s*\\(|\"\n"
    "    r\"if\\s+__name__\\s*==\\s*['\\\"]__main__['\\\"]\"\n"
    "    r\")\",\n"
    ")\n"
)

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1163f] {ts} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(path: Path) -> Path:
    ARCH.mkdir(parents=True, exist_ok=True)
    dst = ARCH / f"{path.name}.{int(time.time())}.bak"
    shutil.copy2(path, dst)
    log(f"Backup: {path} -> {dst}")
    return dst

def patch_source(src: str) -> tuple[str, list[str]]:
    changes: list[str] = []

    # 1) Konstante RE_PY_HEAD einfügen, wenn nicht vorhanden
    if "RE_PY_HEAD = re.compile(" not in src:
        # Einfügen direkt nach den Imports (nach der tkinter-Importstelle)
        insert_after = 0
        lines = src.splitlines(True)
        for i, ln in enumerate(lines[:200]):  # großzügiges Fenster
            if "from tkinter import ttk" in ln or "import tkinter" in ln:
                insert_after = i + 1
        if insert_after == 0:
            insert_after = 0
        src = "".join(lines[:insert_after]) + HEADER_SNIPPET + "".join(lines[insert_after:])
        changes.append("Added RE_PY_HEAD precompiled regex")

    # 2) Problematische re.search(...) Zeile ersetzen
    #    Wir suchen die Zeile mit ^\s*if re.search(r"(?m)^\s*(from...
    lines = src.splitlines(True)
    replaced = False
    for i, ln in enumerate(lines):
        if "if re.search(r\"(?m)^\\s*(from" in ln.replace(" ", ""):
            # Ersetze komplette Zeile durch die sichere Variante
            indent = ln[:len(ln) - len(ln.lstrip())]
            lines[i] = f'{indent}if RE_PY_HEAD.search(" "+head): return ".py"\n'
            replaced = True
            break
    if replaced:
        src = "".join(lines)
        changes.append("Replaced head-detection re.search(...) with RE_PY_HEAD.search(...)")
    else:
        # fallback: nichts kaputtmachen
        changes.append("No target line found for replacement")

    return src, changes

def main() -> int:
    try:
        if not MOD.exists():
            log(f"[ERR] Not found: {MOD}")
            return 2
        src = MOD.read_text(encoding="utf-8")
        bak = backup(MOD)
        new_src, changes = patch_source(src)
        for c in changes:
            log(f"Change: {c}")
        if "Replaced head-detection" not in " ".join(changes):
            log("No changes applied (nothing to replace).")
            return 0

        MOD.write_text(new_src, encoding="utf-8", newline="\n")

        try:
            py_compile.compile(str(MOD), doraise=True)
            log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}")
            shutil.copy2(bak, MOD)
            log("Restored from backup.")
            return 3

        # Sanity: Kompilierbarkeit der Regex sicherstellen
        try:
            re.compile(r"(?m)^\s*(?:from\s+\w+\s+import|import\s+\w+|def\s+\w+\s*\(|class\s+\w+\s*\(|if\s+__name__\s*==\s*['\"]__main__['\"])")
            log("Probe-Compile of RE_PY_HEAD: OK")
        except re.error as ex:
            log(f"[ERR] RE_PY_HEAD compile failed: {ex}")
            shutil.copy2(bak, MOD)
            log("Restored from backup.")
            return 4

        log("R1163f completed successfully.")
        return 0

    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
