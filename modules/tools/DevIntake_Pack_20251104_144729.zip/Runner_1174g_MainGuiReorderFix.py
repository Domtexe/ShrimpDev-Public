# -*- coding: utf-8 -*-
"""
Runner 1174g – MainGui Reorder Fix
Verschiebt den __main__-Block ans Dateiende, hinter alle Funktionsdefinitionen.
Behebt NameError auf _safe_add_intake_tab.
"""
import os, re, time, shutil, py_compile, traceback, sys

ROOT = r"D:\ShrimpDev"
TARGET = os.path.join(ROOT, "main_gui.py")
ARCHIV = os.path.join(ROOT, "_Archiv")
DBG = os.path.join(ROOT, "debug_output.txt")
os.makedirs(ARCHIV, exist_ok=True)

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1174g {ts}] {msg}"
    print(line)
    with open(DBG, "a", encoding="utf-8") as f:
        f.write(line + "\n")

def backup(src):
    ts = str(int(time.time()))
    dst = os.path.join(ARCHIV, f"main_gui.py.{ts}.bak")
    shutil.copy2(src, dst)
    log(f"Backup erstellt: {dst}")
    return dst

def read(p):
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def write(p, s):
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)

def main():
    if not os.path.exists(TARGET):
        log("FEHLER: main_gui.py nicht gefunden.")
        return 2

    src = read(TARGET)
    bak = backup(TARGET)

    # __main__-Block ausschneiden
    pattern = re.compile(
        r"if __name__ == ['\"]__main__['\"]:(?:\n    .*)+",
        re.MULTILINE
    )
    matches = list(pattern.finditer(src))
    if not matches:
        log("Kein __main__-Block gefunden – keine Änderung.")
        return 0

    main_block = matches[-1].group(0)
    cleaned = pattern.sub("", src).rstrip() + "\n\n" + main_block + "\n"

    tmp = TARGET + ".1174g.tmp"
    write(tmp, cleaned)

    try:
        py_compile.compile(tmp, doraise=True)
    except Exception as ex:
        log("Syntaxfehler -> Rollback.")
        log("".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        shutil.copy2(bak, TARGET)
        os.remove(tmp)
        return 1

    write(TARGET, cleaned)
    os.remove(tmp)
    log("Patch übernommen, Syntax OK.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
