# Runner_1096_Reindent_IntakeMethods.py
# Reindents IntakeFrame methods that slipped to top-level and adds a class safeguard.

import os, re, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")

METHOD_NAMES = {"__init__"}
METHOD_PREFIXES = ("_build", "_on_", "_schedule", "_auto_detect", "_detect", "_ping")

def backup(path: str):
    os.makedirs(ARCH, exist_ok=True)
    b = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "rb") as fi, open(b, "wb") as fo:
        fo.write(fi.read())
    print(f"[R1096] Backup: {path} -> {b}")

def is_target_def(line: str) -> bool:
    m = re.match(r'^def\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(', line)
    if not m:
        return False
    name = m.group(1)
    return (name in METHOD_NAMES) or any(name.startswith(p) for p in METHOD_PREFIXES)

def main() -> int:
    if not os.path.exists(MOD):
        print(f"[R1096] Datei nicht gefunden: {MOD}")
        return 1

    src = open(MOD, "r", encoding="utf-8", errors="replace").read()
    lines = src.splitlines(keepends=True)

    # find class IntakeFrame
    cls_i = None
    for i, ln in enumerate(lines):
        if re.match(r'^\s*class\s+IntakeFrame\b.*:\s*(?:#.*)?\r?$', ln.rstrip()):
            cls_i = i
            break
    if cls_i is None:
        print("[R1096] Keine 'class IntakeFrame' gefunden – keine Änderungen.")
        return 0

    changed = False

    # Safeguard: at least one indented line after class
    def next_real_index(j):
        k = j + 1
        while k < len(lines) and lines[k].strip() == "":
            k += 1
        return k if k < len(lines) else None

    k = next_real_index(cls_i)
    if k is None:
        lines.append("    pass  # R1096 safeguard\n")
        changed = True
    else:
        if re.match(r'^\S', lines[k]):  # next content at col 0
            lines.insert(k, "    pass  # R1096 safeguard\n")
            changed = True

    # Reindent top-level decorators+def blocks that belong to IntakeFrame
    i = 0
    while i < len(lines):
        ln = lines[i]
        if re.match(r'^\S', ln):  # only col-0 candidates
            deco_end = i
            while deco_end < len(lines) and lines[deco_end].startswith("@") and re.match(r'^\S', lines[deco_end]):
                deco_end += 1
            if deco_end < len(lines) and lines[deco_end].startswith("def ") and is_target_def(lines[deco_end]):
                j = deco_end + 1
                while j < len(lines) and not re.match(r'^\S', lines[j]):
                    j += 1
                for t in range(i, j):
                    lines[t] = "    " + lines[t]
                changed = True
                i = j
                continue
        i += 1

    if not changed:
        print("[R1096] Keine Änderungen nötig.")
        return 0

    backup(MOD)
    with open(MOD, "w", encoding="utf-8") as f:
        f.write("".join(lines))
    print("[R1096] Intake-Methoden eingerückt und Safeguard gesetzt.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
