"""
Runner_1043_NoBell_StripTypeHints
- Entfernt ALLE akustischen Signale (self.bell()) aus module_code_intake.py.
- Entfernt Type-Hints in Funktionssignaturen (Parameter- und Return-Annotationen),
  damit kein '-> str' mehr Syntaxfehler auslöst.
- Lässt Logik/Bindings unverändert.
- Setzt Version v9.9.33.
"""
from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1043] {ts} {msg}\n")
    except Exception:
        pass

def backup_write(path: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

def strip_type_hints(src: str) -> str:
    # Return-Annotationen in def-Zeilen entfernen: ")-> xyz:" oder ")->xyz:"
    src = re.sub(r"(\)\s*->\s*[^:]+:)", "):", src)

    # Parameter-Annotationen innerhalb der Klammern entfernen: "name: Typ" -> "name"
    def _strip_params(m):
        params = m.group(1)
        # entferne alle "name: Typ" (inkl. verschachtelter generics grob)
        params = re.sub(r"(\b\w+)\s*:\s*[^,\)\n]+", r"\1", params)
        # doppelte Spaces bereinigen
        params = re.sub(r"\s{2,}", " ", params)
        return "def " + m.group(2) + "(" + params + "):"

    src = re.sub(r"def\s+([A-Za-z_]\w*)\s*\(([^)]*)\)\s*:",  # erstmal Standard belassen
                 lambda m: _strip_params(m), src)

    return src

def remove_bell_calls(src: str) -> str:
    # _ping und andere Stellen: self.bell() komplett raus
    src = re.sub(r"\n\s*try:\s*\n\s*self\.bell\(\)\s*\n\s*except\s+Exception:\s*\n\s*pass\s*\n", "\n", src)
    src = re.sub(r"\s*self\.bell\(\)\s*;?", "", src)
    return src

def patch() -> int:
    with open(MOD, "r", encoding="utf-8") as f:
        src = f.read()

    new = remove_bell_calls(strip_type_hints(src))
    if new != src:
        backup_write(MOD, new)
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.33\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.33 (2025-10-18)
- Intake: Alle akustischen Signale entfernt (keine bell()).
- Type-Hints aus Funktionssignaturen entfernt (Kompatibilitäts-/Syntax-Fix).
""")
        log("Type-Hints entfernt und bell()-Aufrufe gelöscht.")
    else:
        log("Keine Änderungen nötig.")
    return 0

if __name__ == "__main__":
    raise SystemExit(patch())
