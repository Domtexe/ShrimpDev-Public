"""
Runner_1016_IntakeFix_ContextActions
- Fix für AttributeError: IntakeFrame._open_selected() fehlt
- Fügt _open_selected() ein (Explorer /select), und _path_of_item(), falls nicht vorhanden
- Keine UI-Änderungen, nur Funktionsergänzung
- Version -> v9.9.7
"""
from __future__ import annotations
import os, re, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1016] {ts} {msg}\n")
    print(msg, flush=True)

def backup_write(path: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    log(f"Backup: {path} -> {bck}")
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

OPEN_SELECTED_FUNC = r'''
    def _open_selected(self):
        """Öffnet die markierte Datei im Explorer (mit /select)."""
        sel = self.tbl.selection()
        if not sel:
            return
        path = self._path_of_item(sel[0])
        try:
            if os.path.exists(path):
                os.system(f'explorer /select,"{path}"')
            else:
                base = os.path.dirname(path) or "."
                os.system(f'explorer "{base}"')
        except Exception:
            pass
'''

PATH_OF_ITEM_FUNC = r'''
    def _path_of_item(self, item_id: str) -> str:
        """Erzeugt den absoluten Pfad aus Tabellenwerten (name, ext, subfolder)."""
        vals = self.tbl.item(item_id, "values")
        if not vals:
            return ""
        name, ext, sub = vals
        folder = self.var_target.get() or "."
        if sub:
            folder = os.path.join(folder, sub)
        return os.path.join(folder, f"{name}{ext}")
'''

def ensure_method(src: str, method_name: str, method_block: str) -> tuple[str, bool]:
    if re.search(rf"def\s+{re.escape(method_name)}\s*\(", src):
        return src, False
    # Einfügen am Ende der IntakeFrame-Klasse (vor der letzten Klassen-Klammer)
    m = re.search(r"class\s+IntakeFrame\s*\([\s\S]+?\n\)", src)  # nicht robust genug; daher alternative:
    # Robust: finde Ende der Klasse via Einrückung: wir suchen das letzte 'def ' in der Klasse und hängen danach an
    cls = re.search(r"(class\s+IntakeFrame\s*\([^\)]*\)\s*:\s*\n)([\s\S]+?)(\n^[^\s])", src, flags=re.MULTILINE)
    if cls:
        start, body, tail = cls.group(1), cls.group(2), cls.group(3)
        new_body = body.rstrip() + method_block + "\n"
        return src.replace(start + body + tail, start + new_body + tail), True
    # Fallback: vor Datei-Ende anhängen
    return src.rstrip() + "\n" + method_block + "\n", True

def patch() -> int:
    try:
        with open(MOD, "r", encoding="utf-8") as f:
            src = f.read()

        changed = False
        # os import absichern (brauchen wir für os.path/os.system)
        if not re.search(r"^\s*import\s+os\b", src, flags=re.MULTILINE):
            src = "import os\n" + src
            changed = True

        # _path_of_item sicherstellen (einige Varianten benutzen andere Reihenfolge)
        if not re.search(r"def\s+_path_of_item\s*\(", src):
            src, c = ensure_method(src, "_path_of_item", PATH_OF_ITEM_FUNC)
            changed = changed or c

        # _open_selected ergänzen
        if not re.search(r"def\s+_open_selected\s*\(", src):
            src, c = ensure_method(src, "_open_selected", OPEN_SELECTED_FUNC)
            changed = changed or c

        if changed:
            backup_write(MOD, src)
            log("module_code_intake.py ergänzt (_open_selected/_path_of_item).")
        else:
            log("module_code_intake.py bereits vollständig – kein Patch nötig.")

        # Meta
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.7\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.7 (2025-10-18)
- FIX: Intake-Context „Öffnen im Explorer“ – fehlende Methode _open_selected() ergänzt
- Robustheit: _path_of_item() abgesichert
""")
        return 0
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(patch())
