from __future__ import annotations
from pathlib import Path
import re, time

ROOT = Path(r"D:\ShrimpDev")
MOD  = ROOT / "modules" / "module_code_intake.py"
LOGF = ROOT / "debug_output.txt"

def log(msg: str):
    try: LOGF.open("a", encoding="utf-8", errors="ignore").write(f"[R983] {msg}\n")
    except Exception: pass
    print(f"[R983] {msg}")

def backup(p: Path):
    ts = time.strftime("%Y%m%d_%H%M%S")
    bak = p.with_suffix(p.suffix + f".{ts}.bak")
    p.replace(bak)
    log(f"Backup: {bak.name}")
    return bak

def main() -> int:
    if not MOD.exists():
        log("FEHLT: modules\\module_code_intake.py"); return 2
    src = MOD.read_text(encoding="utf-8", errors="ignore")

    changed = False

    # 1) Geometriemanager-Fix: LED im 'top'-Frame nicht grid() sondern pack(side="right")
    #    wir suchen die Stelle 'led_det.grid(' und wandeln sie in pack um.
    new = re.sub(
        r"led_det\.grid\(.*?\)\s*",
        'led_det.pack(side="right", padx=10)\n',
        src,
        flags=re.DOTALL
    )
    if new != src:
        changed = True
        src = new
        log("Geometry-Fix angewendet (led_det.pack statt grid).")

    # 2) Popup bei Speichern deaktivieren (Silent-Default=True)
    #    a) Default-Config im Fallback: intake_silent_success -> True
    new = re.sub(
        r'"intake_silent_success":\s*False',
        '"intake_silent_success": True',
        src
    )
    if new != src:
        changed = True
        src = new
        log("Silent-Default jetzt True (Popup aus).")

    #    b) Sicherstellen, dass im _save() kein messagebox.showinfo bei Silent=True erscheint.
    #       Falls noch eine harte showinfo drin ist, schützen.
    new = re.sub(
        r"(?s)messagebox\.showinfo\([^)]*\)\s*",
        "pass  # Popup unterdrückt (Silent Mode)\n",
        src
    )
    # aber nur ersetzen, wenn es NICHT bereits in if-not-silent-Block war:
    # (unser Code hatte schon eine if not st.silent-Prüfung – dann ist dieses Muster eh nicht da)
    if new != src:
        changed = True
        src = new
        log("Harte showinfo() entfernt (Popup aus).")

    if not changed:
        log("Keine Änderungen nötig.")
        return 0

    backup(MOD)
    MOD.write_text(src, encoding="utf-8")
    log("Patch geschrieben.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
