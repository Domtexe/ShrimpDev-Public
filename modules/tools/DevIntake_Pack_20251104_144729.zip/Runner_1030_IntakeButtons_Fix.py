"""
Runner_1030_IntakeButtons_Fix
- Repariert/vereinheitlicht die Intake-Buttons (Erkennen/Speichern/Löschen)
- Verhindert Überlappen: Toolbar von pack() -> grid(), Linksausrichtung, Resizing-fest
- Tooltips für die drei Buttons
- Shortcuts erneut binden (Ctrl+I / Ctrl+S / Entf)
- Statische Mini-QA prüft Verkabelung
- Version -> v9.9.20
"""
from __future__ import annotations
import os, re, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1030] {ts} {msg}\n")
    except Exception:
        pass
    print(msg)

TOOLBAR_GRID = r'''
        # Toolbar
        bar = ttk.Frame(self)
        bar.grid(row=2, column=0, sticky="ew", padx=_PADX, pady=(0,4))
        # Layout: feste linke Buttons, Stretch rechts
        for c in (0,1,2): bar.columnconfigure(c, weight=0)
        bar.columnconfigure(3, weight=1)  # Spacer
        self.btn_detect = ttk.Button(bar, text="Erkennen (Ctrl+I)", command=self._detect)
        self.btn_save   = ttk.Button(bar, text="Speichern (Ctrl+S)", command=self._save)
        self.btn_del    = ttk.Button(bar, text="Löschen (Entf)",    command=self._delete_selected)
        self.btn_detect.grid(row=0, column=0, padx=(0,6), sticky="w")
        self.btn_save.grid(  row=0, column=1, padx=(0,6), sticky="w")
        self.btn_del.grid(   row=0, column=2, padx=(0,0), sticky="w")
        # Tooltips
        try:
            Tooltip(self.btn_detect, "Erkennt Endung aus dem Namensfeld (respektiert manuelle Eingabe)")
            Tooltip(self.btn_save,   "Speichert den Editor-Inhalt in Zielordner/Name+Endung")
            Tooltip(self.btn_del,    "Löscht die markierte Datei (oder nur aus der Liste)")
        except Exception:
            pass
'''

SHORTCUTS_FIX = r'''
    def _bind_shortcuts(self):
        root = self.winfo_toplevel()
        try:
            root.unbind_all("<Control-s>")
            root.unbind_all("<Control-i>")
        except Exception:
            pass
        root.bind_all("<Control-s>", lambda e: self._save())
        root.bind_all("<Control-i>", lambda e: self._detect())
        self.tbl.bind("<Control-c>", lambda e: self._copy_selected())
        self.tbl.bind("<Delete>",    lambda e: self._delete_selected())
'''

def patch():
    with open(MOD, "r", encoding="utf-8") as f:
        src = f.read()

    changed = False

    # 1) Toolbar: ersetze pack()-Variante durch gridgeführte Variante
    #    Erkenne vorhandenen Block und ersetze ihn robust zwischen "Toolbar" und "Body"
    src2 = re.sub(
        r"\n\s*#\s*Toolbar[\s\S]+?body\s*=\s*ttk\.Panedwindow",
        "\n" + TOOLBAR_GRID + "\n        body = ttk.Panedwindow",
        src,
        flags=re.MULTILINE
    )
    if src2 != src:
        src = src2
        changed = True

    # 2) Shortcuts robust (unbind + bind_all)
    src2 = re.sub(
        r"def\s+_bind_shortcuts\s*\([\s\S]+?^\s*def\s+_popup_menu",
        SHORTCUTS_FIX + "\n\n    def _popup_menu",
        src,
        flags=re.MULTILINE
    )
    if src2 != src:
        src = src2
        changed = True

    # 3) QA: Buttons existieren als Attribute (btn_detect/save/del) – falls nicht, ergänzen wir Namen
    # (die grid-Zuweisung oben erstellt bereits self.btn_*)

    if changed:
        os.makedirs(ARCH, exist_ok=True)
        bck = os.path.join(ARCH, f"module_code_intake.py.{int(time.time())}.bak")
        shutil.copy2(MOD, bck)
        with open(MOD, "w", encoding="utf-8", newline="\r\n") as f:
            f.write(src)
        log(f"Backup: {MOD} -> {bck}")
        log("Toolbar/Shortcuts neu gesetzt.")
    else:
        log("Keine Änderungen nötig (Toolbar/Shortcuts bereits OK).")

    # Mini-QA (statisch)
    ok = True
    chk = {
        "btn_detect": "self.btn_detect" in src and "command=self._detect" in src,
        "btn_save"  : "self.btn_save"   in src and "command=self._save" in src,
        "btn_del"   : "self.btn_del"    in src and "command=self._delete_selected" in src,
        "shortcut_s": "<Control-s>" in src,
        "shortcut_i": "<Control-i>" in src,
        "shortcut_del": "<Delete>" in src,
    }
    for k, v in chk.items():
        log(f"[QA] {k}: {'OK' if v else 'FEHLT'}")
        ok = ok and v

    # Meta
    with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
        f.write("ShrimpDev v9.9.20\n")
    with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
        f.write("""
## v9.9.20 (2025-10-18)
- Intake: Buttons repariert (grid-Toolbar, saubere Commands, Tooltips)
- Shortcuts gefixt (unbind+bind_all), kein Überlappen beim Resizing
""")
    return 0 if ok else 1

if __name__ == "__main__":
    try:
        raise SystemExit(patch())
    except Exception:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write("[R1030] FEHLER:\n" + traceback.format_exc() + "\n")
        print("FEHLER:\n" + traceback.format_exc())
        raise
