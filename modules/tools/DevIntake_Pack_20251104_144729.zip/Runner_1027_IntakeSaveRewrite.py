"""
Runner_1027_IntakeSaveRewrite
- Repariert IndentationError in modules/module_code_intake.py durch vollständiges
  Neuschreiben von IntakeFrame._save() (korrekte 8-Space-Einrückung)
- Stellt sicher, dass _apply_ext_to_name() als Klassenmethode existiert
- Keine sonstigen Änderungen an der UI/Logik
- Version -> v9.9.18
"""
from __future__ import annotations
import os, re, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1027] {ts} {msg}\n")
    except Exception:
        pass
    print(msg, flush=True)

def backup_write(path: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

SAVE_IMPL = (
    "        def _save(self):\n"
    "            tgt_dir = self.var_target.get().strip() or \".\"\n"
    "            os.makedirs(tgt_dir, exist_ok=True)\n"
    "            name = (self.var_name.get() or \"\").strip()\n"
    "            if not name:\n"
    "                name = \"snippet\"\n"
    "            # Endung gemäß Feld durchsetzen (manuelle Overrides erlaubt)\n"
    "            name = self._apply_ext_to_name(name, self.var_ext.get())\n"
    "            target_path = os.path.join(tgt_dir, name)\n"
    "            data = self.txt.get(\"1.0\",\"end-1c\").encode(\"utf-8\")\n"
    "            try:\n"
    "                with open(target_path, \"wb\") as f:\n"
    "                    f.write(data)\n"
    "                self.cfg.append_history(target_path)\n"
    "                self._load_table()\n"
    "                self._update_led(self.led_save, \"green\")\n"
    "            except Exception:\n"
    "                from tkinter import messagebox\n"
    "                messagebox.showerror(\"Fehler\", \"Konnte nicht speichern.\")\n"
    "                self._update_led(self.led_save, \"red\")\n"
)

APPLY_EXT_IMPL = (
    "        def _apply_ext_to_name(self, name: str, ext: str) -> str:\n"
    "            \"\"\"Erzwingt, dass name mit ext endet (ext inkl. Punkt).\"\"\"\n"
    "            ext = (ext or \"\").strip().lower()\n"
    "            if ext and not ext.startswith('.'):\n"
    "                ext = '.' + ext\n"
    "            base, cur = os.path.splitext(name)\n"
    "            if not ext:\n"
    "                return name if cur else (name + \".txt\")\n"
    "            if (cur or '').lower() == ext:\n"
    "                return name\n"
    "            return (base or name) + ext\n"
)

def replace_method(src: str, name: str, new_body: str) -> str:
    """
    Ersetzt die Methode `name` innerhalb der Klasse IntakeFrame.
    new_body muss bereits mit 8 Spaces eingerückt sein.
    """
    pattern = (
        r"(class\s+IntakeFrame\s*\([^\)]*\)\s*:\s*\n)"
        r"([\s\S]*?)"  # Klasseninhalt
    )
    m = re.search(pattern, src)
    if not m:
        raise RuntimeError("Klasse IntakeFrame nicht gefunden.")

    cls_start = m.start(2)
    cls_body  = m.group(2)

    # Suche Methode
    meth_pat = re.compile(
        rf"(^\s*def\s+{re.escape(name)}\s*\([^\)]*\)\s*:\s*\n)([\s\S]*?)(?=^\s*def\s+\w+\s*\(|^\s*#|\Z)",
        re.MULTILINE
    )
    mm = meth_pat.search(cls_body)
    if not mm:
        # Falls die Methode fehlt, füge sie ans Klassenende ein
        new_cls_body = cls_body.rstrip() + "\n" + new_body + "\n"
    else:
        header = mm.group(1)
        new_cls_body = cls_body[:mm.start()] + header + new_body + cls_body[mm.end():]

    return src[:cls_start] + new_cls_body + src[cls_start + len(cls_body):]

def ensure_apply_ext(src: str) -> str:
    # Existiert _apply_ext_to_name innerhalb der Klasse?
    if re.search(r"^\s*def\s+_apply_ext_to_name\s*\(", src, flags=re.MULTILINE):
        return src
    # vor _save einfügen (falls vorhanden), sonst ans Klassenende
    # ersetze _save zuerst, dann _apply davor setzen
    if re.search(r"^\s*def\s+_save\s*\(", src, flags=re.MULTILINE):
        src = re.sub(
            r"(^\s*def\s+_save\s*\([^\)]*\)\s*:\s*\n)",
            APPLY_EXT_IMPL + r"\n\1",
            src,
            count=1,
            flags=re.MULTILINE
        )
        return src
    # Fallback: an Klassenende anhängen
    return re.sub(
        r"(class\s+IntakeFrame\s*\([^\)]*\)\s*:\s*\n)([\s\S]*?)$",
        lambda m: m.group(1) + m.group(2).rstrip() + "\n" + APPLY_EXT_IMPL + "\n",
        src,
        count=1,
        flags=re.MULTILINE
    )

def main() -> int:
    try:
        with open(MOD, "r", encoding="utf-8") as f:
            src = f.read()

        # 1) _save sauber ersetzen
        tmp = replace_method(src, "_save", SAVE_IMPL)

        # 2) Helper sicherstellen
        tmp = ensure_apply_ext(tmp)

        if tmp != src:
            backup_write(MOD, tmp)
            log("module_code_intake.py: _save neu geschrieben, Helper sichergestellt.")
        else:
            log("module_code_intake.py: keine Änderungen erforderlich.")

        # Meta
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.18\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.18 (2025-10-18)
- Intake: _save() neu geschrieben (korrekte Einrückung, Endungs-Override konsistent)
- Helper _apply_ext_to_name() in der Klasse sichergestellt
""")
        return 0
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
