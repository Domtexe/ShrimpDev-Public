# -*- coding: utf-8 -*-
from __future__ import annotations
import re, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCH = ROOT / "_Archiv"
MODS = ROOT / "modules"
TOOLS = ROOT / "tools"
LOG  = ROOT / "debug_output.txt"

def log(tag, msg):
    try:
        LOG.write_text("", encoding="utf-8") if not LOG.exists() else None
        with LOG.open("a", encoding="utf-8", newline="\n") as f:
            f.write(f"[R1190] {time.strftime('%Y-%m-%d %H:%M:%S')} {tag} {msg}\n")
    except Exception:
        pass

def backup(p: Path):
    ARCH.mkdir(exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    if p.exists():
        b = ARCH / f"{p.as_posix().replace('/', '_')}.{stamp}.bak"
        b.write_bytes(p.read_bytes())
        log("Backup:", str(b))

def write_file(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    backup(path)
    path.write_text(content, encoding="utf-8", newline="\n")
    log("Write:", str(path))

CODE_INTAKE = r'''# -*- coding: utf-8 -*-
from __future__ import annotations
import os, sys, time, zipfile, traceback, configparser, subprocess, re
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

INI_FILE = "dev_intake.ini"

def _log(tag: str, msg: str) -> None:
    try:
        root = Path(__file__).resolve().parents[1]
        with (root / "debug_output.txt").open("a", encoding="utf-8", newline="\n") as f:
            f.write(f"[DevIntake] {time.strftime('%Y-%m-%d %H:%M:%S')} [{tag}] {msg}\n")
    except Exception:
        pass

def _fmt_time(ts: float):
    lt = time.localtime(ts)
    return time.strftime("%Y-%m-%d", lt), time.strftime("%H:%M:%S", lt)

def _open_explorer(p: Path) -> None:
    try:
        if p.is_dir():
            subprocess.Popen(["explorer", str(p)])
        else:
            subprocess.Popen(["explorer", "/select,", str(p)])
    except Exception as e:
        messagebox.showerror("Explorer", str(e))
        _log("EXPLORER_FAIL", str(e))

def _safe_run(cmd: list[str]) -> None:
    try:
        subprocess.Popen(cmd, cwd=os.getcwd(), creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
    except Exception as e:
        messagebox.showerror("Run", f"Start fehlgeschlagen:\n{e}")
        _log("RUN_FAIL", str(e))

def _detect_ext_from_text(text: str) -> str:
    t = (text or "").lstrip()
    tl = t.lower()
    # Batch-Heuristik
    batch_markers = ("@echo off", "\nrem ", "\r\nrem ", "\n::", "\r\n::", " call ", " set ", " if exist ", " goto ", "\n:", "\r\n:")
    if tl.startswith("@echo off") or any(m in tl for m in batch_markers):
        return ".bat"
    # Python-Heuristik
    if ("import " in t) or ("from " in t) or ("def " in t) or ("class " in t) or ("print(" in t) or ("__name__" in t):
        return ".py"
    # Fallback
    return ".txt"

class StatusLED(ttk.Frame):
    def __init__(self, master, color="#9e9e9e", tooltip=""):
        super().__init__(master)
        self._tip = tooltip
        self._tw = None
        self._c = tk.Canvas(self, width=14, height=14, highlightthickness=0, bg=self._bg(master))
        self._c.pack()
        self._oval = self._c.create_oval(2, 2, 12, 12, fill=color, outline="#555")
        self._c.bind("<Enter>", self._show_tip)
        self._c.bind("<Leave>", self._hide_tip)

    @staticmethod
    def _bg(w):
        try:
            return w.cget("background")
        except Exception:
            return "#f0f0f0"

    def set(self, ok: bool | str, tip: str = None):
        # ok kann bool (True/False) oder Farbstring sein
        color = None
        if isinstance(ok, bool):
            color = "#4caf50" if ok else "#e53935"
        else:
            color = str(ok)
        self._c.itemconfig(self._oval, fill=color)
        if tip is not None:
            self._tip = tip

    def _show_tip(self, *_):
        if not self._tip or self._tw:
            return
        x = self._c.winfo_rootx() + 16
        y = self._c.winfo_rooty() + self._c.winfo_height() + 6
        self._tw = tw = tk.Toplevel(self._c)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        tk.Label(tw, text=self._tip, background="#ffffe0", relief="solid", borderwidth=1, justify="left").pack(ipadx=3, ipady=1)

    def _hide_tip(self, *_):
        if self._tw:
            self._tw.destroy()
            self._tw = None

class DevIntake(ttk.Frame):
    _STYLE_INIT = False

    def __init__(self, nb: ttk.Notebook) -> None:
        super().__init__(nb)
        # state
        self.after_id = None
        self.current_path: Path | None = None
        self._dirty = False
        self._syntax_ok = True
        self.sort_state = ("name", True)

        ini = self._load_ini()
        self.workspace = tk.StringVar(value=ini.get("workspace", os.getcwd()))
        self.target_dir = tk.StringVar(value=ini.get("target_dir", str(Path(os.getcwd()) / "tools")))
        self.ext_var    = tk.StringVar(value=ini.get("last_ext", ".py"))
        self.name_var   = tk.StringVar(value=f"snippet_{time.strftime('%Y%m%d_%H%M%S')}")
        self.status     = tk.StringVar(value="Bereit.")
        self.filter_var = tk.StringVar(value="")
        self.ui_split   = float(ini.get("ui_split", "0.60"))
        self.col_widths = ini.get("col_widths", "260,60,160,100,80")

        self._styling()
        self._build_ui()
        self._refresh_list()

    # ------------- ini -------------
    def _load_ini(self) -> dict:
        cfg = configparser.ConfigParser(); p = Path(os.getcwd())/INI_FILE
        if p.exists():
            try:
                cfg.read(p, encoding="utf-8")
                return dict(cfg.items("dev")) if cfg.has_section("dev") else {}
            except Exception:
                _log("INI_READ_FAIL", "fallback")
        return {}

    def _save_ini(self) -> None:
        try:
            cfg = configparser.ConfigParser()
            cfg["dev"] = {
                "workspace": self.workspace.get(),
                "target_dir": self.target_dir.get(),
                "last_ext":   self.ext_var.get(),
                "ui_split":   f"{self.ui_split:.2f}",
                "col_widths": ",".join(str(self.tree.column(c, option="width")) for c in ("name","ext","subfolder","date","time")),
            }
            with (Path(os.getcwd())/INI_FILE).open("w", encoding="utf-8", newline="\n") as f:
                cfg.write(f)
        except Exception as e:
            _log("INI_WRITE_FAIL", str(e))

    # ------------- style -------------
    def _styling(self):
        if DevIntake._STYLE_INIT:
            return
        st = ttk.Style()
        # Flacker-Fix: aktiver Button behält Hintergrund
        st.configure('DevToolbar.TButton', padding=4)
        st.map('DevToolbar.TButton', background=[('active', st.lookup('TButton','background'))])
        st.configure('DevEntry.TEntry', foreground='#111', fieldbackground='#fff')
        st.map('DevEntry.TEntry', fieldbackground=[('readonly','#f7f7f7')])
        DevIntake._STYLE_INIT = True

    # ------------- ui -------------
    def _build_ui(self) -> None:
        top = ttk.Frame(self); top.pack(fill="x", padx=8, pady=6)
        ttk.Label(top, text="Workspace:").grid(row=0, column=0, sticky="w")
        e_ws = ttk.Entry(top, textvariable=self.workspace, width=40, style='DevEntry.TEntry'); e_ws.grid(row=0, column=1, sticky="we", padx=(4,4))
        ttk.Button(top, text="…", width=3, style='DevToolbar.TButton', command=self._pick_workspace).grid(row=0, column=2, padx=(2,10))
        ttk.Label(top, text="Name:").grid(row=0, column=3, sticky="w")
        ttk.Entry(top, textvariable=self.name_var, width=28, style='DevEntry.TEntry').grid(row=0, column=4, sticky="we", padx=(4,10))
        ttk.Label(top, text="Endung:").grid(row=0, column=5, sticky="w")
        ttk.Combobox(top, textvariable=self.ext_var, values=[".py",".bat",".txt"], width=6, state="readonly").grid(row=0, column=6, sticky="w")
        ttk.Label(top, text="Zielordner:").grid(row=0, column=7, sticky="e")
        e_td = ttk.Entry(top, textvariable=self.target_dir, width=36, style='DevEntry.TEntry'); e_td.grid(row=0, column=8, sticky="we", padx=(4,4))
        ttk.Button(top, text="…", width=3, style='DevToolbar.TButton', command=self._pick_target).grid(row=0, column=9)
        for c in (1,4,8): top.columnconfigure(c, weight=1)

        # Toolbar
        bar = ttk.Frame(self); bar.pack(fill="x", padx=8, pady=(0,6))
        def group(label: str) -> ttk.Frame:
            frm = ttk.Labelframe(bar, text=label); frm.pack(side="left", padx=(0,8)); return frm

        g_file = group("Datei")
        ttk.Button(g_file, text="Neu",            style='DevToolbar.TButton', command=self._editor_clear).pack(side="left", padx=2, pady=4)
        ttk.Button(g_file, text="Einfügen",       style='DevToolbar.TButton', command=self._insert_as_new).pack(side="left", padx=2, pady=4)
        ttk.Button(g_file, text="Speichern",      style='DevToolbar.TButton', command=self._save_current).pack(side="left", padx=2, pady=4)
        ttk.Button(g_file, text="Speichern als…", style='DevToolbar.TButton', command=self._save_as).pack(side="left", padx=2, pady=4)

        g_an = group("Analyse")
        ttk.Button(g_an, text="Erkennen (Strg+I)", style='DevToolbar.TButton', command=self._detect_name_ext).pack(side="left", padx=2, pady=4)
        ttk.Button(g_an, text="Guard",             style='DevToolbar.TButton', command=self._guard_check).pack(side="left", padx=2, pady=4)
        ttk.Button(g_an, text="Repair",            style='DevToolbar.TButton', command=self._repair).pack(side="left", padx=2, pady=4)

        g_run = group("Ausführen")
        ttk.Button(g_run, text="Run (F5)",       style='DevToolbar.TButton', command=self._run_current).pack(side="left", padx=2, pady=4)
        ttk.Button(g_run, text="Ordner öffnen",  style='DevToolbar.TButton', command=self._open_target).pack(side="left", padx=2, pady=4)
        ttk.Button(g_run, text="Explorer",       style='DevToolbar.TButton', command=lambda: _open_explorer(Path(self.target_dir.get()))).pack(side="left", padx=2, pady=4)

        g_mgmt = group("Verwaltung")
        ttk.Button(g_mgmt, text="Aktualisieren", style='DevToolbar.TButton', command=self._refresh_list).pack(side="left", padx=2, pady=4)
        ttk.Button(g_mgmt, text="Pack speichern",style='DevToolbar.TButton', command=self._save_pack).pack(side="left", padx=2, pady=4)
        ttk.Button(g_mgmt, text="Löschen",       style='DevToolbar.TButton', command=self._delete_current).pack(side="left", padx=2, pady=4)

        # LED-Bar rechts
        led_bar = ttk.Frame(bar); led_bar.pack(side='right', padx=6)
        self.led_dirty  = StatusLED(led_bar, '#9e9e9e', 'Dirty');  self.led_dirty.pack(side='left')
        self.led_syntax = StatusLED(led_bar, '#9e9e9e', 'Syntax'); self.led_syntax.pack(side='left')
        self.led_name   = StatusLED(led_bar, '#9e9e9e', 'Name');   self.led_name.pack(side='left')
        self.led_ext    = StatusLED(led_bar, '#9e9e9e', 'Ext');    self.led_ext.pack(side='left')
        self.led_ok     = StatusLED(led_bar, '#9e9e9e', 'OK');     self.led_ok.pack(side='left')

        # Filter
        fl = ttk.Frame(self); fl.pack(fill="x", padx=8, pady=(0,4))
        ttk.Label(fl, text="Filter (z. B. name:runner ext:py):").pack(side="left")
        ent = ttk.Entry(fl, textvariable=self.filter_var, width=46, style='DevEntry.TEntry'); ent.pack(side="left", padx=(4,10))
        ttk.Button(fl, text="Anwenden", style='DevToolbar.TButton', command=self._refresh_list).pack(side="left")
        ent.bind("<KeyRelease>", self._on_filter_change)

        # Split
        split = ttk.Panedwindow(self, orient="horizontal"); split.pack(fill="both", expand=True, padx=8, pady=(0,8))
        self.left = ttk.Frame(split); self.right = ttk.Frame(split)
        split.add(self.left, weight=int(self.ui_split*100)); split.add(self.right, weight=int((1.0-self.ui_split)*100))
        self.split = split

        # Editor
        self.editor = tk.Text(self.left, wrap="none", undo=True)
        self.editor.pack(fill="both", expand=True)
        self.editor.bind('<<Modified>>', self._on_modified)
        vsb = ttk.Scrollbar(self.left, orient="vertical", command=self.editor.yview)
        hsb = ttk.Scrollbar(self.left, orient="horizontal", command=self.editor.xview)
        self.editor.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set, selectbackground='#cfe8ff', selectforeground='#000')
        vsb.pack(side="right", fill="y"); hsb.pack(side="bottom", fill="x")

        # Tree
        cols = ("name","ext","subfolder","date","time")
        self.tree = ttk.Treeview(self.right, columns=cols, show="headings", selectmode="browse")
        for c,w in zip(cols, [int(x) for x in (self.col_widths.split(",") if self.col_widths else ["260","60","160","100","80"])]):
            self.tree.heading(c, text=c, command=lambda col=c: self._sort_by(col))
            self.tree.column(c, width=w, anchor="w")
        self.tree.pack(fill="both", expand=True)
        self.tree.tag_configure("even", background="#f6f6f6")
        self.tree.tag_configure("odd",  background="#ffffff")
        self.tree.bind("<<TreeviewSelect>>", self._on_select)
        self.tree.bind("<Double-1>", self._on_double)
        self.tree.bind("<F2>", lambda e: self._rename_current())
        self.menu = tk.Menu(self, tearoff=0)
        self.menu.add_command(label="Run", command=self._run_current)
        self.menu.add_command(label="Rename (F2)", command=self._rename_current)
        self.menu.add_command(label="Delete", command=self._delete_current)
        self.menu.add_separator()
        self.menu.add_command(label="Explorer", command=self._open_target)
        self.tree.bind("<Button-3>", self._popup_menu)

        ttk.Label(self, textvariable=self.status, anchor="w").pack(side="bottom", fill="x")
        # Shortcuts
        self.bind_all("<Control-s>", lambda e: self._save_current())
        self.bind_all("<Control-i>", lambda e: self._detect_name_ext())
        self.bind_all("<F5>",        lambda e: self._run_current())
        self.after(100, self._capture_split)
        self._update_leds()

    # ------------- helpers -------------
    def _capture_split(self):
        try:
            total = self.split.winfo_width() or 1
            self.ui_split = max(0.2, min(0.8, self.left.winfo_width() / total))
        finally:
            self.after(800, self._capture_split)

    def _popup_menu(self, event):
        try:
            iid = self.tree.identify_row(event.y)
            if iid: self.tree.selection_set(iid)
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()

    def _on_filter_change(self, _evt=None):
        if self.after_id: self.after_cancel(self.after_id)
        self.after_id = self.after(250, self._refresh_list)

    def _pick_workspace(self):
        d = filedialog.askdirectory(title="Workspace wählen", initialdir=self.workspace.get())
        if d: self.workspace.set(d); self._save_ini()

    def _pick_target(self):
        d = filedialog.askdirectory(title="Zielordner wählen", initialdir=self.target_dir.get())
        if d: self.target_dir.set(d); self._save_ini(); self._refresh_list()

    def _open_target(self):
        _open_explorer(Path(self.target_dir.get()))

    def _editor_clear(self):
        self.editor.delete("1.0","end"); self.name_var.set(f"snippet_{time.strftime('%Y%m%d_%H%M%S')}")
        self._dirty = False
        self._update_leds()
        self.status.set("Editor geleert.")

    def _detect_name_ext(self):
        src = self.editor.get("1.0","end-1c")
        if not src.strip():
            self.status.set("Nichts zu erkennen (Editor leer)."); return
        # Endung
        ext = _detect_ext_from_text(src)
        # Name
        name = None
        for line in src.splitlines():
            s = line.strip()
            if not s or s.startswith("#") or s.lower().startswith(("rem","::")): 
                continue
            m = re.search(r"(Runner_[0-9]{3,5}_[A-Za-z0-9_]+)", s)
            if m: 
                name = m.group(1)
                break
        if not name:
            name = f"snippet_{time.strftime('%Y%m%d_%H%M%S')}"
        # Syntax grob prüfen (nur .py)
        self._syntax_ok = True
        if ext == ".py":
            try:
                compile(src, "<intake>", "exec")
            except Exception:
                self._syntax_ok = False
        self.ext_var.set(ext); self.name_var.set(name)
        self._update_leds()
        self.status.set(f"Erkannt: {name}{ext}")

    def _path_from_ui(self) -> Path:
        base = (self.name_var.get().strip() or f"snippet_{time.strftime('%Y%m%d_%H%M%S')}")
        ext  = (self.ext_var.get().strip()  or ".py")
        d    = Path(self.target_dir.get().strip() or (Path(os.getcwd())/"tools"))
        d.mkdir(parents=True, exist_ok=True)
        return d / f"{base}{ext}"

    def _highlight_error(self, line: int | None):
        try:
            self.editor.tag_delete('errline')
        except Exception:
            pass
        if not line:
            return
        self.editor.tag_configure('errline', background='#ffd6d6')
        self.editor.tag_add('errline', f'{line}.0', f'{line}.0 lineend')
        self.editor.see(f'{line}.0')

    def _insert_as_new(self):
        p = self._path_from_ui()
        if p.exists() and not messagebox.askyesno("Überschreiben?", f"{p.name} existiert. Überschreiben?"):
            return
        try:
            p.write_text(self.editor.get("1.0","end-1c"), encoding="utf-8")
            self.current_path = p
            self._dirty = False
            self._refresh_list(select=p)
            self._update_leds()
            self.status.set(f"Eingefügt: {p.name}")
        except Exception as e:
            messagebox.showerror("Einfügen", f"{e}"); _log("INSERT_FAIL", str(e))

    def _save_current(self):
        if self.current_path is None:
            self._insert_as_new(); 
            return
        try:
            self.current_path.write_text(self.editor.get("1.0","end-1c"), encoding="utf-8")
            self._dirty = False
            self._refresh_list(select=self.current_path)
            self._update_leds()
            self.status.set(f"Gespeichert: {self.current_path.name}")
        except Exception as e:
            messagebox.showerror("Speichern", f"{e}"); _log("SAVE_FAIL", str(e))

    def _save_as(self):
        p = self._path_from_ui()
        try:
            p.write_text(self.editor.get("1.0","end-1c"), encoding="utf-8")
            self.current_path = p
            self._dirty = False
            self._refresh_list(select=p)
            self._update_leds()
            self.status.set(f"Gespeichert als: {p.name}")
        except Exception as e:
            messagebox.showerror("Speichern als", f"{e}"); _log("SAVEAS_FAIL", str(e))

    def _parse_filter(self, s: str):
        # name:foo ext:py sub:tools + freie Tokens
        d = {'name':None,'ext':None,'sub':None}
        raw = []
        for tok in (s or '').strip().split():
            if ':' in tok:
                k,v = tok.split(':',1)
                if k in d: d[k] = v.lower(); continue
            raw.append(tok.lower())
        return d, raw

    def _refresh_list(self, select: Path|None=None):
        self.tree.delete(*self.tree.get_children())
        root = Path(self.target_dir.get() or (Path(os.getcwd())/"tools"))
        root.mkdir(parents=True, exist_ok=True)
        fdict, raw = self._parse_filter(self.filter_var.get())
        items = []
        for p in root.rglob("*"):
            if p.is_file():
                name_l = p.name.lower()
                sub_l = (str(p.parent.relative_to(root)).lower() if p.parent!=root else '')
                if fdict['name'] and fdict['name'] not in name_l: continue
                if fdict['ext'] and fdict['ext'] != (p.suffix.lower().lstrip('.') or ''): continue
                if fdict['sub'] and fdict['sub'] not in sub_l: continue
                if raw and not all(any(t in x for x in (name_l, sub_l)) for t in raw): continue
                sub = str(p.parent.relative_to(root)) if p.parent != root else ""
                date, tm = _fmt_time(p.stat().st_mtime)
                items.append((p, p.stem, p.suffix, sub, date, tm))
        key, asc = self.sort_state; idx = {"name":1,"ext":2,"subfolder":3,"date":4,"time":5}[key]
        items.sort(key=lambda t: t[idx] or "", reverse=not asc)
        for i,(p, stem, ext, sub, date, tm) in enumerate(items):
            tag = "even" if i%2==0 else "odd"
            self.tree.insert("", "end", iid=str(p), values=(stem, ext, sub, date, tm), tags=(tag,))
        if select and self.tree.exists(str(select)):
            self.tree.selection_set(str(select))
        self.status.set(f"{len(items)} Datei(en) in {root}")
        self._save_ini()

    def _sort_by(self, col: str):
        cur, asc = self.sort_state
        self.sort_state = (col, not asc if col==cur else True)
        self._refresh_list(select=self.current_path)

    def _on_select(self, _evt=None):
        sel = self.tree.selection()
        if not sel: return
        p = Path(sel[0])
        try:
            txt = p.read_text(encoding="utf-8", errors="replace")
            self.editor.delete("1.0","end"); self.editor.insert("1.0", txt)
            self.current_path = p
            self.name_var.set(p.stem); self.ext_var.set(p.suffix or ".txt")
            self.target_dir.set(str(p.parent)); self._dirty = False
            self._save_ini()
            self._update_leds()
            self.status.set(f"Geladen: {p}")
        except Exception as e:
            messagebox.showerror("Laden", f"{e}"); _log("LOAD_FAIL", str(e))

    def _on_double(self, _evt=None):
        self._on_select()

    def _rename_current(self):
        if not self.current_path or not self.current_path.exists():
            messagebox.showinfo("Rename", "Keine Datei ausgewählt."); return
        p = self.current_path
        new = simpledialog.askstring("Rename", f"Neuer Name ohne Endung ({p.suffix} bleibt):", initialvalue=p.stem)
        if not new: return
        target = p.with_name(new + (p.suffix or ""))
        try:
            if target.exists() and not messagebox.askyesno("Überschreiben?", f"{target.name} existiert. Überschreiben?"):
                return
            p.rename(target); self.current_path = target; self.name_var.set(target.stem)
            self._refresh_list(select=target); self.status.set(f"Umbenannt zu: {target.name}")
        except Exception as e:
            messagebox.showerror("Rename", f"{e}"); _log("RENAME_FAIL", str(e))

    def _run_current(self):
        p = self.current_path
        if not p or not p.exists():
            messagebox.showinfo("Run", "Keine Datei ausgewählt."); return
        if p.suffix == ".py":
            _safe_run(["py","-3","-u",str(p)])
        elif p.suffix == ".bat":
            _safe_run([str(p)])
        else:
            messagebox.showinfo("Run", "Nur .py oder .bat werden ausgeführt.")

    def _guard_check(self):
        p = self.current_path
        if not p or not p.exists():
            messagebox.showinfo("Guard", "Keine Datei ausgewählt."); return
        if p.suffix == ".py":
            src = self.editor.get("1.0","end-1c")
            try:
                compile(src, p.name, "exec")
                messagebox.showinfo("Guard", "Syntax OK.")
                self._syntax_ok = True
                self._highlight_error(None)
            except SyntaxError as e:
                self._syntax_ok = False
                line = getattr(e, "lineno", None)
                self._highlight_error(line)
                messagebox.showerror("Guard", f"Syntaxfehler in Zeile {line}:\n{e.msg}")
            except Exception as e:
                self._syntax_ok = False
                messagebox.showerror("Guard", f"Fehler:\n{e}")
        else:
            messagebox.showinfo("Guard", "Guard prüft nur .py")
        self._update_leds()

    def _repair(self):
        p = self.current_path
        if not p or not p.exists():
            return
        try:
            txt = p.read_text(encoding="utf-8", errors="replace")
            txt2 = txt.replace("\r\r\n","\r\n")
            if txt2 != txt:
                p.write_text(txt2, encoding="utf-8", newline="\r\n")
            messagebox.showinfo("Repair", "Kleiner Normalizer angewendet.")
        except Exception as e:
            messagebox.showerror("Repair", f"{e}")

    def _save_pack(self):
        root = Path(self.target_dir.get()); 
        if not root.exists():
            return
        ts = time.strftime("%Y%m%d_%H%M%S"); zf = Path(os.getcwd())/f"DevIntake_Pack_{ts}.zip"
        try:
            with zipfile.ZipFile(zf, "w", zipfile.ZIP_DEFLATED) as z:
                for p in root.rglob("*"):
                    if p.is_file():
                        z.write(p, p.relative_to(root))
            messagebox.showinfo("Pack", f"Pack gespeichert:\n{zf}")
            self.status.set(f"Pack: {zf.name}")
        except Exception as e:
            messagebox.showerror("Pack", f"{e}"); _log("PACK_FAIL", str(e))

    def _delete_current(self):
        p = self.current_path
        if not p or not p.exists():
            messagebox.showinfo("Löschen", "Keine Datei ausgewählt."); return
        if not messagebox.askyesno("Löschen", f"{p.name} wirklich löschen?"):
            return
        try:
            p.unlink(); self.current_path = None; self.editor.delete("1.0","end")
            self._refresh_list(); self.status.set("Datei gelöscht.")
            self._dirty = False; self._update_leds()
        except Exception as e:
            messagebox.showerror("Löschen", f"{e}"); _log("DELETE_FAIL", str(e))

    # --- editor change -> LEDs ---
    def _on_modified(self, _evt=None):
        if self.editor.edit_modified():
            self._dirty = True
            self.editor.edit_modified(False)
            self._update_leds()

    def _update_leds(self):
        name_ok = bool((self.name_var.get() or "").strip())
        ext_ok  = bool((self.ext_var.get() or "").strip())
        ok_all  = bool(name_ok and ext_ok and self._syntax_ok and (not self._dirty))
        self.led_dirty.set(self._dirty,  "Datei geändert" if self._dirty else "Datei unverändert")
        self.led_syntax.set(self._syntax_ok, "Syntax OK" if self._syntax_ok else "Syntaxfehler")
        self.led_name.set(name_ok,  "Name OK" if name_ok else "Name fehlt")
        self.led_ext.set(ext_ok,   "Endung OK" if ext_ok else "Endung fehlt")
        self.led_ok.set(ok_all,   "Alles OK" if ok_all else "Nicht OK")
        # Ende
# ---- Shim-Entry ----
def create_intake_tab(nb: ttk.Notebook) -> None:
    try:
        frame = DevIntake(nb)
        nb.add(frame, text="Intake")
    except Exception:
        f = ttk.Frame(nb)
        ttk.Label(f, text="Intake – Fehler beim Laden. Log prüfen.", foreground="red").pack(padx=12, pady=12, anchor="w")
        nb.add(f, text="Intake")
        traceback.print_exc()
'''

CODE_SHIM = r'''# -*- coding: utf-8 -*-
from __future__ import annotations
from tkinter import ttk
import traceback

def mount_intake_tab(nb: ttk.Notebook):
    """Robuster Mount – nutzt module_code_intake.create_intake_tab."""
    try:
        from modules import module_code_intake as dev_intake
        if hasattr(dev_intake, "create_intake_tab"):
            dev_intake.create_intake_tab(nb)
            return
    except Exception:
        traceback.print_exc()
    # Fallback (leerer Tab mit Hinweis, Crash vermeiden)
    f = ttk.Frame(nb)
    ttk.Label(f, text="Intake – Fehler beim Laden (Details im Log).", foreground="red").pack(padx=12, pady=12, anchor="w")
    nb.add(f, text="Intake")

# Backward-Kompatibilität (alte API-Namen)
def _mount_intake_tab_shim(nb: ttk.Notebook): mount_intake_tab(nb)
def _remount_intake_tab_shim(nb: ttk.Notebook): mount_intake_tab(nb)
def create_intake_tab(nb: ttk.Notebook): mount_intake_tab(nb)
'''

def main():
    write_file(MODS / "module_code_intake.py", CODE_INTAKE)
    write_file(MODS / "module_shim_intake.py", CODE_SHIM)
    log("DONE", "DevIntake installed")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
