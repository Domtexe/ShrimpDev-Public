# -*- coding: utf-8 -*-
"""
[1174p] IntakeCtorFix
- Erzwingt super().__init__(parent) als erste ausführbare Zeile in __init__
- Verschiebt self._build_ui(...) vor dem super()-Aufruf ans Ende des Konstruktors
- Schreibt ein Log in debug_output.txt
"""

import argparse, io, os, re, sys, time

def log_line(root, msg):
    try:
        p = os.path.join(root, "debug_output.txt")
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        with io.open(p, "a", encoding="utf-8") as f:
            f.write(f"[1174p {ts}] {msg}\n")
    except Exception:
        pass

def _indent(s: str) -> int:
    return len(re.match(r'^([ \t]*)', s).group(1).replace("\t","    "))

def find_init_blocks(lines):
    res = []
    cur_class = None
    cur_cindent = 0
    for i, ln in enumerate(lines):
        mcls = re.match(r'^([ \t]*)class\s+([A-Za-z0-9_]+)\s*(?:\(|:)', ln)
        if mcls:
            cur_class = mcls.group(2)
            cur_cindent = _indent(ln)
        mdef = re.match(r'^([ \t]*)def\s+__init__\s*\(', ln)
        if mdef and cur_class and re.search(r'Intake|CodeIntake|IntakeTab', cur_class, re.I):
            dind = _indent(ln)
            j = i + 1
            while j < len(lines):
                if re.match(r'^\s*$', lines[j]):
                    j += 1; continue
                if _indent(lines[j]) <= dind: break
                j += 1
            res.append((cur_class, i, dind, i+1, j))
    return res

def patch_ctor(lines, block, root):
    cls, def_idx, dind, bstart, bend = block
    body = lines[bstart:bend]
    changed = False

    # erste ausführbare Zeile finden (Kommentare/Dreifach-Strings überspringen)
    k, in_triple = 0, None
    while k < len(body):
        ln = body[k]
        if in_triple:
            if in_triple in ln: in_triple = None
            k += 1; continue
        mtri = re.search(r'("""|\'\'\')', ln)
        if mtri:
            q = mtri.group(1)
            if ln.count(q) == 1: in_triple = q
            k += 1; continue
        if re.match(r'^\s*#', ln) or re.match(r'^\s*$', ln):
            k += 1; continue
        break
    first_exec = k if k < len(body) else len(body)

    # super().__init__(parent) sicherstellen
    super_pat = re.compile(r'\bsuper\(\)\.__init__\(\s*parent\s*\)')
    ctor_indent_ws = re.match(r'^([ \t]*)', lines[def_idx]).group(1) + "    "
    super_line = f"{ctor_indent_ws}super().__init__(parent)\n"

    if first_exec == len(body) or not super_pat.search(body[first_exec]):
        body.insert(first_exec, super_line)
        changed = True
        log_line(root, f"IntakeCtorFix: super().__init__ in {cls} eingefuegt/positioniert.")

    # Position des ersten super()-Aufrufs nach obiger Einfügung
    first_super = None
    for idx, ln in enumerate(body):
        if super_pat.search(ln):
            first_super = idx; break
    if first_super is None:
        body.insert(first_exec, super_line)
        first_super = first_exec
        changed = True

    # _build_ui vor super() -> ans Ende (vor return)
    build_pat = re.compile(r'\bself\._build_ui\s*\(')
    keep, movers = [], []
    for idx, ln in enumerate(body):
        if idx < first_super and build_pat.search(ln):
            movers.append(ln); changed = True
        else:
            keep.append(ln)
    if movers:
        insert_at = len(keep)
        for back in range(len(keep)-1, -1, -1):
            if re.match(r'^\s*return\b', keep[back]): insert_at = back; break
        for m in movers:
            keep.insert(insert_at, m); insert_at += 1
        body = keep
        log_line(root, f"IntakeCtorFix: {len(movers)} _build_ui-Call(s) verschoben.")

    # zurückschreiben
    if changed:
        lines[bstart:bend] = body
    return changed

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mod", required=True)
    ap.add_argument("--bak", required=True)
    ap.add_argument("--root", required=True)
    a = ap.parse_args()

    with io.open(a.mod, "r", encoding="utf-8") as f:
        src = f.readlines()

    blocks = find_init_blocks(src)
    if not blocks:
        log_line(a.root, "IntakeCtorFix: keine passende __init__ in Intake-Klassen gefunden.")
        print("[1174p] Keine passende __init__ gefunden.")
        return 0

    changed_any = False
    for b in blocks:
        changed_any |= patch_ctor(src, b, a.root)

    if changed_any:
        with io.open(a.mod, "w", encoding="utf-8", newline="") as f:
            f.writelines(src)
        print("[1174p] Anpassungen geschrieben.")
    else:
        print("[1174p] Bereits korrekt – keine Anpassung erforderlich.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
