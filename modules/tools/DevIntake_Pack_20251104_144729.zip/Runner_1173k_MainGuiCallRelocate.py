# -*- coding: utf-8 -*-
"""
Runner_1173k_MainGuiCallRelocate
- Verschiebt den __main__-Aufrufblock in main_gui.py ans Dateiende,
  damit Helper-Funktionen (z.B. _safe_add_intake_tab) vor dem Aufruf definiert sind.
- Sicher: Backup erfolgt in .bat, hier zusätzlich Syntax-Check und Rollback bei Fehler.
"""
from __future__ import annotations
import io, os, re, sys, py_compile, shutil, time, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "main_gui.py")
ARCH   = os.path.join(ROOT, "_Archiv")

def _log(msg: str) -> None:
    try:
        with open(os.path.join(ROOT, "debug_output.txt"), "a", encoding="utf-8", newline="\n") as f:
            ts = time.strftime("%Y-%m-%d %H:%M:%S")
            f.write(f"[1173k {ts}] {msg}\n")
    except Exception:
        pass

def _read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def _write_text(path: str, text: str) -> None:
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

def _syntax_ok(path: str) -> bool:
    try:
        py_compile.compile(path, doraise=True)
        return True
    except Exception as ex:
        _log("Syntax-Check FEHLER:\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        return False

def main() -> int:
    src = _read_text(TARGET)

    # 1) Finde den __main__-Block (robust, inkl. optionalem try/except drumherum)
    #    Wir suchen die *erste* Zeile mit if __name__ == "__main__"
    m = re.search(r'(?m)^[ \t]*if\s+__name__\s*==\s*[\'"]__main__[\'"]\s*:\s*$', src)
    if not m:
        _log("Kein __main__-Block gefunden – keine Änderung notwendig.")
        return 0

    start = m.start()

    # Der Block geht bis zum Datei-Ende oder bis zu einem speziellen Marker hinter ihm.
    # Wir nehmen alles ab der gefundenen Zeile als call_block:
    call_block = src[start:].rstrip() + "\n"
    head = src[:start].rstrip() + "\n\n"

    # Idempotenz: Nur verschieben, wenn der Block NICHT sowieso bereits am Ende steht.
    # Heuristik: Wenn nach dem Block nur Whitespace ist, ist er schon unten.
    if call_block.strip() and head.strip() == src[:start].strip():
        # Es gibt Kopf + Block (normal). Prüfe, ob hinter dem Block noch nicht-leerer Code folgt.
        tail_after = src[start + len(call_block):].strip()
        if not tail_after:
            _log("__main__-Block steht bereits am Dateiende – keine Änderung.")
            return 0

    new_src = head + call_block  # Block ans Ende verlagern

    # 2) Optional: Doppelte __future__-Imports unterbinden / ganz nach oben ziehen
    #    (Nur kosmetisch, schadet nicht)
    lines = new_src.splitlines()
    fut = [i for i, ln in enumerate(lines[:50]) if ln.strip().startswith("from __future__ import")]
    if len(fut) > 1:
        first = fut[0]
        keep = lines[first]
        lines = [ln for i, ln in enumerate(lines) if not (ln.strip().startswith("from __future__ import") and i != first)]
        new_src = "\n".join(lines)

    # 3) Schreiben + Syntax-Check
    _write_text(TARGET, new_src)
    if not _syntax_ok(TARGET):
        return 2

    _log("__main__-Block erfolgreich ans Ende verlegt.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
