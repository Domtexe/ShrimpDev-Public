# -*- coding: utf-8 -*-
r"""
Runner_1122_RepairMainGUI_SafeLogging
Ziel: RecursionError durch Tk-Exception-Handling eliminieren und ZENTRALES Logging sicherstellen.

Aktionen:
  1) Entfernt alte Guard-Blöcke (1118 / 1118b / 1119 / 1121) aus main_gui.py (idempotent).
  2) Fügt EINEN neuen, zentral-loggenden Top-Level-Guard direkt NACH den
     'from __future__ import ...'-Zeilen ein.
     - Kein messagebox-Aufruf
     - Keine UI-Aktionen im Handler
     - Reentrancy-Guard (busy-Flag)
     - Logging über modules.snippets.logger_snippet.write_log
       (Fallback: best-effort Append nach debug_output.txt)
  3) Legt Backup in _Archiv/ und schreibt Report nach _Reports/.

Start: py -3 -u tools\Runner_1122_RepairMainGUI_SafeLogging.py
"""

from __future__ import annotations
import os, re, time, shutil

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
P_MAIN = os.path.join(ROOT, "main_gui.py")
ARCH   = os.path.join(ROOT, "_Archiv")
REPO   = os.path.join(ROOT, "_Reports")
os.makedirs(ARCH, exist_ok=True)
os.makedirs(REPO, exist_ok=True)
REPORT = os.path.join(REPO, "Runner_1122_RepairMainGUI_SafeLogging_report.txt")

# Früher verwendete Tags/Marker, die wir entfernen
TAG_1118  = "def _install_safe_tk_handler(root):"
TAG_1118B = "def _install_global_tk_guard():"
TAG_1119S = "# === 1119 TopLevel Tk Guard (auto) ==="
TAG_1119E = "# === /1119 ==="
TAG_1121S = "# === 1121 Central Tk Guard (auto) ==="
TAG_1121E = "# === /1121 ==="

# Unser neuer, eindeutiger Tag
TAG_1122S = "# === 1122 Central Tk Guard (auto) ==="
TAG_1122E = "# === /1122 ==="

def rep(msg: str) -> None:
    with open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip() + "\n")

def backup(path: str) -> str:
    ts = str(int(time.time()))
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    shutil.copy2(path, dst)
    rep(f"[Backup] {path} -> {dst}")
    return dst

def strip_old_guards(src: str) -> tuple[str, bool]:
    """Entfernt 1118/1118b/1119/1121-Guard-Blöcke und ggf. frühere 1121/1122-Varianten."""
    changed = False

    # Blockweise Marker
    for start, end in ((TAG_1119S, TAG_1119E), (TAG_1121S, TAG_1121E), (TAG_1122S, TAG_1122E)):
        pattern = re.escape(start) + r"[\s\S]*?" + re.escape(end)
        src2, n = re.subn(pattern, "", src)
        if n:
            changed, src = True, src2

    # Funktions-Defs 1118 / 1118b konservativ entfernen
    for def_name in (TAG_1118, TAG_1118B):
        name = re.escape(def_name.split()[1].split("(")[0])
        # Entfernt die komplette Funktionsdefinition bis zur nächsten Top-Level-Zeile (heuristisch)
        pattern = rf"\n?[ \t]*def[ \t]+{name}\s*\([^)]*\)\s*:[\s\S]*?(?=\n^[^\s]|\Z)"
        src2, n = re.subn(pattern, "\n", src, flags=re.MULTILINE)
        if n:
            changed, src = True, src2

    return src, changed

def future_block_end(src: str) -> int:
    """Position NACH dem zusammenhängenden Block der __future__-Imports (falls vorhanden)."""
    m = re.match(r'^(?:\s*from\s+__future__\s+import[^\n]*\n)+', src, flags=re.MULTILINE)
    return m.end() if m else 0

def make_guard_snippet() -> str:
    """
    Neuer Guard: zentral loggend, reentrancy-sicher, ohne UI-Aufrufe.
    Wird sofort beim Laden aktiv – noch bevor Tk interagiert.
    """
    return (
        f"\n{TAG_1122S}\n"
        "def __shrimpdev__central_tk_guard__():\n"
        "    import sys, traceback, time, os\n"
        "    # 1) zentralen Logger auflösen (Fallback: Datei-Append)\n"
        "    try:\n"
        "        from modules.snippets.logger_snippet import write_log as _write\n"
        "    except Exception:\n"
        "        LOG = os.path.join(os.path.dirname(__file__), 'debug_output.txt')\n"
        "        def _write(prefix: str, message: str) -> None:\n"
        "            try:\n"
        "                ts = time.strftime('%Y-%m-%d %H:%M:%S')\n"
        "                with open(LOG, 'a', encoding='utf-8', newline='\\n') as f:\n"
        "                    f.write(f\"[{prefix}] {ts} {message}\\n\")\n"
        "            except Exception:\n"
        "                pass\n"
        "    _busy = {'v': False}\n"
        "    def _handler(exc, val, tb):\n"
        "        # 2) Reentrancy-Guard – niemals erneut in sich selbst wandern\n"
        "        if _busy['v']:\n"
        "            return\n"
        "        _busy['v'] = True\n"
        "        try:\n"
        "            try:\n"
        "                msg = ''.join(traceback.format_exception(exc, val, tb))\n"
        "            except Exception:\n"
        "                msg = '<unformatable exception>'\n"
        "            try:\n"
        "                _write('TK', 'EXC\\n' + msg)\n"
        "            except Exception:\n"
        "                # Fallback schreibt bereits, daher hier stumm\n"
        "                pass\n"
        "        finally:\n"
        "            _busy['v'] = False\n"
        "    # 3) Tk-Hooks setzen, ohne UI-Interaktionen\n"
        "    try:\n"
        "        import tkinter as _tk\n"
        "        _tk.Misc.report_callback_exception = _handler  # type: ignore[attr-defined]\n"
        "        def _safe__report_exception(self):\n"
        "            et, ev, tb = sys.exc_info()\n"
        "            if et is not None:\n"
        "                _handler(et, ev, tb)\n"
        "        _tk.BaseWidget._report_exception = _safe__report_exception  # type: ignore[attr-defined]\n"
        "    except Exception:\n"
        "        # ist ok; falls Tk später importiert wird, sind die Symbole verfügbar\n"
        "        pass\n"
        "    # 4) Auch sys.excepthook best-effort absichern (kein Raise)\n"
        "    try:\n"
        "        _orig_hook = sys.excepthook\n"
        "        def _safe_hook(exc_type, exc_value, exc_traceback):\n"
        "            try:\n"
        "                msg = ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))\n"
        "                _write('PY', 'EXC\\n' + msg)\n"
        "            except Exception:\n"
        "                pass\n"
        "            try:\n"
        "                _orig_hook(exc_type, exc_value, exc_traceback)\n"
        "            except Exception:\n"
        "                pass\n"
        "        sys.excepthook = _safe_hook\n"
        "    except Exception:\n"
        "        pass\n"
        "__shrimpdev__central_tk_guard__()\n"
        f"{TAG_1122E}\n"
    )

def patch_main_gui() -> None:
    if not os.path.exists(P_MAIN):
        rep("[main_gui] nicht gefunden – Abbruch.")
        return
    with open(P_MAIN, "r", encoding="utf-8") as f:
        src = f.read()

    # 1) Vorherige Guards entfernen
    src, removed = strip_old_guards(src)
    if removed:
        rep("[main_gui] Alte Guard-Blöcke entfernt.")

    # 2) Guard nach dem __future__-Block einfügen (früh, aber korrekt)
    ins = future_block_end(src)
    new_src = src[:ins] + make_guard_snippet() + src[ins:]

    # 3) Schreiben (mit Backup)
    backup(P_MAIN)
    with open(P_MAIN, "w", encoding="utf-8", newline="\n") as f:
        f.write(new_src)
    rep("[main_gui] Neuer Central-Guard eingefügt (nach __future__).")
    rep("OK – Runner abgeschlossen.")

def main():
    with open(REPORT, "w", encoding="utf-8", newline="\n") as f:
        f.write("Runner_1122_RepairMainGUI_SafeLogging – Start\n")
    try:
        patch_main_gui()
    except Exception as ex:
        rep("FEHLER: " + repr(ex))

if __name__ == "__main__":
    main()
