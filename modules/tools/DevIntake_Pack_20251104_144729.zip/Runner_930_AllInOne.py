from __future__ import annotations
from pathlib import Path
import json, shutil, time

ROOT = Path(r"D:\ShrimpDev")
TOOLS = ROOT/"tools"; TOOLS.mkdir(parents=True, exist_ok=True)
MODS  = ROOT/"modules"; MODS.mkdir(parents=True, exist_ok=True)

def w(p: Path, s: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(s.replace("\r\n","\n"), encoding="utf-8")
    print(f"[R930] wrote {p.relative_to(ROOT)}")

def backup(p: Path):
    b = p.with_suffix(p.suffix + f".{time.strftime('%Y%m%d_%H%M%S')}.bak")
    shutil.copy2(p, b)
    print(f"[R930] backup {b.name}")

# ---------- Runner Board (Events-Viewer) ----------
runner_board = r'''
from __future__ import annotations
import json, tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
EVENTS = ROOT / "_Reports" / "Agent" / "events.jsonl"

class RunnerBoardTab(ttk.Frame):
    def __init__(self, app: tk.Tk):
        super().__init__(app.nb)
        self.app = app
        bar = ttk.Frame(self); bar.pack(fill="x", pady=6)
        ttk.Label(bar, text="Filter:").pack(side="left")
        self.var_q = tk.StringVar(value="")
        ttk.Entry(bar, textvariable=self.var_q, width=40).pack(side="left", padx=6)
        ttk.Button(bar, text="Suchen", command=self.refresh).pack(side="left")
        self.var_level = tk.StringVar(value="ALL")
        ttk.Combobox(bar, textvariable=self.var_level, values=["ALL","OK","INFO","WARN","ERROR","FAIL"], width=8, state="readonly").pack(side="left", padx=6)
        ttk.Button(bar, text="Reload", command=self.refresh).pack(side="left", padx=6)
        ttk.Button(bar, text="Export CSV", command=self.export_csv).pack(side="right")
        cols=("ts","runner","level","msg")
        self.tree = ttk.Treeview(self, columns=cols, show="headings")
        for c,w in zip(cols,(160,200,80,640)):
            self.tree.heading(c, text=c); self.tree.column(c, width=w, anchor="w")
        self.tree.pack(fill="both", expand=True)
        self.auto = tk.BooleanVar(value=True)
        ttk.Checkbutton(self, text="Auto-Refresh (2s)", variable=self.auto).pack(anchor="e", padx=6, pady=4)
        self.after_id=None
        self.refresh()

    def _tail(self, n=800):
        out=[]
        if EVENTS.exists():
            lines = EVENTS.read_text(encoding="utf-8", errors="ignore").splitlines()[-n:]
            for ln in lines:
                try: e=json.loads(ln)
                except Exception: e={"ts":"","runner":"?","level":"INFO","msg":ln}
                out.append(e)
        return out

    def _filter(self, rows):
        lv = self.var_level.get().upper()
        q  = self.var_q.get().strip().lower()
        def ok(r):
            if lv!="ALL" and str(r.get("level","")).upper()!=lv: return False
            if not q: return True
            return any(q in str(r.get(k,"")).lower() for k in ("ts","runner","level","msg"))
        return [r for r in rows if ok(r)]

    def refresh(self):
        try:
            if self.after_id: self.after_cancel(self.after_id)
        except Exception: pass
        rows = self._filter(self._tail())
        for i in self.tree.get_children(): self.tree.delete(i)
        for r in rows:
            self.tree.insert("", "end", values=(r.get("ts",""), r.get("runner",""), r.get("level",""), r.get("msg","")))
        if self.auto.get(): self.after_id = self.after(2000, self.refresh)

    def export_csv(self):
        try:
            if not EVENTS.exists(): 
                messagebox.showinfo("ShrimpDev", "Keine Events vorhanden."); return
            fn = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="events_export.csv")
            if not fn: return
            import csv
            rows = self._filter(self._tail(5000))
            with open(fn, "w", encoding="utf-8", newline="") as f:
                w = csv.writer(f, delimiter=";")
                w.writerow(["ts","runner","level","msg"])
                for r in rows: w.writerow([r.get("ts",""),r.get("runner",""),r.get("level",""),r.get("msg","")])
            messagebox.showinfo("ShrimpDev", f"Exportiert:\n{fn}")
        except Exception as ex:
            messagebox.showerror("ShrimpDev", f"Export-Fehler:\n{ex}")

def open_runner_board(app: tk.Tk) -> bool:
    try:
        tab = RunnerBoardTab(app); app.nb.add(tab, text="Runner Board"); app.nb.select(tab); return True
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Tab-Fehler:\n{ex}")
        except Exception: pass
        return False
'''
w(MODS/"module_runner_board.py", runner_board)

# ---------- Settings UI ----------
settings_ui = r'''
from __future__ import annotations
import json, tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path

CFG  = Path(r"D:\ShrimpDev\config.json")

def _load():
    if CFG.exists():
        try: return json.loads(CFG.read_text(encoding="utf-8") or "{}")
        except Exception: return {}
    return {}

def _save(d: dict):
    CFG.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")

def open_settings(app: tk.Tk) -> bool:
    conf = _load()
    win = tk.Toplevel(app); win.title("⚙ Settings"); win.geometry("520x280+160+140")
    v_ws   = tk.StringVar(value=conf.get("workspace_root", r"D:\ShrimpHub"))
    v_quiet= tk.BooleanVar(value=bool(conf.get("quiet_mode", True)))
    v_port = tk.StringVar(value=str(conf.get("udp_port", 9488)))

    f=ttk.Frame(win); f.pack(fill="both", expand=True, padx=10, pady=10)
    ttk.Label(f, text="Workspace Root:").grid(row=0, column=0, sticky="w")
    ttk.Entry(f, textvariable=v_ws, width=48).grid(row=0, column=1, sticky="we")
    ttk.Button(f, text="…", command=lambda: v_ws.set(filedialog.askdirectory(initialdir=v_ws.get()) or v_ws.get())).grid(row=0, column=2)

    ttk.Label(f, text="UDP Port:").grid(row=1, column=0, sticky="w", pady=6)
    ttk.Entry(f, textvariable=v_port, width=10).grid(row=1, column=1, sticky="w", pady=6)

    ttk.Checkbutton(f, text="Quiet Mode (keine OK-Popups)", variable=v_quiet).grid(row=2, column=1, sticky="w", pady=6)

    def save():
        try:
            conf["workspace_root"]=v_ws.get().strip() or r"D:\ShrimpHub"
            conf["quiet_mode"]=bool(v_quiet.get())
            conf["udp_port"]=int(v_port.get() or "9488")
            _save(conf)
            try: app.status.set("Settings gespeichert.")
            except Exception: pass
            messagebox.showinfo("ShrimpDev", "Gespeichert.")
            win.destroy()
        except Exception as ex:
            messagebox.showerror("ShrimpDev", f"Fehler beim Speichern:\n{ex}")

    b=ttk.Frame(win); b.pack(fill="x")
    ttk.Button(b, text="Speichern", command=save).pack(side="right", padx=6, pady=6)
    ttk.Button(b, text="Abbrechen", command=win.destroy).pack(side="right")

    return True
'''
w(MODS/"module_settings_ui.py", settings_ui)

# ---------- Preflight ----------
preflight = r'''
from __future__ import annotations
import sys, py_compile, traceback, json
from pathlib import Path
from typing import List, Dict

ROOT = Path(r"D:\ShrimpDev")

def run_preflight() -> Dict[str,int]:
    errs: List[str] = []
    ok_files=0; bad_files=0
    for base in (ROOT/"modules", ROOT/"tools"):
        if not base.exists(): continue
        for p in base.rglob("*.py"):
            try:
                py_compile.compile(str(p), doraise=True)
                ok_files += 1
            except Exception:
                bad_files += 1
                errs.append(f"{p}: {traceback.format_exc(limit=1).strip()}")
    report = {"ok":ok_files, "bad":bad_files}
    (ROOT/"_Reports"/"Preflight").mkdir(parents=True, exist_ok=True)
    (ROOT/"_Reports"/"Preflight"/"report.json").write_text(json.dumps({"report":report,"errors":errs}, ensure_ascii=False, indent=2), encoding="utf-8")
    return report

def open_preflight(app) -> bool:
    from tkinter import messagebox
    rep = run_preflight()
    if rep["bad"]>0:
        messagebox.showerror("ShrimpDev Preflight", f"Fehlerhafte Dateien: {rep['bad']}\nDetails: _Reports\\Preflight\\report.json")
    else:
        try:
            from modules.config_mgr import load_config
            if not bool(load_config().get("quiet_mode", True)):
                messagebox.showinfo("ShrimpDev Preflight", f"OK: {rep['ok']} Dateien.")
        except Exception:
            pass
    try: app.status.set(f"Preflight: OK={rep['ok']} BAD={rep['bad']}")
    except Exception: pass
    return True
'''
w(MODS/"module_preflight.py", preflight)

# ---------- Patch/Export ----------
patch_release = r'''
from __future__ import annotations
import json, zipfile, time
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
OUT  = ROOT/"_Reports"/"Release"; OUT.mkdir(parents=True, exist_ok=True)
VER  = ROOT/"CURRENT_VERSION.txt"

def _version_bump() -> str:
    cur = "0.1.0"
    if VER.exists():
        cur = (VER.read_text(encoding="utf-8") or "0.1.0").strip()
    parts = cur.split(".")
    if len(parts)!=3: parts=["0","1","0"]
    parts[2] = str(int(parts[2])+1)
    new = ".".join(parts)
    VER.write_text(new, encoding="utf-8")
    return new

def make_snapshot() -> Path:
    ts=time.strftime("%Y%m%d_%H%M%S")
    ver=_version_bump()
    z=OUT/f"ShrimpDev_snapshot_v{ver}_{ts}.zip"
    with zipfile.ZipFile(z,"w",compression=zipfile.ZIP_DEFLATED) as zipf:
        def add(p: Path, arc: str): 
            if p.exists(): zipf.write(p, arcname=arc)
        add(ROOT/"main_gui.py","main_gui.py")
        for base in (ROOT/"modules", ROOT/"tools"):
            for p in base.rglob("*"):
                if p.is_file() and ".bak" not in p.name and p.suffix.lower() in {".py",".bat",".vbs",".cmd",".txt",".json"}:
                    add(p, str(p.relative_to(ROOT)))
        add(ROOT/"config.json","config.json")
        add(ROOT/"CURRENT_VERSION.txt", "CURRENT_VERSION.txt")
    return z

def open_patch_release(app) -> bool:
    z = make_snapshot()
    try: 
        from tkinter import messagebox
        messagebox.showinfo("ShrimpDev Release", f"Snapshot erstellt:\n{z}")
    except Exception: pass
    try: app.status.set(f"Release-Snapshot: {z.name}")
    except Exception: pass
    return True
'''
w(MODS/"module_patch_release.py", patch_release)

# ---------- Patch main_gui: Tabs + Menüs ----------
mg = ROOT/"main_gui.py"
if mg.exists():
    backup(mg)
txt = (mg.read_text(encoding="utf-8", errors="ignore") if mg.exists() else "")
# sichere Imports hinzufügen (idempotent)
imports = [
    "from modules import module_runner_board as runner_board",
    "from modules import module_settings_ui as settings_ui",
    "from modules import module_preflight as preflight",
    "from modules import module_patch_release as patch_release",
    "from modules import module_project_ui as project_ui",
    "from modules import module_code_intake as intake",
    "from modules import module_agent_ui as agent_ui",
    "from modules import module_agent as agent",
]
for imp in imports:
    if imp not in txt:
        txt = imp + "\n" + txt

# Menü-Hooks (robust, füge am Ende der Klasse eine _mk_menu_safe hinzu)
if "def _mk_menu(self):" not in txt:
    # Minimaler Rahmen, falls Datei sehr alt ist
    frame = r'''
from __future__ import annotations
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")

class ShrimpDevApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("🦐 ShrimpDev")
        self.geometry("1100x720+80+60")
        self.nb = ttk.Notebook(self); self.nb.pack(fill="both", expand=True)
        self.status = tk.StringVar(value="Bereit.")
        ttk.Label(self, textvariable=self.status, anchor="w").pack(fill="x")
        self._mk_menu()
        agent.AGENT.start()
'''
    txt = frame + "\n" + txt

if "def _mk_menu(" not in txt:
    txt += r'''
    def _mk_menu(self):
        menubar = tk.Menu(self); self.config(menu=menubar)
        m_file = tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="File", menu=m_file)
        m_tools= tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="Tools", menu=m_tools)
        m_view = tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="View",  menu=m_view)
        m_file.add_command(label="Exit", command=self._on_exit)
        m_tools.add_command(label="Code Intake (Ctrl+I)", command=lambda: intake.open_intake(self))
        self.bind_all("<Control-i>", lambda e: intake.open_intake(self))
        m_tools.add_command(label="Preflight Checks", command=lambda: preflight.open_preflight(self))
        m_tools.add_command(label="Make Patch/Export", command=lambda: patch_release.open_patch_release(self))
        m_view.add_command(label="Agent Monitor (Ctrl+M)", command=lambda: agent_ui.open_agent_monitor(self))
        self.bind_all("<Control-m>", lambda e: agent_ui.open_agent_monitor(self))
        m_view.add_command(label="Runner Board", command=lambda: runner_board.open_runner_board(self))
        m_view.add_command(label="Project Map", command=lambda: project_ui.open_project_map(self))
        m_view.add_command(label="Settings…", command=lambda: settings_ui.open_settings(self))

    def _on_exit(self):
        try: agent.AGENT.stop()
        except Exception: pass
        self.after(150, self.destroy)

if __name__ == "__main__":
    app = ShrimpDevApp(); app.mainloop()
'''
else:
    # existierendes Menü erweitern (idempotent)
    add_lines = [
        'm_tools.add_command(label="Preflight Checks", command=lambda: preflight.open_preflight(self))',
        'm_tools.add_command(label="Make Patch/Export", command=lambda: patch_release.open_patch_release(self))',
        'm_view.add_command(label="Runner Board", command=lambda: runner_board.open_runner_board(self))',
        'm_view.add_command(label="Settings…", command=lambda: settings_ui.open_settings(self))',
    ]
    for line in add_lines:
        if line not in txt:
            txt = txt.replace("m_view.add_command(label=\"Agent Monitor (Ctrl+M)\"", 
                              "m_view.add_command(label=\"Agent Monitor (Ctrl+M)\"")  # anchor
            txt = txt + "\n" + line + "\n"

w(mg, txt)
print("[R930] DONE – Tabs/Module installiert. Start: tools\\start_visible.bat")
