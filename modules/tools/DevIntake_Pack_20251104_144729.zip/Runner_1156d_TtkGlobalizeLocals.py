# -*- coding: utf-8 -*-
"""
Runner_1156d_TtkGlobalizeLocals
Problem: In Funktionen wird 'ttk' lokal zugewiesen/importiert -> UnboundLocalError.
Lösung:
- Globalen ttk-Import-Guard sicherstellen.
- Alle Funktionen, die 'ttk' im Body zuweisen/importieren, erhalten am Anfang 'global ttk'.
- Idempotent; Backup, Syntax-Check, Import+Instanziierung, Rollback bei Fehlern.
"""
from __future__ import annotations
import io, sys, time, shutil, re, ast, importlib.util, types, py_compile
from pathlib import Path

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1156d_TtkGlobalizeLocals_report.txt"

def log(s=""):
    print(s)
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(s.rstrip()+"\n")

def backup(p: Path) -> Path:
    dst = ARCH / (p.name + "." + str(int(time.time()*1000)) + ".bak")
    shutil.copy2(p, dst); return dst

def import_smoke()->tuple[bool,str]:
    if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
    # Notfall-Stub
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules"); sys.modules.setdefault("modules", pkg)
        mod = types.ModuleType("modules.module_runner_exec")
        mod.run = lambda *a, **k: 0
        mod._log = lambda *a, **k: None
        sys.modules["modules.module_runner_exec"] = mod
    try:
        spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
        m = importlib.util.module_from_spec(spec); assert spec and spec.loader
        spec.loader.exec_module(m)  # type: ignore[attr-defined]
        # Instanziierungstest
        import tkinter as tk
        root = tk.Tk(); root.withdraw()
        try:
            cls = getattr(m, "IntakeFrame", None)
            if not isinstance(cls, type):
                return False, "IntakeFrame-Klasse fehlt"
            _ = cls(root, None)
        finally:
            root.destroy()
        return True, "Import & Instanziierung OK"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"

def ensure_global_ttk_guard(src:str)->tuple[str,bool]:
    # wenn bereits global import vorhanden, nichts tun
    if re.search(r'(?m)^\s*import\s+tkinter\.ttk\s+as\s+ttk\b', src):
        return src, False
    guard = (
        "# R1156d: globaler ttk-Import-Guard\n"
        "try:\n"
        "    import tkinter as tk  # noqa: F401\n"
        "    import tkinter.ttk as ttk  # noqa: F401\n"
        "except Exception:\n"
        "    ttk = None  # type: ignore\n\n"
    )
    lines = src.splitlines(True)
    insert_at = 0
    # Nach Shebang/Coding-Kommentaren einfügen
    for i in range(min(5, len(lines))):
        if lines[i].startswith("#!") or "coding" in lines[i]:
            insert_at = i+1
        else:
            break
    lines.insert(insert_at, guard)
    return "".join(lines), True

class _TtkGlobalizer(ast.NodeVisitor):
    """Findet Funktionen mit 'ttk' Assignment/Import im Body."""
    def __init__(self):
        self.bad_funcs: set[int] = set()  # lineno von def

    def visit_FunctionDef(self, node: ast.FunctionDef):
        local_assigns = False
        # prüfe lokale Zuweisungen/Imports an 'ttk'
        for n in ast.walk(node):
            if isinstance(n, ast.Assign):
                for t in n.targets:
                    if isinstance(t, ast.Name) and t.id == "ttk":
                        local_assigns = True
            elif isinstance(n, ast.AnnAssign):
                if isinstance(n.target, ast.Name) and n.target.id == "ttk":
                    local_assigns = True
            elif isinstance(n, ast.Import):
                for a in n.names:
                    if a.name == "tkinter.ttk" and (a.asname == "ttk" or a.asname is None):
                        # 'import tkinter.ttk as ttk' oder 'import tkinter.ttk'
                        local_assigns = True
            elif isinstance(n, ast.ImportFrom):
                if n.module in ("tkinter.ttk", "tkinter"):
                    for a in n.names:
                        if a.asname == "ttk" or a.name == "ttk":
                            local_assigns = True
        if local_assigns:
            self.bad_funcs.add(node.lineno)
        # nicht in innere defs weiter sammeln (aber walk hat schon alles gesehen)

def inject_global_ttk(src:str)->tuple[str,int]:
    """Fügt 'global ttk' als erste ausführbare Zeile in allen Problem-Funktionen ein."""
    tree = ast.parse(src)
    glob = _TtkGlobalizer(); glob.visit(tree)
    if not glob.bad_funcs:
        return src, 0

    lines = src.splitlines(True)
    # Map von lineno -> Einfüge-Index (nach def-Zeile und evtl. Docstring)
    added = 0
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            for f in node.body:
                if isinstance(f, ast.FunctionDef) and f.lineno in glob.bad_funcs:
                    start = f.lineno - 1
                    insert_at = start + 1
                    # Docstring überspringen
                    if f.body and isinstance(f.body[0], ast.Expr) and isinstance(getattr(f.body[0], "value", None), ast.Constant) and isinstance(f.body[0].value.value, str):
                        # nach Docstring einfügen
                        insert_at = f.body[0].lineno  # 1-basiert
                    # prüfe, ob bereits 'global ttk' existiert
                    body_start = f.body[0].lineno-1 if f.body else insert_at
                    window_end = min(len(lines), body_start+5)
                    snippet = "".join(lines[start:window_end])
                    if re.search(r'(?m)^\s*global\s+ttk\b', snippet):
                        continue
                    indent = re.match(r'^(\s*)def\b', lines[start]).group(1) + "    "
                    lines.insert(insert_at, indent + "global ttk\n")
                    added += 1
    return "".join(lines), added

def main()->int:
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass
    log("[R1156d] Start TtkGlobalizeLocals")

    if not MODFILE.exists():
        log("[ERR] modules/module_code_intake.py fehlt."); return 1

    bak = backup(MODFILE); log(f"[Backup] {bak.name}")
    src0 = io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

    src1, guard_added = ensure_global_ttk_guard(src0)
    src2, injected = inject_global_ttk(src1)

    if guard_added:
        log("[Write] Globaler ttk-Import-Guard ergänzt.")
    if injected:
        log(f"[Write] 'global ttk' in {injected} Funktion(en) ergänzt.")

    if not (guard_added or injected):
        log("[Info] Keine Änderungen erforderlich.")
        return 0

    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(src2)

    try:
        py_compile.compile(MODFILE, doraise=True)
        log("[Syntax] OK")
    except Exception as e:
        log(f"[Syntax] Fehler: {e} -> Rollback")
        shutil.copy2(bak, MODFILE)
        return 1

    ok, msg = import_smoke()
    if not ok:
        log(f"[Live] Import-Fehler: {msg} -> Rollback")
        shutil.copy2(bak, MODFILE)
        return 1
    log(f"[Live] {msg}")

    log(f"[SUM] guard_added={guard_added}, global_injected={injected}")
    log("[R1156d] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
