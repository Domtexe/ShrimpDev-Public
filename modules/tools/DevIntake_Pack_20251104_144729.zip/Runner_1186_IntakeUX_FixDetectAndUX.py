# -*- coding: utf-8 -*-
from __future__ import annotations
import re, time, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
LOG  = ROOT / "debug_output.txt"

def log(msg: str) -> None:
    with open(LOG, "a", encoding="utf-8", newline="\n") as f:
        f.write(f"[R1186] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")

def patch(src: str) -> str:
    out = src

    # 1) Style/Flicker-Fix: stabile Styles + kein aktiver Hover-Repaint
    if "class DevIntake(ttk.Frame):" in out and "Style().configure('DevToolbar.TButton" not in out:
        out = out.replace(
            "class DevIntake(ttk.Frame):",
            "class DevIntake(ttk.Frame):\n"
            "    _STYLE_INIT_DONE = False\n"
        )
        out = out.replace(
            "def _build_ui(self) -> None:",
            "def _build_ui(self) -> None:\n"
            "        # --- Styles einmalig setzen (Flicker-Fix) ---\n"
            "        if not DevIntake._STYLE_INIT_DONE:\n"
            "            st = ttk.Style()\n"
            "            # Einheitlicher Button-Stil ohne aggressiven Hover-Farbwechsel\n"
            "            st.configure('DevToolbar.TButton', padding=4)\n"
            "            st.map('DevToolbar.TButton', background=[('active', st.lookup('TButton','background'))])\n"
            "            st.configure('DevEntry.TEntry', foreground='#111', fieldbackground='#fff')\n"
            "            st.map('DevEntry.TEntry', fieldbackground=[('readonly','#f7f7f7')])\n"
            "            DevIntake._STYLE_INIT_DONE = True\n"
        )
        # Buttons auf Stil umstellen
        out = re.sub(r"ttk\.Button\(([^,]+),\s*text=",
                     r"ttk.Button(\1, style='DevToolbar.TButton', text=",
                     out)

    # 2) Entry-Selection-Fix: Name-Entry auf lesbares Selektionsschema
    out = re.sub(
        r"ttk\.Entry\((top|.*),\s*textvariable=self\.name_var,\s*width=\d+\)",
        r"ttk.Entry(\1, textvariable=self.name_var, width=28, style='DevEntry.TEntry')",
        out
    )

    # 3) Filter v2: Token-Parser (name:, ext:, sub:)
    if "def _refresh_list(self, select:" in out and "def _parse_filter(" not in out:
        out = out.replace(
            "def _refresh_list(self, select: Path|None=None):",
            "def _parse_filter(self, s: str):\n"
            "        # unterstützt: name:foo ext:py sub:tools (alles lowercase)\n"
            "        d = {'name':None,'ext':None,'sub':None}\n"
            "        raw = []\n"
            "        for tok in (s or '').strip().split():\n"
            "            if ':' in tok:\n"
            "                k,v = tok.split(':',1)\n"
            "                if k in d: d[k] = v.lower(); continue\n"
            "            raw.append(tok.lower())\n"
            "        return d, raw\n"
            "\n"
            "    def _refresh_list(self, select: Path|None=None):"
        )
        out = out.replace(
            "        flt = self.filter_var.get().strip().lower()",
            "        fdict, raw = self._parse_filter(self.filter_var.get())"
        )
        out = out.replace(
            "                if flt and (flt not in p.name.lower() and flt not in str(p.parent.relative_to(root)).lower()): continue",
            "                name_l = p.name.lower(); sub_l = (str(p.parent.relative_to(root)).lower() if p.parent!=root else '')\n"
            "                if fdict['name'] and fdict['name'] not in name_l: continue\n"
            "                if fdict['ext'] and fdict['ext'] != (p.suffix.lower().lstrip('.') or ''): continue\n"
            "                if fdict['sub'] and fdict['sub'] not in sub_l: continue\n"
            "                if raw and not all(any(t in x for x in (name_l, sub_l)) for t in raw): continue"
        )

    # 4) Detect+Name-Extraktion robuster + Guard beim Einfügen mit Fehler-Markierung
    #    – ergänze Hilfsfunktionen, falls noch nicht vorhanden
    if "def _detect_scores(text: str)" in out and "def _extract_preferred_name(" not in out:
        out = out.replace(
            "def _detect_ext_from_text(text: str) -> tuple[str, dict]:",
            "def _detect_ext_from_text(text: str) -> tuple[str, dict]:\n"
            "    \"\"\"Erkennt .py/.bat/.txt per Score.\"\"\"\n"
            "    sc = _detect_scores(text)\n"
            "    if sc['py']==0 and sc['bat']==0:\n"
            "        return '.txt', sc\n"
            "    return ('.py', sc) if sc['py']>=sc['bat'] else ('.bat', sc)\n"
            "\n"
            "def _extract_preferred_name(text: str) -> str | None:\n"
            "    # 1) explizit: Runner_####_* im Code/Kommentar\n"
            "    m = re.search(r'(Runner_[0-9]{3,5}_[A-Za-z0-9_]+)', text)\n"
            "    if m: return m.group(1)\n"
            "    # 2) Fallback: erste def main/klasse/Dateititel-Kommentar\n"
            "    m = re.search(r'^\\s*#\\s*Name:\\s*([A-Za-z0-9_\\-]+)', text, re.M)\n"
            "    if m: return m.group(1)\n"
            "    m = re.search(r'\\bdef\\s+main\\s*\\(', text)\n"
            "    if m: return 'snippet_main'\n"
            "    return None\n"
            "\n"
            "def _py_syntax_check(text: str) -> tuple[bool, str|None, int|None]:\n"
            "    try:\n"
            "        compile(text, '<intake>', 'exec'); return True, None, None\n"
            "    except SyntaxError as e:\n"
            "        return False, f\"{e.msg} (Zeile {e.lineno}, Spalte {e.offset})\", e.lineno\n"
            "    except Exception as e:\n"
            "        return False, str(e), None\n"
            "\n"
            "def _bat_basic_check(text: str) -> tuple[bool, str|None, int|None]:\n"
            "    # Mini-Prüfung: verbotene typografische Anführungszeichen, CRLF, Shebang-Unsinn\n"
            "    if '“' in text or '”' in text or '‚' in text or '’' in text:\n"
            "        return False, 'Unzulässige typografische Anführungszeichen gefunden', None\n"
            "    if not text.replace('\\r\\n',''): # leer\n"
            "        return False, 'Leere Datei', None\n"
            "    return True, None, None\n"
        )

    # 4b) Editor-Highlight bei Fehler & Insert-Guard
    if "_insert_as_new" in out and "def _highlight_error(" not in out:
        out = out.replace(
            "def _insert_as_new(self):",
            "def _highlight_error(self, line: int | None):\n"
            "        try:\n"
            "            self.editor.tag_delete('errline')\n"
            "        except Exception:\n"
            "            pass\n"
            "        if not line:\n"
            "            return\n"
            "        self.editor.tag_configure('errline', background='#ffd6d6')\n"
            "        self.editor.tag_add('errline', f'{line}.0', f'{line}.0 lineend')\n"
            "        self.editor.see(f'{line}.0')\n"
            "\n"
            "    def _insert_as_new(self):"
        )
        out = out.replace(
            "        p = self._path_from_ui()\n"
            "        if p.exists() and not messagebox.askyesno(\"Überschreiben?\", f\"{p.name} existiert. Überschreiben?\"): return\n"
            "        try:\n"
            "            p.write_text(self.editor.get(\"1.0\",\"end-1c\"), encoding=\"utf-8\")\n"
            "            self.current_path = p; self._dirty = False\n"
            "            self._refresh_list(select=p); self.status.set(f\"Eingefügt: {p.name}\")\n"
            "        except Exception as e: messagebox.showerror(\"Einfügen\", f\"{e}\"); _log(\"INSERT_FAIL\", str(e))\n"
            "        self._update_leds()\n",
            # Neuer Insert-Guard-Flow
            "        txt = self.editor.get('1.0','end-1c')\n"
            "        # sichere Erkennung\n"
            "        ext, _sc = _detect_ext_from_text(txt)\n"
            "        nm  = _extract_preferred_name(txt) or self.name_var.get().strip() or f'snippet_{time.strftime(\"%Y%m%d_%H%M%S\")}'\n"
            "        self.ext_var.set(ext)\n"
            "        self.name_var.set(nm)\n"
            "        # Syntax-/Format-Check vor Schreiben\n"
            "        ok, msg, line = (True, None, None)\n"
            "        if ext == '.py':\n"
            "            ok, msg, line = _py_syntax_check(txt)\n"
            "        elif ext == '.bat':\n"
            "            ok, msg, line = _bat_basic_check(txt)\n"
            "        if not ok:\n"
            "            self._highlight_error(line)\n"
            "            messagebox.showerror('Einfügen – Fehler', f'Erkannte Endung: {ext}\\nName: {nm}\\n\\n{msg}')\n"
            "            self.status.set('Fehler beim Einfügen – siehe Markierung/MessageBox.')\n"
            "            return\n"
            "        p = self._path_from_ui()\n"
            "        if p.exists() and not messagebox.askyesno('Überschreiben?', f'{p.name} existiert. Überschreiben?'):\n"
            "            return\n"
            "        try:\n"
            "            p.write_text(txt, encoding='utf-8')\n"
            "            self.current_path = p; self._dirty = False\n"
            "            self._refresh_list(select=p)\n"
            "            self.status.set(f'Eingefügt: {p.name} (Erkannt: {ext})')\n"
            "        except Exception as e:\n"
            "            messagebox.showerror('Einfügen', f'{e}')\n"
            "            _log('INSERT_FAIL', str(e))\n"
            "        self._update_leds()\n"
        )

    return out

def main() -> int:
    try:
        ARCH.mkdir(exist_ok=True)
        bak = ARCH / f"module_code_intake.py.{time.strftime('%Y%m%d_%H%M%S')}.bak"
        src = MOD.read_text(encoding="utf-8", errors="replace")
        new = patch(src)
        if new == src:
            log("Keine Änderungen notwendig (idempotent).")
        else:
            bak.write_text(src, encoding="utf-8")
            MOD.write_text(new, encoding="utf-8", newline="\n")
            log(f"Backup: {bak.name}; Patch angewendet.")
        return 0
    except Exception as e:
        log(f"FAIL: {e}")
        return 2

if __name__ == "__main__":
    sys.exit(main())
