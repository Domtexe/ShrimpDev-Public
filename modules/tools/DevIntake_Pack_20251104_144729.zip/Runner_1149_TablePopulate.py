# -*- coding: utf-8 -*-
"""
Runner_1149_TablePopulate
- ergänzt IntakeFrame um:
  * _scan_tools(base_dir) -> list[tuple[name,ext,subfolder,date,time,path]]
  * _fill_table(rows)
  * _on_click_refresh()  (Toolbar-Button 'Aktualisieren')
  * automatischer Initial-Aufruf nach UI-Build
- Keine Blockade des UI-Threads: Scan ist schnell; bei großen Trees könnte man später threaden.
- Backup + Syntaxcheck + Headless-Probe; Rollback bei Fehlern.
"""
from __future__ import annotations
import io, os, sys, time, shutil, ast, importlib.util, types
from pathlib import Path
import py_compile

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1149_TablePopulate_report.txt"

def w(s=""):
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f: f.write(s.rstrip()+"\n")
    print(s)

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time()*1000)}.bak"; shutil.copy2(p, dst); return dst

NEW_HELPERS = r'''
def _scan_tools(self, base_dir: str) -> list[tuple[str,str,str,str,str,str]]:
    """
    Scannt 'tools' rekursiv (max. Tiefe 3) und liefert tabellenfertige Rows.
    """
    import os, time
    rows = []
    base = base_dir or ""
    if not base:
        return rows
    base = os.path.abspath(base)
    if not os.path.isdir(base):
        return rows
    # Akzeptierte Endungen
    ALLOWED = {".py",".bat",".cmd",".json",".yml",".yaml",".ini",".md"}
    for root, dirs, files in os.walk(base):
        # Tiefe begrenzen
        depth = root.replace(base, "").count(os.sep)
        if depth > 3:
            del dirs[:]  # nicht weiter absteigen
            continue
        subfolder = os.path.relpath(root, base)
        if subfolder == ".":
            subfolder = ""
        for fn in files:
            name, ext = os.path.splitext(fn)
            ext = ext.lower()
            if ext not in ALLOWED:
                continue
            fp = os.path.join(root, fn)
            try:
                ts = time.localtime(os.path.getmtime(fp))
                d  = time.strftime("%Y-%m-%d", ts)
                t  = time.strftime("%H:%M:%S", ts)
            except Exception:
                d = ""; t = ""
            rows.append((name, ext, subfolder, d, t, fp))
    # sortierung: subfolder, name
    rows.sort(key=lambda r: (r[2], r[0], r[1]))
    return rows

def _fill_table(self, rows: list[tuple[str,str,str,str,str,str]]):
    try:
        self.tbl.delete(*self.tbl.get_children())
    except Exception:
        return
    for r in rows:
        name, ext, subfolder, d, t, _path = r
        iid = self.tbl.insert("", "end", values=(name, ext, subfolder, d, t))
        # _path optional in iid tags (für Öffnen)
        try:
            self.tbl.set(iid, column="name", value=name)
        except Exception:
            pass

def _on_click_refresh(self):
    base = self.var_target.get()
    rows = self._scan_tools(base)
    self._fill_table(rows)
    self._ping(f"{len(rows)} Einträge geladen.")
'''.strip("\n")

ADDITIONS_AFTER_BUILD = r'''
        # Nach UI-Build: initiale Füllung (safe)
        try:
            self._on_click_refresh()
        except Exception:
            pass
'''

def patch(txt: str) -> str:
    tree = ast.parse(txt)
    cls = None
    for n in tree.body:
        if isinstance(n, ast.ClassDef) and n.name == "IntakeFrame":
            cls = n; break
    if not cls: raise RuntimeError("class IntakeFrame nicht gefunden.")

    lines = txt.splitlines()
    start = cls.lineno-1
    end = getattr(cls, "end_lineno", None) or len(lines)
    cls_src = "\n".join(lines[start:end])

    # Helfer einfügen, falls nicht vorhanden
    for fname in ("_scan_tools","_fill_table","_on_click_refresh"):
        if not re_search_def(cls_src, fname):
            cls_src += "\n\n    " + NEW_HELPERS.replace("\n", "\n    ")
            break  # alle drei auf einmal eingefügt

    # Refresh-Button in Toolbar suchen/ergänzen
    if "btn_refresh" not in cls_src:
        # Button in _build_ui nach bar-Definition einfügen
        cls_src = cls_src.replace(
            '        self.btn_run    = ttk.Button(bar, text="Run (F5)",           command=self._on_click_run)',
            '        self.btn_run    = ttk.Button(bar, text="Run (F5)",           command=self._on_click_run)\n'
            '        self.btn_refresh= ttk.Button(bar, text="Aktualisieren",     command=self._on_click_refresh)'
        )
        # Grid-Position (rechts neben Run)
        cls_src = cls_src.replace(
            '        self.btn_run.grid(   row=0, column=101, padx=(6,0), sticky="w")',
            '        self.btn_run.grid(   row=0, column=101, padx=(6,0), sticky="w")\n'
            '        self.btn_refresh.grid(row=0, column=102, padx=(6,0), sticky="w")'
        )

    # Initiale Füllung nach _build_ui
    if "_on_click_refresh()" not in cls_src:
        cls_src = cls_src.replace(
            '        self._update_led(self.led_detect, "yellow")',
            '        self._update_led(self.led_detect, "yellow")' + ADDITIONS_AFTER_BUILD
        )

    new_txt = "\n".join(lines[:start]) + ("\n" if start else "") + cls_src + ("\n" if end < len(lines) else "") + "\n".join(lines[end:])
    return new_txt

import re
def re_search_def(src: str, name: str) -> bool:
    return re.search(r'(?m)^\s*def\s+'+re.escape(name)+r'\s*\(', src) is not None

# ---- Live-Probe: nur, ob _on_click_refresh ohne Fehler läuft
def import_intake():
    sys.path.insert(0, str(ROOT))
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules")
        mod = types.ModuleType("modules.module_runner_exec")
        mod.run = lambda *a, **k: 0
        mod._log = lambda *a, **k: None
        sys.modules.setdefault("modules", pkg)
        sys.modules["modules.module_runner_exec"] = mod
    spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
    m = importlib.util.module_from_spec(spec); assert spec and spec.loader
    spec.loader.exec_module(m)  # type: ignore[attr-defined]
    return m

def headless_probe()->tuple[bool,str]:
    try:
        import tkinter as tk
        m = import_intake()
        r = tk.Tk(); r.withdraw()
        fr = m.IntakeFrame(r)
        fr._on_click_refresh()
        r.destroy()
        return True, "OK"
    except Exception as e:
        return False, str(e)

def main()->int:
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass
    w("[R1149] TablePopulate – Start")
    if not MODFILE.exists():
        w("[ERR] module_code_intake.py fehlt."); return 1
    bak = backup(MODFILE); w(f"[Backup] {bak.name}")
    src = io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

    try:
        new_txt = patch(src)
    except Exception as e:
        w(f"[ERR] Patch-Vorbereitung: {e}")
        return 1

    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(new_txt)
    w("[Write] Methoden + Refresh-Button ergänzt.")

    try:
        py_compile.compile(str(MODFILE), doraise=True); w("[Syntax] OK")
    except Exception as e:
        w(f"[Syntax] Fehler: {e} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    ok, msg = headless_probe()
    if not ok:
        w(f"[Live] Probe-Fehler: {msg} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    w("[SUM] Tabellen-Befüllung lauffähig (headless).")
    w("[R1149] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
