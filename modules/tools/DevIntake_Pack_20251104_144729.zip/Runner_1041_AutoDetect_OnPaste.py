"""
Runner_1041_AutoDetect_OnPaste
Aktiviert Auto-Detect (Name + Endung) beim Einfügen/Tippen im Editor:
- Bindings: <<Paste>>, <Control-v>, <<Modified>> (debounced)
- _auto_detect_if_needed(): setzt Name/Ext nur, wenn nicht manuell überschrieben
- Respektiert var_name_manual / var_ext_manual, LED/Status-Ping
- Lässt Button-Wiring (detect/save/delete) unberührt
- Version -> v9.9.31
"""
from __future__ import annotations
import os, re, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1041] {ts} {msg}\n")
    except Exception:
        pass

def backup_write(path: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

def patch() -> int:
    with open(MOD, "r", encoding="utf-8") as f:
        src = f.read()

    changed = False

    # 1) Editor-Bindings nach self.txt hinzufügen
    if "self.txt.bind(\"<<Paste>>\"" not in src or "self.txt.bind(\"<<Modified>>\"" not in src:
        src = re.sub(
            r'(self\.txt\s*=\s*tk\.Text\([^\n]+\)\s*\n)'      # Text-Erstellung
            r'(\s*y1\s*=\s*ttk\.Scrollbar\([^\n]+\)\s*\n'     # danach bleibt alles
            r')',
            r'\1'
            r'        # Auto-Detect Bindings\n'
            r'        self._detect_job = None\n'
            r'        self.txt.bind("<<Paste>>", self._on_editor_paste)\n'
            r'        self.txt.bind("<Control-v>", self._on_editor_paste)\n'
            r'        self.txt.bind("<<Modified>>", self._on_editor_modified)\n'
            r'\2',
            src,
            flags=re.MULTILINE
        )
        changed = True

    # 2) Methoden einfügen, falls noch nicht vorhanden
    if "def _on_editor_paste(" not in src:
        insert_pt = src.find("\n    # ---------- detection ----------")
        if insert_pt == -1:
            insert_pt = len(src)
        methods = r'''
    # --- editor auto-detect helpers (debounced) ---
    def _on_editor_paste(self, _evt=None):
        """Paste erkannt -> nach kurzer Zeit automatisch erkennen."""
        self._schedule_detect()

    def _on_editor_modified(self, _evt=None):
        """<<Modified>>-Event: Flag zurücksetzen und ggf. Erkennung planen."""
        try:
            # Modified-Flag zurücksetzen, sonst feuert es nicht erneut
            self.txt.edit_modified(False)
        except Exception:
            pass
        # Nur bei größeren Änderungen / wenn Name leer ist
        if not (self.var_name.get() or "").strip():
            self._schedule_detect()

    def _schedule_detect(self, delay_ms: int = 300):
        """Debounce: verschiebt Erkennung etwas nach hinten (User tippt/pastet)."""
        try:
            if self._detect_job:
                self.after_cancel(self._detect_job)
        except Exception:
            pass
        self._detect_job = self.after(delay_ms, self._auto_detect_if_needed)

    def _auto_detect_if_needed(self):
        """Führt _detect() aus, wenn Name/Ext nicht manuell gesetzt wurden."""
        try:
            name_empty = not (self.var_name.get() or "").strip()
            ext_free   = not getattr(self, "var_ext_manual", False)
            # wenn Name leer ODER Ext nicht manuell -> erkennen
            if name_empty or ext_free:
                self._ping("Auto-Erkennung…")
                self._detect()
        except Exception:
            pass
'''
        src = src[:insert_pt] + methods + src[insert_pt:]
        changed = True

    # 3) Beim Start: falls Editor Inhalt hat und Name leer -> einmalig detecten
    if "self.after(200, self._auto_detect_if_needed)" not in src:
        src = re.sub(
            r'(# LEDs[^\n]+\n\s*self\.led_save .*?\n)',  # nach LED-Setup
            r'\1        # Initiale Auto-Erkennung (falls bereits Inhalt vorhanden)\n'
            r'        self.after(200, self._auto_detect_if_needed)\n',
            src, flags=re.MULTILINE | re.DOTALL
        )
        changed = True

    if changed:
        backup_write(MOD, src)
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.31\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.31 (2025-10-18)
- Intake: Auto-Erkennung bei Paste/Tippen (<<Paste>>, <Ctrl+V>, <<Modified>>), debounced.
- Initiale Auto-Erkennung nach Start, wenn Editor nicht leer ist.
""")
        log("Auto-Detect Bindings + Methoden ergänzt.")
        return 0
    else:
        log("Keine Änderungen nötig (Auto-Detect bereits aktiv).")
        return 0

if __name__ == "__main__":
    try:
        raise SystemExit(patch())
    except Exception:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write("[R1041] FEHLER:\n" + traceback.format_exc() + "\n")
        print("FEHLER:\n" + traceback.format_exc())
        raise
