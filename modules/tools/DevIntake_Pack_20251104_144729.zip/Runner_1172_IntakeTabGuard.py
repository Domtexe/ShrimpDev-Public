# -*- coding: utf-8 -*-
"""
Runner_1172_IntakeTabGuard
Sichert den Notebook-Tab 'Code Intake' gegen ungültige Widgets.
Fügt einen robusten _safe_add_intake_tab()-Block ein und ersetzt nb.add(tab_intake, ...)
durch die sichere Variante.
Master-Regeln:
 - Backup im _Archiv/
 - Syntax-Check mit py_compile
 - Rollback bei Fehler
 - Idempotent (führt sich nur einmal ein)
"""
from __future__ import annotations
import os, re, time, shutil, py_compile, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "main_gui.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG = os.path.join(ROOT, "debug_output.txt")

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1172 {ts}] {msg}\n"
    print(line, end="")
    with open(LOG, "a", encoding="utf-8") as f: f.write(line)

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"main_gui.py.{int(time.time())}.bak")
    shutil.copy2(path, dst)
    return dst

def syntax_ok(path: str) -> bool:
    try:
        py_compile.compile(path, doraise=True)
        return True
    except Exception as e:
        log("Syntax-Fehler:\n" + "".join(traceback.format_exception_only(type(e), e)))
        return False

def inject_guard(src: str) -> str:
    # 1) Helferfunktion einfügen, falls nicht vorhanden
    guard_func = r'''
def _safe_add_intake_tab(nb):
    """Garantiert, dass Code-Intake-Tab immer ein gültiges Widget ist."""
    try:
        from modules import module_code_intake as mci
        w = mci.IntakeFrame(nb)
        from tkinter import ttk
        if not isinstance(w, ttk.Frame):
            raise TypeError("IntakeFrame ist kein Frame")
    except Exception as ex:
        print("FEHLER beim Erstellen des IntakeFrame:", ex)
        from tkinter import ttk
        w = ttk.Frame(nb)
        ttk.Label(w, text="Code Intake konnte nicht initialisiert werden.").pack(padx=12, pady=12, anchor="w")
    nb.add(w, text="Code Intake")
'''
    if "_safe_add_intake_tab(" not in src:
        # Einfügen oberhalb main()-Definition
        src = re.sub(r"(?m)^(def\s+main\s*\()", guard_func + r"\1", src, count=1)

    # 2) Ersetze direkte Aufrufe nb.add(tab_intake, text="Code Intake") durch Guard
    if "nb.add(tab_intake" in src:
        src = re.sub(
            r"^\s*nb\.add\s*\(\s*tab_intake\s*,\s*text\s*=\s*[\"']Code Intake[\"']\s*\)\s*$",
            "    _safe_add_intake_tab(nb)",
            src, flags=re.M
        )
    return src

def main() -> int:
    if not os.path.exists(TARGET):
        log(f"Zieldatei nicht gefunden: {TARGET}")
        return 2

    bak = backup(TARGET)
    log(f"Backup erstellt: {bak}")

    with open(TARGET, "r", encoding="utf-8") as f:
        src = f.read()

    new_src = inject_guard(src)
    if new_src == src:
        log("Keine Änderung erforderlich (idempotent).")
        return 0

    with open(TARGET, "w", encoding="utf-8", newline="\n") as f:
        f.write(new_src)

    if syntax_ok(TARGET):
        log("Patch erfolgreich – Syntax OK.")
        return 0
    else:
        shutil.copy2(bak, TARGET)
        log("Rollback auf Backup wegen Syntax-Fehler.")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
