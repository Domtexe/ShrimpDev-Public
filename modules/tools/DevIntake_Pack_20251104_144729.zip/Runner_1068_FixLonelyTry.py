# -*- coding: utf-8 -*-
"""
Runner_1068_FixLonelyTry
Repariert "einsame" try:-Blöcke in modules/module_code_intake.py:
- fügt fehlenden Body (pass) ein, falls nötig
- fügt ein except Exception: pass auf gleicher Einrückung an
- validiert via ast.parse()
"""
from __future__ import annotations
import os, re, time, shutil, ast

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD    = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOG    = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1068] {ts} {msg}\n")
    except Exception:
        pass

def read_text(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def write_text_with_backup(p: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bak)
    log(f"Backup: {p} -> {bak}")
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

def normalize(src: str) -> str:
    src = src.replace("\r\n", "\n").replace("\r", "\n")
    # trailing spaces + Tabs -> 4 Spaces
    src = "\n".join(ln.rstrip(" \t") for ln in src.split("\n"))
    src = src.replace("\t", "    ")
    if not src.endswith("\n"):
        src += "\n"
    return src

def fix_lonely_try(src: str) -> tuple[str, int]:
    """
    Sucht try:-Zeilen und prüft, ob im selben Indent-Level ein except/finally folgt.
    Wenn nicht, hängt nach der Suite (oder direkt, falls keine Suite) folgendes an:
        except Exception:
            pass
    Außerdem: Falls der Suite-Body fehlt (nächste Zeile nicht tiefer eingerückt),
    wird ein 'pass' in der Suite ergänzt.
    """
    lines = src.split("\n")
    changed = 0

    def indent_of(s: str) -> int:
        return len(s) - len(s.lstrip(" "))

    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if stripped.endswith("try:") and not stripped.startswith("#"):
            cur_indent = indent_of(line)
            # 1) sicherstellen, dass es einen Body gibt
            j = i + 1
            # überspringe Leerzeilen/Kommentare
            while j < len(lines) and (not lines[j].strip() or lines[j].lstrip().startswith("#")):
                j += 1
            has_suite = (j < len(lines) and indent_of(lines[j]) > cur_indent)
            if not has_suite:
                # füge minimalen Body ein
                lines.insert(i + 1, " " * (cur_indent + 4) + "pass")
                changed += 1
                j = i + 2

            # 2) suche Ende der Suite (erster Dedent <= cur_indent)
            k = j
            while k < len(lines):
                if lines[k].strip():  # nicht-leer
                    if indent_of(lines[k]) <= cur_indent:
                        break
                k += 1
            suite_end = k  # Position, vor der wir except einfügen

            # 3) Prüfe, ob am gleichen Indent bereits except/finally existiert
            has_handler = False
            m = suite_end
            while m < len(lines) and lines[m].strip() == "":  # skip blank
                m += 1
            if m < len(lines):
                nxt = lines[m].strip()
                if nxt.startswith("except ") or nxt == "except:" or nxt.startswith("finally:"):
                    has_handler = True

            if not has_handler:
                # except Exception: pass anfügen
                lines.insert(suite_end, " " * cur_indent + "except Exception:")
                lines.insert(suite_end + 1, " " * (cur_indent + 4) + "pass")
                changed += 1
                # Index fortschieben hinter den neu eingefügten Block
                i = suite_end + 2
                continue
        i += 1

    return ("\n".join(lines) + ("\n" if not src.endswith("\n") else "")), changed

def main() -> int:
    if not os.path.exists(MOD):
        log(f"Datei fehlt: {MOD}")
        return 2

    src0 = read_text(MOD)
    src1 = normalize(src0)
    fixed, cnt = fix_lonely_try(src1)

    if cnt == 0:
        log("Keine einsamen try:-Blöcke gefunden – nichts zu tun.")
        # trotzdem Syntaxcheck, um klare Meldung zu haben
        try:
            ast.parse(fixed)
            log("Syntax OK.")
            return 0
        except SyntaxError as e:
            log(f"SyntaxError weiterhin vorhanden: {e} (line {e.lineno}, col {e.offset})")
            return 3

    # Validate
    try:
        ast.parse(fixed)
    except SyntaxError as e:
        log(f"SyntaxError nach Fix: {e} (line {e.lineno}, col {e.offset})")
        return 4

    write_text_with_backup(MOD, fixed)
    log(f"Repariert: {cnt} try-Blöcke ergänzt.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
