# -*- coding: utf-8 -*-
r"""
Runner_1118b_GlobalTkPatch
- Entschärft Tkinter-Recursion: globales Monkeypatching von
  tkinter.Misc.report_callback_exception und tkinter.BaseWidget._report_exception
  → kein Messagebox/kein Re-Entry, nur sicherer Log-Append.
- Beibehaltung des \R-Warnungsfixes (Raw-Docstring) in modules/module_runner_exec.py.
- Backups werden in _Archiv/ erstellt; Report in _Reports/.
"""

from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
REPO = os.path.join(ROOT, "_Reports")
os.makedirs(ARCH, exist_ok=True)
os.makedirs(REPO, exist_ok=True)

REPORT = os.path.join(REPO, "Runner_1118b_GlobalTkPatch_report.txt")

def logrep(msg: str) -> None:
    with open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip() + "\n")

def backup(p: str) -> str:
    dst = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, dst)
    logrep(f"[Backup] {p} -> {dst}")
    return dst

def patch_runner_exec_rawdoc() -> None:
    p = os.path.join(ROOT, "modules", "module_runner_exec.py")
    if not os.path.exists(p):
        logrep("[runner_exec] nicht gefunden – übersprungen.")
        return
    src = open(p, "r", encoding="utf-8").read()
    new = re.sub(r'^\s*"""(.*?)"""', lambda m: 'r"""' + m.group(1) + '"""',
                 src, count=1, flags=re.DOTALL)
    if new != src:
        backup(p)
        open(p, "w", encoding="utf-8", newline="\n").write(new)
        logrep("[runner_exec] Docstring auf Raw gestellt.")
    else:
        logrep("[runner_exec] Docstring bereits Raw oder kein Änderungsbedarf.")

def _guard_snippet() -> str:
    return (
        "\n"
        "# === 1118b GlobalTkPatch (auto) ===\n"
        "def _install_global_tk_guard():\n"
        "    import tkinter as _tk\n"
        "    import traceback, time, os, sys\n"
        "    _LOG = os.path.join(os.path.dirname(__file__), 'debug_output.txt')\n"
        "    _busy = {'v': False}\n"
        "    def _safe_write(txt: str):\n"
        "        try:\n"
        "            with open(_LOG, 'a', encoding='utf-8') as f:\n"
        "                f.write(txt)\n"
        "        except Exception:\n"
        "            pass\n"
        "    def _safe_handler(exc, val, tb):\n"
        "        if _busy['v']:  # Re-Entryping verhindern\n"
        "            return\n"
        "        _busy['v'] = True\n"
        "        try:\n"
        "            ts = time.strftime('%Y-%m-%d %H:%M:%S')\n"
        "            lines = ''.join(traceback.format_exception(exc, val, tb))\n"
        "            _safe_write(f\"[TK-EXC] {ts}\\n\" + lines + \"\\n\")\n"
        "        finally:\n"
        "            _busy['v'] = False\n"
        "    try:\n"
        "        # 1) Standardpfad: Tk ruft über Misc.report_callback_exception(...)\n"
        "        _tk.Misc.report_callback_exception = _safe_handler  # type: ignore[attr-defined]\n"
        "    except Exception:\n"
        "        pass\n"
        "    try:\n"
        "        # 2) Einige Pfade nutzen BaseWidget._report_exception(self)\n"
        "        def _safe__report_exception(self):\n"
        "            et, ev, tb = sys.exc_info()\n"
        "            if et is not None:\n"
        "                _safe_handler(et, ev, tb)\n"
        "        _tk.BaseWidget._report_exception = _safe__report_exception  # type: ignore[attr-defined]\n"
        "    except Exception:\n"
        "        pass\n"
        "    try:\n"
        "        # 3) Messagebox stilllegen (optional), um event-loop Feedback-Schleifen zu vermeiden\n"
        "        from tkinter import messagebox as _mb\n"
        "        def _silent(*args, **kwargs):\n"
        "            return None\n"
        "        for _n in ('showerror','showwarning','showinfo','askyesno','askokcancel'):\n"
        "            if hasattr(_mb, _n):\n"
        "                setattr(_mb, _n, _silent)\n"
        "    except Exception:\n"
        "        pass\n"
        "\n"
        "try:\n"
        "    _install_global_tk_guard()\n"
        "except Exception:\n"
        "    pass\n"
        "# === /1118b ===\n"
    )

def patch_main_gui() -> None:
    p = os.path.join(ROOT, "main_gui.py")
    if not os.path.exists(p):
        logrep("[main_gui] nicht gefunden – Abbruch.")
        return
    src = open(p, "r", encoding="utf-8").read()
    changed = False

    if "def _install_global_tk_guard():" not in src:
        # Nach Import-Block einfügen
        m = re.search(r"(?:^from\s[^\n]+\n|^import\s[^\n]+\n)+", src, flags=re.MULTILINE)
        ins = m.end() if m else 0
        src = src[:ins] + _guard_snippet() + src[ins:]
        changed = True
        logrep("[main_gui] GlobalTkPatch-Snippet eingefügt.")

    if changed:
        backup(p)
        open(p, "w", encoding="utf-8", newline="\n").write(src)
        logrep("[main_gui] geschrieben.")
    else:
        logrep("[main_gui] bereits gepatcht – keine Änderung.")

def main():
    open(REPORT, "w", encoding="utf-8", newline="\n").write("Runner_1118b_GlobalTkPatch – Start\n")
    try:
        patch_runner_exec_rawdoc()
        patch_main_gui()
        logrep("OK – Runner beendet.")
    except Exception as ex:
        logrep("FEHLER: " + repr(ex))

if __name__ == "__main__":
    main()
