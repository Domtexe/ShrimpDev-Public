# -*- coding: utf-8 -*-
"""
R1166c Intake MinimalScopeFix
- Minimal, idempotent, einrückungssicher:
  (1) Entfernt 'global ttk' in _build_ui
  (2) Fügt NUR 'self.toolbar = bar' und 'self.frm_actions = bar' direkt nach 'bar = ttk.Frame(...)' ein,
      wenn sie fehlen (mit exakt derselben Einrückung, Tabs/Spaces werden beibehalten).
- Keine weiteren Blockersetzungen => kein IndentationError-Risiko.
- Backup, Syntax-Check, Rollback.
"""
from __future__ import annotations
import io, re, time, shutil, py_compile, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
DOCS = ROOT / "docs"
RULE = DOCS / "MASTERREGELN_ADDENDUM_2025-10-23.md"
LOGF = ROOT / "debug_output.txt"

ADDENDUM = """# Masterregeln – Addendum (2025-10-23)

## 1.4 GUI-Imports (verbindlich)
- GUI-Imports (tkinter/ttk/messagebox/filedialog) ausschließlich im **Modulkopf**.
- In Funktionen **keine** lokalen Re-Imports/Zuweisungen dieser Namen.

## 1.5 Toolbar-Referenzen
- Toolbar-Container wird zentral referenziert (z. B. `self.toolbar = bar`).
- Legacy-Aliase (z. B. `self.frm_actions`) dürfen auf **dieselbe Instanz** zeigen.

## 12.4 Sorgfalt bei Patches (NEU)
- Patches müssen **einrückungssicher** sein: Einrückung **aus dem Quelltext übernehmen** (Tabs/Spaces nicht verändern).
- Minimalprinzip: Nur notwendige Änderungen vornehmen; große Ersetzungen vermeiden, solange nicht zwingend.
- Idempotenz: Mehrfaches Ausführen darf nicht zu Doppel-Injektionen führen.
"""

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1166c] {ts} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f: f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(p: Path) -> Path:
    ARCH.mkdir(parents=True, exist_ok=True)
    dst = ARCH / f"{p.name}.{int(time.time())}.bak"
    shutil.copy2(p, dst)
    log(f"Backup: {p} -> {dst}")
    return dst

def patch_source(src: str) -> tuple[str, list[str]]:
    changes: list[str] = []

    # _build_ui finden
    m_def = re.search(r"^\s*def\s+_build_ui\s*\(\s*self[^\)]*\)\s*:\s*$", src, re.M)
    if not m_def:
        return src, changes
    start = m_def.end()
    m_next = re.search(r"^\s*def\s+\w+\s*\(", src[start:], re.M)
    end = start + (m_next.start() if m_next else len(src) - start)
    block = src[start:end]

    # 1) global ttk entfernen (falls vorhanden)
    new_block = re.sub(r"^\s*global\s+ttk\s*\r?\n", "", block, flags=re.M)
    if new_block != block:
        changes.append("Removed 'global ttk'")
        block = new_block

    # 2) nach 'bar = ttk.Frame(' Alias-Zuweisungen setzen (idempotent)
    m_bar = re.search(r"^(\s*)bar\s*=\s*ttk\.Frame\([^\)]*\)\s*$", block, re.M)
    if m_bar:
        indent = m_bar.group(1)                    # exakt diese Einrückung verwenden (Tabs/Spaces)
        ins_pos = m_bar.end()
        tail = block[ins_pos:ins_pos+400]          # wenige Zeilen danach prüfen
        need_toolbar = "self.toolbar = bar" not in tail
        need_actions = "self.frm_actions = bar" not in tail
        if need_toolbar or need_actions:
            lines = []
            if need_toolbar:
                lines.append(f"{indent}self.toolbar = bar  # R1166c")
            if need_actions:
                lines.append(f"{indent}self.frm_actions = bar  # R1166c (compat)")
            insert = "\n" + "\n".join(lines) + "\n"
            block = block[:ins_pos] + insert + block[ins_pos:]
            if need_toolbar: changes.append("Inserted 'self.toolbar = bar'")
            if need_actions: changes.append("Inserted 'self.frm_actions = bar'")

    # zusammenbauen
    new_src = src[:start] + block + src[end:]
    return new_src, changes

def write_rules():
    DOCS.mkdir(parents=True, exist_ok=True)
    RULE.write_text(ADDENDUM, encoding="utf-8")

def main() -> int:
    try:
        if not MOD.exists():
            log(f"[ERR] Not found: {MOD}"); return 2
        src = MOD.read_text(encoding="utf-8")
        bak = backup(MOD)
        new_src, changes = patch_source(src)
        if not changes:
            log("No changes applied (nothing to fix).")
        else:
            MOD.write_text(new_src, encoding="utf-8", newline="\n")
            for c in changes: log(f"Change: {c}")
            try:
                py_compile.compile(str(MOD), doraise=True)
                log("Syntax-Check: OK")
            except Exception as ex:
                log(f"[ERR] Syntax-Check failed: {ex}")
                shutil.copy2(bak, MOD)
                log("Restored from backup.")
                return 3

        # Regeln immer aktualisieren
        try:
            write_rules(); log(f"Wrote rules addendum: {RULE}")
        except Exception as ex:
            log(f"[WARN] Could not write rules addendum: {ex}")

        log("R1166c completed successfully.")
        return 0
    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
