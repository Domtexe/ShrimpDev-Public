# -*- coding: utf-8 -*-
"""
Runner_1139_IntakeFrameRepair
Stellt sicher, dass tkinter & ttk korrekt importiert sind.
"""
import os, io, time, shutil, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")

def backup(src):
    os.makedirs(ARCH, exist_ok=True)
    ts = int(time.time())
    bak = os.path.join(ARCH, f"{os.path.basename(src)}.{ts}.bak")
    shutil.copy2(src, bak)
    print(f"[R1139] Backup -> {bak}")
    return bak

def main():
    print("[R1139] IntakeFrameRepair – Start")
    if not os.path.exists(MOD):
        print(f"[R1139] FEHLER: Datei fehlt: {MOD}")
        return 2

    backup(MOD)
    with io.open(MOD, "r", encoding="utf-8") as f:
        src = f.read()

    changed = False
    lines = src.splitlines()

    # Prüfe auf tkinter imports
    if not any("import tkinter" in l for l in lines):
        lines.insert(0, "import tkinter as tk")
        print("[R1139] Hinzugefügt: import tkinter as tk")
        changed = True

    if not any("from tkinter import ttk" in l for l in lines):
        lines.insert(1, "from tkinter import ttk")
        print("[R1139] Hinzugefügt: from tkinter import ttk")
        changed = True

    new_src = "\n".join(lines)

    try:
        compile(new_src, MOD, "exec")
    except SyntaxError as e:
        print(f"[R1139] SyntaxError nach Patch: {e}")
        return 1

    if changed:
        with io.open(MOD, "w", encoding="utf-8", newline="\n") as f:
            f.write(new_src)
        print("[R1139] Imports korrigiert und Datei gespeichert.")
    else:
        print("[R1139] Keine Änderungen nötig.")

    return 0

if __name__ == "__main__":
    sys.exit(main())
