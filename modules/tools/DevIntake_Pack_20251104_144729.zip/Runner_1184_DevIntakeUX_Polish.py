# -*- coding: utf-8 -*-
from __future__ import annotations
"""
R1184 – Polish für Dev-Intake (ShrimpDev):
- Cleanes Ribbon-Layout, deutsch
- Live-Filter (Debounce), Statuszählung
- Stripe-Rows, persistente Spaltenbreiten & Split-Position
- Tooltips, robustere Fehlerbehandlung
"""
import time, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCH = ROOT / "_Archiv"
LOG  = ROOT / "debug_output.txt"
OUT  = ROOT / "modules" / "module_code_intake.py"

def _log(msg: str) -> None:
    with open(LOG, "a", encoding="utf-8", newline="\n") as f:
        f.write(f"[R1184] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")

DEV_INTAKE = r'''# -*- coding: utf-8 -*-
from __future__ import annotations
import os, sys, time, shutil, zipfile, traceback, subprocess, configparser, re
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

INI_FILE = "dev_intake.ini"

# ---------------- util & logging ----------------
def _log(tag: str, msg: str) -> None:
    try:
        root = Path(__file__).resolve().parents[1]
        with open(root / "debug_output.txt", "a", encoding="utf-8", newline="\n") as f:
            f.write(f"[DevIntake] {time.strftime('%Y-%m-%d %H:%M:%S')} [{tag}] {msg}\n")
    except Exception:
        pass

def _fmt_time(ts: float):
    lt = time.localtime(ts)
    return time.strftime("%Y-%m-%d", lt), time.strftime("%H:%M:%S", lt)

def _detect_ext_from_text(text: str) -> str:
    t = (text or "").lstrip(); tl = t.lower()
    batch_markers = ("@echo off","\nrem ","\r\nrem ","\n::","\r\n::"," call "," set "," if exist "," goto ","\n:", "\r\n:")
    if tl.startswith("@echo off") or any(m in tl for m in batch_markers): return ".bat"
    if tl.startswith("#!") or "import " in t or "from " in t or "def " in t or "class " in t or "print(" in t or "__name__" in t: return ".py"
    return ".txt"

def _open_explorer(path: Path) -> None:
    try:
        if path.is_dir(): subprocess.Popen(["explorer", str(path)])
        else:            subprocess.Popen(["explorer", "/select,", str(path)])
    except Exception as e:
        messagebox.showerror("Explorer", str(e)); _log("EXPLORER_FAIL", str(e))

def _safe_run(cmd: list[str]) -> None:
    try:
        subprocess.Popen(cmd, cwd=os.getcwd(), creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
    except Exception as e:
        messagebox.showerror("Run", f"Start fehlgeschlagen:\n{e}"); _log("RUN_FAIL", str(e))

# ---------------- tooltips ----------------
class ToolTip:
    def __init__(self, widget, text: str):
        self.w, self.text, self.tip = widget, text, None
        widget.bind("<Enter>", self._show); widget.bind("<Leave>", self._hide)
    def _show(self, *_):
        if self.tip: return
        x,y,cx,cy = self.w.bbox("insert") if hasattr(self.w,"bbox") else (0,0,0,0)
        x += self.w.winfo_rootx() + 20; y += self.w.winfo_rooty() + 20
        self.tip = tw = tk.Toplevel(self.w); tw.wm_overrideredirect(True); tw.wm_geometry(f"+{x}+{y}")
        lb = tk.Label(tw, text=self.text, background="#ffffe0", relief="solid", borderwidth=1, justify="left")
        lb.pack(ipadx=4, ipady=2)
    def _hide(self, *_):
        if self.tip: self.tip.destroy(); self.tip = None

# ---------------- main widget ----------------
class DevIntake(ttk.Frame):
    def __init__(self, nb: ttk.Notebook) -> None:
        super().__init__(nb)
        self.after_id = None  # debounce timer
        ini = self._load_ini()
        self.workspace = tk.StringVar(value=ini.get("workspace", os.getcwd()))
        self.target_dir = tk.StringVar(value=ini.get("target_dir", str(Path(os.getcwd()) / "tools")))
        self.ext_var    = tk.StringVar(value=ini.get("last_ext", ".py"))
        self.name_var   = tk.StringVar(value=f"snippet_{time.strftime('%Y%m%d_%H%M%S')}")
        self.status     = tk.StringVar(value="Bereit.")
        self.filter_var = tk.StringVar(value="")
        self.ui_split   = float(ini.get("ui_split", "0.60"))
        self.col_widths = ini.get("col_widths", "260,60,160,100,80")
        self.current_path: Path | None = None
        self.sort_state = ("name", True)
        self._styling()
        self._build_ui()
        self._refresh_list()

    # -------- ini --------
    def _load_ini(self) -> dict:
        cfg = configparser.ConfigParser(); p = Path(os.getcwd())/INI_FILE
        if p.exists():
            try: cfg.read(p, encoding="utf-8"); return dict(cfg.items("dev")) if cfg.has_section("dev") else {}
            except Exception: _log("INI_READ_FAIL","fallback")
        return {}
    def _save_ini(self) -> None:
        try:
            cfg = configparser.ConfigParser()
            cfg["dev"] = {
                "workspace": self.workspace.get(),
                "target_dir": self.target_dir.get(),
                "last_ext":   self.ext_var.get(),
                "ui_split":   f"{self.ui_split:.2f}",
                "col_widths": ",".join(str(self.tree.column(c, option="width")) for c in ("name","ext","subfolder","date","time")),
            }
            with open(Path(os.getcwd())/INI_FILE, "w", encoding="utf-8", newline="\n") as f: cfg.write(f)
        except Exception as e: _log("INI_WRITE_FAIL", str(e))

    # -------- style --------
    def _styling(self):
        style = ttk.Style()
        # Striped rows
        style.map("Treeview",
                  background=[("selected", style.lookup("Treeview", "background", default="SystemHighlight"))])
        self.tag_even = ("even",); self.tag_odd = ("odd",)

    # -------- ui --------
    def _build_ui(self) -> None:
        # Ribbon: 2 Zeilen – obere Zeile Felder, darunter Gruppen
        top = ttk.Frame(self); top.pack(fill="x", padx=8, pady=6)
        ttk.Label(top, text="Workspace:").grid(row=0, column=0, sticky="w")
        e_ws = ttk.Entry(top, textvariable=self.workspace, width=40); e_ws.grid(row=0, column=1, sticky="we", padx=(4,4))
        b_ws = ttk.Button(top, text="…", width=3, command=self._pick_workspace); b_ws.grid(row=0, column=2, padx=(2,10))
        ttk.Label(top, text="Name:").grid(row=0, column=3, sticky="w")
        ttk.Entry(top, textvariable=self.name_var, width=28).grid(row=0, column=4, sticky="we", padx=(4,10))
        ttk.Label(top, text="Endung:").grid(row=0, column=5, sticky="w")
        ttk.Combobox(top, textvariable=self.ext_var, values=[".py",".bat",".txt"], width=6, state="readonly").grid(row=0, column=6, sticky="w")
        ttk.Label(top, text="Zielordner:").grid(row=0, column=7, sticky="e")
        e_td = ttk.Entry(top, textvariable=self.target_dir, width=36); e_td.grid(row=0, column=8, sticky="we", padx=(4,4))
        b_td = ttk.Button(top, text="…", width=3, command=self._pick_target); b_td.grid(row=0, column=9)
        for c in (1,4,8): top.columnconfigure(c, weight=1)
        ToolTip(b_ws, "Workspace wählen"); ToolTip(b_td, "Zielordner wählen")

        bar = ttk.Frame(self); bar.pack(fill="x", padx=8, pady=(0,6))
        def group(label: str) -> ttk.Frame:
            frm = ttk.Labelframe(bar, text=label); frm.pack(side="left", padx=(0,8)); return frm

        g_file = group("Datei")
        btn_new = ttk.Button(g_file, text="Neu", command=self._editor_clear);        btn_new.pack(side="left", padx=2, pady=4); ToolTip(btn_new, "Editor leeren")
        btn_ins = ttk.Button(g_file, text="Einfügen", command=self._insert_as_new);  btn_ins.pack(side="left", padx=2, pady=4); ToolTip(btn_ins, "Editor-Inhalt als Datei anlegen")
        btn_sv  = ttk.Button(g_file, text="Speichern", command=self._save_current);  btn_sv.pack(side="left", padx=2, pady=4);  ToolTip(btn_sv, "Aktuelle Datei speichern (Strg+S)")
        btn_sva = ttk.Button(g_file, text="Speichern als…", command=self._save_as);  btn_sva.pack(side="left", padx=2, pady=4)

        g_an = group("Analyse")
        ttk.Button(g_an, text="Erkennen (Strg+I)", command=self._detect_name_ext).pack(side="left", padx=2, pady=4)
        ttk.Button(g_an, text="Guard", command=self._guard_check).pack(side="left", padx=2, pady=4)
        ttk.Button(g_an, text="Repair", command=self._repair).pack(side="left", padx=2, pady=4)

        g_run = group("Ausführen")
        ttk.Button(g_run, text="Run (F5)", command=self._run_current).pack(side="left", padx=2, pady=4)
        ttk.Button(g_run, text="Ordner öffnen", command=self._open_target).pack(side="left", padx=2, pady=4)
        ttk.Button(g_run, text="Explorer", command=lambda: _open_explorer(Path(self.target_dir.get()))).pack(side="left", padx=2, pady=4)

        g_mgmt = group("Verwaltung")
        ttk.Button(g_mgmt, text="Aktualisieren", command=self._refresh_list).pack(side="left", padx=2, pady=4)
        ttk.Button(g_mgmt, text="Pack speichern", command=self._save_pack).pack(side="left", padx=2, pady=4)
        ttk.Button(g_mgmt, text="Löschen", command=self._delete_current).pack(side="left", padx=2, pady=4)

        # Filter-Zeile mit Live-Filter (Debounce)
        fl = ttk.Frame(self); fl.pack(fill="x", padx=8, pady=(0,4))
        ttk.Label(fl, text="Filter:").pack(side="left")
        ent = ttk.Entry(fl, textvariable=self.filter_var, width=46); ent.pack(side="left", padx=(4,10))
        ttk.Button(fl, text="Anwenden", command=self._refresh_list).pack(side="left")
        ent.bind("<KeyRelease>", self._on_filter_change)

        # Split
        split = ttk.Panedwindow(self, orient="horizontal"); split.pack(fill="both", expand=True, padx=8, pady=(0,8))
        self.left = ttk.Frame(split); self.right = ttk.Frame(split)
        split.add(self.left, weight=int(self.ui_split*100)); split.add(self.right, weight=int((1.0-self.ui_split)*100))
        self.split = split

        self.editor = tk.Text(self.left, wrap="none", undo=True)
        self.editor.pack(fill="both", expand=True)
        vsb = ttk.Scrollbar(self.left, orient="vertical", command=self.editor.yview)
        hsb = ttk.Scrollbar(self.left, orient="horizontal", command=self.editor.xview)
        self.editor.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        vsb.pack(side="right", fill="y"); hsb.pack(side="bottom", fill="x")

        cols = ("name","ext","subfolder","date","time")
        self.tree = ttk.Treeview(self.right, columns=cols, show="headings", selectmode="browse")
        widths = [int(x) for x in (self.col_widths.split(",") if self.col_widths else ["260","60","160","100","80"])]
        for c,w in zip(cols, widths):
            self.tree.heading(c, text=c, command=lambda col=c: self._sort_by(col))
            self.tree.column(c, width=w, anchor="w")
        self.tree.pack(fill="both", expand=True)

        # stripes
        self.tree.tag_configure("even", background="#f6f6f6")
        self.tree.tag_configure("odd",  background="#ffffff")

        # events
        self.tree.bind("<<TreeviewSelect>>", self._on_select)
        self.tree.bind("<Double-1>", self._on_double)
        self.tree.bind("<F2>", lambda e: self._rename_current())

        # context
        self.menu = tk.Menu(self, tearoff=0)
        self.menu.add_command(label="Run", command=self._run_current)
        self.menu.add_command(label="Rename (F2)", command=self._rename_current)
        self.menu.add_command(label="Delete", command=self._delete_current)
        self.menu.add_separator()
        self.menu.add_command(label="Explorer", command=lambda: self._open_target())
        self.tree.bind("<Button-3>", self._popup_menu)

        ttk.Label(self, textvariable=self.status, anchor="w").pack(side="bottom", fill="x")
        # Shortcuts
        self.bind_all("<Control-s>", lambda e: self._save_current())
        self.bind_all("<Control-S>", lambda e: self._save_current())
        self.bind_all("<Control-i>", lambda e: self._detect_name_ext())
        self.bind_all("<Control-I>", lambda e: self._detect_name_ext())
        self.bind_all("<F5>",        lambda e: self._run_current())

        # persist split on resize
        self.after(100, self._capture_split)

    # ---- helpers ----
    def _capture_split(self):
        try:
            # Annäherung: nutze Breite linker Frame / Gesamtbreite
            total = self.split.winfo_width() or 1
            self.ui_split = max(0.2, min(0.8, self.left.winfo_width() / total))
        finally:
            self.after(800, self._capture_split)

    def _popup_menu(self, event):
        try:
            iid = self.tree.identify_row(event.y)
            if iid: self.tree.selection_set(iid)
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()

    def _on_filter_change(self, _evt=None):
        if self.after_id: self.after_cancel(self.after_id)
        self.after_id = self.after(250, self._refresh_list)

    def _pick_workspace(self):
        d = filedialog.askdirectory(title="Workspace wählen", initialdir=self.workspace.get())
        if d: self.workspace.set(d); self._save_ini()

    def _pick_target(self):
        d = filedialog.askdirectory(title="Zielordner wählen", initialdir=self.target_dir.get())
        if d: self.target_dir.set(d); self._save_ini(); self._refresh_list()

    def _open_target(self):
        _open_explorer(Path(self.target_dir.get()))

    def _editor_clear(self):
        self.editor.delete("1.0","end"); self.name_var.set(f"snippet_{time.strftime('%Y%m%d_%H%M%S')}")
        self.status.set("Editor geleert.")

    def _detect_name_ext(self):
        txt = self.editor.get("1.0","end-1c")
        if not txt.strip(): self.status.set("Nichts zu erkennen (Editor leer)."); return
        ext = _detect_ext_from_text(txt)
        base = None
        for line in txt.splitlines():
            s = line.strip()
            if not s or s.startswith("#") or s.lower().startswith(("rem","::")): continue
            m = re.search(r"(Runner_[0-9]{3,4}_[A-Za-z0-9_]+)", s)
            if m: base = m.group(1)
            break
        if base is None: base = f"snippet_{time.strftime('%Y%m%d_%H%M%S')}"
        self.name_var.set(base); self.ext_var.set(ext); self._save_ini()
        self.status.set(f"Erkannt: {base}{ext}")

    def _path_from_ui(self) -> Path:
        base = self.name_var.get().strip() or f"snippet_{time.strftime('%Y%m%d_%H%M%S')}"
        ext  = self.ext_var.get().strip() or ".py"
        d    = Path(self.target_dir.get().strip() or (Path(os.getcwd())/"tools"))
        d.mkdir(parents=True, exist_ok=True); return d / f"{base}{ext}"

    def _insert_as_new(self):
        p = self._path_from_ui()
        if p.exists() and not messagebox.askyesno("Überschreiben?", f"{p.name} existiert. Überschreiben?"): return
        try:
            p.write_text(self.editor.get("1.0","end-1c"), encoding="utf-8")
            self.current_path = p; self._refresh_list(select=p); self.status.set(f"Eingefügt: {p.name}")
        except Exception as e: messagebox.showerror("Einfügen", f"{e}"); _log("INSERT_FAIL", str(e))

    def _save_current(self):
        if self.current_path is None: self._insert_as_new(); return
        try:
            self.current_path.write_text(self.editor.get("1.0","end-1c"), encoding="utf-8")
            self._refresh_list(select=self.current_path); self.status.set(f"Gespeichert: {self.current_path.name}")
        except Exception as e: messagebox.showerror("Speichern", f"{e}"); _log("SAVE_FAIL", str(e))

    def _save_as(self):
        p = self._path_from_ui()
        try:
            p.write_text(self.editor.get("1.0","end-1c"), encoding="utf-8")
            self.current_path = p; self._refresh_list(select=p); self.status.set(f"Gespeichert als: {p.name}")
        except Exception as e: messagebox.showerror("Speichern als", f"{e}"); _log("SAVEAS_FAIL", str(e))

    def _refresh_list(self, select: Path|None=None):
        self.tree.delete(*self.tree.get_children())
        root = Path(self.target_dir.get() or (Path(os.getcwd())/"tools")); root.mkdir(parents=True, exist_ok=True)
        flt = self.filter_var.get().strip().lower()
        items = []
        for p in root.rglob("*"):
            if p.is_file():
                if flt and (flt not in p.name.lower() and flt not in str(p.parent.relative_to(root)).lower()): continue
                sub = str(p.parent.relative_to(root)) if p.parent != root else ""
                date, tm = _fmt_time(p.stat().st_mtime)
                items.append((p, p.stem, p.suffix, sub, date, tm))
        key, asc = self.sort_state; idx = {"name":1,"ext":2,"subfolder":3,"date":4,"time":5}[key]
        items.sort(key=lambda t: t[idx] or "", reverse=not asc)
        for i,(p, stem, ext, sub, date, tm) in enumerate(items):
            tag = "even" if i%2==0 else "odd"
            self.tree.insert("", "end", iid=str(p), values=(stem, ext, sub, date, tm), tags=(tag,))
        if select and self.tree.exists(str(select)): self.tree.selection_set(str(select))
        self.status.set(f"{len(items)} Datei(en) in {root}")
        self._save_ini()

    def _sort_by(self, col: str):
        cur, asc = self.sort_state; self.sort_state = (col, not asc if col==cur else True); self._refresh_list(select=self.current_path)

    def _on_select(self, _evt=None):
        sel = self.tree.selection()
        if not sel: return
        p = Path(sel[0])
        try:
            txt = p.read_text(encoding="utf-8", errors="replace")
            self.editor.delete("1.0","end"); self.editor.insert("1.0", txt)
            self.current_path = p
            self.name_var.set(p.stem); self.ext_var.set(p.suffix or ".txt")
            self.target_dir.set(str(p.parent)); self._save_ini()
            self.status.set(f"Geladen: {p}")
        except Exception as e: messagebox.showerror("Laden", f"{e}"); _log("LOAD_FAIL", str(e))

    def _on_double(self, _evt=None): self._on_select()

    def _rename_current(self):
        if not self.current_path or not self.current_path.exists(): messagebox.showinfo("Rename", "Keine Datei ausgewählt."); return
        p = self.current_path
        new = simpledialog.askstring("Rename", f"Neuer Name ohne Endung ({p.suffix} bleibt):", initialvalue=p.stem)
        if not new: return
        target = p.with_name(new + (p.suffix or ""))
        try:
            if target.exists() and not messagebox.askyesno("Überschreiben?", f"{target.name} existiert. Überschreiben?"): return
            p.rename(target); self.current_path = target; self.name_var.set(target.stem)
            self._refresh_list(select=target); self.status.set(f"Umbenannt zu: {target.name}")
        except Exception as e: messagebox.showerror("Rename", f"{e}"); _log("RENAME_FAIL", str(e))

    def _run_current(self):
        p = self.current_path
        if not p or not p.exists(): messagebox.showinfo("Run", "Keine Datei ausgewählt."); return
        if p.suffix == ".py": _safe_run(["py","-3","-u",str(p)])
        elif p.suffix == ".bat": _safe_run([str(p)])
        else: messagebox.showinfo("Run", "Nur .py oder .bat werden ausgeführt.")

    def _guard_check(self):
        p = self.current_path
        if not p or not p.exists(): messagebox.showinfo("Guard", "Keine Datei ausgewählt."); return
        if p.suffix == ".py":
            try: compile(p.read_text(encoding="utf-8"), p.name, "exec"); messagebox.showinfo("Guard", "Syntax OK.")
            except Exception as e: messagebox.showerror("Guard", f"Syntaxfehler:\n{e}")
        else: messagebox.showinfo("Guard", "Guard prüft nur .py")

    def _repair(self):
        p = self.current_path
        if not p or not p.exists(): return
        try:
            txt = p.read_text(encoding="utf-8", errors="replace"); txt2 = txt.replace("\r\r\n","\r\n")
            if txt2 != txt: p.write_text(txt2, encoding="utf-8", newline="\r\n")
            messagebox.showinfo("Repair", "Kleiner Normalizer angewendet.")
        except Exception as e: messagebox.showerror("Repair", f"{e}")

    def _save_pack(self):
        root = Path(self.target_dir.get()); 
        if not root.exists(): return
        ts = time.strftime("%Y%m%d_%H%M%S"); zf = Path(os.getcwd())/f"DevIntake_Pack_{ts}.zip"
        try:
            with zipfile.ZipFile(zf, "w", zipfile.ZIP_DEFLATED) as z:
                for p in root.rglob("*"):
                    if p.is_file(): z.write(p, p.relative_to(root))
            messagebox.showinfo("Pack", f"Pack gespeichert:\n{zf}"); self.status.set(f"Pack: {zf.name}")
        except Exception as e: messagebox.showerror("Pack", f"{e}"); _log("PACK_FAIL", str(e))

    def _delete_current(self):
        p = self.current_path
        if not p or not p.exists(): messagebox.showinfo("Löschen", "Keine Datei ausgewählt."); return
        if not messagebox.askyesno("Löschen", f"{p.name} wirklich löschen?"): return
        try:
            p.unlink(); self.current_path = None; self.editor.delete("1.0","end"); self._refresh_list(); self.status.set("Datei gelöscht.")
        except Exception as e: messagebox.showerror("Löschen", f"{e}"); _log("DELETE_FAIL", str(e))

# ---- Shim ----
def create_intake_tab(nb: ttk.Notebook) -> None:
    try:
        frame = DevIntake(nb); nb.add(frame, text="Intake")
    except Exception:
        f = ttk.Frame(nb)
        ttk.Label(f, text="Intake – Fehler beim Laden. Log prüfen.", foreground="red").pack(padx=12, pady=12, anchor="w")
        nb.add(f, text="Intake"); traceback.print_exc()
'''

def main() -> int:
    try:
        ARCH.mkdir(exist_ok=True); OUT.parent.mkdir(parents=True, exist_ok=True)
        if OUT.exists():
            bak = ARCH / f"module_code_intake.py.{time.strftime('%Y%m%d_%H%M%S')}.bak"
            bak.write_text(OUT.read_text(encoding="utf-8"), encoding="utf-8"); _log(f"Backup: {bak}")
        OUT.write_text(DEV_INTAKE, encoding="utf-8", newline="\n")
        compile(DEV_INTAKE, "module_code_intake.py", "exec")
        _log("Dev-Intake Polish installiert.")
        return 0
    except Exception as e:
        _log(f"FAIL: {e}"); return 2

if __name__ == "__main__":
    sys.exit(main())
