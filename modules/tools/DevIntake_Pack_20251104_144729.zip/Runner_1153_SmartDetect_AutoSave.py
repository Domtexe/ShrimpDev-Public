# -*- coding: utf-8 -*-
"""
Runner_1153_SmartDetect_AutoSave
Mastermodus-konformer Patch:
- Ergänzt IntakeFrame um:
  * Toolbar-Toggles: Auto-Detect (on), Auto-Save (off)
  * _maybe_auto_save(): sichere, debounce-gesteuerte Speicherung
  * _sig_content(): Signatur zur Duplikatvermeidung
  * Integration: nach _detect() AutoSave prüfen
- Rückbau sicher: Backup -> Write -> Syntaxcheck -> Headless-Probe -> Rollback bei Fehlern
Report: _Reports/Runner_1153_SmartDetect_AutoSave_report.txt
"""
from __future__ import annotations
import io, os, sys, time, shutil, ast, importlib.util, types, re, hashlib, tempfile
from pathlib import Path
import py_compile

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1153_SmartDetect_AutoSave_report.txt"

def w(s=""):
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f: f.write(s.rstrip()+"\n")
    print(s)

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time()*1000)}.bak"; shutil.copy2(p, dst); return dst

NEW_METHODS = r'''
def _sig_content(self) -> str:
    """liefert eine kurze Signatur des Editorinhalts zur Duplikatvermeidung."""
    try:
        data = self.txt.get("1.0","end-1c")
    except Exception:
        data = ""
    try:
        import hashlib
        return hashlib.sha256(data.encode("utf-8", "ignore")).hexdigest()[:16]
    except Exception:
        return str(len(data))

def _maybe_auto_save(self):
    """
    Speichert automatisch, wenn:
      - Auto-Save aktiv ist
      - Erkennung ok (gültiger Name/Ext/Zielpfad)
      - Inhalt seit letztem Save geändert (Signatur)
    Debounce: 600ms; kein UI-Block. Fehler -> _ping, aber kein Crash.
    """
    try:
        if not getattr(self, "var_auto_save", None):
            return
        if not self.var_auto_save.get():
            return
    except Exception:
        return

    # Debounce über after – bereits schedulierten Job ggf. abbrechen
    try:
        if getattr(self, "_autosave_job", None):
            try: self.after_cancel(self._autosave_job)
            except Exception: pass
    except Exception:
        pass

    def _do_save():
        try:
            p = self._path_from_selection_or_fields()
            if not p:
                self._ping("AutoSave: Kein gültiger Name."); return
            folder = os.path.dirname(p) or ""
            if folder and not os.path.isdir(folder):
                try: os.makedirs(folder, exist_ok=True)
                except Exception:
                    self._ping("AutoSave: Ziel nicht schreibbar."); return
            sig = self._sig_content()
            if sig and sig == getattr(self, "_last_saved_sig", None):
                return  # nichts verändert
            # Schreiben
            try:
                with open(p, "w", encoding="utf-8", newline="\n") as f:
                    f.write(self.txt.get("1.0","end-1c"))
                self._last_saved_sig = sig
                self._update_led(self.led_save, "green")
                self._ping(f"AutoSave: {os.path.basename(p)}")
            except Exception as ex:
                self._ping(f"AutoSave-Fehler: {ex}")
        except Exception:
            try: self._ping("AutoSave fehlgeschlagen.")
            except Exception: pass

    try:
        self._autosave_job = self.after(600, _do_save)
    except Exception:
        # Fallback: sofort ausführen
        try: _do_save()
        except Exception: pass
'''.strip("\n")

def add_toggles_and_methods(src: str) -> tuple[str, list[str]]:
    """
    - Fügt Methoden (_sig_content, _maybe_auto_save) in class IntakeFrame hinzu
    - Fügt in _build_ui zwei Checkbuttons ein (Auto-Detect, Auto-Save)
    - hängt AutoSave-Aufruf an _detect() an
    """
    changes = []

    # class IntakeFrame lokalisieren
    tree = ast.parse(src)
    cls = None
    for n in tree.body:
        if isinstance(n, ast.ClassDef) and n.name == "IntakeFrame":
            cls = n; break
    if not cls: raise RuntimeError("class IntakeFrame nicht gefunden.")

    lines = src.splitlines()
    start = cls.lineno - 1
    end   = getattr(cls, "end_lineno", None) or len(lines)
    cls_src = "\n".join(lines[start:end])

    # 1) Methoden einfügen/ersetzen
    def upsert_method(csrc: str, fname: str, body_src: str) -> tuple[str,bool]:
        rx = re.compile(r'(?ms)^\s*def\s+'+re.escape(fname)+r'\s*\([^)]*\):\s*(?:\n\s+.+?)(?=^\s*def\s+\w+\s*\(|\Z)')
        if rx.search(csrc):
            return rx.sub("\n    "+body_src.replace("\n","\n    ")+"\n", csrc, count=1), True
        else:
            if not csrc.endswith("\n"): csrc += "\n"
            return csrc + "\n    "+body_src.replace("\n","\n    ")+"\n", False

    for fname in ("_sig_content","_maybe_auto_save"):
        block = re.findall(r'(?ms)^def\s+'+fname+r'\s*\([^)]*\):\s*(?:\n.+?)(?=^def\s+|\Z)', NEW_METHODS)
        if block:
            cls_src, rep = upsert_method(cls_src, fname, block[0])
            changes.append(("replaced:" if rep else "added:")+fname)

    # 2) Toggle-Variablen und Checkbuttons in _build_ui
    #   - Variablen anlegen (StringVar/BooleanVar) – wir nehmen tk.BooleanVar
    if "var_auto_detect" not in cls_src or "var_auto_save" not in cls_src:
        # nach Toolbar-Buttons definieren
        cls_src = cls_src.replace(
            '        self.btn_run.grid(   row=0, column=101, padx=(6,0), sticky="w")',
            '        self.btn_run.grid(   row=0, column=101, padx=(6,0), sticky="w")\n'
            '        # Toggles\n'
            '        self.var_auto_detect = tk.BooleanVar(value=True)\n'
            '        self.var_auto_save   = tk.BooleanVar(value=False)\n'
            '        self.chk_auto_detect = ttk.Checkbutton(bar, text="Auto-Detect", variable=self.var_auto_detect)\n'
            '        self.chk_auto_save   = ttk.Checkbutton(bar, text="Auto-Save",   variable=self.var_auto_save)\n'
            '        self.chk_auto_detect.grid(row=0, column=102, padx=(12,0), sticky="w")\n'
            '        self.chk_auto_save.grid(  row=0, column=103, padx=(6,0),  sticky="w")'
        )
        changes.append("added:toolbar_toggles")

    # 3) _detect() erweitern: Auto-Detect respektieren + AutoSave triggern
    #    - Wenn Auto-Detect aus: _detect() macht trotzdem Erkennung (Button/F5),
    #      aber keine Autosave-Trigger durch Editor-Events.
    #    -> Wir hängen _maybe_auto_save() ans Ende von _detect() an (idempotent).
    rx_detect = re.compile(r'(?ms)^\s*def\s+_detect\s*\([^)]*\):\s*\n(.*?)^\s*def\s+', re.DOTALL)
    m = rx_detect.search(cls_src)
    if m and "_maybe_auto_save(" not in m.group(1):
        body = m.group(1)
        # vor Return ok -> call _maybe_auto_save()
        body2 = re.sub(r'(return\s+ok\s*)', r'self._maybe_auto_save()\n        \1', body, count=1)
        if body2 == body:
            # Fallback: ganz am Ende vor nächster def einfügen
            body2 = body + '\n        self._maybe_auto_save()\n'
        cls_src = cls_src[:m.start(1)] + body2 + cls_src[m.end(1):]
        changes.append("patched:_detect_autosave_hook")

    # 4) Editor-Event-Handler respektieren Toggle Auto-Detect:
    #    wir schützen _schedule_detect-Aufrufe – bei Auto-Detect off: nicht schedulen.
    for handler_name in ("_on_editor_paste","_on_editor_key","_on_editor_modified"):
        rx_h = re.compile(r'(?ms)^\s*def\s+'+re.escape(handler_name)+r'\s*\([^)]*\):\s*\n(.*?)^\s*def\s+', re.DOTALL)
        m = rx_h.search(cls_src)
        if m and "var_auto_detect" in cls_src and "self.var_auto_detect.get()" not in m.group(1):
            body = m.group(1)
            guarded = (
                '        try:\n'
                '            if getattr(self, "var_auto_detect", None) and not self.var_auto_detect.get():\n'
                '                return\n'
                '        except Exception:\n'
                '            pass\n' + body
            )
            cls_src = cls_src[:m.start(1)] + guarded + cls_src[m.end(1):]
            changes.append("guarded:"+handler_name)

    new_src = "\n".join(lines[:start]) + ("\n" if start else "") + cls_src + ("\n" if end < len(lines) else "") + "\n".join(lines[end:])
    return new_src, changes

# ---- Live-Test (headless): AutoSave in temp/tools prüfen
def import_intake_for_test():
    sys.path.insert(0, str(ROOT))
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules")
        mod = types.ModuleType("modules.module_runner_exec")
        mod.run = lambda *a, **k: 0
        mod._log = lambda *a, **k: None
        sys.modules.setdefault("modules", pkg)
        sys.modules["modules.module_runner_exec"] = mod
    spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
    m = importlib.util.module_from_spec(spec); assert spec and spec.loader
    spec.loader.exec_module(m)  # type: ignore[attr-defined]
    return m

def headless_probe()->tuple[bool,str]:
    import tkinter as tk
    tmp_root = Path(tempfile.gettempdir()) / ("intake_autosave_"+str(int(time.time())))
    tools = tmp_root / "tools"; tools.mkdir(parents=True, exist_ok=True)

    m = import_intake_for_test()
    r = tk.Tk(); r.withdraw()
    fr = m.IntakeFrame(r)

    # Zielordner setzen
    try: fr.var_target.set(str(tools))
    except Exception: pass

    # Inhalt einfügen (PY), Auto-Save aktivieren
    try:
        fr.txt.delete("1.0","end"); fr.txt.insert("1.0", "import os\nprint('autosave')\n")
        fr.var_name_manual = False; fr.var_ext_manual = False
        # Toggles
        fr.var_auto_detect.set(True)
        fr.var_auto_save.set(True)
    except Exception as e:
        r.destroy(); return False, f"Init-Error: {e}"

    # Detect + AutoSave manuell triggern
    try:
        fr._detect()
        fr._maybe_auto_save()
    except Exception as e:
        r.destroy(); return False, f"Detect/AutoSave-Error: {e}"

    # Erwartete Dateipfade prüfen
    saved = list(tools.glob("*.py"))
    r.destroy()
    if not saved:
        return False, "Keine Datei gespeichert."
    try:
        txt = saved[0].read_text(encoding="utf-8", errors="ignore")
    except Exception as e:
        return False, f"Lese-Fehler: {e}"
    if "autosave" in txt:
        return True, f"AutoSave OK: {saved[0].name}"
    return False, "Inhalt weicht ab."

def main()->int:
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass
    w("[R1153] SmartDetect_AutoSave – Start")
    if not MODFILE.exists():
        w("[ERR] module_code_intake.py fehlt."); return 1

    bak = backup(MODFILE); w(f"[Backup] {bak.name}")
    src = io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

    try:
        new_src, changes = add_toggles_and_methods(src)
    except Exception as e:
        w(f"[ERR] Patch-Vorbereitung: {e}")
        return 1

    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(new_src)
    w("[Write] " + ", ".join(changes))

    try:
        py_compile.compile(str(MODFILE), doraise=True); w("[Syntax] OK")
    except Exception as e:
        w(f"[Syntax] Fehler: {e} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    ok, msg = headless_probe()
    if not ok:
        w(f"[Live] Probe-Fehler: {msg} -> Rollback"); shutil.copy2(bak, MODFILE); return 1
    w(f"[Live] {msg}")

    w("[SUM] Auto-Detect/Auto-Save integriert und lauffähig.")
    w("[R1153] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
