# -*- coding: utf-8 -*-
"""
Runner_1163_DetectGuardFix
- Fix für den vom R1162-Scanner gemeldeten Regex-Fehler (line≈331):
  FAIL error=missing ), unterminated subpattern at position 61
  snippet=«or\t\s*\w+\s*def\s*\w+\s*\(|class\s+\w+\(|if\s+»
- Ersetzt NUR diese eine Regex-Literal-Stelle durch eine balancierte, getestete Variante:
    r"(?:\bor\t\s*\w+|\bdef\s+\w+\s*\(|\bclass\s+\w+\s*\(|\bif\s+)"
- Safety: Backup, Syntax-Check, Rollback, ausführliches Logging.
"""
from __future__ import annotations
import os, io, re, time, shutil, py_compile, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOGF = os.path.join(ROOT, "debug_output.txt")

SAFE_PATTERN = r'(?:\bor\t\s*\w+|\bdef\s+\w+\s*\(|\bclass\s+\w+\s*\(|\bif\s+)'
SAFE_LITERAL = 'r"' + SAFE_PATTERN.replace('"', r'\"') + '"'  # r"..."

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1163] {ts} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, dst)
    log(f"Backup: {path} -> {dst}")
    return dst

def patch_once(src: str) -> tuple[str, list[str]]:
    changes: list[str] = []

    # Ziel: re.search(r"...or\t\s*\w+...class\s+\w+\(...if\s+...", <text>)
    # Wir ersetzen das komplette r"...." Literal innerhalb des Aufrufs.
    call_rx = re.compile(
        r"""(re\.(?:search|match)\s*\(\s*)
            (r"[^"]*or\\t\\s*\\w+[^"]*class\\s+\\w+\\([^"]*if\\s+[^"]*")   # das problematische Literal
            (\s*,)""",
        re.VERBOSE
    )

    def repl(m: re.Match) -> str:
        changes.append("Replaced broken guard-regex literal with safe canonical pattern")
        return m.group(1) + SAFE_LITERAL + m.group(3)

    new_src, n = call_rx.subn(repl, src, count=1)

    if n == 0:
        # Fallback: sehr ähnliche Schreibweisen (z.B. mit einfachen Quotes)
        call_rx_alt = re.compile(
            r"""(re\.(?:search|match)\s*\(\s*)
                (r'[^']*or\\t\\s*\\w+[^']*class\\s+\\w+\\([^']*if\\s+[^']*')
                (\s*,)""",
            re.VERBOSE
        )
        new_src, n = call_rx_alt.subn(lambda m: m.group(1) + SAFE_LITERAL + m.group(3), src, count=1)
        if n > 0:
            changes.append("Replaced broken guard-regex literal (single-quote variant) with safe canonical pattern")

    return new_src, changes

def main() -> int:
    try:
        if not os.path.isfile(MOD):
            log(f"[ERR] Not found: {MOD}")
            return 2

        with io.open(MOD, "r", encoding="utf-8") as f:
            src = f.read()

        bak = backup(MOD)

        new_src, changes = patch_once(src)
        if not changes:
            log("No changes applied (target regex literal not found). Leaving file untouched.")
            return 0

        # schreiben
        with io.open(MOD, "w", encoding="utf-8", newline="\n") as f:
            f.write(new_src)
        for c in changes:
            log(f"Change: {c}")

        # Syntax-Check
        try:
            py_compile.compile(MOD, doraise=True)
            log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}")
            shutil.copy2(bak, MOD)
            log("Restored from backup due to syntax error.")
            return 3

        # Sanity: Probe-Compile des neuen Regex (sollte fehlerfrei sein)
        try:
            re.compile(SAFE_PATTERN)
            log("Probe-Compile of SAFE_PATTERN: OK")
        except re.error as ex:
            log(f"[ERR] SAFE_PATTERN compile failed unexpectedly: {ex}")
            shutil.copy2(bak, MOD)
            log("Restored from backup due to pattern compile error.")
            return 4

        log("R1163 completed successfully.")
        return 0

    except Exception as e:
        tb = traceback.format_exc()
        log(f"[EXC] {e}\n{tb}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
