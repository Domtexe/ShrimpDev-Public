# -*- coding: utf-8 -*-
"""
[1174n] IntakeHotFix_UIInit
- fixed Tooltip.__init__ (self.widget = widget)
- ensure IntakeFrame.__init__ calls self._build_ui()
- repair _open_explorer_select() logic (Explorer öffnet Ziel/Pfad)
- defensiver Regex, idempotent; mit kurzer Ergebnisanzeige
"""
import io, os, re, sys

ROOT = r"D:\ShrimpDev"
MOD  = os.path.join(ROOT, r"modules\module_code_intake.py")

def load(p):
    with io.open(p, "r", encoding="utf-8") as f:
        return f.read()

def save(p, s):
    with io.open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)

src = load(MOD)
orig = src

changes = []

# 1) Tooltip.__init__: self.widget = widg  ->  self.widget = widget
src2 = re.sub(
    r'(class\s+Tooltip\s*\(object\)\s*:\s*def\s+__init__\s*\(\s*self\s*,\s*widget\s*,\s*text\s*\)\s*:\s*[\s\S]{0,200}?self\.widget\s*=\s*)widg\b',
    r'\1widget',
    src, flags=re.MULTILINE)
if src2 != src:
    changes.append("Tooltip.widget-Fix")
src = src2

# 2) IntakeFrame.__init__: Stelle sicher, dass self._build_ui() aufgerufen wird
#    Wir suchen Ende der __init__-Methode und fügen den Call ein, falls nicht vorhanden.
def ensure_build_call(s: str) -> str:
    pat = re.compile(r'(class\s+IntakeFrame\s*\([\w\.]+\)\s*:\s*def\s+__init__\s*\(\s*self\s*,\s*master\s*\)\s*:\s*)([\s\S]*?)(?=\n\s*def\s+\w|\Z)')
    m = pat.search(s)
    if not m:
        return s
    head, body = m.group(1), m.group(2)
    if re.search(r'\bself\._build_ui\s*\(', body):
        return s  # schon vorhanden
    # Robust am Ende der Methode einfügen (eine Einrückstufe halten)
    indent = re.search(r'\n(\s+)\S', body)
    indent_str = indent.group(1) if indent else "        "
    body_new = body.rstrip() + f"\n{indent_str}# Auto-Fix: baue Intake-UI\n{indent_str}self._build_ui()\n"
    s2 = s[:m.start()] + head + body_new + s[m.end():]
    return s2

src2 = ensure_build_call(src)
if src2 != src:
    changes.append("__init__->_build_ui()")
src = src2

# 3) _open_explorer_select: defekten try/except ersetzen durch saubere Implementierung
open_pat = re.compile(
    r'def\s+_open_explorer_select\s*\(\s*path\s*\)\s*:\s*[\s\S]*?(?=\n\s*def\s+|\Z)',
    flags=re.MULTILINE
)
def OPEN_IMPL():
    return (
        "def _open_explorer_select(path):\n"
        "    import os, subprocess\n"
        "    try:\n"
        "        if not path:\n"
        "            return\n"
        "        p = os.path.normpath(path)\n"
        "        # Datei markieren, Ordner öffnen\n"
        "        if os.path.isfile(p):\n"
        "            subprocess.Popen(['explorer', '/select,', p])\n"
        "        elif os.path.isdir(p):\n"
        "            subprocess.Popen(['explorer', p])\n"
        "        else:\n"
        "            subprocess.Popen(['explorer', os.path.dirname(p) or p])\n"
        "    except Exception:\n"
        "        pass\n"
    )

m = open_pat.search(src)
if m:
    block = m.group(0)
    if "subprocess.Popen(['explorer'" not in block:
        src = src[:m.start()] + OPEN_IMPL() + src[m.end():]
        changes.append("Explorer-Open-Fix")
else:
    # Falls Funktion fehlt (sollte nicht), am Dateiende ergänzen
    src = src.rstrip() + "\n\n" + OPEN_IMPL()
    changes.append("Explorer-Open-ADD")

# 4) Kleiner Guard: Intake-Fehlermeldung bleibt, aber wir verhindern hartnäckige Build-Abbrüche durch verirrte except/try-Blöcke
#    (nur harmlose Kosmetik – keine Logikänderung außerhalb der drei Fixes)

if src == orig:
    print("[1174n] Keine Aenderungen notwendig (bereits repariert).")
    sys.exit(0)

save(MOD, src)
print("[1174n] Uebernommen:", ", ".join(changes) or "n/a")
sys.exit(0)
