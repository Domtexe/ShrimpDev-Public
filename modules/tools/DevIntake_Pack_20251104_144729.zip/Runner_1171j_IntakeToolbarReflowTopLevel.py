# -*- coding: utf-8 -*-
"""
R1171j_IntakeToolbarReflowTopLevel
- Entfernt ALLE verschachtelten/mehrfachen 'def _intake_toolbar_reflow(...)' Blöcke robust.
- Blockende via Indent-Analyse (bis dedent < Startindent), nicht nur via Regex.
- Hängt genau EINE saubere Top-Level-Definition ans Datei-Ende.
- Ergänzt R1170e-Lifecycle-Call, falls fehlend.
- Idempotent. Mit Backup + Syntax-Check + Rollback.
Exit: 0 OK, 1 Fehler.
"""
from __future__ import annotations
import os, re, time, py_compile, traceback

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOG    = os.path.join(ROOT, "debug_output.txt")
MARK_LIFE = "# R1170e: lifecycle wire"

HELPER = r'''
# R1171j: toolbar reflow (top-level, safe)
def _intake_toolbar_reflow(self):
    """
    Ordnet die Toolbar logisch: Links (über Editor) und Rechts (über Dateiliste).
    Zwischen beiden liegt eine Stretch-Trennspalte. Status-Labels: links (lbl_ping),
    rechts ("Erkennung: …"). Keine Parent-Änderung, nur Grid-Reposition.
    """
    try:
        from tkinter import ttk
    except Exception:
        return
    try:
        # Parent bestimmen: nimm Parent eines vorhandenen Buttons
        parent = None
        for name in dir(self):
            if not name.startswith("btn_"):
                continue
            try:
                b = getattr(self, name, None)
                if b and getattr(b, "winfo_exists", lambda: False)():
                    parent = b.nametowidget(b.winfo_parent()); break
            except Exception:
                pass
        if parent is None:
            parent = getattr(self, "frm_actions", None)
        if parent is None:
            return

        # Spaltengewichte setzen: 0..39 links, 40 = Trenn-Stretch, 41..197 rechts, 198 weiterer Stretch
        try:
            for i in range(0, 200):
                try: parent.columnconfigure(i, weight=0)
                except Exception: pass
            parent.columnconfigure(40, weight=1)
            parent.columnconfigure(198, weight=1)
        except Exception:
            pass

        def _grid(w, c, padx=(0,6), sticky="w"):
            try: w.grid(row=0, column=c, padx=padx, sticky=sticky)
            except Exception: pass

        def _opt(n):
            w = getattr(self, n, None)
            return w if w and getattr(w, "winfo_exists", lambda: False)() else None

        # --- Linke Gruppe (über Editor) ---
        colL = 0
        for n in ("btn_clear", "btn_detect", "btn_save"):
            w = _opt(n)
            if w: _grid(w, colL); colL += 1

        # linker Status (lbl_ping) füllt bis Trennspalte
        try:
            from tkinter import ttk
            lbl = getattr(self, "lbl_ping", None)
            if not lbl:
                lbl = ttk.Label(parent, text="", anchor="w"); self.lbl_ping = lbl
            lbl.grid(row=0, column=colL, padx=(12,4), sticky="ew")
            try: lbl.grid_configure(columnspan=max(1, 40 - colL))
            except Exception: pass
        except Exception:
            pass

        # --- Rechte Gruppe (über Dateiliste) ---
        colR = 41
        for n in ("btn_guard", "btn_repair", "btn_run", "btn_refresh", "btn_pack", "btn_delete"):
            w = _opt(n) or _opt(n.replace("btn_delete", "btn_del"))
            if w: _grid(w, colR); colR += 1

        # rechter Status: "Erkennung: …"
        detect_lbl = None
        for nm in dir(self):
            if nm.startswith("lbl_") and "detect" in nm:
                detect_lbl = getattr(self, nm, None); break
        if detect_lbl is None:
            for nm in dir(self):
                try:
                    w = getattr(self, nm, None)
                    if hasattr(w, "cget") and isinstance(w.cget("text"), str) and "Erkennung" in w.cget("text"):
                        detect_lbl = w; break
                except Exception:
                    pass
        if detect_lbl is None:
            try:
                detect_lbl = ttk.Label(parent, text="Erkennung: (keine)", anchor="e")
                self.lbl_detect = detect_lbl
            except Exception:
                detect_lbl = None
        if detect_lbl:
            try:
                detect_lbl.grid(row=0, column=colR, padx=(12,0), sticky="ew")
                detect_lbl.grid_configure(columnspan=max(1, 198 - colR))
            except Exception:
                pass

        # Konsistente Optik
        try:
            style = ttk.Style(); style.configure("TButton", padding=(10,4))
        except Exception:
            pass

    except Exception:
        pass
'''.lstrip("\n")

def _log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1171j {ts}] {msg}\n"
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def _backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "r", encoding="utf-8") as fi, open(dst, "w", encoding="utf-8", newline="") as fo:
        fo.write(fi.read())
    return dst

def _collect_blocks(lines: list[str]) -> list[tuple[int,int,int]]:
    """
    Finde ALLE 'def _intake_toolbar_reflow(' Blöcke:
    Rückgabe: [(start_index, end_index_exclusive, start_indent_len)]
    Blockende: erste Zeile mit führenden Whitespaces < start_indent_len (Dedent) oder EOF.
    """
    heads = []
    for i, ln in enumerate(lines):
        if re.match(r'^[ \t]*def\s+_intake_toolbar_reflow\s*\(', ln):
            indent_len = len(ln) - len(ln.lstrip(" \t"))
            # vorwärts laufen
            j = i + 1
            while j < len(lines):
                s = lines[j]
                # reine Leerzeile: gehört noch zum Block
                if s.strip() == "":
                    j += 1
                    continue
                lead = len(s) - len(s.lstrip(" \t"))
                if lead < indent_len:
                    break
                j += 1
            heads.append((i, j, indent_len))
    return heads

def _dedent(snippet: list[str], indent_len: int) -> list[str]:
    out = []
    for s in snippet:
        # entferne bis zu indent_len führende Whitespaces
        k = min(indent_len, len(s) - len(s.lstrip(" \t")))
        out.append(s[k:])
    return out

def _ensure_lifecycle_call(src: str) -> tuple[str, bool]:
    if MARK_LIFE not in src:
        _log("Warnung: R1170e-Lifecycle-Block fehlt – kein Auto-Call möglich.")
        return src, False
    m = re.search(r'(?m)^([ \t]*)' + re.escape(MARK_LIFE) + r'\s*$', src)
    base = m.group(1)
    start = m.end()
    pat_end = re.compile(r'(?m)^(%s)(def|class)\b' % re.escape(base))
    m_end = pat_end.search(src, start)
    end = m_end.start() if m_end else len(src)
    block = src[start:end]
    if "_intake_toolbar_reflow(self)" in block:
        return src, False
    block = block.rstrip() + "\n" + base + "    _intake_toolbar_reflow(self)\n"
    return src[:start] + block + src[end:], True

def main() -> int:
    try:
        if not os.path.exists(TARGET):
            _log(f"Zieldatei fehlt: {TARGET}")
            return 1

        raw = open(TARGET, "r", encoding="utf-8").read()
        lines = raw.splitlines(True)

        blocks = _collect_blocks(lines)
        if not blocks and "def _intake_toolbar_reflow(" in raw:
            _log("Hinweis: Helper vorhanden, aber Blockscan ergab 0 Treffer (evtl. schon top-level).")

        moved = 0
        # von hinten nach vorne löschen
        for start, end, ind in sorted(blocks, key=lambda t: t[0], reverse=True):
            snippet = lines[start:end]
            ded = _dedent(snippet, ind)
            # entfernen
            del lines[start:end]
            # am Ende anhängen (mit Marker)
            tail = []
            if tail or True:
                tail.append("\n\n# R1171j: moved to top-level (_intake_toolbar_reflow)\n")
            tail.extend(ded)
            lines.extend(tail)
            moved += 1

        src = "".join(lines)

        # Wenn gar keine Def vorhanden ist, helfer anhängen
        if "def _intake_toolbar_reflow(" not in src:
            src = src.rstrip() + "\n\n" + HELPER
            _log("Top-Level-Helper angehängt (fehlte komplett).")
        else:
            # Absichern: genau ein Helper behalten – überschüssige doppelte Defs hart entfernen
            # (selten: wenn mehrfach vorhanden ohne Scan-Treffer)
            occ = re.findall(r'(?m)^def\s+_intake_toolbar_reflow\s*\(', src)
            if len(occ) > 1:
                # harte Bereinigung: entferne alle bis auf die letzte
                lines = src.splitlines(True)
                blocks = _collect_blocks(lines)
                # behalte die letzte
                for (start, end, _ind) in sorted(blocks, key=lambda t: t[0])[:-1]:
                    del lines[start:end]
                src = "".join(lines)
                _log(f"Doppelte Helper-Bereinigung: {len(occ)-1} überschüssige Def(s) entfernt.")

        # Lifecycle-Call sicherstellen
        src, ch = _ensure_lifecycle_call(src)
        if ch: _log("Lifecycle-Block ergänzt.")

        if moved == 0 and not ch and "R1171j: toolbar reflow" in src:
            _log("Keine Änderung erforderlich (idempotent).")

        # Backup + Schreiben + Syntaxcheck
        os.makedirs(ARCH, exist_ok=True)
        bak = os.path.join(ARCH, f"{os.path.basename(TARGET)}.{int(time.time())}.bak")
        with open(TARGET, "r", encoding="utf-8") as fi, open(bak, "w", encoding="utf-8", newline="") as fo:
            fo.write(fi.read())
        _log(f"Backup erstellt: {bak}")

        with open(TARGET, "w", encoding="utf-8", newline="\n") as f:
            f.write(src)

        try:
            py_compile.compile(TARGET, doraise=True)
        except Exception as e:
            # Rollback
            with open(bak, "r", encoding="utf-8") as fi, open(TARGET, "w", encoding="utf-8", newline="\n") as fo:
                fo.write(fi.read())
            _log("Syntax-Check FEHLER -> Rollback auf Backup.")
            _log("Traceback:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 1

        _log(f"Reflow abgeschlossen. Verschobene Blöcke: {moved}. Syntax-Check OK.")
        return 0

    except Exception as e:
        _log("UNERWARTETER FEHLER:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
