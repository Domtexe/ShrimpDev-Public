# -*- coding: utf-8 -*-
"""
Runner_1194_LEDBackgroundFix
- Fix für TclError: unknown option "-background" bei LED-Widget
- Ersetzt in modules/module_code_intake.py jede Verwendung von master.cget("background")
  durch eine ttk-freundliche, robuste Variante (Style-Lookup + Fallback).
- Non-destructive (Backup + minimaler Patch), Syntax-Check, Logging.
"""
from __future__ import annotations
import re, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
LOG  = ROOT / "debug_output.txt"

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    prev = LOG.read_text(encoding="utf-8", errors="ignore") if LOG.exists() else ""
    LOG.write_text(prev + f"[R1194] {ts} {msg}\n", encoding="utf-8")

def bail(msg: str, rc: int=1) -> None:
    log("FAIL: " + msg)
    print(msg)
    sys.exit(rc)

def ensure_dirs() -> None:
    ARCH.mkdir(parents=True, exist_ok=True)

RE_CGET_LINE = re.compile(
    r'^(?P<indent>\s*)self\.\s*_?bg\s*=\s*[^#\n]*cget\s*\(\s*[\'"]background[\'"]\s*\)[^\n]*$',
    flags=re.MULTILINE
)

# inkl. Varianten wie:
#   self._bg = master.cget("background") if hasattr(master,"cget") else "#f0f0f0"
RE_ANY_CGET_USAGE = re.compile(r'cget\s*\(\s*[\'"]background[\'"]\s*\)')

RE_CLASS_LED = re.compile(r'^\s*class\s+LED\b[\s\S]*?^\s*class\b', flags=re.MULTILINE)  # bis nächste class
# Falls LED die letzte Klasse ist: wir fangen übergeordnet ab und patchen auf Zeilenbasis.

REPLACEMENT_TEMPLATE = """{I}# robust: ttk-Theme-Hintergrund + Fallback
{I}try:
{I}    bg = master.cget("background")
{I}except Exception:
{I}    try:
{I}        import tkinter.ttk as _ttk
{I}        bg = _ttk.Style().lookup("TFrame", "background")
{I}        if not bg:
{I}            bg = "#f0f0f0"
{I}    except Exception:
{I}        bg = "#f0f0f0"
{I}self._bg = bg"""

def patch_led_background(src: str) -> tuple[str, int]:
    """
    Ersetzt in module_code_intake.py innerhalb der LED-Klasse die Hintergrunderkennung.
    Gibt (gepatchter_text, anzahl_ersetzungen) zurück.
    """
    replaced = 0

    # Wir patchen zeilenbasiert jede Zuweisung mit cget("background")
    def repl_line(m: re.Match) -> str:
        nonlocal replaced
        indent = m.group("indent")
        replaced += 1
        return REPLACEMENT_TEMPLATE.format(I=indent)

    new_src, count_line = RE_CGET_LINE.subn(repl_line, src)
    replaced += count_line  # repl_line erhöht bereits; hier nur robustheitshalber

    # Falls kein direkter Treffer (z. B. Code auf mehrere Zeilen verteilt), versuchen wir
    # einen konservativen Fallback in der LED-Klasse: wir suchen eine Zeile mit cget("background")
    if count_line == 0 and RE_ANY_CGET_USAGE.search(src):
        # Wir versuchen, die Zeile 'self._bg =' zu finden, die 'cget("background")' enthält
        lines = src.splitlines()
        for i, line in enumerate(lines):
            if RE_ANY_CGET_USAGE.search(line) and 'self._bg' in line:
                indent = re.match(r'^(\s*)', line).group(1)
                lines[i] = REPLACEMENT_TEMPLATE.format(I=indent)
                new_src = "\n".join(lines)
                replaced += 1
                break

    return new_src, replaced

def syntax_check(text: str) -> None:
    try:
        compile(text, str(MOD), "exec")
    except Exception as e:
        bail(f"Syntax-Check fehlgeschlagen: {e}", rc=3)

def main() -> None:
    ensure_dirs()
    if not MOD.exists():
        bail(f"Datei fehlt: {MOD}")

    src = MOD.read_text(encoding="utf-8", errors="ignore")

    # Backup
    bak = ARCH / f"{MOD.name}.{time.strftime('%Y%m%d_%H%M%S')}.bak"
    bak.write_text(src, encoding="utf-8")
    log(f"Backup: {bak}")

    new_src, n = patch_led_background(src)
    if n == 0:
        log("Hinweis: Keine cget(\"background\")-Stelle gefunden. Nichts zu patchen.")
    else:
        log(f"LED-Background-Stellen ersetzt: {n}")

    # Schreiben + Syntaxcheck
    MOD.write_text(new_src, encoding="utf-8")
    syntax_check(new_src)
    log("Patch geschrieben & Syntax OK.")
    print("[R1194] Done.")

if __name__ == "__main__":
    main()
