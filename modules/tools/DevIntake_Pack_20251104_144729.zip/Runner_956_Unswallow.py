from __future__ import annotations
from pathlib import Path
import re, time, shutil, py_compile, sys

ROOT = Path(r"D:\ShrimpDev")
MAIN = ROOT / "main_gui.py"

def ts(): return time.strftime("%Y%m%d_%H%M%S")
def backup(p: Path):
    if p.exists():
        b = p.with_suffix(p.suffix + f".{ts()}.bak")
        shutil.copy2(p, b)
        print(f"[R956] Backup: {b.name}")

def compile_ok(p: Path) -> tuple[bool,str]:
    try:
        py_compile.compile(str(p), doraise=True)
        return True, ""
    except Exception as ex:
        return False, str(ex)

def unswallow(txt: str) -> tuple[str,int]:
    """
    Entfernt leere 'except Exception: pass' direkt vor einem weiteren except/finally/else.
    Ersetzt Muster:
        except Exception:\n [leer/Kommentare/Spaces]* pass ...\n except ...
    durch nur einen 'except ...' (den zweiten Block behalten).
    """
    # robust: gleiche Einrückung, optional Kommentare/Leerzeilen zwischen except und pass
    pat = re.compile(
        r'(?m)^(?P<ind>[ \t]*)except\s+Exception\s*:\s*\n'
        r'(?:(?P=ind)[ \t]*(?:#.*)?\s*\n)*'
        r'(?P=ind)[ \t]*pass[^\n]*\n'
        r'(?P=ind)except\s+',
    )
    count = 0
    while True:
        new, n = pat.subn(r'\g<ind>except ', txt)
        txt = new
        count += n
        if n == 0:
            break
    return txt, count

def fix_main_logging(txt: str) -> tuple[str,bool]:
    """
    Stellt sicher, dass im __main__-Block EIN except mit Logging vorhanden ist.
    Entfernt den leeren except und lässt den mit 'as ex' stehen.
    """
    # Entferne explizit ein leeres 'except Exception: pass' im __main__-Konstrukt
    pat = re.compile(
        r'(if __name__ == "__main__":\s*\n'
        r'[ \t]*try:\s*\n'
        r'(?:.*\n)*?)'                               # try-body
        r'([ \t]*except\s+Exception\s*:\s*\n'
        r'(?:[ \t]*pass[^\n]*\n)+)'                  # leere except-Section
        r'([ \t]*except\s+Exception\s+as\s+ex\s*:\s*\n'
        r'(?:.*\n)*?)$',                             # logging except
        re.S
    )
    new, n = pat.subn(r'\1\3', txt)
    return new, n > 0

def add_boot_log(txt: str) -> tuple[str,bool]:
    """
    Fügt direkt nach App-Erstellung ein Boot-Log hinzu, falls nicht vorhanden.
    """
    if '[BOOT]' in txt:
        return txt, False
    pat = re.compile(r'(app\s*=\s*ShrimpDevApp\(\)\s*\n[ \t]*app\.mainloop\(\))')
    new, n = pat.subn(r'log("[BOOT] launching")\n\1', txt, count=1)
    return new, n > 0

def main() -> int:
    if not MAIN.exists():
        print("[R956] FEHLT: main_gui.py"); return 2

    backup(MAIN)
    txt = MAIN.read_text(encoding="utf-8", errors="ignore")

    # 1) leere excepts entfernen (vor nachfolgendem except/..)
    txt, removed = unswallow(txt)
    if removed:
        print(f"[R956] Leere excepts entfernt: {removed}")

    # 2) __main__-Block: leeren except raus, Logging-except behalten
    txt, fixed_main = fix_main_logging(txt)
    if fixed_main:
        print("[R956] __main__-Logging wiederhergestellt.")

    # 3) optional: Boot-Log ergänzen
    txt, boot = add_boot_log(txt)
    if boot:
        print("[R956] Boot-Log ergänzt.")

    MAIN.write_text(txt, encoding="utf-8")

    ok, err = compile_ok(MAIN)
    if ok:
        print("[R956] Syntax OK – main_gui.py kompiliert.")
        return 0
    else:
        print(f"[R956] FEHLER bleibt: {err}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
