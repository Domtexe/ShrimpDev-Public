from __future__ import annotations
import sys, time
from pathlib import Path

ROOT  = Path(r"D:\ShrimpDev")
TOOLS = ROOT/"tools"; TOOLS.mkdir(parents=True, exist_ok=True)

RID  = int(sys.argv[1]) if len(sys.argv)>1 else 950
DESC = (sys.argv[2] if len(sys.argv)>2 else "New Runner").strip()

py_name  = f"Runner_{RID}.py"
bat_name = f"Runner_{RID}.bat"

PY = f'''# {py_name} — {DESC}
from __future__ import annotations
import json, time
from pathlib import Path

ROOT = Path(r"D:\\ShrimpDev")

def _send(ev: dict):
    try:
        from modules.snippets.agent_client import send_event
        send_event({{"runner":"R{RID}", **ev}})
    except Exception:
        try:
            inbox = ROOT/"_Reports"/"Agent"/"inbox"
            inbox.mkdir(parents=True, exist_ok=True)
            (inbox/f"{{int(time.time())}}.jsonl").open("a", encoding="utf-8").write(json.dumps({{"runner":"R{RID}", **ev}}, ensure_ascii=False)+"\\n")
        except Exception:
            pass

def main():
    _send({{"level":"INFO","msg":"Runner started"}})
    # TODO: implement logic here
    print("[R{RID}] hello")
    _send({{"level":"OK","msg":"Runner finished"}})

if __name__ == "__main__":
    main()
'''

BAT = f'''@echo off
cd /d "D:\\ShrimpDev"
echo [RUN ] py -3 -u tools\\{py_name}
py -3 -u tools\\{py_name}
echo [END ] RC=%errorlevel%
exit /b %errorlevel%
'''

(py := TOOLS/py_name).write_text(PY, encoding="utf-8")
(TOOLS/bat_name).write_text(BAT, encoding="utf-8")
print(f"[R943] CREATED: tools\\{py_name} + .bat")

# Registry upsert
try:
    from modules.module_registry import upsert_runner
    upsert_runner(RID, f"Runner_{RID}", str(py), purpose=DESC, inputs=["*"])
    print("[R943] Registry updated.")
except Exception as ex:
    print(f"[R943] Registry update failed: {ex}")
