import io, re, sys, py_compile, os, shutil
p = os.path.join("modules","module_code_intake.py")
src = io.open(p, "r", encoding="utf-8").read()

# nur gezielte, idempotente Ersetzung
new = src.replace("self._intake_post_build_bind_clear()", "_intake_post_build_bind_clear(self)")

if new == src:
    print("[1167i] Hinweis: Datei war bereits korrekt – keine Änderung.")
else:
    io.open(p, "w", encoding="utf-8", newline="\n").write(new)
    print("[1167i] Änderung geschrieben.")

# Syntaxcheck
py_compile.compile(p, doraise=True)
print("[1167i] Syntax-Check OK.")
