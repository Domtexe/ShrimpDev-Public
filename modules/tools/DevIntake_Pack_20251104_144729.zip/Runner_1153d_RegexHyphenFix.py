"""
Runner_1153d_RegexHyphenFix.py
Ziel: Regex-Zeichenklassen mit problematischem '-' reparieren (bad character range).
Vorgehen:
- Backup anlegen
- Selektiv Zeichenklassen fixen: '-' ans Ende der Klasse verschieben oder escapen
- Syntax-/Import-Check
- Bei Fehlern: Rollback
"""

from __future__ import annotations
import io, os, re, shutil, sys, time, importlib.util

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD_PATH = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCHIV = os.path.join(ROOT, "_Archiv")
os.makedirs(ARCHIV, exist_ok=True)

def ts() -> str:
    return str(int(time.time()*1000))

def read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8", newline="") as f:
        return f.read()

def write_text(path: str, data: str) -> None:
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(data)

def backup(src: str) -> str:
    dst = os.path.join(ARCHIV, f"{os.path.basename(src)}.{ts()}.bak")
    shutil.copy2(src, dst)
    print(f"[Backup] {os.path.relpath(src, ROOT)} -> {os.path.relpath(dst, ROOT)}")
    return dst

# -------- Kern-Heuristik -------------------------------------------------------
# Wir finden Regex-Literale in re.compile("...")/r"..."
# und sanieren NUR Zeichenklassen [ ... ] mit '-' der kein Bereich sein soll.
#
# Regeln:
# 1) '-' ist unkritisch am Anfang oder Ende einer Klasse: [-...], [...-]
# 2) Echte Bereiche lassen wir durch (A-Z, a-z, 0-9, etc.)
# 3) Bei isoliertem '-' zwischen Nicht-Bereichszeichen -> an das Klassenende
#    Beispiel:  [\w\.-]  =>  [\w\. -]   (wir normalisieren zu [\w\.-])
# 4) Doppelt backslashte Sequenzen lassen wir als Literal zu.
#
# Umsetzung: Wir parsen Zeichenklassen grob und reorganisieren „-“,
# indem wir innerhalb der Klasse einen einzelnen „-“ als Literal ans Ende ziehen,
# sofern er nicht zwischen zwei alphanumerischen Zeichen steht.

CHARCLASS_RE = re.compile(r"""
    (\[)                 # Start '['
    (                    # Inhalt der Klasse (gruppe 2)
        (?:\\.|[^\]\\])* # beliebig, aber ']' und Backslash als Escape
    )
    (\])                 # schliessende ']'
""", re.VERBOSE)

def _is_range(left: str, right: str) -> bool:
    """Erkennt typische Bereiche wie A-Z, a-z, 0-9."""
    if len(left) != 1 or len(right) != 1:
        return False
    return (
        ("A" <= left <= "Z" and "A" <= right <= "Z") or
        ("a" <= left <= "z" and "a" <= right <= "z") or
        ("0" <= left <= "9" and "0" <= right <= "9")
    )

def fix_charclass(content: str) -> str:
    # Wir zerlegen in Token, um '-' bewerten zu können.
    tokens = []
    i = 0
    while i < len(content):
        c = content[i]
        if c == "\\" and i + 1 < len(content):
            tokens.append(content[i:i+2])
            i += 2
        else:
            tokens.append(c)
            i += 1

    # Markiere „isolierte“ - die KEIN Range bilden
    fixed = []
    hyphens_literal = 0
    for idx, tok in enumerate(tokens):
        if tok == "-":
            left = tokens[idx-1] if idx-1 >= 0 else ""
            right = tokens[idx+1] if idx+1 < len(tokens) else ""
            # Wenn links/rechts ein Escapesymbol wie \w, \s, \. etc. ist,
            # behandeln wir '-' als literal (kein Range).
            left_atom = left if len(left) == 1 else ("X" if left.startswith("\\") else left[-1:])
            right_atom = right if len(right) == 1 else ("X" if right.startswith("\\") else right[:1])
            if _is_range(left_atom, right_atom):
                fixed.append("-")   # Range beibehalten
            else:
                # Literal '-' erst sammeln; wir hängen es später ans Ende der Klasse
                hyphens_literal += 1
                continue
        else:
            fixed.append(tok)

    if hyphens_literal:
        # Stelle sicher, dass '-' am Ende als Literal enthalten ist (einmal pro gefundenem Literal)
        fixed.extend("-" * hyphens_literal)

    return "".join(fixed)

def repair_regex_hyphens(source: str) -> tuple[str, int]:
    """Sanierung aller Zeichenklassen in Regex-Literalen innerhalb der Datei."""
    # Wir wenden die Heuristik breit auf ALLE Zeichenklassen im Quelltext an.
    # Das ist sicher, weil wir nur '-' verschieben – andere Zeichen bleiben unverändert.
    replacements = 0
    out = []
    last = 0
    for m in CHARCLASS_RE.finditer(source):
        out.append(source[last:m.start()])
        head, body, tail = m.group(1), m.group(2), m.group(3)
        new_body = fix_charclass(body)
        if new_body != body:
            replacements += 1
        out.append(head + new_body + tail)
        last = m.end()
    out.append(source[last:])
    return "".join(out), replacements

def syntax_check(path: str) -> None:
    import py_compile
    py_compile.compile(path, doraise=True)

def import_check(module_path: str) -> None:
    spec = importlib.util.spec_from_file_location("modules.module_code_intake", module_path)
    mod = importlib.util.module_from_spec(spec)
    loader = spec.loader
    assert loader is not None
    loader.exec_module(mod)

def main() -> int:
    print("[R1153d] RegexHyphenFix – Start")
    if not os.path.isfile(MOD_PATH):
        print(f"[R1153d] Fehler: {MOD_PATH} nicht gefunden.")
        return 2

    bak = backup(MOD_PATH)
    src = read_text(MOD_PATH)

    fixed, n = repair_regex_hyphens(src)
    if n == 0:
        print("[Info] Keine problematischen '-' in Zeichenklassen gefunden – keine Änderung.")
        return 0

    write_text(MOD_PATH, fixed)
    print(f"[Write] Sanierte Zeichenklassen: {n}")

    try:
        syntax_check(MOD_PATH)
        print("[Syntax] OK")
        import_check(MOD_PATH)
        print("[Import] OK")
        print("[R1153d] Fertig")
        return 0
    except Exception as e:
        print(f"[Probe-Fehler] {e.__class__.__name__}: {e} -> Rollback")
        shutil.copy2(bak, MOD_PATH)
        return 1

if __name__ == "__main__":
    sys.exit(main())
