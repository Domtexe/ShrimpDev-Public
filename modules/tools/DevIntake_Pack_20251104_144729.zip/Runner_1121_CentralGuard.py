# -*- coding: utf-8 -*-
r"""
Runner_1121_CentralGuard
- Entfernt alte Guard-Blöcke (1119 & 1121) aus main_gui.py
- Fügt einen Central-Tk-Guard DIREKT NACH allen 'from __future__ import ...' ein
- Guard loggt ausschließlich zentral via modules.snippets.logger_snippet.write_log
  (Datei-Fallback nur, wenn der Logger nicht importierbar ist)
- Keine messagebox-/Tk-Aufrufe im Handler → kein _report_exception-Reentrancy-Pfad
"""

from __future__ import annotations
import os, re, time, shutil

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
P_MAIN = os.path.join(ROOT, "main_gui.py")
ARCH   = os.path.join(ROOT, "_Archiv")
REPO   = os.path.join(ROOT, "_Reports")
os.makedirs(ARCH, exist_ok=True)
os.makedirs(REPO, exist_ok=True)
REPORT = os.path.join(REPO, "Runner_1121_CentralGuard_report.txt")

# Tags
TAG_1119_S = "# === 1119 TopLevel Tk Guard (auto) ==="
TAG_1119_E = "# === /1119 ==="
TAG_1121_S = "# === 1121 Central Tk Guard (auto) ==="
TAG_1121_E = "# === /1121 ==="

def rep(msg: str) -> None:
    with open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip() + "\n")

def backup(path: str) -> str:
    ts = str(int(time.time()))
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    shutil.copy2(path, dst)
    rep(f"[Backup] {path} -> {dst}")
    return dst

def strip_old_guards(src: str) -> tuple[str, bool]:
    """Entfernt 1119- und 1121-Blöcke konservativ."""
    changed = False
    # 1119
    src2, n = re.subn(re.escape(TAG_1119_S) + r"[\s\S]*?" + re.escape(TAG_1119_E), "", src)
    if n: changed, src = True, src2
    # 1121
    src2, n = re.subn(re.escape(TAG_1121_S) + r"[\s\S]*?" + re.escape(TAG_1121_E), "", src)
    if n: changed, src = True, src2
    return src, changed

def future_block_end(src: str) -> int:
    """
    Liefert die Position NACH dem zusammenhängenden Block der __future__-Imports.
    """
    m = re.match(r'^(?:\s*from\s+__future__\s+import[^\n]*\n)+', src, flags=re.MULTILINE)
    return m.end() if m else 0

def make_guard_snippet() -> str:
    """Central Guard – keine UI-Aufrufe, zentraler Logger, Datei-Fallback."""
    return (
        f"\n{TAG_1121_S}\n"
        "def __install_central_tk_guard__():\n"
        "    import sys, traceback, time, os\n"
        "    # Logger-Resolver\n"
        "    _write = None\n"
        "    try:\n"
        "        from modules.snippets.logger_snippet import write_log as _write\n"
        "    except Exception:\n"
        "        LOG = os.path.join(os.path.dirname(__file__), 'debug_output.txt')\n"
        "        def _write(prefix: str, message: str) -> None:\n"
        "            try:\n"
        "                ts = time.strftime('%Y-%m-%d %H:%M:%S')\n"
        "                with open(LOG, 'a', encoding='utf-8', newline='\\n') as f:\n"
        "                    f.write(f\"[{prefix}] {ts} {message}\\n\")\n"
        "            except Exception:\n"
        "                pass\n"
        "    _busy = {'v': False}\n"
        "    def _handler(exc, val, tb):\n"
        "        if _busy['v']:\n"
        "            return\n"
        "        _busy['v'] = True\n"
        "        try:\n"
        "            msg = ''.join(traceback.format_exception(exc, val, tb))\n"
        "            _write('TK', 'EXC\\n' + msg)\n"
        "        finally:\n"
        "            _busy['v'] = False\n"
        "    try:\n"
        "        import tkinter as _tk\n"
        "        # Nur Callback-Hooks ersetzen; keine UI in _handler()\n"
        "        _tk.Misc.report_callback_exception = _handler  # type: ignore[attr-defined]\n"
        "        def _safe__report_exception(self):\n"
        "            et, ev, tb = sys.exc_info()\n"
        "            if et is not None:\n"
        "                _handler(et, ev, tb)\n"
        "        _tk.BaseWidget._report_exception = _safe__report_exception  # type: ignore[attr-defined]\n"
        "    except Exception:\n"
        "        # Falls Tk noch nicht geladen ist: Guard bleibt trotzdem definiert\n"
        "        pass\n"
        "__install_central_tk_guard__()\n"
        f"{TAG_1121_E}\n"
    )

def patch_main() -> None:
    if not os.path.exists(P_MAIN):
        rep("[main_gui] nicht gefunden – Abbruch.")
        return
    with open(P_MAIN, "r", encoding="utf-8") as f:
        src = f.read()

    # Alte Guards raus
    src, removed = strip_old_guards(src)
    if removed:
        rep("[main_gui] Alte Guard-Blöcke entfernt.")

    # Guard nach __future__-Block einfügen
    pos = future_block_end(src)  # 0 wenn keine __future__-Imports vorhanden
    new_src = src[:pos] + make_guard_snippet() + src[pos:]

    # Schreiben
    backup(P_MAIN)
    with open(P_MAIN, "w", encoding="utf-8", newline="\n") as f:
        f.write(new_src)
    rep("[main_gui] Central-Guard nach __future__-Imports eingefügt.")
    rep("OK – Runner abgeschlossen.")

if __name__ == "__main__":
    with open(REPORT, "w", encoding="utf-8", newline="\n") as f:
        f.write("Runner_1121_CentralGuard – Start\n")
    try:
        patch_main()
    except Exception as ex:
        rep("FEHLER: " + repr(ex))
