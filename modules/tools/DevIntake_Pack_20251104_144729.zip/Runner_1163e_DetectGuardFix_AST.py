# -*- coding: utf-8 -*-
"""
R1163e DetectGuardFix AST
- Sucht AST-basiert re.search|match und extrahiert Pattern:
  unterstützt r'', r"", r''' ''', r""" """, String-Additionen; f-Strings nur ohne Platzhalter.
- Wenn Pattern die bekannten Substrings enthält (or\\t\\s*\\w+, class\\s+\\w+\\(, if\\s+)
  UND re.compile scheitert, ersetzt NUR dieses Literal durch SAFE_PATTERN.
- Safety: Backup, Syntax-Check, Rollback.
"""
from __future__ import annotations
import os, io, ast, re, time, shutil, py_compile, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOGF = os.path.join(ROOT, "debug_output.txt")
SAFE_PATTERN = r'(?:\bor\t\s*\w+|\bdef\s+\w+\s*\(|\bclass\s+\w+\s*\(|\bif\s+)'

def log(msg): 
    ts=time.strftime("%Y-%m-%d %H:%M:%S"); 
    line=f"[R1163e] {ts} {msg}\n"
    try: 
        with io.open(LOGF,"a",encoding="utf-8") as f: f.write(line)
    except Exception: 
        pass
    print(line,end="")

def backup(p):
    os.makedirs(ARCH, exist_ok=True)
    dst=os.path.join(ARCH,f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p,dst); log(f"Backup: {p} -> {dst}"); return dst

def const_string(n: ast.AST):
    if isinstance(n, ast.Constant) and isinstance(n.value, str): return True, n.value
    if isinstance(n, ast.JoinedStr):
        parts=[]
        for v in n.values:
            if isinstance(v, ast.Constant) and isinstance(v.value, str): parts.append(v.value)
            else: return False, ""
        return True, "".join(parts)
    if isinstance(n, ast.BinOp) and isinstance(n.op, ast.Add):
        ok_l,s_l=const_string(n.left); ok_r,s_r=const_string(n.right)
        if ok_l and ok_r: return True, s_l+s_r
        return False, ""
    return False, ""

def replace_slice(src, sl, sc, el, ec, new_text):
    lines=src.splitlines(True)
    before="".join(lines[:sl-1])+lines[sl-1][:sc]
    after=lines[el-1][ec:]+ "".join(lines[el:])
    return before+new_text+after

def main():
    try:
        if not os.path.isfile(MOD): log(f"[ERR] Not found: {MOD}"); return 2
        src=io.open(MOD,"r",encoding="utf-8").read()
        tree=ast.parse(src, filename=MOD)
        keys=("or\\t\\s*\\w+","class\\s+\\w+\\(","if\\s+")
        targets=[]
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                if not (isinstance(node.func.value, ast.Name) and node.func.value.id=="re"): continue
                if node.func.attr not in ("search","match"): continue
                if not node.args: continue
                ok,pat=const_string(node.args[0])
                if not ok: continue
                if all(k in pat for k in keys):
                    try:
                        re.compile(pat); continue   # kompiliert -> kein Patch
                    except re.error as ex:
                        targets.append((node, pat, str(ex)))
        if not targets:
            log("No changes applied (target regex not found or already compilable)."); return 0

        node, pat, err = targets[0]
        log(f"Will replace failing pattern at line={node.lineno}: error={err}")
        arg=node.args[0]
        if not hasattr(arg,"lineno") or not hasattr(arg,"end_lineno"):
            log("[ERR] No positional info; abort."); return 5
        new_literal='r"'+SAFE_PATTERN.replace('"', r'\"')+'"'
        new_src=replace_slice(src,arg.lineno,arg.col_offset,arg.end_lineno,arg.end_col_offset,new_literal)
        bak=backup(MOD)
        io.open(MOD,"w",encoding="utf-8",newline="\n").write(new_src)
        try: py_compile.compile(MOD,doraise=True); log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}"); shutil.copy2(bak,MOD); log("Restored from backup."); return 3
        try: re.compile(SAFE_PATTERN); log("Probe-Compile of SAFE_PATTERN: OK")
        except re.error as ex:
            log(f"[ERR] SAFE_PATTERN compile failed: {ex}"); shutil.copy2(bak,MOD); log("Restored from backup."); return 4
        log("R1163e completed successfully."); return 0
    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}"); return 1

if __name__=="__main__": raise SystemExit(main())
