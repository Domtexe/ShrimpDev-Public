import time, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOG  = ROOT / "debug_output.txt"
OUT  = ROOT / "modules" / "module_gate_panel.py"

CODE = r'''<<<PASTE_gate_panel_py_HERE>>>'''

def log(msg: str):
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1178o] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    except Exception:
        pass

def main():
    code = CODE.replace("<<<PASTE_gate_panel_py_HERE>>>", "")
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(code, encoding="utf-8", newline="\n")
    try:
        compile(code, "module_gate_panel.py", "exec")
    except Exception as ex:
        log("SyntaxError: " + str(ex))
        sys.exit(1)
    log("Gate panel fixed and written.")

if __name__ == "__main__":
    main()
