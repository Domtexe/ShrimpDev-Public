# -*- coding: utf-8 -*-
"""
R1163h2 FixPythonHeadRegex SafePlain
- Kein re.sub mit Backslashes -> kein 'bad escape'.
- Scannt Datei textuell: findet Aufrufe re.search( r"...", ... ) / re.search( r'...', ... )
  und extrahiert das Pattern-Literal robust (unterstützt mehrzeilig).
- Wenn das Pattern die Teile ('def\\s+\\w+\\(', 'class\\s+\\w+\\(', '__main__') enthält
  UND re.compile() darauf fehlschlägt (unterminated subpattern), ersetzt NUR den Inhalt
  des String-Literals durch ein balanciertes, getestetes SAFE_PATTERN.
- Safety: Backup -> _Archiv, Syntax-Check via py_compile, Rollback bei Fehler.
"""
from __future__ import annotations
import io, os, time, shutil, py_compile, re, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
LOGF = ROOT / "debug_output.txt"

# Balanciertes, getestetes Pattern für Python-Head-Erkennung
SAFE_PATTERN = r'(?m)^\s*(?:from\s+\w+\s+import|import\s+\w+|def\s+\w+\s*\(|class\s+\w+\s*\(|if\s+__name__\s*==\s*[\'\"]__main__[\'\"])'

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1163h2] {ts} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f: f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(p: Path) -> Path:
    ARCH.mkdir(parents=True, exist_ok=True)
    dst = ARCH / f"{p.name}.{int(time.time())}.bak"
    shutil.copy2(p, dst)
    log(f"Backup: {p} -> {dst}")
    return dst

def extract_literal(src: str, pos: int) -> tuple[int,int,str,str] | tuple[None,None,None,None]:
    """
    Ab pos (Index auf 're.search(') das erste String-Literal (r'...' oder r"...") extrahieren.
    Gibt (start_index, end_index, quote_char, body) zurück; end_index ist exklusive Position hinter dem schließenden Quote.
    Unterstützt mehrzeilige Literale (Triple-Quotes) NICHT – falls die Stelle so vorliegt, überspringen wir.
    """
    i = src.find("re.search(", pos)
    if i == -1: return (None, None, None, None)
    j = src.find("r'", i, i+500)
    k = src.find('r"', i, i+500)
    use = None
    if j != -1 and k != -1:
        use = min(j, k)
    elif j != -1:
        use = j
    elif k != -1:
        use = k
    else:
        return (None, None, None, None)
    quote = src[use+1]  # ' or "
    start = use + 2
    end = src.find(quote, start)
    if end == -1:
        return (None, None, None, None)
    body = src[start:end]
    return (use, end+1, quote, body)

def find_and_fix(src: str) -> tuple[str, bool]:
    """
    Durchsucht nacheinander alle re.search-Vorkommen; sobald ein passender, fehlerhafter
    Pattern-String gefunden wird, ersetzt ihn durch SAFE_PATTERN (nur den String-Inhalt).
    """
    idx = 0
    changed = False
    keys = ("def\\s+\\w+\\(", "class\\s+\\w+\\(", "__main__")
    while True:
        i = src.find("re.search(", idx)
        if i == -1:
            break
        s, e, quote, body = extract_literal(src, i)
        if s is None:
            idx = i + 10
            continue
        # Kandidat prüfen
        if all(k in body for k in keys):
            try:
                re.compile(body)
                # kompiliert -> nichts ändern
            except re.error as ex:
                # genau das wollen wir fixen
                new_literal = "r\"" + SAFE_PATTERN.replace('"', r'\"') + "\"" if quote == '"' else "r'" + SAFE_PATTERN.replace("'", r"\'") + "'"
                src = src[:s] + new_literal + src[e:]
                changed = True
                break
        idx = e + 1
    return src, changed

def main() -> int:
    try:
        if not MOD.exists():
            log(f"[ERR] Not found: {MOD}")
            return 2
        text = MOD.read_text(encoding="utf-8")
        bak = backup(MOD)
        new_text, changed = find_and_fix(text)
        if not changed:
            log("No changes applied (target literal not found or already compilable).")
            return 0

        MOD.write_text(new_text, encoding="utf-8", newline="\n")
        # Syntax-Check
        try:
            py_compile.compile(str(MOD), doraise=True)
            log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}")
            shutil.copy2(bak, MOD)
            log("Restored from backup.")
            return 3

        # Sanity: neues Pattern muss kompilieren
        try:
            re.compile(SAFE_PATTERN)
            log("Probe-Compile SAFE_PATTERN: OK")
        except re.error as ex:
            log(f"[ERR] SAFE_PATTERN compile failed: {ex}")
            shutil.copy2(bak, MOD)
            log("Restored from backup.")
            return 4

        log("R1163h2 completed successfully.")
        return 0

    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
