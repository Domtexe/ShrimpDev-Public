# -*- coding: utf-8 -*-
"""
[1174i] IntakeRestoreSmart
- Findet die jüngste "gute" module_code_intake.py.*.bak im _Archiv
- Kriterien:
    * Syntax OK (py_compile)
    * Enthält class IntakeFrame und _build_ui
    * Enthält typische Intake-UI-Elemente (heuristische Stichworte)
- Ersetzt modules/module_code_intake.py sicher mit Backup & Rollback
- Schreibt Logs nach debug_output.txt
"""
from __future__ import annotations
import os, time, glob, shutil, py_compile, importlib.util

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
MODS   = os.path.join(ROOT, "modules")
ARCH   = os.path.join(ROOT, "_Archiv")
TARGET = os.path.join(MODS, "module_code_intake.py")
LOGF   = os.path.join(ROOT, "debug_output.txt")

os.makedirs(ARCH, exist_ok=True)

def log(msg:str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(f"[1174i] {ts} {msg}\n")
    except Exception:
        pass

def _syntax_ok(path:str) -> bool:
    try:
        py_compile.compile(path, doraise=True)
        return True
    except Exception as ex:
        log(f"Syntax-Check FAIL for {os.path.basename(path)}: {ex}")
        return False

def _features_ok(path:str) -> bool:
    """Heuristischer Feature-Check ohne Ausführen des Codes."""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            s = f.read()
        must = ["class IntakeFrame", "def _build_ui", "ttk.Treeview", "tk.Text"]
        score = 0
        for m in must:
            if m in s: score += 1
        # Bonus-Treffer für bekannte Buttons/Begriffe
        hints = ["Erkennen", "Speichern", "Prüfen", "Repair", "Aktualisieren", "Datei löschen", "Pack speichern"]
        bonus = sum(1 for h in hints if h in s)
        log(f"Feature-Score {os.path.basename(path)}: base={score}/{len(must)} bonus={bonus}")
        return score == len(must)
    except Exception as ex:
        log(f"Feature-Check FAIL for {os.path.basename(path)}: {ex}")
        return False

def _import_smoke(path:str) -> bool:
    """Versuche, das Modul als Datei zu importieren (ohne es global zu installieren)."""
    try:
        spec = importlib.util.spec_from_file_location("module_code_intake_probe", path)
        mod  = importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        spec.loader.exec_module(mod)  # führt Datei einmalig aus
        ok = hasattr(mod, "IntakeFrame")
        if not ok:
            log("Import-Smoke: Kein IntakeFrame im Modul.")
        return ok
    except Exception as ex:
        log(f"Import-Smoke FAIL: {ex}")
        return False

def find_best_backup() -> str | None:
    cand = sorted(glob.glob(os.path.join(ARCH, "module_code_intake.py.*.bak")),
                  key=lambda p: os.path.getmtime(p),
                  reverse=True)
    if not cand:
        log("Keine module_code_intake.py.*.bak im _Archiv gefunden.")
        return None
    for c in cand:
        log(f"Prüfe Kandidat: {os.path.basename(c)}")
        if not _syntax_ok(c): 
            continue
        if not _features_ok(c):
            continue
        if not _import_smoke(c):
            continue
        log(f"Geeigneter Kandidat: {os.path.basename(c)}")
        return c
    log("Kein geeigneter Kandidat im _Archiv bestanden.")
    return None

def backup_current():
    if os.path.exists(TARGET):
        ts = str(int(time.time()))
        bak = os.path.join(ARCH, f"module_code_intake.py.{ts}.bak")
        shutil.copy2(TARGET, bak)
        log(f"Backup aktuelle Intake: {bak}")

def fallback_save_current_as_fallback():
    """Sichere die ggf. vereinfachte aktuelle Intake als 'FALLBACK'."""
    if os.path.exists(TARGET):
        ts = str(int(time.time()))
        fb = os.path.join(ARCH, f"module_code_intake.py.FALLBACK.{ts}.bak")
        try:
            shutil.copy2(TARGET, fb)
            log(f"Fallback aus aktueller Intake gesichert: {fb}")
        except Exception as ex:
            log(f"Fallback-Sicherung fehlgeschlagen: {ex}")

def replace_with(src:str) -> bool:
    tmp = TARGET + ".tmprestore"
    try:
        shutil.copy2(src, tmp)
        if not _syntax_ok(tmp):
            log("TMP Syntax-Check unerwartet fehlgeschlagen – Abbruch.")
            try: os.remove(tmp)
            except: pass
            return False
        shutil.move(tmp, TARGET)
        log(f"Restored: {os.path.basename(src)} -> module_code_intake.py")
        return True
    except Exception as ex:
        log(f"Replace-Fehler: {ex}")
        try: 
            if os.path.exists(tmp): os.remove(tmp)
        except: 
            pass
        return False

def main() -> int:
    log("=== START IntakeRestoreSmart ===")
    # 1) aktuelle (vereinfachte) Intake als Fallback sichern
    fallback_save_current_as_fallback()
    # 2) besten Backup-Kandidaten finden
    best = find_best_backup()
    if not best:
        log("Keine geeignete Archiv-Version gefunden. Abbruch ohne Änderung.")
        return 2
    # 3) aktuelle Intake backuppen
    backup_current()
    # 4) ersetzen
    ok = replace_with(best)
    if not ok:
        log("Ersetzung fehlgeschlagen. Alte Datei bleibt erhalten.")
        return 3
    # 5) letzte Kontrolle
    if not _syntax_ok(TARGET) or not _import_smoke(TARGET):
        log("Post-Check fehlgeschlagen – versuche Rollback.")
        return 4
    log("=== DONE IntakeRestoreSmart OK ===")
    return 0

if __name__ == "__main__":
    import sys
    sys.exit(main())
