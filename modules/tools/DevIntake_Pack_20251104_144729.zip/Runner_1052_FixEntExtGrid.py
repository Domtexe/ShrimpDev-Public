"""
Runner_1052_FixEntExtGrid
Behebt 'SyntaxError: unmatched )' in modules/module_code_intake.py
bei ent_ext.grid(...)) -> genau eine überzählige Klammer entfernen.
Version: v9.9.42
"""
from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1052] {ts} {msg}\n")
    except Exception:
        pass

def read_text(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def write_backup(p: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bck)
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {p} -> {bck}")

def patch() -> int:
    src = read_text(MOD)
    original = src

    # Ziel: Varianten mit doppelter Klammer am Ende korrigieren
    patterns = [
        r'(ent_ext\.grid\(row=0,\s*column=7,\s*sticky="w",\s*padx=\(4,12\)\)\))',   # exakt wie im Screenshot
        r'(ent_ext\.grid\([^)]*\)\))',  # generischer Fallback
    ]
    fixed = False
    for pat in patterns:
        src2 = re.sub(pat, lambda m: m.group(1)[:-1], src, count=1)
        if src2 != src:
            src = src2
            fixed = True
            break

    if not fixed:
        log("Keine fehlerhafte ent_ext.grid()-Zeile gefunden.")
        return 0

    write_backup(MOD, src)

    # Version bump + Changelog
    with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
        f.write("ShrimpDev v9.9.42\n")
    with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
        f.write("""
## v9.9.42 (2025-10-18)
- Fix: SyntaxError durch doppelte Klammer in ent_ext.grid() korrigiert.
""")
    log("Patch angewendet.")
    return 0

if __name__ == "__main__":
    raise SystemExit(patch())
