"""
Runner_1054_Intake_QuoteFix_ClearDelete_PasteReset
- Fix: entfernt falsche Backslashes in self._ping(\"Gelöscht.\") -> self._ping("Gelöscht.")
- Ergänzt (falls fehlend): Helper _prepare_new_intake() und _clear_editor_and_fields()
- Löschen: leert nach _load_table() Editor + Name + Endung
- Paste: setzt Name/Endung zurück und triggert sofortige Auto-Erkennung
Version: v9.9.44
"""
from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1054] {ts} {msg}\n")
    except Exception:
        pass

def rd(p): 
    with open(p, "r", encoding="utf-8") as f: 
        return f.read()

def wr_backup(p, data):
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bck)
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {p} -> {bck}")

def ensure_helpers(src: str) -> tuple[str, bool]:
    """Fügt _prepare_new_intake/_clear_editor_and_fields ein, falls nicht vorhanden."""
    changed = False
    if "_prepare_new_intake(" not in src or "_clear_editor_and_fields(" not in src:
        # nach _ping() einfügen (innerhalb der Klasse, 4-Spaces indent)
        m = re.search(r"\n\s*def\s+_ping\([^\)]*\):[\s\S]+?\n\s*pass\s*\n", src)
        if not m:
            # Fallback: nach class Kopf
            m = re.search(r"class\s+IntakeFrame\(ttk\.Frame\):[\s\S]+?\n", src)
        if m:
            insert_at = m.end()
            helpers = """
    def _prepare_new_intake(self):
        \"\"\"Name/Ext zurücksetzen und LEDs neutralisieren.\"\"\"
        self.var_name_manual = False
        self.var_ext_manual = False
        try:
            self.var_name.set("")
            self.var_ext.set("")
        except Exception:
            pass
        try:
            self._update_led(self.led_detect, "yellow")
            self._update_led(self.led_save, "yellow")
        except Exception:
            pass

    def _clear_editor_and_fields(self):
        \"\"\"Editor leeren + _prepare_new_intake.\"\"\"
        try:
            self.txt.delete("1.0","end")
        except Exception:
            pass
        self._prepare_new_intake()
"""
            src = src[:insert_at] + helpers + src[insert_at:]
            changed = True
    return src, changed

def fix_ping_quotes(src: str) -> tuple[str, bool]:
    """Entfernt Backslashes in self._ping(\"…\") Zeilen."""
    new_src, n = re.subn(r'self\._ping\(\\"([^"]*)\\"\)', r'self._ping("\1")', src)
    return new_src, (n > 0)

def patch_delete_handler(src: str) -> tuple[str, bool]:
    """Sorgt dafür, dass nach dem Löschen Editor+Felder geleert werden."""
    changed = False
    # Stelle im Delete-Handler: nach self._load_table() unseren Call einfügen, falls nicht vorhanden
    patt = re.compile(r"(def\s+_on_click_delete\([^\)]*\):[\s\S]+?self\._load_table\(\)\s*)(?![\s\S]{0,120}?_clear_editor_and_fields\()", re.MULTILINE)
    m = patt.search(src)
    if m:
        insert_pos = m.end(1)
        src = src[:insert_pos] + "\n        self._clear_editor_and_fields()\n" + src[insert_pos:]
        changed = True
    return src, changed

def patch_paste_handler(src: str) -> tuple[str, bool]:
    """Paste setzt Felder zurück und triggert Detect sofort."""
    changed = False
    patt = re.compile(r"def\s+_on_editor_paste\([^\)]*\):[\s\S]+?\n\s*def\s+", re.MULTILINE)
    m = patt.search(src)
    if m:
        body = """
    def _on_editor_paste(self, _evt=None):
        self._prepare_new_intake()
        self._schedule_detect(150)

"""
        src = src[:m.start()] + body + src[m.end()-len("def "):]  # den nächsten def nicht verlieren
        changed = True
    return src, changed

def run_patch():
    src = rd(MOD)
    changed_any = False

    src, ch = ensure_helpers(src);            changed_any |= ch
    src, ch = fix_ping_quotes(src);           changed_any |= ch
    src, ch = patch_delete_handler(src);      changed_any |= ch
    src, ch = patch_paste_handler(src);       changed_any |= ch

    if changed_any:
        wr_backup(MOD, src)
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.44\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.44 (2025-10-18)
- Fix: falsches Escaping in self._ping("Gelöscht.") entfernt.
- UX: [Löschen] leert Editor/Name/Endung; Paste setzt Name/Endung zurück und triggert Auto-Erkennung.
""")
        log("Patch angewendet.")
        return 0
    else:
        log("Keine Änderungen nötig.")
        return 0

if __name__ == "__main__":
    raise SystemExit(run_patch())
