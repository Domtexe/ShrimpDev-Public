#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Runner_1132_FixIntakeActions
- Toolbar-Fix: btn_guard auf 'bar' statt self.frm_actions
- Syntax-Fix: entfernt leeren zweiten try-Block im Toolbar-Bereich
- Absicherung: _on_click_guard() ergänzen, falls fehlend
- Backups + zentrales Logging (Append, robust)
"""
from __future__ import annotations
import os, re, time, tempfile

ROOT = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
MOD_PATH = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCHIV = os.path.join(ROOT, "_Archiv")
LOG = os.path.join(ROOT, "debug_output.txt")

def write_log(tag: str, msg: str) -> None:
    ts = time.strftime("%d.%m.%Y %H:%M:%S")
    line = f"[{tag}] {ts} {msg}\n"
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        # Fallback: temp
        try:
            tf = os.path.join(tempfile.gettempdir(), "shrimpdev_debug_output.txt")
            with open(tf, "a", encoding="utf-8") as f:
                f.write(line)
        except Exception:
            pass

def backup(src: str) -> str:
    os.makedirs(ARCHIV, exist_ok=True)
    ts = str(int(time.time()))
    dst = os.path.join(ARCHIV, f"{os.path.basename(src)}.{ts}.bak")
    with open(src, "r", encoding="utf-8") as f_in, open(dst, "w", encoding="utf-8", newline="\n") as f_out:
        f_out.write(f_in.read())
    write_log("R1132", f"Backup: {src} -> {dst}")
    return dst

def patch_toolbar_parent(s: str) -> tuple[str, bool]:
    """
    Ersetzt Button-Eltern für Guard:
      ttk.Button(self.frm_actions, ...) -> ttk.Button(bar, ...)
    """
    pattern = r'ttk\.Button\(\s*self\.frm_actions\s*,\s*text\s*=\s*"Prüfen\s*\(Guard\)"\s*,\s*command\s*=\s*self\._on_click_guard\s*\)'
    repl    = r'ttk.Button(bar, text="Prüfen (Guard)", command=self._on_click_guard)'
    s_new, n = re.subn(pattern, repl, s)
    return s_new, n > 0

def patch_toolbar_syntax(s: str) -> tuple[str, bool]:
    """
    Entfernt den leeren verschachtelten try-Block direkt nach den Button-Bindings.
    Wir suchen ein Muster der Form:
        \n<whitespace>try:\n<whitespace>pass\n<whitespace>except Exception:\n<whitespace>pass\n
    """
    # Nur im UI-Bereich arbeiten (schränkt False Positives ein)
    # Heuristik: wir suchen im Bereich um "self.btn_del.bind(...)" bis "body = ttk.Panedwindow"
    block_pat = re.compile(
        r'(self\.btn_del\.bind\(.*?\)\s*)'      # bis zur letzten Bind-Zeile
        r'(?:\n[ \t]*)try:\s*\n[ \t]*pass\s*\n[ \t]*except\s+Exception:\s*\n[ \t]*pass\s*\n', 
        re.DOTALL
    )
    def _fix(m):
        head = m.group(1)
        return head + "\n"  # nur die Bind-Zeile behalten
    s_new, n = block_pat.subn(_fix, s, count=1)
    return s_new, n > 0

def ensure_guard_method(s: str) -> tuple[str, bool]:
    """
    Fügt _on_click_guard hinzu, falls nicht vorhanden.
    Minimal: ping + log; nutzt vorhandene Hilfsfunktionen, falls verfügbar.
    """
    if re.search(r'\ndef\s+_on_click_guard\s*\(self(?:,.*)?\):', s):
        return s, False
    insert_after = re.search(r'\nclass\s+IntakeFrame\([^\)]*\):', s)
    if not insert_after:
        return s, False
    idx = insert_after.end()
    snippet = (
        "\n    def _on_click_guard(self, _evt=None):\n"
        "        \"\"\"Einfacher Guard-Handler (sanft, nicht blockierend).\"\"\"\n"
        "        try:\n"
        "            if hasattr(self, '_ping'):\n"
        "                self._ping('Guard…')\n"
        "        except Exception:\n"
        "            pass\n"
        "        try:\n"
        "            # Platzhalter: hier könnte ein Runner aufgerufen werden\n"
        "            # write_log('INTAKE', 'Guard clicked') falls Logger injiziert\n"
        "            pass\n"
        "        except Exception:\n"
        "            pass\n"
    )
    return s[:idx] + snippet + s[idx:], True

def main() -> int:
    write_log("R1132", "FixIntakeActions – Start")
    if not os.path.isfile(MOD_PATH):
        write_log("R1132", f"FEHLER: Datei nicht gefunden: {MOD_PATH}")
        print("[R1132] Datei nicht gefunden.")
        return 2
    backup(MOD_PATH)
    with open(MOD_PATH, "r", encoding="utf-8") as f:
        s = f.read()

    changed = False

    s2, ok1 = patch_toolbar_parent(s)
    if ok1:
        write_log("R1132", "Toolbar-Fix: btn_guard → parent 'bar'")
    s = s2; changed = changed or ok1

    s2, ok2 = patch_toolbar_syntax(s)
    if ok2:
        write_log("R1132", "Syntax-Fix: leerer try-Block im Toolbar-Bereich entfernt")
    s = s2; changed = changed or ok2

    s2, ok3 = ensure_guard_method(s)
    if ok3:
        write_log("R1132", "Absicherung: _on_click_guard ergänzt")
    s = s2; changed = changed or ok3

    if not changed:
        write_log("R1132", "Info: Keine relevanten Stellen gefunden – nichts geändert.")
        print("[R1132] Keine Änderungen nötig.")
        return 0

    with open(MOD_PATH, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)

    write_log("R1132", "Patch abgeschlossen.")
    print("[R1132] Patch abgeschlossen.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
