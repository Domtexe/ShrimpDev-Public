r"""
Runner_1137_IntakeLoadFix
Ziel: Intake-Tab wieder lauffähig machen (Toolbar/Bindings/Handler konsolidieren).

Vorgehen:
- Backup von modules/module_code_intake.py in _Archiv/<name>.<epoch>.bak
- Datei einlesen, idempotente Patches anwenden:
  * "frm_actions" -> "bar" bei Button-Erstellung/Gridding
  * Guard-Button sauber einfügen (ohne Klammerfehler)
  * doppelte try:...try:... -> try:... except: pass
  * fehlende Handler ergänzen (_on_click_guard, _open_selected, _path_of_item)
  * Toolbar-Buttons (detect/save/del) und Bindings an Wrapper hängen
- Syntaxprobe via compile(); bei Fehler: Rollback.

Logging zentral in debug_output.txt (mit Retry, wie gehabt).
"""
from __future__ import annotations

import os, re, time, io, sys, shutil, textwrap

ROOT = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
MODULE_PATH = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCHIV = os.path.join(ROOT, "_Archiv")
REPORT = os.path.join(ROOT, "_Reports", "Runner_1137_IntakeLoadFix_report.txt")
LOG_PATH = os.path.join(ROOT, "debug_output.txt")

def write_log(tag: str, msg: str) -> None:
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    line = f"[{tag}] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n"
    for i in range(5):
        try:
            with open(LOG_PATH, "a", encoding="utf-8") as f:
                f.write(line)
            return
        except PermissionError:
            time.sleep(0.05)

def _read(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def _write(p: str, s: str) -> None:
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)

def _backup(src: str) -> str:
    os.makedirs(ARCHIV, exist_ok=True)
    bak = os.path.join(ARCHIV, f"{os.path.basename(src)}.{int(time.time())}.bak")
    shutil.copy2(src, bak)
    return bak

def _ensure_guard_button(txt: str) -> tuple[str, list[str]]:
    """
    Sucht die Toolbar-Erzeugung (Frame 'bar') und stellt dort:
      - btn_detect, btn_save, btn_del
      - btn_guard auf 'bar' (nicht 'frm_actions')
      - saubere Grid/Bind-Klammern
    sicher. Gibt (gepatchter_text, notes).
    """
    notes = []
    # 1) Verwaiste Container "self.frm_actions" -> "bar" nur in Button-Kontext
    before = txt
    txt = re.sub(
        r"(ttk\.Button\()\s*self\.frm_actions(\s*,)",
        r"\1bar\2",
        txt
    )
    if txt != before:
        notes.append("frm_actions->bar ersetzt")

    # 2) Guard-Button einfügen oder korrigieren
    # Stelle: nach btn_save-Zeile auf Toolbar
    pat_toolbar = re.compile(
        r"(self\.btn_save[^\n]*\n(?:\s*#.*\n)*)", re.M)
    guard_block = (
        "        # Guard-Button\n"
        "        self.btn_guard = ttk.Button(bar, text=\"Prüfen (Guard)\", command=self._on_click_guard)\n"
        "        self.btn_guard.grid(row=0, column=99, padx=(4,0))\n"
    )
    if "self.btn_guard" not in txt:
        m = pat_toolbar.search(txt)
        if m:
            pos = m.end()
            txt = txt[:pos] + guard_block + txt[pos:]
            notes.append("Guard-Button eingefügt")
    else:
        # Korrigiere evtl. defekte Grid-Zeile (z.B. unmatched ')')
        txt = re.sub(
            r"(self\.btn_guard\.grid\()[^)]+\)",
            r"self.btn_guard.grid(row=0, column=99, padx=(4,0))",
            txt
        )

    # 3) Doppelte try: try: -> aufräumen
    txt_old = txt
    txt = re.sub(
        r"(\n\s*try:\s*\n(?:\s*[^\n]+\n)*?)\n\s*try:\s*\n\s*pass(\n\s*except\s+Exception:\s*\n\s*pass)",
        r"\1\2", txt, flags=re.M)
    if txt != txt_old:
        notes.append("try/try-Sequenz bereinigt")

    # 4) Wrapper-Bindings – sicherstellen, dass sie in einem try/except stehen
    if "_on_click_detect(" in txt and ".bind(\"<ButtonRelease-1>\"" in txt:
        pass  # schon vorhanden
    else:
        bind_insert = (
            "        try:\n"
            "            self.btn_detect.bind(\"<ButtonRelease-1>\", lambda e: self._on_click_detect())\n"
            "            self.btn_save.bind(\"<ButtonRelease-1>\",   lambda e: self._on_click_save())\n"
            "            self.btn_del.bind(\"<ButtonRelease-1>\",    lambda e: self._on_click_delete())\n"
            "        except Exception:\n"
            "            pass\n"
        )
        # Insert hinter lbl_ping.grid(...)
        txt = re.sub(r"(self\.lbl_ping\.grid[^\n]*\n)", r"\1" + bind_insert, txt)
        notes.append("Bindings für ButtonRelease ergänzt")
    return txt, notes

def _ensure_handlers(txt: str) -> tuple[str, list[str]]:
    """
    Fügt fehlende Handler minimal hinzu (wenn nicht vorhanden),
    ohne Logik umzuschreiben.
    """
    notes = []

    def add_method(name: str, body: str) -> None:
        nonlocal txt, notes
        if re.search(rf"\n\s*def\s+{name}\s*\(", txt) is None:
            txt += "\n" + textwrap.dedent(body) + "\n"
            notes.append(f"Handler {name} ergänzt")

    add_method("_path_of_item", r"""
        def _path_of_item(self, item_id=None):
            """ + '"""Pfad für gewählten Tree-Eintrag (rudimentär)"""' + r"""
            try:
                sel = item_id or (self.tbl.selection()[0] if hasattr(self, "tbl") and self.tbl.selection() else None)
                if not sel:
                    return None
                # Annahme: Pfad in values[0] oder text
                vals = self.tbl.item(sel, "values") if hasattr(self, "tbl") else ()
                if vals and vals[0]:
                    return str(vals[0])
                return str(self.tbl.item(sel, "text"))
            except Exception:
                return None
    """)

    add_method("_open_selected", r"""
        import subprocess, os
        def _open_selected(self, _evt=None):
            """ + '"""Gewählten Pfad im Explorer öffnen (best-effort)."""' + r"""
            p = self._path_of_item()
            if not p:
                return
            try:
                if os.path.isdir(p):
                    os.startfile(p)
                else:
                    subprocess.Popen(f'explorer /select,"{p}"', shell=True)
            except Exception:
                pass
    """)

    add_method("_on_click_guard", r"""
        import subprocess, os
        def _on_click_guard(self, _evt=None):
            """ + '"""Guard-Check per Runner (nicht blockierend)."""' + r"""
            try:
                bat = os.path.join(os.path.dirname(os.path.dirname(__file__)), "tools", "Runner_1129_IntakeLoadGuard.bat")
                py  = os.path.join(os.path.dirname(os.path.dirname(__file__)), "tools", "Runner_1129_IntakeLoadGuard.py")
                if os.path.exists(bat):
                    subprocess.Popen(f'"{bat}"', shell=True)
                elif os.path.exists(py):
                    subprocess.Popen(f'py -3 -u "{py}"', shell=True)
            except Exception:
                pass
    """)
    return txt, notes

def _compile_check(src: str) -> tuple[bool, str]:
    try:
        compile(src, "module_code_intake.py", "exec")
        return True, ""
    except SyntaxError as ex:
        return False, f"SyntaxError: {ex.msg} (line {ex.lineno}, col {ex.offset})"

def main() -> int:
    os.makedirs(os.path.dirname(REPORT), exist_ok=True)
    buf = io.StringIO()
    def logrep(s: str): buf.write(s + "\n")

    logrep("[R1137] IntakeLoadFix – Start")
    if not os.path.exists(MODULE_PATH):
        logrep(f"[ERR] Datei fehlt: {MODULE_PATH}")
        _write(REPORT, buf.getvalue())
        return 2

    backup = _backup(MODULE_PATH)
    logrep(f"[Backup] {MODULE_PATH} -> {backup}")

    src = _read(MODULE_PATH)
    if "class IntakeFrame" not in src:
        logrep("[ERR] class IntakeFrame nicht gefunden – Abbruch.")
        _write(REPORT, buf.getvalue())
        return 1

    changed = False
    notes_all = []

    # 1) Toolbar / Guard / Bindings
    src_new, notes = _ensure_guard_button(src)
    changed |= (src_new != src); src = src_new; notes_all += notes

    # 2) Handler sichern
    src_new, notes = _ensure_handlers(src)
    changed |= (src_new != src); src = src_new; notes_all += notes

    # 3) Syntaktische Unfälle um "unmatched ')'" minimieren (Banales wieder gerade ziehen)
    src = re.sub(r"self\.btn_guard\.grid\([^)]*$", "self.btn_guard.grid(row=0, column=99, padx=(4,0))", src, flags=re.M)

    ok, err = _compile_check(src)
    if not ok:
        logrep(f"[ERR] {err}")
        logrep("[INFO] Rollback auf Backup.")
        shutil.copy2(backup, MODULE_PATH)
        _write(REPORT, buf.getvalue())
        return 1

    if changed:
        _write(MODULE_PATH, src)
        logrep("[OK] Patch geschrieben.")
        for n in notes_all:
            logrep(f"[NOTE] {n}")
    else:
        logrep("[OK] Keine Änderungen nötig.")

    _write(REPORT, buf.getvalue())
    write_log("R1137", "IntakeLoadFix abgeschlossen")
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as ex:
        try:
            write_log("R1137", f"Crash: {ex}")
        finally:
            raise
