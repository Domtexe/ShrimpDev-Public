"""
Runner_1004_ShrimpDev_PathFix
- Keine Import-Checks mehr ohne sys.path; prüft per Dateiexistenz
- Erstellt/repair: modules/__init__.py, modules/snippets/__init__.py
- Stellt Snippets (logger_snippet.py, file_detect_snippet.py) sicher her
- Erzwingt sys.path-Safeguard + korrekten Fallback-Logger in main_gui.py
- Version -> v9.8.6
"""
from __future__ import annotations
import os, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1004] {ts} {msg}\n")
    print(msg, flush=True)

def safe_write(path: str, data: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        os.makedirs(ARCH, exist_ok=True)
        bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
        shutil.copy2(path, bck)
        log(f"Backup: {path} -> {bck}")
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

def ensure_file(path: str, content: str="") -> None:
    if not os.path.exists(path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="\r\n") as f:
            f.write(content)
        log(f"Created: {path}")

LOGGER_SNIPPET = r'''"""Zentraler Logger für ShrimpDev."""
from __future__ import annotations
import os, time
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
LOG_PATH = os.path.join(ROOT, "debug_output.txt")
def write_log(prefix: str, msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(f"[{prefix}] {ts} {msg}\n")
'''

FILE_DETECT_SNIPPET = r'''"""Robuste Dateiname/Endung-Erkennung."""
from __future__ import annotations
import os
from typing import Tuple
ALLOWED_EXTS = {".py", ".bat", ".cmd", ".json", ".txt", ".yml", ".yaml", ".ini", ".md", ".shcut"}
def split_name_ext(path: str) -> Tuple[str, str]:
    base = os.path.basename(path).strip()
    name, ext = os.path.splitext(base)
    return name, ext.lower()
def classify(path: str) -> str:
    _, ext = split_name_ext(path)
    if not ext: return "unknown"
    if ext in {".py"}: return "python"
    if ext in {".bat", ".cmd"}: return "batch"
    if ext in {".json", ".shcut"}: return "plan"
    if ext in {".ini"}: return "config"
    if ext in {".md", ".txt"}: return "doc"
    return "other"
def is_supported(path: str) -> bool:
    return split_name_ext(path)[1] in ALLOWED_EXTS
'''

FALLBACK_BLOCK = (
    "try:\n"
    "    from modules.snippets.logger_snippet import write_log\n"
    "except Exception:\n"
    "    def _fallback_write_log(prefix: str, msg: str) -> None:\n"
    "        import os, time\n"
    "        root = os.path.abspath(os.path.dirname(__file__))\n"
    "        logp = os.path.join(root, 'debug_output.txt')\n"
    "        ts = time.strftime('%Y-%m-%d %H:%M:%S')\n"
    "        try:\n"
    "            with open(logp, 'a', encoding='utf-8') as f:\n"
    "                f.write(f'[{prefix}] {ts} {msg}\\n')\n"
    "        except Exception:\n"
    "            pass\n"
    "    write_log = _fallback_write_log"
)

def patch() -> int:
    try:
        # 1) Packages sicherstellen
        ensure_file(os.path.join(ROOT, "modules", "__init__.py"))
        ensure_file(os.path.join(ROOT, "modules", "snippets", "__init__.py"))

        # 2) Snippets sicherstellen
        ensure_file(os.path.join(ROOT, "modules", "snippets", "logger_snippet.py"), LOGGER_SNIPPET)
        ensure_file(os.path.join(ROOT, "modules", "snippets", "file_detect_snippet.py"), FILE_DETECT_SNIPPET)

        # 3) main_gui.py: sys.path-Safeguard + Fallback-Logger erzwingen
        gpath = os.path.join(ROOT, "main_gui.py")
        with open(gpath, "r", encoding="utf-8") as f:
            gui = f.read()

        # sys.path Safeguard (falls fehlt)
        if "sys.path.insert(0, ROOT)" not in gui:
            gui = gui.replace(
                "import os, sys, traceback, tkinter as tk",
                "import os, sys, traceback, tkinter as tk\n"
                "ROOT = os.path.abspath(os.path.dirname(__file__))\n"
                "if ROOT not in sys.path:\n"
                "    sys.path.insert(0, ROOT)"
            )

        # Fallback-Logger sauber injizieren
        if "_fallback_write_log" not in gui:
            gui = gui.replace(
                "from modules.snippets.logger_snippet import write_log",
                FALLBACK_BLOCK
            )
        # Versionsbump
        gui = gui.replace("ShrimpDev – v9.8.5", "ShrimpDev – v9.8.6").replace(
              "ShrimpDev – v9.8.4", "ShrimpDev – v9.8.6").replace(
              "ShrimpDev – v9.8.3", "ShrimpDev – v9.8.6").replace(
              "ShrimpDev – v9.8.2", "ShrimpDev – v9.8.6").replace(
              "ShrimpDev – v9.8.1", "ShrimpDev – v9.8.6")
        safe_write(gpath, gui)

        # 4) Keine Import-Prüfung via importlib – stattdessen Dateichecks loggen
        checks = [
            os.path.join(ROOT, "modules", "snippets", "logger_snippet.py"),
            os.path.join(ROOT, "modules", "snippets", "file_detect_snippet.py"),
        ]
        for p in checks:
            log(f"Check {os.path.relpath(p, ROOT)}: {'OK' if os.path.exists(p) else 'FEHLT'}")

        # 5) Meta
        safe_write(os.path.join(ROOT, "CURRENT_VERSION.txt"), "ShrimpDev v9.8.6\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.8.6 (2025-10-18)
- FIX: Pfad/Import-Stabilität für ShrimpDev (keine importlib-Checks ohne sys.path)
- FIX: Snippets + __init__.py werden sicher angelegt
- FIX: Fallback-Logger korrekt und eingerückt injiziert
""")

        log("Patch erfolgreich.")
        return 0
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(patch())
