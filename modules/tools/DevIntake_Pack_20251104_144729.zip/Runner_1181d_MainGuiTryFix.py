# -*- coding: utf-8 -*-
"""
R1181d – Repariert den fehlerhaften Fallback-try-Block in _safe_add_intake_tab()
- Sucht ab Kommentar '# sichtbarer Fallback' bis 'return False' und ersetzt den Block.
- Legt Backup in _Archiv an.
- Syntax-Check (compile) vor Start.
"""
from __future__ import annotations
import os, re, time, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MAIN = os.path.join(ROOT, "main_gui.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

FIX_BLOCK = (
    "        # sichtbarer Fallback\n"
    "        try:\n"
    "            f = ttk.Frame(nb)\n"
    "            ttk.Label(\n"
    "                f,\n"
    "                text=\"Intake – Fehler beim Laden (Details im Log).\",\n"
    "                foreground=\"red\"\n"
    "            ).pack(padx=12, pady=12, anchor=\"w\")\n"
    "            nb.add(f, text=\"Intake\")\n"
    "            nb.select(nb.tabs()[-1])\n"
    "        except Exception:\n"
    "            pass\n"
    "        return False\n"
)

def log(msg: str) -> None:
    try:
        with open(LOG, "a", encoding="utf-8", newline="\n") as f:
            f.write(f"[R1181d] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    except Exception:
        pass
    print(f"[R1181d] {msg}")

def backup(path: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{stamp}.bak")
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        src = f.read()
    with open(dst, "w", encoding="utf-8") as f:
        f.write(src)
    log(f"Backup: {dst}")

def main() -> int:
    if not os.path.isfile(MAIN):
        log("main_gui.py nicht gefunden.")
        return 2

    with open(MAIN, "r", encoding="utf-8", errors="replace") as f:
        src = f.read()

    # Zielbereich: ab Kommentar bis einschließlich 'return False'
    pat = r"(        # sichtbarer Fallback[\s\S]*?return False\s*)"
    if not re.search(pat, src):
        log("Zielblock nicht gefunden – keine Änderung nötig.")
        # trotzdem Syntax prüfen
        compile(src, "main_gui.py", "exec")
        return 0

    new_src = re.sub(pat, FIX_BLOCK, src, count=1)

    if new_src != src:
        backup(MAIN)
        with open(MAIN, "w", encoding="utf-8", newline="\n") as f:
            f.write(new_src)
        log("Fallback-Block ersetzt.")
    else:
        log("Keine Änderung angewendet.")

    # Syntax-Check
    try:
        compile(new_src, "main_gui.py", "exec")
        log("SyntaxCheck OK.")
        return 0
    except SyntaxError as e:
        log(f"SyntaxError: line {e.lineno} col {e.offset} {e.msg}")
        return 3

if __name__ == "__main__":
    sys.exit(main())
