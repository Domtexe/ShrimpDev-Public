"""
Runner_1012_FixMenuIndent
- Behebt 'unexpected indent' in main_gui.py (falsche Einrückung bei m_file.add_separator()).
- Sichert Datei, normalisiert Menüblock, hebt Version auf v9.9.3.
"""
from __future__ import annotations
import os, re, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
GUI = os.path.join(ROOT, "main_gui.py")
LOG = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1012] {ts} {msg}\n")
    print(msg)

def backup(path: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    log(f"Backup: {path} -> {bck}")

def main() -> int:
    try:
        with open(GUI, "r", encoding="utf-8") as f:
            src = f.read()

        # 1) Versionstitel aktualisieren
        src = src.replace("ShrimpDev – v9.9.2", "ShrimpDev – v9.9.3")\
                 .replace("ShrimpDev – v9.9.1", "ShrimpDev – v9.9.3")

        # 2) Fehlerhafte Einrückungen bei m_file.add_separator() geradeziehen
        #    -> jede Zeile, die NUR aus whitespace + 'm_file.add_separator()' besteht, auf 4 spaces setzen
        fixed_lines = []
        changed = False
        for line in src.splitlines(keepends=False):
            if re.fullmatch(r"\s*m_file\.add_separator\(\)\s*", line):
                nl = "    m_file.add_separator()"
                if line != nl:
                    changed = True
                fixed_lines.append(nl)
            else:
                fixed_lines.append(line)
        new_src = "\n".join(fixed_lines) + ("\n" if not fixed_lines[-1].endswith("\n") else "")

        # 3) Sicherstellen, dass der File-Menüblock minimal und gültig ist
        #    (keine Speichern/Erkennen-Einträge mehr; nur Separator, Topmost, Separator, Beenden)
        new_src = new_src.replace(
            'm_file.add_command(label="Speichern (Ctrl+S)", command=tab_intake._save)\n', ''
        ).replace(
            'm_file.add_command(label="Erkennen (Ctrl+I)", command=tab_intake._detect)\n', ''
        )

        if new_src != src:
            backup(GUI)
            with open(GUI, "w", encoding="utf-8", newline="\r\n") as f:
                f.write(new_src)
            log("main_gui.py korrigiert (Indent + Menü).")
        else:
            log("main_gui.py unverändert (bereits korrekt).")

        # 4) Meta-Dateien
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.3\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.3 (2025-10-18)
- FIX: Unerwartete Einrückung im Menü (m_file.add_separator) behoben.
""")

        log("Patch erfolgreich.")
        return 0
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
