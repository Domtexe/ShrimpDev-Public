# -*- coding: utf-8 -*-
"""
Runner_1082_Guard_VerboseOK
- macht Runner_1063_Intake_SanityGuard.py gesprächig:
  - druckt "[GUARD] OK" bei Erfolg
  - druckt verständliche Fehlermeldungen bei Misserfolg
"""
from __future__ import annotations
import os, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
GUARD = os.path.join(ROOT, "tools", "Runner_1063_Intake_SanityGuard.py")

TEMPLATE = r'''# -*- coding: utf-8 -*-
from __future__ import annotations
import sys, os, ast

def _read_crlf(path: str) -> str:
    with open(path, "rb") as f:
        raw = f.read()
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("latin-1", errors="replace")

def _has_unclosed_triple_quotes(s: str) -> bool:
    c1 = s.count('"""')
    c2 = s.count("'''")
    return (c1 % 2 != 0) or (c2 % 2 != 0)

def check_file(path: str) -> bool:
    if not os.path.exists(path):
        print(f"[GUARD] Datei nicht gefunden: {path}")
        return False
    try:
        src = _read_crlf(path)
    except Exception as ex:
        print(f"[GUARD] Lesen fehlgeschlagen: {ex}")
        return False

    if _has_unclosed_triple_quotes(src):
        print("[GUARD] Unausgeglichenes Triple-Quote erkannt.")
        return False

    try:
        ast.parse(src)
    except SyntaxError as ex:
        print(f"[GUARD] SyntaxError: {ex.msg} (line {ex.lineno}, col {getattr(ex, 'offset', '?')})")
        return False
    except Exception as ex:
        print(f"[GUARD] Parser-Fehler: {ex}")
        return False

    print("[GUARD] OK")
    return True

def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if len(argv) >= 2 and argv[0] == "--check":
        path = argv[1]
        ok = check_file(path)
        return 0 if ok else 1
    print("Usage: py -3 tools\\Runner_1063_Intake_SanityGuard.py --check <file.py>")
    return 2

if __name__ == "__main__":
    raise SystemExit(main())
'''

def backup(p):
    os.makedirs(ARCH, exist_ok=True)
    if os.path.exists(p):
        bak = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
        shutil.copy2(p, bak)
        print(f"Backup: {p} -> {bak}")

def write_guard():
    txt = TEMPLATE.replace("\n", "\r\n")
    with open(GUARD, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(txt)
    print(f"Guard aktualisiert: {GUARD}")

if __name__ == "__main__":
    backup(GUARD)
    write_guard()
