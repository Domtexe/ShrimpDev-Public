# -*- coding: utf-8 -*-
import os, sys, time, shutil, py_compile, io

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
MODS = os.path.join(ROOT, 'modules')
TARGET = os.path.join(MODS, 'module_code_intake.py')
ARCH  = os.path.join(ROOT, '_Archiv')
os.makedirs(ARCH, exist_ok=True)

def log(msg): print(f"[1175q] {msg}")

BASIS_CODE = r'''# -*- coding: utf-8 -*-
"""
Stabile Basis von module_code_intake.py (1175q HardRestore)
- Minimal funktionsfähig, kompilierbar
- Keine externen Abhängigkeiten
- Stubs für Buttons/Events, damit nichts crasht
"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from typing import Optional

_PADX = (8,8)
_PADY = (6,6)

class IntakeFrame(ttk.Frame):
    def __init__(self, master: tk.Misc):
        super().__init__(master)
        self._build_ui()

    # ---------- UI ----------
    def _build_ui(self) -> None:
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

        # Toolbar
        bar = ttk.Frame(self)
        bar.grid(row=0, column=0, sticky="ew", padx=_PADX, pady=(8,4))
        for i in range(0, 4): bar.columnconfigure(i, weight=0)
        bar.columnconfigure(10, weight=1)

        self.btn_refresh = ttk.Button(bar, text="Aktualisieren", command=self._on_refresh)
        self.btn_save    = ttk.Button(bar, text="Speichern",     command=self._on_save)
        self.btn_guard   = ttk.Button(bar, text="Guard prüfen",  command=self._on_guard)
        self.btn_run     = ttk.Button(bar, text="Run (Smoke)",   command=self._on_run)

        self.btn_refresh.grid(row=0, column=0, padx=(0,6))
        self.btn_save.grid(   row=0, column=1, padx=(0,6))
        self.btn_guard.grid(  row=0, column=2, padx=(0,6))
        self.btn_run.grid(    row=0, column=3, padx=(0,6))

        # Body: Editor links, Liste rechts
        pw = ttk.Panedwindow(self, orient="horizontal")
        pw.grid(row=1, column=0, sticky="nsew", padx=_PADX, pady=_PADY)

        # Editor
        left = ttk.Frame(pw); left.rowconfigure(0,weight=1); left.columnconfigure(0,weight=1)
        self.txt = tk.Text(left, wrap="none", undo=True)
        y1 = ttk.Scrollbar(left, orient="vertical",   command=self.txt.yview)
        x1 = ttk.Scrollbar(left, orient="horizontal", command=self.txt.xview)
        self.txt.configure(yscrollcommand=y1.set, xscrollcommand=x1.set)
        self.txt.grid(row=0, column=0, sticky="nsew")
        y1.grid(row=0, column=1, sticky="ns")
        x1.grid(row=1, column=0, sticky="ew")
        pw.add(left, weight=3)

        # Liste
        right = ttk.Frame(pw); right.rowconfigure(0,weight=1); right.columnconfigure(0,weight=1)
        cols = ("name","ext","pfad")
        self.tbl = ttk.Treeview(right, columns=cols, show="headings", selectmode="browse")
        for c,w in (("name",280),("ext",80),("pfad",420)):
            self.tbl.heading(c, text=c); self.tbl.column(c, width=w, anchor="w", stretch=(c!="ext"))
        y2 = ttk.Scrollbar(right, orient="vertical", command=self.tbl.yview)
        self.tbl.configure(yscrollcommand=y2.set)
        self.tbl.grid(row=0, column=0, sticky="nsew")
        y2.grid(row=0, column=1, sticky="ns")
        pw.add(right, weight=2)

        # Status
        self.status = tk.StringVar(self, value="Bereit.")
        ttk.Label(self, textvariable=self.status, anchor="w").grid(row=2, column=0, sticky="ew", padx=_PADX, pady=(4,8))

    # ---------- Aktionen (stubs, sicher) ----------
    def _on_refresh(self) -> None:
        self.status.set("Aktualisiert.")
    def _on_save(self) -> None:
        self.status.set("Gespeichert (Stub).")
    def _on_guard(self) -> None:
        self.status.set("Guard OK (Stub).")
    def _on_run(self) -> None:
        self.status.set("Smoke ok (Stub).")

# API für main_gui
def get_tab(parent: tk.Misc) -> IntakeFrame:
    """Kompatible Fabrikfunktion, falls main_gui sie nutzt."""
    return IntakeFrame(parent)
'''

def smoke_compile(path: str) -> None:
    py_compile.compile(path, doraise=True)

def main() -> int:
    try:
        ts = time.strftime("%Y%m%d_%H%M%S")
        bak = os.path.join(ARCH, f"module_code_intake.py.{ts}.bak")
        if os.path.exists(TARGET):
            shutil.copy2(TARGET, bak)
            log(f"Backup erstellt: {bak}")
        else:
            log("Hinweis: Ziel-Datei existierte nicht – Neuaufbau.")

        # Schreibschutz entfernen falls nötig
        try:
            os.chmod(TARGET, 0o666)
        except Exception:
            pass

        with io.open(TARGET, "w", encoding="utf-8", newline="\n") as f:
            f.write(BASIS_CODE)
        log("Basis geschrieben.")

        smoke_compile(TARGET)
        log("Smoke-Compile OK.")
        return 0

    except Exception as e:
        log(f"FEHLER: {e!r}")
        # Versuche Rollback, wenn Backup existiert
        try:
            if 'bak' in locals() and os.path.exists(bak):
                shutil.copy2(bak, TARGET)
                log("Rollback aus Backup wiederhergestellt.")
        except Exception as e2:
            log(f"Rollback-Fehler: {e2!r}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
