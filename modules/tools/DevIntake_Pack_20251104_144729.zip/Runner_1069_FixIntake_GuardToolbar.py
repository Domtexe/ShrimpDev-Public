# -*- coding: utf-8 -*-
"""
Runner_1069_FixIntake_GuardToolbar
- Hängt den Guard-Button an die bestehende Toolbar 'bar' statt an 'self.frm_actions'
- Standardisiert das Grid des Guard-Buttons (row=0, column=99, padx=(4,0))
- Entfernt nutzlose Mini-try/except-Blöcke (try: pass / except Exception: pass)
- Ergänzt (falls fehlend) den Handler _on_click_guard() mit Aufruf des Sanity-Guards
- Sichert Backup und validiert via ast.parse()

Ausführen im Projekt-Root:
    py -3 tools\Runner_1069_FixIntake_GuardToolbar.py
"""
from __future__ import annotations
import os, re, time, shutil, ast

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1069] {ts} {msg}\n")
    except Exception:
        pass

def rd(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f: return f.read()

def wr_with_backup(p: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bak)
    log(f"Backup: {p} -> {bak}")
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

def normalize(src: str) -> str:
    src = src.replace("\r\n", "\n").replace("\r", "\n")
    src = "\n".join(ln.rstrip(" \t") for ln in src.split("\n"))
    src = src.replace("\t", "    ")
    if not src.endswith("\n"):
        src += "\n"
    return src

def ensure_guard_button_on_bar(src: str) -> tuple[str, int]:
    """Zwingt Guard-Button auf Toolbar 'bar' und setzt Grid-Standardierung."""
    changed = 0
    s = src

    # 1) Falls bereits Guard-Button existiert, 'self.frm_actions' -> 'bar'
    before = s
    s = re.sub(
        r'(self\s*\.\s*btn_guard\s*=\s*ttk\.Button\()\s*self\.frm_actions(\s*,)',
        r'\1bar\2',
        s
    )
    if s != before:
        changed += 1
        log("btn_guard: Ziel-Container auf 'bar' umgestellt.")

    # 2) Grid-Aufruf des Guard-Buttons vereinheitlichen
    before = s
    s = re.sub(
        r'self\s*\.\s*btn_guard\s*\.\s*grid\s*\([^)]*\)',
        r'self.btn_guard.grid(row=0, column=99, padx=(4,0))',
        s
    )
    if s != before:
        changed += 1
        log("btn_guard: Grid vereinheitlicht (row=0, column=99, padx=(4,0)).")

    # 3) Wenn gar kein Guard-Button existiert, hinter btn_del.grid(...) einfügen
    if "self.btn_guard" not in s:
        m = re.search(r'(^[ \t]*self\.btn_del\s*\.\s*grid\s*\([^)]*\)\s*$)', s, re.MULTILINE)
        if m:
            indent = re.match(r'[ \t]*', m.group(1)).group(0)
            inject = (
                f"{m.group(1)}\n"
                f"{indent}self.btn_guard = ttk.Button(bar, text=\"Prüfen (Guard)\", "
                f"command=self._on_click_guard)\n"
                f"{indent}self.btn_guard.grid(row=0, column=99, padx=(4,0))\n"
            )
            s = s[:m.start(1)] + inject + s[m.end(1):]
            changed += 1
            log("btn_guard: Neu hinter btn_del.grid(...) eingefügt.")
        else:
            log("WARN: btn_del.grid(...) nicht gefunden – kein Insert des Guard-Buttons möglich.")

    return s, changed

def strip_mini_try_blocks(src: str) -> tuple[str, int]:
    """
    Entfernt Mini-Blöcke:
        try:
            pass
        except Exception:
            pass
    """
    pattern = re.compile(
        r'^[ \t]*try:[ \t]*\r?\n[ \t]*pass[ \t]*\r?\n'
        r'[ \t]*except[ \t]+Exception[ \t]*:[ \t]*\r?\n[ \t]*pass[ \t]*\r?\n',
        re.MULTILINE
    )
    s, n = pattern.subn("", src)
    if n:
        log(f"Mini try/except-Blöcke entfernt: {n}")
    return s, n

def ensure_guard_handler(src: str) -> tuple[str, int]:
    """Erzeugt _on_click_guard(), falls nicht vorhanden (mit Guard-Aufruf)."""
    if re.search(r'^\s*def\s+_on_click_guard\s*\(', src, re.MULTILINE):
        return src, 0

    # Einfügepunkt: am Ende der IntakeFrame-Klasse oder vor nächster Klasse
    # Finde Beginn der IntakeFrame-Klasse und deren Einrückung
    mcls = re.search(r'^\s*class\s+IntakeFrame\s*\(\s*ttk\.Frame\s*\)\s*:\s*$', src, re.MULTILINE)
    if not mcls:
        log("WARN: IntakeFrame-Klasse nicht gefunden – Handler kann nicht eingefügt werden.")
        return src, 0

    cls_start = mcls.end()
    # Suche nächstes "class " nach cls_start als ungefährer Endpunkt
    mnext = re.search(r'^\s*class\s+[A-Za-z_]\w*\s*\(', src[cls_start:], re.MULTILINE)
    insert_pos = cls_start + (mnext.start() if mnext else len(src[cls_start:]))

    # Einrückung 4 Spaces
    code = (
        "\n"
        "    def _on_click_guard(self):\n"
        "        \"\"\"Guard-Analyse starten und Ergebnis im Ping-Label anzeigen.\"\"\"\n"
        "        try:\n"
        "            import os, sys, subprocess\n"
        "            root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))\n"
        "            runner = os.path.join(root, 'tools', 'Runner_1063_Intake_SanityGuard.py')\n"
        "            self._ping('Guard läuft…')\n"
        "            rc = subprocess.call([sys.executable, runner])\n"
        "            if rc == 0:\n"
        "                self._ping('Guard OK')\n"
        "            else:\n"
        "                self._ping(f'Guard meldet RC={rc}')\n"
        "        except Exception as ex:\n"
        "            try:\n"
        "                self._ping(f'Guard-Fehler: {ex}')\n"
        "            except Exception:\n"
        "                pass\n"
    )

    s = src[:insert_pos] + code + src[insert_pos:]
    log("Handler _on_click_guard() ergänzt.")
    return s, 1

def main() -> int:
    if not os.path.exists(MOD):
        log(f"Datei fehlt: {MOD}")
        return 2

    src0 = rd(MOD)
    src1 = normalize(src0)

    total_changes = 0

    src2, n = ensure_guard_button_on_bar(src1)
    total_changes += n

    src3, n = strip_mini_try_blocks(src2)
    total_changes += n

    src4, n = ensure_guard_handler(src3)
    total_changes += n

    # Syntax-Validierung
    try:
        ast.parse(src4)
    except SyntaxError as e:
        log(f"SyntaxError nach Patch: {e} (line {e.lineno}, col {e.offset})")
        # Dump-Ausschnitt
        lines = src4.splitlines()
        a, b = max(1, (e.lineno or 1) - 20), min(len(lines), (e.lineno or 1) + 20)
        log(f"--- DUMP {a}..{b} ---")
        for i in range(a, b+1):
            vis = lines[i-1].replace('\t', '→').replace(' ', '·')
            log(f"{i:04d}: {vis}")
        log("--- END DUMP ---")
        return 3

    if total_changes == 0 and src4 == src0:
        log("Keine Änderungen nötig.")
        return 0

    wr_with_backup(MOD, src4)
    log(f"Patch geschrieben. Änderungen: {total_changes}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
