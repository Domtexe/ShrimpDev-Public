# -*- coding: utf-8 -*-
"""
Runner_1177m_FixMainAndGate
- Vereinheitlicht Intake-Mount in main_gui.py via _safe_add_intake_tab(nb)
- Aktualisiert module_gate_panel.py auf mount_intake_tab(nb)
- Backups nach _Archiv, robustes Logging
"""
import io, os, re, sys, time, traceback
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
LOGF = os.path.join(ROOT, "debug_output.txt")

MAIN = os.path.join(ROOT, "main_gui.py")
GATE = os.path.join(ROOT, "modules", "module_gate_panel.py")

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(f"[R1177m] {ts} {msg}\n")
    except Exception:
        pass
    print(f"[R1177m] {msg}")

def backup(path):
    os.makedirs(ARCH, exist_ok=True)
    base = path.replace(ROOT+os.sep, "").replace(os.sep, "_")
    stamp = time.strftime("%Y%m%d_%H%M%S")
    dst = os.path.join(ARCH, f"{base}.{stamp}.bak")
    data = open(path, "r", encoding="utf-8", errors="replace").read()
    open(dst, "w", encoding="utf-8").write(data)
    log(f"Backup erstellt: {dst}")

def patch_main():
    if not os.path.isfile(MAIN):
        raise SystemExit("main_gui.py nicht gefunden.")
    src = open(MAIN, "r", encoding="utf-8", errors="replace").read()
    orig = src

    # 1) Import sicherstellen: from modules.module_shim_intake import mount_intake_tab
    if "from modules.module_shim_intake import mount_intake_tab" not in src:
        # ggf. alten Import ersetzen (_mount_*_shim)
        src = re.sub(
            r"from\s+modules\.module_shim_intake\s+import\s+[_a-zA-Z, ]+",
            "from modules.module_shim_intake import mount_intake_tab",
            src, count=1
        )
        if "from modules.module_shim_intake import mount_intake_tab" not in src:
            # falls kein Import vorhanden: nach den Top-Imports einfügen
            src = re.sub(
                r"(import\s+os,?\s*sys,?\s*traceback,?\s*tkinter\s+as\s+tk[\s\S]*?from\s+tkinter\s+import\s+ttk,?\s*messagebox)",
                r"\1\nfrom modules.module_shim_intake import mount_intake_tab",
                src, count=1
            )

    # 2) Zentrale Mount-Funktion _safe_add_intake_tab(nb) einfügen/ersetzen (idempotent)
    SAFE_BLOCK = r'''
def _safe_add_intake_tab(nb):
    """Hängt den Intake-Tab an das gegebene ttk.Notebook nb.
    - idempotent (wenn schon vorhanden -> select)
    - sauberes Fehler-Logging in debug_output.txt
    """
    try:
        from tkinter import ttk
        if not isinstance(nb, ttk.Notebook):
            try: write_log('GUI','IntakeMount: nb ist kein Notebook.')
            except Exception: pass
            return False
        # existiert bereits?
        try:
            for i, tid in enumerate(nb.tabs()):
                if nb.tab(tid, "text") == "Intake":
                    nb.select(i)
                    try: write_log('GUI','IntakeMount: Tab existiert -> select.')
                    except Exception: pass
                    return True
        except Exception:
            pass
        # Montage via Shim
        try:
            from modules.module_shim_intake import mount_intake_tab
            mount_intake_tab(nb)
            try: write_log('GUI','IntakeMount: Tab montiert.')
            except Exception: pass
            return True
        except Exception as e:
            try: write_log('GUI', f'IntakeMount: Montage-Fehler: {e}')
            except Exception: pass
            return False
    except Exception as e:
        try: write_log('GUI', f'IntakeMount: Unerwarteter Fehler: {e}')
        except Exception: pass
        return False
'''.lstrip("\n")

    # vorhandenen def _safe_add_intake_tab(...) ersetzen/ergänzen
    if re.search(r"\ndef\s+_safe_add_intake_tab\s*\(", src):
        src = re.sub(r"\ndef\s+_safe_add_intake_tab\s*\([\s\S]*?\n(?=def\s+|if\s+__name__|$)", "\n"+SAFE_BLOCK, src, count=1)
    else:
        # an sinnvolle Stelle einfügen (vor __start_guard oder am Ende)
        ins_pos = src.rfind("def __start_guard")
        if ins_pos == -1:
            src += "\n" + SAFE_BLOCK + "\n"
        else:
            src = src[:ins_pos] + "\n" + SAFE_BLOCK + "\n" + src[ins_pos:]

    # 3) Aufruf sicherstellen: _safe_add_intake_tab(nb) – genau einmal!
    src = re.sub(r"\n\s*_safe_add_intake_tab\s*\(\s*nb\s*\)\s*#?\s*[^\n]*", "", src)  # evtl. Altaufruf entfernen
    src = re.sub(
        r"(nb\s*=\s*ttk\.Notebook\(root\)[^\n]*\n)",
        r"\1    _safe_add_intake_tab(nb)\n",
        src, count=1
    )

    # 4) Offensichtliche Indent-Fehler aus alten Patches entschärfen:
    #    Stelle mit nb.add(tab_agent...) / nb.add(tab_proj...) korrekt einrücken.
    src = re.sub(r"\n(nb\.add\(tab_proj,[^\n]+\))", r"\n    \1", src)
    src = re.sub(r"\n(nb\.add\(tab_agent,[^\n]+\))", r"\n    \1", src)
    src = re.sub(r"\n(nb\.select\([^\n]+\))", r"\n    \1", src)

    if src != orig:
        backup(MAIN)
        open(MAIN, "w", encoding="utf-8").write(src)
        log("MainGuiFix applied.")
    else:
        log("MainGuiFix: keine Änderungen nötig.")

def patch_gate():
    if not os.path.isfile(GATE):
        log("module_gate_panel.py nicht gefunden – übersprungen.")
        return
    src = open(GATE, "r", encoding="utf-8", errors="replace").read()
    orig = src

    # 1) Import sicherstellen
    if "from modules.module_shim_intake import mount_intake_tab" not in src:
        if "module_shim_intake" in src:
            src = re.sub(
                r"from\s+modules\.module_shim_intake\s+import\s+[_a-zA-Z, ]+",
                "from modules.module_shim_intake import mount_intake_tab",
                src, count=1
            )
        else:
            src = "from modules.module_shim_intake import mount_intake_tab\n" + src

    # 2) Alte API-Namen auf die neue API mappen
    src = re.sub(r"\b_remount_intake_tab_shim\s*\(", "mount_intake_tab(", src)
    src = re.sub(r"\b_mount_intake_tab_shim\s*\(", "mount_intake_tab(", src)

    # 3) Optional: defensives Guarding – wenn Gate einen Button/Handler definiert,
    #    darf der Aufruf nicht crashen (wir fangen Exceptions und loggen).
    src = re.sub(
        r"mount_intake_tab\((.*?)\)",
        r"__gate_safe_mount(\1)",
        src
    )
    if "__gate_safe_mount(" not in src:
        src = (
            "def __gate_safe_mount(nb):\n"
            "    try:\n"
            "        return mount_intake_tab(nb)\n"
            "    except Exception as e:\n"
            "        try:\n"
            "            import traceback, os\n"
            "            with open(os.path.join(os.path.dirname(__file__), '..', 'debug_output.txt'), 'a', encoding='utf-8') as f:\n"
            "                f.write('[R1177m] Gate safe mount error: %s\\n' % e)\n"
            "                traceback.print_exc(file=f)\n"
            "        except Exception:\n"
            "            pass\n"
            "        return None\n"
        ) + "\n" + src

    if src != orig:
        backup(GATE)
        open(GATE, "w", encoding="utf-8").write(src)
        log("GatePanelUpdate applied.")
    else:
        log("GatePanelUpdate: keine Änderungen nötig.")

def main():
    try:
        patch_main()
        patch_gate()
    except Exception:
        buf = io.StringIO()
        traceback.print_exc(file=buf)
        log("Runner EXC:\n" + buf.getvalue())
        sys.exit(1)
    sys.exit(0)

if __name__ == "__main__":
    main()
