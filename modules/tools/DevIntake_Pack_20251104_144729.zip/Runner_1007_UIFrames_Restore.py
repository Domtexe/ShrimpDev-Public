"""
Runner_1007_UIFrames_Restore
- Stellt fehlende/defekte UI-Module wieder her:
  * modules/module_agent_ui.py -> AgentFrame
  * modules/module_project_ui.py -> ProjectFrame
- Hebt GUI-Titel auf v9.8.9 an
"""
from __future__ import annotations
import os, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1007] {ts} {msg}\n")
    print(msg, flush=True)

def safe_write(path: str, data: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        os.makedirs(ARCH, exist_ok=True)
        bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
        shutil.copy2(path, bck)
        log(f"Backup: {path} -> {bck}")
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

MODULE_AGENT_UI = r'''"""Agent UI-Monitor: zeigt _Reports/Agent/events.jsonl tail-sicher."""
from __future__ import annotations
import os, tkinter as tk
from tkinter import ttk

# Logger optional (harmloser Fallback)
try:
    from modules.snippets.logger_snippet import write_log as _log
except Exception:
    def _log(_p: str, _m: str) -> None:
        pass

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
EVENTS = os.path.join(ROOT, "_Reports", "Agent", "events.jsonl")

class AgentFrame(ttk.Frame):
    """Kleiner Monitor für Agent-Events (nur lesend)."""
    def __init__(self, master):
        super().__init__(master)
        self._build()
        self._refresh()

    def _build(self) -> None:
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        self.txt = tk.Text(self, height=12, state="disabled")
        self.txt.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        btns = ttk.Frame(self)
        btns.grid(row=1, column=0, sticky="w", padx=6, pady=6)
        ttk.Button(btns, text="Neu laden", command=self._refresh).pack(side="left")
        ttk.Button(btns, text="Alles löschen", command=self._clear_events).pack(side="left", padx=(6,0))

    def _refresh(self) -> None:
        data = ""
        if os.path.exists(EVENTS):
            try:
                with open(EVENTS, "r", encoding="utf-8", errors="ignore") as f:
                    lines = f.readlines()[-500:]
                    data = "".join(lines)
            except Exception as ex:
                data = f"[Fehler] {ex}"
        self.txt.config(state="normal")
        self.txt.delete("1.0", "end")
        self.txt.insert("end", data or "(keine Events)")
        self.txt.config(state="disabled")
        _log("AGENT", "Events aktualisiert")

    def _clear_events(self) -> None:
        try:
            os.makedirs(os.path.dirname(EVENTS), exist_ok=True)
            with open(EVENTS, "w", encoding="utf-8") as f:
                f.write("")
            _log("AGENT", "Events geleert")
            self._refresh()
        except Exception as ex:
            _log("AGENT", f"Clear-Fehler: {ex}")
'''

MODULE_PROJECT_UI = r'''"""Project-Tab: zeigt _Reports/Agent/project_map.json formatiert an."""
from __future__ import annotations
import os, json, tkinter as tk
from tkinter import ttk

try:
    from modules.snippets.logger_snippet import write_log as _log
except Exception:
    def _log(_p: str, _m: str) -> None:
        pass

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
PMAP = os.path.join(ROOT, "_Reports", "Agent", "project_map.json")

class ProjectFrame(ttk.Frame):
    """Lesende Anzeige der Projektkarte."""
    def __init__(self, master):
        super().__init__(master)
        self._build()
        self._refresh()

    def _build(self) -> None:
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        self.txt = tk.Text(self, height=12, state="disabled")
        self.txt.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        btns = ttk.Frame(self)
        btns.grid(row=1, column=0, sticky="w", padx=6, pady=6)
        ttk.Button(btns, text="Neu laden", command=self._refresh).pack(side="left")

    def _refresh(self) -> None:
        out = ""
        try:
            if os.path.exists(PMAP):
                with open(PMAP, "r", encoding="utf-8") as f:
                    data = json.load(f)
                out = json.dumps(data, ensure_ascii=False, indent=2)
            else:
                out = "(project_map.json fehlt)"
        except Exception as ex:
            out = f"[Fehler] {ex}"
        self.txt.config(state="normal")
        self.txt.delete("1.0", "end")
        self.txt.insert("end", out)
        self.txt.config(state="disabled")
        _log("PROJ", "project_map aktualisiert")
'''

def patch() -> int:
    try:
        # Module schreiben
        safe_write(os.path.join(ROOT, "modules", "module_agent_ui.py"), MODULE_AGENT_UI)
        safe_write(os.path.join(ROOT, "modules", "module_project_ui.py"), MODULE_PROJECT_UI)

        # GUI-Titel bumpen (nur Anzeige)
        gpath = os.path.join(ROOT, "main_gui.py")
        if os.path.exists(gpath):
            with open(gpath, "r", encoding="utf-8") as f:
                gui = f.read()
            gui = gui.replace("ShrimpDev – v9.8.8", "ShrimpDev – v9.8.9")\
                     .replace("ShrimpDev – v9.8.7", "ShrimpDev – v9.8.9")\
                     .replace("ShrimpDev – v9.8.6", "ShrimpDev – v9.8.9")
            safe_write(gpath, gui)

        # Meta
        safe_write(os.path.join(ROOT, "CURRENT_VERSION.txt"), "ShrimpDev v9.8.9\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.8.9 (2025-10-18)
- FIX: module_agent_ui.py (AgentFrame) und module_project_ui.py (ProjectFrame) sauber wiederhergestellt
- GUI: Versionstitel aktualisiert
""")

        log("UI-Frames wiederhergestellt.")
        return 0
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(patch())
