# -*- coding: utf-8 -*-
"""
Runner_1167d_GUIMountRefresher
Fügt nach nb.select(0) einen sicheren Render-Refresher ein:
    root.after(250, root.update_idletasks)
    root.after(400, lambda: nb.select(0))
Mit Backup, Syntax-Check und Rollback. Idempotent.
Exitcodes:
 0 = OK, Patch vorhanden (neu oder bereits vorhanden)
 1 = Fehler (Details in debug_output.txt)
"""
from __future__ import annotations
import os, re, time, py_compile, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "main_gui.py")
ARCH  = os.path.join(ROOT, "_Archiv")
LOG   = os.path.join(ROOT, "debug_output.txt")

PATCH_MARK = "# R1167d: initial render refresher"
PATCH_SNIPPET = (
    "    " + PATCH_MARK + "\n"
    "    try:\n"
    "        root.after(250, root.update_idletasks)\n"
    "        root.after(400, lambda: nb.select(0))\n"
    "    except Exception:\n"
    "        pass\n"
)

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1167d {ts}] {msg}\n"
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    ts = int(time.time())
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    with open(path, "r", encoding="utf-8") as fsrc, open(dst, "w", encoding="utf-8", newline="") as fdst:
        fdst.write(fsrc.read())
    return dst

def main() -> int:
    try:
        if not os.path.exists(TARGET):
            log(f"Zieldatei fehlt: {TARGET}")
            return 1

        with open(TARGET, "r", encoding="utf-8") as f:
            src = f.read()

        # idempotent?
        if PATCH_MARK in src:
            log("Patch bereits vorhanden – keine Änderung notwendig.")
            return 0

        # Füge nach 'nb.select(0)' ein (erste passende Stelle)
        # Wir suchen die Zeile mit nb.select(0) und hängen den Block direkt danach an.
        pattern = r"(^[ \t]*nb\.select\(\s*0\s*\)[ \t]*\r?\n)"
        m = re.search(pattern, src, flags=re.MULTILINE)
        if not m:
            log("Konnte 'nb.select(0)' nicht finden – Abbruch ohne Änderung.")
            return 1

        insert_pos = m.end()
        new_src = src[:insert_pos] + PATCH_SNIPPET + src[insert_pos:]

        # Backup, schreiben, Syntax-Test
        bak = backup(TARGET)
        log(f"Backup erstellt: {bak}")

        with open(TARGET, "w", encoding="utf-8", newline="") as f:
            f.write(new_src)

        try:
            py_compile.compile(TARGET, doraise=True)
        except Exception as e:
            # Rollback
            with open(bak, "r", encoding="utf-8") as fb, open(TARGET, "w", encoding="utf-8", newline="") as fw:
                fw.write(fb.read())
            log("Syntax-Check FEHLER -> Rollback auf Backup.")
            log("Traceback:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 1

        log("Patch erfolgreich eingefügt und Syntax-Check OK.")
        return 0

    except Exception as e:
        log("UNERWARTETER FEHLER:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
