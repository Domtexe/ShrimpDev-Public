# -*- coding: utf-8 -*-
"""
R1171q_IntakeCleanAndExternalize
- Iterativer Repair-Runner für module_code_intake.py:
  * Top-Level-Indent-Fixer (dedent)
  * "nackte" try:-Blöcke heilen (except anhängen)
  * Toolbar-Helper externalisieren + Lifecycle-Import/Call injizieren
- Backup, Syntax-Check, Rollback
"""
from __future__ import annotations
import os, re, time, shutil, traceback, py_compile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TARGET = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"; ARCH.mkdir(exist_ok=True, parents=True)
SNIP_DIR = ROOT / "modules" / "snippets"; SNIP_DIR.mkdir(exist_ok=True, parents=True)
SNIP_INIT = SNIP_DIR / "__init__.py"
SNIP_HELP = SNIP_DIR / "intake_toolbar_reflow_helper.py"
LOG = ROOT / "debug_output.txt"
MARK_LIFE = "# R1170e: lifecycle wire"

HELPER_CODE = r'''# -*- coding: utf-8 -*-
"""
Helper: intake_toolbar_reflow_helper (robust, idempotent)
Aktuell defensiv (no-op), kann später gezielt befüllt werden.
"""
from typing import Any
def intake_toolbar_reflow(self: Any) -> None:
    try:
        return
    except Exception:
        return
'''

IMPORT_LINE = 'from modules.snippets.intake_toolbar_reflow_helper import intake_toolbar_reflow as _sd_toolbar_reflow'
CALL_BLOCK_TEMPLATE = (
    '{IND}try:\n'
    '{IND}    _sd_toolbar_reflow(self)\n'
    '{IND}except Exception:\n'
    '{IND}    pass\n'
)

TOP_BAD_PREFIX = re.compile(r'^(?P<indent>[ \t]+)(?P<head>(try:|except\b|finally:|def\b|class\b|from\b|import\b))', re.M)

def log(msg: str):
    line = f"[1171q {time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n"
    print(line, end="")
    try:
        with LOG.open("a", encoding="utf-8") as f: f.write(line)
    except Exception:
        pass

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time())}.bak"
    shutil.copy2(p, dst); return dst

def syntax_ok(p: Path) -> bool:
    try:
        py_compile.compile(str(p), doraise=True); return True
    except Exception as e:
        log("Syntax-Check FEHLER:\n" + "".join(traceback.format_exception_only(type(e), e)))
        return False

def read(p: Path) -> str: return p.read_text(encoding="utf-8")
def write(p: Path, s: str) -> None: p.write_text(s, encoding="utf-8", newline="\n")

def dedent_toplevel_candidates(src: str) -> str:
    lines = src.splitlines(True); out = []
    for i, line in enumerate(lines):
        m = TOP_BAD_PREFIX.match(line)
        if not m: out.append(line); continue
        # vorangehende relevante Zeile suchen
        j = i - 1; prev = ""
        while j >= 0:
            prev = lines[j].rstrip("\r\n")
            if prev.strip() != "": break
            j -= 1
        ps = prev.strip()
        # nur dedenten, wenn NICHT in einem offenen Block / Fortsetzung
        cont = (ps.endswith(':') or ps.endswith('\\') or ps.endswith(',') or ps.endswith('(') or ps.endswith('[') or ps.endswith('{'))
        if not cont:
            out.append(line[len(m.group('indent')):])
        else:
            out.append(line)
    return "".join(out)

def heal_naked_try(src: str) -> str:
    lines = src.splitlines(True); out = []
    for i, ln in enumerate(lines):
        if re.match(r'^\s*try:\s*$', ln):
            nxt = lines[i+1].lstrip() if i+1 < len(lines) else ""
            if not (nxt.startswith("except") or nxt.startswith("finally")):
                ind = ln[:len(ln)-len(ln.lstrip())]
                out.extend([ln, f"{ind}    pass\n", f"{ind}except Exception:\n{ind}    pass\n"])
                log(f"try: ohne except/finally in Zeile {i+1} ergänzt.")
                continue
        out.append(ln)
    return "".join(out)

def ensure_snippets():
    if not SNIP_INIT.exists(): write(SNIP_INIT, "# pkg\n")
    write(SNIP_HELP, HELPER_CODE)

def externalize_and_wire(src: str) -> str:
    """Injiziert Import-Zeile und Call am Ende von _build_ui(self) (idempotent)."""
    if IMPORT_LINE not in src:
        # nach erstem import-block einsortieren, sonst oben einfügen
        m = re.search(r'(?m)^(?:from\s+\S+\s+import\s+.*|import\s+.*)\s*$', src)
        insert_at = m.end() if m else 0
        src = src[:insert_at] + ("" if insert_at == 0 else "\n") + IMPORT_LINE + "\n" + src[insert_at:]

    # _build_ui finden
    m = re.search(r'(?m)^(\s*)def\s+_build_ui\s*\(\s*self\b[^\)]*\)\s*:', src)
    if not m: return src
    func_indent = m.group(1)
    start = m.end()
    # Ende des Funktionsblocks finden
    lines = src[start:].splitlines(True)
    body_indent = None; pos = start
    for ln in lines:
        if body_indent is None:
            m2 = re.match(r'(\s*)\S', ln)
            if not m2: pos += len(ln); continue
            body_indent = m2.group(1)
        # Ende wenn Einrückung < body_indent und nicht leer
        if ln.strip() and not ln.startswith(body_indent):
            break
        pos += len(ln)
    end = pos
    if "_sd_toolbar_reflow(self)" in src[start:end]:
        return src
    call = CALL_BLOCK_TEMPLATE.replace("{IND}", body_indent)
    return src[:end] + call + src[end:]

def main():
    if not TARGET.exists():
        log(f"Zieldatei fehlt: {TARGET}"); return 2

    bak = backup(TARGET); log(f"Backup: {bak.name}")
    ensure_snippets(); log("Externer Helper bereitgestellt.")

    # Iterativ reparieren, max. 5 Durchläufe
    for attempt in range(1, 6):
        src = read(TARGET)
        before = src

        # 1) vorhandene Fehler entschärfen
        src = dedent_toplevel_candidates(src)
        src = heal_naked_try(src)

        # 2) Externalize + Wire
        src = externalize_and_wire(src)

        changed = (src != before)
        if changed:
            write(TARGET, src)
        if syntax_ok(TARGET):
            log(f"Durchlauf {attempt}: Syntax OK.")
            return 0
        else:
            log(f"Durchlauf {attempt}: Syntax noch fehlerhaft – versuche erneut...")

    # hart gescheitert -> Rollback
    shutil.copy2(bak, TARGET)
    log("Rollback auf Backup nach 5 fehlgeschlagenen Versuchen.")
    return 1

if __name__ == "__main__":
    raise SystemExit(main())
