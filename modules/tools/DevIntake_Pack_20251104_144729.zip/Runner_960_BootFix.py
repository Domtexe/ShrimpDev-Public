from __future__ import annotations
import sys, subprocess, time, shutil, py_compile, re
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
MAIN = ROOT / "main_gui.py"
TOOLS = ROOT / "tools"
LOGF  = ROOT / "debug_output.txt"

def ts(): return time.strftime("%Y%m%d_%H%M%S")
def backup(p: Path):
    if p.exists():
        b = p.with_suffix(p.suffix + f".%s.bak" % ts())
        shutil.copy2(p, b); print(f"[R960] Backup: {b.name}")

GOOD_LOG = (
    "import sys, time\n"
    "from pathlib import Path\n"
    "ROOT = Path(r'D:\\ShrimpDev')\n"
    "LOGFILE = ROOT / 'debug_output.txt'\n"
    "def log(msg: str):\n"
    "    ts = time.strftime('%Y-%m-%d %H:%M:%S')\n"
    "    line = f'[{ts}] {msg}\\n'\n"
    "    try:\n"
    "        with LOGFILE.open('a', encoding='utf-8', errors='ignore') as f:\n"
    "            f.write(line)\n"
    "    except Exception:\n"
    "        pass\n"
    "    try:\n"
    "        print(line, end='')\n"
    "    except Exception:\n"
    "        pass\n"
)

GOOD_MAIN = (
    'if __name__ == "__main__":\n'
    '    import traceback\n'
    '    from tkinter import messagebox as _mb\n'
    '    try:\n'
    '        log("[BOOT] launching")\n'
    '        app = ShrimpDevApp()\n'
    '        log("[MAIN] GUI ready")\n'
    '        app.mainloop()\n'
    '    except Exception as ex:\n'
    '        tb = traceback.format_exc()\n'
    '        try:\n'
    '            log(f"[FATAL] {ex}\\n{tb}")\n'
    '        finally:\n'
    '            try: _mb.showerror("ShrimpDev", f"Fataler Fehler:\\n{ex}\\n\\n{tb}")\n'
    '            except Exception: pass\n'
)

def ensure_log_function(txt: str) -> tuple[str,bool]:
    if "def log(" in txt:
        return txt, False
    # Nach der future-Importzeile einfügen
    m = re.search(r'(?m)^from __future__ import annotations\s*$', txt)
    if not m:
        # Falls kein future-Import, setze log am Dateianfang
        return GOOD_LOG + "\n" + txt, True
    i = m.end()
    new = txt[:i] + "\n" + GOOD_LOG + txt[i:]
    return new, True

def replace_main_block(txt: str) -> tuple[str,bool]:
    # find __main__ start
    pat = re.compile(r'(?m)^\s*if __name__\s*==\s*[\'"]__main__[\'"]\s*:\s*$')
    m = pat.search(txt)
    if not m:
        # nicht vorhanden → anhängen
        if not txt.endswith("\n"): txt += "\n"
        return txt + "\n" + GOOD_MAIN + "\n", True
    start = m.start()
    # Ersetze ab Start bis Dateiende durch GOOD_MAIN
    return txt[:start] + GOOD_MAIN + ("\n" if not txt.endswith("\n") else ""), True

def write_starters():
    TOOLS.mkdir(parents=True, exist_ok=True)
    (TOOLS/"start_visible.bat").write_text(
        '@echo off\n'
        'cd /d "D:\\ShrimpDev"\n'
        'set PY=py -3\n'
        'echo [START] ShrimpDev visible (%date% %time%)>> debug_output.txt\n'
        '%PY% -u main_gui.py 1>> debug_output.txt 2>>&1\n',
        encoding="utf-8"
    )
    (TOOLS/"start_debug.bat").write_text(
        '@echo off\n'
        'cd /d "D:\\ShrimpDev"\n'
        'set PY=py -3\n'
        'echo [START] ShrimpDev DEBUG (%date% %time%)>> debug_output.txt\n'
        '%PY% -u main_gui.py 1>> debug_output.txt 2>>&1\n'
        'echo [ENDE] RC=%errorlevel%>> debug_output.txt\n'
        'pause\n',
        encoding="utf-8"
    )
    print("[R960] Starter aktualisiert (start_visible.bat / start_debug.bat)")

def compile_check() -> tuple[bool,str]:
    try:
        py_compile.compile(str(MAIN), doraise=True)
        return True, ""
    except Exception as ex:
        return False, str(ex)

def import_check() -> tuple[bool,str]:
    # Import ohne __main__ auszuführen (runpy mit geändertem name)
    code = (
        "import runpy; "
        "d = runpy.run_path(r'D:\\ShrimpDev\\main_gui.py', run_name='__not_main__'); "
        "print('IMPORTED_OK' if 'ShrimpDevApp' in d else 'NO_APP')"
    )
    try:
        r = subprocess.run(["py","-3","-c",code], capture_output=True, text=True, cwd=str(ROOT), timeout=20)
        out = (r.stdout or "") + (r.stderr or "")
        return r.returncode == 0, out.strip()
    except Exception as ex:
        return False, str(ex)

def main() -> int:
    if not MAIN.exists():
        print("[R960] FEHLT: main_gui.py"); return 2
    backup(MAIN)
    txt = MAIN.read_text(encoding="utf-8", errors="ignore")

    changed = False
    txt, c1 = ensure_log_function(txt); changed |= c1
    txt, c2 = replace_main_block(txt); changed |= c2

    if changed:
        MAIN.write_text(txt, encoding="utf-8")
        print("[R960] main_gui.py repariert (__main__/log).")
    else:
        print("[R960] Keine inhaltlichen Änderungen nötig.")

    ok, err = compile_check()
    if not ok:
        print(f"[R960] FEHLER: compile: {err}")
        return 1

    write_starters()

    ok2, out = import_check()
    print(f"[R960] Import-Check: {'OK' if ok2 else 'FAIL'} :: {out}")

    # Hinweis zum Start
    print("[R960] Starte jetzt mit: tools\\start_debug.bat (zeigt Logs + hält offen).")
    return 0 if ok2 else 1

if __name__ == "__main__":
    sys.exit(main())
