# -*- coding: utf-8 -*-
r"""
Runner_1118_SafeTkHandler
- Installiert einen sicheren Tkinter-Exception-Callback in main_gui.py
- Fixt die \R-SyntaxWarning in modules/module_runner_exec.py (Raw-Docstring)
- Backups in _Archiv/
- Schreibt Ergebnis nach _Reports/Runner_1118_SafeTkHandler_report.txt
"""

from __future__ import annotations
import os, re, time, io, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
REPO = os.path.join(ROOT, "_Reports")
os.makedirs(ARCH, exist_ok=True)
os.makedirs(REPO, exist_ok=True)

REPORT = os.path.join(REPO, "Runner_1118_SafeTkHandler_report.txt")

def write_report(msg: str) -> None:
    with open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip() + "\n")

def ts() -> str:
    return time.strftime("%Y%m%d_%H%M%S")

def backup(path: str) -> str:
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, dst)
    write_report(f"[Backup] {path} -> {dst}")
    return dst

def patch_module_runner_exec() -> None:
    p = os.path.join(ROOT, "modules", "module_runner_exec.py")
    if not os.path.exists(p):
        write_report("[runner_exec] Datei fehlt – übersprungen.")
        return
    with open(p, "r", encoding="utf-8") as f:
        src = f.read()

    # Ersten Docstring auf Raw umstellen, um \R o.ä. zu neutralisieren
    new_src = re.sub(
        r'^\s*"""(.*?)"""',
        lambda m: 'r"""' + m.group(1) + '"""',
        src,
        count=1,
        flags=re.DOTALL
    )

    if new_src != src:
        backup(p)
        with open(p, "w", encoding="utf-8", newline="\n") as f:
            f.write(new_src)
        write_report("[runner_exec] Docstring auf Raw umgestellt (SyntaxWarning entfernt).")
    else:
        write_report("[runner_exec] Keine Docstring-Änderung nötig.")

def make_safe_handler_snippet() -> str:
    return (
        "\n"
        "# === 1118 Safe Tk Handler (auto) ===\n"
        "def _install_safe_tk_handler(root):\n"
        "    \"\"\"Ersetzt Tkinter-Exception-Callback durch nicht-reentranten Logger.\n"
        "    Kein messagebox-Aufruf, kein Zugriff auf fremde Logger.\n"
        "    \"\"\"\n"
        "    import traceback, os, time\n"
        "    log_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'debug_output.txt')\n"
        "    def _safe_write(text: str):\n"
        "        try:\n"
        "            with open(log_path, 'a', encoding='utf-8') as f:\n"
        "                f.write(text)\n"
        "        except Exception:\n"
        "            pass\n"
        "    def _report(exc, val, tb):\n"
        "        try:\n"
        "            ts = time.strftime('%Y-%m-%d %H:%M:%S')\n"
        "            lines = ''.join(traceback.format_exception(exc, val, tb))\n"
        "            _safe_write(f\"[TK-EXC] {ts}\\n\" + lines + \"\\n\")\n"
        "        except Exception:\n"
        "            pass\n"
        "    try:\n"
        "        root.report_callback_exception = _report\n"
        "    except Exception:\n"
        "        pass\n"
        "# === /1118 ===\n"
    )

def inject_safe_handler_into_main() -> None:
    p = os.path.join(ROOT, "main_gui.py")
    if not os.path.exists(p):
        write_report("[main_gui] Datei fehlt – Abbruch.")
        return
    with open(p, "r", encoding="utf-8") as f:
        src = f.read()

    injected = False

    # 1) Snippet nur einmal einfügen
    if "def _install_safe_tk_handler(root):" not in src:
        m = re.search(r"(?:^from\s[^\n]+\n|^import\s[^\n]+\n)+", src, flags=re.MULTILINE)
        insert_at = m.end() if m else 0
        src = src[:insert_at] + make_safe_handler_snippet() + src[insert_at:]
        injected = True
        write_report("[main_gui] Safe-Handler-Snippet eingefügt.")

    # 2) Aufruf nach tk.Tk()-Erzeugung sicherstellen
    if re.search(r"_install_safe_tk_handler\s*\(", src) is None:
        mm = re.search(r"(\broot\s*=\s*tk\.Tk\s*\(\s*\))", src)
        if not mm:
            mm = re.search(r"(tk\.Tk\s*\(\s*\))", src)
            if mm:
                # ohne Zuweisung: root Variable erzeugen
                call = "\nroot = " + mm.group(1) + "\n_install_safe_tk_handler(root)\n"
                src = src[:mm.end()] + call + src[mm.end():]
                injected = True
                write_report("[main_gui] Aufruf + root-Erstellung gesetzt.")
        else:
            call = "\n_install_safe_tk_handler(root)\n"
            src = src[:mm.end()] + call + src[mm.end():]
            injected = True
            write_report("[main_gui] Aufruf _install_safe_tk_handler(root) gesetzt.")

    if injected:
        backup(p)
        with open(p, "w", encoding="utf-8", newline="\n") as f:
            f.write(src)
        write_report("[main_gui] Patch geschrieben.")
    else:
        write_report("[main_gui] Patch nicht nötig (bereits vorhanden).")

def main():
    with open(REPORT, "w", encoding="utf-8", newline="\n") as f:
        f.write("Runner_1118_SafeTkHandler – Start\n")
    try:
        patch_module_runner_exec()
        inject_safe_handler_into_main()
        write_report("OK – Runner abgeschlossen.")
    except Exception as ex:
        write_report("FEHLER: " + repr(ex))

if __name__ == "__main__":
    main()
