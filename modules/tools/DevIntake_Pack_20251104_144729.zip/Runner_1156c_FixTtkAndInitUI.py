# -*- coding: utf-8 -*-
"""
Runner_1156c_FixTtkAndInitUI
- Setzt robusten globalen ttk-Import-Guard (ttk ist immer definiert).
- Stellt __init__(..., ctx=None), build_ui(), on_run() idempotent sicher.
- Backup, Syntax-Check, Import+Instanziierung (Smoke), Rollback bei Fehlern.
"""
from __future__ import annotations
import io, sys, time, shutil, re, ast, importlib.util, types, py_compile
from pathlib import Path

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1156c_FixTtkAndInitUI_report.txt"

def log(s=""):
    print(s)
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(s.rstrip()+"\n")

def backup(p: Path) -> Path:
    dst = ARCH / (p.name + "." + str(int(time.time()*1000)) + ".bak")
    shutil.copy2(p, dst); return dst

def import_smoke()->tuple[bool,str]:
    if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
    # Notfall-Stub für runner_exec
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules"); sys.modules.setdefault("modules", pkg)
        mod = types.ModuleType("modules.module_runner_exec")
        mod.run = lambda *a, **k: 0
        mod._log = lambda *a, **k: None
        sys.modules["modules.module_runner_exec"] = mod

    try:
        spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
        m = importlib.util.module_from_spec(spec); assert spec and spec.loader
        spec.loader.exec_module(m)  # type: ignore[attr-defined]
        # Instanziierungstest
        import tkinter as tk
        root = tk.Tk(); root.withdraw()
        try:
            cls = getattr(m, "IntakeFrame", None)
            if not isinstance(cls, type):
                return False, "IntakeFrame-Klasse fehlt"
            _ = cls(root, None)  # ctx optional
        finally:
            root.destroy()
        return True, "Import & Instanziierung OK"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"

def ensure_global_ttk_guard(src:str)->tuple[str,bool]:
    """
    Sorgt dafür, dass oben im Modul ein sicherer ttk-Import existiert.
    Falls bereits ein globaler ttk-Import vorhanden ist, keine Änderung.
    """
    if re.search(r'(?m)^\s*import\s+tkinter\.ttk\s+as\s+ttk\b', src):
        return src, False
    guard = (
        "# R1156c: globaler ttk-Import-Guard (immer definiert)\n"
        "try:\n"
        "    import tkinter as tk  # noqa: F401\n"
        "    import tkinter.ttk as ttk  # noqa: F401\n"
        "except Exception:\n"
        "    ttk = None  # type: ignore\n"
        "\n"
    )
    # hinter Shebang/Coding und vor sonstigen Imports einfügen
    lines = src.splitlines(True)
    insert_at = 0
    # überspringe shebang/coding comments
    for i, l in enumerate(lines[:5]):
        if l.startswith("#!") or "coding" in l:
            insert_at = i+1
        else:
            break
    lines.insert(insert_at, guard)
    return "".join(lines), True

def find_class_span(lines:list[str], class_name:str="IntakeFrame")->tuple[int,int]:
    start=None
    for i,l in enumerate(lines):
        if re.match(rf'^\s*class\s+{class_name}\b', l):
            start=i; break
    if start is None: raise RuntimeError("class IntakeFrame nicht gefunden")
    for j in range(start+1,len(lines)):
        if re.match(r'^\S', lines[j]) and not lines[j].lstrip().startswith("#"):
            return start, j
    return start, len(lines)

def patch_init_signature(src:str)->tuple[str,bool]:
    tree = ast.parse(src)
    cls = next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name=="IntakeFrame"), None)
    if not cls: raise RuntimeError("IntakeFrame nicht gefunden")
    fn  = next((b for b in cls.body if isinstance(b, ast.FunctionDef) and b.name=="__init__"), None)
    if not fn:
        return src, False
    argnames = [a.arg for a in fn.args.args]  # inkl. self
    if "ctx" in argnames:
        return src, False
    lines = src.splitlines(True)
    s = fn.lineno-1
    header = lines[s]
    new_header = re.sub(
        r'^\s*def\s+__init__\s*\(\s*self\s*,\s*([^)]+)\)\s*:',
        lambda m: f"    def __init__(self, {m.group(1).strip()}, ctx=None):",
        header
    )
    if new_header == header:
        new_header = re.sub(r'\)\s*:\s*$', ', ctx=None):', header)
    lines[s] = new_header
    return "".join(lines), True

def ensure_method(src:str, name:str, body_lines:list[str])->tuple[str,bool]:
    tree = ast.parse(src)
    cls = next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name=="IntakeFrame"), None)
    if not cls: raise RuntimeError("IntakeFrame nicht gefunden")
    if any(isinstance(b, ast.FunctionDef) and b.name==name for b in cls.body):
        return src, False
    lines = src.splitlines(True)
    s,e = find_class_span(lines, "IntakeFrame")
    indent = "    "
    method_src = indent + f"def {name}(self):\n" + "".join(indent*2 + l for l in body_lines)
    if not lines[e-1].endswith("\n"):
        lines[e-1] = lines[e-1] + "\n"
    lines[e-1:e-1] = [method_src]
    return "".join(lines), True

def main()->int:
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass
    log("[R1156c] Start FixTtkAndInitUI")

    if not MODFILE.exists():
        log("[ERR] modules/module_code_intake.py fehlt."); return 1

    bak = backup(MODFILE); log(f"[Backup] {bak.name}")
    src0 = io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

    # 1) globaler ttk-Guard
    src1, added_guard = ensure_global_ttk_guard(src0)
    if added_guard:
        log("[Write] Globalen ttk-Import-Guard ergänzt.")

    # 2) __init__(..., ctx=None)
    try:
        src2, changed_init = patch_init_signature(src1)
        if changed_init:
            log("[Write] __init__ auf (.., ctx=None) erweitert.")
    except Exception as ex:
        log(f"[ERR] __init__-Analyse/Rewrite: {ex}"); return 1

    # 3) build_ui() (nur falls fehlt) – ohne lokales 'ttk', nutzt globalen Guard
    build_ui_body = [
        "# Minimaler UI-Aufbau (nur falls build_ui fehlte).\n",
        "if getattr(self, 'toolbar', None) is None and ttk is not None:\n",
        "    try:\n",
        "        self.toolbar = ttk.Frame(self)\n",
        "        self.toolbar.grid(row=0, column=0, sticky='ew')\n",
        "    except Exception:\n",
        "        pass\n",
    ]
    try:
        src3, added_build = ensure_method(src2, "build_ui", build_ui_body)
        if added_build:
            log("[Write] build_ui() hinzugefügt (Gerüst ohne lokales ttk).")
    except Exception as ex:
        log(f"[ERR] build_ui()-Insert: {ex}"); return 1

    # 4) on_run() (nur falls fehlt)
    on_run_body = [
        "try:\n",
        "    self._ping('Run invoked') if hasattr(self, '_ping') else None\n",
        "except Exception:\n",
        "    pass\n",
    ]
    try:
        src4, added_run = ensure_method(src3, "on_run", on_run_body)
        if added_run:
            log("[Write] on_run() hinzugefügt (Stub).")
    except Exception as ex:
        log(f"[ERR] on_run()-Insert: {ex}"); return 1

    # Schreiben nur, wenn sich was änderte
    if any([added_guard, changed_init, added_build, added_run]):
        io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(src4)
    else:
        log("[Info] Keine Änderungen erforderlich.")

    # Syntax-Check
    try:
        py_compile.compile(MODFILE, doraise=True)
        log("[Syntax] OK")
    except Exception as e:
        log(f"[Syntax] Fehler: {e} -> Rollback")
        shutil.copy2(bak, MODFILE)
        return 1

    # Import+Instanziierung
    ok, msg = import_smoke()
    if not ok:
        log(f"[Live] Import-Fehler: {msg} -> Rollback")
        shutil.copy2(bak, MODFILE)
        return 1
    log(f"[Live] {msg}")

    log(f"[SUM] added_guard={added_guard}, changed_init={changed_init}, added_build_ui={added_build}, added_on_run={added_run}")
    log("[R1156c] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
