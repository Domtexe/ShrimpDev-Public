# -*- coding: utf-8 -*-
"""
Runner_1158c_UX_ToolbarLayoutFix
- Verschiebt 'Editor leeren' ganz nach links (column=0) innerhalb der Toolbar (bar).
- Schiebt die Kernaktionen rechts davon: Erkennen, Speichern, Löschen (0/1/2 -> 1/2/3).
- Belässt Guard/Repair/Run/Aktualisieren/Pack in ihren hohen Spalten (99ff/100ff etc.).
- Safety: Backup, Syntax-Check, Logging nach debug_output.txt
"""
from __future__ import annotations
import os, re, io, time, shutil, py_compile, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOGF = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    line  = f"[R1158c] {stamp} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    ts = str(int(time.time()))
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    shutil.copy2(path, dst)
    log(f"Backup: {path} -> {dst}")
    return dst

# --- Helfer für column=... in grid() -----------------------------------------

RE_GRID = re.compile(r"""\.grid\(\s*([^\)]*)\)""")
RE_COL  = re.compile(r"""\bcolumn\s*=\s*(\d+)""")

def _set_column_args(args: str, col: int) -> str:
    if RE_COL.search(args):
        return RE_COL.sub(lambda m: f"column={col}", args, count=1)
    if args.strip():
        return args.strip() + f", column={col}"
    return f"column={col}"

def _replace_grid_column(line: str, new_col: int) -> tuple[str, bool]:
    """Ersetzt in einer Zeile den column=... der ersten grid()-Klammer."""
    m = RE_GRID.search(line)
    if not m:
        return line, False
    old_args = m.group(1)
    new_args = _set_column_args(old_args, new_col)
    if new_args == old_args:
        return line, False
    return line[:m.start(1)] + new_args + line[m.end(1):], True

def _bump_grid_column_if(line: str, expect_col: int, delta: int) -> tuple[str, bool]:
    """Erhöht column um delta, aber nur wenn aktuell expect_col steht."""
    m = RE_GRID.search(line)
    if not m:
        return line, False
    args = m.group(1)
    mcol = RE_COL.search(args)
    if mcol and int(mcol.group(1)) == expect_col:
        new_args = RE_COL.sub(lambda _m: f"column={expect_col + delta}", args, count=1)
        return line[:m.start(1)] + new_args + line[m.end(1):], True
    return line, False

# --- Patch-Logik --------------------------------------------------------------

BTN_LINES = {
    "btn_clear_editor": 0,   # Ziel: column 0
    # die folgenden werden nach rechts verschoben
    "btn_detect": 1,         # 0->1
    "btn_save":   2,         # 1->2
    "btn_del":    3,         # 2->3
}

def patch_toolbar_columns(src: str) -> tuple[str, list[str]]:
    changes: list[str] = []
    lines = src.splitlines(True)

    # 1) Editor leeren nach column=0
    edits = 0
    for i, ln in enumerate(lines):
        if "btn_clear_editor.grid" in ln:
            newln, ch = _replace_grid_column(ln, new_col=0)
            if ch:
                lines[i] = newln
                edits += 1
                changes.append("Set btn_clear_editor column=0")

    # 2) Kernaktionen nach rechts verschieben (0->1, 1->2, 2->3)
    bumped = 0
    for key, expect_col in (("btn_detect", 0), ("btn_save", 1), ("btn_del", 2)):
        for i, ln in enumerate(lines):
            if f"{key}.grid" in ln:
                newln, ch = _bump_grid_column_if(ln, expect_col=expect_col, delta=1)
                if ch:
                    lines[i] = newln
                    bumped += 1
                    changes.append(f"Bumped {key} from {expect_col} to {expect_col+1}")

    if edits == 0 and bumped == 0:
        changes.append("No matching grid() lines changed (already in desired layout or labels/names differ)")

    return "".join(lines), changes

# --- main ----------------------------------------------------------------------

def main() -> int:
    try:
        if not os.path.isfile(MOD):
            log(f"[ERR] Not found: {MOD}")
            return 2

        with io.open(MOD, "r", encoding="utf-8") as f:
            src = f.read()

        bak = backup(MOD)

        new_src, changes = patch_toolbar_columns(src)

        # Schreiben nur bei Änderungen
        if any("Set" in c or "Bumped" in c for c in changes):
            with io.open(MOD, "w", encoding="utf-8", newline="\n") as f:
                f.write(new_src)
            for c in changes:
                log(f"Change: {c}")
        else:
            for c in changes:
                log(f"Info: {c}")

        # Syntax-Check
        try:
            py_compile.compile(MOD, doraise=True)
            log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}")
            shutil.copy2(bak, MOD)
            log("Restored from backup due to syntax error.")
            return 3

        log("R1158c completed successfully.")
        return 0

    except Exception as e:
        tb = traceback.format_exc()
        log(f"[EXC] {e}\n{tb}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
