# -*- coding: utf-8 -*-
"""
Runner_1144_ReplaceIntakeSafe
- ersetzt modules/module_code_intake.py durch eine stabile Version
- Backup + Syntax-Check + Rollback bei Fehler
"""
from __future__ import annotations
import os, io, time, shutil, py_compile, sys
from pathlib import Path

ROOT   = Path(__file__).resolve().parents[1]
TARGET = ROOT / "modules" / "module_code_intake.py"
ARCH   = ROOT / "_Archiv"
ARCH.mkdir(exist_ok=True)

def backup(p: Path) -> Path:
    ts = str(int(time.time()*1000))
    dst = ARCH / f"{p.name}.{ts}.bak"
    shutil.copy2(p, dst)
    print(f"[R1144] Backup -> {dst}")
    return dst

FIXED = r'''# -*- coding: utf-8 -*-
from __future__ import annotations

import os, re, json, time, sys
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from modules import module_runner_exec

_PADX = 8
_PADY = 6

# ---------------- Tooltip ----------------
class Tooltip:
    def __init__(self, widget, text: str):
        self.widget = widget
        self.text   = text
        self.tip    = None
        widget.bind("<Enter>", self._show)
        widget.bind("<Leave>", self._hide)

    def _show(self, _=None):
        if self.tip or not self.text:
            return
        x = self.widget.winfo_rootx() + 10
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 4
        self.tip = tk.Toplevel(self.widget)
        self.tip.wm_overrideredirect(True)
        self.tip.wm_geometry("+%d+%d" % (x, y))
        ttk.Label(self.tip, text=self.text, relief="solid", borderwidth=1, padding=(6,3)).pack()

    def _hide(self, _=None):
        if self.tip:
            self.tip.destroy()
            self.tip = None

def _open_explorer_select(path: str) -> None:
    try:
        if os.path.exists(path):
            os.system(f'explorer /select,"{path}"')
        else:
            os.system(f'explorer "{os.path.dirname(path) or "."}"')
    except Exception:
        pass

# ---------------- IntakeFrame ----------------
class IntakeFrame(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.var_name_manual = False
        self.var_ext_manual  = False
        self._build_ui()
        self._bind_shortcuts()
        self.after(250, self._auto_detect_if_needed)

    # ---------- UI ----------
    def _build_ui(self):
        self.columnconfigure(0, weight=1)
        self.rowconfigure(3, weight=1)

        head = ttk.Frame(self)
        head.grid(row=0, column=0, sticky="ew", padx=_PADX, pady=(_PADY,4))
        for c in (1,3,9):
            head.columnconfigure(c, weight=1)
        head.columnconfigure(4, weight=3)

        ttk.Label(head, text="Workspace:").grid(row=0, column=0, sticky="w")
        self.var_ws = tk.StringVar(value=os.getcwd())
        ent_ws = ttk.Entry(head, textvariable=self.var_ws)
        ent_ws.grid(row=0, column=1, sticky="ew", padx=(4,4))
        ttk.Button(head, text="...", width=3, command=self._pick_ws).grid(row=0, column=2, padx=(0,12))
        Tooltip(ent_ws, "Arbeitsverzeichnis")

        ttk.Label(head, text="Name:").grid(row=0, column=3, sticky="w")
        self.var_name = tk.StringVar(value="")
        ent_name = ttk.Entry(head, textvariable=self.var_name)
        ent_name.grid(row=0, column=4, sticky="ew", padx=(4,4))
        ent_name.bind("<KeyRelease>", self._on_name_edited)
        ttk.Button(head, text="Einfügen", width=8, command=self._paste_name).grid(row=0, column=5, padx=(0,12))
        Tooltip(ent_name, "Dateiname (ohne Pfad)")

        ttk.Label(head, text="Endung:").grid(row=0, column=6, sticky="w")
        self.var_ext = tk.StringVar(value=".py")
        ent_ext = ttk.Entry(head, textvariable=self.var_ext, width=6)
        ent_ext.grid(row=0, column=7, sticky="w", padx=(4,12))
        ent_ext.bind("<KeyRelease>", self._on_ext_changed)
        ent_ext.bind("<FocusOut>", self._normalize_ext)
        Tooltip(ent_ext, "Endung (.py/.bat/...)")

        ttk.Label(head, text="Zielordner:").grid(row=0, column=8, sticky="w")
        self.var_target = tk.StringVar(value=os.path.join(os.getcwd(), "tools"))
        ent_tgt = ttk.Entry(head, textvariable=self.var_target)
        ent_tgt.grid(row=0, column=9, sticky="ew", padx=(4,4))
        ttk.Button(head, text="...", width=3, command=self._pick_target).grid(row=0, column=10)
        Tooltip(ent_tgt, "Ablagepfad")
        cm_tgt = tk.Menu(self, tearoff=0)
        cm_tgt.add_command(label="Öffnen im Explorer", command=lambda:_open_explorer_select(self.var_target.get()))
        cm_tgt.add_command(label="Pfad kopieren",       command=lambda:self._copy_text(self.var_target.get()))
        ent_tgt.bind("<Button-3>", lambda e:self._popup_menu(cm_tgt,e))

        # Status-LEDs
        leds = ttk.Frame(self)
        leds.grid(row=1, column=0, sticky="ew", padx=_PADX, pady=(0,4))
        self.led_target = tk.Canvas(leds, width=14, height=14, highlightthickness=0); self.led_target.grid(row=0,column=0,padx=(0,4))
        ttk.Label(leds, text="Ziel").grid(row=0,column=1,padx=(0,16))
        self.led_detect = tk.Canvas(leds, width=14, height=14, highlightthickness=0); self.led_detect.grid(row=0,column=2,padx=(0,4))
        ttk.Label(leds, text="Erkennung").grid(row=0,column=3,padx=(0,16))
        self.led_save   = tk.Canvas(leds, width=14, height=14, highlightthickness=0); self.led_save.grid(row=0,column=4,padx=(0,4))
        ttk.Label(leds, text="Speichern").grid(row=0,column=5)

        # Toolbar (ein Container: 'bar')
        bar = ttk.Frame(self)
        bar.grid(row=2, column=0, sticky="ew", padx=_PADX, pady=(0,4))
        bar.columnconfigure(3, weight=1)

        self.btn_detect = ttk.Button(bar, text="Erkennen (Ctrl+I)", command=self._on_click_detect)
        self.btn_save   = ttk.Button(bar, text="Speichern (Ctrl+S)", command=self._on_click_save)
        self.btn_del    = ttk.Button(bar, text="Löschen (Entf)",    command=self._on_click_delete)
        self.btn_guard  = ttk.Button(bar, text="Prüfen (Guard)",     command=self._on_click_guard)
        self.btn_repair = ttk.Button(bar, text="Repair",             command=self._on_click_repair_safe)
        self.btn_run    = ttk.Button(bar, text="Run (F5)",           command=self._on_click_run)

        self.btn_detect.grid(row=0, column=0, padx=(0,6), sticky="w")
        self.btn_save.grid(  row=0, column=1, padx=(0,6), sticky="w")
        self.btn_del.grid(   row=0, column=2, padx=(0,0), sticky="w")
        self.btn_guard.grid( row=0, column=99, padx=(6,0), sticky="w")
        self.btn_repair.grid(row=0, column=100, padx=(6,0), sticky="w")
        self.btn_run.grid(   row=0, column=101, padx=(6,0), sticky="w")

        self.lbl_ping = ttk.Label(bar, text="", anchor="w")
        self.lbl_ping.grid(row=0, column=3, sticky="ew", padx=(12,0))

        # Body
        body = ttk.Panedwindow(self, orient="horizontal")
        body.grid(row=3, column=0, sticky="nsew", padx=_PADX, pady=(0,_PADY))

        left = ttk.Frame(body); left.rowconfigure(0, weight=1); left.columnconfigure(0, weight=1)
        self.txt = tk.Text(left, wrap="none", undo=True, font=("Consolas", 10))
        self._detect_job = None
        self.txt.bind("<<Paste>>", self._on_editor_paste)
        self.txt.bind("<F5>", lambda _e: self.btn_run.invoke())
        self.txt.bind("<Control-v>", self._on_editor_paste)
        self.txt.bind("<<Modified>>", self._on_editor_modified)
        self.txt.bind("<KeyRelease>", self._on_editor_key)
        y1 = ttk.Scrollbar(left, orient="vertical",   command=self.txt.yview)
        x1 = ttk.Scrollbar(left, orient="horizontal", command=self.txt.xview)
        self.txt.configure(yscrollcommand=y1.set, xscrollcommand=x1.set)
        self.txt.grid(row=0,column=0,sticky="nsew"); y1.grid(row=0,column=1,sticky="ns"); x1.grid(row=1,column=0,sticky="ew")
        self.menu_editor = tk.Menu(self, tearoff=0)
        self.menu_editor.add_command(label="Kopieren", command=lambda:self.txt.event_generate("<<Copy>>"))
        self.menu_editor.add_command(label="Einfügen", command=lambda:self.txt.event_generate("<<Paste>>"))
        self.txt.bind("<Button-3>", lambda e:self._popup_menu(self.menu_editor,e))
        body.add(left, weight=3)

        right = ttk.Frame(body); right.rowconfigure(0,weight=1); right.columnconfigure(0,weight=1)
        cols = ("name","ext","subfolder","date","time")
        self.tbl = ttk.Treeview(right, columns=cols, show="headings", selectmode="browse")
        for c,w,a in (("name",240,"w"),("ext",70,"center"),("subfolder",180,"w"),("date",110,"center"),("time",90,"center")):
            self.tbl.heading(c, text=c)
            self.tbl.column(c, anchor=a, width=w, stretch=(c!="ext"))
        y2 = ttk.Scrollbar(right, orient="vertical",   command=self.tbl.yview)
        x2 = ttk.Scrollbar(right, orient="horizontal", command=self.tbl.xview)
        self.tbl.configure(yscrollcommand=y2.set, xscrollcommand=x2.set)
        self.tbl.grid(row=0,column=0,sticky="nsew"); y2.grid(row=0,column=1,sticky="ns"); x2.grid(row=1,column=0,sticky="ew")
        self.menu_tbl = tk.Menu(self, tearoff=0)
        self.menu_tbl.add_command(label="Name kopieren",       command=self._copy_name_selected)
        self.menu_tbl.add_command(label="Pfad kopieren",       command=self._copy_selected)
        self.menu_tbl.add_command(label="Öffnen im Explorer",  command=self._open_selected)
        self.menu_tbl.add_separator()
        self.menu_tbl.add_command(label="Löschen",             command=self._on_click_delete)
        self.tbl.bind("<Button-3>", lambda e:self._popup_menu(self.menu_tbl,e))
        self.tbl.bind("<Double-Button-1>", self._dbl_open)
        body.add(right, weight=2)

        self._update_led(self.led_target, "green" if os.path.isdir(self.var_target.get()) else "red")
        self._update_led(self.led_detect, "yellow")

    # ---------- helpers ----------
    def _bind_shortcuts(self):
        root = self.winfo_toplevel()
        try:
            root.unbind_all("<Control-s>")
            root.unbind_all("<Control-i>")
        except Exception:
            pass
        root.bind_all("<Control-s>", lambda e:self._on_click_save())
        root.bind_all("<Control-i>", lambda e:self._on_click_detect())
        self.tbl.bind("<Control-c>", lambda e:self._copy_selected())
        self.tbl.bind("<Delete>",    lambda e:self._on_click_delete())

    def _popup_menu(self, menu, evt):
        try:
            row = self.tbl.identify_row(evt.y) if menu is self.menu_tbl else None
            if row: self.tbl.selection_set(row)
            menu.tk_popup(evt.x_root, evt.y_root)
        finally:
            try: menu.grab_release()
            except Exception: pass

    def _update_led(self, canvas, color):
        canvas.delete("all")
        canvas.create_oval(2,2,12,12, fill=color, outline="")

    def _ping(self, text: str):
        try:    self.lbl_ping.configure(text=text)
        except Exception: pass

    def _prepare_new_intake(self):
        self.var_name_manual = False
        self.var_ext_manual  = False
        try:
            self.var_name.set(""); self.var_ext.set(".py")
        except Exception: pass
        self._update_led(self.led_detect, "yellow")
        self._update_led(self.led_save,   "yellow")

    def _clear_editor_and_fields(self):
        try: self.txt.delete("1.0","end")
        except Exception: pass
        self._prepare_new_intake()

    def _copy_text(self, text: str):
        try:
            self.clipboard_clear(); self.clipboard_append(text)
        except Exception: pass

    # ---------- pickers ----------
    def _paste_name(self):
        try:    val = (self.clipboard_get() or "").strip()
        except Exception: val = ""
        if val:
            self.var_name.set(val); self._on_name_edited()

    def _pick_ws(self):
        d = filedialog.askdirectory(title="Workspace wählen", initialdir=self.var_ws.get() or os.getcwd())
        if d: self.var_ws.set(d)

    def _pick_target(self):
        d = filedialog.askdirectory(title="Zielordner wählen", initialdir=self.var_target.get() or os.getcwd())
        if d:
            self.var_target.set(d)
            self._update_led(self.led_target, "green" if os.path.isdir(d) else "red")

    # ---------- editor events ----------
    def _on_ext_changed(self, _evt=None):
        self.var_ext_manual = True

    def _normalize_ext(self, _evt=None):
        ext = (self.var_ext.get() or "").strip().lower()
        if ext and not ext.startswith("."):
            ext = "." + ext
        self.var_ext.set(ext or ".py")

    def _on_name_edited(self, _evt=None):
        self.var_name_manual = True
        self._update_led(self.led_detect, "yellow")

    # ---------- detection ----------
    def _guess_name_from_text(self, text: str) -> tuple[str,str]:
        t = text or ""
        m = re.search(r"(?i)tools[\\/](Runner_[0-9]{3,5}[_A-Za-z0-9\\-]+)\\.(py|bat|cmd)", t)
        if m: return m.group(1), "."+m.group(2).lower()
        m = re.search(r"(?i)\\b(Runner_[0-9]{3,5}[_A-Za-z0-9\\-]+)\\.(py|bat|cmd)\\b", t)
        if m: return m.group(1), "."+m.group(2).lower()
        m = re.search(r"(?i)\\bpy(?:\\s+-3)?\\s+tools[\\/](Runner_[^ \\r\\n\\t]+)\\.(py)\\b", t)
        if m: return m.group(1), ".py"
        m = re.search(r"(?i)\\bcall\\s+tools[\\/](Runner_[^ \\r\\n\\t]+)\\.(bat|cmd)\\b", t)
        if m: return m.group(1), "."+m.group(2).lower()
        m = re.search(r"(?im)^[;#:\\- ]+\\s*name\\s*[:=]\\s*(Runner_[0-9]{3,5}[_A-Za-z0-9\\-]+)(?:\\.(py|bat|cmd))?\\s*$", t)
        if m: return m.group(1), ("."+m.group(2).lower()) if m.group(2) else ""
        m = re.search(r"(?i)\\b(Runner_[0-9]{3,5}[_A-Za-z0-9\\-]+)\\b", t)
        if m: return m.group(1), ""
        return "", ""

    def _guess_ext_from_text(self, text: str) -> str:
        head = (text or "").lstrip()[:4000]
        if re.search(r"(?im)^\\s*@echo\\s+off\\b", head) or re.search(r"(?im)^\\s*rem\\b", head): return ".bat"
        if re.search(r"(?im)^#!.*python", head): return ".py"
        if re.search(r"(?m)^\\s*(from\\s+\\w+\\s+import|import\\s+\\w+|def\\s+\\w+\\(|class\\s+\\w+\\(|if\\s+__name__\\s*==\\s*['\\\"]__main__['\\\"])"," "+head): return ".py"
        try:
            if head and head.strip()[0] in "{[":
                json.loads(head); return ".json"
        except Exception:
            pass
        if re.search(r"(?m)^\\s*-\\s+\\w+", head) or re.search(r"(?m)^\\s*\\w+:\\s+.+", head): return ".yml"
        if re.search(r"(?m)^\\s*\\[[^\\]]+\\]\\s*$", head) and re.search(r"(?m)^\\s*\\w+\\s*=\\s*", head): return ".ini"
        if re.search(r"(?m)^\\s*#\\s+\\w+", head): return ".md"
        return ""

    def _apply_ext_to_name(self, name: str, ext: str) -> str:
        ext = (ext or "").strip().lower()
        if ext and not ext.startswith("."): ext = "." + ext
        base, cur = os.path.splitext(name)
        if not ext: return name if cur else (name + ".txt")
        if (cur or "").lower() == ext: return name
        return (base or name) + ext

    def _detect(self) -> bool:
        name = (self.var_name.get() or "").strip()
        nm, ext_from_name = os.path.splitext(name) if name else ("","")
        ext = (ext_from_name or "").lower()
        try:    content = self.txt.get("1.0","end-1c")
        except Exception: content = ""

        if not self.var_name_manual:
            nm_guess, ext_guess = self._guess_name_from_text(content)
            if nm_guess:
                self.var_name.set(nm_guess + (ext_guess or ""))
                if not self.var_ext_manual and not ext:
                    ext = (ext_guess or "").lower()

        if not ext:
            ext = self._guess_ext_from_text(content) or ""

        if not self.var_ext_manual:
            self.var_ext.set(ext or ".py")
        else:
            self._normalize_ext(); ext = (self.var_ext.get() or "").lower()

        if not self.var_name_manual and not (self.var_name.get() or "").strip():
            ts = time.strftime("%Y%m%d_%H%M%S"); self.var_name.set(f"snippet_{ts}{ext or ''}")

        allowed = {".py",".bat",".cmd",".json",".txt",".yml",".yaml",".ini",".md",".shcut"}
        ok = bool(ext) and (ext in allowed or (ext == "" and not self.var_ext_manual))
        self._update_led(self.led_detect, "green" if ok else "yellow")
        self._ping("Erkennung: " + (ext or "(keine)"))
        return ok

    # --- Paste / Modified
    def _on_editor_paste(self, _evt=None):
        try:
            self._schedule_detect(220)
        except Exception:
            pass

    def _on_editor_key(self, _evt=None):
        try:
            self._schedule_detect(250)
        except Exception:
            pass

    def _on_editor_modified(self, _evt=None):
        try:
            try:
                self.txt.edit_modified(False)
            except Exception:
                pass
            self._schedule_detect(300)
        except Exception:
            pass

    def _schedule_detect(self, delay_ms=250):
        try:
            if getattr(self, '_detect_job', None):
                try:
                    self.after_cancel(self._detect_job)
                except Exception:
                    pass
            self._detect_job = self.after(int(delay_ms), self._auto_detect_if_needed)
        except Exception:
            pass

    def _auto_detect_if_needed(self):
        try:
            self._detect()
        except Exception:
            pass

    # --- Actions ---
    def _path_from_selection_or_fields(self) -> str:
        try:
            if self.tbl.selection():
                iid  = self.tbl.selection()[0]
                vals = self.tbl.item(iid, "values")
                name, ext, subfolder = vals[0], vals[1], vals[2]
                base = self.var_target.get()
                folder = os.path.join(base, subfolder) if subfolder else base
                return os.path.normpath(os.path.join(folder, f"{name}{ext}"))
        except Exception:
            pass
        base = self.var_target.get()
        name = (self.var_name.get() or "").strip()
        ext  = self.var_ext.get() or ".py"
        if not name: return ""
        return os.path.normpath(os.path.join(base, f"{name}{ext}"))

    def _on_click_detect(self):
        self._detect()

    def _on_click_save(self):
        p = self._path_from_selection_or_fields()
        if not p:
            self._ping("Kein Name."); return
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8", newline="\n") as f:
            f.write(self.txt.get("1.0","end-1c"))
        self._update_led(self.led_save, "green")
        self._ping(f"Gespeichert: {os.path.basename(p)}")

    def _on_click_delete(self, _evt=None):
        p = self._path_from_selection_or_fields()
        if not p or not os.path.exists(p):
            self._ping("Nichts zu löschen."); return
        if not messagebox.askyesno("Löschen bestätigen", f"Datei in den Papierkorb verschieben?\n\n{p}"):
            return
        ok = _send_to_recycle_bin(p)
        self._ping("Gelöscht." if ok else "Löschen fehlgeschlagen.")

    def _on_click_guard(self, _evt=None):
        self._ping("Guard: (optional) nicht konfiguriert.")

    def _on_click_run(self):
        """Startet bevorzugt .bat (Auto-Gen), nicht-blockierend.
        Erwartet: ein Runner_XXXX.py unter 'tools/'."""
        p = self._path_from_selection_or_fields()
        if not p:
            self._ping("Kein Ziel."); return
        if not p.lower().endswith(".py"):
            self._ping("Bitte eine Runner-Python (.py) wählen."); return
        try:
            rel = os.path.relpath(p, start=os.path.abspath(os.path.join(Path(__file__).resolve().parents[1])))
        except Exception:
            rel = p
        try:
            module_runner_exec.run(rel.replace("\\", "/"), timeout_sec=120, title="ShrimpDev - Runner")
            self._ping("Runner gestartet (BAT-First).")
        except Exception as ex:
            module_runner_exec._log(f"[IntakeToolbar] Run-ERR: {ex}")
            self._ping(f"Run-ERR: {ex}")

    def _on_click_repair_safe(self, _evt=None):
        try:
            self._on_click_repair_deep()
        except Exception:
            pass

    def _on_click_repair_deep(self, _evt=None):
        """Tiefreparatur: ruft die 1114-Runner (falls vorhanden) auf – nicht-blockierend."""
        try:
            module_runner_exec.run("tools/Runner_1114_DeepSanityAndRepair.py", timeout_sec=300, title="ShrimpDev - 1114 SanityRepair")
            module_runner_exec.run("tools/Runner_1114b_FixUnexpectedIndent_MainGUI.py", timeout_sec=300, title="ShrimpDev - 1114b IndentFix")
            self._ping("Reparatur gestartet …")
        except Exception as ex:
            module_runner_exec._log(f"[RepairDeep] ERR: {ex}")
            self._ping(f"Repair-ERR: {ex}")

    # stubs used by table context menu
    def _copy_selected(self):
        p = self._path_from_selection_or_fields()
        if p: self._copy_text(p)

    def _copy_name_selected(self):
        try:
            if self.tbl.selection():
                iid  = self.tbl.selection()[0]
                vals = self.tbl.item(iid, "values")
                self._copy_text(vals[0] + vals[1])
        except Exception: pass

    def _open_selected(self, _evt=None):
        p = self._path_from_selection_or_fields()
        if p: _open_explorer_select(p)

    def _dbl_open(self, _evt=None):
        self._open_selected()

# ---------------- Windows Recycle Bin helper ----------------
def _send_to_recycle_bin(path: str) -> bool:
    try:
        import ctypes
        from ctypes import wintypes
    except Exception:
        return False
    if not os.path.exists(path):
        return False
    FO_DELETE = 3
    FOF_ALLOWUNDO      = 0x0040
    FOF_NOCONFIRMATION = 0x0010

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [
            ("hwnd", wintypes.HWND),
            ("wFunc", wintypes.UINT),
            ("pFrom", wintypes.LPCWSTR),
            ("pTo", wintypes.LPCWSTR),
            ("fFlags", ctypes.c_uint16),
            ("fAnyOperationsAborted", wintypes.BOOL),
            ("hNameMappings", ctypes.c_void_p),
            ("lpszProgressTitle", wintypes.LPCWSTR),
        ]

    pFrom = path + "\x00\x00"
    sh = SHFILEOPSTRUCTW(
        hwnd=None, wFunc=FO_DELETE, pFrom=pFrom, pTo=None,
        fFlags=FOF_ALLOWUNDO | FOF_NOCONFIRMATION,
        fAnyOperationsAborted=False, hNameMappings=None, lpszProgressTitle=None,
    )
    rc = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(sh))
    return rc == 0 and not sh.fAnyOperationsAborted
'''

def main() -> int:
    print("[R1144] ReplaceIntakeSafe – Start")
    if not TARGET.exists():
        print(f"[R1144] Hinweis: {TARGET} existiert nicht – wird neu angelegt.")
    else:
        backup(TARGET)

    # schreiben
    with io.open(TARGET, "w", encoding="utf-8", newline="\n") as f:
        f.write(FIXED)
    print("[R1144] Datei geschrieben.")

    # Syntaxcheck
    try:
        py_compile.compile(str(TARGET), doraise=True)
        print("[R1144] Syntax OK.")
        return 0
    except Exception as ex:
        print("[R1144] SyntaxError:", ex)
        # Rollback nur wenn Backup existiert
        try:
            last = max(ARCH.glob("module_code_intake.py.*.bak"), key=os.path.getmtime)
            shutil.copy2(last, TARGET)
            print(f"[R1144] Rollback -> {last.name}")
        except Exception:
            print("[R1144] Kein Backup gefunden – Datei bleibt unverändert.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
