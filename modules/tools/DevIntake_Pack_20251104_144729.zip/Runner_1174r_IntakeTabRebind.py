# -*- coding: utf-8 -*-
"""
Runner_1174r_IntakeTabRebind
- Stellt in main_gui.py die direkte Einbindung von IntakeFrame wieder her.
- Behält Fallback via _mount_intake_tab_safe bei.
- Backup + Syntaxcheck + Rollback.
"""
import io, os, re, time, py_compile, shutil

ROOT = r"D:\ShrimpDev"
TARGET = os.path.join(ROOT, "main_gui.py")
ARCHIV = os.path.join(ROOT, "_Archiv")

def _ts():
    return str(int(time.time()))

def backup(path):
    os.makedirs(ARCHIV, exist_ok=True)
    bak = os.path.join(ARCHIV, f"{os.path.basename(path)}.{_ts()}.bak")
    shutil.copy2(path, bak)
    print(f"[1174r] Backup erstellt: {bak}")
    return bak

def read_text(path):
    with io.open(path, "r", encoding="utf-8") as f:
        return f.read()

def write_text(path, txt):
    with io.open(path, "w", encoding="utf-8", newline="") as f:
        f.write(txt)

def ensure_intake_import(src):
    """
    Sichert: from modules.module_code_intake import IntakeFrame
    Fügt nahe bei den anderen imports ein, falls fehlend.
    """
    if re.search(r"\bfrom\s+modules\.module_code_intake\s+import\s+IntakeFrame\b", src):
        return src, False

    # Nach dem letzten from/import Block einfügen
    import_block = re.search(r"(?s)^(?:from\s+\S+\s+import\s+.*\n|import\s+\S+(?:\s+as\s+\S+)?\n)+", src)
    insertion = "from modules.module_code_intake import IntakeFrame\n"
    if import_block:
        end = import_block.end()
        src = src[:end] + insertion + src[end:]
    else:
        src = insertion + src
    print("[1174r] Import für IntakeFrame ergänzt.")
    return src, True

def patch_safe_add(src):
    """
    Ersetzt _safe_add_intake_tab so, dass IntakeFrame direkt gemountet wird.
    Behält Fallback auf _mount_intake_tab_safe (Lazy-Mount), falls IntakeFrame fehlschlägt.
    """
    # robuste Regex: ganze Funktion ersetzen
    pat = re.compile(
        r"(?s)\ndef\s+_safe_add_intake_tab\s*\(\s*nb\s*\)\s*:\s*.*?(?=\n\s*def\s+|\Z)"
    )

    new_fn = """
def _safe_add_intake_tab(nb):
    \"\"\"Sicherer Mount des Intake-Tabs.
    1) Bevorzugt: direkter Mount von IntakeFrame.
    2) Fallback: leerer Frame + Lazy-Mount via _mount_intake_tab_safe.
    \"\"\"
    try:
        tab = IntakeFrame(nb)
        nb.add(tab, text="Code Intake")
        _Log("[Intake] Tab mounted (direct).")
    except Exception as e:
        try:
            _Log(f"[Intake] Direct mount failed: {e}. Fallback to lazy mount...")
        except Exception:
            pass
        import tkinter.ttk as ttk
        tab = ttk.Frame(nb)
        nb.add(tab, text="Code Intake")
        body = ttk.Frame(tab)
        body.pack(fill="both", expand=True)
        # Minimal Delay, damit Notebook vollständig initialisiert ist
        try:
            tab.after(100, lambda: _mount_intake_tab_safe(body))
        except Exception:
            pass
""".lstrip("\n")

    if pat.search(src):
        src2 = pat.sub("\n" + new_fn, src, count=1)
        print("[1174r] _safe_add_intake_tab ersetzt (Direct-Mount + Fallback).")
        return src2, True

    # Falls Funktion fehlt, vor __main__-Block einfügen
    main_pat = re.search(r"\nif\s+__name__\s*==\s*[\"']__main__[\"']\s*:\s*\n", src)
    insert_at = main_pat.start() if main_pat else len(src)
    src2 = src[:insert_at] + "\n" + new_fn + "\n" + src[insert_at:]
    print("[1174r] _safe_add_intake_tab nicht gefunden – hinzugefügt.")
    return src2, True

def syntax_check(path):
    try:
        py_compile.compile(path, doraise=True)
        return True
    except py_compile.PyCompileError as e:
        print("[1174r] Syntax-Check FEHLER:\n", e)
        return False

def main():
    if not os.path.isfile(TARGET):
        print(f"[1174r] FEHLER: {TARGET} nicht gefunden.")
        return 2

    bak = backup(TARGET)
    src = read_text(TARGET)
    changed = False

    # 1) Import sicherstellen
    src, ch1 = ensure_intake_import(src)
    changed |= ch1

    # 2) _safe_add_intake_tab(nb) ersetzen/ergänzen
    src, ch2 = patch_safe_add(src)
    changed |= ch2

    if not changed:
        print("[1174r] Keine Änderung notwendig – bereits korrekt.")
        return 0

    # schreiben und Syntax prüfen
    write_text(TARGET, src)
    if syntax_check(TARGET):
        print("[1174r] Patch übernommen, Syntax OK.")
        return 0

    # Rollback bei Fehler
    print("[1174r] ROLLBACK: Wiederherstellung aus Backup.")
    shutil.copy2(bak, TARGET)
    return 1

if __name__ == "__main__":
    raise SystemExit(main())
