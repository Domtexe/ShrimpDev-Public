# -*- coding: utf-8 -*-
"""
Runner_1107b_AutoRepair_IndentBlocks_ReturnFix
- Korrigiert 'return outside function' durch Einrückung
- Sichert defekte Blöcke ab
"""
from __future__ import annotations
import os, re, time, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")

def backup(p):
    ts = int(time.time())
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(p)}.{ts}.bak")
    with open(p, "rb") as fsrc, open(dst, "wb") as fdst:
        fdst.write(fsrc.read())
    print(f"[R1107b] Backup: {dst}")
    return dst

def read(p):
    with open(p, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def write(p, t):
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(t)

def fix_return_outside(text: str) -> tuple[str, bool]:
    """
    Sucht Zeilen mit 'return ' am Zeilenanfang oder ohne Einrückung
    und rückt sie 4 Spaces ein.
    """
    lines = text.splitlines(True)
    changed = False
    for i, line in enumerate(lines):
        if re.match(r"^return\b", line):
            lines[i] = "    " + line
            changed = True
    return "".join(lines), changed

def normalize(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n").replace("\t", "    ")

def main():
    if not os.path.exists(MOD):
        print("[R1107b] Datei nicht gefunden.")
        return 1

    src = normalize(read(MOD))
    new_src, ch1 = fix_return_outside(src)

    if not ch1:
        print("[R1107b] Keine un-eingerückten returns gefunden.")
        return 0

    backup(MOD)
    try:
        compile(new_src, MOD, "exec")
    except SyntaxError as e:
        print(f"[R1107b] SyntaxError nach Repair: Zeile {e.lineno}: {e.msg}")
        print("[R1107b] Datei bleibt unverändert.")
        return 2

    write(MOD, new_src)
    print("[R1107b] Return-Reparatur erfolgreich.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
