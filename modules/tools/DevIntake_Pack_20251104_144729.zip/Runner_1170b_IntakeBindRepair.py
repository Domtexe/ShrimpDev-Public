# -*- coding: utf-8 -*-
"""
Runner_1170b_IntakeBindRepair
- Fügt einen robusten Helper `_intake_bind_wiring(self)` in module_code_intake.py ein
- Ruft ihn nach `_intake_post_build_bind_clear(self)` in _build_ui() auf
- Idempotent, mit Backup, Syntax-Check & Rollback
Exitcodes: 0 OK, 1 Fehler
"""
from __future__ import annotations
import os, re, time, py_compile, traceback

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOG    = os.path.join(ROOT, "debug_output.txt")

MARK_HELPER = "# R1170b: intake bind wiring helper"
CALL_MARK   = "# R1170b: bind wiring call"

HELPER_CODE = f"""
{MARK_HELPER}
def _intake_bind_wiring(self) -> None:
    \"\"\"Verdrahtung von Buttons, Shortcuts und Doppelklick sicher nachziehen.
    - Greift nur auf existierende Widgets/Handler zu
    - Schluckt alle Fehler (keine GUI-Crashes)
    \"\"\"
    try:
        import tkinter as tk
    except Exception:
        return

    def _maybe_wire_button(btn_attr: str, handler_names):
        try:
            btn = getattr(self, btn_attr, None)
            if not btn:
                return
            handler = None
            for name in handler_names:
                cand = getattr(self, name, None)
                if callable(cand):
                    handler = cand
                    break
            if handler:
                try:
                    btn.configure(command=handler)   # ttk.Button
                except Exception:
                    try:
                        btn["command"] = handler     # tk.Button
                    except Exception:
                        pass
        except Exception:
            pass

    # Buttons: detect/save/open/clear/preview (nur wenn vorhanden)
    _maybe_wire_button("btn_detect",  ("_on_detect_clicked", "on_detect", "detect"))
    _maybe_wire_button("btn_save",    ("_on_save_clicked", "on_save", "save"))
    _maybe_wire_button("btn_open",    ("_on_open_clicked", "on_open", "open"))
    _maybe_wire_button("btn_clear",   ("_on_clear_clicked", "on_clear", "clear", "_intake_on_clear_editor_clicked"))
    _maybe_wire_button("btn_preview", ("_on_preview_clicked", "on_preview", "preview"))

    # Key-Bindings (auf Frame und Editor, wenn vorhanden)
    try:
        target = getattr(self, "txt", self)
        kb = [
            ("<Control-s>", ("_on_save_clicked","on_save","save")),
            ("<Control-i>", ("_on_detect_clicked","on_detect","detect")),
            ("<Control-o>", ("_on_open_clicked","on_open","open")),
            ("<Delete>",    ("_on_clear_clicked","on_clear","clear","_intake_on_clear_editor_clicked")),
        ]
        for seq, names in kb:
            handler = None
            for nm in names:
                cand = getattr(self, nm, None)
                if callable(cand):
                    handler = cand
                    break
            if handler:
                try:
                    self.bind(seq,  lambda e, h=handler: (h(), "break"))
                except Exception:
                    pass
                try:
                    target.bind(seq, lambda e, h=handler: (h(), "break"))
                except Exception:
                    pass
    except Exception:
        pass

    # Doppelklick auf Tabelle (falls vorhanden)
    try:
        tbl = getattr(self, "tbl", None)
        if tbl:
            # Suche Preview/Open-Handler
            handler = None
            for nm in ("_on_open_clicked","on_open","_on_preview_clicked","on_preview"):
                cand = getattr(self, nm, None)
                if callable(cand):
                    handler = cand
                    break
            if handler:
                try:
                    tbl.bind("<Double-1>", lambda e, h=handler: (h(), "break"))
                except Exception:
                    pass
    except Exception:
        pass
"""

def _log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1170b {ts}] {msg}\n"
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def _backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    ts = int(time.time())
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    with open(path, "r", encoding="utf-8") as fi, open(dst, "w", encoding="utf-8", newline="") as fo:
        fo.write(fi.read())
    return dst

def main() -> int:
    try:
        if not os.path.exists(TARGET):
            _log(f"Zieldatei fehlt: {TARGET}")
            return 1

        src = open(TARGET, "r", encoding="utf-8").read()
        changed = False

        # 1) Helper einfügen (falls noch nicht vorhanden)
        if MARK_HELPER not in src:
            # Versuch: nach Helpers-Marker einfügen, sonst ans Datei-Ende
            m = re.search(r"(?m)^\\s*#\\s*-{2,}\\s*helpers\\s*-{2,}\\s*$", src)
            if m:
                insert_at = m.end()
                src = src[:insert_at] + "\n" + HELPER_CODE + src[insert_at:]
            else:
                src = src.rstrip() + "\n\n" + HELPER_CODE
            changed = True

        # 2) Call nach _intake_post_build_bind_clear(self) injizieren (idempotent)
        if CALL_MARK not in src:
            pat = r"(^[ \\t]*_intake_post_build_bind_clear\\(self\\)[ \\t]*\\r?\\n)"
            m2 = re.search(pat, src, flags=re.M)
            if m2:
                pos = m2.end()
                call = "        " + CALL_MARK + "\\n        _intake_bind_wiring(self)\\n"
                src = src[:pos] + call + src[pos:]
                changed = True
            else:
                _log("Warnung: Aufrufstelle _intake_post_build_bind_clear(self) nicht gefunden – kein Call eingefügt.")

        if not changed:
            _log("Keine Änderung notwendig (Patch bereits vorhanden).")
            return 0

        # 3) Backup + Schreiben + Syntax-Check
        bak = _backup(TARGET)
        _log(f"Backup erstellt: {bak}")
        open(TARGET, "w", encoding="utf-8", newline="\n").write(src)
        try:
            py_compile.compile(TARGET, doraise=True)
        except Exception as e:
            open(TARGET, "w", encoding="utf-8", newline="\n").write(open(bak, "r", encoding="utf-8").read())
            _log("Syntax-Check FEHLER -> Rollback auf Backup.")
            _log("Traceback:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 1

        _log("Patch erfolgreich eingefügt und Syntax-Check OK.")
        return 0

    except Exception as e:
        _log("UNERWARTETER FEHLER:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
