# tools/Runner_1064_IntegrateGuard_UI.py
"""
Runner_1064_IntegrateGuard_UI
- Fügt in modules/module_code_intake.py einen Button 'Prüfen (Guard)' ein
- Implementiert _on_click_guard(): ermittelt Datei, ruft Guard via subprocess
- Markiert bei Erfolg den Eintrag in der rechten Liste mit '✅'
- Fallback: Meldungen per self._ping()
"""
from __future__ import annotations
import os, re, time, shutil, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")

def rd(p): 
    with open(p, "r", encoding="utf-8") as f: return f.read()
def wr_backup(p, data):
    os.makedirs(ARCH, exist_ok=True)
    b = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, b)
    with open(p, "w", encoding="utf-8", newline="\r\n") as f: f.write(data)
    print(f"Backup: {p} -> {b}")

def ensure_imports(src: str) -> str:
    need = []
    if "import subprocess" not in src: need.append("import subprocess")
    if "import sys" not in src:        need.append("import sys")
    if not need: return src
    m = re.search(r"^(import[^\n]*\n)+", src, re.MULTILINE)
    ins = m.end() if m else 0
    return src[:ins] + "\n".join(need) + ("\n" if need else "") + src[ins:]

def add_button(src: str) -> str:
    # Buttons liegen in einem Frame – wir hängen nach 'Speichern'/'Löschen' an.
    # sehr tolerante Regex: Suche Stelle, wo die Buttons erstellt werden.
    pat = re.compile(r"(#\s*Actions\s*Bar[\s\S]+?)(\n\s*#|^\s*#?\s*Editor\b|^\s*self\.txt[^\n]*$)", re.MULTILINE)
    m = pat.search(src)
    if not m:
        # Fallback: suche nach 'Speichern' Button
        m2 = re.search(r"self\.btn_save\s*=\s*ttk\.Button[^\n]+\n", src)
        anchor = m2.end() if m2 else None
        if not anchor: return src
        inject = (
            '\n        # Guard-Button\n'
            '        self.btn_guard = ttk.Button(self.frm_actions, text="Prüfen (Guard)", command=self._on_click_guard)\n'
            '        self.btn_guard.grid(row=0, column=99, padx=(4,0))\n'
        )
        return src[:anchor] + inject + src[anchor:]
    block = m.group(1)
    if "btn_guard" in block: 
        return src  # schon integriert
    inject = (
        block +
        '\n        # Guard-Button\n'
        '        self.btn_guard = ttk.Button(self.frm_actions, text="Prüfen (Guard)", command=self._on_click_guard)\n'
        '        self.btn_guard.grid(row=0, column=99, padx=(4,0))\n'
    )
    return src.replace(block, inject)

def add_handler(src: str) -> str:
    if "_on_click_guard(" in src: 
        return src
    handler = r"""
    def _on_click_guard(self, _evt=None):
        """ + '"""' + r"""Sanity-Guard für die ausgewählte/angegebene Datei ausführen.
        Erfolgreich → Eintrag in der Liste mit '✅' markieren.""" + '"""' + r"""
        try:
            # Ziel ermitteln: bevorzugt Auswahl rechts, sonst aus Name/Ext/Zielordner
            path = ""
            try:
                sel = self.tree_right.selection()
                if sel and hasattr(self, 'path_of_item'):
                    path = self.path_of_item(sel[0])
            except Exception:
                path = ""
            if not path:
                # aus Eingaben zusammensetzen
                name = self.var_name.get().strip() if hasattr(self, 'var_name') else ""
                ext  = self.var_ext.get().strip() if hasattr(self, 'var_ext') else ""
                base = self.var_target.get().strip() if hasattr(self, 'var_target') else ""
                if name and ext and base:
                    path = os.path.join(base, name + (ext if ext.startswith(".") else "." + ext))
            if not path or not os.path.exists(path):
                self._ping("Keine gültige Zieldatei für Guard gefunden.")
                return

            # Guard aufrufen
            root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
            guard = os.path.join(root, "tools", "Runner_1063_Intake_SanityGuard.py")
            if not os.path.exists(guard):
                self._ping("Guard nicht gefunden.")
                return
            py = sys.executable or "py"
            rc = subprocess.call([py, guard, "--file", path], cwd=root)
            if rc != 0:
                self._ping(f"Guard meldet Fehler (RC={rc}).")
                return

            # Markierung in der Liste
            try:
                if sel:
                    item = sel[0]
                    vals = list(self.tree_right.item(item, "values"))
                    if vals:
                        # Annahme: name ist Spalte 0 → "… ✅"
                        if not str(vals[0]).endswith("✅"):
                            vals[0] = str(vals[0]) + "  ✅"
                        self.tree_right.item(item, values=tuple(vals))
                self._ping("Guard OK.")
            except Exception:
                self._ping("Guard OK (Liste nicht aktualisiert).")
        except Exception as ex:
            try:
                self._ping(f"Guard-Fehler: {ex}")
            except Exception:
                pass
"""
    # Einfügen vor dem Klassenende von IntakeFrame
    m = re.search(r"\nclass\s+IntakeFrame\(ttk\.Frame\):[\s\S]+?\n(?=class\s+|\Z)", src)
    if not m: 
        return src + handler
    body = m.group(0)
    if "_on_click_guard(" in body:
        return src
    new_body = body + handler
    return src.replace(body, new_body)

def patch():
    src = rd(MOD)
    src2 = ensure_imports(src)
    src2 = add_button(src2)
    src2 = add_handler(src2)
    if src2 != src:
        wr_backup(MOD, src2)
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.54\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("\n## v9.9.54\n- Intake: Guard-Button + Handler integriert (Prüfen & ✅-Markierung)\n")
        print("Patch angewendet.")
        return 0
    print("Keine Änderungen nötig.")
    return 0

if __name__ == "__main__":
    raise SystemExit(patch())
