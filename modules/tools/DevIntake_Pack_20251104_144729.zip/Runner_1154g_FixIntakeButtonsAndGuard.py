# -*- coding: utf-8 -*-
"""
Runner_1154g_FixIntakeButtonsAndGuard
- Entfernt den R1154c-Toolbar-Block auf Klassenebene (benutzt 'bar' außerhalb von _build_ui).
- Hängt die Buttons 'Editor leeren' und 'Datei löschen' idempotent ans Ende von _build_ui().
- Repariert _detect_guarded (kein Selbstaufruf; ruft _detect()).
- Backup, Syntax-Check, Import-Smoke, Rollback bei Fehlern.
"""
from __future__ import annotations
import io, os, sys, time, shutil, re, ast, importlib.util, types, py_compile
from pathlib import Path

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1154g_FixIntakeButtonsAndGuard_report.txt"

BUTTONS_BLOCK = r"""
        # R1154g: zusätzliche Toolbar-Buttons (idempotent; innerhalb _build_ui)
        try:
            parent = bar
        except Exception:
            parent = getattr(self, "toolbar", None)
        if parent:
            try:
                import tkinter.ttk as ttk
            except Exception:
                ttk = None
            if ttk:
                try:
                    if not hasattr(self, 'btn_clear_editor'):
                        self.btn_clear_editor = ttk.Button(parent, text='Editor leeren', command=self._on_clear_editor)
                        self.btn_clear_editor.grid(row=0, column=120, padx=(12,0), sticky='w')
                except Exception:
                    pass
                try:
                    if not hasattr(self, 'btn_delete_file'):
                        self.btn_delete_file = ttk.Button(parent, text='Datei löschen', command=self._on_delete_selected_file)
                        self.btn_delete_file.grid(row=0, column=121, padx=(6,0), sticky='w')
                except Exception:
                    pass
""".rstrip("\n")

def log(line=""):
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(line.rstrip()+"\n")
    print(line)

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time()*1000)}.bak"
    shutil.copy2(p, dst)
    return dst

def import_smoke()->tuple[bool,str]:
    if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
    # Notfall: mod_runner_exec stubben
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules"); sys.modules.setdefault("modules", pkg)
        mod = types.ModuleType("modules.module_runner_exec")
        mod.run = lambda *a, **k: 0
        mod._log = lambda *a, **k: None
        sys.modules["modules.module_runner_exec"] = mod
    try:
        spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
        m = importlib.util.module_from_spec(spec); assert spec and spec.loader
        spec.loader.exec_module(m)  # type: ignore[attr-defined]
        return True, "Import OK"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"

def remove_class_level_toolbar_block(src: str) -> tuple[str, int]:
    """
    Entfernt den 8-Space eingerückten R1154c-Block (oder gleiches Muster) auf Klassenebene.
    Wir löschen nur den sicher erkennbaren Bereich zwischen Kommentarzeile und nächstem def.
    """
    # Startzeile: Kommentar mit 'zusätzliche Toolbar-Buttons' oder 'R1154c'
    rx = re.compile(r'(?ms)^\s{8}#\s*(?:R1154c:)?\s*zusätzliche Toolbar-Buttons.*?(?=^\s{4}def\s+|\Z)')
    new_src, n = rx.subn("", src)
    return new_src, n

def inject_buttons_into_build_ui(src: str) -> tuple[str, bool]:
    tree = ast.parse(src)
    cls = next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name=="IntakeFrame"), None)
    if not cls: raise RuntimeError("IntakeFrame nicht gefunden.")
    fn  = next((b for b in cls.body if isinstance(b, ast.FunctionDef) and b.name=="_build_ui"), None)
    if not fn:  raise RuntimeError("_build_ui() nicht gefunden.")
    lines = src.splitlines()
    s, e = fn.lineno-1, getattr(fn, "end_lineno", None) or (fn.lineno)
    body = "\n".join(lines[s:e])
    if ("btn_clear_editor" in body) or ("btn_delete_file" in body):
        return src, False  # bereits vorhanden
    new_body = body.rstrip("\n") + "\n" + BUTTONS_BLOCK + "\n"
    new_src  = "\n".join(lines[:s]) + new_body + "\n".join(lines[e:])
    return new_src, True

def fix_detect_guarded(src: str) -> tuple[str, bool]:
    rx = re.compile(r'(?ms)^\s{4}def\s+_detect_guarded\s*\([^)]*\):\s*.*?(?=^\s{4}def\s+|\Z)')
    if not rx.search(src):
        return src, False
    safe = (
        "    def _detect_guarded(self, *args, **kwargs):\n"
        "        \"\"\"Safe wrapper around _detect: catches exceptions, pings, returns False.\"\"\"\n"
        "        try:\n"
        "            return self._detect(*args, **kwargs)\n"
        "        except Exception as ex:\n"
        "            try:\n"
        "                self._ping(f\"DetectWarn: {ex}\")\n"
        "            except Exception:\n"
        "                pass\n"
        "            return False\n"
    )
    return rx.sub(safe, src, count=1), True

def main()->int:
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass
    log("[R1154g] Start FixIntakeButtonsAndGuard")

    if not MODFILE.exists():
        log("[ERR] modules/module_code_intake.py nicht gefunden."); return 1

    bak = backup(MODFILE); log(f"[Backup] {bak.name}")
    src0 = io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

    # 1) Klassennahen Toolbar-Block entfernen
    src1, removed = remove_class_level_toolbar_block(src0)
    if removed:
        log(f"[Write] Klassen-Toolbar-Block entfernt: {removed}")
    else:
        log("[Info] Kein Klassen-Toolbar-Block gefunden (ok).")

    # 2) Buttons in _build_ui() injizieren (idempotent)
    try:
        src2, added = inject_buttons_into_build_ui(src1)
    except SyntaxError as ex:
        log(f"[Syntax] Fehler beim Lesen von _build_ui: {ex}"); return 1

    # 3) _detect_guarded reparieren
    src3, fixed = fix_detect_guarded(src2)

    # Schreiben
    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(src3)

    # Syntax prüfen
    try:
        py_compile.compile(MODFILE, doraise=True)
        log("[Syntax] OK")
    except Exception as e:
        log(f"[Syntax] Fehler: {e} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    # Import-Smoke
    ok, msg = import_smoke()
    if not ok:
        log(f"[Live] Import-Fehler: {msg} -> Rollback"); shutil.copy2(bak, MODFILE); return 1
    log(f"[Live] {msg}")

    log(f"[SUM] removed_class_toolbar={removed}, buttons_added={added}, guarded_fixed={fixed}")
    log("[R1154g] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
