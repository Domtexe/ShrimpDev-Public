from __future__ import annotations
from pathlib import Path
import re, time, shutil, py_compile, sys

ROOT = Path(r"D:\ShrimpDev")
MAIN = ROOT / "main_gui.py"

def ts(): return time.strftime("%Y%m%d_%H%M%S")
def backup(p: Path):
    if p.exists():
        b = p.with_suffix(p.suffix + f".{ts()}.bak")
        shutil.copy2(p, b)
        print(f"[R952] Backup: {b.name}")

CLAUSE_RE = re.compile(r'^(?P<indent>[ \t]*)(?P<kw>try|except|finally|else)\s*:\s*$', re.M)

def is_blank_or_comment(s: str) -> bool:
    t = s.strip()
    return (not t) or t.startswith("#") or t.startswith('"""') or t.startswith("'''")

def fix_clauses(lines: list[str]) -> tuple[list[str], int]:
    """
    Nach JEDER Klausel-Zeile (try/except/finally/else):
      - Falls die nächste *signifikante* Zeile NICHT strikter eingerückt ist, füge 'pass' ein.
      - Spezialfall: Wenn direkt darunter Kommentar ODER direkt weitere Klausel mit gleichem Indent steht -> auch 'pass' einfügen.
    """
    i = 0
    fixes = 0
    out: list[str] = []
    n = len(lines)

    def indent_of(s: str) -> int: return len(s) - len(s.lstrip(" "))

    while i < n:
        line = lines[i]
        out.append(line)
        m = CLAUSE_RE.match(line)
        if m:
            base_indent = indent_of(line)
            j = i + 1
            # Skip reine Leer-/Kommentarzeilen (merken dabei max. 1 Kommentarblock)
            saw_only_blanks_or_comments = False
            while j < n and is_blank_or_comment(lines[j]):
                saw_only_blanks_or_comments = True
                j += 1

            if j >= n:
                out.append(" " * (base_indent + 4) + "pass  # [R952 add @EOF]")
                fixes += 1
            else:
                next_line = lines[j]
                next_indent = indent_of(next_line)
                # Wenn die nächste sinnvolle Zeile NICHT tiefer eingerückt ist -> kein Body vorhanden
                if next_indent <= base_indent:
                    out.append(" " * (base_indent + 4) + "pass  # [R952 add]")
                    fixes += 1
                else:
                    # Sonderfall: direkt nach Kommentar kommt wieder 'try/except/finally/else' auf gleicher Einrückung
                    if saw_only_blanks_or_comments:
                        m2 = CLAUSE_RE.match(next_line)
                        if m2 and indent_of(next_line) == base_indent + 4:
                            # Vor dem zweiten Klausel-Start noch einen pass einfügen,
                            # damit der erste Clause gültig ist.
                            out.append(" " * (base_indent + 4) + "pass  # [R952 add after comment]")
                            fixes += 1
        i += 1

    return out, fixes

def compile_ok(p: Path) -> tuple[bool, str]:
    try:
        py_compile.compile(str(p), doraise=True)
        return True, ""
    except Exception as ex:
        return False, str(ex)

def main() -> int:
    if not MAIN.exists():
        print("[R952] FEHLT: main_gui.py"); return 2

    backup(MAIN)
    text = MAIN.read_text(encoding="utf-8", errors="ignore")
    lines = text.splitlines()

    # Bis zu 5 Reparaturdurchläufe (für Kaskaden-Fälle)
    for pass_no in range(1, 6):
        ok, err = compile_ok(MAIN)
        if ok:
            print("[R952] Syntax OK – keine Fixes nötig.")
            return 0

        # Reparieren
        new_lines, count = fix_clauses(lines)
        if count == 0:
            print(f"[R952] PASS {pass_no}: Keine reparablen Klauseln gefunden. Fehler bleibt: {err}")
            break

        MAIN.write_text("\n".join(new_lines), encoding="utf-8")
        lines = new_lines
        print(f"[R952] PASS {pass_no}: Fixes angewendet = {count}")

    ok, err = compile_ok(MAIN)
    if ok:
        print("[R952] Syntax OK nach Fix.")
        return 0
    print(f"[R952] FEHLER bleibt: {err}")
    return 1

if __name__ == "__main__":
    sys.exit(main())
