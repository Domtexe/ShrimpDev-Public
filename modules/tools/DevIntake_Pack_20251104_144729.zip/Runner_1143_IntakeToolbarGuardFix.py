# -*- coding: utf-8 -*-
"""
[R1143] IntakeToolbarGuardFix
- setzt den Guard-Button auf die existierende Toolbar 'bar'
- repariert den fehlerhaften try/except-Block bei den Button-Bindings
- belässt sonst alles unverändert; Backup wird angelegt
"""
import io, os, re, sys, time
from datetime import datetime

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")

def backup(path):
    os.makedirs(ARCH, exist_ok=True)
    stamp = str(int(time.time()*1000))
    dst = os.path.join(ARCH, os.path.basename(path) + "." + stamp + ".bak")
    with io.open(path, "r", encoding="utf-8", newline="") as f:
        data = f.read()
    with io.open(dst, "w", encoding="utf-8", newline="") as f:
        f.write(data)
    return data, dst

def write(path, data):
    with io.open(path, "w", encoding="utf-8", newline="") as f:
        f.write(data)

def main():
    print("[R1143] IntakeToolbarGuardFix")
    if not os.path.isfile(MOD):
        print(f"[R1143] FEHLER: Datei fehlt: {MOD}")
        sys.exit(2)

    src, bak = backup(MOD)
    print(f"[R1143] Backup -> {bak}")

    changed = False
    text = src

    # --- Fix 1: Guard-Button auf 'bar' statt 'self.frm_actions' ---
    # Beispiel-Original:
    # self.btn_guard = ttk.Button(self.frm_actions, text="Prüfen (Guard)", command=self._on_click_guard)
    pat_guard = re.compile(
        r'(\bself\.btn_guard\s*=\s*ttk\.Button\()\s*self\.frm_actions(\s*,\s*text\s*=\s*".*?")',
        re.DOTALL
    )
    if pat_guard.search(text):
        text = pat_guard.sub(r'\1bar\2', text)
        # Falls ein getrenntes .grid() existiert, bleibt es unverändert – es arbeitet ja auf self.btn_guard.
        changed = True
        print("[R1143] Guard-Button: Zielcontainer -> 'bar'")

    # --- Fix 2: kaputten try/except-Block bei den Bindings heilen ---
    # Wir transformieren:
    #    try:
    #        self.btn_detect.bind(...)
    #        self.btn_save.bind(...)
    #        self.btn_del.bind(...)
    #    try:
    #        pass
    #    except Exception:
    #        pass
    #    body = ttk.Panedwindow(...)
    #
    # in:
    #    try:
    #        self.btn_detect.bind(...)
    #        self.btn_save.bind(...)
    #        self.btn_del.bind(...)
    #    except Exception:
    #        pass
    #    body = ttk.Panedwindow(...)

    pat_try_block = re.compile(
        r'(^[ \t]*try:\s*\n'                               # 1. try:
        r'(?P<binds>(?:^[ \t].*\n){0,20}?)'               #   Bindings-Zeilen
        r'^[ \t]*try:\s*\n'                                # 2. try:  (fehlerhaft)
        r'^[ \t]*pass\s*\n'                                #   pass
        r'^[ \t]*except[ \t]+Exception:\s*\n'              # except Exception:
        r'^[ \t]*pass\s*\n'                                #   pass
        r'(?P<indent>^[ \t]*)body\s*=\s*ttk\.Panedwindow', # nächste Anker-Zeile
        re.MULTILINE
    )
    def _fix_try(m):
        binds = m.group('binds')
        indent = m.group('indent')
        return (f"{m.group(0).splitlines()[0]}\n{binds}"
                f"{indent}except Exception:\n{indent}    pass\n"
                f"{indent}body = ttk.Panedwindow")

    new_text, n = pat_try_block.subn(_fix_try, text)
    if n > 0:
        text = new_text
        changed = True
        print(f"[R1143] Button-Bindings: try/except repariert (Vorkommen: {n})")

    if not changed:
        print("[R1143] Keine Änderungen nötig.")
        sys.exit(0)

    # Schreiben
    write(MOD, text)
    print("[R1143] Datei geschrieben.")

    # Syntaxcheck
    try:
        import py_compile
        py_compile.compile(MOD, doraise=True)
        print("[R1143] Syntax OK.")
        rc = 0
    except Exception as ex:
        print("[R1143] SyntaxError:", ex)
        print("[R1143] Rollback ->", bak)
        write(MOD, src)
        rc = 1

    sys.exit(rc)

if __name__ == "__main__":
    main()
