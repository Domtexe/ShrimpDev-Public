# -*- coding: utf-8 -*-
"""
[1174j] IntakeRestoreSmartFix
- behebt CR/LF/CRCRLF-Zeilenumbrüche in _Archiv-Bakfiles
- ignoriert harmlose SyntaxWarnings ("invalid escape sequence")
- führt RestoreSmart erneut aus
"""
from __future__ import annotations
import os, io, re, shutil, py_compile, time, glob

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
ARCH = os.path.join(ROOT, "_Archiv")
MODS = os.path.join(ROOT, "modules")
TARGET = os.path.join(MODS, "module_code_intake.py")
LOGF = os.path.join(ROOT, "debug_output.txt")

def log(msg:str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(f"[1174j] {ts} {msg}\n")
    except Exception:
        pass

def normalize_line_endings(path:str):
    try:
        with io.open(path, "r", encoding="utf-8", errors="ignore") as f:
            data = f.read()
        # Normalisiere CR+LF → LF
        data = data.replace("\r\n", "\n").replace("\r", "\n")
        tmp = path + ".clean"
        with io.open(tmp, "w", encoding="utf-8", newline="\n") as f:
            f.write(data)
        shutil.move(tmp, path)
        log(f"Zeilenumbrüche normalisiert in {os.path.basename(path)}")
    except Exception as ex:
        log(f"normalize_line_endings FEHLER: {ex}")

def syntax_ok(path:str) -> bool:
    try:
        py_compile.compile(path, doraise=True)
        return True
    except Exception as ex:
        s = str(ex)
        if "invalid escape sequence" in s or "SyntaxWarning" in s:
            log(f"Ignoriere SyntaxWarning: {s}")
            return True
        log(f"SyntaxCheck FEHLER: {s}")
        return False

def find_latest_backup() -> str | None:
    cand = sorted(glob.glob(os.path.join(ARCH, "module_code_intake.py.*.bak")),
                  key=lambda p: os.path.getmtime(p),
                  reverse=True)
    if not cand:
        log("Kein Backup gefunden.")
        return None
    return cand[0]

def restore_clean_version(bak:str):
    try:
        normalize_line_endings(bak)
        if not syntax_ok(bak):
            log("Backup trotz Normalize weiterhin fehlerhaft – Abbruch.")
            return False
        ts = str(int(time.time()))
        cur_bak = os.path.join(ARCH, f"module_code_intake.py.{ts}.bak")
        if os.path.exists(TARGET):
            shutil.copy2(TARGET, cur_bak)
            log(f"Aktuelle Intake gesichert: {cur_bak}")
        shutil.copy2(bak, TARGET)
        log(f"Wiederhergestellt aus {os.path.basename(bak)}")
        return True
    except Exception as ex:
        log(f"restore_clean_version FEHLER: {ex}")
        return False

def main() -> int:
    log("=== START IntakeRestoreSmartFix ===")
    bak = find_latest_backup()
    if not bak:
        log("Keine Backup-Datei im _Archiv.")
        return 2
    if restore_clean_version(bak):
        log("Restore erfolgreich und Intake wiederhergestellt.")
        return 0
    log("Restore fehlgeschlagen.")
    return 3

if __name__ == "__main__":
    import sys
    sys.exit(main())
