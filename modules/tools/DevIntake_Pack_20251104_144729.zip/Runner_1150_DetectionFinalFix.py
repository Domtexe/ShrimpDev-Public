# -*- coding: utf-8 -*-
"""
Runner_1150_DetectionFinalFix
Mastermodus-konformer Patch:
- Ersetzt/ergänzt IntakeFrame._guess_ext_from_text mit robuster, konfliktfreier Erkennung.
- Reihenfolge/Prio: BAT -> JSON -> YAML -> INI -> MD -> PY -> Fallback ""
- Keine weiteren Module werden verändert.
- Backup -> Write -> Syntaxcheck -> Headless-Livetests -> Rollback bei Fehlern
- Report: _Reports/Runner_1150_DetectionFinalFix_report.txt
"""
from __future__ import annotations
import io, os, sys, time, shutil, ast, importlib.util, types, re
from pathlib import Path
import py_compile

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1150_DetectionFinalFix_report.txt"

def w(s=""):
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(s.rstrip()+"\n")
    print(s)

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time()*1000)}.bak"
    shutil.copy2(p, dst)
    return dst

NEW_EXT_SRC = r'''
def _guess_ext_from_text(self, text: str) -> str:
    """
    Robuste Endungs-Heuristik (Prio: BAT -> JSON -> YAML -> INI -> MD -> PY -> "")
    Konfliktfrei, ohne fehlerhafte Zeichenklassen/-bereiche.
    """
    import re
    head = (text or "").lstrip()[:4000]

    # --- BAT (früh priorisiert)
    # typische Marker am Zeilenanfang oder "call"-Nutzung
    if re.search(r'(?im)^\s*@echo\s+off\b', head) or re.search(r'(?im)^\s*rem\b', head) or re.search(r'(?im)^\s*call\s+\S+', head):
        return ".bat"

    # --- JSON (vorsichtig validiert via leichter Strukturprüfung; echte Validierung später beim Speichern möglich)
    s = head.strip()
    if s[:1] in "{[" and re.search(r'["\{\[\]\}]', s):
        try:
            import json; json.loads(s)
            return ".json"
        except Exception:
            pass

    # --- YAML/YML (.yaml zulassen)
    # Heuristik: key: value  ODER  "- item" am Zeilenanfang
    if re.search(r'(?m)^\s*-\s+\S+', head) or re.search(r'(?m)^\s*\w[\w\-]*\s*:\s+\S+', head):
        return ".yml"

    # --- INI
    if re.search(r'(?m)^\s*\[[^\]]+\]\s*$', head) and re.search(r'(?m)^\s*[^#;\s][\w\.\-]+\s*=\s*\S+', head):
        return ".ini"

    # --- Markdown
    if re.search(r'(?m)^\s*#\s+\S+', head) or re.search(r'(?m)^\s*[-*+]\s+\S+', head):
        return ".md"

    # --- Python (zuletzt, damit BAT/JSON/YAML nicht überschrieben werden)
    if re.search(r'(?im)^#!.*python', head):
        return ".py"
    if re.search(r'(?m)^\s*(?:from\s+\w+[\w\.]*\s+import|import\s+\w[\w\.]*|def\s+\w+\(|class\s+\w+\(|if\s+__name__\s*==\s*[\'"]__main__[\'"])', " "+head):
        return ".py"

    # --- Fallback
    return ""
'''.strip("\n")

def load_txt() -> str:
    return io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

def save_txt(txt: str) -> None:
    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(txt)

def ensure_method(txt: str) -> tuple[str, str]:
    """
    Sucht class IntakeFrame und ersetzt/fügt _guess_ext_from_text.
    Strategie:
      - Klasse im AST finden (Position im Rohtext bestimmen)
      - In Klassentext die Methode ersetzen (Regex) oder ans Ende der Klasse anhängen
    """
    tree = ast.parse(txt)
    cls: ast.ClassDef|None = None
    for n in tree.body:
        if isinstance(n, ast.ClassDef) and n.name == "IntakeFrame":
            cls = n; break
    if not cls:
        raise RuntimeError("class IntakeFrame nicht gefunden.")

    lines = txt.splitlines()
    start = cls.lineno - 1
    end = getattr(cls, "end_lineno", None) or len(lines)
    cls_src = "\n".join(lines[start:end])

    rx = re.compile(r'(?ms)^\s*def\s+_guess_ext_from_text\s*\([^)]*\):\s*(?:\n\s+.+?)(?=^\s*def\s+\w+\s*\(|\Z)')
    if rx.search(cls_src):
        cls_src2 = rx.sub("\n    " + NEW_EXT_SRC.replace("\n", "\n    ") + "\n", cls_src, count=1)
        change = "replaced:_guess_ext_from_text"
    else:
        if not cls_src.endswith("\n"): cls_src += "\n"
        cls_src2 = cls_src + "\n    " + NEW_EXT_SRC.replace("\n", "\n    ") + "\n"
        change = "added:_guess_ext_from_text"

    new_txt = "\n".join(lines[:start]) + ("\n" if start else "") + cls_src2 + ("\n" if end < len(lines) else "") + "\n".join(lines[end:])
    return new_txt, change

# ---- Live-Test Helfer
def import_intake_for_test():
    sys.path.insert(0, str(ROOT))
    # Shim für module_runner_exec, um Importfehler zu vermeiden
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules")
        mod = types.ModuleType("modules.module_runner_exec")
        mod.run = lambda *a, **k: 0
        mod._log = lambda *a, **k: None
        sys.modules.setdefault("modules", pkg)
        sys.modules["modules.module_runner_exec"] = mod

    spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
    m = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(m)  # type: ignore[attr-defined]
    return m

def run_detection_tests()->tuple[int,int,str]:
    """
    Führt 7 Tests aus (inkl. INI/MD). yml akzeptiert .yml oder .yaml.
    Rückgabe: (fails, total, log_summary)
    """
    import tkinter as tk
    m = import_intake_for_test()
    root = tk.Tk(); root.withdraw()
    fr = m.IntakeFrame(root)

    cases = [
        ("BAT basic",       "@echo off\nrem test\n", ".bat"),
        ("BAT call",        "call tools\\Runner_8888_Task.bat\n", ".bat"),
        ("JSON",            '{ "k": 1, "v": [1,2] }\n', ".json"),
        ("YML",             "name: x\nsteps:\n  - run\n", ".yml"),
        ("INI",             "[core]\nkey=value\n", ".ini"),
        ("MD",              "# Titel\n- Punkt 1\n", ".md"),
        ("PY",              "import os\nif __name__=='__main__':\n    print('x')\n", ".py"),
    ]

    fails = 0
    out_lines = []
    for title, text, want in cases:
        fr.txt.delete("1.0", "end"); fr.txt.insert("1.0", text)
        fr.var_name_manual = False; fr.var_ext_manual = False
        ok = fr._detect()
        ext = (fr.var_ext.get() or "").lower()
        good = (ext in (".yml",".yaml")) if want == ".yml" else (ext == want)
        line = f"[Test] {title:12s} -> ok={ok} ext='{ext}' want='{want}' => {'OK' if good else 'FAIL'}"
        out_lines.append(line)
        if not good:
            fails += 1

    root.destroy()
    return fails, len(cases), "\n".join(out_lines)

def main()->int:
    # Report neu
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass

    w("[R1150] DetectionFinalFix – Start")
    if not MODFILE.exists():
        w(f"[ERR] Datei fehlt: {MODFILE}")
        return 1

    bak = backup(MODFILE); w(f"[Backup] {bak.name}")

    try:
        src = load_txt()
        new_src, change = ensure_method(src)
    except Exception as e:
        w(f"[ERR] Patch-Vorbereitung: {e}")
        return 1

    save_txt(new_src)
    w("[Write] " + change)

    # Syntaxcheck
    try:
        py_compile.compile(str(MODFILE), doraise=True)
        w("[Syntax] OK")
    except Exception as e:
        w(f"[Syntax] Fehler: {e} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    # Headless-Tests
    try:
        fails, total, log = run_detection_tests()
        w(log)
        if fails:
            w(f"[SUM] Detection-Tests FAIL: {fails}/{total} -> Rollback")
            shutil.copy2(bak, MODFILE)
            return 1
        w(f"[SUM] Alle Detection-Tests OK: {total}/{total}")
    except Exception as e:
        w(f"[Live] Fehler: {e} -> Rollback")
        shutil.copy2(bak, MODFILE)
        return 1

    w("[R1150] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
