# -*- coding: utf-8 -*-
"""
Runner_1107_AutoRepair_IndentBlocks
- Normalisiert Zeilenenden auf \n und Tabs -> 4 Spaces
- Härtet den Bereich der class IntakeFrame: jede nicht-leere Zeile innerhalb
  der Klasse erhält mindestens 4 Spaces Einrückung
- Fügt 'pass' hinter leeren Blockeinleitungen ein (def/if/for/while/try/except/finally/with/class),
  falls unmittelbar nichts eingerückt folgt
- Macht Backup; schreibt nur bei erfolgreichem Syntax-Compile
"""

from __future__ import annotations
import os, re, time, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")

BLOCK_START = re.compile(r"^\s*(def|if|for|while|try|except|finally|with|class|elif|else)\b.*:\s*$")

def backup(path: str) -> str:
    ts = int(time.time())
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    os.makedirs(ARCH, exist_ok=True)
    with open(path, "rb") as fsrc, open(dst, "wb") as fdst:
        fdst.write(fsrc.read())
    print(f"[R1107] Backup: {path} -> {dst}")
    return dst

def read(path: str) -> str:
    with open(path, "rb") as f:
        raw = f.read()
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("latin-1", errors="replace")

def write(path: str, txt: str) -> None:
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(txt)

def normalize(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = text.replace("\t", "    ")
    return text

def harden_intake_class(lines: list[str]) -> tuple[list[str], bool]:
    """
    Sucht 'class IntakeFrame' und stellt sicher, dass alle nachfolgenden
    nicht-leeren Zeilen bis zur nächsten top-level 'class ' mindestens
    4 Spaces Einrückung besitzen.
    """
    changed = False
    out = []
    in_class = False
    for i, line in enumerate(lines):
        if not in_class:
            out.append(line)
            # Eintritt in die Klasse?
            if re.match(r"^class\s+IntakeFrame\b.*:\s*$", line.strip()):
                in_class = True
            continue

        # wir sind innerhalb der Klasse, bis nächste top-level-Klasse (spalten-0 'class ')
        if line and not line.startswith(" ") and line.lstrip().startswith("class ") and not line.startswith("    "):
            # Neue Top-Level-Klasse -> Klasse verlassen
            in_class = False
            out.append(line)
            continue

        if line.strip() == "":
            out.append(line)
            continue

        # Kommentare/Dekoratoren innerhalb der Klasse ebenfalls mindestens 4 Spaces
        if not line.startswith("    "):  # weniger als 4 Spaces
            out.append("    " + line.lstrip("\n"))
            changed = True
        else:
            out.append(line)

    return out, changed

def ensure_block_bodies(lines: list[str]) -> tuple[list[str], bool]:
    """
    Fügt 'pass' ein, wenn auf eine Block-Einleitung direkt ein dedent/Leerzeile folgt.
    Das ist konservativ gehalten.
    """
    changed = False
    out = []
    i = 0
    n = len(lines)
    while i < n:
        out.append(lines[i])
        m = BLOCK_START.match(lines[i])
        if m:
            curr_indent = len(lines[i]) - len(lines[i].lstrip(" "))
            j = i + 1
            # Überspringe Leerzeilen/Kommentare
            while j < n and (lines[j].strip() == "" or lines[j].lstrip().startswith("#")):
                out.append(lines[j])
                j += 1
            if j >= n:
                # Datei endet direkt nach Blockeinleitung -> 'pass'
                out.append(" " * (curr_indent + 4) + "pass\n")
                changed = True
                i = j
                continue
            next_indent = len(lines[j]) - len(lines[j].lstrip(" "))
            if next_indent <= curr_indent and lines[j].strip() != "":
                # Kein eingerückter Body -> pass einfügen
                out.append(" " * (curr_indent + 4) + "pass\n")
                changed = True
                # continue normale Verarbeitung für Zeile j
            # Achtung: wir haben bereits bis j-1 (inkl. Leerzeilen/Kommentare) in out gepusht
            # -> wir müssen Zeile j NICHT doppelt schreiben
            # Wir setzen den Zeiger so, dass die Schleife bei j weiter macht
            i = j
            continue
        i += 1
    return out, changed

def main():
    if not os.path.exists(MOD):
        print(f"[R1107] ERROR: nicht gefunden: {MOD}")
        return 1

    src = normalize(read(MOD))
    orig = src

    lines = [ln if ln.endswith("\n") else ln + "\n" for ln in src.split("\n")]
    changed = False

    # 1) IntakeFrame härten (Einrückung >= 4 Spaces)
    lines, ch1 = harden_intake_class(lines); changed |= ch1
    # 2) Leere Blockeinleitungen absichern
    lines, ch2 = ensure_block_bodies(lines); changed |= ch2

    new_src = "".join(lines)
    if not changed:
        # trotzdem Syntax-Check: wenn defekte Einrückung existiert, melden
        try:
            compile(new_src, MOD, "exec")
            print("[R1107] Keine Änderungen nötig.")
            return 0
        except SyntaxError as e:
            print(f"[R1107] SyntaxError erkannt (ohne Änderung möglich): Zeile {e.lineno}: {e.msg}")
            # versuche wenigstens, Datei sauber zu speichern (normalisiert)
            backup(MOD)
            write(MOD, new_src)  # nur Normalisierung
            return 2

    # Nur schreiben, wenn Syntax sauber ist
    try:
        compile(new_src, MOD, "exec")
    except SyntaxError as e:
        print(f"[R1107] SyntaxError nach Auto-Repair in Zeile {e.lineno}: {e.msg}")
        print("[R1107] Datei bleibt UNVERÄNDERT.")
        return 2

    backup(MOD)
    write(MOD, new_src)
    print("[R1107] Auto-Repair angewendet (Einrückungen/Blöcke).")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
