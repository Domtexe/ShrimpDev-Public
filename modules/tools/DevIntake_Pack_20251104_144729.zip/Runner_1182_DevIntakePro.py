# -*- coding: utf-8 -*-
from __future__ import annotations
import time, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCH = ROOT / "_Archiv"
LOG  = ROOT / "debug_output.txt"
OUT  = ROOT / "modules" / "module_code_intake.py"

MOD_CODE = r"""
# -*- coding: utf-8 -*-
from __future__ import annotations
"""
# --- ab hier wird unten ersetzt ---
"""

DEV_INTAKE_CODE = r'''# -*- coding: utf-8 -*-
from __future__ import annotations
"""
ShrimpDev – Dev-Intake Pro (rein ShrimpDev, keine Hub-Vermischung)
- Editor (links), Dateiliste (rechts) mit Spalten: name, ext, subfolder, date, time
- Workspace, Name, Endung(.py/.bat/.txt), Zielordner (mit [...] wählen)
- Buttons: Editor leeren, Erkennen (Ctrl-I), Speichern (Ctrl-S), Einfügen,
          Aktualisieren, Prüfen(Guard), Repair, Run(F5), Pack speichern, Datei löschen
- F5 führt akt. Datei aus (.py -> py -3 -u; .bat -> direkt call)
- Logging nach debug_output.txt
"""
import os, sys, time, shutil, zipfile, traceback
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# --- Logging ---------------------------------------------------------------
def _log(pfx: str, msg: str) -> None:
    try:
        root = Path(__file__).resolve().parents[1]
        with open(root / "debug_output.txt", "a", encoding="utf-8", newline="\\n") as f:
            f.write(f"[DevIntake] {time.strftime('%Y-%m-%d %H:%M:%S')} [{pfx}] {msg}\\n")
    except Exception:
        pass

# --- Utils -----------------------------------------------------------------
def _fmt_time(ts: float) -> tuple[str, str]:
    lt = time.localtime(ts)
    return time.strftime("%Y-%m-%d", lt), time.strftime("%H:%M:%S", lt)

def _detect_ext_from_text(text: str) -> str:
    t = text.lstrip()
    if t.startswith("#!") or "import " in t or "def " in t or "print(" in t:
        return ".py"
    return ".txt"

def _safe_run(cmd: list[str]) -> None:
    try:
        import subprocess
        subprocess.Popen(cmd, cwd=os.getcwd(), creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
    except Exception as e:
        messagebox.showerror("Run", f"Start fehlgeschlagen:\\n{e}")
        _log("RUN_FAIL", str(e))

# --- Haupt-Widget ----------------------------------------------------------
class DevIntakePro(ttk.Frame):
    def __init__(self, nb: ttk.Notebook) -> None:
        super().__init__(nb)
        self.workspace = tk.StringVar(value=os.getcwd())
        self.target_dir = tk.StringVar(value=str(Path(os.getcwd()) / "tools"))
        self.name_var = tk.StringVar(value=f"snippet_{time.strftime('%Y%m%d_%H%M%S')}")
        self.ext_var = tk.StringVar(value=".py")
        self.status = tk.StringVar(value="Bereit.")
        self.current_path: Path|None = None
        self._build_ui()
        self._refresh_list()

    # ---------------- UI ----------------
    def _build_ui(self) -> None:
        top = ttk.Frame(self)
        top.pack(fill="x", padx=8, pady=6)

        ttk.Label(top, text="Workspace:").grid(row=0, column=0, sticky="w")
        ws = ttk.Entry(top, textvariable=self.workspace, width=48)
        ws.grid(row=0, column=1, sticky="we", padx=(4,4))
        ttk.Button(top, text="...", width=3, command=self._pick_workspace).grid(row=0, column=2, padx=(2,10))

        ttk.Label(top, text="Name:").grid(row=0, column=3, sticky="w")
        ttk.Entry(top, textvariable=self.name_var, width=28).grid(row=0, column=4, sticky="we", padx=(4,10))

        ttk.Label(top, text="Endung:").grid(row=0, column=5, sticky="w")
        cb = ttk.Combobox(top, textvariable=self.ext_var, values=[".py",".bat",".txt"], width=6, state="readonly")
        cb.grid(row=0, column=6, sticky="w", padx=(4,10))

        ttk.Label(top, text="Zielordner:").grid(row=0, column=7, sticky="e")
        ttk.Entry(top, textvariable=self.target_dir, width=40).grid(row=0, column=8, sticky="we", padx=(4,4))
        ttk.Button(top, text="...", width=3, command=self._pick_target).grid(row=0, column=9, padx=(2,0))

        top.columnconfigure(1, weight=2)
        top.columnconfigure(4, weight=1)
        top.columnconfigure(8, weight=2)

        # Button-Row 1
        row1 = ttk.Frame(self); row1.pack(fill="x", padx=8, pady=(0,6))
        ttk.Button(row1, text="Editor leeren", command=self._editor_clear).pack(side="left")
        ttk.Button(row1, text="Erkennen (Ctrl-I)", command=self._detect_name_ext).pack(side="left", padx=(6,0))
        ttk.Button(row1, text="Speichern (Ctrl-S)", command=self._save_current).pack(side="left", padx=(6,0))
        ttk.Button(row1, text="Einfügen", command=self._insert_as_new).pack(side="left", padx=(12,0))

        # Button-Row 2
        row2 = ttk.Frame(self); row2.pack(fill="x", padx=8, pady=(0,6))
        ttk.Button(row2, text="Aktualisieren", command=self._refresh_list).pack(side="left")
        ttk.Button(row2, text="Prüfen (Guard)", command=self._guard_check).pack(side="left", padx=(6,0))
        ttk.Button(row2, text="Repair", command=self._repair).pack(side="left", padx=(6,0))
        ttk.Button(row2, text="Run (F5)", command=self._run_current).pack(side="left", padx=(12,0))
        ttk.Button(row2, text="Pack speichern", command=self._save_pack).pack(side="left", padx=(12,0))
        ttk.Button(row2, text="Datei löschen", command=self._delete_current).pack(side="left", padx=(6,0))

        # Split
        split = ttk.Panedwindow(self, orient="horizontal")
        split.pack(fill="both", expand=True, padx=8, pady=(0,8))

        # Editor (links)
        left = ttk.Frame(split); split.add(left, weight=3)
        self.editor = tk.Text(left, wrap="none", undo=True)
        self.editor.pack(fill="both", expand=True)
        # Scrollbars
        vsb = ttk.Scrollbar(left, orient="vertical", command=self.editor.yview)
        hsb = ttk.Scrollbar(left, orient="horizontal", command=self.editor.xview)
        self.editor.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        vsb.pack(side="right", fill="y"); hsb.pack(side="bottom", fill="x")

        # Dateiliste (rechts)
        right = ttk.Frame(split); split.add(right, weight=2)
        cols = ("name","ext","subfolder","date","time")
        self.tree = ttk.Treeview(right, columns=cols, show="headings", selectmode="browse")
        for c,w in zip(cols,(260,60,140,100,80)):
            self.tree.heading(c, text=c)
            self.tree.column(c, width=w, anchor="w")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        # Statusbar
        ttk.Label(self, textvariable=self.status, anchor="w").pack(side="bottom", fill="x")

        # Shortcuts
        self.bind_all("<Control-s>", lambda e: self._save_current())
        self.bind_all("<Control-S>", lambda e: self._save_current())
        self.bind_all("<Control-i>", lambda e: self._detect_name_ext())
        self.bind_all("<F5>", lambda e: self._run_current())

    # --------------- Actions -----------------
    def _pick_workspace(self):
        d = filedialog.askdirectory(title="Workspace wählen", initialdir=self.workspace.get())
        if d: self.workspace.set(d)

    def _pick_target(self):
        d = filedialog.askdirectory(title="Zielordner wählen", initialdir=self.target_dir.get())
        if d: self.target_dir.set(d)

    def _editor_clear(self):
        self.editor.delete("1.0","end")
        self.status.set("Editor geleert.")

    def _detect_name_ext(self):
        txt = self.editor.get("1.0","end-1c")
        if not txt.strip():
            self.status.set("Nichts zu erkennen (Editor leer)."); return
        ext = _detect_ext_from_text(txt)
        stamp = time.strftime("%Y%m%d_%H%M%S")
        base = f"snippet_{stamp}"
        self.name_var.set(base); self.ext_var.set(ext)
        self.status.set(f"Erkannt: {base}{ext}")

    def _path_from_ui(self) -> Path:
        base = self.name_var.get().strip()
        ext  = self.ext_var.get().strip() or ".py"
        d    = Path(self.target_dir.get().strip() or (Path(os.getcwd())/"tools"))
        d.mkdir(parents=True, exist_ok=True)
        return d / f"{base}{ext}"

    def _insert_as_new(self):
        p = self._path_from_ui()
        if p.exists():
            if not messagebox.askyesno("Überschreiben?", f"{p.name} existiert. Überschreiben?"):
                return
        txt = self.editor.get("1.0","end-1c")
        p.write_text(txt, encoding="utf-8")
        self.current_path = p
        self._refresh_list(select=p)
        self.status.set(f"Eingefügt: {p}")

    def _save_current(self):
        if self.current_path is None:
            self._insert_as_new(); return
        txt = self.editor.get("1.0","end-1c")
        self.current_path.write_text(txt, encoding="utf-8")
        self._refresh_list(select=self.current_path)
        self.status.set(f"Gespeichert: {self.current_path.name}")

    def _refresh_list(self, select: Path|None=None):
        self.tree.delete(*self.tree.get_children())
        root = Path(self.target_dir.get() or (Path(os.getcwd())/"tools"))
        if not root.exists(): root.mkdir(parents=True, exist_ok=True)
        for p in sorted(root.rglob("*")):
            if p.is_file():
                sub = str(p.parent.relative_to(root)) if p.parent != root else ""
                date, tm = _fmt_time(p.stat().st_mtime)
                self.tree.insert("", "end", iid=str(p), values=(p.stem, p.suffix, sub, date, tm))
        if select and str(select) in self.tree.get_children(""):
            self.tree.selection_set(str(select))
        self.status.set(f"{root} aktualisiert.")

    def _on_select(self, _evt=None):
        sel = self.tree.selection()
        if not sel: return
        p = Path(sel[0])
        try:
            txt = p.read_text(encoding="utf-8", errors="replace")
            self.editor.delete("1.0","end"); self.editor.insert("1.0", txt)
            self.current_path = p
            self.name_var.set(p.stem); self.ext_var.set(p.suffix or ".txt")
            tgt = str(p.parent if p.parent.name!="." else self.target_dir.get())
            self.target_dir.set(str(p.parent))
            self.status.set(f"Geladen: {p}")
        except Exception as e:
            messagebox.showerror("Laden", f"{e}")
            _log("LOAD_FAIL", str(e))

    def _run_current(self):
        p = self.current_path
        if not p or not p.exists():
            messagebox.showinfo("Run", "Keine Datei ausgewählt."); return
        if p.suffix == ".py":
            _safe_run(["py","-3","-u",str(p)])
        elif p.suffix == ".bat":
            _safe_run([str(p)])
        else:
            messagebox.showinfo("Run", "Nur .py oder .bat werden direkt gestartet.")

    def _guard_check(self):
        # minimales Syntax-/Shebang-Guarding
        p = self.current_path
        if not p or not p.exists():
            messagebox.showinfo("Guard", "Keine Datei ausgewählt."); return
        if p.suffix == ".py":
            try:
                src = p.read_text(encoding="utf-8")
                compile(src, p.name, "exec")
                messagebox.showinfo("Guard", "Syntax OK.")
            except Exception as e:
                messagebox.showerror("Guard", f"Syntaxfehler:\\n{e}")
        else:
            messagebox.showinfo("Guard", "Guard prüft nur .py")

    def _repair(self):
        # Platzhalter: hier können spezifische Auto-Fixes rein. aktuell: Trim BOM/CRLF
        p = self.current_path
        if not p or not p.exists(): return
        try:
            txt = p.read_text(encoding="utf-8", errors="replace")
            p.write_text(txt.replace("\\r\\r\\n","\\r\\n"), encoding="utf-8", newline="\\r\\n")
            messagebox.showinfo("Repair", "Kleiner Normalizer angewendet.")
        except Exception as e:
            messagebox.showerror("Repair", f"{e}")

    def _save_pack(self):
        root = Path(self.target_dir.get())
        if not root.exists(): return
        ts = time.strftime("%Y%m%d_%H%M%S")
        zf = Path(os.getcwd())/f"DevIntake_Pack_{ts}.zip"
        with zipfile.ZipFile(zf, "w", zipfile.ZIP_DEFLATED) as z:
            for p in root.rglob("*"):
                if p.is_file():
                    z.write(p, p.relative_to(root))
        messagebox.showinfo("Pack", f"Pack gespeichert:\\n{zf}")
        self.status.set(f"Pack gespeichert: {zf.name}")

    def _delete_current(self):
        p = self.current_path
        if not p or not p.exists():
            return
        if not messagebox.askyesno("Löschen", f"{p.name} wirklich löschen?"):
            return
        try:
            p.unlink()
            self.current_path = None
            self.editor.delete("1.0","end")
            self._refresh_list()
            self.status.set("Datei gelöscht.")
        except Exception as e:
            messagebox.showerror("Löschen", f"{e}")

# --- API für Shim ----------------------------------------------------------
def create_intake_tab(nb: ttk.Notebook) -> None:
    try:
        frame = DevIntakePro(nb)
        nb.add(frame, text="Intake")
    except Exception:
        import traceback
        f = ttk.Frame(nb)
        ttk.Label(f, text="Intake – Fehler beim Laden (Details im Log).", foreground="red").pack(padx=12, pady=12, anchor="w")
        nb.add(f, text="Intake")
        traceback.print_exc()
'''

def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")

def log(msg: str) -> None:
    with open(LOG, "a", encoding="utf-8", newline="\n") as f:
        f.write(f"[R1182] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")

def main() -> int:
    ARCH.mkdir(exist_ok=True)
    if OUT.exists():
        bak = ARCH / f"module_code_intake.py.{time.strftime('%Y%m%d_%H%M%S')}.bak"
        bak.write_text(OUT.read_text(encoding="utf-8"), encoding="utf-8")
        log(f"Backup: {bak}")
    write(OUT, DEV_INTAKE_CODE)
    try:
        compile(DEV_INTAKE_CODE, "module_code_intake.py", "exec")
    except Exception as e:
        log(f"SyntaxError: {e}")
        return 2
    log("Dev-Intake Pro installiert.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
