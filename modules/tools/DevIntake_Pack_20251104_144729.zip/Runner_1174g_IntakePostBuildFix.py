import re, io, os, sys

ROOT = r"D:\ShrimpDev"
MOD  = os.path.join(ROOT, r"modules\module_code_intake.py")

with io.open(MOD, "r", encoding="utf-8", errors="ignore") as f:
    src = f.read()

orig = src

# 1) Fehlplatzierte Klassen-Level-Aufrufe neutralisieren
#    Beispiele:
#      _intake_post_build_bind_clear(self)
#      self._intake_post_build_bind_clear(self)  (manchmal doppelt)
#    -> Wir kommentieren **nur** freie Zeilen ohne weiteren Code.
pattern_stray_calls = re.compile(
    r"(?m)^[ \t]*(?:self\.)?_intake_post_build_bind_clear\s*\(\s*self?\s*\)\s*$"
)
src = pattern_stray_calls.sub("        # [1174g] stray call entfernt (nach _build_ui verlegt)", src)

# 2) Sicheren Hook am Ende von _build_ui(self) einhängen,
#    **vor** dem Helpers-Abschnitt, falls vorhanden.
hook = (
    "\n"
    "        # [1174g] Post-Build-Hook (failsafe)\n"
    "        try:\n"
    "            if hasattr(self, '_intake_post_build_bind_clear'):\n"
    "                self._intake_post_build_bind_clear()\n"
    "        except Exception:\n"
    "            pass\n"
    "        for _fn in ('_intake_bind_wiring','_intake_bind_shortcuts','_intake_layout_polish'):\n"
    "            try:\n"
    "                _cb = getattr(self, _fn, None)\n"
    "                if callable(_cb):\n"
    "                    _cb()\n"
    "            except Exception:\n"
    "                pass\n"
    )

# Einfügepunkt suchen: Ende von def _build_ui(self)
m = re.search(
    r"(^[ \t]*def\s+_build_ui\s*\(\s*self\s*\)\s*:[\s\S]*?)(?=^\s*#\s*-{4,}\s*helpers\s*-{4,}|^\s*def\s|\Z)",
    src, flags=re.M
)
if m:
    block = m.group(1)
    if hook.strip() not in block:
        block_pat = re.escape(block)
        src = src.replace(block, block.rstrip() + hook + "\n")
else:
    # Fallback: vor Helpers-Marker allgemein einfügen, falls vorhanden
    src = re.sub(
        r"(?m)^(?=\s*#\s*-{4,}\s*helpers\s*-{4,})",
        hook + "\n",
        src, count=1
    )

# 3) Optional: sanfte NO-OP-Definitionen ergänzen, falls Methoden völlig fehlen
def ensure_method(name):
    global src
    if not re.search(rf"^[ \t]*def\s+{name}\s*\(\s*self\s*\)\s*:", src, flags=re.M):
        src += (
            "\n\n"
            f"    # [1174g] failsafe: fehlende Methode {name} als NO-OP\n"
            f"    def {name}(self):\n"
            f"        try:\n"
            f"            pass\n"
            f"        except Exception:\n"
            f"            pass\n"
        )

# Nur ergänzen, wenn Klasse IntakeFrame existiert.
if re.search(r"^[ \t]*class\s+IntakeFrame\s*\(", src, flags=re.M):
    for missing in ("_intake_post_build_bind_clear",
                    "_intake_bind_wiring",
                    "_intake_bind_shortcuts",
                    "_intake_layout_polish"):
        ensure_method(missing)

# Schreiben, wenn geändert
if src != orig:
    with io.open(MOD, "w", encoding="utf-8", newline="") as f:
        f.write(src)
    print("[1174g] Änderungen geschrieben.")
else:
    print("[1174g] Keine Änderung notwendig.")
