# -*- coding: utf-8 -*-
"""
Runner_1170e_IntakeLifecycleWire
Fügt am Ende von _build_ui(self) einen Lifecycle-Block ein, der
_intake_bind_wiring(), _intake_bind_shortcuts() und _intake_layout_polish()
aufruft. Idempotent, mit Backup, Syntax-Check und Rollback.
Exit: 0 OK, 1 Fehler
"""
from __future__ import annotations
import os, re, time, py_compile, traceback

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOG    = os.path.join(ROOT, "debug_output.txt")

MARK = "# R1170e: lifecycle wire"

BLOCK_TEMPLATE = """{indent}    {MARK}
{indent}    try:
{indent}        _intake_bind_wiring(self)
{indent}        _intake_bind_shortcuts(self)
{indent}        _intake_layout_polish(self)
{indent}    except Exception:
{indent}        pass
"""

def _log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1170e {ts}] {msg}\n"
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def _backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "r", encoding="utf-8") as fi, open(dst, "w", encoding="utf-8", newline="") as fo:
        fo.write(fi.read())
    return dst

def main() -> int:
    try:
        if not os.path.exists(TARGET):
            _log(f"Zieldatei fehlt: {TARGET}")
            return 1

        src = open(TARGET, "r", encoding="utf-8").read()

        # Bereits vorhanden?
        if MARK in src:
            _log("Lifecycle-Block bereits vorhanden – keine Änderung.")
            return 0

        # --- _build_ui(self) lokalisieren (Indent-robust) ---
        m = re.search(r"(?m)^([ \t]*)def[ \t]+_build_ui[ \t]*\(\s*self[^)]*\)\s*:\s*$", src)
        if not m:
            _log("Konnte 'def _build_ui(self):' nicht finden – Abbruch ohne Änderung.")
            return 1

        base_indent = m.group(1)  # Einrückung der def-Zeile (i. d. R. 8 Spaces innerhalb der Klasse)
        start = m.end()

        # Ende des Funktionsblocks: nächste 'def' oder 'class' auf gleicher Einrückungsebene ODER EOF
        pat_end = re.compile(r"(?m)^(%s)(def|class)\b" % re.escape(base_indent))
        m_end = pat_end.search(src, start)
        end = m_end.start() if m_end else len(src)

        # Sicherheitscheck: Ist der Block schon drin?
        if MARK in src[start:end]:
            _log("Lifecycle-Block befindet sich bereits in _build_ui – keine Änderung.")
            return 0

        # Einfügen VOR dem ermittelten Funktionsende
        insert_pos = end
        block = BLOCK_TEMPLATE.format(indent=base_indent, MARK=MARK)

        new_src = src[:insert_pos].rstrip("\n") + "\n" + block + src[insert_pos:]

        # Backup + Schreiben + Syntaxcheck
        bak = _backup(TARGET)
        _log(f"Backup erstellt: {bak}")

        with open(TARGET, "w", encoding="utf-8", newline="\n") as f:
            f.write(new_src)

        try:
            py_compile.compile(TARGET, doraise=True)
        except Exception as e:
            # Rollback
            with open(bak, "r", encoding="utf-8") as fi, open(TARGET, "w", encoding="utf-8", newline="\n") as fo:
                fo.write(fi.read())
            _log("Syntax-Check FEHLER -> Rollback auf Backup.")
            _log("Traceback:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 1

        _log("Patch erfolgreich eingefügt und Syntax-Check OK.")
        return 0

    except Exception as e:
        _log("UNERWARTETER FEHLER:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
