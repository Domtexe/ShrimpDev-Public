# -*- coding: utf-8 -*-
"""
Runner_1177i_ImportPathFix
Zweck:
- In main_gui.py alle *nicht paketierten* Importe von `module_code_intake`
  auf `from modules import module_code_intake` umstellen (Alias bleibt erhalten).
- Präziser Regex: nur Zeilen mit `import module_code_intake...` am Zeilenanfang.
- Backup in _Archiv/, Logging in debug_output.txt.
"""
from __future__ import annotations
import os, re, datetime, shutil

ROOT = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
ARCH = os.path.join(ROOT, "_Archiv")
LOGF = os.path.join(ROOT, "debug_output.txt")
TARGET = os.path.join(ROOT, "main_gui.py")

def ts(): return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def log(msg: str):
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(f"[{ts()}] [R1177i] {msg}\n")
    except Exception:
        pass

def backup(path: str) -> str | None:
    if not os.path.exists(path):
        return None
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(path)}.{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.bak")
    shutil.copy2(path, bak)
    log(f"Backup: {bak}")
    return bak

def patch_imports(src: str) -> tuple[str, int]:
    """
    Wandelt nur Zeilen der Form:
        import module_code_intake
        import module_code_intake as intake
    zu:
        from modules import module_code_intake
        from modules import module_code_intake as intake
    um. Bereits korrekte Importe werden NICHT verändert.
    """
    changed = 0

    def repl(m: re.Match) -> str:
        nonlocal changed
        alias = m.group("alias") or ""
        changed += 1
        return f"from modules import module_code_intake{alias}"

    pattern = re.compile(
        r"^(?P<indent>\s*)import\s+module_code_intake(?P<alias>\s+as\s+\w+)?\s*$",
        re.MULTILINE
    )

    def repl_with_indent(m: re.Match) -> str:
        return m.group("indent") + repl(m)

    out, n = pattern.subn(repl_with_indent, src)
    changed += 0  # `n` wird über repl gezählt
    return out, n

def sanity_compile(py_path: str) -> tuple[bool, str]:
    try:
        src = open(py_path, "r", encoding="utf-8").read()
        compile(src, py_path, "exec")
        return True, "OK"
    except SyntaxError as e:
        return False, f"SYNTAX: {e.msg} @ {e.lineno}:{e.offset}"
    except Exception as e:
        return False, f"ERROR: {e}"

def main() -> int:
    if not os.path.exists(TARGET):
        print("[R1177i] main_gui.py nicht gefunden.")
        log("main_gui.py missing.")
        return 2

    src = open(TARGET, "r", encoding="utf-8").read()
    new_src, n = patch_imports(src)

    if n == 0:
        log("Keine unpaketierten Imports gefunden (n=0).")
    else:
        backup(TARGET)
        with open(TARGET, "w", encoding="utf-8") as f:
            f.write(new_src)
        log(f"Importe korrigiert: {n}")

    ok, info = sanity_compile(TARGET)
    log(f"SanityCompile main_gui.py -> {info}")
    if not ok:
        print(f"[R1177i] Sanity-Compile FEHLER: {info}")
        return 3

    print("[R1177i] ImportPathFix applied.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
