# R905 – Fix toggle_quiet() indentation & quotes in D:\ShrimpDev\main_gui.py
from __future__ import annotations
import re, shutil, time
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
MAIN = ROOT / "main_gui.py"

def ts():
    return time.strftime("%Y%m%d_%H%M%S")

def main():
    if not MAIN.exists():
        print(f"[R905] NICHT GEFUNDEN: {MAIN}")
        return 2

    src = MAIN.read_text(encoding="utf-8", errors="ignore")
    bak = MAIN.with_name(f"{MAIN.stem}.{ts()}.bak")
    shutil.copy2(MAIN, bak)
    print(f"[R905] Backup: {bak.name}")

    # 1) toggle_quiet() sauber einsetzen/ersetzen
    new_func = (
        "\n    def toggle_quiet(self):\n"
        "        try:\n"
        "            self.quiet = bool(self.var_quiet.get())\n"
        "            self.conf['quiet_mode'] = self.quiet\n"
        "            save_config(self.conf)\n"
        "            self.status.set(f\"Quiet Mode: {'ON' if self.quiet else 'OFF'}\")\n"
        "            try:\n"
        "                from modules.snippets.agent_client import send_event\n"
        "                send_event({'runner':'ShrimpDev','level':'INFO','msg':f'Quiet Mode set to {self.quiet}'})\n"
        "            except Exception:\n"
        "                pass\n"
        "        except Exception:\n"
        "            pass\n"
    )

    # ersetze def toggle_quiet(...) bis vor dem __main__-Block
    pat = re.compile(
        r"\n\s*def\s+toggle_quiet\s*\(self\)\s*:[\s\S]*?(?=\n\s*if\s+__name__\s*==\s*['\"]__main__['\"])",
        re.M,
    )
    if pat.search(src):
        src2 = pat.sub(new_func + "\n", src)
        changed = True
    else:
        # falls es die Funktion gar nicht gibt, vor dem __main__-Block einfügen
        m = re.search(r"\n\s*if\s+__name__\s*==\s*['\"]__main__['\"]\s*:", src)
        if m:
            src2 = src[:m.start()] + new_func + src[m.start():]
            changed = True
        else:
            src2 = src
            changed = False

    # 2) falsches Binding "^<Control-i>" → "<Control-i>"
    src3 = re.sub(r'"\^?<Control-i>"', '"<Control-i>"', src2)

    # Nur schreiben, wenn sich etwas geändert hat
    if src3 != src:
        MAIN.write_text(src3, encoding="utf-8")
        print("[R905] toggle_quiet repariert und Bindings geprüft.")
        return 0
    else:
        print("[R905] Keine Änderungen nötig.")
        return 0

if __name__ == "__main__":
    raise SystemExit(main())
