# -*- coding: utf-8 -*-
"""
Runner_1170a_IntakeRegression
Headless-Checks für den Intake-Tab (ohne I/O, ohne Ausführung von Button-Commands).
Prüft:
- Kern-Widgets vorhanden?
- Buttons vorhanden & 'command' verdrahtet (nur Präsenz, nicht ausführen)
- Tastenkürzel gebunden? (Ctrl+S / Ctrl+I / Ctrl+O / Del)
- Tabelle hat Doppelklick-Binding?
Ergebnis -> debug_output.txt
Exitcodes:
 0 = alle Kernprüfungen OK (Buttons/Bindings können teilweise fehlen -> WARN)
 2 = kritische Kern-Widgets fehlen
"""
from __future__ import annotations
import os, sys, time, traceback, importlib
from typing import Dict, List

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
LOGFILE = os.path.join(ROOT, "debug_output.txt")

def _log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1170a {ts}] {msg}\n"
    try:
        with open(LOGFILE, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def _has_binding(widget, sequence: str) -> bool:
    # Tkinter .bind(seq) gibt None oder eine Script-String zurück
    try:
        return bool(widget.bind(sequence))
    except Exception:
        return False

def main() -> int:
    os.chdir(ROOT)
    sys.path.insert(0, ROOT)
    _log("=== Intake Regression (Verdrahtung) START ===")

    try:
        import tkinter as tk
        from tkinter import ttk  # noqa: F401
    except Exception as e:
        _log(f"Tk-Import FEHLER: {e}")
        _log(traceback.format_exc())
        return 2

    # Modul & Klasse laden
    try:
        mod = importlib.import_module("modules.module_code_intake")
        IntakeFrame = getattr(mod, "IntakeFrame")
    except Exception as e:
        _log(f"Import FEHLER (Intake): {e}")
        _log(traceback.format_exc())
        return 2

    # Headless Tk
    root = tk.Tk()
    root.withdraw()

    try:
        frame = IntakeFrame(root)
    except Exception as e:
        _log(f"Instanzierung FEHLER: {e}")
        _log(traceback.format_exc())
        try: root.destroy()
        except Exception: pass
        return 2

    # --- Kern-Widgets prüfen ---
    core = {
        "frm_actions": hasattr(frame, "frm_actions"),
        "txt": hasattr(frame, "txt"),
        "tbl": hasattr(frame, "tbl"),
        "lbl_ping": hasattr(frame, "lbl_ping"),
        "var_ws": hasattr(frame, "var_ws"),
        "var_name": hasattr(frame, "var_name"),
        "var_ext": hasattr(frame, "var_ext"),
    }
    for k, v in core.items():
        _log(f"Core {k}: {'OK' if v else 'FEHLT'}")

    if not all(core[x] for x in ("txt", "tbl", "frm_actions")):
        _log("KRITISCH: mindestens eines der Kern-Widgets fehlt (txt/tbl/frm_actions).")
        try:
            frame.destroy(); root.destroy()
        except Exception:
            pass
        _log("=== Intake Regression ENDE (KRITISCH) ===")
        return 2

    # --- Buttons finden & 'command' prüfen (nicht ausführen!) ---
    btn_info: List[str] = []
    wired, missing = 0, 0
    for name in dir(frame):
        if name.startswith("btn_"):
            try:
                btn = getattr(frame, name)
                # in Tkinter liefert .cget('command') None oder ein callable (oder Tcl-String) – wir prüfen nur Präsenz
                cmd = None
                try:
                    cmd = btn.cget("command")
                except Exception:
                    # ttk kann None liefern oder Fehler, dann ignorieren
                    cmd = None
                ok = cmd is not None and cmd != ""
                wired += int(ok)
                missing += int(not ok)
                btn_info.append(f"{name}: {'command vorhanden' if ok else 'KEIN command'}")
            except Exception:
                btn_info.append(f"{name}: FEHLER beim Zugriff")
                missing += 1
    if btn_info:
        for line in btn_info:
            _log(f"Button {line}")
    else:
        _log("WARN: Keine btn_*-Attribute gefunden.")

    # --- Key-Bindings prüfen ---
    bindings_expect = {
        "<Control-s>": "Save",
        "<Control-i>": "Detect/Identify",
        "<Control-o>": "Open",
        "<Delete>": "Clear/Delete",
    }
    # Wir prüfen auf root- und frame-Ebene
    for seq, label in bindings_expect.items():
        present = _has_binding(root, seq) or _has_binding(frame, seq) or _has_binding(getattr(frame, "txt", frame), seq)
        _log(f"KeyBinding {seq} ({label}): {'OK' if present else 'FEHLT'}")

    # --- Doppelklick Tabelle ---
    dbl_tbl = False
    try:
        tbl = getattr(frame, "tbl")
        dbl_tbl = _has_binding(tbl, "<Double-1>")
    except Exception:
        pass
    _log(f"Binding tbl <Double-1> (Open/Preview): {'OK' if dbl_tbl else 'FEHLT'}")

    # Zusammenfassung
    _log(f"Buttons verdrahtet: {wired}, ohne command: {missing}")
    _log("=== Intake Regression ENDE ===")

    # Cleanup
    try:
        frame.destroy()
    except Exception:
        pass
    try:
        root.destroy()
    except Exception:
        pass

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
