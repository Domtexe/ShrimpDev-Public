# -*- coding: utf-8 -*-
"""
Runner_1072_InsertRunButton_AnyAnchor
Fügt den Button "Ausführen (F5)" robust in die Intake-Toolbar ein,
selbst wenn btn_guard/btn_save.grid nicht vorhanden sind.
Anker: vor 'body = ttk.Panedwindow(...)'.
Voraussetzung: _on_click_run() und F5-Bind sind bereits vorhanden (Runner_1071).
"""

from __future__ import annotations
import os, re, time, shutil, ast

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1072] {ts} {msg}\n")
    except Exception:
        pass

def read(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def backup_write(p: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bak)
    log(f"Backup: {p} -> {bak}")
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

def normalize(src: str) -> str:
    src = src.replace("\r\n", "\n").replace("\r", "\n")
    src = "\n".join(ln.rstrip(" \t") for ln in src.split("\n"))
    src = src.replace("\t", "    ")
    if not src.endswith("\n"):
        src += "\n"
    return src

def insert_run_before_body(src: str) -> tuple[str, int]:
    """Button vor 'body = ttk.Panedwindow' einfügen."""
    if "self.btn_run" in src:
        return src, 0

    # 1) Toolbar-Beginn suchen
    m_bar = re.search(r'^([ \t]*)bar\s*=\s*ttk\.Frame\(self\)\s*$', src, re.MULTILINE)
    if not m_bar:
        log("WARN: Keine Toolbar-Zeile 'bar = ttk.Frame(self)' gefunden.")
        return src, 0
    indent = m_bar.group(1)

    # 2) Einfügepunkt: Linie mit 'body = ttk.Panedwindow(' nach der Toolbar
    m_body = re.search(r'^[ \t]*body\s*=\s*ttk\.Panedwindow\(', src[m_bar.end():], re.MULTILINE)
    if m_body:
        insert_pos = m_bar.end() + m_body.start()
    else:
        # Fallback: vor Beginn der nächsten Methode innerhalb der Klasse
        m_next_def = re.search(r'^\s*def\s+[A-Za-z_]\w*\s*\(', src[m_bar.end():], re.MULTILINE)
        insert_pos = m_bar.end() + (m_next_def.start() if m_next_def else 0)

    code = (
        f"{indent}self.btn_run = ttk.Button(bar, text=\"Ausführen (F5)\", command=self._on_click_run)\n"
        f"{indent}self.btn_run.grid(row=0, column=98, padx=(4,0))\n"
    )
    s = src[:insert_pos] + code + src[insert_pos:]
    log("Run-Button vor Panedwindow eingefügt.")
    return s, 1

def main() -> int:
    if not os.path.exists(MOD):
        log(f"Datei fehlt: {MOD}")
        return 2

    src0 = read(MOD)
    s = normalize(src0)

    s, n = insert_run_before_body(s)

    try:
        ast.parse(s)
    except SyntaxError as e:
        log(f"SyntaxError nach Patch: {e} (line {e.lineno}, col {getattr(e,'offset',0)})")
        lines = s.split("\n")
        a, b = max(1, (e.lineno or 1)-10), min(len(lines), (e.lineno or 1)+10)
        log("--- DUMP ---")
        for i in range(a, b+1):
            vis = lines[i-1].replace("\t", "→").replace(" ", "·")
            log(f"{i:04d}: {vis}")
        log("--- END DUMP ---")
        return 3

    if n == 0 and s == src0:
        log("Keine Änderungen nötig.")
        return 0

    backup_write(MOD, s)
    log(f"Patch gespeichert. Änderungen: {n}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
