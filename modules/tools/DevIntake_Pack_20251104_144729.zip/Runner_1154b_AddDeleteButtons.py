# -*- coding: utf-8 -*-
"""
Runner_1154b_AddDeleteButtons
Fix: keine nonlocal-Nutzung mehr; Änderungen am Klassenblock erfolgen
über Rückgaben (funktionaler Stil).
Funktion: Fügt zwei Buttons in IntakeFrame hinzu:
- "Editor leeren" (links)
- "Datei löschen" (rechts)
Sicher: Backup -> Write -> Syntaxcheck -> Import-Smoke -> Rollback.
"""
from __future__ import annotations
import io, os, sys, time, shutil, ast, importlib.util, types, re
from pathlib import Path
import py_compile

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1154_AddDeleteButtons_report.txt"

def log(s=""):
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f: f.write(s.rstrip()+"\n")
    print(s)

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time()*1000)}.bak"
    shutil.copy2(p, dst)
    return dst

CLEAR_AND_DELETE_METHODS = r'''
def _on_clear_editor(self):
    """Löscht den gesamten Inhalt des Editors – mit Sicherheitsabfrage."""
    try:
        import tkinter.messagebox as mb
        txt = self.txt.get("1.0","end-1c")
        if not txt:
            self._ping("Editor ist bereits leer.")
            return
        if not mb.askyesno("Bestätigen", "Editor-Inhalt vollständig löschen?"):
            return
        self.txt.delete("1.0","end")
        self._ping("Editor geleert.")
        try:
            self.var_name_manual = False
            self.var_ext_manual = False
        except Exception:
            pass
    except Exception as ex:
        try: self._ping(f"Clear-Fehler: {ex}")
        except Exception: pass

def _on_delete_selected_file(self):
    """Löscht die aktuell markierte/ausgewählte Datei (rechte Liste)."""
    import os
    try:
        import tkinter.messagebox as mb
    except Exception:
        mb = None
    try:
        p = None
        try:
            if hasattr(self, "_path_from_selection_or_fields"):
                p = self._path_from_selection_or_fields()
        except Exception:
            p = None
        if not p:
            try:
                tgt = self.var_target.get().strip()
                nm  = self.var_name.get().strip()
                ext = self.var_ext.get().strip()
                if nm and ext:
                    p = os.path.join(tgt, f"{nm}{ext}")
            except Exception:
                p = None

        if not p or not os.path.exists(p):
            self._ping("Keine gültige Datei ausgewählt.")
            return
        base = os.path.basename(p)
        ok = True
        if mb is not None:
            ok = mb.askyesno("Datei löschen", f"„{base}“ endgültig löschen?")
        if not ok:
            return

        try:
            os.remove(p)
            self._ping(f"Gelöscht: {base}")
        except PermissionError:
            try:
                os.chmod(p, 0o666)
                os.remove(p)
                self._ping(f"Gelöscht: {base}")
            except Exception as ex2:
                self._ping(f"Lösch-Fehler: {ex2}")
                return
        except Exception as ex:
            self._ping(f"Lösch-Fehler: {ex}")
            return

        try:
            if hasattr(self, "_refresh_table"):
                self._refresh_table()
            elif hasattr(self, "btn_guard") and callable(getattr(self, "_detect_guarded", None)):
                try: self._detect_guarded()
                except Exception: pass
        except Exception:
            pass
    except Exception as ex:
        try: self._ping(f"Lösch-Handler-Fehler: {ex}")
        except Exception: pass
'''.strip("\n")

def patch_add_buttons(src: str) -> tuple[str, list[str]]:
    changes = []
    tree = ast.parse(src)
    cls = None
    for n in tree.body:
        if isinstance(n, ast.ClassDef) and n.name == "IntakeFrame":
            cls = n; break
    if not cls:
        raise RuntimeError("class IntakeFrame nicht gefunden.")

    lines = src.splitlines()
    start = cls.lineno - 1
    end   = getattr(cls, "end_lineno", None) or len(lines)
    cls_src = "\n".join(lines[start:end])

    # -- 1) Methoden ergänzen/ersetzen (funktional, ohne nonlocal)
    def upsert_block(class_src: str, func_name: str) -> tuple[str, bool, bool]:
        """returns: (new_src, added, replaced)"""
        added = replaced = False
        rx = re.compile(r'(?ms)^\s*def\s+'+re.escape(func_name)+r'\s*\([^)]*\):\s*(?:\n\s+.+?)(?=^\s*def\s+\w+\s*\(|\Z)')
        if rx.search(class_src):
            # aus CLEAR_AND_DELETE_METHODS den Funktionsblock extrahieren
            block_rx = re.compile(r'(?ms)^def\s+'+re.escape(func_name)+r'\s*\([^)]*\):\s*(?:\n.+?)(?=^def\s+|\Z)')
            m2 = block_rx.search(CLEAR_AND_DELETE_METHODS)
            if m2:
                new_block = "\n    " + m2.group(0).replace("\n", "\n    ") + "\n"
                class_src = rx.sub(new_block, class_src, count=1)
                replaced = True
        else:
            block_rx = re.compile(r'(?ms)^def\s+'+re.escape(func_name)+r'\s*\([^)]*\):\s*(?:\n.+?)(?=^def\s+|\Z)')
            m2 = block_rx.search(CLEAR_AND_DELETE_METHODS)
            if m2:
                if not class_src.endswith("\n"):
                    class_src += "\n"
                class_src += "\n    " + m2.group(0).replace("\n", "\n    ") + "\n"
                added = True
        return class_src, added, replaced

    cls_src, a1, r1 = upsert_block(cls_src, "_on_clear_editor")
    if a1: changes.append("added:_on_clear_editor")
    if r1: changes.append("replaced:_on_clear_editor")

    cls_src, a2, r2 = upsert_block(cls_src, "_on_delete_selected_file")
    if a2: changes.append("added:_on_delete_selected_file")
    if r2: changes.append("replaced:_on_delete_selected_file")

    # -- 2) Toolbar-Buttons einbauen
    if 'btn_clear_editor' not in cls_src:
        insert_marker = 'self.btn_run.grid'
        if insert_marker in cls_src:
            cls_src = cls_src.replace(
                insert_marker,
                insert_marker + "\n"
                "        # neue Buttons: Editor leeren & Datei löschen\n"
                "        try:\n"
                "            self.btn_clear_editor = ttk.Button(bar, text='Editor leeren', command=self._on_clear_editor)\n"
                "            self.btn_delete_file   = ttk.Button(bar, text='Datei löschen', command=self._on_delete_selected_file)\n"
                "            self.btn_clear_editor.grid(row=0, column=120, padx=(12,0), sticky='w')\n"
                "            self.btn_delete_file.grid(  row=0, column=121, padx=(6,0),  sticky='w')\n"
                "        except Exception:\n"
                "            pass"
            )
            changes.append("added:toolbar_buttons")
        else:
            rx_build = re.compile(r'(?ms)^\s*def\s+_build_ui\s*\([^)]*\):\s*\n(.*?)^\s*def\s+', re.DOTALL)
            m = rx_build.search(cls_src)
            if m:
                body = m.group(1)
                body2 = body + (
                    "\n        # neue Buttons (Fallback-Platzierung)\n"
                    "        try:\n"
                    "            self.btn_clear_editor = ttk.Button(bar, text='Editor leeren', command=self._on_clear_editor)\n"
                    "            self.btn_delete_file   = ttk.Button(bar, text='Datei löschen', command=self._on_delete_selected_file)\n"
                    "            self.btn_clear_editor.grid(row=0, column=120, padx=(12,0), sticky='w')\n"
                    "            self.btn_delete_file.grid(  row=0, column=121, padx=(6,0),  sticky='w')\n"
                    "        except Exception:\n"
                    "            pass\n"
                )
                cls_src = cls_src[:m.start(1)] + body2 + cls_src[m.end(1):]
                changes.append("added:toolbar_buttons_fallback")

    new_src = "\n".join(lines[:start]) + ("\n" if start else "") + cls_src + ("\n" if end < len(lines) else "") + "\n".join(lines[end:])
    return new_src, changes

def import_smoke()->tuple[bool,str]:
    # nur Import (ohne Tk-Loop)
    if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
    try:
        pkgname = "modules.module_runner_exec"
        try:
            import modules.module_runner_exec  # noqa
        except Exception:
            pkg = types.ModuleType("modules"); sys.modules.setdefault("modules", pkg)
            mod = types.ModuleType(pkgname); mod.run = lambda *a, **k: 0; mod._log = lambda *a, **k: None
            sys.modules[pkgname] = mod

        spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
        m = importlib.util.module_from_spec(spec); assert spec and spec.loader
        spec.loader.exec_module(m)  # type: ignore[attr-defined]
        return True, "Import OK"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"

def main()->int:
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass
    log("[R1154b] AddDeleteButtons – Start")

    if not MODFILE.exists():
        log("[ERR] module_code_intake.py fehlt.")
        return 1

    bak = backup(MODFILE); log(f"[Backup] {bak.name}")
    src = io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

    try:
        new_src, changes = patch_add_buttons(src)
    except Exception as e:
        log(f"[ERR] Patch-Vorbereitung: {e}")
        return 1

    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(new_src)
    log("[Write] " + (", ".join(changes) if changes else "keine Änderungen"))

    try:
        py_compile.compile(str(MODFILE), doraise=True); log("[Syntax] OK")
    except Exception as e:
        log(f"[Syntax] Fehler: {e} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    ok, msg = import_smoke()
    if not ok:
        log(f"[Live] Probe-Fehler: {msg} -> Rollback"); shutil.copy2(bak, MODFILE); return 1
    log(f"[Live] {msg}")

    log("[SUM] Buttons 'Editor leeren' und 'Datei löschen' wurden hinzugefügt.")
    log("[R1154b] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
