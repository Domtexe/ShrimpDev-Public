# -*- coding: utf-8 -*-
"""
Runner_1173b_IntakeUILayoutFix
- Korrigiert die fehlerhafte Replacement-Logik (kein Backslash nach '=')
- Gleiche Ziele wie 1173 (nur Layout/Umbau), aber sicherer
- Mit optionalem Sanitizer, falls irgendwo bereits '=\ ' entstanden ist.
"""
from __future__ import annotations
import os, re, time, shutil, traceback, py_compile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOGF   = os.path.join(ROOT, "debug_output.txt")

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1173b {ts}] {msg}\n"
    print(line, end="")
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, dst)
    return dst

def syntax_ok(path: str) -> bool:
    try:
        py_compile.compile(path, doraise=True)
        return True
    except Exception as e:
        log("Syntax-Fehler:\n" + "".join(traceback.format_exception_only(type(e), e)))
        return False

def ensure_grid_scaffold(code: str) -> str:
    # wie zuvor – unverändert, nur relevante Stellen gekürzt
    if not re.search(r"\bdef\s+_build_ui\s*\(\s*self\s*\)\s*:", code):
        log("WARN: _build_ui(self) nicht gefunden — keine Änderung.")
        return code

    if "[1173] grid cfg" not in code:
        code = re.sub(
            r"(\bdef\s+_build_ui\s*\(\s*self\s*\)\s*:\s*\n)",
            r"\1        # [1173] grid cfg\n"
            r"        self.grid_columnconfigure(0, weight=1)\n"
            r"        self.grid_columnconfigure(1, weight=1)\n"
            r"        self.grid_columnconfigure(2, weight=1)\n"
            r"        self.grid_columnconfigure(3, weight=1)\n",
            code, count=1
        )
    def add_block(need, snippet):
        nonlocal code
        if need not in code:
            code = re.sub(r"(\bdef\s+_build_ui\s*\(\s*self\s*\)\s*:\s*\n)",
                          r"\1"+snippet, code, count=1)

    add_block("self.frm_led",
        "        # [1173] LED-Zeile\n"
        "        from tkinter import ttk\n"
        "        self.frm_led = ttk.Frame(self)\n"
        "        self.frm_led.grid(row=1, column=0, columnspan=4, sticky='we', padx=6, pady=(2,2))\n")
    add_block("self.frm_toolbar",
        "        # [1173] Toolbar\n"
        "        from tkinter import ttk\n"
        "        self.frm_toolbar = ttk.Frame(self)\n"
        "        self.frm_toolbar.grid(row=2, column=0, columnspan=4, sticky='we', padx=6, pady=(2,2))\n")
    add_block("self.lbl_status_mid",
        "        # [1173] Statuszeile (unter Toolbar)\n"
        "        from tkinter import ttk\n"
        "        self.lbl_status_mid = ttk.Label(self, text='', anchor='w')\n"
        "        self.lbl_status_mid.grid(row=3, column=0, columnspan=4, sticky='we', padx=6, pady=(0,6))\n")
    add_block("self.frm_body",
        "        # [1173] Body-Container\n"
        "        from tkinter import ttk\n"
        "        self.frm_body = ttk.Frame(self)\n"
        "        self.frm_body.grid(row=4, column=0, columnspan=4, sticky='nsew', padx=6, pady=(0,6))\n"
        "        self.grid_rowconfigure(4, weight=1)\n")

    return code

def reparent_buttons_to_toolbar(code: str) -> str:
    if "self.frm_toolbar" not in code:
        return code
    names = [
        "btn_guard","btn_pack","btn_refresh","btn_repair","btn_run","btn_save",
        "btn_open","btn_clear","btn_detect"
    ]
    for n in names:
        code = re.sub(
            rf"(self\.{n}\s*=\s*ttk\.Button\()\s*self\s*(,)",
            rf"\1self\.frm_toolbar\2",
            code
        )
    return code

def ensure_body_children_parent(code: str) -> str:
    """
    Reparent gängige Body-Widgets auf self.frm_body.
    **Fix:** Kein Backslash mehr in der Replacement-String!
    """
    if "self.frm_body" not in code:
        return code
    targets = ["ttk\\.Treeview", "ttk\\.Panedwindow", "ttk\\.Notebook", "ttk\\.Frame", "tk\\.Text", "ttk\\.Scrollbar"]
    for cls in targets:
        code = re.sub(
            rf"(\=\s*)({cls}\()\s*self\s*(,)",
            rf"\1\2self.frm_body\3",
            code
        )
    return code

def sanitize_accidental_eq_backslash(code: str) -> str:
    """
    Repariert evtl. bereits entstandene '=\ ' / '=\t' Artefakte -> macht ein normales ' = ' daraus.
    (Idempotent, konservativ.)
    """
    code = re.sub(r"=\s*\\\s*", " = ", code)
    return code

def move_detection_status_to_label(code: str) -> str:
    # Hinweis-Kommentar, keine Logikänderung
    code = re.sub(
        r"(#\s*Status:.*\n)",
        r"\1        # [1173] Hinweis: Status bitte in self.lbl_status_mid.config(text=...) schreiben.\n",
        code
    )
    return code

def patch(code: str) -> str:
    before = code
    code = ensure_grid_scaffold(code)
    code = reparent_buttons_to_toolbar(code)
    code = ensure_body_children_parent(code)
    code = sanitize_accidental_eq_backslash(code)
    code = move_detection_status_to_label(code)
    return code if code != before else before

def main() -> int:
    if not os.path.exists(TARGET):
        log(f"Zieldatei nicht gefunden: {TARGET}")
        return 2

    bak = backup(TARGET); log(f"Backup erstellt: {bak}")

    with open(TARGET, "r", encoding="utf-8") as f:
        src = f.read()

    new_src = patch(src)
    if new_src == src:
        log("Keine Layout-Änderung erforderlich (idempotent).")
        return 0

    tmp = TARGET + ".1173b.tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(new_src)

    if not syntax_ok(tmp):
        log("Rollback: Syntax-Check fehlgeschlagen.")
        os.remove(tmp)
        shutil.copy2(bak, TARGET)
        return 1

    shutil.move(tmp, TARGET)
    if not syntax_ok(TARGET):
        log("Rollback: End-Syntax-Check fehlgeschlagen.")
        shutil.copy2(bak, TARGET)
        return 1

    log("Patch erfolgreich, Syntax OK.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
