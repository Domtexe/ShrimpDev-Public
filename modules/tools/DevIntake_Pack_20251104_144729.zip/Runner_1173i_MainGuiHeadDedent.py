# -*- coding: utf-8 -*-
"""
1173i: Header-Dedent-Fix fuer main_gui.py (idempotent, sicher)
- Entfernt unerlaubte Einrueckung am Datei-Anfang (vor def/import/class/Docstring)
- Bewahrt Shebang, Encoding und Modul-Docstring
- Positioniert __future__-Imports direkt hinter Docstring
- Sortiert die ersten Import-Zeilenblock nach oben (ohne Inhalte umzuschreiben)
- Syntax-Check; bei Fehler -> Prozess return code != 0 (BAT macht Rollback)
"""
import io, os, re, sys, py_compile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC  = os.path.join(ROOT, "main_gui.py")

def R(p): return io.open(p, "r", encoding="utf-8", errors="replace").read()
def W(p, s): io.open(p, "w", encoding="utf-8", newline="\n").write(s)

src0 = R(SRC)
src  = src0

# --- 1) Shebang + Encoding ---
pos = 0
m = re.match(r"(?:\s*#![^\n]*\n)?(?:\s*#\s*-\*-[^\n]*-\*-\s*\n)?", src)
if m: pos = m.end()

# --- 2) Modul-Docstring (optional) ---
m = re.match(r'(?s)(\s*(?:[rRuU]{0,2}["\']{3}.*?["\']{3}\s*\n))', src[pos:])
if m:
    doc = m.group(1)
    doc_start = pos
    doc_end = pos + m.end()
    pos = doc_end
else:
    doc = ""
    doc_start = doc_end = pos

# --- 3) Sammle __future__-Imports unterhalb von Docstring (evtl. verteilt) ---
future_pat = re.compile(r"(?m)^\s*from\s+__future__\s+import\s+[^\n]+$")
futures = future_pat.findall(src)
# entferne alle __future__-Imports aus dem Text
src_wo_future = future_pat.sub("", src)

# --- 4) Jetzt die allerersten ~150 Zeilen nach dem Docstring dedentieren,
#         bis wir auf die erste Leerzeile NACH einem Top-Level-Statement stossen
head = src_wo_future[:]
head_prefix = head[:pos]
tail = head[pos:]

lines = tail.splitlines(True)
out = []
top_started = False
done_limit = False
count = 0

def _is_top_token(line: str) -> bool:
    s = line.lstrip()
    return (
        s.startswith("def ")
        or s.startswith("class ")
        or s.startswith("import ")
        or s.startswith("from ")
        or s.startswith("\"\"\"") or s.startswith("'''")
        or s.startswith("#")  # Kommentar am Anfang tolerieren
    )

for ln in lines:
    count += 1
    if count > 200 and not top_started:
        # Sicherheitsgrenze: nicht endlos scannen
        top_started = True
    if not top_started and ln.strip() == "":
        out.append(ln)
        continue
    if not top_started and _is_top_token(ln):
        top_started = True
        # wichtige Zeilen am Anfang nach Spalte 0 ziehen
        out.append(ln.lstrip())
        continue
    if top_started and not done_limit:
        # solange wir noch im Kopfblock sind, alles linksbündig
        if ln.strip() == "":
            # erste Leerzeile nach dem Kopf-Block: übernehmen und Limit setzen
            out.append(ln)
            done_limit = True
        else:
            out.append(ln.lstrip())
        continue
    out.append(ln)

new_body = "".join(out)

# --- 5) Zukunfts-Imports direkt nach Docstring reintegrieren ---
future_block = ""
if futures:
    # Duplikate entfernen, Reihenfolge stabilisieren
    seen = set()
    uniq = []
    for f in futures:
        if f not in seen:
            uniq.append(f)
            seen.add(f)
    future_block = "\n".join(uniq) + "\n"

rebuilt = src_wo_future[:doc_start] + doc + future_block + new_body

# --- 6) Leerzeilen normalisieren (max 2 in Folge)
rebuilt = re.sub(r"\n{3,}", "\n\n", rebuilt)

# --- 7) Syntax-Check über temp ---
tmp = SRC + ".1173i.tmp"
W(tmp, rebuilt)
py_compile.compile(tmp, doraise=True)
os.replace(tmp, SRC)
print("[1173i] Header dedentet, __future__/Imports oben, Syntax OK.")
