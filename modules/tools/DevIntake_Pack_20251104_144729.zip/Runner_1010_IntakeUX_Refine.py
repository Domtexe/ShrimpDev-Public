"""
Runner_1010_IntakeUX_Refine
- Fix: Menü/Shortcuts funktionieren wieder (Menü NACH Tab-Erzeugung, saubere Bindings)
- UI: responsive Grid/PanedWindow, Scrollbars, Stile
- Version -> v9.9.1
"""
from __future__ import annotations
import os, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1010] {ts} {msg}\n")
    print(msg, flush=True)

def safe_write(path: str, data: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        os.makedirs(ARCH, exist_ok=True)
        bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
        shutil.copy2(path, bck)
        log(f"Backup: {path} -> {bck}")
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

def patch():
    try:
        # module_code_intake neu
        safe_write(os.path.join(ROOT, "modules", "module_code_intake.py"), MODULE_CODE_INTAKE)

        # main_gui reparieren: Menü NACH Tab-Erzeugung, Styles, Shortcuts an root
        gpath = os.path.join(ROOT, "main_gui.py")
        with open(gpath, "r", encoding="utf-8") as f:
            gui = f.read()
        gui = MAIN_GUI_REWRITE  # saubere Referenz
        safe_write(gpath, gui)

        # Meta
        safe_write(os.path.join(ROOT, "CURRENT_VERSION.txt"), "ShrimpDev v9.9.1\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.1 (2025-10-18)
- UI: Ordnung & Responsive-Layout (Grid-Gewichte, PanedWindow, Scrollbars)
- Fix: Menübefehle + Shortcuts funktionieren zuverlässig
- Optik: ttk-Styles (clam), klare Abstände/Toolbar
""")
        log("Patch erfolgreich.")
        return 0
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

# ---------------- module_code_intake.py (neu) ----------------
MODULE_CODE_INTAKE = r'''"""Intake-UI (v9.9.1) – aufgeräumt & responsive"""
from __future__ import annotations
import os, shutil, tkinter as tk
from tkinter import ttk, filedialog, messagebox
from modules.config_mgr import ConfigMgr
from modules.snippets.file_detect_snippet import split_name_ext, classify, is_supported

_PADX, _PADY = 8, 6

def _open_explorer_select(path: str) -> None:
    try:
        if os.path.exists(path):
            os.system(f'explorer /select,"{path}"')
        else:
            os.system(f'explorer "{os.path.dirname(path) or "."}"')
    except Exception:
        pass

class IntakeFrame(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.cfg = ConfigMgr()
        self._build_ui()
        self._load_table()
        self._update_led("yellow", "Bereit")
        self._bind_shortcuts()

    # ---------- UI ----------
    def _build_ui(self):
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        # Kopfzeile
        head = ttk.Frame(self)
        head.grid(row=0, column=0, sticky="ew", padx=_PADX, pady=(_PADY,4))
        for c in (1,4,7,10): head.columnconfigure(c, weight=1)

        ttk.Label(head, text="Workspace:").grid(row=0, column=0, sticky="w")
        self.var_ws = tk.StringVar(value=self.cfg.get_str("general", "default_path", os.getcwd()))
        ent_ws = ttk.Entry(head, textvariable=self.var_ws)
        ent_ws.grid(row=0, column=1, sticky="ew", padx=(4,4))
        ttk.Button(head, text="...", width=3, command=self._pick_ws).grid(row=0, column=2, padx=(0,12))

        ttk.Label(head, text="Datei:").grid(row=0, column=3, sticky="w")
        self.var_path = tk.StringVar(value="")
        self.ent_path = ttk.Entry(head, textvariable=self.var_path)
        self.ent_path.grid(row=0, column=4, sticky="ew", padx=(4,4))
        ttk.Button(head, text="...", width=3, command=self._pick_file).grid(row=0, column=5, padx=(0,12))

        ttk.Label(head, text="Endung:").grid(row=0, column=6, sticky="w")
        self.var_ext = tk.StringVar(value="")
        ttk.Entry(head, textvariable=self.var_ext, state="readonly", width=7).grid(row=0, column=7, sticky="ew", padx=(4,12))

        ttk.Label(head, text="Zielordner:").grid(row=0, column=8, sticky="w")
        self.var_target = tk.StringVar(value=self.cfg.get_str("general", "target_folder", os.path.join(os.getcwd(), "tools")))
        ent_tgt = ttk.Entry(head, textvariable=self.var_target)
        ent_tgt.grid(row=0, column=9, sticky="ew", padx=(4,4))
        ttk.Button(head, text="...", width=3, command=self._pick_target).grid(row=0, column=10)

        # LED/Status rechts
        ledwrap = ttk.Frame(self)
        ledwrap.grid(row=0, column=0, sticky="e", padx=_PADX)
        self.led = tk.Canvas(ledwrap, width=14, height=14, highlightthickness=0)
        self.led.pack(side="left", padx=(0,6))
        self.var_ledtext = tk.StringVar(value="Erkennung")
        ttk.Label(ledwrap, textvariable=self.var_ledtext).pack(side="left")

        # Toolbar
        bar = ttk.Frame(self)
        bar.grid(row=1, column=0, sticky="ew", padx=_PADX, pady=(0,4))
        ttk.Button(bar, text="Erkennen (Ctrl+I)", command=self._detect).pack(side="left")
        ttk.Button(bar, text="Speichern (Ctrl+S)", command=self._save).pack(side="left", padx=(6,0))
        bar.pack_propagate(False)

        # Body: PanedWindow
        body = ttk.Panedwindow(self, orient="horizontal")
        body.grid(row=2, column=0, sticky="nsew", padx=_PADX, pady=(0,_PADY))
        self.rowconfigure(2, weight=1)

        # Editor links + Scrollbars
        left = ttk.Frame(body)
        left.rowconfigure(0, weight=1)
        left.columnconfigure(0, weight=1)
        self.txt = tk.Text(left, wrap="none", undo=True, font=("Consolas", 10))
        y1 = ttk.Scrollbar(left, orient="vertical", command=self.txt.yview)
        x1 = ttk.Scrollbar(left, orient="horizontal", command=self.txt.xview)
        self.txt.configure(yscrollcommand=y1.set, xscrollcommand=x1.set)
        self.txt.grid(row=0, column=0, sticky="nsew")
        y1.grid(row=0, column=1, sticky="ns")
        x1.grid(row=1, column=0, sticky="ew")
        body.add(left, weight=3)

        # Tabelle rechts + Scrollbars
        right = ttk.Frame(body)
        right.rowconfigure(0, weight=1)
        right.columnconfigure(0, weight=1)

        cols = ("name","ext","subfolder")
        self.tbl = ttk.Treeview(right, columns=cols, show="headings", selectmode="browse")
        self.tbl.heading("name", text="name")
        self.tbl.heading("ext", text="ext")
        self.tbl.heading("subfolder", text="subfolder")
        self.tbl.column("name", anchor="w", width=240, stretch=True)
        self.tbl.column("ext", anchor="center", width=70, stretch=False)
        self.tbl.column("subfolder", anchor="w", width=180, stretch=True)

        y2 = ttk.Scrollbar(right, orient="vertical", command=self.tbl.yview)
        x2 = ttk.Scrollbar(right, orient="horizontal", command=self.tbl.xview)
        self.tbl.configure(yscrollcommand=y2.set, xscrollcommand=x2.set)

        self.tbl.grid(row=0, column=0, sticky="nsew")
        y2.grid(row=0, column=1, sticky="ns")
        x2.grid(row=1, column=0, sticky="ew")
        body.add(right, weight=2)

        # Kontextmenü
        self.menu = tk.Menu(self, tearoff=0)
        self.menu.add_command(label="Öffnen im Explorer", command=self._open_selected)
        self.menu.add_command(label="Pfad kopieren", command=self._copy_selected)
        self.menu.add_separator()
        self.menu.add_command(label="Löschen", command=self._delete_selected)
        self.tbl.bind("<Button-3>", self._context)

        # Doppelklick → laden/erkennen
        self.tbl.bind("<Double-Button-1>", self._dbl_open)

    # ---------- helpers ----------
    def _bind_shortcuts(self):
        root = self.winfo_toplevel()
        root.bind_all("<Control-s>", lambda e: self._save())
        root.bind_all("<Control-i>", lambda e: self._detect())
        self.tbl.bind("<Control-c>", lambda e: self._copy_selected())
        self.tbl.bind("<Delete>", lambda e: self._delete_selected())

    def _update_led(self, color: str, text: str):
        self.led.delete("all")
        self.led.create_oval(2,2,12,12, fill=color, outline="")
        self.var_ledtext.set(text)

    def _pick_ws(self):
        d = filedialog.askdirectory(title="Workspace wählen", initialdir=self.var_ws.get() or os.getcwd())
        if d:
            self.var_ws.set(d)
            self.cfg.set_str("general", "default_path", d)

    def _pick_file(self):
        f = filedialog.askopenfilename(title="Datei wählen", initialdir=self.var_ws.get() or os.getcwd())
        if f:
            self.var_path.set(f)
            try:
                with open(f, "r", encoding="utf-8", errors="ignore") as fh:
                    self.txt.delete("1.0","end"); self.txt.insert("1.0", fh.read())
            except Exception:
                pass
            self._detect()

    def _pick_target(self):
        d = filedialog.askdirectory(title="Zielordner wählen", initialdir=self.var_target.get() or os.getcwd())
        if d:
            self.var_target.set(d)
            self.cfg.set_str("general", "target_folder", d)

    def _context(self, evt):
        try:
            row = self.tbl.identify_row(evt.y)
            if row:
                self.tbl.selection_set(row)
            self.menu.tk_popup(evt.x_root, evt.y_root)
        finally:
            self.menu.grab_release()

    def _path_of_item(self, item_id: str) -> str:
        vals = self.tbl.item(item_id, "values")
        if not vals: return ""
        name, ext, sub = vals
        folder = self.var_target.get() or "."
        if sub:
            folder = os.path.join(folder, sub)
        return os.path.join(folder, f"{name}{ext}")

    # ---------- actions ----------
    def _detect(self):
        path = self.var_path.get().strip()
        content = self.txt.get("1.0", "end-1c")
        name, ext = split_name_ext(path) if path else ("", "")
        self.var_ext.set(ext or "")
        ok = bool((path and is_supported(path)) or content.strip() != "")
        typ = classify(path) if path else "unknown"
        self._update_led("green" if ok else "yellow", "Erkennung OK" if ok else f"Typ: {typ}")
        return ok

    def _save(self):
        tgt_dir = self.var_target.get().strip() or "."
        os.makedirs(tgt_dir, exist_ok=True)
        src = self.var_path.get().strip()
        nm, ext = split_name_ext(src) if src else ("snippet", ".txt")
        target_path = os.path.join(tgt_dir, f"{os.path.basename(nm)}{ext}")
        data = self.txt.get("1.0","end-1c").encode("utf-8")
        try:
            with open(target_path, "wb") as f:
                f.write(data)
            self.cfg.append_history(target_path)
            self._load_table()
            self._update_led("green", "Gespeichert")
        except Exception as ex:
            messagebox.showerror("Fehler", f"Konnte nicht speichern:\n{ex}")
            self._update_led("red", "Fehler")

    def _load_table(self):
        for i in self.tbl.get_children(): self.tbl.delete(i)
        tgt = os.path.abspath(self.var_target.get() or ".")
        for p in self.cfg.get_history():
            base = os.path.basename(p)
            name, ext = os.path.splitext(base)
            try:
                rel = os.path.relpath(os.path.dirname(os.path.abspath(p)), tgt)
                sub = "" if rel in (".", "") else rel
            except Exception:
                sub = ""
            self.tbl.insert("", "end", values=(name, ext.lower(), sub))

    def _dbl_open(self, _evt=None):
        sel = self.tbl.selection()
        if not sel: return
        path = self._path_of_item(sel[0])
        if not os.path.isfile(path): return
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                self.txt.delete("1.0","end"); self.txt.insert("1.0", f.read())
            self.var_path.set(path); self._detect()
        except Exception:
            pass

    def _copy_selected(self):
        sel = self.tbl.selection()
        if not sel: return
        path = self._path_of_item(sel[0])
        try:
            self.clipboard_clear(); self.clipboard_append(path)
        except Exception:
            pass

    def _delete_selected(self):
        sel = self.tbl.selection()
        if not sel: return
        path = self._path_of_item(sel[0])
        if not os.path.isfile(path):
            self.cfg.remove_history(path); self._load_table(); return
        if not messagebox.askyesno("Löschen bestätigen", f"Datei endgültig löschen?\n\n{path}"):
            return
        try:
            os.remove(path)
        except Exception:
            try:
                trash = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "_Archiv", "_Trash"))
                os.makedirs(trash, exist_ok=True)
                shutil.move(path, os.path.join(trash, os.path.basename(path) + ".del"))
            except Exception:
                messagebox.showerror("Fehler", "Löschen fehlgeschlagen.")
                return
        self.cfg.remove_history(path)
        self._load_table()

    def _open_selected(self):
        sel = self.tbl.selection()
        if not sel: return
        _open_explorer_select(self._path_of_item(sel[0]))
'''

# ---------------- main_gui.py (saubere Referenz mit Styles & funktionierendem Menü) -------------
MAIN_GUI_REWRITE = r'''"""ShrimpDev main_gui (v9.9.1)
- Notebook: Code Intake / Agent / Project
- Menü nach Tab-Erzeugung (damit Callbacks existieren)
- Styles (clam), responsive Layout
"""
from __future__ import annotations
import os, sys, traceback, tkinter as tk
from tkinter import ttk, messagebox

# sys.path Safeguard
ROOT = os.path.abspath(os.path.dirname(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# Logger-Fallback
try:
    from modules.snippets.logger_snippet import write_log
except Exception:
    def write_log(p: str, m: str) -> None:
        try:
            with open(os.path.join(ROOT, "debug_output.txt"), "a", encoding="utf-8") as f:
                import time; ts = time.strftime("%Y-%m-%d %H:%M:%S")
                f.write(f"[{p}] {ts} {m}\n")
        except Exception:
            pass

from modules.module_code_intake import IntakeFrame
from modules.module_agent_ui import AgentFrame
from modules.module_project_ui import ProjectFrame
from modules.config_mgr import ConfigMgr

def _safe_main() -> None:
    root = tk.Tk()
    root.title("ShrimpDev – v9.9.1")
    root.geometry("1100x740")

    # Styles
    style = ttk.Style()
    try:
        style.theme_use("clam")
    except Exception:
        pass
    style.configure("TButton", padding=(8,4))
    style.configure("TLabel", padding=(2,0))

    cfg = ConfigMgr()

    # Always-on-Top Setting
    var_top = tk.BooleanVar(value=cfg.get_bool("general", "always_on_top", False))
    def _apply_top():
        try:
            root.attributes("-topmost", bool(var_top.get()))
            cfg.set_str("general", "always_on_top", "true" if var_top.get() else "false")
        except Exception as ex:
            write_log("GUI", f"TOPMOST_ERR: {ex}")

    # Notebook
    nb = ttk.Notebook(root)
    nb.pack(fill="both", expand=True)

    tab_intake = IntakeFrame(nb)
    tab_agent  = AgentFrame(nb)
    tab_proj   = ProjectFrame(nb)

    nb.add(tab_intake, text="Code Intake")
    nb.add(tab_agent,  text="Agent")
    nb.add(tab_proj,   text="Project")
    nb.select(0)

    # Menü (NACH der Tab-Erzeugung, damit Callbacks referenzieren können)
    menubar = tk.Menu(root)
    m_file = tk.Menu(menubar, tearoff=0)
    m_file.add_command(label="Speichern (Ctrl+S)", command=tab_intake._save)
    m_file.add_command(label="Erkennen (Ctrl+I)", command=tab_intake._detect)
    m_file.add_separator()
    m_file.add_checkbutton(label="Always on Top", onvalue=True, offvalue=False,
                           variable=var_top, command=_apply_top)
    m_file.add_separator()
    m_file.add_command(label="Beenden", command=root.destroy)
    menubar.add_cascade(label="File", menu=m_file)

    m_tools = tk.Menu(menubar, tearoff=0)
    m_tools.add_command(label="Explorer (Auswahl)", command=tab_intake._open_selected)
    m_tools.add_command(label="Pfad kopieren", command=tab_intake._copy_selected)
    menubar.add_cascade(label="Tools", menu=m_tools)

    m_help = tk.Menu(menubar, tearoff=0)
    m_help.add_command(label="Info", command=lambda: messagebox.showinfo("ShrimpDev","Standalone Dev-Umgebung für ShrimpHub"))
    menubar.add_cascade(label="Help", menu=m_help)

    root.config(menu=menubar)

    # Shortcuts (global)
    root.bind_all("<Control-t>", lambda e: (var_top.set(not var_top.get()), _apply_top()))
    root.bind_all("<Control-s>", lambda e: tab_intake._save())
    root.bind_all("<Control-i>", lambda e: tab_intake._detect())

    _apply_top()

    # Statusbar
    status = tk.StringVar(value="Bereit.")
    bar = ttk.Label(root, textvariable=status, anchor="w")
    bar.pack(side="bottom", fill="x")

    def report_callback_exception(*exc):
        write_log("GUI", "CRASH\n" + "".join(traceback.format_exception(*exc)))
        status.set(f"Fehler: {exc[-1]}")
    root.report_callback_exception = report_callback_exception

    root.mainloop()

if __name__ == "__main__":
    try:
        _safe_main()
    except Exception:
        tb = traceback.format_exc()
        write_log("GUI", "CRASH\n" + tb)
        sys.exit(1)
'''

if __name__ == "__main__":
    raise SystemExit(patch())
