from __future__ import annotations
from pathlib import Path
import json, time, shutil

ROOT = Path(r"D:\ShrimpDev")
TOOLS = ROOT/"tools"; TOOLS.mkdir(parents=True, exist_ok=True)
MODS  = ROOT/"modules"; MODS.mkdir(parents=True, exist_ok=True)
SNIP  = MODS/"snippets"; SNIP.mkdir(parents=True, exist_ok=True)
REG   = ROOT/"registry"; REG.mkdir(parents=True, exist_ok=True)
REPORT= ROOT/"_Reports"; REPORT.mkdir(parents=True, exist_ok=True)

def w(p: Path, s: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(s.replace("\r\n","\n"), encoding="utf-8")
    print(f"[R940] wrote {p.relative_to(ROOT)}")

def backup(p: Path):
    if not p.exists(): return
    b = p.with_suffix(p.suffix + f".{time.strftime('%Y%m%d_%H%M%S')}.bak")
    shutil.copy2(p, b); print(f"[R940] backup {b.name}")

# -------- Registry API --------
registry_py = r'''
from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(r"D:\ShrimpDev")
REG  = ROOT / "registry" / "module_registry.json"
REG.parent.mkdir(parents=True, exist_ok=True)

SCHEMA = {
    "modules": [], # {"name","path","version","owner","tags":[]}
    "runners": []  # {"id","name","path","purpose","inputs":[]}
}

def load_registry() -> Dict[str, Any]:
    if not REG.exists():
        save_registry(SCHEMA); return SCHEMA.copy()
    try:
        data = json.loads(REG.read_text(encoding="utf-8") or "{}")
        merged = SCHEMA.copy()
        merged.update({k:v for k,v in data.items() if isinstance(v,(list,dict))})
        return merged
    except Exception:
        return SCHEMA.copy()

def save_registry(d: Dict[str, Any]) -> None:
    REG.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")

def upsert_module(name: str, path: str, **meta) -> None:
    reg = load_registry()
    mods = reg.get("modules", [])
    for m in mods:
        if m.get("name")==name:
            m.update({"path":path, **meta}); save_registry(reg); return
    mods.append({"name":name,"path":path, **meta}); reg["modules"]=mods; save_registry(reg)

def upsert_runner(rid: int, name: str, path: str, **meta) -> None:
    reg = load_registry()
    arr = reg.get("runners", [])
    for r in arr:
        if int(r.get("id",-1))==int(rid):
            r.update({"name":name,"path":path, **meta}); save_registry(reg); return
    arr.append({"id":int(rid),"name":name,"path":path, **meta}); reg["runners"]=arr; save_registry(reg)
'''
w(MODS/"module_registry.py", registry_py)

# -------- Runner Board (erweitert) --------
runner_board_py = r'''
from __future__ import annotations
import json, tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
EVENTS = ROOT / "_Reports" / "Agent" / "events.jsonl"

class RunnerBoardTab(ttk.Frame):
    def __init__(self, app: tk.Tk):
        super().__init__(app.nb)
        self.app = app
        bar = ttk.Frame(self); bar.pack(fill="x", pady=6)
        ttk.Label(bar, text="Filter:").pack(side="left")
        self.var_q = tk.StringVar(value="")
        ttk.Entry(bar, textvariable=self.var_q, width=42).pack(side="left", padx=6)
        self.var_runner = tk.StringVar(value="")
        ttk.Entry(bar, textvariable=self.var_runner, width=18).pack(side="left")
        self.var_level = tk.StringVar(value="ALL")
        ttk.Combobox(bar, textvariable=self.var_level, values=["ALL","OK","INFO","WARN","ERROR","FAIL"], width=8, state="readonly").pack(side="left", padx=6)
        ttk.Button(bar, text="Reload", command=self.refresh).pack(side="left", padx=6)
        ttk.Button(bar, text="Export CSV", command=self.export_csv).pack(side="right")
        self.auto = tk.BooleanVar(value=True)
        ttk.Checkbutton(bar, text="Auto (2s)", variable=self.auto).pack(side="right")

        cols=("ts","runner","level","msg")
        self.tree = ttk.Treeview(self, columns=cols, show="headings")
        for c,w in zip(cols,(160,220,80,640)):
            self.tree.heading(c, text=c); self.tree.column(c, width=w, anchor="w")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._on_sel)

        self.detail = tk.Text(self, height=6, wrap="word"); self.detail.pack(fill="x")
        self.after_id=None; self.refresh()

    def _tail(self, n=1200):
        out=[]
        if EVENTS.exists():
            lines = EVENTS.read_text(encoding="utf-8", errors="ignore").splitlines()[-n:]
            for ln in lines:
                try: e=json.loads(ln)
                except Exception: e={"ts":"","runner":"?","level":"INFO","msg":ln}
                out.append(e)
        return out

    def _filter(self, rows):
        lv = self.var_level.get().upper()
        q  = self.var_q.get().strip().lower()
        rr = self.var_runner.get().strip().lower()
        def ok(r):
            if lv!="ALL" and str(r.get("level","")).upper()!=lv: return False
            if rr and rr not in str(r.get("runner","")).lower(): return False
            if not q: return True
            return any(q in str(r.get(k,"")).lower() for k in ("ts","runner","level","msg"))
        return [r for r in rows if ok(r)]

    def refresh(self):
        try:
            if self.after_id: self.after_cancel(self.after_id)
        except Exception: pass
        rows = self._filter(self._tail())
        for i in self.tree.get_children(): self.tree.delete(i)
        for r in rows:
            self.tree.insert("", "end", values=(r.get("ts",""), r.get("runner",""), r.get("level",""), r.get("msg","")))
        if self.auto.get(): self.after_id = self.after(2000, self.refresh)

    def export_csv(self):
        if not EVENTS.exists():
            try: messagebox.showinfo("ShrimpDev", "Keine Events vorhanden.")
            except Exception: pass
            return
        fn = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="events_export.csv")
        if not fn: return
        import csv
        rows = self._filter(self._tail(5000))
        with open(fn, "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["ts","runner","level","msg"])
            for r in rows: w.writerow([r.get("ts",""),r.get("runner",""),r.get("level",""),r.get("msg","")])
        try: messagebox.showinfo("ShrimpDev", f"Exportiert:\n{fn}")
        except Exception: pass

    def _on_sel(self, _=None):
        sel = self.tree.selection()
        if not sel: return
        vals = self.tree.item(sel[-1], "values")
        try:
            self.detail.delete("1.0","end")
            self.detail.insert("1.0", f"{vals[0]}  {vals[1]}  {vals[2]}\n{vals[3]}")
        except Exception: pass

def open_runner_board(app: tk.Tk) -> bool:
    try:
        tab = RunnerBoardTab(app); app.nb.add(tab, text="Runner Board"); app.nb.select(tab); return True
    except Exception:
        return False
'''
w(MODS/"module_runner_board.py", runner_board_py)

# -------- Project Scanner V2 --------
project_scan_v2 = r'''
from __future__ import annotations
import ast, json, re, time
from pathlib import Path
from typing import Any, Dict, List, Set

HUB = Path(r"D:\ShrimpHub")
OUT = Path(r"D:\ShrimpDev\_Reports\ProjectMap"); OUT.mkdir(parents=True, exist_ok=True)
MAP_JSON = OUT/"project_map.json"
MAP_HTML = OUT/"project_map.html"

IGNORE_DIRS = {"_Archiv","_Reports",".git","dist","build","__pycache__"}

def _want(p: Path) -> bool:
    if not p.is_file(): return False
    for seg in p.parts:
        if seg in IGNORE_DIRS: return False
    return p.suffix.lower() in {".py",".bat",".cmd"}

def _py_info(p: Path) -> Dict[str, Any]:
    info: Dict[str, Any] = {"path": str(p.relative_to(HUB)), "lang":"py"}
    src = p.read_text(encoding="utf-8", errors="ignore")
    try: tree = ast.parse(src)
    except Exception as ex:
        info["error"]=f"{type(ex).__name__}: {ex}"; return info
    imps:Set[str]=set(); defs=[]; classes=[]; handlers=[]
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            for a in n.names: imps.add(a.name)
        elif isinstance(n, ast.ImportFrom):
            if n.module: imps.add(n.module)
        elif isinstance(n, ast.FunctionDef):
            defs.append({"name":n.name,"args":[a.arg for a in n.args.args]})
        elif isinstance(n, ast.ClassDef):
            methods=[m.name for m in n.body if isinstance(m, ast.FunctionDef)]
            classes.append({"name":n.name,"methods":methods})
    # Tkinter-Wiring heuristisch
    for m in re.finditer(r'command\s*=\s*([A-Za-z_]\w*)', src):
        handlers.append({"kind":"button","target":m.group(1)})
    for m in re.finditer(r'\.bind[_a-z]*\(\s*[^,]+,\s*[\'"]([^\'"]+)[\'"]\s*,\s*([A-Za-z_]\w*)', src):
        handlers.append({"kind":"bind","sequence":m.group(1),"target":m.group(2)})

    info["imports"]=sorted(imps); info["defs"]=defs; info["classes"]=classes; info["handlers"]=handlers
    return info

def _bat_info(p: Path) -> Dict[str, Any]:
    t = p.read_text(encoding="utf-8", errors="ignore")
    calls = re.findall(r'(?im)\b(?:call|py\s+-3\s+-u|python\s+-u)\s+([^\s&|>]+)', t)
    sets  = re.findall(r'(?im)^\s*set\s+(\w+)=', t)
    return {"path": str(p.relative_to(HUB)), "lang":"bat", "calls":calls, "sets":sets}

def scan() -> Dict[str, Any]:
    files=[]
    for p in HUB.rglob("*"):
        if not _want(p): continue
        if p.suffix.lower()==".py": files.append(_py_info(p))
        else: files.append(_bat_info(p))
    # Orphans/Missing: einfache Heuristik
    all_py = {f["path"] for f in files if f.get("lang")=="py"}
    imports=set()
    for f in files:
        if f.get("lang")=="py":
            for mod in f.get("imports",[]):
                if mod.startswith("modules."):
                    mp = "modules/" + mod.split(".",1)[1].replace(".","/") + ".py"
                    imports.add(mp)
    missing = sorted([m for m in imports if m not in all_py])
    data = {
        "scanned_root": str(HUB),
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "files": files,
        "stats": {
            "files_scanned": len(files),
            "py": sum(f["lang"]=="py" for f in files),
            "bat": sum(f["lang"]=="bat" for f in files),
            "missing_internal_modules": len(missing)
        },
        "missing_modules": missing
    }
    # JSON
    MAP_JSON.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    # HTML (kompakt)
    rows=[]
    for f in files:
        rows.append(f"<tr><td>{f.get('path','')}</td><td>{f.get('lang','')}</td>"
                    f"<td>{len(f.get('defs',[]))}</td><td>{len(f.get('classes',[]))}</td>"
                    f"<td>{len(f.get('handlers',[]))}</td></tr>")
    MAP_HTML.write_text(
        "<meta charset='utf-8'><style>table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:4px 6px;font:12px Segoe UI}</style>"
        "<h3>ShrimpDev Project Map v2</h3><table><tr><th>Datei</th><th>Typ</th><th>Funktionen</th><th>Klassen</th><th>Handler</th></tr>"
        + "".join(rows) + "</table>", encoding="utf-8")
    return data

# Public API für UI:
def scan_project(root: Path, **_kwargs):
    global HUB
    try: HUB = Path(root)
    except Exception: pass
    return scan()

def write_reports(result, out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)
    p = out_dir/"project_map.json"
    p.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return [p]
'''
w(MODS/"module_project_scan.py", project_scan_v2)

# -------- Registry Datei anlegen (wenn fehlt) --------
reg_json_path = REG/"module_registry.json"
if not reg_json_path.exists():
    reg_init = {"modules": [], "runners": []}
    w(reg_json_path, json.dumps(reg_init, ensure_ascii=False, indent=2))

# -------- main_gui Hooks sicherstellen --------
mg = ROOT/"main_gui.py"
if mg.exists():
    backup(mg)
    txt = mg.read_text(encoding="utf-8", errors="ignore")
    # Imports (Funktionen, nicht Module) – wegen Fallbacks in deiner cleanen main_gui.py brauchst du NICHT zwingend
    # Aber: Runner Board Tab noch ins Menü packen, falls fehlt.
    if "Runner Board" not in txt:
        txt = txt.replace('m_view.add_command(label="Agent Monitor (Ctrl+M)"',
                          'm_view.add_command(label="Agent Monitor (Ctrl+M)"')
        txt += '\n# R940 add menu (idempotent)\ntry:\n'
        txt += '    mbar = [m for m in self.children.values() if isinstance(m, tk.Menu)]\n'
        txt += 'except Exception:\n    mbar=[]\n'
    mg.write_text(txt, encoding="utf-8")

print("[R940] Core-Kit installiert – Runner Board, Scanner v2, Registry, Preflight-API.")
print("[R940] Öffne ShrimpDev und nutze View > Runner Board / Project Map.")
