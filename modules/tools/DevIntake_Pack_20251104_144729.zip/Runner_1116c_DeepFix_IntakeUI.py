# D:\ShrimpDev\tools\Runner_1116c_DeepFix_IntakeUI.py
import os, re, sys, time, shutil

ROOT = os.path.abspath(os.path.dirname(__file__))
PROJ = os.path.abspath(os.path.join(ROOT, ".."))
MOD  = os.path.join(PROJ, "modules", "module_code_intake.py")
ARCH = os.path.join(PROJ, "_Archiv")

TAG = "[R1116c]"

def read_text(p):
    with open(p, "rb") as f:
        b = f.read()
    # tolerant CRLF -> LF
    t = b.decode("utf-8", "replace").replace("\r\n", "\n").replace("\r", "\n")
    return t

def write_text(p, t):
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(t)

def ensure_future_at_top(src: str) -> str:
    # entferne doppelte future-Imports, dann setze ihn direkt nach der coding-Zeile
    lines = src.split("\n")
    coding_idx = 0
    if lines and lines[0].startswith("#"):
        coding_idx = 1
    # drop alle vorhandenen future-Zeilen
    lines = [ln for ln in lines if not re.match(r"^\s*from\s+__future__\s+import\s+annotations\s*$", ln)]
    # einfügen falls fehlt
    if not re.match(r"^\s*from\s+__future__\s+import\s+annotations\s*$", lines[coding_idx] if len(lines)>coding_idx else ""):
        lines.insert(coding_idx, "from __future__ import annotations")
    return "\n".join(lines)

def fix_toolbar_block(src: str) -> str:
    """
    Ersetzt den gesamten Button-Block sicher.
    Vom Beginn 'bar = ttk.Frame(self)' bis zur Definition von 'self.lbl_ping' inkl. Grids.
    """
    pat = re.compile(
        r"(bar\s*=\s*ttk\.Frame\(self\)[\s\S]+?)(?:self\.lbl_ping\s*=.+?\n)",
        re.MULTILINE
    )
    def repl(m):
        head = "bar = ttk.Frame(self); bar.grid(row=2, column=0, sticky=\"ew\", padx=_PADX, pady=(0,4))\n" \
               "bar.columnconfigure(3, weight=1)\n" \
               "self.btn_detect = ttk.Button(bar, text=\"Erkennen (Ctrl+I)\", command=self._on_click_detect)\n" \
               "self.btn_save   = ttk.Button(bar, text=\"Speichern (Ctrl+S)\", command=self._on_click_save)\n" \
               "self.btn_guard  = ttk.Button(bar, text=\"Prüfen (Guard)\",    command=self._on_click_guard)\n" \
               "self.btn_run    = ttk.Button(bar, text=\"Run (F5)\",          command=self._on_click_run)\n" \
               "self.btn_del    = ttk.Button(bar, text=\"Löschen (Entf)\",    command=self._on_click_delete)\n" \
               "self.btn_repair = ttk.Button(bar, text=\"Reparieren (Tief)\", command=self._on_click_repair_deep)\n" \
               "self.btn_detect.grid(row=0,column=0,padx=(0,6),sticky=\"w\")\n" \
               "self.btn_save.grid(  row=0,column=1,padx=(0,6),sticky=\"w\")\n" \
               "self.btn_del.grid(   row=0,column=2,padx=(0,0),sticky=\"w\")\n" \
               "self.btn_guard.grid( row=0,column=99,padx=(6,0))\n" \
               "self.btn_repair.grid(row=0,column=100,padx=(6,0))\n" \
               "self.btn_run.grid(   row=0,column=101,padx=(6,0))\n" \
               "self.lbl_ping = ttk.Label(bar, text=\"\", anchor=\"w\")\n"
        return head
    if pat.search(src):
        src = pat.sub(lambda m: repl(m), src, count=1)
    return src

def fix_editor_binds(src: str) -> str:
    # löst die verklebte Zeile: ..._repair_deep)self.txt.bind("<F5>", ...)
    src = re.sub(
        r'self\.txt\.bind\("<F7>",\s*self\._on_click_repair_deep\)\s*self\.txt\.bind\("<F5>",\s*lambda\s*_e:\s*self\._on_click_run\(\)\)',
        'self.txt.bind("<F7>", self._on_click_repair_deep)\n        self.txt.bind("<F5>", lambda _e: self._on_click_run())',
        src
    )
    return src

def fix_recycle_bin_helper(src: str) -> str:
    # pFrom = path + "\x00\x00"
    src = re.sub(r'pFrom\s*=\s*path\s*\+\s*"\\\\x00\\\\x00"', 'pFrom = path + "\\x00\\x00"', src)
    src = re.sub(r'pFrom\s*=\s*path\s*\+\s*"\\\\0\\\\0"', 'pFrom = path + "\\x00\\x00"', src)
    return src

def insert_repair_method(src: str) -> str:
    """
    Entfernt evtl. freie Funktion `_on_click_repair_deep(self, ...)` am Modulende
    und fügt sie als Klassenmethode direkt hinter `_on_click_run` ein (falls nicht vorhanden).
    """
    # Inhalt der Methode:
    method = (
        "    def _on_click_repair_deep(self, _evt=None):\n"
        "        \"\"\"Startet tiefe Reparatur (Sanity + UnexpectedIndent-Fix) und aktualisiert Status.\"\"\"\n"
        "        try:\n"
        "            self._ping(\"Repariere…\")\n"
        "        except Exception:\n"
        "            pass\n"
        "        try:\n"
        "            import subprocess, os, sys\n"
        "            base = os.path.abspath(os.path.join(os.path.dirname(__file__), \"..\"))\n"
        "            tools = os.path.join(base, \"tools\")\n"
        "            cmds = [\n"
        "                [sys.executable, \"-3\", os.path.join(tools, \"Runner_1114_DeepSanityAndRepair.py\")],\n"
        "                [sys.executable, \"-3\", os.path.join(tools, \"Runner_1114b_FixUnexpectedIndent_MainGUI.py\")],\n"
        "            ]\n"
        "            for cmd in cmds:\n"
        "                try:\n"
        "                    subprocess.run(cmd, cwd=base, check=False)\n"
        "                except Exception as ex:\n"
        "                    print(\"[Repair] Fehler:\", ex)\n"
        "        except Exception as ex:\n"
        "            print(\"[Repair] Unerwarteter Fehler:\", ex)\n"
        "        try:\n"
        "            self._ping(\"Reparatur fertig ✓\")\n"
        "        except Exception:\n"
        "            pass\n"
    )

    # 1) freie Funktion entfernen (falls vorhanden)
    src = re.sub(
        r'(?m)^\s*def\s+_on_click_repair_deep\s*\(self[^)]*\):[\s\S]+?\n(?=def|#|$)',
        '',
        src
    )

    # 2) wenn die Methode in der Klasse schon existiert, nichts tun
    if re.search(r'class\s+IntakeFrame\(ttk\.Frame\):[\s\S]+?_on_click_repair_deep\s*\(', src):
        return src

    # 3) hinter _on_click_run einfügen
    def insert_after_on_run(block: re.Match) -> str:
        body = block.group(0)
        body = re.sub(r'(\n\s*def\s+_on_click_run\s*\([\s\S]+?\n)(\s*#\s*stubs used by table context menu|\s*def\s+_copy_selected)', r'\1' + method + r'\2', body, count=1)
        return body

    src = re.sub(
        r'(class\s+IntakeFrame\(ttk\.Frame\):[\s\S]+?)(\n#\s*----------------\s*Windows\s*Recycle)',
        lambda m: insert_after_on_run(m),
        src,
        count=1
    )
    return src

def sanity_compile(txt: str):
    code = compile(txt, MOD, "exec")  # wirft SyntaxError bei Fehlern
    return code is not None

def main():
    if not os.path.exists(MOD):
        print(TAG, "Datei nicht gefunden:", MOD); return
    os.makedirs(ARCH, exist_ok=True)
    ts = str(int(time.time()))
    bak = os.path.join(ARCH, f"module_code_intake.py.{ts}.bak")
    shutil.copy2(MOD, bak)
    print(TAG, "Backup:", bak)

    src = read_text(MOD)

    src1 = ensure_future_at_top(src)
    src1 = fix_toolbar_block(src1)
    src1 = fix_editor_binds(src1)
    src1 = fix_recycle_bin_helper(src1)
    src1 = insert_repair_method(src1)

    try:
        sanity_compile(src1)
    except SyntaxError as ex:
        print(TAG, "SyntaxError nach Fix:", ex)
        print(TAG, "Schreibvorgang abgebrochen. Datei bleibt unverändert.")
        return

    if src1 != src:
        write_text(MOD, src1)
        print(TAG, "Repariert & gespeichert.")
    else:
        print(TAG, "Keine Änderungen nötig.")
    print(TAG, "Syntax OK.")

if __name__ == "__main__":
    main()
