# -*- coding: utf-8 -*-
"""
Runner_1177l_CleanTabMount
Saubere, zentrale Intake-Montage in main_gui.py:
- Stellt korrekten Shim-Import sicher
- Fügt/ersetzt _safe_add_intake_tab(nb) (idempotent, Logging)
- Ruft _safe_add_intake_tab(...) genau EINMAL direkt nach der Erstellung des Haupt-Notebooks auf
- Entfernt/neutralisiert veraltete _mount_*_shim-Aufrufe an falscher Stelle
Backups -> _Archiv/, Logging -> debug_output.txt
"""
from __future__ import annotations
import os, re, shutil, datetime

ROOT  = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
ARCH  = os.path.join(ROOT, "_Archiv")
LOGF  = os.path.join(ROOT, "debug_output.txt")
TARGET= os.path.join(ROOT, "main_gui.py")

def ts(): return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def log(msg: str):
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(f"[{ts()}] [R1177l] {msg}\n")
    except Exception:
        pass

def backup(path: str):
    if not os.path.exists(path): return
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(path)}.{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.bak")
    shutil.copy2(path, bak)
    log(f"Backup: {bak}")

SAFE_FUNC = r'''
# ----- R1177l: zentraler Intake-Mount (idempotent) -----
def _safe_add_intake_tab(nb):
    """Hängt den Intake-Tab an das gegebene ttk.Notebook nb.
    - idempotent (wenn schon vorhanden -> nur select)
    - sauberes Fehler-Logging
    """
    try:
        from tkinter import ttk
        if not isinstance(nb, ttk.Notebook):
            try:
                _log("IntakeMount: nb ist kein Notebook.")
            except Exception:
                pass
            return False
        # Intake schon vorhanden?
        try:
            for i in range(len(nb.tabs())):
                if nb.tab(i, "text") == "Intake":
                    nb.select(i)
                    try: _log("IntakeMount: Tab existiert -> select.")
                    except Exception: pass
                    return True
        except Exception:
            pass
        # Neu montieren
        try:
            from modules.module_shim_intake import mount_intake_tab
        except Exception as e:
            try: _log(f"IntakeMount: Shim-Import fehlgeschlagen: {e}")
            except Exception: pass
            return False
        try:
            mount_intake_tab(nb)
            try: _log("IntakeMount: Tab montiert.")
            except Exception: pass
            return True
        except Exception as e:
            try: _log(f"IntakeMount: Montage-Fehler: {e}")
            except Exception: pass
            return False
    except Exception as e:
        try: _log(f"IntakeMount: Unerwarteter Fehler: {e}")
        except Exception: pass
        return False
# ----- /R1177l -----
'''

def ensure_imports(src: str) -> str:
    # Entferne alte Shim-API-Imports und ersetze mit modernem Import
    src = re.sub(
        r'from\s+modules\.module_shim_intake\s+import\s+.*',
        'from modules.module_shim_intake import mount_intake_tab  # R1177l',
        src, count=1
    ) if 'module_shim_intake' in src else 'from modules.module_shim_intake import mount_intake_tab  # R1177l\n' + src
    return src

def ensure_safe_func(src: str) -> str:
    if re.search(r'def\s+_safe_add_intake_tab\s*\(', src):
        # Ersetzen vorhandener Implementierung
        src = re.sub(
            r'def\s+_safe_add_intake_tab\s*\([\s\S]*?\)\s*:[\s\S]*?(?=\n# ----- /R1177l -----|^def\s|\Z)',
            SAFE_FUNC.strip() + "\n",
            src, count=1, flags=re.MULTILINE
        )
        return src
    # Sonst: vor der Hauptklasse oder nach Imports einfügen
    m = re.search(r'^\s*class\s+\w+\s*\(\s*ttk\.\w+\s*\)\s*:', src, flags=re.MULTILINE)
    insert_at = m.start() if m else len(src)
    return src[:insert_at] + SAFE_FUNC + src[insert_at:]

def neutralize_early_mounts(src: str) -> str:
    """
    Entfernt/kommentiert alte frühe Aufrufe wie:
      _mount_intake_tab_shim(nb)
      mount_intake_tab(nb)
      _remount_intake_tab_shim(nb)
    außerhalb des neuen definierten Ortes.
    """
    # Markiere alle Aufrufe – später setzen wir den offiziellen Call gezielt
    patterns = [
        r'\n\s*_mount_intake_tab_shim\s*\(\s*[\w\.]+\s*\)\s*',
        r'\n\s*_remount_intake_tab_shim\s*\(\s*[\w\.]+\s*\)\s*',
        r'\n\s*mount_intake_tab\s*\(\s*[\w\.]+\s*\)\s*'
    ]
    for pat in patterns:
        src = re.sub(pat, '\n# [R1177l] (alt) Intake-Mount hier entfernt\n', src)
    return src

def place_single_mount_after_nb_creation(src: str) -> str:
    """
    Sucht die Erstellung des Haupt-Notebooks und fügt danach EINEN Aufruf ein.
    Deckt beide Varianten ab:
      self.nb = ttk.Notebook(self)
      nb = ttk.Notebook(self)
    """
    inserted = False

    # Variante 1: self.nb = ttk.Notebook(...)
    def repl_self(m):
        nonlocal inserted
        inserted = True
        line = m.group(0)
        indent = m.group('indent')
        return line + f"\n{indent}_safe_add_intake_tab(self.nb)  # R1177l\n"

    src, n1 = re.subn(
        r'(?P<indent>^\s*)self\.nb\s*=\s*ttk\.Notebook\([^\n]*\)\s*$',
        repl_self, src, count=1, flags=re.MULTILINE
    )

    if not inserted:
        # Variante 2: nb = ttk.Notebook(...)
        def repl_local(m):
            nonlocal inserted
            inserted = True
            indent = m.group('indent')
            return m.group(0) + f"\n{indent}_safe_add_intake_tab(nb)  # R1177l\n"

        src, n2 = re.subn(
            r'(?P<indent>^\s*)nb\s*=\s*ttk\.Notebook\([^\n]*\)\s*$',
            repl_local, src, count=1, flags=re.MULTILINE
        )

    if not inserted:
        log("WARN: Notebook-Erstellung nicht eindeutig gefunden. Kein Auto-Insert durchgeführt.")
    return src

def main() -> int:
    if not os.path.exists(TARGET):
        print("[R1177l] main_gui.py nicht gefunden.")
        log("main_gui.py missing.")
        return 2

    src = open(TARGET, "r", encoding="utf-8").read()
    orig = src

    # 1) saubere Importe
    src = ensure_imports(src)
    # 2) zentrale Helper-Funktion
    src = ensure_safe_func(src)
    # 3) alte, frühe Mounts neutralisieren
    src = neutralize_early_mounts(src)
    # 4) offiziellen Aufruf hinter Notebook-Erstellung setzen
    src = place_single_mount_after_nb_creation(src)

    if src != orig:
        backup(TARGET)
        with open(TARGET, "w", encoding="utf-8") as f:
            f.write(src)
        log("Clean Tab-Mount in main_gui.py angewendet.")
    else:
        log("Keine Änderungen notwendig (Clean Tab-Mount bereits vorhanden).")

    print("[R1177l] Clean Tab-Mount applied.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
