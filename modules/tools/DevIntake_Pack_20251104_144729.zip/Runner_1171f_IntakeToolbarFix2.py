# -*- coding: utf-8 -*-
"""
R1171f_IntakeToolbarFix2
- Ersetzt 1171e: verwendet FUNKTIONALE Replacements (kein \1...\2-String),
  behebt dadurch 'invalid group reference'.
- Toolbar-Fixes (idempotent):
    * bar.columnconfigure(X, weight=1)  -> X=198
    * self.lbl_ping.grid(..., column=Y) -> Y=198
    * self.btn_del.grid (..., column=Z) -> Z=4
    * Buttontexte: entfernt am Textende ' ( … )'
- Backup + Syntax-Check + Rollback, ausführliches Logging.
Exit: 0 OK, 1 Fehler
"""
from __future__ import annotations
import os, re, time, py_compile, traceback

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOG    = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1171f {ts}] {msg}\n"
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "r", encoding="utf-8") as fi, open(dst, "w", encoding="utf-8", newline="") as fo:
        fo.write(fi.read())
    return dst

def sub_count(pattern: re.Pattern, text: str, repl_fn) -> tuple[str, int]:
    """re.sub mit Zählung und funktionalem Replacement."""
    count = 0
    def _wrap(m):
        nonlocal count
        count += 1
        return repl_fn(m)
    return pattern.sub(_wrap, text), count

def main() -> int:
    try:
        if not os.path.exists(TARGET):
            log(f"Zieldatei fehlt: {TARGET}")
            return 1

        src = open(TARGET, "r", encoding="utf-8").read()
        changed = 0

        # 1) Stretch-Spalte -> 198
        #    bar.columnconfigure(<zahl>, weight=1)
        rx_colcfg = re.compile(r'(?m)^(\s*bar\.columnconfigure\()\s*(\d+)\s*(,\s*weight\s*=\s*1\s*\))\s*$')
        def repl_colcfg(m):
            idx = m.group(2)
            if idx == "198":
                return m.group(0)
            return f"{m.group(1)}198{m.group(3)}"
        src, n = sub_count(rx_colcfg, src, repl_colcfg)
        if n: changed += n; log(f"bar.columnconfigure: {n} Stelle(n) auf 198 gesetzt")

        # 2) lbl_ping -> column=198
        rx_lbl = re.compile(r'(?m)^(\s*self\.lbl_ping\.grid\([^)]*?\bcolumn\s*=\s*)(\d+)(\b[^)]*\))')
        def repl_lbl(m):
            if m.group(2) == "198":
                return m.group(0)
            return f"{m.group(1)}198{m.group(3)}"
        src, n = sub_count(rx_lbl, src, repl_lbl)
        if n: changed += n; log(f"lbl_ping.column: {n} Stelle(n) auf 198 gesetzt")

        # 3) btn_del -> column=4
        rx_del = re.compile(r'(?m)^(\s*self\.btn_del\.grid\([^)]*?\bcolumn\s*=\s*)(\d+)(\b[^)]*\))')
        def repl_del(m):
            if m.group(2) == "4":
                return m.group(0)
            return f"{m.group(1)}4{m.group(3)}"
        src, n = sub_count(rx_del, src, repl_del)
        if n: changed += n; log(f"btn_del.column: {n} Stelle(n) auf 4 gesetzt")

        # 4) Buttontexte: Text-Ende von (Klammern) befreien – nur für btn_*
        #    self.btn_xyz = ttk.Button(..., text="Irgendwas (Ctrl+S)")
        rx_btn_text = re.compile(
            r'(?m)^(?P<pfx>\s*self\.btn_[A-Za-z0-9_]+\s*=\s*ttk\.Button\([^)]*?\btext\s*=\s*")(?P<txt>[^"]*?)(?P<suf>"[^)]*\))?'
        )
        # Wir bereinigen nur, wenn der Text mit " (....)" endet
        def repl_text(m):
            txt = m.group("txt")
            new_txt = re.sub(r"\s*\([^)]*\)\s*$", "", txt)
            if new_txt == txt:
                return m.group(0)
            return f'{m.group("pfx")}{new_txt}"'  # Rest der Parameter bleibt wie im Original vor dem nächsten Komma
        src2, n = sub_count(rx_btn_text, src, repl_text)
        # Falls der obige Regex zu breit ist, n kann 0 bleiben – das ist OK.
        if n:
            changed += n; src = src2; log(f"Buttontexte gesäubert: {n} Treffer")
        else:
            src = src2  # identisch

        if not changed:
            log("Keine Änderung erforderlich (idempotent).")
            return 0

        bak = backup(TARGET); log(f"Backup erstellt: {bak}")
        with open(TARGET, "w", encoding="utf-8", newline="\n") as f:
            f.write(src)

        try:
            py_compile.compile(TARGET, doraise=True)
        except Exception as e:
            # Rollback
            with open(bak, "r", encoding="utf-8") as fi, open(TARGET, "w", encoding="utf-8", newline="\n") as fo:
                fo.write(fi.read())
            log("Syntax-Check FEHLER -> Rollback auf Backup.")
            log("Traceback:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 1

        log("Patch erfolgreich eingefügt und Syntax-Check OK.")
        return 0

    except Exception as e:
        log("UNERWARTETER FEHLER:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
