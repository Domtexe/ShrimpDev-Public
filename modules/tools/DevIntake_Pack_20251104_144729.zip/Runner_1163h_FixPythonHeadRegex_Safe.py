# -*- coding: utf-8 -*-
"""
R1163h_FixPythonHeadRegex_Safe
Ersetzt die fehlerhafte Regex-Zeile in _guess_ext_from_text durch eine balancierte, sichere Variante.
"""
import re, time, shutil, io, py_compile, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
LOGF = ROOT / "debug_output.txt"

OLD = r'if re\.search\(r"(?m)\^\\s\*\(from\\s\+\\w\+\\s\+import\|import\\s\+\\w\+\|def\\s\+\\w\+\\\(|class\\s\+\\w\+\\\(|if\\s\+__name__\\s\*==\\s\*\[\'\\\"]__main__\[\'\\\"]\)"'
NEW = r'if re.search(r"(?m)^\s*(?:from\s+\w+\s+import|import\s+\w+|def\s+\w+\s*\(|class\s+\w+\s*\(|if\s+__name__\s*==\s*[\'\"]__main__[\'\"])", " "+head): return ".py"'

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(LOGF, "a", encoding="utf-8") as f:
        f.write(f"[R1163h] {ts} {msg}\n")
    print(f"[R1163h] {ts} {msg}")

def backup():
    ARCH.mkdir(exist_ok=True)
    dst = ARCH / f"{MOD.name}.{int(time.time())}.bak"
    shutil.copy2(MOD, dst)
    log(f"Backup: {MOD} -> {dst}")
    return dst

def main():
    try:
        text = MOD.read_text(encoding="utf-8")
        bak = backup()
        if "def _guess_ext_from_text" not in text:
            log("No _guess_ext_from_text found.")
            return 0

        pattern = re.compile(r'if re\.search\(r"[^"]+__main__[^"]*",\s*" \+head\): return ".py"')
        new_text, n = pattern.subn(NEW, text)
        if n == 0:
            log("No matching line replaced.")
            return 0

        MOD.write_text(new_text, encoding="utf-8", newline="\n")
        log(f"Replaced {n} pattern(s).")

        try:
            py_compile.compile(str(MOD), doraise=True)
            log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}")
            shutil.copy2(bak, MOD)
            log("Restored from backup.")
            return 1

        log("R1163h completed successfully.")
        return 0
    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
