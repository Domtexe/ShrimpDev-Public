# -*- coding: utf-8 -*-
"""
R1171k_IntakeToolbarReflowExternalize
- Entfernt ALLE verschachtelten/übrig gebliebenen 'def _intake_toolbar_reflow(...):'-Blöcke
  per Indent-Analyse.
- Schreibt externen Helper 'modules/snippets/intake_toolbar_reflow_helper.py'.
- Sichert Package-Struktur (snippets/__init__.py).
- Patched R1170e-Lifecycle zu: from .snippets.intake_toolbar_reflow_helper import intake_toolbar_reflow as _intake_toolbar_reflow_ext
  und ruft _intake_toolbar_reflow_ext(self).
- Idempotent, mit Backup + Syntax-Check + Rollback.
Exit: 0 OK, 1 Fehler.
"""
from __future__ import annotations
import os, re, time, py_compile, traceback

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
SNIP   = os.path.join(ROOT, "modules", "snippets")
SNIP_INIT = os.path.join(SNIP, "__init__.py")
SNIP_HELP = os.path.join(SNIP, "intake_toolbar_reflow_helper.py")
LOG    = os.path.join(ROOT, "debug_output.txt")
MARK_LIFE = "# R1170e: lifecycle wire"

HELPER_CODE = r'''
"""
Toolbar-Reflow-Helper (extern, robust)
Ordnet die Toolbar in links (über Editor) und rechts (über Dateiliste).
Zwischen beiden liegt eine Stretch-Trennspalte. Status: links (lbl_ping), rechts ("Erkennung: …").
"""
from tkinter import ttk

def intake_toolbar_reflow(self):
    try:
        # Parent bestimmen: nimm Parent eines vorhandenen Buttons
        parent = None
        for name in dir(self):
            if not name.startswith("btn_"):
                continue
            try:
                b = getattr(self, name, None)
                if b and getattr(b, "winfo_exists", lambda: False)():
                    parent = b.nametowidget(b.winfo_parent()); break
            except Exception:
                pass
        if parent is None:
            parent = getattr(self, "frm_actions", None)
        if parent is None:
            return

        # Spaltengewichte: 0..39 links, 40 Stretch, 41..197 rechts, 198 zusätzlicher Stretch
        for i in range(0, 200):
            try: parent.columnconfigure(i, weight=0)
            except Exception: pass
        parent.columnconfigure(40, weight=1)
        parent.columnconfigure(198, weight=1)

        def _grid(w, c, padx=(0,6), sticky="w"):
            try: w.grid(row=0, column=c, padx=padx, sticky=sticky)
            except Exception: pass

        def _opt(n):
            w = getattr(self, n, None)
            return w if w and getattr(w, "winfo_exists", lambda: False)() else None

        # --- Linke Gruppe (über Editor) ---
        colL = 0
        for n in ("btn_clear", "btn_detect", "btn_save"):
            w = _opt(n)
            if w: _grid(w, colL); colL += 1

        # linker Status (lbl_ping) bis Stretch-Spalte
        lbl = getattr(self, "lbl_ping", None)
        if not lbl:
            lbl = ttk.Label(parent, text="", anchor="w"); self.lbl_ping = lbl
        lbl.grid(row=0, column=colL, padx=(12,4), sticky="ew")
        try: lbl.grid_configure(columnspan=max(1, 40 - colL))
        except Exception: pass

        # --- Rechte Gruppe (über Dateiliste) ---
        colR = 41
        for n in ("btn_guard", "btn_repair", "btn_run", "btn_refresh", "btn_pack", "btn_delete"):
            w = _opt(n) or _opt(n.replace("btn_delete","btn_del"))
            if w: _grid(w, colR); colR += 1

        # rechter Status: "Erkennung: …"
        detect_lbl = None
        for nm in dir(self):
            if nm.startswith("lbl_") and "detect" in nm:
                detect_lbl = getattr(self, nm, None); break
        if detect_lbl is None:
            for nm in dir(self):
                try:
                    w = getattr(self, nm, None)
                    if hasattr(w, "cget") and isinstance(w.cget("text"), str) and "Erkennung" in w.cget("text"):
                        detect_lbl = w; break
                except Exception:
                    pass
        if detect_lbl is None:
            detect_lbl = ttk.Label(parent, text="Erkennung: (keine)", anchor="e")
            self.lbl_detect = detect_lbl
        detect_lbl.grid(row=0, column=colR, padx=(12,0), sticky="ew")
        try: detect_lbl.grid_configure(columnspan=max(1, 198 - colR))
        except Exception: pass

        # Konsistente Optik
        try:
            style = ttk.Style(); style.configure("TButton", padding=(10,4))
        except Exception:
            pass

    except Exception:
        # keine Exceptions nach außen
        pass
'''.lstrip("\n")

def _log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1171k {ts}] {msg}\n"
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def _backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "r", encoding="utf-8") as fi, open(dst, "w", encoding="utf-8", newline="") as fo:
        fo.write(fi.read())
    return dst

def _collect_blocks(lines: list[str]) -> list[tuple[int,int,int]]:
    """Finde ALLE 'def _intake_toolbar_reflow(' Blöcke (egal wo)."""
    heads = []
    for i, ln in enumerate(lines):
        if re.match(r'^[ \t]*def\s+_intake_toolbar_reflow\s*\(', ln):
            indent_len = len(ln) - len(ln.lstrip(" \t"))
            j = i + 1
            while j < len(lines):
                s = lines[j]
                if s.strip() == "":
                    j += 1; continue
                lead = len(s) - len(s.lstrip(" \t"))
                if lead < indent_len:
                    break
                j += 1
            heads.append((i, j, indent_len))
    return heads

def _ensure_snippet_files() -> None:
    os.makedirs(SNIP, exist_ok=True)
    if not os.path.exists(SNIP_INIT):
        with open(SNIP_INIT, "w", encoding="utf-8", newline="\n") as f:
            f.write("# package for external helpers\n")
    with open(SNIP_HELP, "w", encoding="utf-8", newline="\n") as f:
        f.write(HELPER_CODE)

def _patch_lifecycle(src: str) -> tuple[str, bool]:
    if MARK_LIFE not in src:
        _log("Warnung: R1170e-Lifecycle-Block fehlt – Import/Call wird NICHT injiziert.")
        return src, False
    m = re.search(r'(?m)^([ \t]*)' + re.escape(MARK_LIFE) + r'\s*$', src)
    base = m.group(1)
    start = m.end()
    pat_end = re.compile(r'(?m)^(%s)(def|class)\b' % re.escape(base))
    m_end = pat_end.search(src, start)
    end = m_end.start() if m_end else len(src)
    block = src[start:end]
    need_import = "intake_toolbar_reflow_helper" not in block
    need_call   = "_intake_toolbar_reflow_ext(self)" not in block
    if not (need_import or need_call):
        return src, False
    imp = base + "    try:\n" + \
          base + "        from .snippets.intake_toolbar_reflow_helper import intake_toolbar_reflow as _intake_toolbar_reflow_ext\n" + \
          base + "        _intake_toolbar_reflow_ext(self)\n" + \
          base + "    except Exception:\n" + \
          base + "        pass\n"
    block = block.rstrip() + "\n" + imp
    return src[:start] + block + src[end:], True

def main() -> int:
    try:
        if not os.path.exists(TARGET):
            _log(f"Zieldatei fehlt: {TARGET}")
            return 1

        raw = open(TARGET, "r", encoding="utf-8").read()
        lines = raw.splitlines(True)

        # 1) Alle lokalen _intake_toolbar_reflow-Defs entfernen
        blocks = _collect_blocks(lines)
        removed = 0
        if blocks:
            for s, e, _ind in sorted(blocks, key=lambda t: t[0], reverse=True):
                del lines[s:e]; removed += 1
            _log(f"Lokale _intake_toolbar_reflow-Defs entfernt: {removed}")

        src = "".join(lines)

        # 2) Externen Helper schreiben/aktualisieren
        _ensure_snippet_files()
        _log("Externer Helper geschrieben: modules/snippets/intake_toolbar_reflow_helper.py")

        # 3) Lifecycle-Block patchen (Import + Call)
        src, changed_life = _patch_lifecycle(src)
        if changed_life:
            _log("Lifecycle-Block: Import+Call injiziert/ergänzt.")

        if not removed and not changed_life:
            _log("Keine Änderung erforderlich (idempotent).")
            return 0

        # 4) Backup + Schreiben + Syntax-Check
        bak = _backup(TARGET); _log(f"Backup erstellt: {bak}")
        with open(TARGET, "w", encoding="utf-8", newline="\n") as f:
            f.write(src)

        try:
            # Syntax nur für TARGET prüfen – der externe Helper wird bei Lauf importiert;
            # er enthält keine top-level Syntax-Fallen.
            py_compile.compile(TARGET, doraise=True)
        except Exception as e:
            with open(bak, "r", encoding="utf-8") as fi, open(TARGET, "w", encoding="utf-8", newline="\n") as fo:
                fo.write(fi.read())
            _log("Syntax-Check FEHLER -> Rollback auf Backup.")
            _log("Traceback:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 1

        _log("Patch erfolgreich eingefügt und Syntax-Check OK.")
        return 0

    except Exception as e:
        _log("UNERWARTETER FEHLER:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
