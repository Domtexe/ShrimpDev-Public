from __future__ import annotations
from pathlib import Path
import re, time, shutil, py_compile, sys

ROOT = Path(r"D:\ShrimpDev")
MAIN = ROOT / "main_gui.py"

def ts(): return time.strftime("%Y%m%d_%H%M%S")

def backup(p: Path):
    if p.exists():
        bak = p.with_suffix(p.suffix + f".{ts()}.bak")
        shutil.copy2(p, bak)
        print(f"[R950] Backup: {bak.name}")

def context(lines: list[str], idx: int, radius: int = 3) -> str:
    lo = max(0, idx - radius); hi = min(len(lines), idx + radius + 1)
    out = []
    w = len(str(hi))
    for i in range(lo, hi):
        mark = ">>" if i == idx else "  "
        out.append(f"{mark} {i+1:>{w}}: {lines[i].rstrip()}")
    return "\n".join(out)

def is_blank_or_comment(s: str) -> bool:
    t = s.strip()
    if not t: return True
    return t.startswith(("#", '"""', "'''"))

def fix_try_suite(lines: list[str]) -> tuple[list[str], int]:
    """
    Nach jedem 'try:' ohne Suite füge 'pass' ein.
    Ebenso für 'except:' / 'finally:' / 'else:' ohne Suite.
    Gibt (neue_zeilen, fixes_anzahl) zurück.
    """
    out: list[str] = []
    fixes = 0
    i = 0
    n = len(lines)

    clause_pat = re.compile(r'^\s*(try|except|finally|else)\s*:\s*$')
    while i < n:
        line = lines[i]
        out.append(line)
        m = clause_pat.match(line)
        if m:
            indent = len(line) - len(line.lstrip(" "))
            # nächstes physisches Line anschauen (wenn vorhanden)
            if i + 1 >= n:
                out.append(" " * (indent + 4) + "pass  # [R950 add @EOF]")
                fixes += 1
            else:
                nxt = lines[i + 1]
                nxt_indent = len(nxt) - len(nxt.lstrip(" "))
                nxt_blank = is_blank_or_comment(nxt)

                # Fall A: nächste Zeile dedentet oder gleiches Indent → keine Suite
                if (not nxt.strip()) or nxt_indent <= indent:
                    out.append(" " * (indent + 4) + "pass  # [R950 add]")
                    fixes += 1
                # Fall B: nächste Zeile ist Kommentar/leer, aber gleich eingerückt
                elif nxt_blank and nxt_indent == indent + 4:
                    # prüfe, ob danach echte Suite folgt; wenn nicht, einfügen
                    j = i + 2
                    has_real = False
                    while j < n:
                        s = lines[j]
                        if not s.strip():
                            j += 1; continue
                        si = len(s) - len(s.lstrip(" "))
                        if si < indent + 4:
                            break
                        if not is_blank_or_comment(s):
                            has_real = True
                        break
                    if not has_real:
                        out.append(" " * (indent + 4) + "pass  # [R950 add after comment]")
                        fixes += 1
        i += 1
    return out, fixes

def compile_or_error(p: Path) -> tuple[bool, str]:
    try:
        py_compile.compile(str(p), doraise=True)
        return True, ""
    except Exception as ex:
        return False, str(ex)

def locate_error_line(errmsg: str) -> int | None:
    # Muster: "(main_gui.py, line 128)"
    m = re.search(r'\(.*?,\s*line\s+(\d+)\)', errmsg)
    if m:
        try: return int(m.group(1))
        except Exception: return None
    return None

def main() -> int:
    if not MAIN.exists():
        print("[R950] FEHLT: main_gui.py"); return 2

    backup(MAIN)
    txt = MAIN.read_text(encoding="utf-8", errors="ignore")
    lines = txt.splitlines()

    # Bis zu 5 Iterationen: fixen → kompilieren → ggf. erneut fixen
    for pass_no in range(1, 6):
        ok, err = compile_or_error(MAIN)
        if ok:
            print("[R950] Syntax OK – keine weiteren Fixes nötig.")
            return 0

        # Fehlerspur ausgeben
        ln = locate_error_line(err)
        print(f"[R950] PASS {pass_no}: compile error: {err}")
        if ln:
            print("[R950] Kontext rund um Fehler:")
            print(context(lines, ln - 1))

        # Fix anwenden
        new_lines, fixes = fix_try_suite(lines)
        if fixes == 0:
            # kein try/finally/except/else-Problem mehr – nichts zu tun
            print("[R950] Keine weiteren try/except/finally/else-Fixes gefunden.")
            break

        # speichern & erneut versuchen
        lines = new_lines
        MAIN.write_text("\n".join(lines), encoding="utf-8")
        print(f"[R950] Fixes angewendet: {fixes} – erneut kompilieren...")

    # finaler Kompilationsversuch
    ok, err = compile_or_error(MAIN)
    if ok:
        print("[R950] Syntax OK nach Fix.")
        return 0
    else:
        print(f"[R950] FEHLER bleibt: {err}")
        # letzten Kontext zeigen
        ln = locate_error_line(err)
        if ln:
            print("[R950] Letzter Kontext:")
            print(context(lines, ln - 1))
        return 1

if __name__ == "__main__":
    sys.exit(main())
