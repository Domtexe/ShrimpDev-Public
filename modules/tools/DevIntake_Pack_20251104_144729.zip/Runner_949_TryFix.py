from __future__ import annotations
from pathlib import Path
import re, time, shutil, py_compile

ROOT = Path(r"D:\ShrimpDev")
MAIN = ROOT / "main_gui.py"

def ts(): return time.strftime("%Y%m%d_%H%M%S")

def backup(p: Path):
    if not p.exists(): return
    b = p.with_suffix(p.suffix + f".{ts()}.bak")
    shutil.copy2(p, b)
    print(f"[R949] Backup: {b.name}")

def fix_try_blocks(txt: str) -> str:
    """Fügt nach jedem 'try:' ohne eingerückte Zeile ein 'pass' ein."""
    lines = txt.splitlines()
    out = []
    for i, line in enumerate(lines):
        out.append(line)
        if re.match(r'^\s*try\s*:\s*$', line):
            nxt = lines[i + 1] if i + 1 < len(lines) else ''
            if not nxt.strip() or len(nxt) - len(nxt.lstrip()) <= len(line) - len(line.lstrip()):
                indent = ' ' * (len(line) - len(line.lstrip()) + 4)
                out.append(f"{indent}pass  # auto-fix [R949]")
    return "\n".join(out)

def main():
    if not MAIN.exists():
        print("[R949] main_gui.py fehlt."); return 2
    backup(MAIN)
    code = MAIN.read_text(encoding="utf-8", errors="ignore")
    fixed = fix_try_blocks(code)
    MAIN.write_text(fixed, encoding="utf-8")
    try:
        py_compile.compile(str(MAIN), doraise=True)
        print("[R949] Syntax OK – main_gui.py repariert.")
        return 0
    except Exception as ex:
        print(f"[R949] Syntaxfehler bleibt: {ex}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
