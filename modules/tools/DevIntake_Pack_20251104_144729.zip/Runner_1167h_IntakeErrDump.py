# -*- coding: utf-8 -*-
"""
Runner_1167h_IntakeErrDump
Liest den in main_gui gesetzten Fallback-Trace (_INTAKE_ERR) aus und schreibt ihn
in _Reports/Intake_err.txt und debug_output.txt. Read-only.
Exitcode: 0 = ok (Trace gefunden/leer), 1 = Importfehler.
"""
from __future__ import annotations
import os, sys, time, traceback, importlib

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
LOG  = os.path.join(ROOT, "debug_output.txt")
REP  = os.path.join(ROOT, "_Reports", "Intake_err.txt")

def _log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1167h {ts}] {msg}\n"
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def main() -> int:
    try:
        os.makedirs(os.path.dirname(REP), exist_ok=True)
        os.chdir(ROOT)
        sys.path.insert(0, ROOT)

        mg = importlib.import_module("main_gui")
        err = getattr(mg, "_INTAKE_ERR", "")
        if not err:
            _log("Hinweis: _INTAKE_ERR ist leer. (Kein aktueller Importfehler im Intake-Pfad?)")
        else:
            _log("Traceback aus _INTAKE_ERR gefunden – schreibe Report.")
        with open(REP, "w", encoding="utf-8", newline="") as f:
            f.write(err or "[leer]")
        _log(f"Report geschrieben: {os.path.relpath(REP, ROOT)}")
        return 0
    except Exception as e:
        _log(f"UNERWARTETER FEHLER: {e}")
        _log(traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
