# -*- coding: utf-8 -*-
"""
Runner_1177h_IntakeImportCheck
- Keine Änderungen am System; reine Diagnose.
- Prüft Importkette für Intake (Shim + echtes Intake).
- Loggt klare Befunde in debug_output.txt.
"""
from __future__ import annotations
import os, sys, importlib, traceback, types, datetime

ROOT = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
LOGF = os.path.join(ROOT, "debug_output.txt")
MODS = os.path.join(ROOT, "modules")

def ts(): return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def log(msg: str):
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(f"[{ts()}] [R1177h] {msg}\n")
    except Exception:
        pass

def safe_import(name: str):
    try:
        mod = importlib.import_module(name)
        log(f"import OK: {name}  (file={getattr(mod, '__file__', '?')})")
        return mod, None
    except Exception as e:
        log(f"import FAIL: {name}: {e}")
        tb = traceback.format_exc(limit=3)
        log(tb.strip())
        return None, e

def check_shim(mod_shim: types.ModuleType):
    ok = True
    required = ("mount_intake_tab","_mount_intake_tab_shim","_remount_intake_tab_shim")
    for r in required:
        has = hasattr(mod_shim, r)
        log(f"shim.has {r} = {has}")
        ok &= has
    # Versuche, die Quelle des Frames zu ermitteln
    src_hint = None
    try:
        # häufige Muster: Adapter-Klasse mit _frame() oder direktem Import
        txt = open(os.path.join(MODS, "module_shim_intake.py"), "r", encoding="utf-8").read()
        if "from modules.module_code_intake import IntakeFrame" in txt:
            src_hint = "modules.module_code_intake.IntakeFrame"
        log("shim source hint: " + str(src_hint))
    except Exception as e:
        log(f"shim read fail: {e}")
    return ok

def check_intake_module():
    mod, err = safe_import("modules.module_code_intake")
    if not mod:
        return False
    has_class = hasattr(mod, "IntakeFrame")
    log(f"module_code_intake.IntakeFrame exists = {has_class}")
    if not has_class:
        return False
    # Instanziert IntakeFrame minimal in einem unsichtbaren Tk-Kontext
    try:
        import tkinter as tk
        from tkinter import ttk
        root = tk.Tk()
        root.withdraw()
        frm = mod.IntakeFrame(root)  # darf keine Exceptions werfen
        # prüfe, ob zentrale Attribute vorhanden sind oder sich nachbauen lassen
        attrs = ["nb", "lbl_status"]
        for a in attrs:
            log(f"IntakeFrame has '{a}' = {hasattr(frm, a)}")
        frm.destroy()
        root.destroy()
        log("IntakeFrame instantiation: OK")
        return True
    except Exception as e:
        log(f"IntakeFrame instantiation FAIL: {e}")
        tb = traceback.format_exc(limit=3)
        log(tb.strip())
        return False

def main() -> int:
    log("=== Intake Import Diagnostics START ===")
    log(f"ROOT={ROOT}")
    log(f"sys.executable={sys.executable}")
    log("sys.path[0..5]= " + " | ".join(sys.path[:6]))

    # 1) Shim prüfen
    shim, _ = safe_import("modules.module_shim_intake")
    shim_ok = False
    if shim:
        shim_ok = check_shim(shim)

    # 2) Echten Intake prüfen
    intake_ok = check_intake_module()

    # 3) Befund
    if shim_ok and intake_ok:
        log("RESULT: Shim OK + IntakeFrame OK. Erwartung: Dev-Intake sollte sichtbar sein.")
        rc = 0
    elif shim_ok and not intake_ok:
        log("RESULT: Shim OK, aber module_code_intake fehlerhaft/leer. Bitte Dev-Intake neu schreiben oder reparieren.")
        rc = 2
    elif not shim_ok and intake_ok:
        log("RESULT: IntakeFrame OK, aber Shim-API unvollständig. Shim aktualisieren.")
        rc = 3
    else:
        log("RESULT: Sowohl Shim als auch IntakeFrame fehlerhaft. Ursachen siehe obige Logs.")
        rc = 4

    log("=== Intake Import Diagnostics END ===")
    print(f"[R1177h] Diagnostics done (rc={rc}). See debug_output.txt.")
    return rc

if __name__ == "__main__":
    raise SystemExit(main())
