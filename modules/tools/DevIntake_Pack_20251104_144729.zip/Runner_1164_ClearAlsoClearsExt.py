# -*- coding: utf-8 -*-
"""
R1164 ClearAlsoClearsExt
- Ergänzt im Editor-Clear-Handler: auch Endung zurücksetzen.
- Nicht-invasiv: versucht beide Varianten (self.var_ext / self.entry_ext) mit try/except.
- Safety: Backup, Syntax-Check, Rollback. Macht nur eine kleine Code-Injektion in die Clear-Funktion.
"""
from __future__ import annotations
import os, io, re, time, shutil, py_compile, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOGF = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with io.open(LOGF, "a", encoding="utf-8") as f: f.write(f"[R1164] {ts} {msg}\n")
    print(f"[R1164] {ts} {msg}")

INJECT = (
    "        # R1164: also clear extension field (safe best-effort)\n"
    "        try:\n"
    "            getattr(self, 'var_ext').set('')\n"
    "        except Exception:\n"
    "            try:\n"
    "                ent = getattr(self, 'entry_ext')\n"
    "                ent.delete(0, 'end')\n"
    "            except Exception:\n"
    "                pass\n"
)

def backup(p: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, dst); log(f"Backup: {p} -> {dst}"); return dst

def patch(src: str) -> tuple[str, list[str]]:
    changes = []
    # Finde eine Clear-Funktion – häufig: def on_clear_editor(self): oder def clear_editor(self):
    rx = re.compile(r"^\s*def\s+(on_)?clear_editor\s*\(\s*self[^\)]*\)\s*:\s*$", re.M)
    m = rx.search(src)
    if not m:
        return src, changes
    # nächste Zeile nach Funktionskopf finden und INJECT nach dem ersten Editor-Delete einfügen,
    # ansonsten direkt nach der Kopfzeile.
    start = m.end()
    tail = src[start:]
    # versuche, die erste Löschzeile zu finden (Textwidget .delete oder .set('') o.ä.)
    del_rx = re.compile(r"^\s*self\.\w+\.(delete|set)\(", re.M)
    md = del_rx.search(tail)
    if md:
        # Einfügen NACH dieser Zeile
        insert_at = start + md.end()
        # suche Zeilenende
        line_end = tail.find("\n", md.start())
        if line_end == -1: line_end = len(tail)-1
        insert_abs = start + line_end + 1
        new = src[:insert_abs] + INJECT + src[insert_abs:]
    else:
        # direkt nach Funktionskopf
        new = src[:start] + INJECT + src[start:]
    changes.append("Injected extension-clear logic into clear_editor handler")
    return new, changes

def main() -> int:
    try:
        if not os.path.isfile(MOD): log(f"[ERR] Not found: {MOD}"); return 2
        with io.open(MOD, "r", encoding="utf-8") as f: src = f.read()
        bak = backup(MOD)
        new, changes = patch(src)
        if not changes: log("No changes applied (clear_editor handler not found)."); return 0
        with io.open(MOD, "w", encoding="utf-8", newline="\n") as f: f.write(new)
        for c in changes: log(f"Change: {c}")
        try: py_compile.compile(MOD, doraise=True); log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}"); shutil.copy2(bak, MOD); log("Restored from backup."); return 3
        log("R1164 completed successfully."); return 0
    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}"); return 1

if __name__ == "__main__":
    raise SystemExit(main())
