# -*- coding: utf-8 -*-
"""
Runner_1145_IntakeAudit
Ziel: Intake-Elemente sorgfältig prüfen – ohne Änderungen.
- Statische Analyse (AST + Text-Heuristiken)
- Live-Smoketest (tkinter headless): IntakeFrame instanziieren und Objekte/Bindings prüfen
- Ergebnis als strukturierter Report
RC=0: alles OK/empfehlenswerte Kleinigkeiten
RC=1: Fehler / harte Abweichungen
"""

from __future__ import annotations
import ast, io, os, sys, time, importlib.util, traceback
from pathlib import Path

ROOT    = Path(__file__).resolve().parents[1]
MODPATH = ROOT / "modules" / "module_code_intake.py"
REPORTS = ROOT / "_Reports"; REPORTS.mkdir(exist_ok=True)
REPORT  = REPORTS / "Runner_1145_IntakeAudit_report.txt"

def w(line: str = ""):
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(line.rstrip() + "\n")
    print(line)

def head(title: str):
    w("")
    w("=" * 78)
    w(title)
    w("=" * 78)

def load_source() -> str:
    return io.open(MODPATH, "r", encoding="utf-8", errors="ignore").read()

def ast_tree(src: str):
    try:
        return ast.parse(src), None
    except SyntaxError as e:
        return None, f"SyntaxError: {e.msg} (line {e.lineno})"

def ast_find_class(tree: ast.AST, name: str):
    for n in ast.walk(tree):
        if isinstance(n, ast.ClassDef) and n.name == name:
            return n
    return None

def ast_has_method(cls: ast.ClassDef, name: str):
    for n in cls.body:
        if isinstance(n, ast.FunctionDef) and n.name == name:
            return True
    return False

def import_module_safely() -> tuple[object|None, str|None]:
    """
    Lädt module_code_intake.py als Modul.
    - stellt sicher, dass ROOT auf sys.path liegt
    - optionaler Shim für modules.module_runner_exec, falls nicht vorhanden
    """
    try:
        import importlib.util, importlib.machinery, types, sys as _sys
        # 1) Projekt-Root auf sys.path legen, damit "from modules import ..." funktioniert
        root_str = str(ROOT)
        if root_str not in _sys.path:
            _sys.path.insert(0, root_str)

        # 2) Fallback-Shim bereitstellen, falls module_runner_exec fehlt
        try:
            import modules.module_runner_exec as _mre  # noqa: F401
        except Exception:
            # Leichten Shim registrieren, damit der Import in module_code_intake nicht fehlschlägt
            shim_pkg = types.ModuleType("modules")
            shim_mod = types.ModuleType("modules.module_runner_exec")
            def _shim_run(*args, **kwargs): return 0
            def _shim_log(msg): pass
            shim_mod.run = _shim_run
            shim_mod._log = _shim_log
            _sys.modules.setdefault("modules", shim_pkg)
            _sys.modules["modules.module_runner_exec"] = shim_mod

        # 3) Modul aus Datei laden
        spec = importlib.util.spec_from_file_location("module_code_intake", str(MODPATH))
        if not spec or not spec.loader:
            return None, "Spec/Loader konnte nicht erstellt werden."
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)  # type: ignore[attr-defined]
        return mod, None

    except Exception as e:
        return None, f"ImportError: {e}"

    """
    Lädt module_code_intake.py als Modul, initiiert KEIN Tk-Fenster.
    Für Live-Test wird später Tk headless verwendet.
    """
    try:
        spec = importlib.util.spec_from_file_location("module_code_intake", str(MODPATH))
        mod  = importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        spec.loader.exec_module(mod)  # type: ignore[attr-defined]
        return mod, None
    except Exception as e:
        return None, f"ImportError: {e}"

def live_smoketest(mod) -> list[str]:
    """
    Headless Tk-Test: Tk() -> withdraw(), IntakeFrame instanzieren,
    prüfbare Attribute/Bindings inspizieren.
    """
    issues: list[str] = []
    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        try:
            fr = mod.IntakeFrame(root)
        except Exception as e:
            issues.append(f"Instanziierung IntakeFrame fehlgeschlagen: {e}")
            root.destroy()
            return issues

        # erwartete Widgets
        expected_attrs = [
            "txt", "tbl", "btn_detect", "btn_save", "btn_del",
            "btn_guard", "btn_repair", "btn_run", "lbl_ping",
            "led_target", "led_detect", "led_save", "var_target",
        ]
        for a in expected_attrs:
            if not hasattr(fr, a):
                issues.append(f"Fehlendes Attribut: {a}")

        # Editor-Bindings prüfen (nur wenn txt existiert)
        try:
            txt = fr.txt  # type: ignore[attr-defined]
            # Liste relevanter Events
            events = ["<<Paste>>", "<Control-v>", "<<Modified>>", "<KeyRelease>", "<F5>"]
            for ev in events:
                try:
                    # tcl: bind <widget> <sequence> => liefert Befehl oder ""
                    got = txt.bind(ev) or ""
                except Exception:
                    got = ""
                if not got:
                    issues.append(f"Binding fehlt am Editor: {ev}")
        except Exception:
            issues.append("Text-Widget nicht verfügbar (Bindings nicht geprüft).")

        root.destroy()
    except Exception as e:
        issues.append(f"Tk-Smoke fehlgeschlagen: {e}")
    return issues

def main() -> int:
    # Reset Report
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass

    head("[R1145] IntakeAudit – Start")
    if not MODPATH.exists():
        w(f"[FEHLER] Datei fehlt: {MODPATH}")
        return 1

    # --- Statische Analyse
    head("1) Statische Analyse (AST)")
    src = load_source()
    tree, err = ast_tree(src)
    if err:
        w("[AST] " + err)
        return 1
    w("[AST] Syntax OK.")

    cls = ast_find_class(tree, "IntakeFrame")
    if not cls:
        w("[AST] FEHLER: class IntakeFrame nicht gefunden.")
        return 1

    required_methods = [
        "_build_ui", "_bind_shortcuts",
        "_on_click_detect", "_on_click_save", "_on_click_delete",
        "_on_click_guard", "_on_click_run",
        "_on_editor_paste", "_on_editor_key", "_on_editor_modified",
        "_schedule_detect", "_auto_detect_if_needed",
    ]
    missing = [m for m in required_methods if not ast_has_method(cls, m)]
    if missing:
        w("[AST] Fehlende Methoden: " + ", ".join(missing))
    else:
        w("[AST] Alle Pflicht-Methoden vorhanden.")

    # Heuristik: keine offensichtlichen doppelten/kaputten try/except-Sequenzen
    if "try:\n" in src and "try:\n" in src.split("try:\n", 1)[1]:
        # nicht automatisch Fehler – nur Hinweis
        w("[AST] Hinweis: Mehrere try-Blöcke – visuell prüfen (erwartet in Editor-Handlern).")

    # --- Import-Test
    head("2) Modul-Import")
    mod, imp_err = import_module_safely()
    if imp_err:
        w("[Import] " + imp_err)
        return 1
    w("[Import] OK.")

    # --- Live-Test
    head("3) Live-Smoke (tkinter headless)")
    issues = live_smoketest(mod)
    if issues:
        for i in issues:
            w("[Live] " + i)
    else:
        w("[Live] Alle Widgets & Bindings OK.")

    # Zusammenfassung
    head("4) Zusammenfassung")
    rc = 0 if not issues and not missing else 1
    if rc == 0:
        w("[OK] Intake ist funktionsfähig. Keine harten Abweichungen.")
    else:
        if missing:
            w("[SUM] Fehlende Methoden: " + ", ".join(missing))
        if issues:
            w("[SUM] Live-Issues: " + "; ".join(issues))
        w("[HINWEIS] Ich kann auf Wunsch einen modularen Repair-Runner liefern, der nur die oben aufgeführten Punkte anfasst.")

    return rc

if __name__ == "__main__":
    sys.exit(main())
