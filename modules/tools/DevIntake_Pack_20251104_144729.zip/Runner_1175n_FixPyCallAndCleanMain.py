# -*- coding: utf-8 -*-
"""
[1175n] Repariert den defekten nb.add-Block in main_gui.py
- Entfernt die falsche "def nb.add(__mount_intake_tab_shim(nb), ...):" Def
- Idempotent (kein Effekt, wenn schon bereinigt)
"""
from __future__ import annotations
import os, re, py_compile, shutil

ROOT = r"D:\ShrimpDev"
MAIN = os.path.join(ROOT, "main_gui.py")
DBG  = os.path.join(ROOT, "debug_output.txt")

def log(msg):
    print(msg)
    try:
        with open(DBG, "a", encoding="utf-8") as f:
            f.write(msg + "\n")
    except Exception:
        pass

def compile_ok(path:str) -> bool:
    try:
        py_compile.compile(path, doraise=True)
        return True
    except Exception as e:
        log(f"[1175n] COMPILE_FAIL {path}: {e}")
        return False

def fix_main():
    with open(MAIN, "r", encoding="utf-8") as f:
        src = f.read()

    # Entfernt EXAKT die kaputte Zeile(n) um Zeile ~302:
    # def nb.add(__mount_intake_tab_shim(nb), text="Code Intake"):
    pat = re.compile(
        r"\n[ \t]*def[ \t]+nb\.add\(\s*__mount_intake_tab_shim\(nb\)\s*,\s*text\s*=\s*\"Code Intake\"\s*\)\s*:\s*"
        r"(?:\n[ \t]+.*?)*?(?=\n[^\s]|\n[ \t]*def[ \t]+\w|\Z)",
        re.DOTALL
    )

    if not pat.search(src):
        log("[1175n] main_gui: defekter nb.add-Block nicht gefunden (OK).")
        return

    new = pat.sub("\n# [1175n] Entfernt defekten nb.add-Block (Duplikat)\n", src)
    tmp = MAIN + ".1175n.tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(new)

    if not compile_ok(tmp):
        raise SystemExit(10)

    shutil.move(tmp, MAIN)
    log("[1175n] main_gui: nb.add-Block bereinigt.")

if __name__ == "__main__":
    fix_main()
    if not compile_ok(MAIN):
        raise SystemExit(10)
    log("[1175n] Done.")
