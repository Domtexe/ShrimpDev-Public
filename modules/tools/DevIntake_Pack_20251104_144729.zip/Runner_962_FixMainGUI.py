# tools/Runner_962_FixMainGUI.py
from __future__ import annotations
import shutil, time
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
MAIN = ROOT / "main_gui.py"

GOOD = r'''from __future__ import annotations

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import subprocess
from pathlib import Path

# ---- optionale Module sicher importieren -------------------------------------
def _safe_import(modpath: str, attr: str, fallback):
    try:
        mod = __import__(modpath, fromlist=[attr])
        return getattr(mod, attr)
    except Exception:
        return fallback

# Agent (Fallback ohne Wirkung)
try:
    from modules import module_agent as agent
except Exception:
    class _AgentSvc:
        _started = False
        def start(self): self._started = True
        def stop(self):  self._started = False
    agent = type("agent", (), {"AGENT": _AgentSvc()})()  # type: ignore

def _fallback_msg(title: str, text: str) -> bool:
    try: messagebox.showinfo(title, text)
    except Exception: pass
    return False

open_agent_monitor = _safe_import(
    "modules.module_agent_ui", "open_agent_monitor",
    lambda app: _fallback_msg("ShrimpDev", "Agent Monitor nicht verfügbar.")
)

open_project_map = _safe_import(
    "modules.module_project_ui", "open_project_map",
    lambda app: _fallback_msg("ShrimpDev", "Project Map nicht verfügbar.") or True
)

open_intake = _safe_import(
    "modules.module_code_intake", "open_intake",
    lambda app: _fallback_msg("ShrimpDev", "Code Intake nicht verfügbar.")
)

open_runner_board = _safe_import(
    "modules.module_runner_board", "open_runner_board",
    lambda app: _fallback_msg("ShrimpDev", "Runner Board nicht verfügbar.")
)

open_settings = _safe_import(
    "modules.module_settings_ui", "open_settings",
    lambda app: _fallback_msg("ShrimpDev", "Settings nicht verfügbar.")
)

open_preflight = _safe_import(
    "modules.module_preflight", "open_preflight",
    lambda app: _fallback_msg("ShrimpDev", "Preflight nicht verfügbar.")
)

open_patch_release = _safe_import(
    "modules.module_patch_release", "open_patch_release",
    lambda app: _fallback_msg("ShrimpDev", "Patch/Release nicht verfügbar.")
)

# ---- Config / Logging ---------------------------------------------------------
ROOT = Path(r"D:\ShrimpDev")

def _load_quiet() -> bool:
    try:
        from modules.config_mgr import load_config
        return bool(load_config().get("quiet_mode", True))
    except Exception:
        return True

def log(msg: str) -> None:
    try:
        (ROOT / "debug_output.txt").open("a", encoding="utf-8", errors="ignore") \
            .write(f"[MAIN] {msg}\n")
    except Exception:
        pass

# ---- Haupt-GUI ----------------------------------------------------------------
class ShrimpDevApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("🦐 ShrimpDev")
        self.geometry("1100x720+80+60")

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True)

        self.status = tk.StringVar(value="Bereit.")
        ttk.Label(self, textvariable=self.status, anchor="w").pack(fill="x")

        self.quiet = _load_quiet()
        self._mk_menu()

        # Info-Tab
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="Info")
        ttk.Label(tab, text="ShrimpDev – Standalone Dev-Umgebung für ShrimpHub",
                  font=("Segoe UI", 12)).pack(pady=12)

        # Agent starten
        try:
            if not getattr(agent.AGENT, "_started", False):
                agent.AGENT.start()
                setattr(agent.AGENT, "_started", True)
        except Exception:
            pass

        log("GUI ready")

    # ---- Menü -----------------------------------------------------------------
    def _mk_menu(self):
        menubar = tk.Menu(self)
        self.config(menu=menubar)

        m_file  = tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="File",  menu=m_file)
        m_tools = tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="Tools", menu=m_tools)
        m_view  = tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="View",  menu=m_view)

        # File
        m_file.add_command(label="Exit", command=self._on_exit)

        # Tools
        m_tools.add_command(label="Code Intake (Ctrl+I)", command=lambda: open_intake(self))
        self.bind_all("<Control-i>", lambda e: open_intake(self))

        m_tools.add_separator()
        m_tools.add_command(label="Preflight Checks",     command=lambda: open_preflight(self))
        m_tools.add_command(label="Make Patch/Export",    command=lambda: open_patch_release(self))
        m_tools.add_separator()
        m_tools.add_command(label="Neues Modul…",         command=self._new_module_dialog)
        m_tools.add_command(label="Neuer Runner…",        command=self._new_runner_dialog)

        # View
        m_view.add_command(label="Agent Monitor (Ctrl+M)", command=lambda: open_agent_monitor(self))
        self.bind_all("<Control-m>", lambda e: open_agent_monitor(self))
        m_view.add_command(label="Runner Board",           command=lambda: open_runner_board(self))
        m_view.add_command(label="Project Map",            command=lambda: open_project_map(self))
        m_view.add_command(label="Settings…",              command=lambda: open_settings(self))

    def _on_exit(self):
        try: agent.AGENT.stop()
        except Exception: pass
        self.after(150, self.destroy)

    # ---- Helfer für „Neues Modul/Neuer Runner“ --------------------------------
    def _safe_module_filename(self, raw: str) -> str:
        import re
        name = re.sub(r"\W+", "_", (raw or "").strip().lower())
        if not name:
            raise ValueError("Leerer Name")
        if not name.startswith("module_"):
            name = "module_" + name
        if not name.endswith(".py"):
            name += ".py"
        return name

    def _write_if_absent(self, path: Path, content: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            path.write_text(content, encoding="utf-8")

    def _module_template(self, mod_name: str) -> str:
        return f"""# {mod_name}
# erstellt mit ShrimpDev
from __future__ import annotations

def main():
    print("Hello from {mod_name}")

if __name__ == "__main__":
    main()
"""

    def _runner_template(self, runner_name: str) -> str:
        return f"""# tools/{runner_name}
# erstellt mit ShrimpDev
from __future__ import annotations
import sys

def main() -> int:
    print("[{runner_name}] Hello")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
"""

    def _open_in_editor(self, p: Path) -> None:
        try:
            subprocess.Popen(["cmd", "/c", "start", "", str(p)], shell=False)
        except Exception:
            pass

    def _new_module_dialog(self):
        raw = simpledialog.askstring("Neues Modul", "Name (ohne 'module_' und .py):", parent=self)
        if not raw:
            return
        try:
            fname  = self._safe_module_filename(raw)
            target = Path(r"D:\ShrimpDev") / "modules" / fname
            self._write_if_absent(target, self._module_template(fname))
            try: messagebox.showinfo("ShrimpDev", f"Neues Modul erstellt:\n{target}")
            except Exception: pass
            self._open_in_editor(target)
        except Exception as ex:
            try: messagebox.showerror("ShrimpDev", f"Fehler beim Erstellen:\n{ex}")
            except Exception: pass

    def _new_runner_dialog(self):
        import re
        raw = simpledialog.askstring("Neuer Runner", "Name (ohne 'Runner_' und .py/.bat):", parent=self)
        if not raw:
            return
        base = re.sub(r"\W+", "_", raw.strip())
        if not base:
            try: messagebox.showerror("ShrimpDev", "Ungültiger Name.")
            except Exception: pass
            return
        base = f"Runner_{base}"
        py  = Path(r"D:\ShrimpDev") / "tools" / f"{base}.py"
        bat = Path(r"D:\ShrimpDev") / "tools" / f"{base}.bat"
        try:
            self._write_if_absent(py, self._runner_template(f"{base}.py"))
            bat.write_text(
                f"@echo off\r\ncd /d \"D:\\ShrimpDev\"\r\npy -3 -u tools\\{base}.py\r\n"
                "echo [END ] RC=%errorlevel%\r\npause\r\n",
                encoding="utf-8"
            )
            try: messagebox.showinfo("ShrimpDev", f"Neuer Runner erstellt:\n{py}\n{bat}")
            except Exception: pass
            self._open_in_editor(py)
        except Exception as ex:
            try: messagebox.showerror("ShrimpDev", f"Fehler beim Erstellen:\n{ex}")
            except Exception: pass

if __name__ == "__main__":
    import traceback
    try:
        log("[BOOT] launching")
        app = ShrimpDevApp()
        app.mainloop()
    except Exception as ex:
        tb = traceback.format_exc()
        try:
            log(f"[FATAL] {ex}\n{tb}")
        finally:
            try: messagebox.showerror("ShrimpDev", f"Fataler Fehler:\n{ex}\n\n{tb}")
            except Exception: pass
'''

def main() -> int:
    MAIN.parent.mkdir(parents=True, exist_ok=True)
    if MAIN.exists():
        bak = MAIN.with_suffix(".py." + time.strftime("%Y%m%d_%H%M%S") + ".bak")
        shutil.copy2(MAIN, bak)
        print(f"[R962] Backup: {bak.name}")
    MAIN.write_text(GOOD, encoding="utf-8")
    print("[R962] main_gui.py ersetzt (saubere, startfähige Version).")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
