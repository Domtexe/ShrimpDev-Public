"""
Runner_1034_IntakeDetect_SmartFix
- Ersetzt _detect() durch robuste Erkennung:
  1) Name -> Endung
  2) Falls keine Endung: Text-Heuristiken (bat/py/json/yml/ini/md)
- Manuelle Endung (var_ext_manual) wird respektiert
- LED grün/gelb + Ping-Status aktualisiert
- Version -> v9.9.24
"""
from __future__ import annotations
import os, re, json, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1034] {ts} {msg}\n")
    except Exception:
        pass
    print(msg, flush=True)

def backup_write(path: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

def patch() -> int:
    with open(MOD, "r", encoding="utf-8") as f:
        src = f.read()

    # Helper zum Raten der Endung aus Text
    if "def _guess_ext_from_text(" not in src:
        helper = r'''
    def _guess_ext_from_text(self, text: str) -> str:
        """
        Versucht, die passende Endung aus dem Text zu erraten.
        Liefert z.B. ".bat", ".py", ".json", ".yml", ".ini", ".md" – oder "".
        """
        t = (text or "").lstrip()
        head = t[:4000]  # genügt
        # BAT
        if re.search(r"(?im)^\s*@echo\s+off\b", head) or re.search(r"(?im)^\s*rem\s", head):
            return ".bat"
        # Shebang Python
        if re.search(r"(?im)^#!.*python", head):
            return ".py"
        # Python-Heuristik
        if re.search(r"(?m)^\s*(from\s+\w+\s+import|import\s+\w+|def\s+\w+\(|class\s+\w+\(|if\s+__name__\s*==\s*['\"]__main__['\"])"," "+head):
            return ".py"
        # JSON
        try:
            if head and head.strip()[0] in "{[":
                json.loads(head)
                return ".json"
        except Exception:
            pass
        # YAML
        if re.search(r"(?m)^\s*-\s+\w+", head) or re.search(r"(?m)^\s*\w+:\s+.+", head):
            return ".yml"
        # INI
        if re.search(r"(?m)^\s*\[[^\]]+\]\s*$", head) and re.search(r"(?m)^\s*\w+\s*=", head):
            return ".ini"
        # Markdown
        if re.search(r"(?m)^\s*#\s+\w+", head):
            return ".md"
        return ""
'''
        # Vor dem Actions-Block einfügen
        ins = src.find("\n    # ---------- actions ----------")
        src = src[:ins] + helper + src[ins:]

    # _detect ersetzen
    detect_impl = r'''
    def _detect(self):
        """
        Erkennung der Endung:
        1) Aus dem Namensfeld
        2) Falls leer: aus dem Editor-Text heuristisch
        Achtung: Manuelle Endung (var_ext_manual) wird NICHT überschrieben.
        """
        name = (self.var_name.get() or "").strip()
        nm, ext_from_name = os.path.splitext(name) if name else ("", "")
        ext_from_name = (ext_from_name or "").lower()

        ext = ext_from_name
        if not ext:
            # Heuristik aus Text
            try:
                content = self.txt.get("1.0","end-1c")
            except Exception:
                content = ""
            ext = self._guess_ext_from_text(content)

        # Manuelle Endung respektieren
        if not getattr(self, "var_ext_manual", False):
            self.var_ext.set(ext)
        else:
            # Nutzer hat überschrieben -> normalisieren und übernehmen
            self._normalize_ext()
            ext = (self.var_ext.get() or "").lower()

        # Gültigkeit
        allowed = {".py",".bat",".cmd",".json",".txt",".yml",".yaml",".ini",".md",".shcut"}
        ok = bool(ext) and (ext in allowed or (ext == "" and not self.var_ext_manual))

        # LED + Status
        self._update_led(self.led_detect, "green" if ok else "yellow")
        try:
            self._ping(f"Erkennung: {(ext or '(keine)')}")
        except Exception:
            pass
        return ok
'''
    # ersetze existierende _detect
    import re
    src2 = re.sub(
        r"def\s+_detect\([\s\S]+?^\s*return\s+ok\s*$",
        detect_impl.strip(),
        src,
        flags=re.MULTILINE
    )

    if src2 != src:
        backup_write(MOD, src2)
        log("_detect() durch Smart-Erkennung ersetzt; Helper hinzugefügt.")
    else:
        log("Keine Änderung nötig – _detect ist bereits auf Smart-Logik.")

    # Meta
    with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
        f.write("ShrimpDev v9.9.24\n")
    with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
        f.write("""
## v9.9.24 (2025-10-18)
- Intake: Erkennung repariert – Name->Endung + Text-Heuristiken (bat/py/json/yml/ini/md)
- LED/Status aktualisiert; manuelle Endung bleibt unberührt
""")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(patch())
    except Exception:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write("[R1034] FEHLER:\n" + traceback.format_exc() + "\n")
        print("FEHLER:\n" + traceback.format_exc())
        raise
