"""
Runner_1051_ExtDetectStrong_FixSub
Behebt den re.error "bad escape \s" aus Runner_1050, indem wir
- die Funktion _guess_ext_from_text per Slicing ersetzen (kein re-Replace im Replacement-String),
- die Nutzung in _detect() sicher auf unsere Funktion setzen.
Erweitert die Heuristik (Batch/Python/JSON/YAML/INI/MD + Runner-Fallback).
Version: v9.9.41
"""
from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

NEW_FUNC = r'''
    def _guess_ext_from_text(self, text):
        """
        Starke Heuristik für Dateiendungen.
        """
        import re, json as _json, time as _t  # lokale imports unkritisch
        t = (text or "")
        head = t.lstrip()[:8192]

        # ---- BATCH / CMD ----
        batch_markers = [
            r"(?im)^\s*@echo\s+off\b",
            r"(?im)^\s*setlocal\b",
            r"(?im)^\s*rem\b|^\s*::",
            r"(?im)^\s*:[A-Za-z0-9_]+",
            r"(?im)\bgoto\s+[A-Za-z0-9_]+",
            r"(?im)\bif\s+exist\b|\bif\s+not\s+exist\b",
            r"(?im)\bcall\b",
            r"%[A-Za-z0-9_]+%",
            r"![A-Za-z0-9_]+!",
        ]
        for rx in batch_markers:
            if re.search(rx, head):
                return ".bat"

        # ---- PYTHON ----
        if re.search(r"(?im)^#!.*python", head):
            return ".py"
        py_markers = [
            r"(?m)^\s*from\s+\w[\w\.]*\s+import\s+",
            r"(?m)^\s*import\s+\w",
            r"(?m)^\s*def\s+\w+\(",
            r"(?m)^\s*class\s+\w+\(",
            r"(?m)^\s*if\s+__name__\s*==\s*['\"]__main__['\"]\s*:",
            r"\bf?string\b|f\"|f\'",
            r"\bprint\s*\(",
        ]
        for rx in py_markers:
            if re.search(rx, head):
                return ".py"
        if re.search(r"(?i)\bpy(?:\s+-3)?\s+tools[\\/](Runner_[^ \r\n\t]+)\.py\b", t):
            return ".py"

        # ---- JSON / YAML / INI / MD ----
        try:
            if head and head.strip()[0] in "{[":
                _json.loads(head)
                return ".json"
        except Exception:
            pass
        if re.search(r"(?m)^\s*-\s+\w+", head) or re.search(r"(?m)^\s*\w+:\s+.+", head):
            return ".yml"
        if re.search(r"(?m)^\s*\[[^\]]+\]\s*$", head) and re.search(r"(?m)^\s*\w+\s*=", head):
            return ".ini"
        if re.search(r"(?m)^\s*#\s+\w+", head):
            return ".md"

        # Bare Runner ohne Endung -> .py als Standard
        if re.search(r"(?i)\bRunner_[0-9]{3,5}[_A-Za-z0-9\-]+\b", t):
            return ".py"

        return ""
'''

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1051] {ts} {msg}\n")
    except Exception:
        pass

def read_text(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def write_backup(p: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bck)
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {p} -> {bck}")

def replace_guess_func(src: str) -> str:
    # Finde Start/Ende der alten Funktion per Schlüsselwörtern
    m_start = re.search(r"\ndef\s+_guess_ext_from_text\([^\)]*\):", src)
    m_end   = re.search(r"\n\s*def\s+_apply_ext_to_name\(", src)
    if not (m_start and m_end and m_end.start() > m_start.start()):
        return src  # nichts zu ersetzen
    before = src[:m_start.start()]
    after  = src[m_end.start():]
    return before + NEW_FUNC + after

def force_use_in_detect(src: str) -> str:
    # Stelle sicher, dass in _detect() unser Pfad verwendet wird
    pat = re.compile(r"if\s+not\s+ext:\s*\n\s*ext\s*=\s*self\._guess_ext_from_text\(content\)\s*or\s*\"\"", re.MULTILINE)
    if pat.search(src):
        return src  # schon richtig
    # ersetze die erste Stelle "if not ext:"-Zweig auf unsere Variante
    src = re.sub(
        r"if\s+not\s+ext:\s*\n\s*ext\s*=\s*[^ \n\r]+",
        'if not ext:\n            ext = self._guess_ext_from_text(content)',
        src, count=1
    )
    return src

def patch() -> int:
    src = read_text(MOD)
    original = src

    src = replace_guess_func(src)
    src = force_use_in_detect(src)

    if src != original:
        write_backup(MOD, src)
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.41\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.41 (2025-10-18)
- Intake: robuste Ext-Erkennung integriert (ohne re.sub-Escape-Probleme).
- Batch/Python/JSON/YAML/INI/MD + Runner-Fallback.
""")
        log("Patch angewendet.")
        return 0
    else:
        log("Keine Änderungen nötig.")
        return 0

if __name__ == "__main__":
    raise SystemExit(patch())
