# -*- coding: ascii -*-
from __future__ import annotations
"""
R1182a - Write clean Dev-Intake Pro module (ASCII only), backup old file,
syntax-check, log, launch via .bat.
"""
import time, sys, os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCH = ROOT / "_Archiv"
LOG  = ROOT / "debug_output.txt"
OUT  = ROOT / "modules" / "module_code_intake.py"

DEV_INTAKE_CODE = r'''# -*- coding: utf-8 -*-
from __future__ import annotations
"""
ShrimpDev - Dev-Intake Pro (pure ShrimpDev, no Hub mix)
- Editor (left), file list (right) with columns: name, ext, subfolder, date, time
- Workspace, Name, Extension (.py/.bat/.txt), Target folder
- Buttons: Clear Editor, Detect (Ctrl-I), Save (Ctrl-S), Insert,
          Refresh, Guard, Repair, Run (F5), Save Pack, Delete file
- Logging to debug_output.txt
"""
import os, sys, time, shutil, zipfile, traceback
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

def _log(pfx: str, msg: str) -> None:
    """Append message to debug_output.txt"""
    try:
        root = Path(__file__).resolve().parents[1]
        with open(root / "debug_output.txt", "a", encoding="utf-8", newline="\n") as f:
            f.write(f"[DevIntake] {time.strftime('%Y-%m-%d %H:%M:%S')} [{pfx}] {msg}\n")
    except Exception:
        pass

def _fmt_time(ts: float):
    lt = time.localtime(ts)
    return time.strftime("%Y-%m-%d", lt), time.strftime("%H:%M:%S", lt)

def _detect_ext_from_text(text: str) -> str:
    t = text.lstrip()
    if t.startswith("#!") or "import " in t or "def " in t or "print(" in t:
        return ".py"
    return ".txt"

def _safe_run(cmd: list[str]) -> None:
    try:
        import subprocess
        subprocess.Popen(cmd, cwd=os.getcwd(), creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
    except Exception as e:
        messagebox.showerror("Run", f"Start failed:\n{e}")
        _log("RUN_FAIL", str(e))

class DevIntakePro(ttk.Frame):
    """ShrimpDev development intake user interface."""
    def __init__(self, nb: ttk.Notebook) -> None:
        super().__init__(nb)
        self.workspace = tk.StringVar(value=os.getcwd())
        self.target_dir = tk.StringVar(value=str(Path(os.getcwd()) / "tools"))
        self.name_var = tk.StringVar(value=f"snippet_{time.strftime('%Y%m%d_%H%M%S')}")
        self.ext_var = tk.StringVar(value=".py")
        self.status = tk.StringVar(value="Ready.")
        self.current_path: Path | None = None
        self._build_ui()
        self._refresh_list()

    def _build_ui(self) -> None:
        top = ttk.Frame(self)
        top.pack(fill="x", padx=8, pady=6)

        ttk.Label(top, text="Workspace:").grid(row=0, column=0, sticky="w")
        ws = ttk.Entry(top, textvariable=self.workspace, width=48)
        ws.grid(row=0, column=1, sticky="we", padx=(4,4))
        ttk.Button(top, text="...", width=3, command=self._pick_workspace).grid(row=0, column=2, padx=(2,10))

        ttk.Label(top, text="Name:").grid(row=0, column=3, sticky="w")
        ttk.Entry(top, textvariable=self.name_var, width=28).grid(row=0, column=4, sticky="we", padx=(4,10))

        ttk.Label(top, text="Ext:").grid(row=0, column=5, sticky="w")
        cb = ttk.Combobox(top, textvariable=self.ext_var, values=[".py",".bat",".txt"], width=6, state="readonly")
        cb.grid(row=0, column=6, sticky="w", padx=(4,10))

        ttk.Label(top, text="Target:").grid(row=0, column=7, sticky="e")
        ttk.Entry(top, textvariable=self.target_dir, width=40).grid(row=0, column=8, sticky="we", padx=(4,4))
        ttk.Button(top, text="...", width=3, command=self._pick_target).grid(row=0, column=9, padx=(2,0))

        top.columnconfigure(1, weight=2)
        top.columnconfigure(4, weight=1)
        top.columnconfigure(8, weight=2)

        row1 = ttk.Frame(self); row1.pack(fill="x", padx=8, pady=(0,6))
        ttk.Button(row1, text="Clear Editor", command=self._editor_clear).pack(side="left")
        ttk.Button(row1, text="Detect (Ctrl-I)", command=self._detect_name_ext).pack(side="left", padx=(6,0))
        ttk.Button(row1, text="Save (Ctrl-S)", command=self._save_current).pack(side="left", padx=(6,0))
        ttk.Button(row1, text="Insert", command=self._insert_as_new).pack(side="left", padx=(12,0))

        row2 = ttk.Frame(self); row2.pack(fill="x", padx=8, pady=(0,6))
        ttk.Button(row2, text="Refresh", command=self._refresh_list).pack(side="left")
        ttk.Button(row2, text="Guard", command=self._guard_check).pack(side="left", padx=(6,0))
        ttk.Button(row2, text="Repair", command=self._repair).pack(side="left", padx=(6,0))
        ttk.Button(row2, text="Run (F5)", command=self._run_current).pack(side="left", padx=(12,0))
        ttk.Button(row2, text="Save Pack", command=self._save_pack).pack(side="left", padx=(12,0))
        ttk.Button(row2, text="Delete", command=self._delete_current).pack(side="left", padx=(6,0))

        split = ttk.Panedwindow(self, orient="horizontal")
        split.pack(fill="both", expand=True, padx=8, pady=(0,8))

        left = ttk.Frame(split); split.add(left, weight=3)
        self.editor = tk.Text(left, wrap="none", undo=True)
        self.editor.pack(fill="both", expand=True)
        vsb = ttk.Scrollbar(left, orient="vertical", command=self.editor.yview)
        hsb = ttk.Scrollbar(left, orient="horizontal", command=self.editor.xview)
        self.editor.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        vsb.pack(side="right", fill="y"); hsb.pack(side="bottom", fill="x")

        right = ttk.Frame(split); split.add(right, weight=2)
        cols = ("name","ext","subfolder","date","time")
        self.tree = ttk.Treeview(right, columns=cols, show="headings", selectmode="browse")
        for c,w in zip(cols,(260,60,140,100,80)):
            self.tree.heading(c, text=c)
            self.tree.column(c, width=w, anchor="w")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        ttk.Label(self, textvariable=self.status, anchor="w").pack(side="bottom", fill="x")

        self.bind_all("<Control-s>", lambda e: self._save_current())
        self.bind_all("<Control-S>", lambda e: self._save_current())
        self.bind_all("<Control-i>", lambda e: self._detect_name_ext())
        self.bind_all("<F5>", lambda e: self._run_current())

    # actions
    def _pick_workspace(self):
        d = filedialog.askdirectory(title="Select workspace", initialdir=self.workspace.get())
        if d: self.workspace.set(d)

    def _pick_target(self):
        d = filedialog.askdirectory(title="Select target", initialdir=self.target_dir.get())
        if d: self.target_dir.set(d)

    def _editor_clear(self):
        self.editor.delete("1.0","end")
        self.status.set("Editor cleared.")

    def _detect_name_ext(self):
        txt = self.editor.get("1.0","end-1c")
        if not txt.strip():
            self.status.set("Nothing to detect (editor empty)."); return
        ext = _detect_ext_from_text(txt)
        base = f"snippet_{time.strftime('%Y%m%d_%H%M%S')}"
        self.name_var.set(base); self.ext_var.set(ext)
        self.status.set(f"Detected: {base}{ext}")

    def _path_from_ui(self) -> Path:
        base = self.name_var.get().strip() or f"snippet_{time.strftime('%Y%m%d_%H%M%S')}"
        ext  = self.ext_var.get().strip() or ".py"
        d    = Path(self.target_dir.get().strip() or (Path(os.getcwd()) / "tools"))
        d.mkdir(parents=True, exist_ok=True)
        return d / f"{base}{ext}"

    def _insert_as_new(self):
        p = self._path_from_ui()
        if p.exists():
            if not messagebox.askyesno("Overwrite?", f"{p.name} exists. Overwrite?"):
                return
        txt = self.editor.get("1.0","end-1c")
        p.write_text(txt, encoding="utf-8")
        self.current_path = p
        self._refresh_list(select=p)
        self.status.set(f"Inserted: {p}")

    def _save_current(self):
        if self.current_path is None:
            self._insert_as_new(); return
        txt = self.editor.get("1.0","end-1c")
        self.current_path.write_text(txt, encoding="utf-8")
        self._refresh_list(select=self.current_path)
        self.status.set(f"Saved: {self.current_path.name}")

    def _refresh_list(self, select: Path | None=None):
        self.tree.delete(*self.tree.get_children())
        root = Path(self.target_dir.get() or (Path(os.getcwd()) / "tools"))
        if not root.exists():
            root.mkdir(parents=True, exist_ok=True)
        for p in sorted(root.rglob("*")):
            if p.is_file():
                sub = str(p.parent.relative_to(root)) if p.parent != root else ""
                date, tm = _fmt_time(p.stat().st_mtime)
                self.tree.insert("", "end", iid=str(p), values=(p.stem, p.suffix, sub, date, tm))
        if select and str(select) in self.tree.get_children(""):
            self.tree.selection_set(str(select))
        self.status.set(f"{root} refreshed.")

    def _on_select(self, _evt=None):
        sel = self.tree.selection()
        if not sel: return
        p = Path(sel[0])
        try:
            txt = p.read_text(encoding="utf-8", errors="replace")
            self.editor.delete("1.0","end"); self.editor.insert("1.0", txt)
            self.current_path = p
            self.name_var.set(p.stem); self.ext_var.set(p.suffix or ".txt")
            self.target_dir.set(str(p.parent))
            self.status.set(f"Loaded: {p}")
        except Exception as e:
            messagebox.showerror("Load", f"{e}")
            _log("LOAD_FAIL", str(e))

    def _run_current(self):
        p = self.current_path
        if not p or not p.exists():
            messagebox.showinfo("Run", "No file selected."); return
        if p.suffix == ".py":
            _safe_run(["py","-3","-u",str(p)])
        elif p.suffix == ".bat":
            _safe_run([str(p)])
        else:
            messagebox.showinfo("Run", "Only .py or .bat are executed.")

    def _guard_check(self):
        p = self.current_path
        if not p or not p.exists():
            messagebox.showinfo("Guard", "No file selected."); return
        if p.suffix == ".py":
            try:
                src = p.read_text(encoding="utf-8")
                compile(src, p.name, "exec")
                messagebox.showinfo("Guard", "Syntax OK.")
            except Exception as e:
                messagebox.showerror("Guard", f"Syntax error:\n{e}")
        else:
            messagebox.showinfo("Guard", "Guard checks only .py files.")

    def _repair(self):
        p = self.current_path
        if not p or not p.exists(): return
        try:
            txt = p.read_text(encoding="utf-8", errors="replace")
            p.write_text(txt.replace("\r\r\n","\r\n"), encoding="utf-8", newline="\r\n")
            messagebox.showinfo("Repair", "Small normalizer applied.")
        except Exception as e:
            messagebox.showerror("Repair", f"{e}")

    def _save_pack(self):
        root = Path(self.target_dir.get())
        if not root.exists(): return
        ts = time.strftime("%Y%m%d_%H%M%S")
        zf = Path(os.getcwd())/f"DevIntake_Pack_{ts}.zip"
        with zipfile.ZipFile(zf, "w", zipfile.ZIP_DEFLATED) as z:
            for p in root.rglob("*"):
                if p.is_file():
                    z.write(p, p.relative_to(root))
        messagebox.showinfo("Pack", f"Saved:\n{zf}")
        self.status.set(f"Pack saved: {zf.name}")

    def _delete_current(self):
        p = self.current_path
        if not p or not p.exists():
            return
        if not messagebox.askyesno("Delete", f"Delete {p.name}?"):
            return
        try:
            p.unlink()
            self.current_path = None
            self.editor.delete("1.0","end")
            self._refresh_list()
            self.status.set("File deleted.")
        except Exception as e:
            messagebox.showerror("Delete", f"{e}")

def create_intake_tab(nb: ttk.Notebook) -> None:
    try:
        frame = DevIntakePro(nb)
        nb.add(frame, text="Intake")
    except Exception:
        import traceback
        f = ttk.Frame(nb)
        ttk.Label(f, text="Intake - error while loading. See log.", foreground="red").pack(padx=12, pady=12, anchor="w")
        nb.add(f, text="Intake")
        traceback.print_exc()
'''

def _log(msg: str) -> None:
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG, "a", encoding="utf-8", newline="\n") as f:
        f.write(f"[R1182a] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")

def main() -> int:
    try:
        ARCH.mkdir(exist_ok=True)
        OUT.parent.mkdir(parents=True, exist_ok=True)
        if OUT.exists():
            bak = ARCH / f"module_code_intake.py.{time.strftime('%Y%m%d_%H%M%S')}.bak"
            bak.write_text(OUT.read_text(encoding="utf-8"), encoding="utf-8")
            _log(f"Backup: {bak}")
        OUT.write_text(DEV_INTAKE_CODE, encoding="utf-8", newline="\n")
        compile(DEV_INTAKE_CODE, "module_code_intake.py", "exec")
        _log("Dev-Intake Pro installed.")
        return 0
    except Exception as e:
        _log(f"FAIL: {e}")
        return 2

if __name__ == "__main__":
    sys.exit(main())
