# -*- coding: utf-8 -*-
"""
Runner_1167b_GUIIntakePresenceCheck
Simuliert den Start von main_gui.py headless und prüft,
ob IntakeFrame korrekt montiert wurde oder der Fallback aktiv ist.
Ergebnis -> debug_output.txt
Exitcode:
  0 = OK (echter IntakeFrame)
  1 = Fallback aktiv
  2 = Fehler beim Import/Start
"""
from __future__ import annotations
import os, sys, time, traceback, importlib

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
LOGFILE = os.path.join(ROOT, "debug_output.txt")

def _log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1167b {ts}] {msg}\n"
    with open(LOGFILE, "a", encoding="utf-8", newline="") as f:
        f.write(line)
    print(line, end="")

def main() -> int:
    os.chdir(ROOT)
    _log("=== GUI Intake Presence Check START ===")
    _log(f"Root: {ROOT}")
    sys.path.insert(0, ROOT)

    try:
        # Dynamischer Import des main_gui
        mg = importlib.import_module("main_gui")
        _log("main_gui importiert.")

        # Prüfen, ob echter IntakeFrame verfügbar ist
        try:
            from modules.module_code_intake import IntakeFrame as RealFrame
            real_cls = RealFrame
        except Exception as e:
            _log(f"Import von IntakeFrame fehlgeschlagen: {e}")
            return 2

        # Der in main_gui sichtbare IntakeFrame
        frame_in_gui = getattr(mg, "IntakeFrame", None)

        if frame_in_gui is None:
            _log("IntakeFrame in main_gui fehlt komplett.")
            return 1

        # Vergleich, ob GUI-Frame dieselbe Klasse ist
        if frame_in_gui is real_cls:
            _log("GUI-Mount IntakeFrame: OK (echte Klasse).")
            _log("=== GUI Intake Presence Check ENDE ===")
            return 0
        else:
            _log(f"GUI-Mount IntakeFrame: FALLBACK ({frame_in_gui})")
            _log("=== GUI Intake Presence Check ENDE ===")
            return 1

    except Exception as e:
        _log(f"UNERWARTETER FEHLER: {e}")
        _log(traceback.format_exc())
        _log("=== GUI Intake Presence Check ENDE (FEHLER) ===")
        return 2

if __name__ == "__main__":
    rc = main()
    sys.exit(rc)
