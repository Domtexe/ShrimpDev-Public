# Runner_1174c_MainGuiIntakeHelpersFix.py
import io, os, re, sys, time, shutil, py_compile

ROOT = r"D:\ShrimpDev"
TARGET = os.path.join(ROOT, "main_gui.py")
ARCHIV = os.path.join(ROOT, "_Archiv")
os.makedirs(ARCHIV, exist_ok=True)

def log(msg):
    ts = time.strftime("[%Y-%m-%d %H:%M:%S]")
    print(f"[1174c] {ts} {msg}")

def read(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def write(path, data):
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(data)

def syntax_ok(tmp):
    try:
        py_compile.compile(tmp, doraise=True)
        return True, None
    except Exception as e:
        return False, e

def strip_bad_top_indented_doc(src):
    # Entfernt EINEN indenten Triple-Quote-Block ganz am Anfang (Fehlerquelle)
    head_limit = min(2000, len(src))
    head = src[:head_limit]
    m_future = re.search(r'^(?:\ufeff)?(?:\s*from\s+__future__\s+import[^\n]*\n)?', head)
    pos = m_future.end() if m_future else 0
    m_doc = re.match(r'(?s)([ \t]+)("""[\s\S]*?""")', src[pos:])
    if m_doc:
        span_start = pos + m_doc.start(1)
        span_end = pos + m_doc.end(2)
        pre = src[:span_start]
        if not re.search(r'^\s*(def|class)\s', pre, flags=re.M):
            return src[:span_start] + src[span_end:]
    return src

HELPERS_BLOCK = r"""
# === Intake GUI helper block (idempotent) ===
def _mount_intake_tab_safe(container):
    \"\"\"Mountet den IntakeFrame sauber in den gegebenen Container und
    kapselt Import-/Runtimefehler. Keine Seiteneffekte.\"\"\""
    try:
        from modules.module_code_intake import IntakeFrame
    except Exception as exc:
        import traceback, sys
        print("[Intake] Importfehler – IntakeFrame nicht verfügbar:", exc, file=sys.stderr)
        traceback.print_exc()
        return
    try:
        frm = IntakeFrame(container)
        try:
            frm.pack(fill="both", expand=True)
        except Exception:
            try:
                frm.grid(sticky="nsew")
                container.rowconfigure(0, weight=1)
                container.columnconfigure(0, weight=1)
            except Exception:
                pass
    except Exception as exc:
        import traceback, sys
        print("[Intake] Fehler beim Mounten:", exc, file=sys.stderr)
        traceback.print_exc()

def _safe_add_intake_tab(nb):
    \"\"\"Hängt den Intake-Tab korrekt ans Notebook und mountet den Inhalt verzögert.
    Idempotent: legt genau EINEN Tab mit Titel 'Code Intake' an, falls fehlend.\"\"\""
    from tkinter import ttk
    try:
        for i in range(len(nb.tabs())):
            try:
                if nb.tab(i, "text") == "Code Intake":
                    return
            except Exception:
                pass
    except Exception:
        pass
    tab = ttk.Frame(nb)
    nb.add(tab, text="Code Intake")
    body = ttk.Frame(tab); body.pack(fill="both", expand=True)
    try:
        tab.after(50, lambda: _mount_intake_tab_safe(body))
    except Exception:
        _mount_intake_tab_safe(body)
"""

def ensure_helpers(src):
    need_insert = ("def _mount_intake_tab_safe(" not in src or
                   "def _safe_add_intake_tab(" not in src)
    if not need_insert:
        return src
    m = re.search(r'(?m)^\s*if\s+__name__\s*==\s*[\'"]__main__[\'"]\s*:', src)
    insert_at = m.start() if m else 0
    if insert_at == 0:
        m2 = re.search(r'(?m)^\s*def\s+_safe_main\s*\(', src)
        insert_at = m2.start() if m2 else 0
    if insert_at == 0:
        insert_at = len(src)
    return src[:insert_at] + "\n" + HELPERS_BLOCK + "\n" + src[insert_at:]

def ensure_call_in_safe_main(src):
    m = re.search(r'(?s)(def\s+_safe_main\s*\([^)]*\)\s*:\s*)([\s\S]*?)(?:\n\s*def\s|\Z)', src)
    if not m:
        return src
    block = m.group(2)
    if "_safe_add_intake_tab(" in block:
        return src
    nb_name = "nb"
    m_nb = re.search(r'(\w+)\s*=\s*ttk\.Notebook\(', block)
    if m_nb:
        nb_name = m_nb.group(1)
    injection = f"\n    try:\n        _safe_add_intake_tab({nb_name})\n    except Exception:\n        pass\n"
    new_block = block + injection
    return src[:m.start(2)] + new_block + src[m.end(2):]

def main():
    print("[1174c] MainGuiIntakeHelpersFix: starte Patch...")
    if not os.path.exists(TARGET):
        print("[1174c] FEHLER: main_gui.py nicht gefunden:", TARGET)
        sys.exit(2)

    original = read(TARGET)
    patched = original

    patched = strip_bad_top_indented_doc(patched)
    patched = ensure_helpers(patched)
    patched = ensure_call_in_safe_main(patched)

    if patched == original:
        print("[1174c] Keine Änderung notwendig.")
        return

    ts = str(int(time.time()))
    bak = os.path.join(ARCHIV, f"main_gui.py.{ts}.bak")
    shutil.copy2(TARGET, bak)
    print("[1174c] Backup erstellt:", bak)

    tmp = TARGET + ".1174c.tmp"
    write(tmp, patched)

    ok, err = syntax_ok(tmp)
    if not ok:
        print("[1174c] Syntax-Check FEHLER -> Rollback.")
        print(err)
        os.remove(tmp)
        print("[1174c] Ende (Rollback).")
        sys.exit(1)

    os.replace(tmp, TARGET)
    print("[1174c] Patch übernommen, Syntax OK.")
    print("[1174c] Ende.")

if __name__ == "__main__":
    main()
