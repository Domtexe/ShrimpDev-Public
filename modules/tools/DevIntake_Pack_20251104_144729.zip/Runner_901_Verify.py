# Runner_901_Verify.py — prüft UDP- und Inbox-Weg zum Agent
from __future__ import annotations
import json, os, socket, time
from pathlib import Path

ROOT   = Path(r"D:\ShrimpDev")
EVENTS = ROOT / "_Reports" / "Agent" / "events.jsonl"
INBOX  = ROOT / "_Reports" / "Agent" / "inbox"
ADDR   = ("127.0.0.1", int(os.environ.get("SHRIMPDEV_PORT", "9477")))

def count_events(tag: str) -> int:
    if not EVENTS.exists(): return 0
    return sum(1 for ln in EVENTS.read_text(encoding="utf-8", errors="ignore").splitlines()
               if tag in ln)

def send_udp(msg: str):
    ev = {"runner": "Runner_901_Verify", "level": "INFO", "msg": msg, "via": "UDP"}
    data = json.dumps(ev, ensure_ascii=False).encode("utf-8")
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.sendto(data, ADDR)
    finally:
        s.close()

def send_inbox(msg: str):
    ev = {"runner": "Runner_901_Verify", "level": "OK", "msg": msg, "via": "INBOX"}
    INBOX.mkdir(parents=True, exist_ok=True)
    (INBOX / f"{int(time.time())}_{os.getpid()}.jsonl").write_text(
        json.dumps(ev, ensure_ascii=False) + "\n", encoding="utf-8"
    )

def main():
    tag_udp   = '"via": "UDP"'
    tag_inbox = '"via": "INBOX"'
    before_u, before_i = count_events(tag_udp), count_events(tag_inbox)
    print(f"[R901] Vorher: UDP={before_u}, INBOX={before_i}")

    send_udp("UDP-Ping")
    send_inbox("Inbox-Ping")

    # kurze Wartezeit, damit der Agent einsammelt
    time.sleep(1.5)

    after_u, after_i = count_events(tag_udp), count_events(tag_inbox)
    print(f"[R901]  Nachher: UDP={after_u}, INBOX={after_i}")

    if after_u == before_u:
        print("[R901][WARN] UDP nicht angekommen. Gründe: Agent-UDP nicht gebunden (Firewall/Port), "
              "falscher Port. INBOX funktioniert.")
        print("[R901][HINT] Teste mit anderem Port, z.B.: set SHRIMPDEV_PORT=9488")
    else:
        print("[R901] UDP OK.")

    print("[END ] RC=0")

if __name__ == "__main__":
    main()
