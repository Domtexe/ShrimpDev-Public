# -*- coding: utf-8 -*-
"""
Runner_1177b_IntakeRestore
- legt/aktualisiert Intake-Module (GUI/Worker/Snippets)
- aktualisiert module_shim_intake.py -> echter IntakeFrame statt Dummy
- Logging nach debug_output.txt
"""
from __future__ import annotations
import os, sys, datetime

ROOT = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
MOD  = os.path.join(ROOT, "modules")
SNIP = os.path.join(MOD, "snippets")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def ts(): return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def stamp(): return datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
def log(msg):
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[{ts()}] [R1177b] {msg}\n")
    except Exception:
        pass
def ensure_dir(p): os.makedirs(p, exist_ok=True)
def write(path, content):
    ensure_dir(os.path.dirname(path))
    if os.path.exists(path):
        ensure_dir(ARCH)
        bak = os.path.join(ARCH, f"{os.path.basename(path)}.{stamp()}.bak")
        with open(path, "rb") as s, open(bak, "wb") as d: d.write(s.read())
        log(f"Backup: {bak}")
    with open(path, "w", encoding="utf-8") as f: f.write(content)
    log(f"Wrote: {path}")

# --------- payloads ---------
MODULE_SHIM = r'''# -*- coding: utf-8 -*-
"""
module_shim_intake – R1177b
Stellt den Intake-Tab bereit (Back-Compat + echter Frame).
"""
from __future__ import annotations
import traceback

try:
    import tkinter as tk
    from tkinter import ttk
except Exception:
    tk = None; ttk = None

__all__ = ["IntakeShimAdapter","mount_intake_tab","_mount_intake_tab_shim","_remount_intake_tab_shim"]

def _log(msg: str):
    try:
        import os, datetime
        root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        logfile = os.path.join(root, "debug_output.txt")
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(logfile, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] [IntakeShim] {msg}\n")
    except Exception:
        pass

class IntakeShimAdapter:
    TAB_TEXT = "Intake"
    def __init__(self): self._nb = None
    def _ensure(self):
        if ttk is None: raise RuntimeError("tk/ttk not available")

    def _find_tab(self, nb):
        try:
            for i, tid in enumerate(nb.tabs()):
                if str(nb.tab(tid, "text")).strip().lower() == self.TAB_TEXT.lower():
                    return i, tid
        except Exception: traceback.print_exc()
        return None, None

    def _frame(self, nb):
        try:
            from modules.module_code_intake import IntakeFrame
            frm = IntakeFrame(nb)
        except Exception as e:
            _log(f"Fallback IntakeFrame due to error: {e}")
            frm = ttk.Frame(nb); ttk.Label(frm, text="Intake – bereit", padding=8).pack(expand=True)
        return frm

    def mount_intake_tab(self, nb):
        try:
            self._ensure()
            idx, tid = self._find_tab(nb)
            if tid is None:
                frm = self._frame(nb)
                nb.add(frm, text=self.TAB_TEXT)
                nb.select(frm)
                _log("Tab mounted.")
            else:
                nb.select(tid); _log("Tab already present – selected.")
            self._nb = nb
            return True
        except Exception as e:
            _log(f"ERROR mount: {e}"); traceback.print_exc(); return False

    def _remount_intake_tab_shim(self, nb): return self.mount_intake_tab(nb)

_ADAPTER = IntakeShimAdapter()
def mount_intake_tab(nb): return _ADAPTER.mount_intake_tab(nb)
def _mount_intake_tab_shim(nb): return _ADAPTER.mount_intake_tab(nb)
def _remount_intake_tab_shim(nb): return _ADAPTER._remount_intake_tab_shim(nb)
'''

MODULE_CODE = r'''# -*- coding: utf-8 -*-
"""
module_code_intake – R1177b
Intake-Tab mit:
- Ordnerscan (rekursiv, lazy Eintrag)
- Vorschau (Bild via Pillow, sonst Info)
- Drag&Drop (tkinterdnd2 optional, sauberer Fallback)
- Auto-Kategorie (Endungs-Mapping)
- Sicheres Move (Copy→Verify→Delete) + Undo via Journal
- Doppelklick: os.startfile
- Nicht-blockierende Worker
"""
from __future__ import annotations
import os, threading, queue, hashlib, mimetypes, traceback
import time
from typing import Optional, List, Dict, Tuple

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

try:
    from PIL import Image, ImageTk   # optional
    _HAS_PIL = True
except Exception:
    _HAS_PIL = False

try:
    # optional Drag&Drop
    from tkinterdnd2 import DND_FILES, TkinterDnD
    _HAS_DND = True
except Exception:
    _HAS_DND = False

from modules.snippets.snippet_file_ops import safe_move_with_verify, ensure_dir, Journal
from modules.snippets.snippet_auto_category import guess_category

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
LOG  = os.path.join(ROOT, "debug_output.txt")

def _log(msg: str):
    try:
        import datetime
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] [Intake] {msg}\n")
    except Exception:
        pass

class IntakeFrame(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.pack(fill="both", expand=True)
        self._build_ui()
        self._bind_events()
        self._journal = Journal(os.path.join(ROOT, "debug", "intake_moves.journal.json"))
        self._scan_dir = os.getcwd()
        self._worker_q: "queue.Queue[Tuple[str, dict]]" = queue.Queue()
        self._worker = threading.Thread(target=self._worker_loop, daemon=True)
        self._worker.start()
        self._load_initial()

    # ---------- UI ----------
    def _build_ui(self):
        # Toolbar
        tb = ttk.Frame(self); tb.pack(fill="x")
        self.btn_scan = ttk.Button(tb, text="Scan", command=self._cmd_scan)
        self.btn_import = ttk.Button(tb, text="Import…", command=self._cmd_import)
        self.btn_autocat = ttk.Button(tb, text="Auto-Kategorie", command=self._cmd_autocat)
        self.btn_move = ttk.Button(tb, text="Move Auswahl →", command=self._cmd_move)
        self.btn_undo = ttk.Button(tb, text="Undo", command=self._cmd_undo)
        for w in (self.btn_scan, self.btn_import, self.btn_autocat, self.btn_move, self.btn_undo):
            w.pack(side="left", padx=4, pady=4)

        # Main Split
        self.pw = ttk.PanedWindow(self, orient="horizontal"); self.pw.pack(fill="both", expand=True)
        left = ttk.Frame(self.pw); right = ttk.Frame(self.pw)
        self.pw.add(left, weight=3); self.pw.add(right, weight=2)

        # Tree
        cols = ("name","size","type","category","path")
        self.tree = ttk.Treeview(left, columns=cols, show="headings", selectmode="extended")
        for c, w in zip(cols, (220, 90, 90, 120, 400)):
            self.tree.heading(c, text=c.title()); self.tree.column(c, width=w, anchor="w")
        ys = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscroll=ys.set)
        self.tree.pack(side="left", fill="both", expand=True); ys.pack(side="right", fill="y")

        # Preview
        self.prev_title = ttk.Label(right, text="Vorschau", anchor="w"); self.prev_title.pack(fill="x")
        self.prev_canvas = tk.Canvas(right, bg="#f2f2f2", height=280); self.prev_canvas.pack(fill="both", expand=True)
        self.prev_text = ttk.Label(right, text="Dateiinfo…", anchor="w", padding=6, justify="left")
        self.prev_text.pack(fill="x")

        # Statusbar
        self.status = ttk.Label(self, text="Bereit.", anchor="w"); self.status.pack(fill="x")

        if _HAS_DND:
            try:
                self.drop_target_register(DND_FILES)
                self.dnd_bind('<<Drop>>', self._on_drop)
                self.status.config(text="Drag&Drop aktiv. Ziehe Dateien in die Liste.")
            except Exception:
                _log("DND bind failed.")
        else:
            self.status.config(text="Bereit. (Drag&Drop optional – tkinterdnd2 nicht gefunden)")

    def _bind_events(self):
        self.tree.bind("<Double-1>", self._on_open)
        self.tree.bind("<<TreeviewSelect>>", lambda e: self._refresh_preview())

    # ---------- Worker ----------
    def _worker_loop(self):
        while True:
            try:
                cmd, payload = self._worker_q.get()
                if cmd == "scan":
                    path = payload["path"]; self._scan_impl(path)
                elif cmd == "move":
                    rows = payload["rows"]; target = payload["target"]; self._move_impl(rows, target)
                self._worker_q.task_done()
            except Exception as e:
                _log(f"Worker error: {e}"); traceback.print_exc()

    # ---------- Commands ----------
    def _cmd_scan(self):
        sel = filedialog.askdirectory(initialdir=self._scan_dir or os.getcwd())
        if not sel: return
        self._scan_dir = sel
        self.status.config(text=f"Scanne: {sel}")
        self._worker_q.put(("scan", {"path": sel}))

    def _cmd_import(self):
        files = filedialog.askopenfilenames(initialdir=self._scan_dir or os.getcwd())
        if not files: return
        self._add_files(list(files))
        self.status.config(text=f"{len(files)} Datei(en) importiert.")

    def _cmd_autocat(self):
        for iid in self.tree.get_children(""):
            vals = list(self.tree.item(iid, "values"))
            vals[3] = guess_category(vals[0], vals[4])
            self.tree.item(iid, values=vals)
        self.status.config(text="Auto-Kategorie angewendet.")

    def _cmd_move(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Move", "Bitte Dateien auswählen."); return
        target = filedialog.askdirectory(title="Zielordner wählen", initialdir=self._scan_dir or os.getcwd())
        if not target: return
        rows = [self.tree.item(i, "values") for i in sel]
        self.status.config(text=f"Verschiebe {len(rows)} Datei(en) → {target}")
        self._worker_q.put(("move", {"rows": rows, "target": target}))

    def _cmd_undo(self):
        try:
            entry = self._journal.pop_last()
            if not entry:
                messagebox.showinfo("Undo", "Kein Move im Journal."); return
            # Rückwärts verschieben
            safe_move_with_verify(entry["dst"], entry["src"], journal=self._journal, record=False)
            self.status.config(text="Undo ausgeführt.")
            self._rescan_if_inside(entry["src"], entry["dst"])
        except Exception as e:
            _log(f"Undo error: {e}")
            messagebox.showerror("Undo", f"Fehler: {e}")

    # ---------- Impl ----------
    def _scan_impl(self, path: str):
        try:
            files: List[str] = []
            for root, _, fns in os.walk(path):
                for fn in fns:
                    p = os.path.join(root, fn)
                    files.append(p)
            self._add_files(files, replace=True)
            self.status.config(text=f"Scan abgeschlossen: {len(files)} Dateien.")
            _log(f"Scan done: {path} -> {len(files)}")
        except Exception as e:
            _log(f"Scan error: {e}")

    def _move_impl(self, rows, target):
        ok = 0; fail = 0
        ensure_dir(target)
        for vals in rows:
            name, size, typ, cat, src = vals
            dst_dir = os.path.join(target, cat or "")
            ensure_dir(dst_dir)
            dst = os.path.join(dst_dir, name)
            try:
                safe_move_with_verify(src, dst, journal=self._journal, record=True)
                ok += 1
            except Exception as e:
                fail += 1; _log(f"Move fail {src} -> {dst}: {e}")
        self.status.config(text=f"Move fertig: {ok} ok, {fail} Fehler.")
        self._rescan_if_inside(target, rows[0][4] if rows else "")

    # ---------- Helpers ----------
    def _load_initial(self):
        # initialer Scan des aktuellen Arbeitsverzeichnisses
        self._worker_q.put(("scan", {"path": self._scan_dir or os.getcwd()}))

    def _add_files(self, files: List[str], replace: bool=False):
        if replace:
            for iid in self.tree.get_children(""):
                self.tree.delete(iid)
        for p in files:
            try:
                if not os.path.isfile(p): continue
                name = os.path.basename(p)
                size = os.path.getsize(p)
                typ = (mimetypes.guess_type(p)[0] or "file").split("/")[0]
                cat = guess_category(name, p)
                self.tree.insert("", "end", values=(name, size, typ, cat, p))
            except Exception as e:
                _log(f"Add file fail {p}: {e}")
        self._refresh_preview()

    def _refresh_preview(self):
        sel = self.tree.selection()
        if not sel:
            self.prev_canvas.delete("all"); self.prev_text.config(text="Dateiinfo…"); return
        name, size, typ, cat, p = self.tree.item(sel[0], "values")
        info = f"Name: {name}\nGröße: {int(size)} B\nTyp: {typ}\nKategorie: {cat}\nPfad: {p}"
        self.prev_text.config(text=info)
        self.prev_canvas.delete("all")
        if _HAS_PIL and typ == "image":
            try:
                img = Image.open(p)
                img.thumbnail((self.prev_canvas.winfo_width() or 640, self.prev_canvas.winfo_height() or 360))
                self._tkimg = ImageTk.PhotoImage(img)  # keep ref
                self.prev_canvas.create_image(10,10, anchor="nw", image=self._tkimg)
            except Exception as e:
                _log(f"Preview image fail: {e}")
                self.prev_canvas.create_text(10,10, anchor="nw", text="(Bildvorschau fehlgeschlagen)")
        else:
            self.prev_canvas.create_text(10,10, anchor="nw", text="(Keine Bildvorschau verfügbar)")

    def _on_open(self, _evt):
        sel = self.tree.selection()
        if not sel: return
        p = self.tree.item(sel[0], "values")[4]
        try:
            os.startfile(p)
        except Exception as e:
            messagebox.showerror("Öffnen", f"Konnte Datei nicht öffnen:\n{e}")

    def _on_drop(self, evt):
        try:
            files = self.tk.splitlist(evt.data)
            self._add_files(list(files))
            self.status.config(text=f"{len(files)} Datei(en) gedroppt.")
        except Exception as e:
            _log(f"DnD error: {e}")

    def _rescan_if_inside(self, a: str, b: str):
        # wenn Ziel innerhalb Scan-Root liegt → aktualisieren
        root = (self._scan_dir or "").lower()
        if (a or "").lower().startswith(root) or (b or "").lower().startswith(root):
            self._worker_q.put(("scan", {"path": self._scan_dir}))
'''

MODULE_WORKERS = r'''# -*- coding: utf-8 -*-
"""
module_intake_workers – R1177b
(Reserviert für zukünftige spezialisierte Worker. Derzeit in module_code_intake integriert.)
"""
# Platz für spätere Auslagerung; aktuell nicht zwingend genutzt.
'''

SNIPPET_OPS = r'''# -*- coding: utf-8 -*-
"""
snippet_file_ops – R1177b
Sichere Datei-Transaktionen:
- safe_move_with_verify: Copy -> Verify (SHA256) -> Delete
- Journal: JSON Move-Historie für Undo
"""
from __future__ import annotations
import os, shutil, json, hashlib, datetime
from typing import Optional

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
LOG  = os.path.join(ROOT, "debug_output.txt")

def _log(msg: str):
    try:
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] [FileOps] {msg}\n")
    except Exception:
        pass

def ensure_dir(p: str): os.makedirs(p, exist_ok=True)

def sha256(p: str) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1<<20), b""):
            h.update(chunk)
    return h.hexdigest()

class Journal:
    def __init__(self, path: str):
        self.path = path
        ensure_dir(os.path.dirname(self.path))
        if not os.path.exists(self.path):
            with open(self.path, "w", encoding="utf-8") as f: f.write("[]")

    def _load(self):
        try:
            return json.load(open(self.path, "r", encoding="utf-8"))
        except Exception:
            return []

    def _save(self, data):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def append(self, src: str, dst: str):
        data = self._load()
        data.append({"src": src, "dst": dst, "ts": datetime.datetime.now().isoformat(timespec="seconds")})
        self._save(data)

    def pop_last(self):
        data = self._load()
        if not data: return None
        item = data.pop()
        self._save(data)
        return item

def safe_move_with_verify(src: str, dst: str, *, journal: Optional[Journal]=None, record: bool=True):
    if not os.path.isfile(src): raise FileNotFoundError(src)
    ensure_dir(os.path.dirname(dst))
    tmp = dst + ".tmpcopy"
    shutil.copy2(src, tmp)
    if sha256(src) != sha256(tmp):
        os.remove(tmp)
        raise IOError("Hash mismatch after copy")
    os.replace(tmp, dst)
    os.remove(src)
    if journal and record:
        journal.append(src, dst)
    _log(f"Move OK: {src} -> {dst}")
'''

SNIPPET_AUTOCAT = r'''# -*- coding: utf-8 -*-
"""
snippet_auto_category – R1177b
Einfaches Mapping von Datei-Endungen auf Kategorien.
"""
from __future__ import annotations
import os

MAP = {
    # Bilder
    ".jpg":"Images",".jpeg":"Images",".png":"Images",".webp":"Images",".gif":"Images",".bmp":"Images",".tif":"Images",".tiff":"Images",
    # Videos
    ".mp4":"Videos",".mov":"Videos",".mkv":"Videos",".avi":"Videos",".wmv":"Videos",
    # Audio
    ".mp3":"Audio",".wav":"Audio",".flac":"Audio",".ogg":"Audio",
    # Docs
    ".pdf":"Docs",".txt":"Docs",".md":"Docs",".json":"Docs",".csv":"Docs",
}

def guess_category(name: str, path: str) -> str:
    ext = os.path.splitext(name or path)[1].lower()
    return MAP.get(ext, "Misc")
'''

# --------- write files ---------
def main():
    write(os.path.join(MOD, "module_shim_intake.py"), MODULE_SHIM)
    write(os.path.join(MOD, "module_code_intake.py"), MODULE_CODE)
    write(os.path.join(MOD, "module_intake_workers.py"), MODULE_WORKERS)
    write(os.path.join(SNIP, "snippet_file_ops.py"), SNIPPET_OPS)
    write(os.path.join(SNIP, "snippet_auto_category.py"), SNIPPET_AUTOCAT)
    log("All Intake modules written.")
    print("[R1177b] Intake modules installed.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
