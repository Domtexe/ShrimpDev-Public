from __future__ import annotations
import os, time, json, socket
from pathlib import Path

PORT = int(os.environ.get("SHRIMPDEV_PORT", "9488"))
ADDR = ("127.0.0.1", PORT)
LOG  = Path(r"D:\ShrimpHub\debug_output.txt")
RUNNER = "ShrimpHub.debug_output"

def _send(level, msg):
    ev = {"runner": RUNNER, "level": level, "msg": msg,
          "ts": time.strftime("%m-%d %H:%M:%S", time.localtime())}
    data = json.dumps(ev, ensure_ascii=False).encode("utf-8")
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.sendto(data, ADDR); s.close()
    except Exception:
        ib = Path(r"D:\ShrimpDev\_Reports\Agent\inbox"); ib.mkdir(parents=True, exist_ok=True)
        (ib / f"{int(time.time())}_{os.getpid()}.jsonl").write_text(json.dumps(ev, ensure_ascii=False)+"\n", encoding="utf-8")

def main():
    _send("INFO", f"Tail start: {LOG}")
    LOG.parent.mkdir(parents=True, exist_ok=True)
    LOG.touch(exist_ok=True)
    with LOG.open("r", encoding="utf-8", errors="ignore") as f:
        f.seek(0, 2)
        while True:
            ln = f.readline()
            if not ln:
                time.sleep(0.25); continue
            _send("INFO", ln.rstrip())

if __name__ == "__main__":
    main()
