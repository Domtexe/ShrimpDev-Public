# -*- coding: utf-8 -*-
"""
Runner_1137a_IntakeLoadFix – "sprechende" Variante
- Druckt Heartbeats (Schritt 1..5) auf STDOUT, schreibt Report sofort.
- Identisch zum Fix-Ziel: Intake-Toolbar/Handler konsolidieren.
"""
from __future__ import annotations
import os, re, time, sys, shutil, traceback

ROOT = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
MODULE_PATH = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCHIV = os.path.join(ROOT, "_Archiv")
REPORT = os.path.join(ROOT, "_Reports", "Runner_1137a_IntakeLoadFix_report.txt")
LOG = os.path.join(ROOT, "debug_output.txt")

os.makedirs(os.path.dirname(REPORT), exist_ok=True)

def p(msg: str):
    print(msg, flush=True)
    with open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip()+"\n")

def read_retry(path: str, tries: int = 20, delay: float = 0.1) -> str:
    last = None
    for _ in range(tries):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            last = e; time.sleep(delay)
    raise last

def write_retry(path: str, data: str, tries: int = 20, delay: float = 0.1):
    last = None
    for _ in range(tries):
        try:
            with open(path, "w", encoding="utf-8", newline="\n") as f:
                f.write(data)
                return
        except Exception as e:
            last = e; time.sleep(delay)
    raise last

def backup(src: str) -> str:
    os.makedirs(ARCHIV, exist_ok=True)
    dst = os.path.join(ARCHIV, f"{os.path.basename(src)}.{int(time.time())}.bak")
    shutil.copy2(src, dst)
    return dst

def compile_ok(src: str) -> tuple[bool, str]:
    try:
        compile(src, os.path.basename(MODULE_PATH), "exec")
        return True, ""
    except SyntaxError as e:
        return False, f"SyntaxError: {e.msg} (line {e.lineno}, col {e.offset})"

# ---------- Patch-Helfer (wie zuvor) ----------
def replace_frm_actions_with_bar(s: str) -> tuple[str, int]:
    new, n = re.subn(r"(ttk\.Button\()\s*self\.frm_actions(\s*,)", r"\1bar\2", s)
    return new, n

def ensure_guard_button(s: str) -> tuple[str, int]:
    n_total = 0
    if "self.btn_guard" not in s:
        s, n = re.subn(r"(self\.btn_save[^\n]*\n)", r"\1        self.btn_guard = ttk.Button(bar, text=\"Prüfen (Guard)\", command=self._on_click_guard)\n        self.btn_guard.grid(row=0, column=99, padx=(4,0))\n", s, count=1)
        n_total += n
    s, n = re.subn(r"self\.btn_guard\.grid\([^)]*$", "self.btn_guard.grid(row=0, column=99, padx=(4,0))", s, flags=re.M)
    n_total += n
    return s, n_total

def fix_double_try(s: str) -> tuple[str, int]:
    pat = (r'(\n[ \t]*try:\n(?:[ \t]*self\.btn_detect\.bind[^\n]*\n)'
           r'(?:[ \t]*self\.btn_save\.bind[^\n]*\n)'
           r'(?:[ \t]*self\.btn_del\.bind[^\n]*\n))'
           r'[ \t]*try:\n[ \t]*pass\n[ \t]*except\s+Exception:\s*\n[ \t]*pass')
    def _f(m): return m.group(1)+"        except Exception:\n            pass"
    new, n = re.subn(pat, _f, s)
    return new, n

def ensure_handlers(s: str) -> tuple[str, int]:
    added = 0
    if re.search(r'\ndef\s+_on_click_guard\s*\(', s) is None:
        s += ("\n    def _on_click_guard(self, _evt=None):\n"
              "        try:\n"
              "            if hasattr(self, '_ping'): self._ping('Guard…')\n"
              "        except Exception: pass\n")
        added += 1
    if re.search(r'\ndef\s+_open_selected\s*\(', s) is None:
        s += ("\n    def _open_selected(self, _evt=None):\n"
              "        try:\n"
              "            import os, subprocess\n"
              "            p = getattr(self, '_path', None) or None\n"
              "            if not p: return\n"
              "            if os.path.isdir(p): os.startfile(p)\n"
              "            else: subprocess.Popen(f'explorer /select,\"{p}\"', shell=True)\n"
              "        except Exception: pass\n")
        added += 1
    return s, added

# --------------- Main ---------------
def main() -> int:
    p("[R1137a] Schritt 1/5: Vorprüfung")
    if not os.path.exists(MODULE_PATH):
        p(f"[R1137a] FEHLER: Datei fehlt: {MODULE_PATH}")
        return 2

    p("[R1137a] Schritt 2/5: Backup & Einlesen")
    bak = backup(MODULE_PATH)
    p(f"[R1137a] Backup -> {bak}")
    src = read_retry(MODULE_PATH)

    p("[R1137a] Schritt 3/5: Patches anwenden")
    changed = 0
    src2, n = replace_frm_actions_with_bar(src); changed += n; src = src2
    src2, n = ensure_guard_button(src); changed += n; src = src2
    src2, n = fix_double_try(src); changed += n; src = src2
    src2, n = ensure_handlers(src); changed += n; src = src2
    p(f"[R1137a] Patch-Zähler: {changed}")

    p("[R1137a] Schritt 4/5: Syntax-Check")
    ok, err = compile_ok(src)
    if not ok:
        p("[R1137a] Syntaxfehler nach Patch -> Rollback")
        p("[R1137a] " + err)
        write_retry(MODULE_PATH, read_retry(bak))  # expliziter Rollback
        return 1

    if changed:
        p("[R1137a] Schreibe Datei")
        write_retry(MODULE_PATH, src)
    else:
        p("[R1137a] Keine Änderungen nötig")

    p("[R1137a] Schritt 5/5: Fertig")
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        with open(REPORT, "a", encoding="utf-8") as f:
            f.write("[CRASH]\n"+traceback.format_exc())
        print("[R1137a] CRASH – siehe Report", flush=True)
        sys.exit(1)
