# -*- coding: utf-8 -*-
"""
R1171g_IntakeToolbarReflow
Ziel: Toolbar in links/rechts strukturieren, Status-Texte an die markierten Bereiche rücken.
Vorgehen:
- Fügt einen Helper _intake_toolbar_reflow(self) ein (wenn nicht vorhanden).
- Ergänzt R1170e-Lifecycle-Block um den Aufruf, falls noch nicht enthalten.
- Idempotent. Mit Backup, Syntax-Check, Rollback.
"""
from __future__ import annotations
import os, re, time, py_compile, traceback

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOG    = os.path.join(ROOT, "debug_output.txt")

MARK_HELPER = "# R1171g: toolbar reflow"
MARK_LIFE   = "# R1170e: lifecycle wire"

HELPER_BLOCK = """
# R1171g: toolbar reflow
def _intake_toolbar_reflow(self):
    \"\"\"Ordnet die Toolbar zweispaltig: links (Editor), rechts (Dateiliste).
    Links/rechts werden durch eine Stretch-Spalte getrennt. Status-Labels liegen
    an den rot markierten Positionen: links 'lbl_ping', rechts 'Erkennung: …'.\"\"\"
    try:
        from tkinter import ttk
    except Exception:
        return
    try:
        # Parent der bestehenden Buttons ermitteln
        parent = None
        for name in dir(self):
            if not name.startswith("btn_"):
                continue
            try:
                w = getattr(self, name, None)
                if hasattr(w, "winfo_exists") and w.winfo_exists():
                    parent = w.nametowidget(w.winfo_parent()); break
            except Exception:
                pass
        if parent is None:
            parent = getattr(self, "frm_actions", None)
        if parent is None:
            return

        # Spaltengewichte: 0..39 fix, 40 stretch (Trennung), 41..79 fix, 198 zusätzlicher Stretch (Kompat.)
        try:
            for i in range(0, 200):
                try: parent.columnconfigure(i, weight=0)
                except Exception: pass
            parent.columnconfigure(40, weight=1)
            parent.columnconfigure(198, weight=1)
        except Exception:
            pass

        # Hilfsfunktionen
        def _grid(widget, row, col, padx=(0,6), sticky="w"):
            try:
                widget.grid(row=row, column=col, padx=padx, sticky=sticky)
            except Exception:
                pass

        def _opt(name):
            w = getattr(self, name, None)
            return w if w and getattr(w, "winfo_exists", lambda: False)() else None

        # --- Linke Gruppe (über dem Editor) ---
        colL = 0
        for n in ("btn_clear", "btn_detect", "btn_save"):
            w = _opt(n)
            if w: _grid(w, 0, colL); colL += 1

        # linker Status (lbl_ping) füllt bis Trennspalte
        lbl_ping = getattr(self, "lbl_ping", None)
        if not lbl_ping:
            try:
                lbl_ping = ttk.Label(parent, text="", anchor="w")
                self.lbl_ping = lbl_ping
            except Exception:
                lbl_ping = None
        if lbl_ping:
            try:
                lbl_ping.grid(row=0, column=colL, padx=(12,4), sticky="ew")
                # Spanne bis vor Trennspalte: wir setzen columnspan so, dass es (40 - colL) Spalten umfasst
                lbl_ping.grid_configure(columnspan=max(1, 40 - colL))
            except Exception:
                pass

        # --- Rechte Gruppe (über der Dateiliste) ---
        colR0 = 41
        colR  = colR0
        for n in ("btn_guard", "btn_repair", "btn_run", "btn_refresh", "btn_pack", "btn_delete"):
            w = _opt(n) or _opt(n.replace("btn_delete", "btn_del"))
            if w: _grid(w, 0, colR); colR += 1

        # rechter Status: Erkennungstext (falls als Label vorhanden), sonst Dummy-Label
        detect_lbl = None
        # heuristisch: Attributnamen durchsuchen
        for nm in dir(self):
            if nm.startswith("lbl_") and "detect" in nm:
                detect_lbl = getattr(self, nm, None); break
        if detect_lbl is None:
            # versuche bekannten Text auf existierenden Labels
            for nm in dir(self):
                if not nm.startswith("lbl_"):
                    continue
                try:
                    w = getattr(self, nm, None)
                    if hasattr(w, "cget") and isinstance(w.cget("text"), str) and "Erkennung" in w.cget("text"):
                        detect_lbl = w; break
                except Exception:
                    pass
        if detect_lbl is None:
            try:
                detect_lbl = ttk.Label(parent, text="Erkennung: (keine)", anchor="e")
                self.lbl_detect = detect_lbl
            except Exception:
                detect_lbl = None
        if detect_lbl:
            try:
                _grid(detect_lbl, 0, colR, padx=(12,0), sticky="ew")
                detect_lbl.grid_configure(columnspan=max(1, 198 - colR))
            except Exception:
                pass

        # Optik: knappe, einheitliche Buttons
        try:
            style = ttk.Style()
            style.configure("TButton", padding=(10, 4))
        except Exception:
            pass

    except Exception:
        # Keine Exceptions nach außen
        pass
"""

def _log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1171g {ts}] {msg}\n"
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def _backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "r", encoding="utf-8") as fi, open(dst, "w", encoding="utf-8", newline="") as fo:
        fo.write(fi.read())
    return dst

def _ensure_helper(src: str) -> tuple[str, bool]:
    if MARK_HELPER in src:
        return src, False
    # nach helpers-Marker oder EOF
    m = re.search(r"(?m)^\s*#\s*-{2,}\s*helpers\s*-{2,}\s*$", src)
    pos = m.end() if m else len(src)
    return src[:pos] + "\n" + HELPER_BLOCK + src[pos:], True

def _ensure_lifecycle_call(src: str) -> tuple[str, bool]:
    if MARK_LIFE not in src:
        _log("Warnung: R1170e-Lifecycle-Block fehlt – kein Auto-Call. (Helper ist trotzdem verfügbar.)")
        return src, False
    m = re.search(r"(?m)^([ \t]*)" + re.escape(MARK_LIFE) + r"\s*$", src)
    base = m.group(1)
    start = m.end()
    pat_end = re.compile(r"(?m)^(%s)(def|class)\b" % re.escape(base))
    m_end = pat_end.search(src, start)
    end = m_end.start() if m_end else len(src)
    block = src[start:end]
    if "_intake_toolbar_reflow(self)" in block:
        return src, False
    block = block.rstrip() + "\n" + base + "    _intake_toolbar_reflow(self)\n"
    return src[:start] + block + src[end:], True

def main() -> int:
    try:
        if not os.path.exists(TARGET):
            _log(f"Zieldatei fehlt: {TARGET}")
            return 1
        src = open(TARGET, "r", encoding="utf-8").read()
        changed = False

        src, ch = _ensure_helper(src); changed |= ch
        src, ch = _ensure_lifecycle_call(src); changed |= ch

        if not changed:
            _log("Keine Änderung erforderlich (bereits gepatcht).")
            return 0

        bak = _backup(TARGET); _log(f"Backup erstellt: {bak}")
        with open(TARGET, "w", encoding="utf-8", newline="\n") as f:
            f.write(src)

        try:
            py_compile.compile(TARGET, doraise=True)
        except Exception as e:
            with open(bak, "r", encoding="utf-8") as fi, open(TARGET, "w", encoding="utf-8", newline="\n") as fo:
                fo.write(fi.read())
            _log("Syntax-Check FEHLER -> Rollback auf Backup.")
            _log("Traceback:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 1

        _log("Patch erfolgreich eingefügt und Syntax-Check OK.")
        return 0

    except Exception as e:
        _log("UNERWARTETER FEHLER:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
