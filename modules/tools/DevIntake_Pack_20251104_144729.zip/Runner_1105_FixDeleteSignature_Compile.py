# D:\ShrimpDev\tools\Runner_1105_FixDeleteSignature_Compile.py
from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.dirname(__file__))
APP  = os.path.dirname(ROOT)
SRC  = os.path.join(APP, "modules", "module_code_intake.py")
ARCH = os.path.join(APP, "_Archiv")
os.makedirs(ARCH, exist_ok=True)

def backup(path: str) -> str:
    ts = int(time.time())
    bak = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    shutil.copy2(path, bak)
    print(f"[R1105] Backup: {path} -> {bak}")
    return bak

def read_text(p): 
    with open(p, "r", encoding="utf-8") as f: 
        return f.read()

def write_text(p, s):
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)

def fix_delete_signature(src: str) -> tuple[str, int]:
    """
    Ersetzt def _on_click_delete(self, *_evt=None)  -> def _on_click_delete(self, _evt=None)
    Fängt auch Varianten wie *evt=None, *e=None etc. ab.
    """
    rx = re.compile(r"def\s+_on_click_delete\(\s*self\s*,\s*\*[_a-zA-Z0-9]+\s*=\s*None\s*\)", re.M)
    new = rx.sub("def _on_click_delete(self, _evt=None)", src)
    return new, (0 if new == src else 1)

def sanity_compile(src_text: str) -> None:
    try:
        compile(src_text, "module_code_intake.py", "exec")
        print("[R1105] Syntax OK.")
    except SyntaxError as e:
        # etwas Kontext ausgeben
        line = e.lineno or 0
        lines = src_text.splitlines()
        ctx = []
        for i in range(max(0, line-3), min(len(lines), line+2)):
            prefix = ">> " if (i+1)==line else "   "
            ctx.append(f"{prefix}{i+1:04d}: {lines[i]}")
        print("[R1105] SyntaxError:", e)
        print("---- context ----")
        print("\n".join(ctx))
        raise

def main():
    if not os.path.exists(SRC):
        print(f"[R1105] Datei nicht gefunden: {SRC}")
        return
    backup(SRC)
    src = read_text(SRC)
    src2, changed = fix_delete_signature(src)
    if changed:
        write_text(SRC, src2)
        print("[R1105] _on_click_delete-Signatur korrigiert.")
    else:
        print("[R1105] Keine Korrektur nötig (Signatur bereits ok).")
    # Syntax prüfen
    sanity_compile(read_text(SRC))

if __name__ == "__main__":
    main()
