"""
Runner_1014_SafeBoot_StringFix
- Korrigiert SyntaxError durch unescaped Zeilenumbruch in SafeImport-Strings.
- Alle "Fehler: …" Textzeilen werden mit \\n korrekt escaped.
- Version -> v9.9.5
"""
from __future__ import annotations
import os, re, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
GUI  = os.path.join(ROOT, "main_gui.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1014] {ts} {msg}\n")
    print(msg)

def patch():
    try:
        with open(GUI, "r", encoding="utf-8") as f:
            src = f.read()

        # Fehlerhafte Strings erkennen (Fehler: ... konnte nicht geladen werden.)
        src_fixed = re.sub(
            r'Fehler: ([^"]+)\\n',
            lambda m: f'Fehler: {m.group(1)}\\\\n',
            src
        )

        # Spezifischer: ersetze Zeilen mit unescaped Newlines in SafeImport
        src_fixed = src_fixed.replace(
            'txt.insert("end", "Fehler: IntakeFrame konnte nicht geladen werden.',
            'txt.insert("end", "Fehler: IntakeFrame konnte nicht geladen werden.\\n'
        )
        src_fixed = src_fixed.replace(
            'tk.Message(frm, text="".join(traceback.format_exception_only(type(_ex), _ex)), width=800).pack(padx=10, pady=4)',
            'tk.Message(frm, text="".join(traceback.format_exception_only(type(_ex), _ex)), width=800).pack(padx=10, pady=4)'
        )

        if src_fixed != src:
            os.makedirs(ARCH, exist_ok=True)
            bck = os.path.join(ARCH, f"main_gui.py.{int(time.time())}.bak")
            shutil.copy2(GUI, bck)
            with open(GUI, "w", encoding="utf-8", newline="\r\n") as f:
                f.write(src_fixed)
            log("main_gui.py korrigiert (escaped strings in SafeImport).")
        else:
            log("main_gui.py bereits korrekt.")

        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.5\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.5 (2025-10-18)
- FIX: SyntaxError durch unescaped Zeilenumbruch in SafeImport-String (Fehler: IntakeFrame...)
""")
        log("Patch erfolgreich.")
        return 0
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(patch())
