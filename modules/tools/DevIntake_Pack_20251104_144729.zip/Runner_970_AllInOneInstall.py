from __future__ import annotations
from pathlib import Path
import time, json

ROOT = Path(r"D:\ShrimpDev")
MOD  = ROOT / "modules"
REP  = ROOT / "_Reports"
AG   = REP / "Agent"
AG.mkdir(parents=True, exist_ok=True)
LOGF = ROOT / "debug_output.txt"

def log(msg: str):
    try: LOGF.open("a", encoding="utf-8", errors="ignore").write(f"[R970] {msg}\n")
    except Exception: pass

def w(p: Path, s: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        p.write_text(s, encoding="utf-8")
        log(f"wrote {p.relative_to(ROOT)}")
    else:
        log(f"kept {p.relative_to(ROOT)}")

def agent_ui_py() -> str:
    return r'''from __future__ import annotations
import json, tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
import time

ROOT   = Path(r"D:\ShrimpDev")
EVENTS = ROOT / "_Reports" / "Agent" / "events.jsonl"
STATUS = ROOT / "_Reports" / "Agent" / "agent_status.html"

def _tail(n: int = 500):
    if not EVENTS.exists(): return []
    lines = EVENTS.read_text(encoding="utf-8", errors="ignore").splitlines()[-n:]
    out=[]
    for ln in lines:
        try: out.append(json.loads(ln))
        except Exception: out.append({"ts":"", "runner":"?", "level":"INFO", "msg": ln})
    return out

class _Win(tk.Toplevel):
    def __init__(self, app: tk.Tk):
        super().__init__(app)
        self.title("🦐 Agent Monitor"); self.geometry("1000x560+140+140")
        bar = ttk.Frame(self); bar.pack(fill="x", pady=6)
        ttk.Label(bar, text="Level:").pack(side="left")
        self.var_level = tk.StringVar(value="ALL")
        ttk.Combobox(bar, textvariable=self.var_level, values=["ALL","OK","INFO","WARN","ERROR","FAIL"], width=8, state="readonly").pack(side="left", padx=6)
        ttk.Button(bar, text="Refresh", command=self.refresh).pack(side="left")
        self.var_auto = tk.BooleanVar(value=True)
        ttk.Checkbutton(bar, text="Auto (2s)", variable=self.var_auto).pack(side="right")
        cols=("ts","runner","level","msg"); self.tree=ttk.Treeview(self, columns=cols, show="headings")
        for c,w in zip(cols,(170,180,90,540)): self.tree.heading(c, text=c); self.tree.column(c, width=w, anchor="w")
        self.tree.pack(fill="both", expand=True)
        self.after_id=None; self.refresh()

    def _f(self, rows):
        lv = self.var_level.get().upper()
        if lv=="ALL": return rows
        return [r for r in rows if str(r.get("level","")).upper()==lv]

    def refresh(self):
        try:
            if self.after_id: self.after_cancel(self.after_id)
        except Exception: pass
        rows = self._f(_tail())
        for i in self.tree.get_children(): self.tree.delete(i)
        for r in rows: self.tree.insert("", "end", values=(r.get("ts",""), r.get("runner",""), r.get("level",""), r.get("msg","")))
        if self.var_auto.get(): self.after_id = self.after(2000, self.refresh)

def open_agent_monitor(app: tk.Tk) -> bool:
    try: _Win(app); return True
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Agent Monitor Fehler:\n{ex}")
        except Exception: pass
        return False
'''

def code_intake_py() -> str:
    return r'''from __future__ import annotations
import re
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

ROOT = Path(r"D:\ShrimpDev")

def _detect_name_and_ext(code: str):
    head = code[:4000]
    patterns = [
        r"(?im)^\s*#\s*file\s*:\s*(?P<p>[\w\-/\\\. ]+\.(py|bat|cmd|vbs|ps1|json|md|txt))\s*$",
        r"(?ism)^[`\"']{3}[^`\"']*?(?P<p>[\w\-/\\\. ]+\.(py|bat|cmd|vbs|ps1|json|md|txt))[^`\"']*?[`\"']{3}",
        r"(?im)^\s*//\s*(?P<p>[\w\-/\\\. ]+\.(py|bat|cmd|vbs|ps1|json|md|txt))\s*$",
        r"(?im)^\s*;\s*(?P<p>[\w\-/\\\. ]+\.(py|bat|cmd|vbs|ps1|json|md|txt))\s*$",
        r"(?i)\b(Runner_\w+\.(py|bat|cmd|vbs))\b",
        r"(?i)\b(module_[\w\-]+\.py)\b",
    ]
    for pat in patterns:
        m = re.search(pat, head)
        if m:
            p = m.group("p") if "p" in m.groupdict() else m.group(0)
            from pathlib import Path as P
            n = P(p).name; e = P(n).suffix.lower()
            return n, e
    return None, None

def _map_target(workspace: Path, name: str, ext: str) -> Path:
    n = name.lower()
    if ext==".py" and n.startswith("runner_"): return workspace/"tools"
    if ext in {".bat",".cmd",".vbs",".ps1"}:   return workspace/"tools"
    if ext==".py" and n.startswith("module_"): return workspace/"modules"
    if ext==".py":                             return workspace/"modules"/"snippets"
    return workspace

class _Win(tk.Toplevel):
    def __init__(self, app: tk.Tk):
        super().__init__(app)
        self.title("🦐 ShrimpDev – Code Intake"); self.geometry("1000x680+120+120")
        try:
            from modules.config_mgr import load_config
            self.conf = load_config()
        except Exception:
            self.conf = {"workspace_root": r"D:\ShrimpHub"}
        self.workspace = Path(self.conf.get("workspace_root", r"D:\ShrimpHub"))

        top = ttk.Frame(self); top.pack(fill="x", pady=6)
        ttk.Label(top, text="Workspace:").pack(side="left")
        self.var_ws = tk.StringVar(value=str(self.workspace))
        ttk.Entry(top, textvariable=self.var_ws, width=60).pack(side="left", padx=6)
        ttk.Button(top, text="…", command=self._pick_ws).pack(side="left")

        bar = ttk.Frame(self); bar.pack(fill="x", pady=4)
        self.var_name = tk.StringVar(); self.var_ext = tk.StringVar(); self.var_target = tk.StringVar()
        for lbl, var, w in (("Dateiname:", self.var_name, 40), ("Endung:", self.var_ext, 8), ("Zielordner:", self.var_target, 50)):
            ttk.Label(bar, text=lbl).pack(side="left"); ttk.Entry(bar, textvariable=var, width=w).pack(side="left", padx=6)

        self.txt = tk.Text(self, wrap="none", undo=True); self.txt.pack(fill="both", expand=True)
        self.txt.bind("<<Modified>>", self._on_modified)

        b = ttk.Frame(self); b.pack(fill="x", pady=6)
        ttk.Button(b, text="Erkennen (Ctrl+I)", command=self._detect).pack(side="left")
        ttk.Button(b, text="Speichern (Ctrl+S)", command=self._save).pack(side="right")
        self.status = tk.StringVar(value="Bereit."); ttk.Label(self, textvariable=self.status, anchor="w").pack(fill="x")
        self.bind_all("<Control-i>", lambda e: self._detect())
        self.bind_all("<Control-s>", lambda e: self._save())

    def _pick_ws(self):
        d = filedialog.askdirectory(title="Workspace wählen", initialdir=str(self.workspace))
        if d:
            self.workspace = Path(d); self.var_ws.set(str(self.workspace))

    def _on_modified(self, _=None):
        self.txt.edit_modified(0)
        if not self.var_name.get() or not self.var_ext.get(): self._detect(auto=True)

    def _detect(self, auto: bool=False):
        code = self.txt.get("1.0", "end-1c")
        name, ext = _detect_name_and_ext(code)
        if name: self.var_name.set(name)
        if ext:  self.var_ext.set(ext)
        nm, ex = self.var_name.get().strip(), self.var_ext.get().strip().lower()
        if nm and ex: self.var_target.set(str(_map_target(self.workspace, nm, ex)))
        if not auto: self.status.set(f"Erkannt: name={nm!r}, ext={ex!r}, target={self.var_target.get()!r}")

    def _save(self):
        nm, ex, target = self.var_name.get().strip(), self.var_ext.get().strip().lower(), self.var_target.get().strip()
        code = self.txt.get("1.0", "end-1c")
        if not nm or not ex or not target:
            messagebox.showwarning("ShrimpDev", "Bitte Name/Endung/Target prüfen."); return
        if not nm.lower().endswith(ex): nm = Path(nm).stem + ex; self.var_name.set(nm)
        out_dir = Path(target); out_dir.mkdir(parents=True, exist_ok=True)
        out = out_dir / nm
        # einfache Rotations-Backups
        if out.exists():
            for i in range(4,0,-1):
                pi = out.with_name(out.name + f".{i}.bak"); pj = out.with_name(out.name + f".{i+1}.bak")
                if pi.exists(): pi.replace(pj)
            try: out.with_name(out.name + ".bak").replace(out.with_name(out.name + ".1.bak"))
            except Exception: pass
        out.write_text(code, encoding="utf-8")
        messagebox.showinfo("ShrimpDev", f"Gespeichert:\n{out}")
        self.status.set(f"Gespeichert: {out}")

def open_intake(app: tk.Tk) -> bool:
    try: _Win(app); return True
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Intake Fehler:\n{ex}")
        except Exception: pass
        return False
'''

def project_ui_py() -> str:
    return r'''from __future__ import annotations
import os, json, tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")

def _scan(ws: Path) -> dict:
    out = {"root": str(ws), "modules": [], "tools": [], "snippets": [], "other": []}
    if not ws.exists(): return out
    for p in ws.rglob("*"):
        if p.is_dir(): continue
        rel = p.relative_to(ws).as_posix()
        if rel.startswith("modules/snippets/"): out["snippets"].append(rel)
        elif rel.startswith("modules/"):        out["modules"].append(rel)
        elif rel.startswith("tools/"):          out["tools"].append(rel)
        else:                                   out["other"].append(rel)
    return out

class _Win(tk.Toplevel):
    def __init__(self, app: tk.Tk):
        super().__init__(app)
        self.title("🦐 Project Map"); self.geometry("1000x620+140+120")
        try:
            from modules.config_mgr import load_config
            self.conf = load_config()
        except Exception:
            self.conf = {"workspace_root": r"D:\ShrimpHub"}
        self.ws = Path(self.conf.get("workspace_root", r"D:\ShrimpHub"))

        top = ttk.Frame(self); top.pack(fill="x", pady=6)
        ttk.Label(top, text="Workspace:").pack(side="left")
        self.var_ws = tk.StringVar(value=str(self.ws))
        ttk.Entry(top, textvariable=self.var_ws, width=60).pack(side="left", padx=6)
        ttk.Button(top, text="Scan", command=self.refresh).pack(side="left")
        cols=("type","path"); self.tree=ttk.Treeview(self, columns=cols, show="headings")
        for c,w in zip(cols,(120,820)): self.tree.heading(c, text=c); self.tree.column(c, width=w, anchor="w")
        self.tree.pack(fill="both", expand=True)
        self.refresh()

    def refresh(self):
        self.ws = Path(self.var_ws.get().strip() or r"D:\ShrimpHub")
        data = _scan(self.ws)
        for i in self.tree.get_children(): self.tree.delete(i)
        for k in ("modules","snippets","tools","other"):
            for rel in data.get(k, []): self.tree.insert("", "end", values=(k, rel))

def open_project_map(app: tk.Tk) -> bool:
    try: _Win(app); return True
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Project Map Fehler:\n{ex}")
        except Exception: pass
        return False
'''

def runner_board_py() -> str:
    return r'''from __future__ import annotations
import subprocess, tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")

class _Win(tk.Toplevel):
    def __init__(self, app: tk.Tk):
        super().__init__(app)
        self.title("🦐 Runner Board"); self.geometry("900x560+180+140")
        bar = ttk.Frame(self); bar.pack(fill="x", pady=6)
        ttk.Button(bar, text="Refresh", command=self.refresh).pack(side="left")
        self.tree = ttk.Treeview(self, columns=("file","type"), show="headings")
        for c,w in (("file",650),("type",160)): self.tree.heading(c, text=c); self.tree.column(c, width=w, anchor="w")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<Double-1>", self._run_selected)
        self.refresh()

    def _list(self):
        t = ROOT/"tools"
        out=[]
        if t.exists():
            for p in sorted(t.glob("Runner_*.*")):
                if p.suffix.lower() in {".py",".bat",".cmd"}:
                    out.append((p.name, p.suffix.lower().lstrip(".")))
        return out

    def refresh(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        for name, typ in self._list(): self.tree.insert("", "end", values=(name, typ))

    def _run_selected(self, _evt=None):
        sel = self.tree.focus()
        if not sel: return
        name, typ = self.tree.item(sel, "values")
        cmd = ["cmd","/c","start","", str(ROOT/"tools"/name)]
        try: subprocess.Popen(cmd, cwd=str(ROOT), shell=False)
        except Exception as ex:
            try: messagebox.showerror("ShrimpDev", f"Startfehler:\n{ex}")
            except Exception: pass

def open_runner_board(app: tk.Tk) -> bool:
    try: _Win(app); return True
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Runner Board Fehler:\n{ex}")
        except Exception: pass
        return False
'''

def settings_ui_py() -> str:
    return r'''from __future__ import annotations
import json, tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
CFG  = ROOT / "config.json"

def _load() -> dict:
    if not CFG.exists(): return {"workspace_root": r"D:\ShrimpHub", "quiet_mode": True}
    try: return json.loads(CFG.read_text(encoding="utf-8", errors="ignore") or "{}") or {}
    except Exception: return {"workspace_root": r"D:\ShrimpHub", "quiet_mode": True}

def _save(conf: dict):
    try: CFG.write_text(json.dumps(conf, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception: pass

class _Win(tk.Toplevel):
    def __init__(self, app: tk.Tk):
        super().__init__(app)
        self.title("🦐 Settings"); self.geometry("540x280+220+180")
        self.conf = _load()
        frm = ttk.Frame(self); frm.pack(fill="both", expand=True, padx=10, pady=10)
        ttk.Label(frm, text="Workspace Root:").grid(row=0, column=0, sticky="w")
        self.var_ws = tk.StringVar(value=self.conf.get("workspace_root", r"D:\ShrimpHub"))
        ttk.Entry(frm, textvariable=self.var_ws, width=46).grid(row=0, column=1, sticky="we", padx=6)
        ttk.Button(frm, text="…", command=self._pick).grid(row=0, column=2)
        self.var_quiet = tk.BooleanVar(value=bool(self.conf.get("quiet_mode", True)))
        ttk.Checkbutton(frm, text="Quiet Mode (Popup-Reduktion)", variable=self.var_quiet).grid(row=1, column=1, sticky="w", pady=8)
        b = ttk.Frame(self); b.pack(fill="x", pady=8, padx=10)
        ttk.Button(b, text="Speichern", command=self._save).pack(side="right")

    def _pick(self):
        d = filedialog.askdirectory(title="Workspace wählen", initialdir=str(Path(self.var_ws.get() or r"D:\\")))
        if d: self.var_ws.set(d)

    def _save(self):
        self.conf["workspace_root"] = self.var_ws.get().strip() or r"D:\ShrimpHub"
        self.conf["quiet_mode"] = bool(self.var_quiet.get())
        _save(self.conf)
        try: messagebox.showinfo("ShrimpDev", "Gespeichert.")
        except Exception: pass

def open_settings(app: tk.Tk) -> bool:
    try: _Win(app); return True
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Settings Fehler:\n{ex}")
        except Exception: pass
        return False
'''

def preflight_py() -> str:
    return r'''from __future__ import annotations
import sys, subprocess, tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
import time

ROOT = Path(r"D:\ShrimpDev")
OUT  = ROOT / "_Reports" / "Preflight"
OUT.mkdir(parents=True, exist_ok=True)

def _check():
    rows=[]
    # Python
    rows.append(("python", sys.version.split()[0], "OK" if sys.version_info >= (3,10) else "WARN"))
    # Tk
    try:
        import tkinter as t
        rows.append(("tkinter", "available", "OK"))
    except Exception as ex:
        rows.append(("tkinter", f"error: {ex}", "FAIL"))
    # dirs
    for d in (ROOT/"modules", ROOT/"tools", ROOT/"_Reports"):
        rows.append((f"dir:{d.name}", "exists" if d.exists() else "missing", "OK" if d.exists() else "WARN"))
    return rows

class _Win(tk.Toplevel):
    def __init__(self, app: tk.Tk):
        super().__init__(app)
        self.title("🦐 Preflight"); self.geometry("700x420+260+220")
        ttk.Button(self, text="Run Checks", command=self.run).pack(anchor="e", padx=10, pady=6)
        cols=("item","value","status"); self.tree=ttk.Treeview(self, columns=cols, show="headings")
        for c,w in zip(cols,(300,280,80)): self.tree.heading(c, text=c); self.tree.column(c, width=w, anchor="w")
        self.tree.pack(fill="both", expand=True)

    def run(self):
        rows = _check()
        for i in self.tree.get_children(): self.tree.delete(i)
        for r in rows: self.tree.insert("", "end", values=r)
        rep = OUT / f"Preflight_{time.strftime('%Y%m%d_%H%M%S')}.txt"
        txt = "\n".join([f"{a}\t{b}\t{c}" for a,b,c in rows])
        rep.write_text(txt, encoding="utf-8")

def open_preflight(app: tk.Tk) -> bool:
    try: _Win(app); return True
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Preflight Fehler:\n{ex}")
        except Exception: pass
        return False
'''

def patch_release_py() -> str:
    return r'''from __future__ import annotations
import zipfile, tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
import time

ROOT = Path(r"D:\ShrimpDev")
OUT  = ROOT / "_Exports"
OUT.mkdir(parents=True, exist_ok=True)

def _default_includes(p: Path) -> bool:
    rel = p.relative_to(ROOT).as_posix()
    if rel.startswith("_Reports/") or rel.startswith("_Exports/") or rel.startswith("dist/"): return False
    if "/__pycache__/" in rel: return False
    return True

class _Win(tk.Toplevel):
    def __init__(self, app: tk.Tk):
        super().__init__(app)
        self.title("🦐 Patch / Export"); self.geometry("600x260+300+240")
        ttk.Label(self, text="Erstellt ein ZIP der aktuellen ShrimpDev-Struktur.").pack(anchor="w", padx=10, pady=8)
        ttk.Button(self, text="Build ZIP", command=self.build).pack(pady=10)

    def build(self):
        name = f"ShrimpDev_patch_{time.strftime('%Y%m%d_%H%M%S')}.zip"
        target = OUT / name
        with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for p in ROOT.rglob("*"):
                if p.is_file() and _default_includes(p):
                    z.write(p, p.relative_to(ROOT))
        try: messagebox.showinfo("ShrimpDev", f"Export:\n{target}")
        except Exception: pass

def open_patch_release(app: tk.Tk) -> bool:
    try: _Win(app); return True
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Patch/Release Fehler:\n{ex}")
        except Exception: pass
        return False
'''

def main():
    w(MOD/"module_agent_ui.py",      agent_ui_py())
    w(MOD/"module_code_intake.py",   code_intake_py())
    w(MOD/"module_project_ui.py",    project_ui_py())
    w(MOD/"module_runner_board.py",  runner_board_py())
    w(MOD/"module_settings_ui.py",   settings_ui_py())
    w(MOD/"module_preflight.py",     preflight_py())
    w(MOD/"module_patch_release.py", patch_release_py())
    # Agent-Ordner & leere events.jsonl anlegen, falls nicht existent
    (AG/"events.jsonl").touch(exist_ok=True)
    print("[R970] DONE – Alle Module vorhanden. Öffne GUI (start_visible.bat).")

if __name__ == "__main__":
    main()
