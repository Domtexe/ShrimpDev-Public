from __future__ import annotations
from pathlib import Path
import importlib, sys, textwrap, time

ROOT = Path(r"D:\ShrimpDev")
MODPATH = ROOT / "modules" / "module_code_intake.py"

def load_module():
    """
    Lade module_code_intake im richtigen Paketkontext:
    - sys.path[0] = D:\ShrimpDev  -> import 'modules.module_code_intake' funktioniert
    """
    if str(ROOT) not in map(str, sys.path):
        sys.path.insert(0, str(ROOT))
    return importlib.import_module("modules.module_code_intake")

def tc(name: str, code: str, expect_name: str|None, expect_ext: str) -> bool:
    mod = load_module()
    n, e = mod._extract(textwrap.dedent(code))  # type: ignore
    ok = ((expect_name is None or (n or "").lower() == expect_name.lower()) and (e == expect_ext))
    print(f"[TEST] {name}: input=({n},{e}) expected=({expect_name},{expect_ext}) => {'OK' if ok else 'FAIL'}")
    return ok

def main():
    if not MODPATH.exists():
        print(f"[R947] FEHLT: {MODPATH} – bitte zuerst Runner_946_IntakeSmart.bat ausführen.")
        return 2

    ok = True
    ok &= tc("header file", "# file: tools/Runner_960.py\nprint('x')", "Runner_960.py", ".py")
    ok &= tc("fenced", "```python filename=modules/module_abc.py```\nprint()", "module_abc.py", ".py")
    ok &= tc("yaml fm", "---\nfilename: tools/Runner_961.bat\n---\n@echo off", "Runner_961.bat", ".bat")
    ok &= tc("inline marker", "@@file=modules/module_demo.py@@\nprint(1)", "module_demo.py", ".py")
    ok &= tc("pragma", "REM FILE tools/Runner_962.cmd\n@echo off", "Runner_962.cmd", ".cmd")
    ok &= tc("heuristic py", "def main(): pass", None, ".py")
    ok &= tc("heuristic bat", "@echo off\nset X=1", None, ".bat")

    print("[R947] RESULT:", "OK" if ok else "FAIL")
    return 0 if ok else 1

if __name__ == "__main__":
    raise SystemExit(main())
