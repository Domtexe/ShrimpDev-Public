# -*- coding: utf-8 -*-
r"""
Runner_1123_EditorGuardPatch
Sichere Editor-Callbacks (Paste/Modified/Key) + Detect-Scheduler für Intake-Tab.

Vorgehen:
- Backup modules/module_code_intake.py
- Ersetze/füge robuste Implementierungen ein:
    _on_editor_paste, _on_editor_modified, _on_editor_key,
    _schedule_detect, _auto_detect_if_needed, _safe_detect
- Stelle sicher: genau EIN Binding pro Event, keine Doppelbindungen.
- Logging: zentral via write_log(), Fallback auf debug_output.txt (schluckend).

Start: py -3 -u tools\Runner_1123_EditorGuardPatch.py
"""

from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
P_MOD = os.path.join(ROOT, "modules", "module_code_intake.py")
REPORT_DIR = os.path.join(ROOT, "_Reports")
ARCH_DIR   = os.path.join(ROOT, "_Archiv")
os.makedirs(REPORT_DIR, exist_ok=True)
os.makedirs(ARCH_DIR, exist_ok=True)
REPORT = os.path.join(REPORT_DIR, "Runner_1123_EditorGuardPatch_report.txt")

def rep(msg: str) -> None:
    with open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip() + "\n")

def backup(src: str) -> str:
    ts = str(int(time.time()))
    dst = os.path.join(ARCH_DIR, f"{os.path.basename(src)}.{ts}.bak")
    shutil.copy2(src, dst)
    rep(f"[Backup] {src} -> {dst}")
    return dst

SNIPPET = r'''
    # --- Editor-Event-Guards (1123) -----------------------------------------
    def _safe_write(self, prefix: str, message: str) -> None:
        try:
            from modules.snippets.logger_snippet import write_log as _w
            _w(prefix, message)
        except Exception:
            try:
                p = os.path.join(os.path.dirname(os.path.dirname(__file__)), "debug_output.txt")
                ts = time.strftime("%Y-%m-%d %H:%M:%S")
                with open(p, "a", encoding="utf-8", newline="\n") as f:
                    f.write(f"[{prefix}] {ts} {message}\n")
            except Exception:
                pass

    def _ensure_editor_bindings(self) -> None:
        """Genau ein Binding pro Event; alte/plus-Bindings vermeiden."""
        try:
            # remove duplicates defensively
            self.txt.unbind("<<Paste>>")
            self.txt.unbind("<Control-v>")
            self.txt.unbind("<<Modified>>")
            self.txt.unbind("<KeyRelease>")
        except Exception:
            pass
        self.txt.bind("<<Paste>>", self._on_editor_paste)
        self.txt.bind("<Control-v>", self._on_editor_paste)
        self.txt.bind("<<Modified>>", self._on_editor_modified)
        self.txt.bind("<KeyRelease>", self._on_editor_key)

    def _on_editor_paste(self, _evt=None):
        """Paste: Standard-Paste ausführen lassen, dann Detect planen – niemals direkt detect() aufrufen."""
        try:
            # Standardpaste auslösen
            try:
                self.txt.event_generate("<<Paste>>") if _evt and _evt.type else None
            except Exception:
                # Fallback für Treiber/Layouts ohne <<Paste>>
                try:
                    import tkinter as _tk
                    data = self.txt.clipboard_get()
                    if data:
                        self.txt.insert("insert", data)
                except Exception:
                    pass
            # Detect leicht verzögert, um Reentrancy zu vermeiden
            self._schedule_detect(200)
        except Exception as ex:
            self._safe_write("INTAKE", f"PASTE_ERR: {ex!r}")

    def _on_editor_key(self, _evt=None):
        """KeyRelease: nur Detect schedulen; keine teuren Operationen im UI-Thread."""
        try:
            self._schedule_detect(250)
        except Exception as ex:
            self._safe_write("INTAKE", f"KEY_ERR: {ex!r}")

    def _on_editor_modified(self, _evt=None):
        """Modified: Flag zurücksetzen und Detect planen – ohne zu raisen."""
        try:
            try:
                self.txt.edit_modified(False)
            except Exception:
                pass
            self._schedule_detect(300)
        except Exception as ex:
            self._safe_write("INTAKE", f"MODIFIED_ERR: {ex!r}")

    def _schedule_detect(self, delay_ms: int = 250):
        """Debounce/Scheduler für Detect – cancelt vorherige Jobs sicher."""
        try:
            if getattr(self, "_detect_job", None):
                try:
                    self.after_cancel(self._detect_job)
                except Exception:
                    pass
            self._detect_job = self.after(delay_ms, self._auto_detect_if_needed)
        except Exception as ex:
            self._safe_write("INTAKE", f"SCHED_ERR: {ex!r}")

    def _auto_detect_if_needed(self):
        """Wrapper um _detect mit harter Fehlerbremse und Status-Ping."""
        try:
            self._ping("Auto-Erkennung…")
        except Exception:
            pass
        self._safe_detect()

    def _safe_detect(self):
        """Detect nie direkt aus Events: stets über diesen Wrapper ausführen."""
        try:
            # ältere Implementierungen nutzten _detect() direkt – das bleibt erhalten
            if hasattr(self, "_detect"):
                self._detect()
        except Exception as ex:
            # nicht raisen – nur melden & LED neutral
            self._safe_write("INTAKE", "DETECT_ERR\n" + "".join(__import__("traceback").format_exception(type(ex), ex, ex.__traceback__)))
            try:
                self._update_led(self.led_detect, "yellow")
            except Exception:
                pass
    # --- /Editor-Event-Guards (1123) ----------------------------------------
'''

def inject_or_replace(src: str) -> tuple[str, bool]:
    """
    Sucht die Klasse IntakeFrame und ersetzt/fügt dort die Methoden ein.
    Wir entfernen existierende problematische Implementierungen der vier Handler
    und hängen SNIPPET am Ende der Klasse an (idempotent).
    """
    # IntakeFrame-Klassenblock finden
    cls = re.search(r'(?ms)class\s+IntakeFrame\s*\([^)]*\)\s*:\s*(.*?)\n(?=[^\n]+\nclass\s|\Z)', src)
    if not cls:
        return src, False
    block = cls.group(1)

    # Alte Handler grob entfernen
    def kill(name: str, b: str) -> str:
        pat = rf'\n[ \t]*def[ \t]+{name}\s*\([^)]*\)\s*:[\s\S]*?(?=\n[ \t]*def[ \t]+|\n[ \t]*# ---|^\s*\Z)'
        return re.sub(pat, "\n", b, flags=re.MULTILINE)

    for fn in ("_on_editor_paste", "_on_editor_key", "_on_editor_modified",
               "_schedule_detect", "_auto_detect_if_needed", "_safe_detect",
               "_ensure_editor_bindings", "_safe_write"):
        block = kill(fn, block)

    # SNIPPET nur einmal einfügen
    if "Editor-Event-Guards (1123)" not in block:
        block = block.rstrip() + "\n" + SNIPPET

    # Bindings-Aufruf nach Editor-Erzeugung sicherstellen:
    # wir suchen die Stelle, an der self.txt erstellt wird, und fügen call ein.
    block = re.sub(
        r'(\bself\.txt\s*=\s*tk\.Text\([^)]*\)\s*\n)',
        r'\1        self._detect_job = None\n        self._ensure_editor_bindings()\n',
        block,
        count=1
    )

    new_src = src[:cls.start(1)] + block + src[cls.end(1):]
    return new_src, True

def main() -> None:
    with open(REPORT, "w", encoding="utf-8", newline="\n") as f:
        f.write("Runner_1123_EditorGuardPatch – Start\n")
    if not os.path.exists(P_MOD):
        rep(f"[FEHLER] Datei nicht gefunden: {P_MOD}")
        return
    backup(P_MOD)
    with open(P_MOD, "r", encoding="utf-8") as f:
        src = f.read()

    new_src, changed = inject_or_replace(src)
    if not changed:
        rep("[Hinweis] IntakeFrame nicht gefunden oder bereits gepatcht.")
    with open(P_MOD, "w", encoding="utf-8", newline="\n") as f:
        f.write(new_src)
    rep("[OK] Editor-Guards eingesetzt. Syntaxprüfung folgt…")

    # einfache Syntaxprobe
    try:
        compiled = compile(new_src, P_MOD, "exec")
        rep("[OK] Syntax OK.")
    except Exception as ex:
        rep(f"[FEHLER] Syntax: {ex!r}")
        # Wiederherstellung
        rep("[ROLLBACK] stelle Backup wieder her.")
        with open(P_MOD, "w", encoding="utf-8", newline="\n") as f:
            f.write(src)

if __name__ == "__main__":
    main()
