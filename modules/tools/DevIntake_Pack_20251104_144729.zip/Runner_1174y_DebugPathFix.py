# -*- coding: utf-8 -*-
import re, sys, argparse, py_compile
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True)
    args = ap.parse_args()

    p = Path(args.file)
    src = p.read_text(encoding="utf-8", errors="ignore")

    # Ersetze problematische open("D:\ShrimpDev\debug_output.txt", ...) -> open(r"...", ...)
    # robust auf Spaces/Encodings/utf-8-Varianten
    pat = re.compile(
        r'(with\s+open\(\s*")D:\\ShrimpDev\\debug_output\.txt(")\s*,',
        re.IGNORECASE
    )
    src2 = pat.sub(r'\1r"D:\\ShrimpDev\\debug_output.txt"\2,', src)

    # Zweite Variante: ohne doppelte Backslashes (falls je nach Stelle unescaped)
    pat2 = re.compile(
        r'(with\s+open\(\s*")D:\ShrimpDev\\debug_output\.txt(")\s*,',
        re.IGNORECASE
    )
    src2b = pat2.sub(r'\1r"D:\\ShrimpDev\\debug_output.txt"\2,', src2)

    # Nur schreiben, wenn es etwas zu ändern gab
    if src2b != src:
        tmp = p.with_suffix(p.suffix + ".1174y.tmp")
        tmp.write_text(src2b, encoding="utf-8")
        # Syntax-Prüfung
        py_compile.compile(str(tmp), doraise=True)
        tmp.replace(p)
        print("[1174y] Pfadfix angewendet, Syntax OK.")
    else:
        print("[1174y] Keine Änderung nötig (bereits r-String).")

if __name__ == "__main__":
    try:
        main()
        sys.exit(0)
    except Exception as e:
        print(f"[1174y] Fehler: {e}", file=sys.stderr)
        sys.exit(1)
