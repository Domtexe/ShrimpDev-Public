# -*- coding: utf-8 -*-
"""
Runner_1152_TableUX_Interactions
Mastermodus-konformer Patch:
- Ergänzt IntakeFrame um:
  * _load_selected_into_editor(self)
  * _on_tbl_double_click(self, _evt=None)
- Erweitert Kontextmenü der Tabelle um "In Editor laden"
- Setzt Doppelklick-Binding der Tabelle auf _on_tbl_double_click
- Keine bestehenden Funktionen werden entfernt; alles rückbaubar.

Sicherheit:
- Backup -> Write -> Syntaxcheck -> Headless-Smoke -> Rollback bei Fehler
- Report: _Reports/Runner_1152_TableUX_Interactions_report.txt
"""
from __future__ import annotations
import io, os, sys, time, shutil, ast, importlib.util, types, re, tempfile
from pathlib import Path
import py_compile

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1152_TableUX_Interactions_report.txt"

def w(s=""):
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(s.rstrip()+"\n")
    print(s)

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time()*1000)}.bak"
    shutil.copy2(p, dst)
    return dst

NEW_METHODS = r'''
def _load_selected_into_editor(self):
    """
    Lädt den selektierten Listeneintrag in den Editor und setzt Felder.
    - Liest Dateiinhalt, schreibt in self.txt
    - Setzt self.var_name, self.var_ext, self.var_target
    - Aktualisiert LEDs/Status
    """
    try:
        p = self._path_from_selection_or_fields()
        if not p or not os.path.exists(p):
            self._ping("Kein gültiger Dateipfad."); return
        # Inhalt lesen
        try:
            with open(p, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except Exception as ex:
            self._ping(f"Lesefehler: {ex}")
            return

        # Editor füllen
        try:
            self.txt.delete("1.0","end")
            self.txt.insert("1.0", content)
            self.txt.edit_modified(False)
        except Exception:
            pass

        # Felder setzen
        try:
            folder = os.path.dirname(p)
            base   = os.path.basename(p)
            name, ext = os.path.splitext(base)
            self.var_name.set(name)
            self.var_ext.set(ext or ".txt")
            # Zielordner nur setzen, wenn der Eintrag aus dem Ziel stammt
            if folder:
                self.var_target.set(folder if os.path.isdir(folder) else self.var_target.get())
        except Exception:
            pass

        self._update_led(self.led_detect, "green")
        self._ping(f"Geladen: {os.path.basename(p)}")
    except Exception:
        try: self._ping("Laden fehlgeschlagen.")
        except Exception: pass

def _on_tbl_double_click(self, _evt=None):
    """Doppelklick-Handler: lädt Auswahl in den Editor."""
    try:
        self._load_selected_into_editor()
    except Exception:
        try: self._ping("Doppelklick fehlgeschlagen.")
        except Exception: pass
'''.strip("\n")

def add_or_replace_methods_in_class(src: str, class_name: str, methods_src: str) -> tuple[str, list[str]]:
    """Fügt Methoden in Klassenquelltext ein; ersetzt vorhandene gleichnamige."""
    changed = []
    lines = src.splitlines()
    tree = ast.parse(src)
    cls: ast.ClassDef | None = None
    for n in tree.body:
        if isinstance(n, ast.ClassDef) and n.name == class_name:
            cls = n; break
    if not cls:
        raise RuntimeError(f"class {class_name} nicht gefunden.")

    start = cls.lineno - 1
    end   = getattr(cls, "end_lineno", None) or len(lines)
    cls_src = "\n".join(lines[start:end])

    def upsert_method(csrc: str, fname: str, body_src: str) -> tuple[str, bool]:
        rx = re.compile(r'(?ms)^\s*def\s+'+re.escape(fname)+r'\s*\([^)]*\):\s*(?:\n\s+.+?)(?=^\s*def\s+\w+\s*\(|\Z)')
        if rx.search(csrc):
            return rx.sub("\n    " + body_src.replace("\n","\n    ") + "\n", csrc, count=1), True
        else:
            if not csrc.endswith("\n"): csrc += "\n"
            return csrc + "\n    " + body_src.replace("\n","\n    ") + "\n", False

    # split provided methods into individual defs
    blocks = re.findall(r'(?ms)^def\s+\w+\s*\([^)]*\):\s*(?:\n.+?)(?=^def\s+|\Z)', methods_src)
    for block in blocks:
        mname = re.match(r'^def\s+(\w+)\s*\(', block).group(1)  # type: ignore
        cls_src, rep = upsert_method(cls_src, mname, block)
        changed.append(("replaced" if rep else "added") + ":" + mname)

    new_src = "\n".join(lines[:start]) + ("\n" if start else "") + cls_src + ("\n" if end < len(lines) else "") + "\n".join(lines[end:])
    return new_src, changed

def tweak_bindings_and_menu(src: str) -> tuple[str, list[str]]:
    """Erweitert Listendoppelklick-Binding und Tabellen-Kontextmenü."""
    changes = []
    # 1) Doppelklick-Binding (ersetzen/ergänzen)
    if 'self.tbl.bind("<Double-Button-1>",' in src:
        src = src.replace(
            'self.tbl.bind("<Double-Button-1>", self._dbl_open)',
            'self.tbl.bind("<Double-Button-1>", self._on_tbl_double_click)'
        )
        changes.append("rebind:tbl_doubleclick")
    elif 'self.tbl.bind("<Double-Button-1>"' in src and "_on_tbl_double_click" in src:
        # bereits gesetzt – nichts tun
        pass
    else:
        # an üblicher Stelle nach Tabellenaufbau ergänzen
        src = src.replace(
            'self.tbl.grid(row=0,column=0,sticky="nsew"); y2.grid(row=0,column=1,sticky="ns"); x2.grid(row=1,column=0,sticky="ew")',
            'self.tbl.grid(row=0,column=0,sticky="nsew"); y2.grid(row=0,column=1,sticky="ns"); x2.grid(row=1,column=0,sticky="ew")\n        self.tbl.bind("<Double-Button-1>", self._on_tbl_double_click)'
        )
        changes.append("bind:tbl_doubleclick")

    # 2) Kontextmenü-Eintrag "In Editor laden"
    if "self.menu_tbl" in src and "In Editor laden" not in src:
        src = src.replace(
            'self.menu_tbl.add_command(label="Öffnen im Explorer",  command=self._open_selected)',
            'self.menu_tbl.add_command(label="Öffnen im Explorer",  command=self._open_selected)\n        self.menu_tbl.add_command(label="In Editor laden",      command=self._load_selected_into_editor)'
        )
        changes.append("menu:add_load_to_editor")

    return src, changes

# ---- Live-Test: erzeugt temp-Datei in tools/, lädt sie über Tabelle in Editor
def import_intake_for_test():
    sys.path.insert(0, str(ROOT))
    # Shim für module_runner_exec
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules")
        mod = types.ModuleType("modules.module_runner_exec")
        mod.run = lambda *a, **k: 0
        mod._log = lambda *a, **k: None
        sys.modules.setdefault("modules", pkg)
        sys.modules["modules.module_runner_exec"] = mod

    spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
    m = importlib.util.module_from_spec(spec); assert spec and spec.loader
    spec.loader.exec_module(m)  # type: ignore[attr-defined]
    return m

def headless_probe()->tuple[bool,str]:
    import tkinter as tk
    from pathlib import Path
    # 1) temp runner anlegen
    tools = ROOT / "tools"
    tools.mkdir(exist_ok=True)
    probe = tools / "Runner_99998_TableUX_Probe.py"
    content = "print('table-ux-probe')\n"
    try:
        probe.write_text(content, encoding="utf-8")
    except Exception as e:
        return False, f"Temp-Datei-Error: {e}"

    # 2) Intake instanzieren
    try:
        m = import_intake_for_test()
        root = tk.Tk(); root.withdraw()
        fr = m.IntakeFrame(root)
        # Zielordner setzen & refresh auslösen
        try:
            fr.var_target.set(str(tools))
        except Exception:
            pass
        # Refresh verwenden, wenn vorhanden; sonst _scan_tools/_fill_table
        try:
            fr._on_click_refresh()
        except Exception:
            try:
                rows = fr._scan_tools(str(tools))
                fr._fill_table(rows)
            except Exception as e:
                root.destroy()
                return False, f"Scan/Fill-Error: {e}"

        # 3) Versuchen, den Probe-Eintrag zu selektieren
        found = False
        for iid in fr.tbl.get_children(""):
            vals = fr.tbl.item(iid, "values")
            if len(vals) >= 2 and vals[0] == "Runner_99998_TableUX_Probe" and vals[1] == ".py":
                fr.tbl.selection_set(iid)
                found = True
                break
        if not found:
            root.destroy()
            return False, "Probeeintrag nicht gefunden."

        # 4) Laden in den Editor
        fr._load_selected_into_editor()
        got = fr.txt.get("1.0", "end-1c")
        root.destroy()
        # 5) Cleanup
        try: probe.unlink()
        except Exception: pass

        if "table-ux-probe" in got:
            return True, "Editor-Load OK"
        return False, "Editor-Inhalt weicht ab."
    except Exception as e:
        try: probe.unlink()
        except Exception: pass
        return False, f"Headless-Error: {e}"

def main()->int:
    # Report neu
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass

    w("[R1152] TableUX_Interactions – Start")
    if not MODFILE.exists():
        w(f"[ERR] Datei fehlt: {MODFILE}")
        return 1

    bak = backup(MODFILE); w(f"[Backup] {bak.name}")
    src = io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

    # 1) Methoden hinzufügen/ersetzen
    try:
        src1, changes1 = add_or_replace_methods_in_class(src, "IntakeFrame", NEW_METHODS)
    except Exception as e:
        w(f"[ERR] Patch-Methoden: {e}")
        return 1

    # 2) Bindings & Menü tweaken
    try:
        src2, changes2 = tweak_bindings_and_menu(src1)
    except Exception as e:
        w(f"[ERR] Patch-Bindings: {e}")
        return 1

    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(src2)
    w("[Write] " + ", ".join(changes1 + changes2))

    # Syntaxcheck
    try:
        py_compile.compile(str(MODFILE), doraise=True)
        w("[Syntax] OK")
    except Exception as e:
        w(f"[Syntax] Fehler: {e} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    # Headless-Test
    ok, msg = headless_probe()
    if not ok:
        w(f"[Live] Probe-Fehler: {msg} -> Rollback"); shutil.copy2(bak, MODFILE); return 1
    w(f"[Live] {msg}")

    w("[SUM] Tabelle: Doppelklick & 'In Editor laden' funktionsfähig.")
    w("[R1152] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
