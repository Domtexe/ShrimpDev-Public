"""
Runner_1058_FixKeyAndModified_Block
Repariert den IndentationError bei Zeile ~360, indem der gesamte Block
'_on_editor_key' + '_on_editor_modified' innerhalb von IntakeFrame
kanonisch neu geschrieben wird. Zusätzlich: Tabs->Spaces im Klassenblock.

Version: v9.9.48
"""
from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

CANON_BLOCK = (
    "    def _on_editor_key(self, _evt=None):\n"
    "        \"\"\"Keypress im Editor: leicht verzögert neu erkennen.\"\"\"\n"
    "        self._schedule_detect(250)\n"
    "\n"
    "    def _on_editor_modified(self, _evt=None):\n"
    "        \"\"\"Editor-Änderung: Modified-Flag zurücksetzen und erkennen planen.\"\"\"\n"
    "        try:\n"
    "            self.txt.edit_modified(False)\n"
    "        except Exception:\n"
    "            pass\n"
    "        self._schedule_detect(300)\n"
    "\n"
)

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1058] {ts} {msg}\n")
    except Exception:
        pass

def rd(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def wr_backup(p: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    b = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, b)
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {p} -> {b}")

def patch() -> int:
    src = rd(MOD)

    # 1) Klassenblock IntakeFrame isolieren und Tabs->Spaces
    m = re.search(r"(class\s+IntakeFrame\(ttk\.Frame\):)([\s\S]+)", src)
    if not m:
        log("IntakeFrame-Klasse nicht gefunden.")
        return 1
    head, body = src[:m.start(2)], m.group(2)
    body = body.replace("\t", "    ")

    # 2) Bereich von _on_editor_key bis inkl. _on_editor_modified robust ersetzen
    #    Wir suchen _on_editor_key und schneiden bis VOR die nächste def nach _on_editor_modified
    rgx_key = re.compile(r"\n\s*def\s+_on_editor_key\([^\)]*\):[\s\S]*?", re.MULTILINE)
    m_key = rgx_key.search(body)
    if not m_key:
        log("Anker _on_editor_key nicht gefunden – ich füge Block neu ein (nach _schedule_detect).")
        # Fallback: hinter _schedule_detect einfügen
        anchor = re.search(r"\n\s*def\s+_schedule_detect\([^\)]*\):[\s\S]*?(?=\n\s*def\s+|\Z)", body, re.MULTILINE)
        ins = anchor.end() if anchor else 0
        body = body[:ins] + "\n\n" + CANON_BLOCK + body[ins:]
    else:
        # ab key-begin bis zur nächsten def NACH _on_editor_modified ersetzen
        # finde die Position des Beginns von _on_editor_modified
        m_mod = re.search(r"\n\s*def\s+_on_editor_modified\([^\)]*\):[\s\S]*?", body[m_key.start():], re.MULTILINE)
        if not m_mod:
            # Wenn modified nicht existiert, ersetzen wir ab _on_editor_key bis vor nächste def
            end = re.search(r"(?=\n\s*def\s+|\Z)", body[m_key.end():])
            cut_to = m_key.end() + (end.start() if end else 0)
            body = body[:m_key.start()] + "\n" + CANON_BLOCK + body[cut_to:]
        else:
            # Ende = nächster def-Start nach modified
            after_mod_start = m_key.start() + m_mod.end()
            m_next = re.search(r"\n\s*def\s+", body[after_mod_start:], re.MULTILINE)
            cut_to = after_mod_start + (m_next.start() if m_next else 0)
            body = body[:m_key.start()] + "\n" + CANON_BLOCK + body[cut_to:]

    new_src = head + body
    if new_src != src:
        wr_backup(MOD, new_src)
        # Version & Changelog
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.48\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.48 (2025-10-18)
- Intake: Block _on_editor_key/_on_editor_modified vollständig neu geschrieben (saubere 4-Space-Indent).
""")
        log("Patch angewendet.")
        return 0
    else:
        log("Keine Änderungen nötig.")
        return 0

if __name__ == "__main__":
    raise SystemExit(patch())
