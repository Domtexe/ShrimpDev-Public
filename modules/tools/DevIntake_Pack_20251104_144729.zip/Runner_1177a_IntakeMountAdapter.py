# -*- coding: utf-8 -*-
"""
Runner_1177a_IntakeMountAdapter
Ziel:
- Shim konsolidieren (Adapter + Backcompat)
- main_gui.py so patchen, dass Intake beim Start zuverlässig gemountet wird
- Zentrales Logging in debug_output.txt
"""
from __future__ import annotations
import io, os, re, sys, datetime
from typing import Tuple

ROOT = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
LOGFILE = os.path.join(ROOT, "debug_output.txt")
ARCHIV = os.path.join(ROOT, "_Archiv")

ADAPTER_CODE = r'''# -*- coding: utf-8 -*-
"""
module_shim_intake
R1177a: IntakeShimAdapter mit Rückwärtskompatibilität:
- mount_intake_tab(nb)
- _mount_intake_tab_shim(nb)
- _remount_intake_tab_shim(nb)
"""

from __future__ import annotations
from typing import Optional
import traceback

try:
    import tkinter as tk
    from tkinter import ttk
except Exception:
    # Headless import – Adapter bleibt importierbar
    tk = None
    ttk = None

__all__ = [
    "IntakeShimAdapter",
    "mount_intake_tab",
    "_mount_intake_tab_shim",
    "_remount_intake_tab_shim",
]

def _log(msg: str) -> None:
    try:
        import os, datetime
        root = os.path.abspath(os.path.dirname(__file__))
        root = os.path.abspath(os.path.join(root, ".."))
        logfile = os.path.join(root, "debug_output.txt")
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(logfile, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] {msg}\n")
    except Exception:
        pass

class IntakeShimAdapter:
    """Kapselt den Intake-Mount mit Remount-Erkennung."""
    TAB_TEXT = "Intake"

    def __init__(self) -> None:
        self._last_nb = None

    def _ensure_ttk(self) -> None:
        if ttk is None:
            raise RuntimeError("tk/ttk not available (headless or import error)")

    def _find_existing_tab(self, nb) -> Optional[int]:
        try:
            for idx in range(len(nb.tabs())):
                tab_id = nb.tabs()[idx]
                txt = nb.tab(tab_id, option="text")
                if str(txt).strip().lower() == self.TAB_TEXT.lower():
                    return idx
        except Exception:
            traceback.print_exc()
        return None

    def _build_frame(self, nb):
        frame = ttk.Frame(nb)
        # Minimaler Stub – kann später durch echtes Intake ersetzt werden
        lbl = ttk.Label(frame, text="Intake – bereit", anchor="center", padding=8)
        lbl.pack(fill="both", expand=True)
        return frame

    def mount_intake_tab(self, nb) -> bool:
        """
        Garantiert, dass der Intake-Tab existiert.
        Returns:
            True bei Erfolg, False bei (geloggtem) Fehler.
        """
        try:
            self._ensure_ttk()
            if nb is None:
                raise ValueError("Notebook reference is None")
            idx = self._find_existing_tab(nb)
            if idx is None:
                frame = self._build_frame(nb)
                nb.add(frame, text=self.TAB_TEXT)
                nb.select(frame)
                _log("[1177a] Intake erfolgreich montiert")
            else:
                nb.select(idx)
                _log("[1177a] Intake bereits vorhanden – selektiert (Remount)")
            self._last_nb = nb
            return True
        except Exception as e:
            _log(f"[1177a][ERROR] Intake-Mount fehlgeschlagen: {e}")
            try:
                traceback.print_exc()
            except Exception:
                pass
            return False

    # Alias: alter API-Name
    def _remount_intake_tab_shim(self, nb) -> bool:
        return self.mount_intake_tab(nb)

# Singleton-Adapter
_ADAPTER = IntakeShimAdapter()

# Öffentliche/kompatible Funktionen
def mount_intake_tab(nb) -> bool:
    return _ADAPTER.mount_intake_tab(nb)

def _mount_intake_tab_shim(nb) -> bool:
    # volle Rückwärtskompatibilität
    return _ADAPTER.mount_intake_tab(nb)

def _remount_intake_tab_shim(nb) -> bool:
    return _ADAPTER._remount_intake_tab_shim(nb)
'''

# --------- Utilities ----------

def now_ts() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def stamp() -> str:
    return datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

def log(msg: str) -> None:
    try:
        with open(LOGFILE, "a", encoding="utf-8") as f:
            f.write(f"[{now_ts()}] {msg}\n")
    except Exception:
        pass

def read_text(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def write_text(p: str, s: str) -> None:
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)

def backup(p: str) -> None:
    os.makedirs(ARCHIV, exist_ok=True)
    if os.path.exists(p):
        base = os.path.basename(p)
        dst = os.path.join(ARCHIV, f"{base}.{stamp()}.bak")
        with open(p, "rb") as src, open(dst, "wb") as out:
            out.write(src.read())
        log(f"[R1177a] Backup created: {dst}")

def ensure_adapter_module() -> None:
    """Create/replace modules/module_shim_intake.py with adapter implementation."""
    mod = os.path.join(ROOT, "modules", "module_shim_intake.py")
    os.makedirs(os.path.dirname(mod), exist_ok=True)
    if os.path.exists(mod):
        backup(mod)
    write_text(mod, ADAPTER_CODE)
    log("[R1177a] module_shim_intake.py written (Adapter + Backcompat)")

def patch_main_gui_mount() -> Tuple[bool, str]:
    """
    Insert `_safe_add_intake_tab(nb)` and call it right after the first
    `<name> = ttk.Notebook(` occurrence.
    """
    p = os.path.join(ROOT, "main_gui.py")
    if not os.path.exists(p):
        return (False, "main_gui.py not found")

    src = read_text(p)
    orig = src

    # 1) Ensure helper present
    if "_safe_add_intake_tab(" not in src:
        helper = r'''
def _safe_add_intake_tab(_nb):
    """
    R1177a: Mount Intake-Tab robust mit Logging, ohne UI-Block.
    """
    try:
        from modules.module_shim_intake import mount_intake_tab as _mount
        ok = _mount(_nb)
        if not ok:
            _log("[1177a][WARN] Intake-Mount meldete False")
    except Exception as _e:
        try:
            _log(f"[1177a][ERROR] _safe_add_intake_tab: {_e}")
        except Exception:
            pass
'''
        # Stelle sicher, dass _log existiert oder füge eine leichte Variante ein
        if "_log(" not in src:
            # Minimal-Logger am Datei-Ende anfügen
            src += "\n\ndef _log(msg: str):\n"
            src += "    try:\n"
            src += "        import os, datetime\n"
            src += "        root = os.path.abspath(os.path.dirname(__file__))\n"
            src += "        logfile = os.path.join(root, 'debug_output.txt')\n"
            src += "        ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')\n"
            src += "        with open(logfile, 'a', encoding='utf-8') as f:\n"
            src += "            f.write(f\"[{ts}] {msg}\\n\")\n"
            src += "    except Exception:\n"
            src += "        pass\n"
        src += "\n" + helper

    # 2) Find first Notebook creation
    m = re.search(r"^\s*(\w+)\s*=\s*ttk\.Notebook\s*\(", src, flags=re.M)
    if not m:
        write = (orig != src)
        if write:
            backup(p)
            write_text(p, src)
            return (False, "No ttk.Notebook assignment found; helper injected only")
        return (False, "No ttk.Notebook assignment found")

    nb_var = m.group(1)
    insert_call = f"\ntry:\n    _safe_add_intake_tab({nb_var})\nexcept Exception as _e:\n    _log(f\"[1177a][ERROR] call _safe_add_intake_tab: {_e}\")\n"

    # Insert after the match line
    pos_line_end = src.find("\n", m.end())
    if pos_line_end == -1:
        pos_line_end = len(src)
    src = src[:pos_line_end+1] + insert_call + src[pos_line_end+1:]

    if src != orig:
        backup(p)
        write_text(p, src)
        return (True, f"Inserted _safe_add_intake_tab({nb_var})")
    else:
        return (False, "No changes written")

def main() -> int:
    log("[R1177a] Runner started")
    try:
        ensure_adapter_module()
        ok, msg = patch_main_gui_mount()
        log(f"[R1177a] main_gui.py patch result: {ok} ({msg})")
        log("[R1177a] DONE")
        print("[R1177a] OK:", msg)
        return 0
    except Exception as e:
        log(f"[R1177a][FATAL] {e}")
        print("[R1177a] FAIL:", e, file=sys.stderr)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
