from __future__ import annotations
import os, re
from patchlib_guard import guarded_apply, ensure_import, FileCtx

ROOT = r"D:\ShrimpDev"
MAIN = os.path.join(ROOT, "main_gui.py")

ENTRY_STUB = r'''
def __start_guard():
    try:
        _safe_main()
    except SystemExit:
        raise
    except Exception:
        import traceback
        try:
            with open(r"D:\ShrimpDev\debug_output.txt","a",encoding="utf-8") as f:
                f.write("\n[MAIN_START_ERROR]\n")
                traceback.print_exc(file=f)
        except Exception:
            pass

if __name__ == "__main__":
    __start_guard()
'''

def _transform(ctx: FileCtx):
    src = ctx.modified

    # Sicherstellen, dass tkinter/ttk-Imports weiter oben ggf. nicht kollidieren (keine Änderung hier nötig)
    # Wir kümmern uns nur um den main-Entry.

    has_main_guard = re.search(r'if\s+__name__\s*==\s*["\']__main__["\']\s*:', src) is not None
    calls_safe_main = re.search(r'_safe_main\s*\(', src) is not None

    # Falls es bereits einen __main__-Block gibt, der _safe_main() aufruft: nichts tun.
    if has_main_guard and re.search(r'if\s+__name__\s*==\s*["\']__main__["\']\s*:\s*(?:.*\n)*?.*_safe_main\s*\(', src, re.S):
        ctx.modified = src
        return

    # Falls __main__-Block fehlt oder _safe_main() dort nicht aufgerufen wird:
    # Wir hängen einen sicheren Start-Guard ans Ende an (idempotent).
    if "__start_guard" not in src:
        if not src.endswith("\n"):
            src += "\n"
        src += ENTRY_STUB
        ctx.modified = src
    else:
        # Es gibt schon einen __start_guard (unwahrscheinlich) -> belassen
        ctx.modified = src

ok, msg = guarded_apply(MAIN, _transform)
print(("[1175d] " + (msg or "")).strip())
raise SystemExit(0 if ok else 1)
