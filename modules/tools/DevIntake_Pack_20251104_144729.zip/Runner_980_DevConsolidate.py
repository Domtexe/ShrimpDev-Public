from __future__ import annotations
import os, re, time, shutil
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
TOOLS = ROOT / "tools"
MODS  = ROOT / "modules"
SNIP  = MODS / "snippets"
LOGF  = ROOT / "debug_output.txt"

def log(msg: str):
    try: LOGF.open("a", encoding="utf-8", errors="ignore").write(f"[R980] {msg}\n")
    except Exception: pass
    print(f"[R980] {msg}")

def w(p: Path, s: str, only_if_missing: bool=False):
    p.parent.mkdir(parents=True, exist_ok=True)
    if only_if_missing and p.exists():
        log(f"keep {p.relative_to(ROOT)}")
        return
    p.write_text(s, encoding="utf-8")
    log(f"wrote {p.relative_to(ROOT)}")

def ensure_apply_hook_in(bat_path: Path):
    if not bat_path.exists():
        log(f"skip hook (missing): {bat_path.name}")
        return
    txt = bat_path.read_text(encoding="utf-8", errors="ignore").splitlines()
    mark = "REM [R972] APPLY-PENDING"
    if any(mark in line for line in txt):
        log(f"hook ok: {bat_path.name}")
        return
    out = []
    inserted = False
    for line in txt:
        if (not inserted) and line.strip().lower().startswith(("py -3 -u", "python", "py ")):
            out.append(r"call tools\apply_pending_patches.bat")
            out.append(mark)
            inserted = True
        out.append(line)
    bat_path.write_text("\r\n".join(out) + "\r\n", encoding="utf-8")
    log(f"hook inserted: {bat_path.name}")

def ensure_apply_script():
    ap = TOOLS / "apply_pending_patches.bat"
    if ap.exists():
        log("keep apply_pending_patches.bat")
        return
    w(ap, r"""@echo off
setlocal
cd /d "D:\ShrimpDev"
set PENDING=_Pending
if not exist "%PENDING%" exit /b 0
for /r "%PENDING%" %%F in (*) do (
  set "REL=%%F"
  setlocal enabledelayedexpansion
  set "REL=!REL:D:\ShrimpDev\_Pending\=!"
  for %%# in ("!REL!") do (
    if not exist "D:\ShrimpDev\%%~dp#" mkdir "D:\ShrimpDev\%%~dp#"
    copy /y "%%F" "D:\ShrimpDev\!REL!" >nul
  )
  endlocal
)
for /f "delims=" %%D in ('dir /b /s /ad "%PENDING%" ^| sort /r') do rd "%%D" 2>nul
exit /b 0
""")

def common_tabs_py() -> str:
    return r'''from __future__ import annotations
import tkinter as tk
from tkinter import ttk

def ensure_tab(app: tk.Tk, key: str, title: str, builder):
    """
    Sorgt dafür, dass ein Tab mit Schlüssel `key` existiert (ein Fenster, kein Toplevel).
    """
    if not hasattr(app, "_tab_registry"):
        app._tab_registry = {}
    nb = getattr(app, "nb", None)
    if nb is None:
        # Fallback: Toplevel, falls Notebook fehlt
        win = tk.Toplevel(app); win.title(title)
        frm = builder(win); frm.pack(fill="both", expand=True)
        return True
    if key in app._tab_registry:
        idx = app._tab_registry[key]["index"]
        nb.select(idx); return True
    container = ttk.Frame(nb)
    frame = builder(container)
    frame.pack(fill="both", expand=True)
    nb.add(container, text=title)
    app._tab_registry[key] = {"frame": container, "index": nb.index("end") - 1}
    nb.select(app._tab_registry[key]["index"])
    return True
'''

def code_intake_py() -> str:
    # Verbesserte Erkennung + Override
    return r'''from __future__ import annotations
import re, tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from .common_tabs import ensure_tab

ROOT = Path(r"D:\ShrimpDev")

def _detect_name_ext(code: str) -> tuple[str|None, str|None]:
    """
    Mehrstufige Erkennung (Prioritäten):
    1) Explizite Header/Marker (höchste Priorität)
    2) YAML Front Matter
    3) Fenced Code Block mit Dateiangabe
    4) 'filename=' oder 'file:' in erster Codezeile
    5) Heuristik: Runner_*.py / module_*.py / BAT/CMD
    """
    head = code[:8000]

    # 1) Explizite Markierungen (verschiedene Kommentarstile)
    markers = [
        r"(?im)^\s*(?:#|//|;|REM)\s*(?:file|filename|path)\s*:\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*$",
        r"(?im)^\s*@file\s*:\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*$",
        r"(?im)^\s*#\s*filepath\s*:\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*$",
    ]
    for pat in markers:
        m = re.search(pat, head)
        if m:
            p = Path(m.group("p"))
            return p.name, p.suffix.lower()

    # 2) YAML Front Matter
    m = re.search(r"(?s)^---\s*(.*?)\s*---", head)
    if m:
        y = m.group(1)
        m2 = re.search(r"(?im)^\s*(?:file|filename|path)\s*:\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*$", y)
        if m2:
            p = Path(m2.group("p"))
            return p.name, p.suffix.lower()

    # 3) Fenced Block mit Pfadangabe / filename=
    fenced = [
        r"(?is)^[`\"']{3}[^`\"'\n]*?(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)[^`\"']*?[`\"']{3}",
        r"(?is)^[`\"']{3}[^`\n]*?filename\s*=\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)[^`]*?[`\"']{3}",
    ]
    for pat in fenced:
        m = re.search(pat, head)
        if m:
            p = Path(m.group("p"))
            return p.name, p.suffix.lower()

    # 4) Erste Zeilen mit "file:" / "filename="
    early = re.search(r"(?im)^\s*(?:#|//|;|REM)?\s*(?:file|filename)\s*(?:=|:)\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*$", head[:800])
    if early:
        p = Path(early.group("p"))
        return p.name, p.suffix.lower()

    # 5) Heuristiken
    h = re.search(r"(?i)\b(Runner_[\w\-]+\.(?:py|bat|cmd|vbs))\b", head)
    if h:
        p = Path(h.group(1))
        return p.name, p.suffix.lower()
    h = re.search(r"(?i)\b(module_[\w\-]+\.py)\b", head)
    if h:
        p = Path(h.group(1))
        return p.name, p.suffix.lower()

    return None, None

def _map_target(ws: Path, name: str, ext: str) -> Path:
    n = (name or "").lower()
    if ext == ".py" and n.startswith("runner_"): return ws / "tools"
    if ext in {".bat", ".cmd", ".vbs", ".ps1"}: return ws / "tools"
    if ext == ".py" and n.startswith("module_"): return ws / "modules"
    if ext == ".py": return ws / "modules" / "snippets"
    if ext in {".md", ".json", ".txt"}: return ws
    return ws

def _build_tab(parent):
    frm = ttk.Frame(parent)
    try:
        from modules.config_mgr import load_config, save_config
    except Exception:
        def load_config(): return {"workspace_root": r"D:\ShrimpHub"}
        def save_config(_): pass
    conf = load_config()
    ws = Path(conf.get("workspace_root", r"D:\ShrimpHub"))

    # Workspace
    row = ttk.Frame(frm); row.pack(fill="x", pady=6)
    ttk.Label(row, text="Workspace:").pack(side="left")
    var_ws = tk.StringVar(value=str(ws))
    ttk.Entry(row, textvariable=var_ws, width=60).pack(side="left", padx=6)
    ttk.Button(row, text="…", command=lambda: _pick_ws(var_ws)).pack(side="left")

    # Override-Zeile (Name/Ext/Target)
    bar = ttk.Frame(frm); bar.pack(fill="x", pady=4)
    var_name = tk.StringVar(); var_ext = tk.StringVar(); var_target = tk.StringVar()
    for lbl, var, w in (("Dateiname:", var_name, 40), ("Endung:", var_ext, 8), ("Zielordner:", var_target, 50)):
        ttk.Label(bar, text=lbl).pack(side="left")
        ttk.Entry(bar, textvariable=var, width=w).pack(side="left", padx=6)

    # Editor
    txt = tk.Text(frm, wrap="none", undo=True); txt.pack(fill="both", expand=True)

    # Status + Buttons
    btm = ttk.Frame(frm); btm.pack(fill="x", pady=6)
    status = tk.StringVar(value="Bereit."); ttk.Label(btm, textvariable=status, anchor="w").pack(side="left")
    ttk.Button(btm, text="Erkennen (Ctrl+I)", command=lambda: _detect(txt, var_name, var_ext, var_target, var_ws, status)).pack(side="right", padx=6)
    ttk.Button(btm, text="Speichern (Ctrl+S)", command=lambda: _save(txt, var_name, var_ext, var_target, status)).pack(side="right")

    # Bindings
    frm.bind_all("<Control-i>", lambda e: _detect(txt, var_name, var_ext, var_target, var_ws, status))
    frm.bind_all("<Control-s>", lambda e: _save(txt, var_name, var_ext, var_target, status))

    # Auto-Detect beim Tippen (nicht nervig, nur Felder füllen)
    def _on_mod(_=None):
        txt.edit_modified(0)
        if not var_name.get() or not var_ext.get():
            _detect(txt, var_name, var_ext, var_target, var_ws, status, auto=True)
    txt.bind("<<Modified>>", _on_mod)

    return frm

def _pick_ws(var_ws: tk.StringVar):
    d = filedialog.askdirectory(title="Workspace wählen", initialdir=var_ws.get() or r"D:\ShrimpHub")
    if d: var_ws.set(d)

def _detect(txt, var_name, var_ext, var_target, var_ws, status, auto: bool=False):
    code = txt.get("1.0", "end-1c")
    name, ext = _detect_name_ext(code)
    if name: var_name.set(name)
    if (not ext) and name:
        ext = Path(name).suffix.lower()
    if ext:  var_ext.set(ext)
    nm, ex = var_name.get().strip(), var_ext.get().strip().lower()
    if nm and ex:
        ws = Path(var_ws.get() or r"D:\ShrimpHub")
        var_target.set(str(_map_target(ws, nm, ex)))
    if not auto:
        status.set(f"Erkannt: name={nm!r}, ext={ex!r}, target={var_target.get()!r}")

def _save(txt, var_name, var_ext, var_target, status):
    nm, ex, target = var_name.get().strip(), var_ext.get().strip().lower(), var_target.get().strip()
    code = txt.get("1.0", "end-1c")
    if not nm or not ex or not target:
        messagebox.showwarning("ShrimpDev", "Bitte Name/Endung/Target prüfen."); return
    if not nm.lower().endswith(ex):
        nm = Path(nm).stem + ex
        var_name.set(nm)
    out_dir = Path(target); out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / nm
    # einfache Rotations-Backups
    if out.exists():
        for i in range(4,0,-1):
            pi = out.with_name(out.name + f".{i}.bak"); pj = out.with_name(out.name + f".{i+1}.bak")
            if pi.exists(): pi.replace(pj)
        try: out.with_name(out.name + ".bak").replace(out.with_name(out.name + ".1.bak"))
        except Exception: pass
    out.write_text(code, encoding="utf-8")
    try: messagebox.showinfo("ShrimpDev", f"Gespeichert:\n{out}")
    except Exception: pass
    status.set(f"Gespeichert: {out}")

def open_intake(app: tk.Tk) -> bool:
    try: return ensure_tab(app, "intake", "Code Intake", _build_tab)
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Intake Fehler:\n{ex}")
        except Exception: pass
        return False
'''

def main():
    # 1) Apply-Pending-Mechanik für beide Starter
    ensure_apply_script()
    ensure_apply_hook_in(TOOLS / "start_visible.bat")
    ensure_apply_hook_in(TOOLS / "start_debug.bat")

    # 2) Tab-Helper sicherstellen
    w(MODS / "common_tabs.py", common_tabs_py())

    # 3) Code-Intake ersetzen/aktualisieren (besseres Erkennen + Override)
    w(MODS / "module_code_intake.py", code_intake_py())

    print("[R980] DONE – Hooks gesetzt, Code-Intake verbessert, Tabs bleiben 1-Fenster.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
