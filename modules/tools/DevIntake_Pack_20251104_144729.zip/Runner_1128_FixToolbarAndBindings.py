# -*- coding: utf-8 -*-
"""
Runner_1128_FixToolbarAndBindings
Repariert die konkreten Syntaxfehler im Toolbar-/Binding-Block von modules/module_code_intake.py:
- schließt fehlende Klammer bei btn_guard.grid(...)
- ersetzt die zwei defekten btn_repair-Zeilen durch eine korrekte Definition+Grid (spaltenneutral)
- trennt verklebte bind-Zeilen (F7/F5) in zwei gültige Aufrufe
- bewahrt Einrückung; führt Syntax-Check durch; Rollback bei Fehler
"""

from __future__ import annotations
import re, time, shutil, traceback
from pathlib import Path

ROOT   = Path(__file__).resolve().parents[1]
TARGET = ROOT / "modules" / "module_code_intake.py"
ARCH   = ROOT / "_Archiv"
REPO   = ROOT / "_Reports"
ARCH.mkdir(exist_ok=True); REPO.mkdir(exist_ok=True)
REPORT = REPO / "Runner_1128_FixToolbarAndBindings_report.txt"

def rep(msg: str) -> None:
    with open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip() + "\n")

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time())}.bak"
    shutil.copy2(p, dst)
    rep(f"[Backup] {p} -> {dst}")
    return dst

def fix_source(src: str) -> str:
    s = src

    # 1) btn_guard.grid(...) fehlende schließende Klammer ergänzen
    s = re.sub(
        r'(^[ \t]*self\.btn_guard\.grid\(\s*row=0\s*,\s*column=99\s*,\s*padx=\(6,0\)\s*)(\r?\n)',
        r'\1)\2', s, flags=re.MULTILINE
    )

    # 2) defekte btn_repair-Zeilen (ohne Einrückung/mit Extra-")") entfernen/ersetzen
    #    Wir ersetzen jegliche der folgenden Varianten zwischen Guard.grid und Run.grid:
    #      self.btn_repair = ttk.Button(..._on_click_repair_deep)
    #      self.btn_repair.grid(...))    <- doppel-")"
    #   durch eine saubere, eingerückte Doppellinie (Button + Grid).
    pattern_repair_block = re.compile(
        r'(?ms)'
        r'(^[ \t]*self\.btn_guard\.grid[^\n]*\n)'                # Gruppe 1: guard.grid-Zeile
        r'([ \t]*self\.btn_repair[^\n]*\n[ \t]*self\.btn_repair[^\n]*\)\)?\n)'  # Gruppe 2: defekter Block
    )
    def repl_repair(m):
        guard_line = m.group(1)
        indent = re.match(r'^([ \t]*)', guard_line).group(1)
        fixed = (
            f'{indent}self.btn_repair = ttk.Button(bar, text="Reparieren (F7)", '
            f'command=lambda: self._on_click_repair_deep())\n'
            f'{indent}self.btn_repair.grid(row=0, column=4, padx=(6,0), sticky="w")\n'
        )
        return guard_line + fixed
    s = pattern_repair_block.sub(repl_repair, s)

    # Falls es die defekten Einzelzeilen irgendwo separat gibt: hart bereinigen
    s = re.sub(r'^[ \t]*self\.btn_repair\s*=.*_on_click_repair_deep[^\n]*\n', '', s, flags=re.MULTILINE)
    s = re.sub(r'^[ \t]*self\.btn_repair\.grid\([^\n]*\)\)\s*\n', '', s, flags=re.MULTILINE)

    # 3) verklebte bind-Zeilen trennen:
    #    ...bind("<F7>", ... )self.txt.bind("<F5>", ... )
    s = re.sub(
        r'(^[ \t]*self\.txt\.bind\(\s*"<F7>"\s*,\s*self\._on_click_repair_deep\)\s*)'
        r'(self\.txt\.bind\(\s*"<F5>"\s*,\s*lambda[^\n]*\))',
        r'\1\n        \2', s, flags=re.MULTILINE
    )
    # Variante ohne lambda bei F7: auf lambda vereinheitlichen (Event verwerfen)
    s = re.sub(
        r'(^[ \t]*self\.txt\.bind\(\s*"<F7>"\s*,\s*self\._on_click_repair_deep\s*\))',
        r'        self.txt.bind("<F7>", lambda _e: self._on_click_repair_deep())',
        s, flags=re.MULTILINE
    )
    # Falls F5-Bind fehlt/kaputt: sicherstellen
    if 'self.txt.bind("<F5>"' not in s:
        s = s.replace(
            'self._detect_job = None',
            'self._detect_job = None\n        self.txt.bind("<F5>", lambda _e: self._on_click_run())'
        )

    return s

def main() -> int:
    with open(REPORT, "w", encoding="utf-8", newline="\n") as f:
        f.write("Runner_1128_FixToolbarAndBindings – Start\n")

    if not TARGET.exists():
        rep(f"[FEHLER] Datei fehlt: {TARGET}")
        return 2

    original = TARGET.read_text(encoding="utf-8", errors="ignore")
    backup(TARGET)

    try:
        patched = fix_source(original)
        # Syntaxprobe
        compile(patched, str(TARGET), "exec")
        TARGET.write_text(patched, encoding="utf-8", newline="\n")
        rep("[OK] Patch geschrieben, Syntax OK.")
        return 0
    except Exception as ex:
        rep("[FEHLER] Patch fehlgeschlagen – Rollback.")
        TARGET.write_text(original, encoding="utf-8", newline="\n")
        rep("TRACE:\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
