"""
Runner_1045_NameForceAndDateCols
- Erzwingt Auto-Detect: _auto_detect_if_needed() ruft immer _detect() (respektiert var_name_manual).
- _on_editor_paste / _on_editor_key triggern _detect() direkt (ohne nur zu schedulen).
- _detect(): Übernimmt gefundenen Namen IMMER, wenn var_name_manual==False.
- Tabelle: neue Spalten 'date' (YYYY-MM-DD) und 'time' (HH:MM:SS).
- Version v9.9.35
"""
from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1045] {ts} {msg}\n")
    except Exception:
        pass

def backup_write(path: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

def patch() -> int:
    with open(MOD, "r", encoding="utf-8") as f:
        src = f.read()

    changed = False

    # 1) _auto_detect_if_needed: immer _detect() starten
    src2 = re.sub(
        r"def\s+_auto_detect_if_needed\([\s\S]+?def\s+_save\(",
        lambda m: (
            m.group(0)
            .replace(
                # ersetze die Bedingung durch bedingungslose Erkennung
                "name_empty = not (self.var_name.get() or \"\").strip()\n            if name_empty or not self.var_ext_manual:\n                self._ping(\"Auto-Erkennung…\")\n                self._detect()",
                "self._ping(\"Auto-Erkennung…\")\n            self._detect()"
            )
        ),
        src,
        count=1,
        flags=re.MULTILINE
    )
    if src2 != src:
        src = src2
        changed = True

    # 2) _on_editor_paste / _on_editor_key: direkt _detect()
    src2 = re.sub(
        r"def\s+_on_editor_paste\([^\)]*\):[\s\S]+?def\s+_on_editor_key\(",
        "def _on_editor_paste(self, _evt=None):\n        self._ping(\"Auto-Erkennung…\")\n        self._detect()\n\n    def _on_editor_key(self, _evt=None):\n        self._ping(\"Auto-Erkennung…\")\n        self._detect()\n\n    def _on_editor_key(",
        src,
        count=1,
        flags=re.MULTILINE
    )
    if src2 != src:
        src = src2
        changed = True

    # 3) _detect(): Name-Übernahme klarstellen (nur wenn nicht manuell)
    src2 = re.sub(
        r"if not self\.var_name_manual:\s*\n\s*nm_guess,\s*ext_guess\s*=\s*self\._guess_name_from_text\(content\)\s*\n\s*if nm_guess:\s*\n\s*self\.var_name\.set\([^\n]+\)\s*\n\s*if not self\.var_ext_manual and not ext:\s*\n\s*ext\s*=\s*\(ext_guess or \"\"\)\.lower\(\)",
        "if not self.var_name_manual:\n            nm_guess, ext_guess = self._guess_name_from_text(content)\n            if nm_guess:\n                # Name wird gesetzt (solange nicht manuell editiert)\n                self.var_name.set(nm_guess + (ext_guess or \"\"))\n                if not self.var_ext_manual and not ext:\n                    ext = (ext_guess or \"\").lower()",
        src,
        count=1,
        flags=re.MULTILINE
    )
    if src2 != src:
        src = src2
        changed = True

    # 4) Tabelle: Spalten erweitern (name, ext, subfolder, date, time)
    #    4a) columns-Definition
    src2 = re.sub(
        r'cols\s*=\s*\(\s*"name"\s*,\s*"ext"\s*,\s*"subfolder"\s*\)',
        'cols = ("name","ext","subfolder","date","time")',
        src
    )
    if src2 != src:
        src = src2
        changed = True

    #    4b) heading/column-Setup (füge zwei Zeilen für date/time ein)
    src2 = re.sub(
        r'for c,\s*w,\s*a in \(\("name",\s*240,\s*"w"\),\("ext",\s*70,\s*"center"\),\("subfolder",\s*180,\s*"w"\)\):\s*\n\s*self\.tbl\.heading\(c,\s*text=c\);\s*self\.tbl\.column\(c,\s*anchor=a,\s*width=w,\s*stretch=\(c\!=\\"ext\\"\)\)',
        (
            'for c,w,a in (("name",240,"w"),("ext",70,"center"),("subfolder",180,"w"),("date",110,"center"),("time",90,"center")):\n'
            '            self.tbl.heading(c, text=c); self.tbl.column(c, anchor=a, width=w, stretch=(c!="ext"))'
        ),
        src
    )
    if src2 != src:
        src = src2
        changed = True

    #    4c) _load_table(): Datum/Uhrzeit berechnen und einfügen
    load_pat = re.compile(r"def\s+_load_table\([\s\S]+?for p in entries:\s*\n\s*base\s*=\s*os\.path\.basename\(p\)[\s\S]+?self\.tbl\.insert\(\"\", \"end\", values=\([^\)]*\)\)\s*", re.MULTILINE)
    m = load_pat.search(src)
    if m:
        block = m.group(0)
        if "strftime" not in block:
            block = re.sub(
                r"self\.tbl\.insert\(\"\", \"end\", values=\((name,\s*(\(ext or \"\"\)\.lower\(\)),\s*sub)\)\)",
                '                # Datum/Uhrzeit\n                try:\n                    ts = os.path.getmtime(p)\n                    dt = time.strftime("%Y-%m-%d", time.localtime(ts))\n                    tm = time.strftime("%H:%M:%S", time.localtime(ts))\n                except Exception:\n                    dt, tm = "", ""\n                self.tbl.insert("", "end", values=(name, (ext or "").lower(), sub, dt, tm))',
                block
            )
            src = src[:m.start()] + block + src[m.end():]
            changed = True

    if changed:
        backup_write(MOD, src)
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.35\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.35 (2025-10-18)
- Auto-Detect erzwingt _detect() nach Paste/Key/Start; Name wird gesetzt, solange nicht manuell editiert.
- Rechte Liste: zusätzliche Spalten 'date' und 'time' (Datei-Änderungszeit).
""")
        log("Patch angewendet.")
        return 0
    else:
        log("Keine Änderungen nötig.")
        return 0

if __name__ == "__main__":
    raise SystemExit(patch())
