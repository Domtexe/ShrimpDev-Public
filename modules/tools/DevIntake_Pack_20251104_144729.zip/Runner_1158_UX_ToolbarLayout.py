# -*- coding: utf-8 -*-
"""
Runner_1158_UX_ToolbarLayout
- Schiebt "Editor leeren" in der Intake-Toolbar ganz nach links (column=0).
- Verschiebt links stehende Kern-Buttons ("Ziel", "Erkennung", "Speichern", "Speichern (Ctrl+S)", "Löschen (Entf)")
  jeweils eine Spalte nach rechts, falls sie aktuell column=0 waren.
- Lässt Event-Handler/Kommandos unverändert.
- Safety: Backup in _Archiv/, Syntax-Check via py_compile, Logging nach debug_output.txt
"""
from __future__ import annotations
import os, re, io, time, shutil, py_compile, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOGF = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    line  = f"[R1158] {stamp} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    ts = str(int(time.time()))
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    shutil.copy2(path, dst)
    log(f"Backup: {path} -> {dst}")
    return dst

# --- Grid-Patcher --------------------------------------------------------------

BTN_EDITOR_LEEREN = r"Editor\s*leeren"
BTN_LEFT_GROUP = [
    r"Ziel\b",
    r"Erkennung\b",
    r"Speichern\s*\(Ctrl\+S\)",  # Tastaturhinweis-Button
    r"Speichern\b",               # ggf. zweiter Save-Button
    r"Löschen\s*\(Entf\)",
]

# findet Button-Zeilen mit text="..."; erlaubt Aufrufketten .grid(...) in gleicher Zeile
RE_BTN_LINE = re.compile(
    r"""(?P<prefix>\s*ttk\.Button\([^\n]*?\btext\s*=\s*["'](?P<label>[^"']+)["'][^\n]*?\))
        (?P<tail>[^\n]*?)$""",
    re.X
)

RE_GRID = re.compile(r"""\.grid\(\s*(?P<args>[^\)]*)\)""")
RE_COL  = re.compile(r"""\bcolumn\s*=\s*(?P<val>\d+)""")

def _ensure_column_in_args(args: str, new_col: int) -> str:
    """Setzt column=new_col (ersetzen oder hinzufügen)."""
    if RE_COL.search(args):
        return RE_COL.sub(lambda m: f"column={new_col}", args, count=1)
    if args.strip():
        return args.strip() + f", column={new_col}"
    return f"column={new_col}"

def _shift_column_in_args(args: str, delta: int) -> str:
    """Erhöht column-Wert um delta, falls vorhanden; andernfalls fügt column=(0+delta) an."""
    m = RE_COL.search(args)
    if m:
        val = int(m.group("val"))
        return RE_COL.sub(lambda _m: f"column={val + delta}", args, count=1)
    # kein column vorhanden: wir nehmen an, column=0 und shiften
    if args.strip():
        return args.strip() + f", column={0 + delta}"
    return f"column={0 + delta}"

def _regrid_line_for_editor_left(line: str) -> tuple[str, bool, bool]:
    """
    Verschiebt 'Editor leeren' -> column=0.
    Verschiebt definierte Left-Group-Buttons um +1, wenn sie column=0 sind (oder nicht gesetzt).
    Gibt (newline, changed, matched_any) zurück.
    """
    m = RE_BTN_LINE.match(line)
    if not m:
        return line, False, False

    label = m.group("label")
    prefix, tail = m.group("prefix"), m.group("tail")
    changed = False
    matched_any = False

    # Alle .grid()-Aufrufe in der Zeile patchen (typisch: genau einer)
    def patch_grid_args(args: str, set_col: int | None = None, shift_if_zero: bool = False):
        nonlocal changed
        if set_col is not None:
            new_args = _ensure_column_in_args(args, new_col=set_col)
            if new_args != args:
                changed = True
            return new_args
        if shift_if_zero:
            # nur shiften, wenn column==0 oder nicht vorhanden
            cm = RE_COL.search(args)
            if cm:
                cval = int(cm.group("val"))
                if cval == 0:
                    new_args = _shift_column_in_args(args, delta=1)
                    if new_args != args:
                        changed = True
                    return new_args
                # column != 0 → nichts ändern
                return args
            else:
                # kein column -> wir interpretieren als 0
                new_args = _shift_column_in_args(args, delta=1)
                if new_args != args:
                    changed = True
                return new_args
        return args

    # Editor leeren?
    if re.fullmatch(BTN_EDITOR_LEEREN, label.strip(), flags=0):
        matched_any = True
        def repl_grid(mg: re.Match) -> str:
            new_args = patch_grid_args(mg.group("args"), set_col=0)
            return f".grid({new_args})"
        newline = RE_GRID.sub(repl_grid, prefix + tail)
        return newline, changed, matched_any

    # Left-Group?
    for pat in BTN_LEFT_GROUP:
        if re.fullmatch(pat, label.strip()):
            matched_any = True
            def repl_grid(mg: re.Match) -> str:
                new_args = patch_grid_args(mg.group("args"), set_col=None, shift_if_zero=True)
                return f".grid({new_args})"
            newline = RE_GRID.sub(repl_grid, prefix + tail)
            return newline, changed, matched_any

    # kein Zielbutton
    return line, False, False

def patch_toolbar(src: str) -> tuple[str, list[str]]:
    changes: list[str] = []
    out_lines = []
    changed_any = False
    matched = 0
    edited = 0

    for ln in src.splitlines(True):
        newln, chg, hit = _regrid_line_for_editor_left(ln)
        if hit: matched += 1
        if chg:
            edited += 1
            changed_any = True
        out_lines.append(newln)

    if changed_any:
        if edited:
            changes.append(f"Toolbar layout adjusted: {edited} grid() calls updated (Editor left, others shifted)")
    else:
        if matched:
            changes.append("Toolbar already in desired layout (no changes)")
        else:
            changes.append("No matching toolbar buttons found (labels differ?)")

    return "".join(out_lines), changes

# --- main ----------------------------------------------------------------------

def main() -> int:
    try:
        if not os.path.isfile(MOD):
            log(f"[ERR] Not found: {MOD}")
            return 2

        with io.open(MOD, "r", encoding="utf-8") as f:
            src = f.read()

        bak = backup(MOD)

        new_src, changes = patch_toolbar(src)

        # Schreiben nur, wenn tatsächlich modifiziert
        if "updated" in " ".join(changes):
            with io.open(MOD, "w", encoding="utf-8", newline="\n") as f:
                f.write(new_src)
            for c in changes:
                log(f"Change: {c}")
        else:
            for c in changes:
                log(f"Info: {c}")

        # Syntax-Check
        try:
            py_compile.compile(MOD, doraise=True)
            log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}")
            shutil.copy2(bak, MOD)
            log("Restored from backup due to syntax error.")
            return 3

        log("R1158 completed successfully.")
        return 0

    except Exception as e:
        tb = traceback.format_exc()
        log(f"[EXC] {e}\n{tb}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
