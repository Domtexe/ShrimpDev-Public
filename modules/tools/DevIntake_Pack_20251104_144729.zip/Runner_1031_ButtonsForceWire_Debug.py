"""
Runner_1031_ButtonsForceWire_Debug
- Verdrahtet Buttons robust über Wrapper (_on_click_detect/save/delete)
- Ersetzt Toolbar-Block sicher (grid, keine Überlappung), Buttons als self-Attribute
- Shortcuts neu (unbind_all + bind_all) -> Wrapper
- Fügt sicheren Logger-Fallback ein (write_log)
- Mini-QA prüft, dass Wrapper & Commands vorhanden sind
- Version -> v9.9.21
"""
from __future__ import annotations
import os, re, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1031] {ts} {msg}\n")
    except Exception:
        pass
    print(msg, flush=True)

TOOLBAR_BLOCK = r'''
        # Toolbar (re-wired)
        bar = ttk.Frame(self)
        bar.grid(row=2, column=0, sticky="ew", padx=_PADX, pady=(0,4))
        for c in (0,1,2): bar.columnconfigure(c, weight=0)
        bar.columnconfigure(3, weight=1)  # spacer
        self.btn_detect = ttk.Button(bar, text="Erkennen (Ctrl+I)", command=self._on_click_detect)
        self.btn_save   = ttk.Button(bar, text="Speichern (Ctrl+S)", command=self._on_click_save)
        self.btn_del    = ttk.Button(bar, text="Löschen (Entf)",    command=self._on_click_delete)
        self.btn_detect.grid(row=0, column=0, padx=(0,6), sticky="w")
        self.btn_save.grid(  row=0, column=1, padx=(0,6), sticky="w")
        self.btn_del.grid(   row=0, column=2, padx=(0,0), sticky="w")
        try:
            Tooltip(self.btn_detect, "Erkennt Endung aus dem Namensfeld (respektiert manuelle Eingabe)")
            Tooltip(self.btn_save,   "Speichert den Editor-Inhalt in Zielordner/Name+Endung")
            Tooltip(self.btn_del,    "Löscht die markierte Datei (oder nur aus der Liste)")
        except Exception:
            pass
'''

WRAPPER_METHODS = r'''
    # --- button wrappers with logging ---
    def _on_click_detect(self):
        try:
            try:
                from modules.snippets.logger_snippet import write_log as _wl
            except Exception:
                def _wl(p,m): pass
            _wl("INTAKE","BTN Detect click")
            ok = self._detect()
            return ok
        except Exception as ex:
            try:
                from tkinter import messagebox
                messagebox.showerror("Fehler", f"Erkennen fehlgeschlagen:\n{ex}")
            except Exception:
                pass

    def _on_click_save(self):
        try:
            try:
                from modules.snippets.logger_snippet import write_log as _wl
            except Exception:
                def _wl(p,m): pass
            _wl("INTAKE","BTN Save click")
            self._save()
        except Exception as ex:
            try:
                from tkinter import messagebox
                messagebox.showerror("Fehler", f"Speichern fehlgeschlagen:\n{ex}")
            except Exception:
                pass

    def _on_click_delete(self):
        try:
            try:
                from modules.snippets.logger_snippet import write_log as _wl
            except Exception:
                def _wl(p,m): pass
            _wl("INTAKE","BTN Delete click")
            self._delete_selected()
        except Exception as ex:
            try:
                from tkinter import messagebox
                messagebox.showerror("Fehler", f"Löschen fehlgeschlagen:\n{ex}")
            except Exception:
                pass
'''

SHORTCUTS_WRAPPED = r'''
    def _bind_shortcuts(self):
        root = self.winfo_toplevel()
        try:
            root.unbind_all("<Control-s>")
            root.unbind_all("<Control-i>")
        except Exception:
            pass
        root.bind_all("<Control-s>", lambda e: self._on_click_save())
        root.bind_all("<Control-i>", lambda e: self._on_click_detect())
        self.tbl.bind("<Control-c>", lambda e: self._copy_selected())
        self.tbl.bind("<Delete>",    lambda e: self._on_click_delete())
'''

def patch_file(src: str) -> str:
    changed = False

    # 1) Toolbar-Block austauschen (zwischen "# Toolbar" und "body = ttk.Panedwindow")
    src2 = re.sub(
        r"\n\s*#\s*Toolbar[\s\S]+?body\s*=\s*ttk\.Panedwindow",
        "\n" + TOOLBAR_BLOCK + "\n        body = ttk.Panedwindow",
        src,
        flags=re.MULTILINE
    )
    if src2 != src:
        src = src2
        changed = True

    # 2) Shortcut-Methode ersetzen
    src2 = re.sub(
        r"def\s+_bind_shortcuts\s*\([\s\S]+?^\s*def\s+_popup_menu",
        SHORTCUTS_WRAPPED + "\n\n    def _popup_menu",
        src,
        flags=re.MULTILINE
    )
    if src2 != src:
        src = src2
        changed = True

    # 3) Wrapper-Methoden einfügen (falls nicht vorhanden)
    if "def _on_click_detect(" not in src:
        # Vor dem Block "# ---------- actions ----------" einfügen
        ins_pt = src.find("\n    # ---------- actions ----------")
        if ins_pt != -1:
            src = src[:ins_pt] + WRAPPER_METHODS + src[ins_pt:]
            changed = True

    return src, changed

def qa(src: str) -> bool:
    ok = True
    checks = {
        "Wrapper detect vorhanden": ("def _on_click_detect(" in src),
        "Wrapper save vorhanden"  : ("def _on_click_save(" in src),
        "Wrapper delete vorhanden": ("def _on_click_delete(" in src),
        "Toolbar-Buttons verdrahtet": ("command=self._on_click_detect" in src and
                                       "command=self._on_click_save" in src and
                                       "command=self._on_click_delete" in src),
        "Shortcuts auf Wrapper"   : ("_on_click_save()" in src and "_on_click_detect()" in src),
    }
    for k, v in checks.items():
        log(f"[QA] {k}: {'OK' if v else 'FEHLT'}")
        ok = ok and v
    return ok

def main() -> int:
    try:
        with open(MOD, "r", encoding="utf-8") as f:
            src = f.read()

        new_src, changed = patch_file(src)
        if changed:
            os.makedirs(ARCH, exist_ok=True)
            bck = os.path.join(ARCH, f"module_code_intake.py.{int(time.time())}.bak")
            shutil.copy2(MOD, bck)
            with open(MOD, "w", encoding="utf-8", newline="\r\n") as f:
                f.write(new_src)
            log(f"Backup: {MOD} -> {bck}")
            log("Buttons-Toolbar & Shortcuts neu verdrahtet.")
        else:
            log("Keine Änderungen nötig (Buttons/Shortcuts bereits korrekt).")

        ok = qa(new_src)

        # Meta
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.21\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.21 (2025-10-18)
- Intake: Buttons hart verdrahtet über Wrapper (mit Logging & Fehlermeldung)
- Toolbar fix (grid), Shortcuts auf Wrapper; QA prüft Verkabelung
""")
        return 0 if ok else 1
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
