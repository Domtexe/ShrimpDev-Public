# -*- coding: utf-8 -*-
"""
Runner_1113_DeepRepair_FixReturnScope.py
- Korrigiert fehlerhaft eingefügte __auto_fix_return__-Wrapper
- Fix "return outside function" NUR auf echtem Top-Level (Tiefe 0)
- Rest identisch zu R1112 (Normalisieren, Future hoisten, IntakeFrame reindenten, lonely try)
"""

from __future__ import annotations
import os, re, io, time, ast, shutil, sys

ROOT = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
ARCH = os.path.join(ROOT, "_Archiv")
MODS = os.path.join(ROOT, "modules")
TARGETS = [os.path.join(MODS, "module_code_intake.py"),
           os.path.join(ROOT, "main_gui.py")]

def log(msg): print(f"[R1113] {msg}")

def backup(path):
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bak)
    log(f"Backup: {path} -> {bak}"); return bak

def rd(path):
    with open(path, "rb") as f:
        b=f.read()
    try: return b.decode("utf-8")
    except UnicodeDecodeError: return b.decode("latin-1", errors="replace")

def wr(path, s):
    with open(path, "w", encoding="utf-8", newline="\n") as f: f.write(s)

def normalize(s:str)->str:
    s=s.replace("\r\n","\n").replace("\r","\n").replace("\t","    ")
    s="\n".join(l.rstrip() for l in s.split("\n"))
    return s

def split_head_for_future(s:str):
    i=0; lines=s.split("\n"); head=[]
    if i<len(lines) and lines[i].startswith("#!"): head.append(lines[i]); i+=1
    if i<len(lines) and re.match(r"^#\s*-\*-\s*coding:", lines[i]): head.append(lines[i]); i+=1
    while i<len(lines) and lines[i].strip()=="":
        head.append(lines[i]); i+=1
    if i<len(lines) and re.match(r"^\s*[ru]?['\"]{3}", lines[i]):
        head.append(lines[i]); i+=1
        while i<len(lines) and not lines[i].strip().endswith('"""') and not lines[i].strip().endswith("'''"):
            head.append(lines[i]); i+=1
        if i<len(lines): head.append(lines[i]); i+=1
    return "\n".join(head), "\n".join(lines[i:])

def hoist_future(s:str)->str:
    head, body = split_head_for_future(s)
    fut=[]; rest=[]
    for ln in body.split("\n"):
        if re.match(r"^\s*from\s+__future__\s+import\s+", ln): fut.append(ln.strip())
        else: rest.append(ln)
    if not fut: return s
    return head.rstrip("\n")+"\n"+"\n".join(fut)+"\n"+"\n".join(rest)

def reindent_class(s:str, klass="IntakeFrame")->str:
    lines=s.split("\n"); out=[]; i=0
    while i<len(lines):
        ln=lines[i]; m=re.match(rf"^(\s*)class\s+{klass}\b.*:\s*$", ln)
        if not m: out.append(ln); i+=1; continue
        base=len(m.group(1)); out.append(ln); i+=1
        blk=[]
        while i<len(lines):
            l2=lines[i]; ind=len(l2)-len(l2.lstrip())
            if l2.strip()=="":
                blk.append(l2); i+=1; continue
            if ind<=base and not l2.lstrip().startswith("#"): break
            if ind<=base and l2.strip():
                l2=" "*(base+4)+l2.lstrip()
            elif ind==base:
                l2=" "*(base+4)+l2.lstrip()
            blk.append(l2); i+=1
        out.extend(blk)
    return "\n".join(out)

def fix_lonely_try(s:str)->str:
    lines=s.split("\n"); out=[]; i=0
    while i<len(lines):
        ln=lines[i]; out.append(ln)
        if re.match(r"^\s*try:\s*$", ln):
            indent=len(ln)-len(ln.lstrip()); j=i+1; ok=False
            while j<len(lines):
                l2=lines[j]
                if l2.strip()=="": j+=1; continue
                ind2=len(l2)-len(l2.lstrip())
                if ind2<indent: break
                if ind2==indent and re.match(r"^\s*(except|finally)\b", l2):
                    ok=True; break
                j+=1
            if not ok:
                out.append(" "*indent+"except Exception:")
                out.append(" "*(indent+4)+"pass")
        i+=1
    return "\n".join(out)

# --- NEU: Cleanup für fälschlich eingefügte __auto_fix_return__-Wrapper
def cleanup_auto_fix_return_wrappers(s:str)->str:
    pat = re.compile(r"^(\s*)def\s+__auto_fix_return__\s*\(\)\s*:\s*\n\1    return\s*$", re.M)
    # mehrfach ersetzen, falls mehrfach vorhanden
    while True:
        m = pat.search(s)
        if not m: break
        indent = m.group(1)
        s = s[:m.start()] + indent + "return" + s[m.end():]
    return s

# --- NEU: Top-Level-Return nur auf Tiefe 0 anfassen
def fix_top_level_return_only(s:str)->str:
    lines = s.split("\n")
    out = []
    stack = []  # [(indent, type)]
    for idx, ln in enumerate(lines):
        stripped = ln.lstrip()
        indent = len(ln) - len(stripped)

        # Stack pflegen: bei geringerer Einrückung Blöcke schließen
        while stack and indent <= stack[-1][0]:
            stack.pop()

        # Neue Blöcke?
        if re.match(r"^\s*(class|def)\b", ln):
            stack.append((indent, "block"))

        # Nur auf Top-Level (kein offener Block) reagieren
        if stripped.startswith("return") and not stack and indent == 0:
            out.append("def __auto_fix_return__():")
            out.append("    " + stripped)
        else:
            out.append(ln)
    return "\n".join(out)

def sanity(src:str, hint:str):
    try:
        ast.parse(src, filename=hint)
        return True, ""
    except SyntaxError as ex:
        ctx_lines = src.split("\n")
        start = max(1, (ex.lineno or 1)-5)
        ctx = "\n".join(f"{n:04d}: {ctx_lines[n-1]}" for n in range(start, min(len(ctx_lines), start+10)))
        return False, f"{ex.__class__.__name__}: {ex} (line {ex.lineno})\n--- context ---\n{ctx}"

def process(path:str)->bool:
    if not os.path.exists(path):
        log(f"SKIP: {path} fehlt."); return False
    src0 = rd(path)
    s = normalize(src0)
    s = hoist_future(s)
    if os.path.basename(path)=="module_code_intake.py":
        s = reindent_class(s, "IntakeFrame")
    s = fix_lonely_try(s)
    s = cleanup_auto_fix_return_wrappers(s)          # <- zuerst aufräumen
    s = fix_top_level_return_only(s)                 # <- dann korrekt neu anwenden

    ok, why = sanity(s, path)
    if not ok:
        log(f"Sanity-Check FEHLGESCHLAGEN – Datei wurde NICHT überschrieben.\n{why}")
        return False

    if s != src0:
        backup(path)
        wr(path, s)
        log(f"Repariert & gespeichert: {path}")
    else:
        log("Keine Änderungen nötig. Syntax OK.")
    return True

if __name__=="__main__":
    ok_all=True
    for p in TARGETS:
        log(f"== Repariere: {p}")
        ok_all = process(p) and ok_all
    sys.exit(0 if ok_all else 1)
