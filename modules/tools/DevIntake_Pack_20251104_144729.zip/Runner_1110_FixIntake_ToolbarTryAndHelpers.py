# -*- coding: utf-8 -*-
"""
Runner_1110_FixIntake_ToolbarTryAndHelpers.py
- Repariert try/try-Dopplungen durch eingeschobenes 'except ... pass'
- Erzwingt, dass der Guard-Button im 'bar'-Container erzeugt wird
- Ergänzt F5-Binding für Run
- Ergänzt fehlende Helper (_open_selected, _copy_selected, _copy_name_selected, _dbl_open)
Idempotent: wiederholtes Ausführen macht nichts kaputt.
"""
from __future__ import annotations
import os, re, sys, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    ts = int(time.time())
    bak = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    with open(path, "rb") as r, open(bak, "wb") as w:
        w.write(r.read())
    print(f"[R1110] Backup: {path} -> {bak}")
    return bak

def read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8", newline="") as f:
        return f.read()

def write_text(path: str, s: str) -> None:
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(s)

def sanity_compile(src: str) -> None:
    compile(src, MOD, "exec")

def fix_double_try(src: str) -> tuple[str, int]:
    """
    Sucht Stellen, an denen auf derselben Einrückungsebene direkt zwei 'try:'-Zeilen
    hintereinander stehen, und schiebt davor ein 'except Exception: pass' ein.
    """
    lines = src.splitlines(True)
    changed = 0
    i = 0
    while i < len(lines)-1:
        L = lines[i]
        if L.lstrip().startswith("try:"):
            indent = L[:len(L)-len(L.lstrip())]
            # suche nächste nicht-leere Zeile (Kommentare erlauben)
            j = i + 1
            while j < len(lines) and lines[j].strip() == "":
                j += 1
            if j < len(lines):
                nxt = lines[j]
                # gleiche Einrückung und wieder 'try:'
                if nxt.startswith(indent) and nxt.strip().startswith("try:"):
                    inject = f"{indent}except Exception:\n{indent}    pass\n"
                    lines.insert(j, inject)
                    changed += 1
                    i = j + 1
                    continue
        i += 1
    return ("".join(lines), changed)

def fix_guard_parent(src: str) -> tuple[str, int]:
    """
    Sorgt dafür, dass der Guard-Button an 'bar' hängt.
    Ersetzt in ttk.Button(XXX, text="Prüfen...|Guard...", ...) das erste Argument durch 'bar'.
    """
    pat = re.compile(
        r'(ttk\.Button\()\s*([A-Za-z_]\w*)\s*,\s*(text\s*=\s*"(?:Prüfen|Guard)[^"]*")',
        re.U
    )
    def repl(m):
        return f"{m.group(1)}bar, {m.group(3)}"
    new, n = pat.subn(repl, src)
    return new, n

def ensure_f5_binding(src: str) -> tuple[str, bool]:
    if "<F5>" in src:
        return src, False
    # nach Erzeugung von self.txt einfügen
    pat = re.compile(r'^(?P<indent>\s*)self\.txt\b.*$', re.M)
    m = pat.search(src)
    if not m:
        return src, False
    indent = m.group("indent")
    insert_line = f'{indent}self.txt.bind("<F5>", lambda _e: self._on_click_run())\n'
    # nur einmal
    head = src[:m.end()]
    tail = src[m.end():]
    return head + "\n" + insert_line + tail, True

def _find_class_block(src: str, cls_name: str) -> tuple[int, int, str]:
    """
    Liefert (start_idx, end_idx, indent) für den Klassenblock.
    end_idx zeigt auf den Beginn der nächsten Klasse auf Spalte 0 oder EOF.
    """
    m = re.search(rf'^(class\s+{cls_name}\b[^\n]*:\s*)$', src, re.M)
    if not m:
        return -1, -1, ""
    start = m.start()
    # Einrückung innerhalb der Klasse sind mind. 4 Spaces;
    # Ende der Klasse = nächste 'class ' am Zeilenanfang oder EOF
    m2 = re.search(r'^\s*class\s+\w+', src[m.end():], re.M)
    end = len(src) if not m2 else m.end() + m2.start()
    return start, end, "    "

HELPERS = """
{I}def _open_selected(self):
{I}    \"\"\"Öffnet den selektierten Pfad im Explorer (falls ermittelbar).\"\"\"
{I}    try:
{I}        p = None
{I}        if hasattr(self, "_path_from_selection_or_fields"):
{I}            p = self._path_from_selection_or_fields()
{I}        if not p and hasattr(self, "tbl") and self.tbl.selection():
{I}            iid = self.tbl.selection()[0]
{I}            vals = self.tbl.item(iid, "values") or []
{I}            if vals:
{I}                # name/ext/subfolder -> Pfad bestmöglich ableiten, sofern var_target existiert
{I}                base = ""
{I}                if hasattr(self, "var_target"):
{I}                    try:
{I}                        base = self.var_target.get()
{I}                    except Exception:
{I}                        base = ""
{I}                cand = vals[0] + (vals[1] if len(vals) > 1 else "")
{I}                import os
{I}                p = os.path.join(base, cand) if base else cand
{I}        if p:
{I}            try:
{I}                _open_explorer_select(p)  # vorhandene Helper-Funktion
{I}            except Exception:
{I}                pass
{I}    except Exception:
{I}        pass
{I}
{I}def _copy_selected(self):
{I}    try:
{I}        if hasattr(self, "_path_from_selection_or_fields"):
{I}            p = self._path_from_selection_or_fields()
{I}        else:
{I}            p = None
{I}        if p:
{I}            self._copy_text(p)
{I}    except Exception:
{I}        pass
{I}
{I}def _copy_name_selected(self):
{I}    try:
{I}        if hasattr(self, "tbl") and self.tbl.selection():
{I}            iid = self.tbl.selection()[0]
{I}            vals = self.tbl.item(iid, "values") or []
{I}            if vals:
{I}                self._copy_text(vals[0] + (vals[1] if len(vals) > 1 else ""))
{I}    except Exception:
{I}        pass
{I}
{I}def _dbl_open(self, _evt=None):
{I}    try:
{I}        self._open_selected()
{I}    except Exception:
{I}        pass
"""

def ensure_helpers(src: str) -> tuple[str, int]:
    need = []
    for name in ("_open_selected(", "_copy_selected(", "_copy_name_selected(", "_dbl_open("):
        if name not in src:
            need.append(name)
    if not need:
        return src, 0

    s_idx, e_idx, IND = _find_class_block(src, "IntakeFrame")
    if s_idx < 0:
        return src, 0  # Klasse nicht gefunden; nichts tun

    block = src[s_idx:e_idx]
    # am Ende des Klassenblocks einfügen (vor der abschließenden Dedent/EOF)
    insert = HELPERS.format(I=IND)
    if insert.strip() in block:
        return src, 0  # bereits vorhanden (idempotent)
    new_block = block.rstrip() + "\n\n" + insert.lstrip("\n")
    return src[:s_idx] + new_block + src[e_idx:], 1

def main():
    if not os.path.isfile(MOD):
        print(f"[R1110] Nicht gefunden: {MOD}")
        sys.exit(1)

    src0 = read_text(MOD)

    # 1) try/try-Dopplungen entschärfen
    src1, n_try = fix_double_try(src0)

    # 2) Guard-Button an 'bar' binden
    src2, n_guard = fix_guard_parent(src1)

    # 3) F5-Binding sicherstellen
    src3, did_f5 = ensure_f5_binding(src2)

    # 4) Helper ergänzen (falls fehlen)
    src4, n_helpers = ensure_helpers(src3)

    if (src4 == src0):
        print("[R1110] Keine Änderungen nötig.")
        # trotzdem kurze Syntaxprobe
        try:
            sanity_compile(src4)
            print("[R1110] Syntax OK.")
        except Exception as ex:
            print("[R1110] Warnung: Syntaxcheck meldet Fehler:\n", ex)
        return

    backup(MOD)

    # vor dem Schreiben Syntax prüfen, um Totalschäden zu vermeiden
    try:
        sanity_compile(src4)
    except Exception as ex:
        print("[R1110] SyntaxError nach Patch – Datei bleibt UNVERÄNDERT.")
        print(ex)
        sys.exit(2)

    write_text(MOD, src4)
    print(f"[R1110] Patch gespeichert. Änderungen: try-fix={n_try}, guard-parent={n_guard}, f5={int(did_f5)}, helpers={n_helpers}")
    print("[R1110] Syntax OK.")

if __name__ == "__main__":
    main()
