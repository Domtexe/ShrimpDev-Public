# -*- coding: utf-8 -*-
"""
Runner_1177c_IntakeRecover
- Sucht im _Archiv/ nach alten DEV-Intake-Versionen und stellt die neueste passende wieder her.
- Ausschluss von ShrimpHub-Intake (Heuristik via Keywords).
- Sichert die aktuelle module_code_intake.py nach _Archiv/ bevor sie überschrieben wird.
- Schreibt Log nach debug_output.txt
"""
from __future__ import annotations
import os, re, shutil, datetime

ROOT   = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
ARCH   = os.path.join(ROOT, "_Archiv")
MODDIR = os.path.join(ROOT, "modules")
TARGET = os.path.join(MODDIR, "module_code_intake.py")
LOGF   = os.path.join(ROOT, "debug_output.txt")

# Schlüsselwörter, die eindeutig auf **ShrimpHub**-Intake hindeuten (sollen NICHT vorkommen)
HUB_MARKERS = [
    "tkinterdnd2", "Drag&Drop", "snippet_file_ops", "safe_move_with_verify",
    "guess_category", "snippet_auto_category", "Videos", "Auto-Kategorie",
    "Move Auswahl", "Journal", "ImageTk", "Preview", "Vorschau",
]
# Marker, die üblicherweise im **ShrimpDev**-Intake stehen (optional, hilft beim Ranking)
DEV_HINTS = [
    "ShrimpDev", "DevIntake", "Runner", "debug_output.txt", "Analyse",
    "Syntax", "Sanity", "Gate", "module_shim_intake",
]

def ts(): return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def log(msg: str):
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(f"[{ts()}] [R1177c] {msg}\n")
    except Exception:
        pass

def list_archived_candidates():
    if not os.path.isdir(ARCH):
        return []
    items = []
    for fn in os.listdir(ARCH):
        if not fn.startswith("module_code_intake.py.") or not fn.endswith(".bak"):
            continue
        p = os.path.join(ARCH, fn)
        try:
            size = os.path.getsize(p)
        except Exception:
            size = 0
        items.append((p, size, os.path.getmtime(p)))
    # neueste zuerst
    items.sort(key=lambda x: x[2], reverse=True)
    return [p for p,_,_ in items]

def is_hub_intake(text: str) -> bool:
    t = text
    for m in HUB_MARKERS:
        if m in t:
            return True
    return False

def dev_score(text: str) -> int:
    score = 0
    for h in DEV_HINTS:
        if h in text:
            score += 1
    return score

def pick_best_dev_intake(paths):
    best = None
    best_score = -1
    for p in paths:
        try:
            with open(p, "r", encoding="utf-8") as f:
                txt = f.read()
        except Exception:
            continue
        if is_hub_intake(txt):
            log(f"Skip Hub-like candidate: {os.path.basename(p)}")
            continue
        score = dev_score(txt)
        # Bonus, wenn eine IntakeFrame-Klasse existiert
        if re.search(r"class\s+IntakeFrame\s*\(", txt):
            score += 2
        if score > best_score:
            best = (p, txt)
            best_score = score
    return best  # (path, text) oder None

def backup_current():
    if not os.path.exists(TARGET):
        return None
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"module_code_intake.py.{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.bak")
    shutil.copy2(TARGET, bak)
    log(f"Backup current -> {bak}")
    return bak

def restore_from(text: str, src_path: str):
    os.makedirs(MODDIR, exist_ok=True)
    with open(TARGET, "w", encoding="utf-8") as f:
        f.write(text)
    log(f"Restored DEV-Intake from {os.path.basename(src_path)} to modules/module_code_intake.py")

def main() -> int:
    log("Start IntakeRecover.")
    cands = list_archived_candidates()
    if not cands:
        print("[R1177c] Keine Archiv-Kandidaten gefunden.")
        log("No candidates in _Archiv.")
        return 2
    best = pick_best_dev_intake(cands)
    if not best:
        print("[R1177c] Es wurde kein DEV-Intake im Archiv erkannt (nur Hub-Varianten?).")
        log("No DEV candidate recognized.")
        return 3
    backup_current()
    restore_from(best[1], best[0])
    print("[R1177c] DEV-Intake wiederhergestellt aus:", os.path.basename(best[0]))
    log("Finished OK.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
