from __future__ import annotations
import os, re, io
ROOT = r"D:\ShrimpDev"
MAIN = os.path.join(ROOT, "main_gui.py")
BACK = os.path.join(ROOT, "_Archiv", "main_gui.py.1175e.bak")

SHIM = r'''
# === Intake Mount Shim (idempotent, non-destructive) ===
def __log_exc(tag, e):
    try:
        import traceback
        with open(r"D:\ShrimpDev\debug_output.txt","a",encoding="utf-8") as f:
            f.write(f"\n[{tag}] {type(e).__name__}: {e}\n")
            traceback.print_exc(file=f)
    except Exception:
        pass

def __mount_intake_tab_shim(nb):
    import tkinter as tk
    from tkinter import ttk
    try:
        import module_code_intake as intake
    except Exception as e:
        f = ttk.Frame(nb)
        tk.Label(f, text="Fehler beim Import von Intake (module_code_intake). Details in debug_output.txt",
                 foreground="red").pack(padx=12, pady=8, anchor="w")
        __log_exc("INTAKE_IMPORT", e)
        return f

    candidates = [
        "mount_intake_tab_safe", "mount_intake_tab", "create_intake_tab",
        "build_ui", "_build_ui"
    ]

    for name in candidates:
        fn = getattr(intake, name, None)
        if not callable(fn):
            continue
        try:
            # Versuche mit nb-Param, sonst ohne
            try:
                res = fn(nb)
            except TypeError:
                res = fn()
        except Exception as e:
            __log_exc(f"INTAKE_CALL:{name}", e)
            continue

        try:
            import tkinter as tk
            from tkinter import ttk
            if isinstance(res, (tk.Frame, ttk.Frame)):
                return res
            if isinstance(res, (list, tuple)):
                for it in res:
                    if isinstance(it, (tk.Frame, ttk.Frame)):
                        return it
            fr = getattr(res, "frame", None)
            if isinstance(fr, (tk.Frame, ttk.Frame)):
                return fr
        except Exception:
            pass

    # Fallback-Placeholder (sichtbar in der GUI)
    f = ttk.Frame(nb)
    tk.Label(f, text="Intake konnte nicht aufgebaut werden – Fallback aktiv.",
             foreground="red").pack(padx=12, pady=8, anchor="w")
    tk.Label(f, text="Prüfe module_code_intake.* Builder-Funktionen.",
             foreground="#444").pack(padx=12, pady=0, anchor="w")
    return f
# === End Shim ===
'''

def read(p):
    with open(p, 'r', encoding='utf-8') as f:
        return f.read()

def write(p, s):
    os.makedirs(os.path.dirname(BACK), exist_ok=True)
    if not os.path.exists(BACK):
        with open(BACK, 'w', encoding='utf-8') as b:
            b.write(read(MAIN))
    with open(p, 'w', encoding='utf-8') as f:
        f.write(s)

src = read(MAIN)

# 1) Shim einfügen (falls noch nicht vorhanden), NACH allen from __future__ imports
if "__mount_intake_tab_shim" not in src:
    # Stelle nach dem letzten __future__-Import finden
    lines = src.splitlines(keepends=True)
    insert_at = 0
    for i,l in enumerate(lines):
        if re.match(r'\s*from\s+__future__\s+import\s+', l):
            insert_at = i+1
    lines.insert(insert_at, SHIM + "\n")
    src = "".join(lines)

# 2) Aufruf im _safe_main(): ersetze alle Varianten durch Shim-Aufruf
# Beispiele, die wir abdecken:
#   nb.add(tab_intake, text="Code Intake")
#   _safe_add_intake_tab(nb)
#   _mount_intake_tab_safe(nb)
patterns = [
    # direkte alte Guards
    (r'_safe_add_intake_tab\s*\(\s*nb\s*\)', r'nb.add(__mount_intake_tab_shim(nb), text="Code Intake")'),
    (r'_mount_intake_tab_safe\s*\(\s*nb\s*\)', r'nb.add(__mount_intake_tab_shim(nb), text="Code Intake")'),
]
for pat, repl in patterns:
    src = re.sub(pat, repl, src)

# Falls es gar keinen Intake-Add mehr gibt, hängen wir einen an der üblichen Stelle an:
if "nb.add(__mount_intake_tab_shim(nb)" not in src:
    # Heuristik: nach Notebook-Erstellung 'nb = ttk.Notebook(' in _safe_main
    m = re.search(r'(nb\s*=\s*ttk\.Notebook\([^\)]*\)[^\n]*\n)', src)
    if m:
        ins_pos = m.end()
        inject = '    nb.add(__mount_intake_tab_shim(nb), text="Code Intake")\n'
        src = src[:ins_pos] + inject + src[ins_pos:]

write(MAIN, src)
print("[1175e] Commit ✅")
