# -*- coding: utf-8 -*-
"""
R1154h: FixMissingBuildUiDef
Repariert die versehentliche Auskommentierung der _build_ui()-Definition:
"# ---------- UI ----------    def _build_ui(self):" -> trennt in zwei Zeilen.
Idempotent, mit Backup, Syntax- & Import-Smoke, Rollback bei Fehlern.
"""
from __future__ import annotations
import io, sys, time, shutil, re, importlib.util, types, py_compile
from pathlib import Path

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1154h_FixMissingBuildUiDef_report.txt"

def log(s=""):
    print(s)
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(s.rstrip()+"\n")

def backup(p: Path) -> Path:
    dst = ARCH / (p.name + "." + str(int(time.time()*1000)) + ".bak")
    shutil.copy2(p, dst)
    return dst

def import_smoke()->tuple[bool,str]:
    if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
    # Notfall: Stub für module_runner_exec
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules"); sys.modules.setdefault("modules", pkg)
        mod = types.ModuleType("modules.module_runner_exec")
        mod.run = lambda *a, **k: 0
        mod._log = lambda *a, **k: None
        sys.modules["modules.module_runner_exec"] = mod
    try:
        spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
        m = importlib.util.module_from_spec(spec); assert spec and spec.loader
        spec.loader.exec_module(m)  # type: ignore[attr-defined]
        return True, "Import OK"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"

def main()->int:
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass
    log("[R1154h] Start FixMissingBuildUiDef")

    if not MODFILE.exists():
        log("[ERR] modules/module_code_intake.py nicht gefunden."); return 1

    bak = backup(MODFILE); log(f"[Backup] {bak.name}")
    src0 = io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

    # 1) Nur reparieren, wenn die def-Zeile fehlt ODER die kaputte Kommentar+def-Linie existiert.
    has_def = re.search(r'(?m)^\s{4}def\s+_build_ui\s*\(\s*self\s*\)\s*:', src0) is not None
    broken  = re.search(r'(?m)^\s{4}#\s*-+\s*UI\s*-+\s+def\s+_build_ui\s*\(\s*self\s*\)\s*:', src0) is not None

    if has_def and not broken:
        log("[Info] _build_ui()-Definition bereits korrekt. Keine Änderung nötig.")
        return 0

    # 2) Patch: Kommentar und def trennen
    patched, n = re.subn(
        r'(?m)^(\s{4}#\s*-+\s*UI\s*-+\s+)(def\s+_build_ui\s*\(\s*self\s*\)\s*:)',
        r'\1\n    \2',
        src0
    )

    # Falls das Muster nicht griff, optional best effort: missratene Kommentarzeile mit 'def' am Ende
    if n == 0:
        patched, n = re.subn(
            r'(?m)^(\s{4}#.*UI.*)\s+(def\s+_build_ui\s*\(\s*self\s*\)\s*:)',
            r'\1\n    \2',
            src0
        )

    if n == 0 and not has_def:
        log("[ERR] Konnte _build_ui()-Header nicht reparieren."); 
        return 1

    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(patched)

    # 3) Syntax-Check
    try:
        py_compile.compile(MODFILE, doraise=True)
        log("[Syntax] OK")
    except Exception as e:
        log(f"[Syntax] Fehler: {e} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    # 4) Import-Smoke
    ok, msg = import_smoke()
    if not ok:
        log(f"[Live] Import-Fehler: {msg} -> Rollback"); shutil.copy2(bak, MODFILE); return 1
    log(f"[Live] {msg}")

    log(f"[SUM] build_ui_header_fixed={n>0}")
    log("[R1154h] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
