# -*- coding: utf-8 -*-
"""
Runner_1154d_FixIntakeToolbarAndGuard

Ziele:
1) Den irrtümlich auf Klassenebene eingefügten Block
   "# R1154c: zusätzliche Toolbar-Buttons (idempotent)" entfernen.
2) Den Buttons-Block korrekt IN _build_ui() am Ende einfügen (idempotent).
3) _detect_guarded reparieren (keine Rekursion; ruft _detect()).
Sicher: Backup -> Write -> Syntaxcheck -> Import-Smoke -> Rollback.
"""
from __future__ import annotations
import io, os, sys, time, shutil, ast, importlib.util, types, re, py_compile
from pathlib import Path

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1154d_FixIntakeToolbarAndGuard_report.txt"

BUTTONS_BLOCK = r"""
        # R1154d: zusätzliche Toolbar-Buttons (idempotent; innerhalb _build_ui)
        try:
            parent = bar
        except Exception:
            try:
                parent = getattr(self, "toolbar", None)
            except Exception:
                parent = None
        if parent:
            try:
                import tkinter.ttk as ttk
            except Exception:
                pass
            try:
                if not hasattr(self, 'btn_clear_editor'):
                    self.btn_clear_editor = ttk.Button(parent, text='Editor leeren', command=self._on_clear_editor)
                    self.btn_clear_editor.grid(row=0, column=120, padx=(12,0), sticky='w')
            except Exception:
                pass
            try:
                if not hasattr(self, 'btn_delete_file'):
                    self.btn_delete_file = ttk.Button(parent, text='Datei löschen', command=self._on_delete_selected_file)
                    self.btn_delete_file.grid(row=0, column=121, padx=(6,0), sticky='w')
            except Exception:
                pass
""".rstrip("\n")

def log(s=""):
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(s.rstrip()+"\n")
    print(s)

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time()*1000)}.bak"
    shutil.copy2(p, dst)
    return dst

def _remove_class_level_buttons_block(src: str) -> tuple[str, bool]:
    """Entfernt den auf Klassenebene stehenden R1154c-Block (falls vorhanden)."""
    # Sucht ab Beginn der Klasse IntakeFrame nach dem exakt kommentierten Marker
    rx = re.compile(
        r'(?ms)^\s{4}#\s*-{10,} helpers -{10,}\s*'  # Abschnitts-Kommentar (so wie in der Datei)
        r'(?:\n\s*)?'
        r'(\s{8}# R1154c: zusätzliche Toolbar-Buttons.*?^\s{4}def\s+_bind_shortcuts\b)',
        re.DOTALL
    )
    m = rx.search(src)
    if m:
        removed = src[:m.start(1)] + src[m.end(1):]
        return removed, True
    # Alternativ: direkter Marker-Match nur auf den Block selbst
    rx2 = re.compile(r'(?ms)^\s{8}# R1154c: zusätzliche Toolbar-Buttons.*?(?=^\s{4}def\s+)', re.DOTALL)
    if rx2.search(src):
        removed = rx2.sub("", src)
        return removed, True
    return src, False

def _inject_buttons_into_build_ui(src: str) -> tuple[str, bool]:
    """Hängt den Buttons-Block am Ende der Methode _build_ui() an (falls nicht vorhanden)."""
    # parse AST um _build_ui zu finden
    tree = ast.parse(src)
    cls = None
    for n in tree.body:
        if isinstance(n, ast.ClassDef) and n.name == "IntakeFrame":
            cls = n; break
    if not cls:
        raise RuntimeError("class IntakeFrame nicht gefunden.")
    func = None
    for b in cls.body:
        if isinstance(b, ast.FunctionDef) and b.name == "_build_ui":
            func = b; break
    if not func:
        raise RuntimeError("_build_ui() nicht gefunden.")
    lines = src.splitlines()
    start = func.lineno - 1
    end   = getattr(func, "end_lineno", None) or (start + 1)
    body  = "\n".join(lines[start:end])
    if "btn_clear_editor" in body or "btn_delete_file" in body:
        return src, False  # schon vorhanden
    # Einfügen VOR der abschließenden Dedent-Zeile (= vor end)
    indented_block = BUTTONS_BLOCK
    new_body = body.rstrip("\n") + "\n" + indented_block + "\n"
    new_src = "\n".join(lines[:start]) + new_body + "\n".join(lines[end:])
    return new_src, True

def _fix_detect_guarded(src: str) -> tuple[str, bool]:
    """
    Ersetzt den rekursiven _detect_guarded durch eine sichere Variante:
        try: return self._detect(*args, **kwargs)
        except Exception: ping + False
    """
    rx = re.compile(
        r'(?ms)^\s{4}def\s+_detect_guarded\s*\([^)]*\):\s*'
        r'"""[^"]*?"""(?:\s*|\n)'
        r'\s*try:\s*\n\s*return\s+self\._detect_guarded\([^)]*\)\s*\n\s*except\s+Exception\s+as\s+ex:\s*\n'
        r'(?:\s*.+?\n)*?'
        r'\s*return\s+False\s*$'
    )
    if rx.search(src):
        safe = (
            'def _detect_guarded(self, *args, **kwargs):\n'
            '        """\n'
            '        Ruft _detect sicher auf. Fängt alle Exceptions (inkl. Regex-Fehler) ab,\n'
            '        zeigt eine kurze Warnung und liefert False statt zu crashen.\n'
            '        """\n'
            '        try:\n'
            '            return self._detect(*args, **kwargs)\n'
            '        except Exception as ex:\n'
            '            try:\n'
            '                self._ping(f"DetectWarn: {ex}")\n'
            '            except Exception:\n'
            '                pass\n'
            '            return False\n'
        )
        # Ersetze den gesamten Block robust über einfachere Kopf-Erkennung:
        rx2 = re.compile(r'(?ms)^\s{4}def\s+_detect_guarded\s*\([^)]*\):\s*.*?(?=^\s{4}def\s+|\Z)')
        src = rx2.sub("    " + safe, src, count=1)
        return src, True
    else:
        # Falls eine andere (defekte) Variante existiert, trotzdem erzwingen:
        rx2 = re.compile(r'(?ms)^\s{4}def\s+_detect_guarded\s*\([^)]*\):\s*.*?(?=^\s{4}def\s+|\Z)')
        if rx2.search(src):
            src = rx2.sub("    " + (
                'def _detect_guarded(self, *args, **kwargs):\n'
                '        """\n'
                '        Ruft _detect sicher auf. Fängt alle Exceptions (inkl. Regex-Fehler) ab,\n'
                '        zeigt eine kurze Warnung und liefert False statt zu crashen.\n'
                '        """\n'
                '        try:\n'
                '            return self._detect(*args, **kwargs)\n'
                '        except Exception as ex:\n'
                '            try:\n'
                '                self._ping(f"DetectWarn: {ex}")\n'
                '            except Exception:\n'
                '                pass\n'
                '            return False\n'
            ), src, count=1)
            return src, True
    return src, False

def import_smoke()->tuple[bool,str]:
    """Nur Import (ohne Tk-Loop). Stubbt optional module_runner_exec."""
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules")
        mod = types.ModuleType("modules.module_runner_exec")
        mod.run = lambda *a, **k: 0
        mod._log = lambda *a, **k: None
        sys.modules.setdefault("modules", pkg)
        sys.modules["modules.module_runner_exec"] = mod
    try:
        spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
        m = importlib.util.module_from_spec(spec); assert spec and spec.loader
        spec.loader.exec_module(m)  # type: ignore[attr-defined]
        return True, "Import OK"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"

def main()->int:
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass
    log("[R1154d] FixIntakeToolbarAndGuard – Start")
    if not MODFILE.exists():
        log("[ERR] module_code_intake.py fehlt."); return 1

    bak = backup(MODFILE); log(f"[Backup] {bak.name}")
    src = io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

    # 1) Class-Level-Block entfernen
    src1, removed = _remove_class_level_buttons_block(src)
    if removed:
        log("[Patch] class-level Toolbar-Block entfernt")

    # 2) Buttons in _build_ui einfügen (falls noch nicht drin)
    src2, added = _inject_buttons_into_build_ui(src1)
    if added:
        log("[Patch] Buttons in _build_ui am Ende ergänzt")

    # 3) _detect_guarded reparieren
    src3, fixed_guard = _fix_detect_guarded(src2)
    if fixed_guard:
        log("[Patch] _detect_guarded repariert (kein Selbstaufruf)")

    if not (removed or added or fixed_guard):
        log("[Info] Keine Änderungen nötig.")

    # schreiben
    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(src3)

    # Syntaxcheck
    try:
        py_compile.compile(str(MODFILE), doraise=True); log("[Syntax] OK")
    except Exception as e:
        log(f"[Syntax] Fehler: {e} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    # Import-Smoke
    ok, msg = import_smoke()
    if not ok:
        log(f"[Live] Probe-Fehler: {msg} -> Rollback"); shutil.copy2(bak, MODFILE); return 1
    log(f"[Live] {msg}")

    log("[SUM] Toolbar korrekt in _build_ui verankert, _detect_guarded gefixt.")
    log("[R1154d] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
