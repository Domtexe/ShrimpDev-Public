# -*- coding: utf-8 -*-
"""
R1164b OptionalConfirmOnClear
- Ergänzt eine kleine Session-Flag-Logik: self._skip_confirm_clear (default False).
- Ersetzt den Clear-Dialog durch ein kleines Toplevel mit Checkbox "Nicht wieder anzeigen".
- Minimal-invasiv: fügt zwei Hilfsfunktionen hinzu und wrappt den bestehenden Clear-Handler.
- Safety: Backup, Syntax-Check, Rollback. Tut nichts, falls Muster nicht gefunden werden.
"""
from __future__ import annotations
import os, io, re, time, shutil, py_compile, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOGF = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with io.open(LOGF, "a", encoding="utf-8") as f: f.write(f"[R1164b] {ts} {msg}\n")
    print(f"[R1164b] {ts} {msg}")

INJECT_FUNCS = r"""
# --- R1164b: optional confirm dialog for editor clear (session-based) ---
def _intake_confirm_clear(self) -> bool:
    try:
        import tkinter as tk
        from tkinter import ttk
        if getattr(self, "_skip_confirm_clear", False):
            return True
        dlg = tk.Toplevel(self)
        dlg.title("Bestätigung")
        dlg.transient(self.winfo_toplevel())
        dlg.grab_set()
        ttk.Label(dlg, text="Editor wirklich leeren?").grid(row=0, column=0, columnspan=2, padx=10, pady=8, sticky="w")
        var_skip = tk.BooleanVar(value=False)
        ttk.Checkbutton(dlg, text="Nicht wieder anzeigen", variable=var_skip).grid(row=1, column=0, columnspan=2, padx=10, pady=(0,8), sticky="w")
        res = {"ok": False}
        def _ok():
            res["ok"] = True
            dlg.destroy()
        def _cancel():
            dlg.destroy()
        ttk.Button(dlg, text="Ja", command=_ok).grid(row=2, column=0, padx=10, pady=8)
        ttk.Button(dlg, text="Nein", command=_cancel).grid(row=2, column=1, padx=10, pady=8)
        dlg.bind("<Return>", lambda e: _ok())
        dlg.bind("<Escape>", lambda e: _cancel())
        dlg.wait_window()
        if res["ok"] and var_skip.get():
            setattr(self, "_skip_confirm_clear", True)
        return res["ok"]
    except Exception:
        # Fallback: bei Problem lieber zulassen statt blockieren
        return True
"""

WRAP_CLEAR = r"""
# --- R1164b wrap: clear with optional confirm ---
try:
    orig_clear_editor = clear_editor
except NameError:
    try:
        orig_clear_editor = on_clear_editor
    except NameError:
        orig_clear_editor = None

if orig_clear_editor is not None:
    def clear_editor(*args, **kwargs):
        try:
            self_ref = args[0] if args else None
            # bei Methoden: erster Arg ist self
            if getattr(self_ref, "_skip_confirm_clear", False) or self_ref._intake_confirm_clear():
                return orig_clear_editor(*args, **kwargs)
            return None
        except Exception:
            return orig_clear_editor(*args, **kwargs)
"""

def backup(p: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, dst); log(f"Backup: {p} -> {dst}"); return dst

def inject(src: str) -> tuple[str, list[str]]:
    changes = []
    if "_intake_confirm_clear" not in src:
        # vor Ende der Datei anhängen
        src = src.rstrip() + "\n\n" + INJECT_FUNCS
        changes.append("Added _intake_confirm_clear() helper")
    # prüfe, ob clear_editor existiert
    if re.search(r"^\s*def\s+(on_)?clear_editor\s*\(\s*self", src, re.M):
        if "# --- R1164b wrap: clear with optional confirm ---" not in src:
            src = src.rstrip() + "\n\n" + WRAP_CLEAR
            changes.append("Wrapped clear_editor with optional confirm")
    else:
        changes.append("No clear_editor found; wrap skipped (no changes to handlers)")
    return src, changes

def main() -> int:
    try:
        if not os.path.isfile(MOD): log(f"[ERR] Not found: {MOD}"); return 2
        with io.open(MOD, "r", encoding="utf-8") as f: src = f.read()
        bak = backup(MOD)
        new, changes = inject(src)
        if not changes: log("No changes applied."); return 0
        with io.open(MOD, "w", encoding="utf-8", newline="\n") as f: f.write(new)
        for c in changes: log(f"Change: {c}")
        try: py_compile.compile(MOD, doraise=True); log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}"); shutil.copy2(bak, MOD); log("Restored from backup."); return 3
        log("R1164b completed successfully."); return 0
    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}"); return 1

if __name__ == "__main__":
    raise SystemExit(main())
