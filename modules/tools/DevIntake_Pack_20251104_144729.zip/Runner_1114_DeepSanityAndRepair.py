# -*- coding: utf-8 -*-
"""
Runner_1114_DeepSanityAndRepair.py
- Tiefer Sanity-Check + Auto-Repair für Intake & GUI
- Behebt typische Indentation-/Syntax-Probleme
- Verhindert Tk-Callback-Recursion durch Reentrancy-Guard
- Führt Vor- und Nachprüfung (AST/compile) durch
"""
from __future__ import annotations
import os, sys, io, re, time, shutil, argparse, traceback, ast

ROOT = os.path.abspath(os.path.dirname(__file__))
BASE = os.path.abspath(os.path.join(ROOT, ".."))
ARCH = os.path.join(BASE, "_Archiv")
os.makedirs(ARCH, exist_ok=True)

DEFAULT_TARGETS = [
    os.path.join(BASE, "modules", "module_code_intake.py"),
    os.path.join(BASE, "main_gui.py"),
]

def backup(path: str) -> str:
    ts = int(time.time())
    base = os.path.basename(path)
    bak = os.path.join(ARCH, f"{base}.{ts}.bak")
    shutil.copy2(path, bak)
    return bak

def read_text(path: str) -> str:
    with open(path, "rb") as f:
        raw = f.read()
    # tolerant dekodieren
    for enc in ("utf-8-sig","utf-8","latin-1"):
        try:
            return raw.decode(enc)
        except Exception:
            pass
    return raw.decode("utf-8", errors="replace")

def write_text(path: str, text: str) -> None:
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

def norm_newlines_tabs(s: str) -> str:
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    s = s.replace("\t", "    ")
    return s

def has_unclosed_triple_quotes(s: str) -> bool:
    # sehr einfache Heuristik: ungerade Anzahlen ''' oder """?
    return (s.count("'''") % 2 != 0) or (s.count('"""') % 2 != 0)

def try_ast_compile(path: str, text: str) -> tuple[bool, str]:
    try:
        ast.parse(text, filename=path)
        compile(text, path, "exec")
        return True, ""
    except SyntaxError as ex:
        return False, f"SyntaxError: {ex.msg} (line {ex.lineno})"
    except Exception as ex:
        return False, f"{type(ex).__name__}: {ex}"

_BLOCK_START = re.compile(r"^\s*(if|for|while|try|with|def|class)\b.*:\s*(#.*)?$")
_RETURN_AT_COL0 = re.compile(r"^(return|break|continue)\b")
_DEF_CLASS = re.compile(r"^\s*(def|class)\s+\w")

def auto_repair_indentation(text: str) -> str:
    """
    Repariert typische Fehler:
      - fehlender Block nach ...:
      - return/break/continue auf Spalte 0 -> Einrücken auf vorheriges Niveau
    """
    lines = text.split("\n")
    n = len(lines)
    i = 0
    while i < n:
        line = lines[i]
        # 1) Blockstarter ohne eingerückte Folgezeile -> 'pass' einfügen
        if _BLOCK_START.match(line):
            cur_indent = len(line) - len(line.lstrip(" "))
            j = i + 1
            # überspringe Leerzeilen/Kommentare
            while j < n and (lines[j].strip() == "" or lines[j].lstrip().startswith("#")):
                j += 1
            if j >= n:
                lines.append(" " * (cur_indent + 4) + "pass")
                n = len(lines)
            else:
                next_indent = len(lines[j]) - len(lines[j].lstrip(" "))
                if next_indent <= cur_indent:
                    lines.insert(j, " " * (cur_indent + 4) + "pass")
                    n += 1
                    i = j  # weiter hinter Einfügung
        # 2) return/break/continue an Spalte 0 → an vorherige Einrückung andocken
        if _RETURN_AT_COL0.match(line.strip()):
            # suche letzten sinnvollen Indent
            k = i - 1
            target_indent = 0
            while k >= 0:
                t = lines[k]
                if t.strip() != "":
                    target_indent = len(t) - len(t.lstrip(" "))
                    break
                k -= 1
            if target_indent < 4:
                target_indent = 4
            if (len(line) - len(line.lstrip(" "))) == 0:
                lines[i] = " " * target_indent + line
        i += 1
    return "\n".join(lines)

def ensure_future_at_top(text: str) -> str:
    """Sorge dafür, dass from __future__-Imports (falls vorhanden) ganz oben stehen."""
    # Wenn keine future-Imports: nichts tun
    if "from __future__ import" not in text:
        return text
    lines = text.split("\n")
    shebang = 0
    if lines and lines[0].startswith("#!"):
        shebang = 1
    # sammle future-Imports und entferne an anderer Stelle
    future = []
    body = []
    for ln in lines[shebang:]:
        if ln.startswith("from __future__ import"):
            future.append(ln)
        else:
            body.append(ln)
    if not future:
        return text
    head = []
    head.extend(lines[:shebang])
    head.append("# -*- coding: utf-8 -*-")
    head.extend(sorted(set(future)))
    head.append("")  # Leerzeile
    return "\n".join(head + body)

def patch_main_gui_recursion_guard(text: str) -> str:
    """
    Fügt in main_gui.py einen Reentrancy-Guard in report_callback_exception ein,
    damit Tkinter-Fehlerberichte nicht erneut einen Fehler erzeugen.
    """
    if "def report_callback_exception" not in text:
        return text
    # Wenn Guard schon vorhanden, nichts tun
    if "_report_guard_active" in text:
        return text

    # sehr vorsichtiges Einfügen der Guard-Variablen im Scope der Funktion
    def repl(m: re.Match) -> str:
        func = m.group(0)
        indent = re.match(r"^(\s*)def report_callback_exception", func).group(1)
        guard = (
            f"{indent}    nonlocal _report_guard_active\n"
            f"{indent}    if _report_guard_active:\n"
            f"{indent}        return\n"
            f"{indent}    _report_guard_active = True\n"
        )
        tail = (
            f"\n{indent}    _report_guard_active = False\n"
        )
        # nach Funktionskopf ersten Codeblock finden:
        lines = func.split("\n")
        # suche die erste nicht-leere Zeile im Körper (ab Zeile 1 in func)
        for idx in range(1, len(lines)):
            if lines[idx].strip() != "":
                # Guard einschieben direkt davor
                lines.insert(idx, guard.rstrip("\n"))
                break
        # Guard-Reset kurz vor Funktionsende hinzufügen
        # (vor 'root.report_callback_exception = ...' o.ä. ist unzuverlässig; daher ans Ende)
        # Einfach: am Ende vor der letzten Zeile einen Reset versuchen
        lines.append(tail.rstrip("\n"))
        return "\n".join(lines)

    # nonlocal-Var im äußeren Scope deklarieren
    # Lege eine Flag-Variable im _safe_main-Scope an:
    if "def _safe_main(" in text and "_report_guard_active" not in text:
        text = re.sub(
            r"(def _safe_main\([^\)]*\)\s*:\s*\n)",
            r"\1    _report_guard_active = False\n",
            text,
            count=1,
            flags=re.M
        )

    # Funktion selbst patchen
    text = re.sub(
        r"(^\s*def report_callback_exception\([^\)]*\)\s*:[\s\S]*?^\s*root\.report_callback_exception\s*=\s*report_callback_exception\s*$)",
        repl,
        text,
        count=1,
        flags=re.M
    )
    return text

def deep_process(path: str) -> bool:
    if not os.path.exists(path):
        print(f"[R1114] SKIP: {path} nicht gefunden.")
        return False

    print(f"[R1114] == Prüfe: {path}")
    bak = backup(path)
    print(f"[R1114] Backup: {path} -> {bak}")

    src = read_text(path)
    src0 = src
    src = norm_newlines_tabs(src)

    changed = False

    # Future-Imports korrekt platzieren
    new = ensure_future_at_top(src)
    if new != src:
        src = new
        changed = True

    # Grobe Heuristik: Triple-Quotes schließen
    if has_unclosed_triple_quotes(src):
        src += "\n'''\n"  # sanft schließen; lieber compile prüfen
        changed = True

    # Auto-Repair Indentation/Syntax-nahe Dinge
    new = auto_repair_indentation(src)
    if new != src:
        src = new
        changed = True

    # GUI-spezifisch: Reentrancy-Guard
    if os.path.basename(path) == "main_gui.py":
        new = patch_main_gui_recursion_guard(src)
        if new != src:
            src = new
            changed = True

    # Vorläufig schreiben & testen
    if changed:
        write_text(path, src)
        ok, err = try_ast_compile(path, src)
        if not ok:
            print(f"[R1114] Nach Reparatur noch Fehler: {err}")
            # Rollback
            shutil.copy2(bak, path)
            return False
        else:
            print(f"[R1114] Repariert & Syntax OK: {path}")
            return True
    else:
        # auch bei “keine Änderung” Syntax checken
        ok, err = try_ast_compile(path, src)
        if not ok:
            print(f"[R1114] Syntaxfehler ohne Auto-Repair erkannt: {err}")
            # letzter Versuch: minimale Reparatur + compile
            src2 = auto_repair_indentation(src)
            if src2 != src:
                write_text(path, src2)
                ok2, err2 = try_ast_compile(path, src2)
                if ok2:
                    print(f"[R1114] Minimalreparatur erfolgreich.")
                    return True
                shutil.copy2(bak, path)
                print(f"[R1114] Minimalreparatur fehlgeschlagen: {err2}")
                return False
            return False
        print(f"[R1114] Keine Änderungen nötig, Syntax OK.")
        return True

def main(argv=None):
    ap = argparse.ArgumentParser(description="Deep Sanity & Repair for Intake/GUI")
    ap.add_argument("files", nargs="*", help="zusätzliche Dateien")
    args = ap.parse_args(argv)

    targets = DEFAULT_TARGETS[:]
    for f in args.files:
        targets.append(os.path.abspath(f))

    overall_ok = True
    for p in targets:
        ok = deep_process(p)
        overall_ok = overall_ok and ok

    # Optional: Guard separat aufrufen (falls vorhanden)
    guard = os.path.join(BASE, "tools", "Runner_1063_Intake_SanityGuard.py")
    if overall_ok and os.path.exists(guard):
        try:
            print("[R1114] Starte Guard --check modules\\module_code_intake.py …")
            os.system(f'py -3 "{guard}" --check "{os.path.join(BASE,"modules","module_code_intake.py")}"')
        except Exception as ex:
            print(f"[R1114] Guard-Aufruf übersprungen: {ex}")

    print("[R1114] Fertig.")
    return 0 if overall_ok else 1

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit as ex:
        sys.exit(ex.code)
    except:
        print(traceback.format_exc())
        sys.exit(2)
