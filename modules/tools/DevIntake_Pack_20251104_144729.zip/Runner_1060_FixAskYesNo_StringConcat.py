"""
Runner_1060_FixAskYesNo_StringConcat
Fix: Ersetzt im Delete-Handler die f-String-Nutzung in messagebox.askyesno(...)
durch sichere String-Konkatenation. Setzt den gesamten _on_click_delete()-Block
kanonisch neu (4 Spaces, CRLF, Tabs->Spaces) und stellt den messagebox-Import sicher.

Version: v9.9.50
"""
from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

CANON_DELETE = (
    "    def _on_click_delete(self, _evt=None):\n"
    "        \"\"\"Gewählte Datei nach Bestätigung löschen und UI zurücksetzen.\"\"\"\n"
    "        path = \"\"\n"
    "        try:\n"
    "            sel = self.tree_right.selection()\n"
    "            if sel and hasattr(self, 'path_of_item'):\n"
    "                path = self.path_of_item(sel[0])\n"
    "        except Exception:\n"
    "            path = \"\"\n"
    "        if not path:\n"
    "            self._ping(\"Keine Datei gewählt.\")\n"
    "            return\n"
    "        # Keine f-Strings – robust gegen Quotes/Braces in Pfaden\n"
    "        msg = \"Datei endgültig löschen?\\n\\n\" + str(path)\n"
    "        if not messagebox.askyesno(\"Löschen bestätigen\", msg):\n"
    "            return\n"
    "        try:\n"
    "            os.remove(path)\n"
    "        except Exception as ex:\n"
    "            self._ping(\"Fehler beim Löschen: \" + str(ex))\n"
    "            return\n"
    "        self._load_table()\n"
    "        try:\n"
    "            self._clear_editor_and_fields()\n"
    "        except Exception:\n"
    "            pass\n"
    "        self._ping(\"Gelöscht.\")\n"
    "\n"
)

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1060] {ts} {msg}\n")
    except Exception:
        pass

def read_text(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def write_backup(p: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bck)
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {p} -> {bck}")

def ensure_messagebox_import(src: str) -> str:
    if re.search(r"from\s+tkinter\s+import\s+messagebox", src):
        return src
    m = re.search(r"^(import\s+tkinter\s+as\s+tk.*)$", src, re.MULTILINE)
    if m:
        return src[:m.end()] + "\nfrom tkinter import messagebox" + src[m.end():]
    return "from tkinter import messagebox\n" + src

def patch() -> int:
    src = read_text(MOD)
    src = ensure_messagebox_import(src)

    # Klasse IntakeFrame isolieren
    m = re.search(r"(class\s+IntakeFrame\(ttk\.Frame\):)([\s\S]+)", src)
    if not m:
        log("IntakeFrame-Klasse nicht gefunden.")
        return 1
    head, body = src[:m.start(2)], m.group(2).replace("\t", "    ")

    # Delete-Handler ersetzen/einfügen
    pat_del = re.compile(r"\n\s*def\s+_on_click_delete\([^\)]*\):[\s\S]*?(?=\n\s*def\s+|\Z)", re.MULTILINE)
    if pat_del.search(body):
        body = pat_del.sub("\n" + CANON_DELETE, body, count=1)
        log("_on_click_delete(): Block ersetzt.")
    else:
        anchor = re.search(r"\n\s*def\s+_load_table\([^\)]*\):[\s\S]*?(?=\n\s*def\s+|\Z)", body, re.MULTILINE)
        ins = anchor.end() if anchor else len(body)
        body = body[:ins] + "\n\n" + CANON_DELETE + body[ins:]
        log("_on_click_delete(): Block neu eingefügt.")

    new_src = head + body
    if new_src != src:
        write_backup(MOD, new_src)
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.50\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.50 (2025-10-18)
- Intake: Delete-Handler auf String-Konkatenation umgestellt (keine f-Strings), CRLF + 4 Spaces.
""")
        log("Patch angewendet.")
    else:
        log("Keine Änderungen nötig.")
    return 0

if __name__ == "__main__":
    raise SystemExit(patch())
