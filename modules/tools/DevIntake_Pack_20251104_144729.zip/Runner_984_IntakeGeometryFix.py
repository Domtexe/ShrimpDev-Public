from __future__ import annotations
from pathlib import Path
import re, time

ROOT = Path(r"D:\ShrimpDev")
MOD  = ROOT / "modules" / "module_code_intake.py"
LOG  = ROOT / "debug_output.txt"

def log(msg: str):
    print("[R984]", msg)
    try: LOG.open("a", encoding="utf-8", errors="ignore").write(f"[R984] {msg}\n")
    except Exception: pass

def backup(p: Path) -> Path:
    ts = time.strftime("%Y%m%d_%H%M%S")
    bak = p.with_suffix(p.suffix + f".{ts}.bak")
    p.replace(bak)
    log(f"Backup: {bak.name}")
    return bak

def _patch_intake_block(src: str) -> tuple[str,int]:
    """
    Ziel:
      - Im Block der Klasse 'IntakeWindow' alle .grid(...) -> .pack(...).
      - Für typische Flächen sinnvolle Pack-Varianten einsetzen.
      - Bestehenden Silent-Save-Modus bewahren (falls vorhanden).
    """
    changed = 0

    # 1) nur den Klassenblock IntakeWindow herausgreifen
    m = re.search(r'(?s)\nclass\s+IntakeWindow\s*\(.*?\):\s*(.*?)\nclass\s+|(?s)\nclass\s+IntakeWindow\s*\(.*?\):\s*(.*)\Z', src)
    if not m:
        return src, 0
    block = m.group(1) if m.group(1) is not None else m.group(2)
    start = m.start(1) if m.group(1) is not None else m.start(2)
    end   = m.end(1)   if m.group(1) is not None else m.end(2)

    # 2) zielgerichtete Ersetzungen im Block
    b = block

    # a) bereits bekannter LED-Fix (falls noch irgendwo grid benutzt wird)
    b_new = re.sub(r'led_\w+\s*\.grid\(.*?\)\s*', 'led_det.pack(side="right", padx=10)\n', b, flags=re.DOTALL)
    if b_new != b:
        changed += 1
        b = b_new

    # b) Textfeld self.txt sollte Fläche einnehmen
    b_new = re.sub(r'self\.txt\s*\.grid\(.*?\)\s*', 'self.txt.pack(fill="both", expand=True)\n', b, flags=re.DOTALL)
    if b_new != b:
        changed += 1
        b = b_new

    # c) jede sonstige .grid(...) im IntakeWindow in eine generische pack-Variante wandeln
    #    (pack ohne Fill für klassische Label/Entry/Button-Reihen; das entspricht dem bisherigen Layout)
    b_new = re.sub(r'\.grid\([^\)]*\)\s*', '.pack(padx=6, pady=2, anchor="w")\n', b)
    # Achtung: die beiden obigen Spezialfälle waren schon vorher ausgeführt
    #          hier geht es um die restlichen grid-Aufrufe
    if b_new != b:
        # Differenzen zählen grob:
        changed += b.count('.grid(')
        b = b_new

    # 3) Block zurückschreiben
    src_new = src[:start] + b + src[end:]
    return src_new, changed

def main() -> int:
    if not MOD.exists():
        log("FEHLT: modules\\module_code_intake.py"); return 2

    src = MOD.read_text(encoding="utf-8", errors="ignore")
    src_new, cnt = _patch_intake_block(src)

    if cnt == 0:
        log("Keine grid()->pack()-Umstellungen nötig oder IntakeWindow nicht gefunden.")
        return 0

    backup(MOD)
    MOD.write_text(src_new, encoding="utf-8")
    log(f"Umstellungen im IntakeWindow: {cnt}")
    log("Fertig. Bitte ShrimpDev neu starten oder den Intake-Tab neu öffnen.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
