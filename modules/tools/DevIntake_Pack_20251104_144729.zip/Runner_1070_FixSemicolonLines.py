# -*- coding: utf-8 -*-
"""
Runner_1070_FixSemicolonLines
Repariert fehlerhafte Mehrfachbefehle in einer Zeile (mit ';') im module_code_intake.py
Ziel: jede Anweisung in eigene Zeile mit korrekter Einrückung verschieben.
"""
from __future__ import annotations
import os, re, time, shutil, ast

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1070] {ts} {msg}\n")
    except Exception:
        pass

def read(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f: return f.read()

def backup_write(p: str, data: str):
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bak)
    log(f"Backup: {p} -> {bak}")
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

def normalize(src: str) -> str:
    src = src.replace("\r\n", "\n").replace("\r", "\n")
    src = "\n".join(ln.rstrip(" \t") for ln in src.split("\n"))
    src = src.replace("\t", "    ")
    if not src.endswith("\n"):
        src += "\n"
    return src

def fix_semicolons(src: str) -> tuple[str, int]:
    """Teilt Zeilen mit ';' in mehrere Einrückungen auf."""
    lines = src.split("\n")
    out = []
    count = 0
    for ln in lines:
        if ";" in ln and not ln.strip().startswith("#"):
            indent = re.match(r"[ \t]*", ln).group(0)
            parts = [p.strip() for p in ln.split(";") if p.strip()]
            if len(parts) > 1:
                for p in parts:
                    out.append(indent + p)
                count += 1
                continue
        out.append(ln)
    return "\n".join(out), count

def main() -> int:
    if not os.path.exists(MOD):
        log(f"Fehlt: {MOD}")
        return 2

    src0 = read(MOD)
    src1 = normalize(src0)
    fixed, n = fix_semicolons(src1)
    if n == 0:
        log("Keine Zeilen mit Semikolons gefunden.")
    else:
        log(f"Aufgeteilt: {n} Zeilen mit Semikolons korrigiert.")

    # Syntaxprüfung
    try:
        ast.parse(fixed)
    except SyntaxError as e:
        log(f"SyntaxError nach Fix: {e} (line {e.lineno})")
        lines = fixed.split("\n")
        a, b = max(1, (e.lineno or 1) - 10), min(len(lines), (e.lineno or 1) + 10)
        for i in range(a, b + 1):
            vis = lines[i - 1].replace("\t", "→").replace(" ", "·")
            log(f"{i:04d}: {vis}")
        return 3

    if fixed != src0:
        backup_write(MOD, fixed)
        log(f"Fix gespeichert.")
    else:
        log(f"Keine Änderungen nötig.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
