"""
Runner_1048_Intake_DeleteAndRecent50
- FIX: Button [Löschen] funktioniert sicher
  * Löscht die selektierte Tabellen-Datei
  * Falls keine Selektion: löscht Datei aus Name/Endung im Zielordner
  * Entfernt Eintrag aus History; GUI aktualisiert
- LISTE: Zeigt die letzten 50 aus der ShrimpDev-History (absteigend nach mtime)
  * Spalten: name | ext | subfolder | date | time
  * subfolder: relativ zum Zielordner, sonst letzter Ordnername mit '…/'-Prefix
- Version bump v9.9.38
"""
from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1048] {ts} {msg}\n")
    except Exception:
        pass

def read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def backup_write(path: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

def patch() -> int:
    src = read(MOD)
    changed = False

    # -----------------------------
    # 1) _load_table: History -> letzte 50 (mtime desc)
    # -----------------------------
    pattern_load = re.compile(r"def\s+_load_table\([\s\S]+?^\s*def\s+_path_of_item", re.MULTILINE)
    m = pattern_load.search(src)
    if m:
        new_load = r'''
    def _load_table(self):
        """Füllt die Tabelle mit den letzten 50 Einträgen aus der ShrimpDev-History."""
        # Tabelle leeren
        for i in self.tbl.get_children():
            self.tbl.delete(i)

        target = os.path.abspath(self.var_target.get() or ".")
        try:
            hist = list(self.cfg.get_history())
        except Exception:
            hist = []

        # nur existierende Dateien, Dedupe (jüngste zuerst), mtime absteigend
        seen = set()
        items = []
        for p in hist:
            try:
                ap = os.path.abspath(p)
                if not os.path.isfile(ap):
                    continue
                if ap in seen:
                    continue
                seen.add(ap)
                mt = os.path.getmtime(ap)
                items.append((mt, ap))
            except Exception:
                continue
        items.sort(key=lambda t: t[0], reverse=True)
        items = items[:50]

        for _mt, p in items:
            base = os.path.basename(p)
            name, ext = os.path.splitext(base)
            # subfolder: relativ zum Zielordner, sonst …/<dirname>
            try:
                ap = os.path.abspath(p)
                if ap.startswith(os.path.join(target, "")):
                    rel = os.path.relpath(os.path.dirname(ap), target)
                    sub = "" if rel in (".", "") else rel
                else:
                    sub = "…/" + os.path.basename(os.path.dirname(ap))
            except Exception:
                sub = ""
            try:
                dt = time.strftime("%Y-%m-%d", time.localtime(os.path.getmtime(p)))
                tm = time.strftime("%H:%M:%S", time.localtime(os.path.getmtime(p)))
            except Exception:
                dt = tm = ""
            self.tbl.insert("", "end", values=(name, (ext or "").lower(), sub, dt, tm))
'''
        src = src[:m.start()] + new_load + "\n    " + src[m.end():]
        changed = True

    # -----------------------------
    # 2) _on_click_delete: robust – Selektion oder aktueller Name
    # -----------------------------
    pattern_del = re.compile(r"def\s+_on_click_delete\([\s\S]+?^\s*def\s+", re.MULTILINE)
    m = pattern_del.search(src)
    if m:
        new_del = r'''
    def _on_click_delete(self):
        """Löscht die selektierte Datei – oder die Datei aus dem Namensfeld im Zielordner."""
        # 1) Pfad aus Auswahl
        path = ""
        sel = self.tbl.selection()
        if sel:
            path = self._path_of_item(sel[0])

        # 2) Fallback: Datei laut Name/Ext im Zielordner
        if not path:
            name = (self.var_name.get() or "").strip()
            if name:
                name = self._apply_ext_to_name(name, self.var_ext.get())
                path = os.path.join(self.var_target.get() or ".", name)

        if not path:
            self._ping("Nichts zum Löschen ausgewählt.")
            return

        # Falls Datei fehlt: nur History bereinigen
        if not os.path.isfile(path):
            try:
                self.cfg.remove_history(path)
            except Exception:
                pass
            self._load_table()
            self._ping("Eintrag entfernt.")
            return

        if not messagebox.askyesno("Löschen bestätigen", "Datei endgültig löschen?\n\n%s" % path):
            return

        # Löschen mit Fallback in _Archiv/_Trash
        try:
            os.remove(path)
        except Exception:
            try:
                trash = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "_Archiv", "_Trash"))
                os.makedirs(trash, exist_ok=True)
                shutil.move(path, os.path.join(trash, os.path.basename(path) + ".del"))
            except Exception:
                messagebox.showerror("Fehler", "Löschen fehlgeschlagen.")
                return

        try:
            self.cfg.remove_history(path)
        except Exception:
            pass
        self._load_table()
        self._ping("Gelöscht.")
'''
        src = src[:m.start()] + new_del + src[m.end():]
        changed = True

    # -----------------------------
    # 3) Spalten sicherstellen (name|ext|subfolder|date|time)
    # -----------------------------
    src2 = re.sub(
        r'cols\s*=\s*\([^\)]*\)',
        'cols = ("name","ext","subfolder","date","time")',
        src, count=1
    )
    if src2 != src:
        src = src2
        changed = True

    src2 = re.sub(
        r'for\s+c,w,a\s+in\s+\([^\)]*\):\s*\n\s*self\.tbl\.heading\(c,[^\n]+\n\s*self\.tbl\.column\(c,[^\n]+',
        'for c,w,a in (("name",240,"w"),("ext",70,"center"),("subfolder",220,"w"),("date",110,"center"),("time",90,"center")):\n            self.tbl.heading(c, text=c); self.tbl.column(c, anchor=a, width=w, stretch=(c!="ext"))',
        src, count=1
    )
    if src2 != src:
        src = src2
        changed = True

    if changed:
        backup_write(MOD, src)
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.38\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.38 (2025-10-18)
- Intake: Button [Löschen] repariert (Selektion oder aktueller Name).
- Intake: Rechte Liste zeigt die letzten 50 aus der ShrimpDev-History (mtime desc).
- Spalten fix: name | ext | subfolder | date | time.
""")
        log("Patch angewendet.")
        return 0
    else:
        log("Keine Änderungen nötig.")
        return 0

if __name__ == "__main__":
    raise SystemExit(patch())
