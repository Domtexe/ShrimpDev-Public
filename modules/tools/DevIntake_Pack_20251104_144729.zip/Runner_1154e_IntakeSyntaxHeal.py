# -*- coding: utf-8 -*-
"""
Runner_1154e_IntakeSyntaxHeal
Heilt kaputte Klassen-Ebene in modules/module_code_intake.py:
- Entfernt/kommentiert "orphanierte" Zeilen innerhalb class IntakeFrame
  (z.B. alleinstehendes "self", "try:" ohne except/finally, "pass(" usw.)
- Entfernt R1154c-Klassenfragmente (Toolbar-Block außerhalb einer Methode)
- Hängt Buttons am Ende von _build_ui() an (idempotent)
- Repariert _detect_guarded (kein Selbstaufruf; ruft _detect())
Sicher: Backup -> Write -> Syntaxcheck -> Import-Smoke -> Rollback
"""
from __future__ import annotations
import io, os, sys, time, shutil, re, ast, importlib.util, types, py_compile
from pathlib import Path

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1154e_IntakeSyntaxHeal_report.txt"

BUTTONS_BLOCK = r"""
        # R1154e: zusätzliche Toolbar-Buttons (idempotent; innerhalb _build_ui)
        try:
            parent = bar
        except Exception:
            parent = getattr(self, "toolbar", None)
        if parent:
            try:
                import tkinter.ttk as ttk
            except Exception:
                ttk = None
            if ttk:
                try:
                    if not hasattr(self, 'btn_clear_editor'):
                        self.btn_clear_editor = ttk.Button(parent, text='Editor leeren', command=self._on_clear_editor)
                        self.btn_clear_editor.grid(row=0, column=120, padx=(12,0), sticky='w')
                except Exception:
                    pass
                try:
                    if not hasattr(self, 'btn_delete_file'):
                        self.btn_delete_file = ttk.Button(parent, text='Datei löschen', command=self._on_delete_selected_file)
                        self.btn_delete_file.grid(row=0, column=121, padx=(6,0), sticky='w')
                except Exception:
                    pass
""".rstrip("\n")

def w(s=""):
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f: f.write(s.rstrip()+"\n")
    print(s)

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time()*1000)}.bak"
    shutil.copy2(p, dst); return dst

def _find_intake_span(lines: list[str]) -> tuple[int,int]:
    """gibt (start,end_exclusive) der class IntakeFrame zurück (indent-basiert, ohne AST)"""
    start = None
    for i,l in enumerate(lines):
        if re.match(r'^\s*class\s+IntakeFrame\b', l):
            start = i; break
    if start is None:
        raise RuntimeError("class IntakeFrame nicht gefunden.")
    # Ende: nächste class/def auf root-indentation (ohne Einrückung) oder EOF
    for j in range(start+1, len(lines)):
        if re.match(r'^\S', lines[j]) and not lines[j].strip().startswith('#'):
            return start, j
    return start, len(lines)

def _sanitize_orphans(cls_lines: list[str]) -> tuple[list[str], int]:
    """
    Kommentiert verdächtige Zeilen (orphanierte Statements) innerhalb der Klasse aus:
    - Zeilen mit genau 8 Spaces Einrückung, die NICHT mit def/cls-Header/@/#/""" beginnen
      und offensichtlich kein gültiger Blockstart sind (z.B. 'self', 'pass(', 'try:' ohne Block).
    """
    changed = 0
    out = cls_lines[:]
    for i, l in enumerate(out):
        s = l.rstrip("\n")
        # nur Ebene 8 Spaces (innerhalb Klasse, aber außerhalb Methodendef) betrachten
        if re.match(r'^\s{8}\S', s):
            if re.match(r'^\s{8}(def |class |@|#|"""|\'\'\')', s):
                continue
            if re.match(r'^\s{8}(try:|except\b|finally:|else:)\s*$', s):
                out[i] = re.sub(r'^(\s*)', r'\1# [R1154e orphan-block] ', s) + "\n"; changed += 1; continue
            if re.match(r'^\s{8}(self\b|pass\(|bar\b|parent\b)', s):
                out[i] = re.sub(r'^(\s*)', r'\1# [R1154e orphan] ', s) + "\n"; changed += 1; continue
    return out, changed

def _remove_r1154c_classblock(cls_src: str) -> tuple[str, int]:
    n = 0
    rx = re.compile(r'(?ms)^\s{8}#\s*R1154c:.*?(?=^\s{4}def\s+|\Z)')
    cls_src2, n = rx.subn("", cls_src)
    return cls_src2, n

def _inject_buttons_in_build_ui(src: str) -> tuple[str, bool]:
    tree = ast.parse(src)
    cls = next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name=="IntakeFrame"), None)
    if not cls: raise RuntimeError("class IntakeFrame nicht gefunden.")
    fn  = next((b for b in cls.body if isinstance(b, ast.FunctionDef) and b.name=="_build_ui"), None)
    if not fn:  raise RuntimeError("_build_ui() nicht gefunden.")
    lines = src.splitlines()
    s, e = fn.lineno-1, getattr(fn, "end_lineno", None) or (fn.lineno)
    body = "\n".join(lines[s:e])
    if "btn_clear_editor" in body or "btn_delete_file" in body:
        return src, False
    new_body = body.rstrip("\n") + "\n" + BUTTONS_BLOCK + "\n"
    new_src  = "\n".join(lines[:s]) + new_body + "\n".join(lines[e:])
    return new_src, True

def _fix_detect_guarded(src: str) -> tuple[str, bool]:
    rx_any = re.compile(r'(?ms)^\s{4}def\s+_detect_guarded\s*\([^)]*\):\s*.*?(?=^\s{4}def\s+|\Z)')
    if not rx_any.search(src): return src, False
    safe = (
        "    def _detect_guarded(self, *args, **kwargs):\n"
        "        \"\"\"\n"
        "        Ruft _detect sicher auf. Fängt alle Exceptions (inkl. Regex-Fehler) ab,\n"
        "        zeigt eine kurze Warnung und liefert False statt zu crashen.\n"
        "        \"\"\"\n"
        "        try:\n"
        "            return self._detect(*args, **kwargs)\n"
        "        except Exception as ex:\n"
        "            try:\n"
        "                self._ping(f\"DetectWarn: {ex}\")\n"
        "            except Exception:\n"
        "                pass\n"
        "            return False\n"
    )
    return rx_any.sub(safe, src, count=1), True

def import_smoke()->tuple[bool,str]:
    if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules"); sys.modules.setdefault("modules", pkg)
        mod = types.ModuleType("modules.module_runner_exec"); mod.run=lambda *a,**k:0; mod._log=lambda *a,**k:None
        sys.modules["modules.module_runner_exec"]=mod
    try:
        spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
        m = importlib.util.module_from_spec(spec); assert spec and spec.loader
        spec.loader.exec_module(m)  # type: ignore[attr-defined]
        return True, "Import OK"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"

def main()->int:
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass
    w("[R1154e] IntakeSyntaxHeal – Start")
    if not MODFILE.exists():
        w("[ERR] module_code_intake.py fehlt."); return 1

    bak = backup(MODFILE); w(f"[Backup] {bak.name}")
    src = io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()
    lines = src.splitlines(True)

    # Klasse IntakeFrame extrahieren und zeilenbasiert heilen
    try:
        s, e = _find_intake_span(lines)
    except Exception as ex:
        w(f"[ERR] Klasse nicht gefunden: {ex}"); return 1

    cls_lines = lines[s:e]
    cls_src0 = "".join(cls_lines)
    cls_src1, removed_r1154c = _remove_r1154c_classblock(cls_src0)
    cls_lines = cls_src1.splitlines(True)

    cls_lines2, orphan_cnt = _sanitize_orphans(cls_lines)
    if removed_r1154c or orphan_cnt:
        w(f"[Heal] Orphans auskommentiert: {orphan_cnt}, R1154c-Fragmente entfernt: {removed_r1154c}")

    healed = "".join(cls_lines2)
    new_src1 = "".join(lines[:s]) + healed + "".join(lines[e:])

    # Syntaxcheck 1 (sollte jetzt parsen)
    try:
        py_compile.compile(MODFILE, doraise=True)
    except Exception:
        # falls Dateisystem noch alt – in Speicher prüfen
        try:
            ast.parse(new_src1)
        except Exception as ex:
            w(f"[Syntax] Noch fehlerhaft nach Heal: {ex}")
            io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(new_src1)
            # zweiter Versuch Kompilieren
            try:
                py_compile.compile(MODFILE, doraise=True)
            except Exception as ex2:
                w(f"[Syntax] Fehler: {ex2} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    # Buttons in _build_ui, Guard fixen
    try:
        patched1, added = _inject_buttons_in_build_ui(new_src1)
    except SyntaxError:
        # falls noch Syntaxreste: schreibe und parse erneut
        io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(new_src1)
        patched1, added = _inject_buttons_in_build_ui(io.open(MODFILE,"r",encoding="utf-8").read())
    patched2, fixed_guard = _fix_detect_guarded(patched1)

    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(patched2)

    # finaler Syntaxcheck & Import
    try:
        py_compile.compile(MODFILE, doraise=True); w("[Syntax] OK")
    except Exception as e:
        w(f"[Syntax] Fehler: {e} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    ok, msg = import_smoke()
    if not ok:
        w(f"[Live] Probe-Fehler: {msg} -> Rollback"); shutil.copy2(bak, MODFILE); return 1
    w(f"[Live] {msg}")

    w(f"[SUM] Healed: orphans={orphan_cnt}, removed_r1154c={removed_r1154c}, added_buttons={added}, fixed_guard={fixed_guard}")
    w("[R1154e] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
