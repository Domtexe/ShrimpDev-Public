# -*- coding: utf-8 -*-
"""
R1166 IntakeTTK ScopeFix + Rules
Ziele:
- Intake reparieren: keine lokalen ttk-Imports/Zuweisungen in _build_ui(), stabile Toolbar-Referenzen.
- Masterregeln ergänzen (neue Datei unter docs/).

Änderungen (minimal-invasiv, idempotent):
1) Entfernt 'global ttk' innerhalb _build_ui (falls vorhanden).
2) Stellt sicher: nach 'bar = ttk.Frame(self)' existiert 'self.toolbar = bar' (wird eingefügt, falls fehlt).
3) Ersetzt den gesamten Block 'R1154g: zusätzliche Toolbar-Buttons …' durch eine ttk-neutrale, modulweite Variante
   (keine lokalen 'import tkinter.ttk as ttk', kein 'ttk = None', keine if-ttk-Wachstellen).
4) Schreibt docs/MASTERREGELN_ADDENDUM_2025-10-23.md mit den Regel-Ergänzungen.

Safety:
- Backup -> _Archiv
- Syntax-Check via py_compile, Rollback on error
"""
from __future__ import annotations
import io, re, time, shutil, py_compile, traceback, os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
DOCS = ROOT / "docs"
RULE = DOCS / "MASTERREGELN_ADDENDUM_2025-10-23.md"
LOGF = ROOT / "debug_output.txt"

ADDENDUM = """# Masterregeln – Addendum (2025-10-23)

## 1.4 GUI-Imports (NEU)
- Alle GUI-Toolkit-Imports (`tkinter`, `ttk`, `messagebox`, `filedialog` etc.) erfolgen **nur im Modulkopf**.
- In Funktionen/Methoden werden **keine** lokalen Re-Imports oder Zuweisungen an diese Namen durchgeführt.
- Motivation: Verhindert Scope-Konflikte wie `UnboundLocalError: local variable 'ttk' referenced before assignment`.

## 1.5 Toolbar-Referenzen (NEU)
- Der Toolbar-Container wird im Code **zentral** referenziert (z. B. `self.toolbar = bar`).
- Legacy-Attribute (z. B. `self.frm_actions`) dürfen als **Kompatibilitäts-Alias** auf die gleiche Instanz zeigen, aber nicht abweichen.

## 7.3 Log-Robustheit (Ergänzung)
- Logfiles dürfen nicht exklusiv gelockt werden. Beim Start darf ein offenes Log nicht zum Abbruch führen (Fallback/Retry).

## 12.3 Safe-Patches (Ergänzung)
- Runner müssen idempotent sein (mehrfaches Ausführen ohne Doppelinjektion).
- Vor jeder Änderung: Backup; nach Änderung: Syntax-Check; bei Fehlern: Rollback.
"""

R1154G_CLEAN = r"""
        # R1154g: zusätzliche Toolbar-Buttons (idempotent; innerhalb _build_ui)
        parent = bar if 'bar' in locals() else getattr(self, "toolbar", None)
        if parent:
            # Editor leeren (links)
            try:
                if not hasattr(self, 'btn_clear_editor'):
                    self.btn_clear_editor = ttk.Button(parent, text='Editor leeren', command=self._on_clear_editor)
                    self.btn_clear_editor.grid(row=0, column=0, padx=(12,0), sticky='w')
            except Exception:
                pass
            # Datei löschen (rechts)
            try:
                if not hasattr(self, 'btn_delete_file'):
                    self.btn_delete_file = ttk.Button(parent, text='Datei löschen', command=self._on_delete_selected_file)
                    self.btn_delete_file.grid(row=0, column=121, padx=(6,0), sticky='w')
            except Exception:
                pass
"""

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1166] {ts} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f: f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(p: Path) -> Path:
    ARCH.mkdir(parents=True, exist_ok=True)
    dst = ARCH / f"{p.name}.{int(time.time())}.bak"
    shutil.copy2(p, dst)
    log(f"Backup: {p} -> {dst}")
    return dst

def patch_source(src: str) -> tuple[str, list[str]]:
    changes: list[str] = []

    # 1) _build_ui block lokalisieren
    m_def = re.search(r"^\s*def\s+_build_ui\s*\(\s*self[^\)]*\)\s*:\s*$", src, re.M)
    if not m_def:
        return src, changes
    start = m_def.end()
    # Ende des Blocks = nächster 'def ..' auf linker Spalte
    m_next = re.search(r"^\s*def\s+\w+\s*\(", src[start:], re.M)
    end = start + (m_next.start() if m_next else len(src) - start)
    block = src[start:end]

    # 1a) 'global ttk' entfernen
    new_block = re.sub(r"^\s*global\s+ttk\s*\r?\n", "", block, flags=re.M)
    if new_block != block:
        changes.append("Removed 'global ttk' from _build_ui")
        block = new_block

    # 2) Nach 'bar = ttk.Frame(' -> 'self.toolbar = bar' sicherstellen
    m_bar = re.search(r"^(\s*)bar\s*=\s*ttk\.Frame\([^\)]*\)\s*$", block, re.M)
    if m_bar:
        indent = m_bar.group(1)
        after_bar_pos = m_bar.end()
        # Bereich bis zum nächsten 'def' innerhalb des Blocks
        tail = block[after_bar_pos:]
        # Prüfen, ob bereits self.toolbar = bar existiert
        if "self.toolbar = bar" not in tail[:200]:  # wenige Zeilen danach prüfen
            insert = f"\n{indent}self.toolbar = bar  # R1166: zentrale Toolbar-Referenz\n"
            block = block[:after_bar_pos] + insert + block[after_bar_pos:]
            changes.append("Inserted 'self.toolbar = bar' after toolbar creation")

        # Optionaler Kompatibilitätsalias: falls self.frm_actions = bar NICHT existiert, fügen wir ihn NICHT zwangsweise hinzu
        # (aktuell ist er vorhanden; wir lassen ihn unberührt)

    # 3) R1154g-Block ersetzen (lokale ttk-Imports raus)
    m_start = re.search(r"^\s*#\s*R1154g:\s*zusaetzliche\s+Toolbar-Buttons.*?$", block, re.M | re.I)
    if not m_start:
        m_start = re.search(r"^\s*#\s*R1154g:\s*zusätzliche\s+Toolbar-Buttons.*?$", block, re.M)
    if m_start:
        # Ende definieren: vor '# ---------- helpers ----------' oder vor 'self._intake_post_build_bind_clear'
        rest = block[m_start.start():]
        m_end = re.search(r"^\s*#\s*-{2,}\s*helpers\s*-{2,}\s*$", rest, re.M)
        if not m_end:
            m_end = re.search(r"^\s*self\._intake_post_build_bind_clear\(\)\s*$", rest, re.M)
        end_idx = (m_end.start() if m_end else len(rest))
        # Original-Indention übernehmen
        indent = re.match(r"^(\s*)", block[m_start.start():]).group(1)
        clean = "\n".join(indent + ln if ln.strip() else ln for ln in R1154G_CLEAN.rstrip("\n").splitlines()) + "\n"
        block = block[:m_start.start()] + clean + rest[end_idx:]
        changes.append("Replaced R1154g toolbar appendix with ttk-neutral version")

    # Reassembliere src
    new_src = src[:start] + block + src[end:]
    return new_src, changes

def write_rules():
    DOCS.mkdir(parents=True, exist_ok=True)
    RULE.write_text(ADDENDUM, encoding="utf-8")

def main() -> int:
    try:
        if not MOD.exists():
            log(f"[ERR] Not found: {MOD}"); return 2
        src = MOD.read_text(encoding="utf-8")
        bak = backup(MOD)
        new_src, changes = patch_source(src)

        if not changes:
            log("No changes applied (patterns not found).")
        else:
            MOD.write_text(new_src, encoding="utf-8", newline="\n")
            for c in changes: log(f"Change: {c}")
            try:
                py_compile.compile(str(MOD), doraise=True)
                log("Syntax-Check: OK")
            except Exception as ex:
                log(f"[ERR] Syntax-Check failed: {ex}")
                shutil.copy2(bak, MOD)
                log("Restored from backup.")
                return 3

        # Regeln schreiben (immer)
        try:
            write_rules()
            log(f"Wrote rules addendum: {RULE}")
        except Exception as ex:
            log(f"[WARN] Could not write rules addendum: {ex}")

        log("R1166 completed successfully.")
        return 0
    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
