from __future__ import annotations
from pathlib import Path
import re, shutil, time

ROOT = Path(r"D:\ShrimpDev")
TOOLS = ROOT / "tools"
MAIN  = ROOT / "main_gui.py"
VBS   = TOOLS / "start_quiet.vbs"
BATV  = TOOLS / "start_visible.bat"

def ts() -> str:
    return time.strftime("%Y%m%d_%H%M%S")

def backup(p: Path) -> Path:
    b = p.with_suffix(p.suffix + f".{ts()}.bak")
    shutil.copy2(p, b)
    return b

def patch_main_gui() -> bool:
    if not MAIN.exists(): 
        print("[R904] WARN main_gui.py fehlt"); 
        return False
    txt = MAIN.read_text(encoding="utf-8", errors="ignore")
    if "warnings.filterwarnings('ignore', category=SyntaxWarning)" in txt:
        return False
    # nach dem ersten nicht-leeren Import-Block einfügen
    lines = txt.splitlines(True)
    ins_idx = 0
    for i, line in enumerate(lines):
        if line.strip(): 
            ins_idx = i + 1
            break
    inject = (
        "import warnings\n"
        "warnings.filterwarnings('ignore', category=SyntaxWarning)\n"
    )
    backup(MAIN)
    lines.insert(ins_idx, inject)
    MAIN.write_text("".join(lines), encoding="utf-8")
    return True

def patch_vbs() -> bool:
    if not VBS.exists(): 
        print("[R904] INFO start_quiet.vbs nicht gefunden (übersprungen)")
        return False
    txt = VBS.read_text(encoding="utf-8", errors="ignore")
    if "-W ignore::SyntaxWarning" in txt:
        return False
    # zuerst gezielt ersetzen
    new = re.sub(
        r'(py\s+-3\s+)(-u\s+main_gui\.py)',
        r'\1-W ignore::SyntaxWarning \2',
        txt,
        flags=re.IGNORECASE
    )
    if new == txt:
        # Fallback: naive Ersetzung
        new = txt.replace("py -3 -u main_gui.py", "py -3 -W ignore::SyntaxWarning -u main_gui.py")
        new = new.replace("python -u main_gui.py", "python -W ignore::SyntaxWarning -u main_gui.py")
    if new != txt:
        backup(VBS)
        VBS.write_text(new, encoding="utf-8")
        return True
    return False

def patch_visible_bat() -> bool:
    if not BATV.exists(): 
        print("[R904] INFO start_visible.bat nicht gefunden (übersprungen)")
        return False
    txt = BATV.read_text(encoding="utf-8", errors="ignore")
    if "-W ignore::SyntaxWarning" in txt:
        return False
    new = re.sub(
        r'(%PY%\s+)-u\s+main_gui\.py',
        r'\1-W ignore::SyntaxWarning -u main_gui.py',
        txt,
        flags=re.IGNORECASE
    )
    if new != txt:
        backup(BATV)
        BATV.write_text(new, encoding="utf-8")
        return True
    # Fallback: direkte Zeile ersetzen, falls ohne %PY%
    new2 = txt.replace("py -3 -u main_gui.py", "py -3 -W ignore::SyntaxWarning -u main_gui.py")
    if new2 != txt:
        backup(BATV)
        BATV.write_text(new2, encoding="utf-8")
        return True
    return False

def main():
    changed = []
    if patch_main_gui():      changed.append("main_gui.py")
    if patch_vbs():           changed.append("tools\\start_quiet.vbs")
    if patch_visible_bat():   changed.append("tools\\start_visible.bat")

    if changed:
        print("[R904] Patched: " + ", ".join(changed))
        print("[R904] Backups: *.bak erstellt")
    else:
        print("[R904] Keine Änderungen nötig.")
    print("[R904] Neu starten via start_visible.bat oder start_quiet.bat")

if __name__ == "__main__":
    main()
