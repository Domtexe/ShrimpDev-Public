# -*- coding: utf-8 -*-
"""
Runner_1176a_IntakeShimUpgrade.py
Sicherer Patch für main_gui.py: integriert den Intake-Shim + Gates.
"""

from __future__ import annotations

import os
import re
import sys
import time
import py_compile


ROOT = r"D:\ShrimpDev"
MAIN = os.path.join(ROOT, "main_gui.py")
ARCH = os.path.join(ROOT, "_Archiv")
os.makedirs(ARCH, exist_ok=True)

HEADER = "# [1176a] IntakeShimUpgrade"
IMPORT_LINE = "from modules.module_shim_intake import mount_intake_tab"
HELPER_BLOCK = r'''
# === Auto-Helper: Intake-Shim (nicht löschen) ===
def _mount_intake_tab_shim(nb):
    try:
        tab = mount_intake_tab(nb)
        try:
            nb.add(tab, text="Code Intake")
        except Exception:
            # manche ttk.Notebook-Versionen wollen "window" first
            nb.add(tab, text="Code Intake")
        return True
    except Exception as _e:
        try:
            with open(r"D:\ShrimpDev\debug_output.txt","a",encoding="utf-8") as f:
                import traceback, time
                f.write("[IntakeShim %s] Mount-Fehler: %r\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), _e))
                traceback.print_exc(file=f)
        except Exception:
            pass
        return False
# === /Auto-Helper ===
'''.lstrip("\n")


def _backup(path: str) -> str:
    ts = time.strftime("%Y%m%d_%H%M%S")
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    with open(path, "r", encoding="utf-8") as fsrc, open(dst, "w", encoding="utf-8") as fdst:
        fdst.write(fsrc.read())
    return dst


def _insert_import(src: str) -> str:
    # Import hinter __future__-Block einfügen
    lines = src.splitlines()
    idx = 0
    while idx < len(lines) and lines[idx].startswith("from __future__"):
        idx += 1
    # weiter über Shebang/Encoding/Leerzeilen hinweg
    while idx < len(lines) and (lines[idx].strip() == "" or lines[idx].startswith("#") or lines[idx].startswith("import " ) or lines[idx].startswith("from ")):
        idx += 1
    # Wir fügen den Import *nach* future, aber *vor* erstem Code-Block ein — robust:
    if IMPORT_LINE not in src:
        lines.insert(idx, IMPORT_LINE)
    return "\n".join(lines)


def _ensure_helper(src: str) -> str:
    if "_mount_intake_tab_shim" in src:
        return src
    # Helper vor if __name__ == "__main__" oder am Ende
    m = re.search(r'(?m)^\s*if\s+__name__\s*==\s*["\']__main__["\']\s*:', src)
    if m:
        pos = m.start()
        return src[:pos] + HELPER_BLOCK + src[pos:]
    else:
        return src + "\n\n" + HELPER_BLOCK


def _replace_legacy_mounts(src: str) -> str:
    # Häufige Altvarianten entfernen/ersetzen:
    patterns = [
        r'nb\.add\s*\(\s*tab_intake\s*,\s*text\s*=\s*["\']Code Intake["\']\s*\)',
        r'nb\.add\s*\(\s*tab_intake\s*[,)]',
        r'nb\.add\s*\(\s*__mount_intake_tab_shim\(\s*nb\s*\)[^)]*\)',
        r'nb\.add\s*\(\s*__mount_intake_tab\(\s*nb\s*\)[^)]*\)',
    ]
    out = src
    for pat in patterns:
        out = re.sub(pat, r'_mount_intake_tab_shim(nb)', out)
    return out


def _ensure_mount_call(src: str) -> str:
    # Wenn nirgends Intake hinzugefügt wird, hänge den Aufruf vor mainloop an
    if "_mount_intake_tab_shim(" in src:
        return src

    # Suche typische Stelle, wo Notebook existiert:
    # Wir patchen robust: vor dem ersten "root.mainloop("
    m = re.search(r'(?m)^.*mainloop\s*\(', src)
    if not m:
        # kein mainloop gefunden: am Ende ranhängen
        return src + "\n\n# Auto-Call (kein mainloop gefunden)\n_mount_intake_tab_shim(nb)\n"
    pos = m.start()
    inject = "\n# Auto-Call Intake-Shim\n_mount_intake_tab_shim(nb)\n"
    return src[:pos] + inject + src[pos:]


def main() -> int:
    if not os.path.isfile(MAIN):
        print("[1176a] ERROR: main_gui.py nicht gefunden.")
        return 10

    backup = _backup(MAIN)
    print(f"[1176a] Backup erstellt: {backup}")

    with open(MAIN, "r", encoding="utf-8") as f:
        src = f.read()

    src = _insert_import(src)
    src = _ensure_helper(src)
    src = _replace_legacy_mounts(src)
    src = _ensure_mount_call(src)

    with open(MAIN, "w", encoding="utf-8") as f:
        f.write(src)

    # Smoke-Compile
    try:
        py_compile.compile(MAIN, doraise=True)
        print("[1176a] Syntax OK.")
        return 0
    except Exception as e:
        # Rollback bei Fehler
        with open(MAIN, "w", encoding="utf-8") as f:
            with open(backup, "r", encoding="utf-8") as fb:
                f.write(fb.read())
        print(f"[1176a] FEHLER -> Rollback: {e}")
        return 20


if __name__ == "__main__":
    raise SystemExit(main())
