# -*- coding: utf-8 -*-
"""
Runner_1153g_SafeRegexAllIntake
Ziel:
- In class IntakeFrame ALLE Vorkommen von `re.search(` sicher machen:
  -> Einfügen der Methode _re_search(self, pat, text)
  -> Ersetzen von `re.search(` durch `self._re_search(`
- Unabhängig vom Methodennamen (z.B. _guess_ext_from_text, _detect etc.)
- Sicher: Backup -> Write -> Syntax-Check -> Headless-Smoke -> Rollback

Report: _Reports/Runner_1153g_SafeRegexAllIntake_report.txt
"""
from __future__ import annotations
import io, os, sys, time, shutil, ast, importlib.util, types, re
from pathlib import Path
import py_compile

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1153g_SafeRegexAllIntake_report.txt"

def w(s=""):
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(s.rstrip()+"\n")
    print(s)

SAFE_SEARCH_METHOD = r'''
def _re_search(self, pat, text):
    """
    Sichere Regex-Suche: verhindert Crashs durch defekte Patterns.
    Bei re.error -> Meldung via _ping, None als Treffer.
    """
    try:
        import re
        return re.search(pat, text)
    except re.error as ex:
        try:
            self._ping(f"RegexWarn: {ex}")
        except Exception:
            pass
        return None
'''.strip("\n")

def backup(src: Path) -> Path:
    bak = ARCH / f"{src.name}.{int(time.time()*1000)}.bak"
    shutil.copy2(src, bak)
    return bak

def load() -> str:
    return io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

def save(txt: str):
    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(txt)

def patch_intake_safe_regex(txt: str) -> tuple[str, list[str]]:
    """
    - class IntakeFrame lokalisieren
    - _re_search einfügen/ersetzen
    - innerhalb des Klassen-Quellblocks ALLE 're.search(' -> 'self._re_search(' ersetzen
    """
    changes: list[str] = []
    tree = ast.parse(txt)
    cls = None
    for n in tree.body:
        if isinstance(n, ast.ClassDef) and n.name == "IntakeFrame":
            cls = n; break
    if not cls:
        raise RuntimeError("class IntakeFrame nicht gefunden.")

    lines = txt.splitlines()
    start = cls.lineno - 1
    end   = getattr(cls, "end_lineno", None) or len(lines)
    cls_src = "\n".join(lines[start:end])

    # 1) _re_search einfügen/ersetzen
    rx_method = re.compile(r'(?ms)^\s*def\s+_re_search\s*\([^)]*\):\s*(?:\n\s+.+?)(?=^\s*def\s+\w+\s*\(|\Z)')
    if rx_method.search(cls_src):
        cls_src = rx_method.sub("\n    " + SAFE_SEARCH_METHOD.replace("\n","\n    ") + "\n", cls_src, count=1)
        changes.append("replaced:_re_search")
    else:
        if not cls_src.endswith("\n"): cls_src += "\n"
        cls_src += "\n    " + SAFE_SEARCH_METHOD.replace("\n","\n    ") + "\n"
        changes.append("added:_re_search")

    # 2) global im Klassenblock re.search( ersetzen (nur wörtlich, kein compile)
    if "re.search(" in cls_src and "self._re_search(" not in cls_src:
        new_cls_src = cls_src.replace("re.search(", "self._re_search(")
        if new_cls_src != cls_src:
            cls_src = new_cls_src
            changes.append("patched:class_re_search_calls")
    else:
        # evtl. gibt es schon gemischte Varianten; trotzdem ersetzen wir sicher alle Vorkommen
        new_cls_src = cls_src.replace("re.search(", "self._re_search(")
        if new_cls_src != cls_src:
            cls_src = new_cls_src
            changes.append("patched:class_re_search_calls_mixed")

    new_txt = "\n".join(lines[:start]) + ("\n" if start else "") + cls_src + ("\n" if end < len(lines) else "") + "\n".join(lines[end:])
    return new_txt, changes

# ---- Smoke-Test: Import + minimaler Detect-Durchlauf
def import_intake_for_test():
    # sys.path robust
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    # Shim für optionales Modul
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules")
        mod = types.ModuleType("modules.module_runner_exec")
        mod.run = lambda *a, **k: 0
        mod._log = lambda *a, **k: None
        sys.modules.setdefault("modules", pkg)
        sys.modules["modules.module_runner_exec"] = mod

    spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
    m = importlib.util.module_from_spec(spec); assert spec and spec.loader
    spec.loader.exec_module(m)  # type: ignore[attr-defined]
    return m

def smoke()->tuple[bool,str]:
    import tkinter as tk
    try:
        m = import_intake_for_test()
        r = tk.Tk(); r.withdraw()
        fr = m.IntakeFrame(r)

        samples = [
            "@echo off\nrem t\n",                       # bat
            '{ "k": 1 }\n',                             # json
            "name: x\nsteps:\n  - run\n",               # yml
            "[x]\na=b\n",                               # ini
            "# h1\n- item\n",                           # md
            "import os\nif __name__=='__main__':\n"     # py
        ]
        for s in samples:
            fr.txt.delete("1.0","end"); fr.txt.insert("1.0", s)
            fr.var_name_manual = False; fr.var_ext_manual = False
            fr._detect()
        r.destroy()
        return True, "Smoke OK"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"

def main()->int:
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass

    w("[R1153g] SafeRegexAllIntake – Start")
    if not MODFILE.exists():
        w(f"[ERR] Datei fehlt: {MODFILE}")
        return 1

    bak = backup(MODFILE); w(f"[Backup] {bak.name}")
    txt = load()

    try:
        new_txt, changes = patch_intake_safe_regex(txt)
    except Exception as e:
        w(f"[ERR] Patch-Vorbereitung: {e}")
        return 1

    save(new_txt)
    w("[Write] " + (", ".join(changes) if changes else "keine Änderungen"))

    # Syntax
    try:
        py_compile.compile(str(MODFILE), doraise=True); w("[Syntax] OK")
    except Exception as e:
        w(f"[Syntax] Fehler: {e} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    # Smoke
    ok, msg = smoke()
    if not ok:
        w(f"[Live] Probe-Fehler: {msg} -> Rollback"); shutil.copy2(bak, MODFILE); return 1
    w(f"[Live] {msg}")

    w("[SUM] Alle re.search-Aufrufe in IntakeFrame sind nun safe-gewrappt.")
    w("[R1153g] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
