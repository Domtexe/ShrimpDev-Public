# -*- coding: utf-8 -*-
"""
Runner_1071_AddRunButton_PyExec
Ziel:
- Neuen Button "Ausführen (F5)" in die Intake-Toolbar einfügen
- Handler _on_click_run() implementieren:
    * speichert die Datei (.py)
    * ermittelt den Pfad (Name + Endung im Zielordner)
    * führt den Runner mit sys.executable aus
    * zeigt RC im Ping-Label an
- F5-Shortcut bindet auf _on_click_run()
- Keine Semikolons; saubere Zeilen; AST-Check
"""

from __future__ import annotations
import os, re, time, shutil, ast

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1071] {ts} {msg}\n")
    except Exception:
        pass

def rd(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f: return f.read()

def wr_with_backup(p: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bak)
    log(f"Backup: {p} -> {bak}")
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

def normalize(src: str) -> str:
    src = src.replace("\r\n", "\n").replace("\r", "\n")
    src = "\n".join(ln.rstrip(" \t") for ln in src.split("\n"))
    src = src.replace("\t", "    ")
    if not src.endswith("\n"): src += "\n"
    return src

def insert_run_button(src: str) -> tuple[str, int]:
    """
    Hängt den Run-Button in die vorhandene Toolbar 'bar'.
    Platzierung: vor dem Guard-Button falls vorhanden, sonst hinter btn_save.grid(...)
    """
    changed = 0
    s = src

    if "self.btn_run" in s:
        return s, 0

    # 1) Versuche vor Guard-Button einzufügen (schönste Position)
    pat_guard = re.compile(r'^([ \t]*)self\.btn_guard\s*=\s*ttk\.Button\([^)]*\)\s*$', re.MULTILINE)
    m = pat_guard.search(s)
    if m:
        indent = m.group(1)
        inject = (
            f"{indent}self.btn_run = ttk.Button(bar, text=\"Ausführen (F5)\", command=self._on_click_run)\n"
            f"{indent}self.btn_run.grid(row=0, column=98, padx=(4,0))\n"
        )
        s = s[:m.start()] + inject + s[m.start():]
        changed += 1
        log("Run-Button vor Guard-Button eingefügt.")
        return s, changed

    # 2) Fallback: hinter btn_save.grid(...) einfügen
    pat_save_grid = re.compile(r'^([ \t]*)self\.btn_save\s*\.\s*grid\s*\([^)]*\)\s*$', re.MULTILINE)
    m = pat_save_grid.search(s)
    if m:
        indent = m.group(1)
        inject = (
            f"{indent}self.btn_run = ttk.Button(bar, text=\"Ausführen (F5)\", command=self._on_click_run)\n"
            f"{indent}self.btn_run.grid(row=0, column=98, padx=(4,0))\n"
        )
        s = s[:m.end()] + "\n" + inject + s[m.end():]
        changed += 1
        log("Run-Button hinter Speichern eingefügt.")
        return s, changed

    log("WARN: Stelle für Run-Button nicht gefunden (btn_guard/btn_save.grid fehlen).")
    return s, changed

def bind_f5(src: str) -> tuple[str, int]:
    """Bindet <F5> auf _on_click_run() – nach vorhandenen Text-Bindings."""
    if re.search(r'bind\(\s*\"<F5>\"', src):
        return src, 0
    # suche typische Bindings um Einfügepunkt zu finden
    pat = re.compile(r'^([ \t]*)self\.txt\.bind\(\s*\"<Paste>\"[^)]*\)\s*$', re.MULTILINE)
    m = pat.search(src)
    if not m:
        # fallback: irgendein bind() auf self.txt
        pat2 = re.compile(r'^([ \t]*)self\.txt\.bind\([^)]*\)\s*$', re.MULTILINE)
        m = pat2.search(src)
    if m:
        indent = m.group(1)
        inject = f'{indent}self.txt.bind("<F5>", lambda _e: self._on_click_run())\n'
        s = src[:m.end()] + "\n" + inject + src[m.end():]
        log("F5-Binding auf _on_click_run() ergänzt.")
        return s, 1
    log("WARN: Kein Einfügepunkt für F5-Binding gefunden.")
    return src, 0

def ensure_run_handler(src: str) -> tuple[str, int]:
    """Ergänzt _on_click_run() wenn nicht vorhanden; robust ohne Projekt-Interna."""
    if re.search(r'^\s*def\s+_on_click_run\s*\(', src, re.MULTILINE):
        return src, 0

    # Einfügepunkt: innerhalb der IntakeFrame-Klasse, vor nächster Klasse oder am Ende der Klasse
    mcls = re.search(r'^\s*class\s+IntakeFrame\s*\(\s*ttk\.Frame\s*\)\s*:\s*$', src, re.MULTILINE)
    if not mcls:
        log("WARN: IntakeFrame nicht gefunden – Run-Handler kann nicht eingefügt werden.")
        return src, 0
    cls_start = mcls.end()
    mnext = re.search(r'^\s*class\s+[A-Za-z_]\w*\s*\(', src[cls_start:], re.MULTILINE)
    insert_pos = cls_start + (mnext.start() if mnext else len(src) - cls_start)

    code = (
        "\n"
        "    def _on_click_run(self):\n"
        "        \"\"\"Speichert und führt den aktuellen Runner (.py) aus.\"\"\"\n"
        "        try:\n"
        "            import os, sys, subprocess\n"
        "            # zuerst speichern\n"
        "            try:\n"
        "                self._on_click_save()\n"
        "            except Exception:\n"
        "                pass\n"
        "            # Name + Endung + Zielordner ermitteln\n"
        "            name = getattr(self, 'var_name', None)\n"
        "            name = name.get().strip() if name else ''\n"
        "            extv = getattr(self, 'var_ext', None)\n"
        "            ext  = extv.get().strip() if extv else '.py'\n"
        "            if not ext:\n"
        "                ext = '.py'\n"
        "            if not ext.startswith('.'):\n"
        "                ext = '.' + ext\n"
        "            tgtv = getattr(self, 'var_target', None)\n"
        "            if tgtv and tgtv.get().strip():\n"
        "                folder = tgtv.get().strip()\n"
        "            else:\n"
        "                folder = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tools'))\n"
        "            if not name:\n"
        "                self._ping('Kein Dateiname – Bitte Namen angeben.')\n"
        "                return\n"
        "            path = os.path.join(folder, name + ext)\n"
        "            self._ping('Starte…')\n"
        "            rc = subprocess.call([sys.executable, path], cwd=folder)\n"
        "            self._ping(f'Fertig (RC={rc})')\n"
        "        except Exception as ex:\n"
        "            try:\n"
        "                self._ping(f'Ausführen-Fehler: {ex}')\n"
        "            except Exception:\n"
        "                pass\n"
    )
    s = src[:insert_pos] + code + src[insert_pos:]
    log("Handler _on_click_run() ergänzt.")
    return s, 1

def main() -> int:
    if not os.path.exists(MOD):
        log(f"Datei fehlt: {MOD}")
        return 2
    src0 = rd(MOD)
    s = normalize(src0)

    total = 0
    s, n = insert_run_button(s); total += n
    s, n = bind_f5(s);          total += n
    s, n = ensure_run_handler(s); total += n

    # AST-Check
    try:
        ast.parse(s)
    except SyntaxError as e:
        log(f"SyntaxError nach Patch: {e} (line {e.lineno}, col {e.offset})")
        lines = s.split("\n")
        a, b = max(1, (e.lineno or 1)-12), min(len(lines), (e.lineno or 1)+12)
        log("--- DUMP ---")
        for i in range(a, b+1):
            vis = lines[i-1].replace("\t", "→").replace(" ", "·")
            log(f"{i:04d}: {vis}")
        log("--- END DUMP ---")
        return 3

    if total == 0 and s == src0:
        log("Keine Änderungen nötig.")
        return 0

    wr_with_backup(MOD, s)
    log(f"Patch gespeichert. Änderungen: {total}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
