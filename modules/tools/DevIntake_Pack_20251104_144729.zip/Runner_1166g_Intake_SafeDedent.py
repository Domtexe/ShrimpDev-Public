# -*- coding: utf-8 -*-
"""
R1166g Intake SafeDedent
------------------------------------
Mastermodus-Fix für module_code_intake.py
Ziel: korrigiert die zu tiefe Einrückung im helpers-Block von _build_ui().

Schritte:
 1. Backup anlegen
 2. Funktionsblock _build_ui extrahieren
 3. Kommentar "# ---------- helpers ----------" und Folgezeilen dedentieren auf 4 Spaces
 4. Syntaxprüfung mit py_compile
 5. Backup-Rollback bei Fehler
 6. Masterregel §12.5 ergänzen (Indentation-Deduplikation)

Ergebnis: Intake startet wieder sichtbar.
"""
from __future__ import annotations
import io, re, time, shutil, py_compile, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
DOCS = ROOT / "docs"
RULE = DOCS / "MASTERREGELN_ADDENDUM_2025-10-23.md"
LOGF = ROOT / "debug_output.txt"

ADDENDUM = """# Masterregeln – Addendum (2025-10-23)

## §12.5 Indentation-Deduplikation und Struktur-Erhaltung
- Einrückungsfehler dürfen nur durch **deduktive Analyse** korrigiert werden, niemals durch blindes Regex-Patching.
- `_build_ui()`-ähnliche Blöcke müssen auf **Basisindent 4 Spaces** enden.
- `# ---------- helpers ----------` markiert das Funktionsende und darf nie auf tieferem Indent stehen.
- Nach jedem Patch erfolgt Syntax-Check und Log.
"""

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1166g] {ts} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f: f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(p: Path) -> Path:
    ARCH.mkdir(parents=True, exist_ok=True)
    dst = ARCH / f"{p.name}.{int(time.time())}.bak"
    shutil.copy2(p, dst)
    log(f"Backup: {p} -> {dst}")
    return dst

def patch_source(src: str) -> tuple[str, list[str]]:
    changes: list[str] = []

    # Nur _build_ui analysieren
    m_def = re.search(r"^(\s*)def\s+_build_ui\s*\(", src, re.M)
    if not m_def:
        return src, changes
    func_indent = m_def.group(1)
    start = m_def.end()
    m_next = re.search(r"^\s*def\s+\w+\s*\(", src[start:], re.M)
    end = start + (m_next.start() if m_next else len(src)-start)
    block = src[start:end]

    # Suche nach helpers-Block mit zu tiefer Einrückung
    pattern = re.compile(
        r"^(?P<indent>\s{6,8})#\s*-{2,}\s*helpers\s*-{2,}\s*$", re.M)
    m = pattern.search(block)
    if not m:
        return src, changes

    bad_indent = m.group("indent")
    good_indent = func_indent + "    "  # Basisindent (4)
    lines = block.splitlines()
    new_lines = []
    dedented = False
    for line in lines:
        if line.startswith(bad_indent) and (
            "# ---------- helpers" in line or "_intake_post_build_bind_clear" in line
        ):
            new_lines.append(line.replace(bad_indent, good_indent, 1))
            dedented = True
        else:
            new_lines.append(line)
    if dedented:
        changes.append("Dedented helpers-block (to 4 spaces)")
        block = "\n".join(new_lines)

    new_src = src[:start] + block + src[end:]
    return new_src, changes

def write_rules():
    DOCS.mkdir(parents=True, exist_ok=True)
    RULE.write_text(ADDENDUM, encoding="utf-8")

def main() -> int:
    try:
        if not MOD.exists():
            log("[ERR] module_code_intake.py not found.")
            return 2
        src = MOD.read_text(encoding="utf-8")
        bak = backup(MOD)
        new_src, changes = patch_source(src)
        if not changes:
            log("No changes applied (already dedented).")
            return 0
        MOD.write_text(new_src, encoding="utf-8", newline="\n")

        try:
            py_compile.compile(str(MOD), doraise=True)
            log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax check failed: {ex}")
            shutil.copy2(bak, MOD)
            log("Restored from backup.")
            return 3

        write_rules(); log(f"Wrote rule addendum: {RULE}")
        log("R1166g completed successfully.")
        return 0
    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
