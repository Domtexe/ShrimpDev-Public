"""
Runner_1056_FixIndent_OnEditorModified_Strict
- Repariert Indentation von _on_editor_modified() in modules/module_code_intake.py
- Normalisiert Tabs -> 4 Spaces im Klassenblock
- Erzwingt eine kanonische Implementierung innerhalb von IntakeFrame

Version: v9.9.46
"""
from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

CANON = (
    "    def _on_editor_modified(self, _evt=None):\n"
    "        \"\"\"Editor-Change: Flag zurücksetzen und Detect schedulen.\"\"\"\n"
    "        try:\n"
    "            self.txt.edit_modified(False)\n"
    "        except Exception:\n"
    "            pass\n"
    "        self._schedule_detect(300)\n"
    "\n"
)

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1056] {ts} {msg}\n")
    except Exception:
        pass

def rd(p): 
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def wr(p, s):
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(s)

def backup(p):
    os.makedirs(ARCH, exist_ok=True)
    b = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, b)
    log(f"Backup: {p} -> {b}")

def patch():
    src = rd(MOD)
    original = src

    # 0) Tabs -> Spaces (nur innerhalb Klasse IntakeFrame)
    cls_m = re.search(r"(class\s+IntakeFrame\(ttk\.Frame\):[\s\S]+?)\Z", src, re.MULTILINE)
    if not cls_m:
        log("IntakeFrame nicht gefunden.")
        return 1
    before = src[:cls_m.start()]
    body   = cls_m.group(1)
    body   = body.replace("\t", "    ")

    # 1) bestehenden _on_editor_modified-Block entfernen/ersetzen (egal welche Einrückung)
    pat = re.compile(r"\n\s*def\s+_on_editor_modified\([^\)]*\):[\s\S]*?(?=\n\s*def\s+|\Z)", re.MULTILINE)
    if pat.search(body):
        body = pat.sub("\n" + CANON, body, count=1)
    else:
        # hinter _on_editor_key oder _on_editor_paste einfügen
        anchor = re.search(r"\n\s*def\s+_on_editor_key\([^\)]*\):[\s\S]*?(?=\n\s*def\s+|\Z)", body, re.MULTILINE)
        if not anchor:
            anchor = re.search(r"\n\s*def\s+_on_editor_paste\([^\)]*\):[\s\S]*?(?=\n\s*def\s+|\Z)", body, re.MULTILINE)
        if anchor:
            ins = anchor.end()
            body = body[:ins] + "\n" + CANON + body[ins:]
        else:
            # Fallback: am Ende der Klasse einfügen
            if not body.endswith("\n"):
                body += "\n"
            body += CANON

    src = before + body

    if src != original:
        backup(MOD)
        wr(MOD, src)
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.46\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.46 (2025-10-18)
- Intake: _on_editor_modified() strikt neu gesetzt (Indent fix + stabiler Body); Tabs→Spaces im Klassenblock.
""")
        log("Patch angewendet.")
        return 0
    else:
        log("Keine Änderungen nötig.")
        return 0

if __name__ == "__main__":
    raise SystemExit(patch())
