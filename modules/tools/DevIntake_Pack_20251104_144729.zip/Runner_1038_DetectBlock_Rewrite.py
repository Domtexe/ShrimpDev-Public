"""
Runner_1038_DetectBlock_Rewrite
- Schreibt den kompletten _detect()-Block robust neu (keine losen 'except', saubere Indents).
- Sichert Helper (_guess_ext_from_text, _guess_name_from_text) und Name/Ext-Flags.
- Normiert Tabs -> 4 Spaces im betroffenen Bereich.
- Version -> v9.9.27
"""
from __future__ import annotations
import os, re, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1038] {ts} {msg}\n")
    except Exception:
        pass

DETECT_NEW = r'''
    def _detect(self):
        """
        Erkennung der Endung + optional des Dateinamens.
        1) Endung aus Namensfeld
        2) Sonst Text lesen (sicher), Name aus Text erraten (wenn Name nicht manuell),
           und Endung aus Text heuristisch bestimmen.
        Hinweis: Manuelle Endung (var_ext_manual=True) wird nicht überschrieben.
        """
        import os
        name = (self.var_name.get() or "").strip()
        nm, ext_from_name = os.path.splitext(name) if name else ("", "")
        ext_from_name = (ext_from_name or "").lower()

        ext = ext_from_name

        # Inhalt sicher holen (kein GUI-Abbruch)
        try:
            content = self.txt.get("1.0", "end-1c")
        except Exception:
            content = ""

        # Name aus Text übernehmen, aber nur wenn nicht manuell editiert
        if not getattr(self, "var_name_manual", False):
            try:
                nm_guess, ext_guess = self._guess_name_from_text(content)
            except Exception:
                nm_guess, ext_guess = "", ""
            if nm_guess:
                self.var_name.set(nm_guess + (ext_guess or ""))
                # Wenn Ext noch leer und kein Ext-Override aktiv, aus Guess übernehmen
                if not getattr(self, "var_ext_manual", False) and not ext:
                    ext = (ext_guess or "").lower()

        # Falls immer noch keine Ext: aus Text heuristisch bestimmen
        if not ext:
            try:
                ext = (self._guess_ext_from_text(content) or "").lower()
            except Exception:
                ext = ""

        # Manuelle Endung respektieren (normalisieren)
        if not getattr(self, "var_ext_manual", False):
            self.var_ext.set(ext)
        else:
            try:
                self._normalize_ext()
                ext = (self.var_ext.get() or "").lower()
            except Exception:
                pass

        allowed = {".py",".bat",".cmd",".json",".txt",".yml",".yaml",".ini",".md",".shcut"}
        ok = bool(ext) and (ext in allowed or (ext == "" and not self.var_ext_manual))

        try:
            self._update_led(self.led_detect, "green" if ok else "yellow")
            self._ping(f"Erkennung: {(ext or '(keine)')}")
        except Exception:
            pass
        return ok
'''

HELPER_NAME = r'''
    def _guess_name_from_text(self, text: str) -> tuple[str, str]:
        """
        Sucht im Text nach üblichen Namensmustern und gibt (name, ext) zurück.
        Beispiele:
          - tools\Runner_1035_Something.py
          - Runner_992_Test.bat
          - py -3 tools\Runner_1000_X.py
          - call tools\Runner_1000_X.bat
          - :: Name: Runner_123_ABC.py    ;  # Name: Runner_123_ABC.py
          - set NAME=Runner_123_ABC.bat
        """
        import re
        t = text or ""
        m = re.search(r'(?i)tools[\\/](Runner_[0-9]{3,4}[_A-Za-z0-9\-]+)\.(py|bat|cmd)', t)
        if m: return m.group(1), "."+m.group(2).lower()
        m = re.search(r'(?i)\b(Runner_[0-9]{3,4}[_A-Za-z0-9\-]+)\.(py|bat|cmd)\b', t)
        if m: return m.group(1), "."+m.group(2).lower()
        m = re.search(r'(?i)\bpy(?:\s+-3)?\s+tools[\\/](Runner_[^ \r\n\t]+)\.(py)\b', t)
        if m: return m.group(1), ".py"
        m = re.search(r'(?i)\bcall\s+tools[\\/](Runner_[^ \r\n\t]+)\.(bat|cmd)\b', t)
        if m: return m.group(1), "."+m.group(2).lower()
        m = re.search(r'(?im)^[;#:\- ]+\s*name\s*[:=]\s*(Runner_[0-9]{3,4}[_A-Za-z0-9\-]+)\.(py|bat|cmd)\s*$', t)
        if m: return m.group(1), "."+m.group(2).lower()
        m = re.search(r'(?im)^\s*set\s+name\s*=\s*(Runner_[0-9]{3,4}[_A-Za-z0-9\-]+)\.(py|bat|cmd)\s*$', t)
        if m: return m.group(1), "."+m.group(2).lower()
        return "", ""
'''

HELPER_EXT = r'''
    def _guess_ext_from_text(self, text: str) -> str:
        """Rate Endung aus Text (.bat/.py/.json/.yml/.ini/.md) – oder ''."""
        import re, json
        t = (text or "").lstrip()
        head = t[:4000]
        if re.search(r"(?im)^\s*@echo\s+off\b", head) or re.search(r"(?im)^\s*rem\s", head):
            return ".bat"
        if re.search(r"(?im)^#!.*python", head):
            return ".py"
        if re.search(r"(?m)^\s*(from\s+\w+\s+import|import\s+\w+|def\s+\w+\(|class\s+\w+\(|if\s+__name__\s*==\s*['\"]__main__['\"])"," "+head):
            return ".py"
        try:
            if head and head.strip()[0] in "{[":
                json.loads(head)
                return ".json"
        except Exception:
            pass
        if re.search(r"(?m)^\s*-\s+\w+", head) or re.search(r"(?m)^\s*\w+:\s+.+", head):
            return ".yml"
        if re.search(r"(?m)^\s*\[[^\]]+\]\s*$", head) and re.search(r"(?m)^\s*\w+\s*=", head):
            return ".ini"
        if re.search(r"(?m)^\s*#\s+\w+", head):
            return ".md"
        return ""
'''

def ensure_helpers(src: str) -> str:
    if "def _guess_name_from_text(" not in src:
        ins = src.find("\n    # ---------- actions ----------")
        if ins == -1: ins = len(src)
        src = src[:ins] + HELPER_NAME + src[ins:]
    if "def _guess_ext_from_text(" not in src:
        ins = src.find("\n    # ---------- actions ----------")
        if ins == -1: ins = len(src)
        src = src[:ins] + HELPER_EXT + src[ins:]
    # Flags für Name/Ext-Manual sicherstellen (falls noch nicht vorhanden)
    if "self.var_name_manual" not in src:
        src = src.replace(
            "self.var_name = tk.StringVar(value=\"\")",
            "self.var_name = tk.StringVar(value=\"\")\n        self.var_name_manual = False"
        )
    return src

def rewrite_detect(src: str) -> str:
    # Tabs -> 4 Spaces (nur im _detect-Block relevant)
    src = src.replace("\t", "    ")

    # vorhandenen _detect-Block ersetzen
    m = re.search(r"def\s+_detect\([\s\S]+?\n\s*return\s+ok\s*\n", src, flags=re.MULTILINE)
    if m:
        src = src[:m.start()] + DETECT_NEW + src[m.end():]
    else:
        # Falls _detect fehlt, am Actions-Anchor einfügen
        ins = src.find("\n    # ---------- actions ----------")
        if ins == -1: ins = len(src)
        src = src[:ins] + DETECT_NEW + src[ins:]
    return src

def write_version():
    with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
        f.write("ShrimpDev v9.9.27\n")
    with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
        f.write("""
## v9.9.27 (2025-10-18)
- _detect() vollständig neu aufgebaut (sicherer content-Read, Name- und Ext-Erkennung, korrekte try/except).
- Tabs im Bereich entfernt; Helpers sichergestellt.
""")

def main() -> int:
    try:
        with open(MOD, "r", encoding="utf-8") as f:
            src = f.read()
        src2 = ensure_helpers(src)
        src3 = rewrite_detect(src2)
        if src3 != src:
            os.makedirs(ARCH, exist_ok=True)
            bck = os.path.join(ARCH, f"module_code_intake.py.{int(time.time())}.bak")
            shutil.copy2(MOD, bck)
            with open(MOD, "w", encoding="utf-8", newline="\r\n") as f:
                f.write(src3)
            log(f"Backup: {MOD} -> {bck}")
            log("_detect neu geschrieben; Helpers/Flags gesichert.")
        else:
            log("Keine Änderungen nötig.")

        write_version()
        return 0
    except Exception:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write("[R1038] FEHLER:\n" + traceback.format_exc() + "\n")
        print("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
