"""
Runner_1036_NameDetect_FromCode
- Fügt Namens-Erkennung aus dem Editor-Text hinzu (Runner_XXXX_*.*, tools\Runner_*.ext etc.)
- Setzt Name nur, wenn Nutzer das Namensfeld NICHT manuell überschrieben hat (name_manual)
- Verbindet Detect-Button damit (Name + Ext werden zusammen erkannt)
- Version -> v9.9.26
"""
from __future__ import annotations
import os, re, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1036] {ts} {msg}\n")
    except Exception:
        pass
    print(msg, flush=True)

def backup_write(path: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

def patch() -> int:
    with open(MOD, "r", encoding="utf-8") as f:
        src = f.read()

    changed = False

    # 1) name_manual-Flag & Binding am Name-Entry
    if "self.var_name_manual" not in src:
        src = src.replace(
            "self.var_name = tk.StringVar(value=\"\")",
            "self.var_name = tk.StringVar(value=\"\")\n        self.var_name_manual = False"
        )
        changed = True
    # Binding (KeyRelease) hinzufügen
    src = re.sub(
        r'(ent_name\s*=\s*ttk\.Entry\([^)]*textvariable=self\.var_name[^)]*\))',
        r'\1\n        ent_name.bind("<KeyRelease>", self._on_name_edited)',
        src
    )

    if "def _on_name_edited(" not in src:
        insert_pt = src.find("\n    # ---------- actions ----------")
        helper = r'''
    # --- name-manual helper ---
    def _on_name_edited(self, _evt=None):
        """Nutzer tippt im Namensfeld -> Name gilt als manuell; LED gelb."""
        self.var_name_manual = True
        try:
            self._update_led(self.led_detect, "yellow")
        except Exception:
            pass
'''
        src = src[:insert_pt] + helper + src[insert_pt:]
        changed = True

    # 2) Name aus Text erraten
    if "def _guess_name_from_text(" not in src:
        insert_pt = src.find("\n    # ---------- actions ----------")
        guess = r'''
    def _guess_name_from_text(self, text: str) -> tuple[str, str]:
        """
        Sucht im Text nach üblichen Namensmustern und gibt (name, ext) zurück.
        Beispiele, die erkannt werden:
          - tools\Runner_1035_Something.py
          - tools/Runner_1035_Something.py
          - Runner_992_Test.bat
          - py -3 tools\Runner_1000_X.py
          - CALL tools\Runner_1000_X.bat
          - :: Name: Runner_123_ABC.py  (Kommentar-Hinweis)
          - set NAME=Runner_123_ABC.bat (Batch)
        """
        import re, os
        t = text or ""
        # 1) direkte Tools-Pfade
        m = re.search(r'(?i)tools[\\/](Runner_[0-9]{3,4}[_A-Za-z0-9\-]+)\.(py|bat|cmd)', t)
        if m:
            return m.group(1), "."+m.group(2).lower()
        # 2) nackte Runner-Dateien
        m = re.search(r'(?i)\b(Runner_[0-9]{3,4}[_A-Za-z0-9\-]+)\.(py|bat|cmd)\b', t)
        if m:
            return m.group(1), "."+m.group(2).lower()
        # 3) py-Aufruf
        m = re.search(r'(?i)\bpy(?:\s+-3)?\s+tools[\\/](Runner_[^ \r\n\t]+)\.(py)\b', t)
        if m:
            return m.group(1), ".py"
        # 4) call-Aufruf
        m = re.search(r'(?i)\bcall\s+tools[\\/](Runner_[^ \r\n\t]+)\.(bat|cmd)\b', t)
        if m:
            return m.group(1), "."+m.group(2).lower()
        # 5) Kommentar-Hinweis
        m = re.search(r'(?im)^[;#:\- ]+\s*name\s*[:=]\s*(Runner_[0-9]{3,4}[_A-Za-z0-9\-]+)\.(py|bat|cmd)\s*$', t)
        if m:
            return m.group(1), "."+m.group(2).lower()
        # 6) Batch-Variable
        m = re.search(r'(?im)^\s*set\s+name\s*=\s*(Runner_[0-9]{3,4}[_A-Za-z0-9\-]+)\.(py|bat|cmd)\s*$', t)
        if m:
            return m.group(1), "."+m.group(2).lower()
        return "", ""
'''
        src = src[:insert_pt] + guess + src[insert_pt:]
        changed = True

    # 3) Detect anreichern: Name aus Text übernehmen, wenn Name leer/nicht manuell
    detect_pat = re.compile(r"def\s+_detect\([\s\S]+?^\s*return\s+ok\s*$", re.MULTILINE)
    m = detect_pat.search(src)
    if m:
        block = m.group(0)
        if "_guess_name_from_text" not in block:
            block = block.replace(
                "content = self.txt.get(\"1.0\",\"end-1c\")",
                "content = self.txt.get(\"1.0\",\"end-1c\")\n            # Name aus Text ermitteln (falls erlaubt)\n            if not getattr(self, \"var_name_manual\", False):\n                nm_guess, ext_guess = self._guess_name_from_text(content)\n                if nm_guess:\n                    self.var_name.set(nm_guess + (ext_guess or \"\"))\n                    if not getattr(self, \"var_ext_manual\", False) and ext == \"\":\n                        ext = ext_guess or ext"
            )
            src = src[:m.start()] + block + src[m.end():]
            changed = True

    if changed:
        backup_write(MOD, src)
        log("Name-Detect aus Code integriert (Bindings, Helper, Detect-Erweiterung).")
    else:
        log("Keine Änderungen nötig (Name-Detect bereits vorhanden).")

    # Meta
    with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
        f.write("ShrimpDev v9.9.26\n")
    with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
        f.write("""
## v9.9.26 (2025-10-18)
- Detect: Dateiname wird aus Code-Text erkannt (Runner_XXXX_*.ext, tools\\Runner_*.ext, py/call-Aufrufe, Kommentar/SET name)
- Name wird nur gesetzt, wenn nicht manuell editiert; Ext-Override bleibt respektiert
""")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(patch())
    except Exception:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write("[R1036] FEHLER:\n" + traceback.format_exc() + "\n")
        print("FEHLER:\n" + traceback.format_exc())
        raise
