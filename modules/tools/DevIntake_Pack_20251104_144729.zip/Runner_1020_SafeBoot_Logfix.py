"""
Runner_1020_SafeBoot_Logfix
- behebt NameError: _ex → ex in main_gui.py (SafeBoot-Block)
- erweitert logger_snippet um Retry bei PermissionError
- Version -> v9.9.11
"""
import os, re, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
LOG = os.path.join(ROOT, "debug_output.txt")
MAIN = os.path.join(ROOT, "main_gui.py")
LOGGER = os.path.join(ROOT, "modules", "snippets", "logger_snippet.py")

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1020] {ts} {msg}\n")
    print(msg)

def backup_write(path, data):
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

def patch_main():
    with open(MAIN, "r", encoding="utf-8") as f:
        src = f.read()
    new_src = src.replace("type(_ex), _ex", "type(ex), ex")
    if new_src != src:
        backup_write(MAIN, new_src)
        log("main_gui.py: _ex → ex korrigiert (SafeBoot).")
    else:
        log("main_gui.py: keine _ex-Vorkommen gefunden.")
    return new_src != src

def patch_logger():
    with open(LOGGER, "r", encoding="utf-8") as f:
        src = f.read()
    if "PermissionError" in src and "for _ in range" in src:
        log("logger_snippet.py: Retry bereits vorhanden.")
        return False
    pat = re.sub(
        r"with open\(LOG_PATH, \"a\", encoding=\"utf-8\"\) as f:\s*\n\s*f\.write\(msg",
        (
            "for _ in range(5):\n"
            "        try:\n"
            "            with open(LOG_PATH, 'a', encoding='utf-8') as f:\n"
            "                f.write(msg)\n"
            "            break\n"
            "        except PermissionError:\n"
            "            time.sleep(0.1)"
        ),
        src
    )
    if pat != src:
        backup_write(LOGGER, pat)
        log("logger_snippet.py: Retry bei PermissionError ergänzt.")
        return True
    return False

def main():
    try:
        changed = patch_main()
        changed |= patch_logger()
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.11\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.11 (2025-10-18)
- FIX: SafeBoot NameError _ex→ex behoben
- logger_snippet: Retry bei PermissionError
""")
        log("Patch abgeschlossen.")
        return 0
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
