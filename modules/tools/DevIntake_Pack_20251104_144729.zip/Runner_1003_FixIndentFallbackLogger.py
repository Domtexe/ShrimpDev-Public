"""
Runner_1003_FixIndentFallbackLogger
Behebt IndentationError im Fallback-Logger-Block in main_gui.py
und prüft, ob Snippets sauber importierbar sind.
Version -> v9.8.5
"""
from __future__ import annotations
import os, time, shutil, importlib.util, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1003] {ts} {msg}\n")
    print(msg, flush=True)

def safe_write(path: str, data: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        os.makedirs(ARCH, exist_ok=True)
        bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
        shutil.copy2(path, bck)
        log(f"Backup: {path} -> {bck}")
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

def patch():
    try:
        gpath = os.path.join(ROOT, "main_gui.py")
        with open(gpath, "r", encoding="utf-8") as f:
            src = f.read()

        # korrigierter Einfügeblock mit richtiger Einrückung
        correct_block = (
            "try:\n"
            "    from modules.snippets.logger_snippet import write_log\n"
            "except Exception:\n"
            "    def _fallback_write_log(prefix: str, msg: str) -> None:\n"
            "        import os, time\n"
            "        root = os.path.abspath(os.path.dirname(__file__))\n"
            "        logp = os.path.join(root, 'debug_output.txt')\n"
            "        ts = time.strftime('%Y-%m-%d %H:%M:%S')\n"
            "        try:\n"
            "            with open(logp, 'a', encoding='utf-8') as f:\n"
            "                f.write(f'[{prefix}] {ts} {msg}\\n')\n"
            "        except Exception:\n"
            "            pass\n"
            "    write_log = _fallback_write_log"
        )

        # Suche alte fehlerhafte Variante und ersetze
        if "def _fallback_write_log" in src and "except Exception:" in src:
            start = src.find("except Exception:")
            end = src.find("write_log = _fallback_write_log", start)
            if end != -1:
                old_block = src[start:end + len("write_log = _fallback_write_log")]
                src = src.replace(old_block, correct_block)
                log("Fallback-Block ersetzt (Indent korrigiert).")
        else:
            # Wenn kein Fallback existiert, hinzufügen
            src = src.replace(
                "from modules.snippets.logger_snippet import write_log",
                correct_block
            )
            log("Fallback-Block neu eingefügt.")

        src = src.replace("ShrimpDev – v9.8.4", "ShrimpDev – v9.8.5")
        safe_write(gpath, src)

        # Importtest
        test_mods = [
            "modules.snippets.logger_snippet",
            "modules.snippets.file_detect_snippet"
        ]
        for mod in test_mods:
            ok = importlib.util.find_spec(mod)
            log(f"Check {mod}: {'OK' if ok else 'FEHLT'}")

        safe_write(os.path.join(ROOT, "CURRENT_VERSION.txt"), "ShrimpDev v9.8.5\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.8.5 (2025-10-18)
- FIX: IndentationError im Fallback-Logger behoben
- Verifiziert: Snippets importierbar
""")
        log("Patch erfolgreich.")
        return 0
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(patch())
