"""
Runner_1037_FixDetectSyntax
Behebt SyntaxError in _detect(): falsch eingerückte try/if-Struktur nach Name-Detect-Patch.
Repariert Einrückung + prüft Klammern und Doppelpunkte.
"""
from __future__ import annotations
import os, re, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1037] {ts} {msg}\n")
    except Exception:
        pass

def main():
    try:
        with open(MOD, "r", encoding="utf-8") as f:
            src = f.read()

        # --- 1. Fehlformatierte try-Zeile korrigieren ---
        # Sucht nach  'try:\n            if not getattr'  und entfernt den überflüssigen try:
        fixed = re.sub(
            r"try:\s*\n\s*if\s+not\s+getattr",
            "if not getattr",
            src
        )

        # --- 2. Sicherheits-Cleanup: Doppelte 'try:' ohne except löschen ---
        fixed = re.sub(
            r"try:\s*\n(\s*#.*\n)*\s*try:",
            "try:",
            fixed
        )

        if fixed != src:
            os.makedirs(ARCH, exist_ok=True)
            bck = os.path.join(ARCH, f"module_code_intake.py.{int(time.time())}.bak")
            shutil.copy2(MOD, bck)
            with open(MOD, "w", encoding="utf-8", newline="\r\n") as f:
                f.write(fixed)
            log(f"Backup: {MOD} -> {bck}")
            log("Syntax in _detect repariert.")
        else:
            log("Keine Änderung nötig – Syntax war bereits korrekt.")

        return 0
    except Exception:
        log(traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
