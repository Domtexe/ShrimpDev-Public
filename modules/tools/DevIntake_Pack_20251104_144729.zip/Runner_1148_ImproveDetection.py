# -*- coding: utf-8 -*-
"""
Runner_1148_ImproveDetection
- Repariert NUR die Erkennung (py/bat/json/yml)
- Ersetzt IntakeFrame._guess_name_from_text und _guess_ext_from_text durch robuste Fassungen
- Backup + Syntax-Check + Live-Tests + Rollback bei Fehlern
- Schreibt Report nach _Reports/Runner_1148_ImproveDetection_report.txt
"""
from __future__ import annotations
import io, os, re, sys, time, shutil, importlib.util, types
from pathlib import Path
import py_compile

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1148_ImproveDetection_report.txt"

def w(line: str = ""):
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(line.rstrip() + "\n")
    print(line)

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time()*1000)}.bak"
    shutil.copy2(p, dst)
    return dst

# --------- neue robuste Erkennung (keine fehlerhaften Range-Classes) ----------
NEW_GUESS_NAME = r'''
    def _guess_name_from_text(self, text: str) -> tuple[str, str]:
        """
        Extrahiert Runner-Namen und ggf. Endung aus beliebigem Text.
        Robust gegen Sonderzeichen – KEINE Zeichenklassen mit problematischem '-'.
        """
        t = text or ""
        # tools/Runner_1234_Name.py|bat
        m = re.search(r'(?i)tools[\\/](Runner_[0-9]{3,5}[_A-Za-z0-9\-]+)\.(py|bat|cmd)', t)
        if m: return m.group(1), "." + m.group(2).lower()

        # nur Runner_1234_Name.py|bat (ohne tools/)
        m = re.search(r'(?i)\b(Runner_[0-9]{3,5}[_A-Za-z0-9\-]+)\.(py|bat|cmd)\b', t)
        if m: return m.group(1), "." + m.group(2).lower()

        # Aufrufmuster: py -3 tools\Runner_XXXX_*.py
        m = re.search(r'(?i)\bpy(?:\s+-3)?\s+tools[\\/](Runner_[^\s\\/:*?"<>|]+)\.py\b', t)
        if m: return m.group(1), ".py"

        # Aufrufmuster: call tools\Runner_XXXX_*.bat
        m = re.search(r'(?i)\bcall\s+tools[\\/](Runner_[^\s\\/:*?"<>|]+)\.(bat|cmd)\b', t)
        if m: return m.group(1), "." + m.group(2).lower()

        # Metadaten:  name: Runner_1234_XYZ(.ext)
        m = re.search(r'(?im)^\s*(?:[#;:\- ]*)name\s*[:=]\s*(Runner_[0-9]{3,5}[_A-Za-z0-9\-]+)(?:\.(py|bat|cmd))?\s*$', t)
        if m: return m.group(1), ("."+m.group(2).lower()) if m.group(2) else ""

        # Fallback: irgendein Runner_1234_XYZ
        m = re.search(r'(?i)\b(Runner_[0-9]{3,5}[_A-Za-z0-9\-]+)\b', t)
        if m: return m.group(1), ""
        return "", ""
'''

NEW_GUESS_EXT = r'''
    def _guess_ext_from_text(self, text: str) -> str:
        """
        Leichte, konfliktfreie Heuristik für .py/.bat/.json/.yml(.yaml)/.ini/.md
        """
        head = (text or "").lstrip()[:4000]

        # Batch: @echo off / rem am Zeilenanfang
        if re.search(r'(?im)^\s*@echo\s+off\b', head) or re.search(r'(?im)^\s*rem\b', head):
            return ".bat"

        # Python: Shebang oder typische Python-Strukturen
        if re.search(r'(?im)^#!.*python', head):
            return ".py"
        if re.search(r'(?m)^\s*(?:from\s+\w+\s+import|import\s+\w+|def\s+\w+\(|class\s+\w+\(|if\s+__name__\s*==\s*[\'"]__main__[\'"])', " "+head):
            return ".py"

        # JSON: erster char { oder [ und gültig parsebar
        try:
            import json
            s = head.strip()
            if s and s[0] in "{[":
                json.loads(s)
                return ".json"
        except Exception:
            pass

        # YAML: "key:" oder "- item" Strukturen
        if re.search(r'(?m)^\s*-\s+\w+', head) or re.search(r'(?m)^\s*\w+:\s+.+', head):
            return ".yml"

        # INI
        if re.search(r'(?m)^\s*\[[^\]]+\]\s*$', head) and re.search(r'(?m)^\s*\w+\s*=\s*', head):
            return ".ini"

        # Markdown
        if re.search(r'(?m)^\s*#\s+\w+', head):
            return ".md"

        return ""
'''

PATCHES = [
    # (function name, regex to find old body, replacement body)
    ("_guess_name_from_text",
     re.compile(r'\n\s*def\s+_guess_name_from_text\([^)]*\):\s*(?:\n.+?)*?\n\s*def\s+', re.DOTALL),
     NEW_GUESS_NAME + "\n\n    def "),
    ("_guess_ext_from_text",
     re.compile(r'\n\s*def\s+_guess_ext_from_text\([^)]*\):\s*(?:\n.+?)*?\n\s*def\s+', re.DOTALL),
     NEW_GUESS_EXT + "\n\n    def "),
]

def patch_source(src: str) -> tuple[str, list[str]]:
    """
    Ersetzt die beiden Methoden im IntakeFrame.
    Strategie: wir suchen den alten Methodentext inklusive folgendem 'def' und setzen
    den neuen Body davor wieder mit 'def' an (damit die nächste Methode erhalten bleibt).
    """
    changed = []
    out = src
    for fname, rx, repl in PATCHES:
        m = rx.search(out)
        if m:
            out = out[:m.start()] + repl + out[m.end()-len("def "):]
            changed.append(fname)
    return out, changed

# ---------- Import-Helfer für Live-Test ----------
def import_intake_for_test():
    sys.path.insert(0, str(ROOT))
    # Shim für module_runner_exec (falls kaputt/fehlend)
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        shim_pkg = types.ModuleType("modules")
        shim_mod = types.ModuleType("modules.module_runner_exec")
        shim_mod.run = lambda *a, **k: 0
        shim_mod._log = lambda *a, **k: None
        sys.modules.setdefault("modules", shim_pkg)
        sys.modules["modules.module_runner_exec"] = shim_mod

    spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
    mod  = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)  # type: ignore[attr-defined]
    return mod

def simulate_detection(fr, title: str, text: str, want: str) -> bool:
    fr.txt.delete("1.0", "end")
    fr.txt.insert("1.0", text)
    fr.var_name_manual = False
    fr.var_ext_manual  = False
    ok = fr._detect()
    ext = (fr.var_ext.get() or "").lower()
    # .yml akzeptiert .yml oder .yaml
    want_ok = ext in (".yml", ".yaml") if want == ".yml" else (ext == want)
    w(f"[Test] {title:16s} -> ok={ok}  ext='{ext}' want='{want}'  => {'OK' if want_ok else 'FAIL'}")
    return want_ok

def main() -> int:
    # Report neu
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass

    w("[R1148] ImproveDetection – Start")
    if not MODFILE.exists():
        w(f"[ERR] Datei fehlt: {MODFILE}")
        return 1

    bak = backup(MODFILE)
    w(f"[Backup] {bak.name}")

    src = io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()
    new_src, changed = patch_source(src)

    if not changed:
        w("[Info] Keine passenden Methoden gefunden – keine Änderungen vorgenommen.")
        return 0

    # Schreiben
    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(new_src)
    w("[Write] Methoden ersetzt: " + ", ".join(changed))

    # Syntaxcheck
    try:
        py_compile.compile(str(MODFILE), doraise=True)
        w("[Syntax] OK")
    except Exception as ex:
        w("[Syntax] Fehler -> Rollback")
        shutil.copy2(bak, MODFILE)
        return 1

    # Live-Tests (headless)
    try:
        import tkinter as tk
        mod = import_intake_for_test()
        root = tk.Tk(); root.withdraw()
        fr = mod.IntakeFrame(root)

        samples = [
            ("PY basic",       "import os\nprint('hi')\n", ".py"),
            ("PY runner call", "py -3 tools\\Runner_9999_Test.py\n", ".py"),
            ("BAT basic",      "@echo off\nrem test\n", ".bat"),
            ("BAT runner call","call tools\\Runner_8888_Task.bat\n", ".bat"),
            ("JSON",           "{ \"k\": 1 }\n", ".json"),
            ("YML",            "name: x\nsteps:\n  - run\n", ".yml"),
        ]
        fails = 0
        for title, text, want in samples:
            if not simulate_detection(fr, title, text, want):
                fails += 1
        root.destroy()
        if fails:
            w(f"[SUM] Tests fehlgeschlagen: {fails}/{len(samples)} -> Rollback")
            shutil.copy2(bak, MODFILE)
            return 1
        else:
            w("[SUM] Alle Erkennungs-Tests OK.")
    except Exception as ex:
        w(f"[Live] Fehler: {ex} -> Rollback")
        shutil.copy2(bak, MODFILE)
        return 1

    w("[R1148] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
