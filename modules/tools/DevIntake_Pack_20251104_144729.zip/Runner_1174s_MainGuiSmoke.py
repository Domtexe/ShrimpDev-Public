# -*- coding: utf-8 -*-
import io, os, sys, traceback, py_compile, time, runpy

ROOT = r"D:\ShrimpDev"
TARGET = os.path.join(ROOT, "main_gui.py")
DBG = os.path.join(ROOT, "debug_output.txt")

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with io.open(DBG, "a", encoding="utf-8") as f:
        f.write(f"[1174s {ts}] {msg}\n")

def main():
    if not os.path.isfile(TARGET):
        print("[1174s] main_gui.py fehlt.")
        return 2
    # frisch anhängen
    log("\n===== 1174s Smoke-Start =====")
    try:
        py_compile.compile(TARGET, doraise=True)
        log("Compile OK.")
    except Exception as e:
        log("Compile FEHLER:\n" + "".join(traceback.format_exception(e)))
        print("[1174s] Compile-Fehler -> debug_output.txt prüfen.")
        return 3
    try:
        # führt main_gui als Modul aus (wie normaler Start)
        runpy.run_path(TARGET, run_name="__main__")
        log("Run OK (beendet ohne Ausnahme).")
    except SystemExit as e:
        log(f"SystemExit: code={e.code}")
    except Exception as e:
        log("Run FEHLER:\n" + "".join(traceback.format_exception(e)))
        print("[1174s] Run-Fehler -> debug_output.txt prüfen.")
        return 4
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
