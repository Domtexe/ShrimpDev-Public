# -*- coding: utf-8 -*-
"""
Runner_1177k_RuntimeImportBridge
Aktualisiert modules/module_shim_intake.py:
- Bevorzugt paketierten Import (from modules import module_code_intake)
- Fällt bei ModuleNotFoundError automatisch auf sys.path-Bridge (./modules) zurück
- Sauberes Logging + sichtbarer Fallback im Tab bei Fehlern
Backups: _Archiv/, Log: debug_output.txt
"""
from __future__ import annotations
import os, datetime, shutil

ROOT   = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
MODS   = os.path.join(ROOT, "modules")
ARCH   = os.path.join(ROOT, "_Archiv")
LOGF   = os.path.join(ROOT, "debug_output.txt")
TARGET = os.path.join(MODS, "module_shim_intake.py")

def ts(): return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def log(msg: str):
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(f"[{ts()}] [R1177k] {msg}\n")
    except Exception:
        pass

PAYLOAD = r'''# -*- coding: utf-8 -*-
"""
module_shim_intake – R1177k
Robuster Intake-Adapter mit RuntimeImportBridge.

API:
- mount_intake_tab(nb)
- _mount_intake_tab_shim(nb)
- _remount_intake_tab_shim(nb)
"""
from __future__ import annotations
import os, sys, traceback
import tkinter as tk
from tkinter import ttk

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
LOG_FILE = os.path.join(ROOT, "debug_output.txt")

_TAB_NAME = "Intake"
_TAG = "[IntakeShim]"

def _log(msg: str) -> None:
    try:
        import datetime
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] {_TAG} {msg}\n")
    except Exception:
        pass

def _import_intake_module():
    """
    1) Paketiert: from modules import module_code_intake as intake
    2) Bridge:   sys.path.insert(0, ROOT/modules) + import module_code_intake as intake
    """
    # 1) Paketierter Import
    try:
        from modules import module_code_intake as intake  # type: ignore
        _log("Import OK (package): modules.module_code_intake")
        return intake
    except ModuleNotFoundError as e:
        _log(f"Package import failed: {e}. Trying RuntimeImportBridge...")
    except Exception as e:
        _log(f"Package import other error: {e}. Trying RuntimeImportBridge...")

    # 2) Bridge-Import
    try:
        mod_path = os.path.join(ROOT, "modules")
        if mod_path not in sys.path:
            sys.path.insert(0, mod_path)
            _log(f"sys.path bridge added: {mod_path}")
        import module_code_intake as intake  # type: ignore
        _log("Import OK (bridge): module_code_intake from ./modules")
        return intake
    except Exception as e:
        _log(f"Bridge import failed: {e}")
        _log(traceback.format_exc(limit=3).strip())
        raise

def _find_tab_index(nb: ttk.Notebook, text: str):
    try:
        for i in range(len(nb.tabs())):
            if nb.tab(i, "text") == text:
                return i
    except Exception:
        pass
    return None

def _build_fallback_frame(parent: ttk.Notebook, message: str) -> ttk.Frame:
    frm = ttk.Frame(parent)
    ttk.Label(frm, text=message, foreground="#b33").place(relx=0.5, rely=0.5, anchor="center")
    return frm

def _mount(nb: ttk.Notebook) -> ttk.Frame:
    try:
        intake = _import_intake_module()
        FrameCls = getattr(intake, "IntakeFrame", None)
        if FrameCls is None:
            raise AttributeError("IntakeFrame not found in module_code_intake")
        frm = FrameCls(nb)
        _log("IntakeFrame instance created.")
    except Exception as e:
        _log(f"ERROR importing/instantiating IntakeFrame: {e}")
        _log(traceback.format_exc(limit=3).strip())
        frm = _build_fallback_frame(nb, "Intake – Fehler beim Laden (Details im Log).")

    # Tab einhängen/ersetzen
    try:
        idx = _find_tab_index(nb, _TAB_NAME)
        if idx is None:
            nb.add(frm, text=_TAB_NAME)
            _log("Tab added.")
        else:
            tab_id = nb.tabs()[idx]
            try:
                nb.nametowidget(tab_id).destroy()
            except Exception:
                pass
            nb.insert(idx, frm)
            nb.tab(idx, text=_TAB_NAME)
            _log("Tab replaced.")
        nb.select(frm)
    except Exception as e:
        _log(f"ERROR while mounting tab: {e}")
    return frm

def mount_intake_tab(nb: ttk.Notebook) -> None:
    _log("mount_intake_tab called.")
    _mount(nb)

def _mount_intake_tab_shim(nb: ttk.Notebook) -> None:
    _log("_mount_intake_tab_shim called.")
    _mount(nb)

def _remount_intake_tab_shim(nb: ttk.Notebook) -> None:
    _log("_remount_intake_tab_shim called.")
    _mount(nb)
'''

def backup(path: str):
    if os.path.exists(path):
        os.makedirs(ARCH, exist_ok=True)
        bak = os.path.join(ARCH, f"{os.path.basename(path)}.{ts().replace(':','').replace(' ','_')}.bak")
        shutil.copy2(path, bak)
        log(f"Backup: {bak}")

def main() -> int:
    os.makedirs(MODS, exist_ok=True)
    backup(TARGET)
    with open(TARGET, "w", encoding="utf-8") as f:
        f.write(PAYLOAD)
    log("module_shim_intake.py updated with RuntimeImportBridge.")
    print("[R1177k] RuntimeImportBridge applied.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
