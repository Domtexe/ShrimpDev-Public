"""
Runner_1042_AutoDetect_Hardwire_Scan
- HART: Auto-Detect beim Tippen/Einfuegen im Editor + beim Start (debounced).
- Buttons: zusaetzliche MouseUp-Bind (falls Styles Commands blocken).
- Liste rechts: Fallback-Scan des Zielordners, wenn keine History geliefert wird.
- Version: v9.9.32
"""
from __future__ import annotations
import os, re, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str)->None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1042] {ts} {msg}\n")
    except Exception:
        pass

def read(p:str)->str:
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def write_backup(p:str, data:str):
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bck)
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {p} -> {bck}")

def patch()->int:
    src = read(MOD)
    changed = False

    # --- 1) Editor-Bindings fuer Auto-Detect (<<Paste>>, <Ctrl-V>, <<Modified>>, KeyRelease) ---
    if "self.txt.bind(\"<<Paste>>\"" not in src:
        src = re.sub(
            r'(self\.txt\s*=\s*tk\.Text\([^\n]+\)\s*\n)',
            r'\1        # Auto-Detect Bindings\n'
            r'        self._detect_job = None\n'
            r'        self.txt.bind("<<Paste>>", self._on_editor_paste)\n'
            r'        self.txt.bind("<Control-v>", self._on_editor_paste)\n'
            r'        self.txt.bind("<<Modified>>", self._on_editor_modified)\n'
            r'        self.txt.bind("<KeyRelease>", self._on_editor_key)\n',
            src, flags=re.MULTILINE
        )
        changed = True

    if "def _on_editor_paste(" not in src:
        inject_pt = src.find("\n    # ---------- detection ----------")
        methods = r'''
    # --- Auto-Detect (debounced) ---
    def _on_editor_paste(self, _evt=None):
        self._schedule_detect()

    def _on_editor_key(self, _evt=None):
        # nur triggern, wenn Name noch leer ist
        if not (self.var_name.get() or "").strip():
            self._schedule_detect(250)

    def _on_editor_modified(self, _evt=None):
        try:
            self.txt.edit_modified(False)
        except Exception:
            pass
        if not (self.var_name.get() or "").strip():
            self._schedule_detect(300)

    def _schedule_detect(self, delay_ms:int=300):
        try:
            if getattr(self, "_detect_job", None):
                self.after_cancel(self._detect_job)
        except Exception:
            pass
        self._detect_job = self.after(delay_ms, self._auto_detect_if_needed)

    def _auto_detect_if_needed(self):
        try:
            name_empty = not (self.var_name.get() or "").strip()
            if name_empty or not self.var_ext_manual:
                self._ping("Auto-Erkennung…")
                self._detect()
        except Exception:
            pass
'''
        src = src[:inject_pt] + methods + src[inject_pt:]
        changed = True

    # initiale Auto-Detect nach LED-Setup
    if "self.after(200, self._auto_detect_if_needed)" not in src:
        src = re.sub(
            r'(# LEDs[\s\S]+?self\.led_save[^\n]+\n)',
            r'\1        # Initiale Auto-Erkennung\n        self.after(200, self._auto_detect_if_needed)\n',
            src, flags=re.MULTILINE
        )
        changed = True

    # --- 2) Buttons zusaetzlich per MouseUp binden (falls nicht vorhanden) ---
    if "self.btn_detect.bind(\"<ButtonRelease-1>\"" not in src:
        src = re.sub(
            r'(self\.btn_del\.grid[^\n]+\n)',
            r'\1        try:\n'
            r'            self.btn_detect.bind("<ButtonRelease-1>", lambda e: self._on_click_detect())\n'
            r'            self.btn_save.bind(  "<ButtonRelease-1>", lambda e: self._on_click_save())\n'
            r'            self.btn_del.bind(   "<ButtonRelease-1>", lambda e: self._on_click_delete())\n'
            r'        except Exception:\n'
            r'            pass\n',
            src, flags=re.MULTILINE
        )
        changed = True

    # --- 3) _load_table: Fallback-Scan wenn History leer/fehlend ---
    load_pat = re.compile(r"def\s+_load_table\([\s\S]+?\n\s*def\s+_", re.MULTILINE)
    m = load_pat.search(src)
    if m:
        old = m.group(0)
        if "os.walk(" not in old:
            new_load = r'''
    def _load_table(self):
        # Tabelle leeren
        for i in self.tbl.get_children():
            self.tbl.delete(i)
        tgt = os.path.abspath(self.var_target.get() or ".")
        entries = []
        # 1) Versuch: History aus Config
        try:
            for p in self.cfg.get_history():
                entries.append(p)
        except Exception:
            pass
        # 2) Fallback: Zielordner scannen (nicht rekursiv tief – nur 1 Ebene)
        if not entries:
            try:
                for root, dirs, files in os.walk(tgt):
                    for fn in files:
                        if os.path.splitext(fn)[1].lower() in (".py",".bat",".cmd",".json",".txt",".yml",".yaml",".ini",".md",".shcut"):
                            entries.append(os.path.join(root, fn))
                    break  # nicht tiefer
            except Exception:
                pass
        # 3) In Tabelle schreiben
        for p in entries:
            base = os.path.basename(p)
            name, ext = os.path.splitext(base)
            try:
                rel = os.path.relpath(os.path.dirname(os.path.abspath(p)), tgt)
                sub = "" if rel in (".", "") else rel
            except Exception:
                sub = ""
            self.tbl.insert("", "end", values=(name, (ext or "").lower(), sub))
'''
            src = src[:m.start()] + new_load + "\n    " + src[m.end():]
            changed = True

    if changed:
        write_backup(MOD, src)
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.32\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.32 (2025-10-18)
- Auto-Detect hart verdrahtet (Paste/Key/Start, debounced).
- Buttons zusätzlich via MouseUp gebunden.
- Rechte Liste: Fallback-Scan des Zielordners, wenn keine History da ist.
""")
        log("Patch angewendet.")
    else:
        log("Keine Änderungen nötig.")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(patch())
    except Exception:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write("[R1042] FEHLER:\n" + traceback.format_exc() + "\n")
        print("FEHLER:\n" + traceback.format_exc())
        raise
