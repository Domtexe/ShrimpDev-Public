# -*- coding: utf-8 -*-
"""
Korrigiert den Importnamen des Intake-Shim in main_gui.py
(_mount_intake_tab_shim → mount_intake_tab).
Rollback bei Syntaxfehler.
"""
import os, re, time, py_compile, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
os.makedirs(ARCH, exist_ok=True)

MAIN = os.path.join(ROOT, "main_gui.py")
DBG  = os.path.join(ROOT, "debug_output.txt")

def log(msg):
    print(msg)
    with open(DBG, "a", encoding="utf-8") as f:
        f.write(f"[1176d {time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")

def backup(path):
    ts = time.strftime("%Y%m%d_%H%M%S")
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    with open(path, "r", encoding="utf-8") as r, open(dst, "w", encoding="utf-8") as w:
        w.write(r.read())
    log(f"Backup erstellt: {dst}")

def patch():
    with open(MAIN, "r", encoding="utf-8") as f:
        src = f.read()

    # Import ersetzen
    src, n1 = re.subn(r"from modules\.module_shim_intake import _mount_intake_tab_shim",
                      "from modules.module_shim_intake import mount_intake_tab", src)
    # Funktionsaufrufe anpassen
    src, n2 = re.subn(r"_mount_intake_tab_shim\s*\(", "mount_intake_tab(", src)
    # Optional Fallbacks (GatePanel)
    src, n3 = re.subn(r"_remount_intake_tab_shim", "mount_intake_tab", src)

    if n1 + n2 + n3 == 0:
        log("Keine Änderungen erforderlich.")
        return

    with open(MAIN, "w", encoding="utf-8") as f:
        f.write(src)

    py_compile.compile(MAIN, doraise=True)
    log("Syntax OK, ShimName korrigiert.")

def main():
    if not os.path.exists(MAIN):
        log("main_gui.py nicht gefunden.")
        sys.exit(2)
    backup(MAIN)
    try:
        patch()
    except Exception as e:
        log(f"Fehler: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
