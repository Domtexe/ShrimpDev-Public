# -*- coding: utf-8 -*-
"""
R1167j_IniDetectHelperPatch
- Fügt in module_code_intake.py einen robusten Helper _detect_is_ini(head) ein.
- Ersetzt die alte Inline-Erkennung "if re.search(...) and re.search(...): return '.ini'"
- Backup + Syntax-Check + Rollback, idempotent.
"""
from __future__ import annotations
import os, re, time, py_compile, traceback

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOG    = os.path.join(ROOT, "debug_output.txt")

HELPER_MARK = "# R1167j: robust INI detector"
HELPER_CODE = f"""
{HELPER_MARK}
def _detect_is_ini(head: str) -> bool:
    \"\"\"Heuristik: Mindestens eine [section]-Zeile und mindestens eine key=value-Zeile.
    Regexe sind bewusst defensiv, ohne verschachtelte Klassen.
    \"\"\"
    import re
    # Section: Zeilen wie [name], ohne eckige Klammern im Namen, multiline
    has_section = re.search(r'^\\s*\\[[^\\[\\]\\r\\n]+\\]\\s*$', head, re.M) is not None
    # key=value: zulässige Keys (Buchstaben/Ziffern/_ . -), irgendein Wert rechts
    has_kv = re.search(r'^\\s*[A-Za-z0-9_.-]+\\s*=\\s*.+$', head, re.M) is not None
    return has_section and has_kv
"""

# Muster für die alte Inline-Erkennung -> wird zu Helper-Aufruf umgeschrieben
INLINE_COND_PAT = re.compile(
    r"""if\s+re\.search\(
        .*?\)\s*             # erster re.search(...)
        and\s*re\.search\(
        .*?\)\s*             # zweiter re.search(...)
        :\s*return\s+["']\.ini["']
    """,
    re.S | re.X,
)

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1167j {ts}] {msg}\n"
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    ts = int(time.time())
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    with open(path, "r", encoding="utf-8") as fi, open(dst, "w", encoding="utf-8", newline="") as fo:
        fo.write(fi.read())
    return dst

def main() -> int:
    try:
        if not os.path.exists(TARGET):
            log(f"Zieldatei fehlt: {TARGET}")
            return 1

        with open(TARGET, "r", encoding="utf-8") as f:
            src = f.read()

        changed = False

        # 1) Helper einfügen – nach dem Helpers-Marker
        if HELPER_MARK not in src:
            # wir suchen die Marker-Zeile "# ---------- helpers ----------"
            m = re.search(r"(?m)^\\s*#\\s*-{2,}\\s*helpers\\s*-{2,}\\s*$", src)
            if not m:
                log("Helpers-Marker nicht gefunden – füge Helper am Datei-Ende an.")
                src = src.rstrip() + "\n\n" + HELPER_CODE
            else:
                insert_at = m.end()
                src = src[:insert_at] + "\n" + HELPER_CODE + src[insert_at:]
            changed = True

        # 2) Inline-INI-Erkennung ersetzen
        if INLINE_COND_PAT.search(src):
            src = INLINE_COND_PAT.sub("if _detect_is_ini(head): return \".ini\"", src)
            changed = True

        if not changed:
            log("Keine Änderung notwendig (bereits gepatcht oder keine Inline-Erkennung gefunden).")
            return 0

        # Backup + Schreiben
        bak = backup(TARGET)
        log(f"Backup erstellt: {bak}")

        with open(TARGET, "w", encoding="utf-8", newline="\n") as f:
            f.write(src)

        # Syntax-Check
        try:
            py_compile.compile(TARGET, doraise=True)
        except Exception as e:
            with open(bak, "r", encoding="utf-8") as fi, open(TARGET, "w", encoding="utf-8", newline="\n") as fo:
                fo.write(fi.read())
            log("Syntax-Check FEHLER -> Rollback auf Backup.")
            log("Traceback:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 1

        log("Patch erfolgreich eingefügt und Syntax-Check OK.")
        return 0

    except Exception as e:
        log("UNERWARTETER FEHLER:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
