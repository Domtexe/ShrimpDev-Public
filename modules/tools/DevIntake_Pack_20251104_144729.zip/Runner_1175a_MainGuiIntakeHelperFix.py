from __future__ import annotations
import os
from patchlib_guard import guarded_apply, ensure_import, upsert_function

ROOT = r"D:\ShrimpDev"
MAIN = os.path.join(ROOT, "main_gui.py")

HELPER_NAME = "_safe_add_intake_tab"

HELPER_FUNC = f'''
def {HELPER_NAME}(nb):
    """
    Robust: fügt den Intake-Tab in ein ttk.Notebook ein, ohne die App zu killen.
    Erwartet ein Notebook-Objekt "nb".
    Idempotent: ersetzt bestehenden Tab 'Code Intake' falls vorhanden.
    """
    import importlib, traceback
    from tkinter import ttk
    title = "Code Intake"
    try:
        # Tab ggf. ersetzen statt duplizieren
        if hasattr(nb, "tabs"):
            try:
                for i, tid in enumerate(nb.tabs()):
                    if nb.tab(tid, "text") == title:
                        try:
                            nb.forget(tid)
                        except Exception:
                            pass
                        break
            except Exception:
                pass

        mod = importlib.import_module("modules.module_code_intake")
        # Strategie 1: create_intake_tab(nb) -> Frame
        if hasattr(mod, "create_intake_tab"):
            frm = mod.create_intake_tab(nb)
            nb.add(frm, text=title)
            return

        # Strategie 2: build_ui(parent) -> Frame
        if hasattr(mod, "build_ui"):
            frm = mod.build_ui(nb)
            nb.add(frm, text=title)
            return

        # Strategie 3: Klasse mit .build(nb)
        if hasattr(mod, "CodeIntake"):
            inst = mod.CodeIntake()
            frm = getattr(inst, "build", lambda p: None)(nb)
            if frm is not None:
                nb.add(frm, text=title)
                return

        # Strategie 4: Fallback – einfache leere Seite statt Crash
        frm = ttk.Frame(nb)
        nb.add(frm, text=title)
    except Exception:
        try:
            # Fehler freundlich loggen, ohne App-Abbruch
            with open(r"D:\ShrimpDev\debug_output.txt", "a", encoding="utf-8") as f:
                f.write("\\n[INTAKE_MOUNT_ERROR]\\n")
                traceback.print_exc(file=f)
        except Exception:
            pass
'''

def _transform(ctx):
    # tk/ttk sicherstellen
    ctx.modified = ensure_import(ctx.modified, "from tkinter import ttk")
    # Helper-Funktion idempotent einfügen/ersetzen
    ctx.modified = upsert_function(ctx.modified, HELPER_FUNC, HELPER_NAME)
    # Aufruf bleibt in _safe_main – wird NICHT angefasst (wir liefern nur die fehlende Def)

ok, msg = guarded_apply(MAIN, _transform)
print(("[1175a] " + (msg or "")).strip())
raise SystemExit(0 if ok else 1)
