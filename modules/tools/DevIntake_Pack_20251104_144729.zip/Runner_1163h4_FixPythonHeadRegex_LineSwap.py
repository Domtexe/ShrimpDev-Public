# -*- coding: utf-8 -*-
"""
R1163h4 FixPythonHeadRegex LineSwap
- Findet die fehlerhafte 're.search(... __main__ ...): return ".py"' Zeile in _guess_ext_from_text
  und ersetzt sie 1:1 per Zeilentausch (ohne re.sub, daher keine Backslash-Probleme).
- Safety: Backup -> _Archiv, Syntax-Check, Rollback bei Fehler.
"""
from __future__ import annotations
import io, time, shutil, py_compile, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
LOGF = ROOT / "debug_output.txt"

GOOD_LINE_BODY = (
    "if re.search(r\"(?m)^\\s*(?:from\\s+\\w+\\s+import|import\\s+\\w+|def\\s+\\w+\\s*\\(|"
    "class\\s+\\w+\\s*\\(|if\\s+__name__\\s*==\\s*[\\'\\\"]__main__[\\'\\\"])\", "
    "\" \"+head): return \".py\""
)

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1163h4] {ts} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f: f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(p: Path) -> Path:
    ARCH.mkdir(parents=True, exist_ok=True)
    dst = ARCH / f"{p.name}.{int(time.time())}.bak"
    shutil.copy2(p, dst)
    log(f"Backup: {p} -> {dst}")
    return dst

def main() -> int:
    try:
        if not MOD.exists():
            log(f"[ERR] Not found: {MOD}")
            return 2

        text = MOD.read_text(encoding="utf-8")
        lines = text.splitlines(True)

        idx = -1
        for i, ln in enumerate(lines):
            if "re.search(" in ln and "__main__" in ln and 'return ".py"' in ln:
                idx = i
                break

        if idx == -1:
            log("No target line found (nothing changed).")
            return 0

        indent = lines[idx][: len(lines[idx]) - len(lines[idx].lstrip())]
        lines[idx] = indent + GOOD_LINE_BODY + "\n"

        bak = backup(MOD)
        MOD.write_text("".join(lines), encoding="utf-8", newline="\n")

        try:
            py_compile.compile(str(MOD), doraise=True)
            log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}")
            shutil.copy2(bak, MOD)
            log("Restored from backup.")
            return 3

        log("R1163h4 completed successfully.")
        return 0

    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
