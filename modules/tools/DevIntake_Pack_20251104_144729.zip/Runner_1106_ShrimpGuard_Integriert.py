# -*- coding: utf-8 -*-
"""
Runner_1106_ShrimpGuard_Integriert
----------------------------------
Prüft sowohl Runner-Code (Editor) als auch alle geänderten Dateien nach Ausführung.
Stellt bei Fehlern automatisch Backups wieder her.
"""

from __future__ import annotations
import os, sys, re, time, subprocess, io, hashlib, argparse, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TOOLS = os.path.join(ROOT, "tools")
MODULES = os.path.join(ROOT, "modules")
ARCHIV = os.path.join(ROOT, "_Archiv")

PYTHON = sys.executable
OK, WARN, FAIL = 0, 1, 2

# ------------------------------------------------------------
# 🔹 Hilfsfunktionen
# ------------------------------------------------------------
def lese_text(pfad: str) -> str:
    with open(pfad, "rb") as f:
        raw = f.read()
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("latin-1", errors="replace")

def schreibe_text(pfad: str, text: str):
    with open(pfad, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

def backup_datei(pfad: str) -> str:
    ts = int(time.time())
    ziel = os.path.join(ARCHIV, f"{os.path.basename(pfad)}.{ts}.bak")
    shutil.copy2(pfad, ziel)
    print(f"[Guard] Backup erstellt: {ziel}")
    return ziel

def hash_datei(pfad: str) -> str:
    h = hashlib.sha256()
    with open(pfad, "rb") as f:
        for block in iter(lambda: f.read(65536), b""):
            h.update(block)
    return h.hexdigest()

def snapshot(verzeichnis: str) -> dict[str, str]:
    mapping = {}
    for basis, _, dateien in os.walk(verzeichnis):
        for datei in dateien:
            if datei.endswith(".py"):
                pfad = os.path.join(basis, datei)
                mapping[pfad] = hash_datei(pfad)
    return mapping

def diff(before: dict[str, str], after: dict[str, str]) -> list[str]:
    return [p for p in sorted(set(before) | set(after)) if before.get(p) != after.get(p)]

# ------------------------------------------------------------
# 🔹 Code-Prüfung
# ------------------------------------------------------------
def check_text(src: str, label: str) -> tuple[int, list[str]]:
    meldungen, rc = [], OK
    src = src.replace("\r\n", "\n").replace("\r", "\n").replace("\t", "    ")

    # einfache Plausibilitätschecks
    if (src.count('"""') % 2 != 0) or (src.count("'''") % 2 != 0):
        meldungen.append(f"[WARN] {label}: Unvollständige Mehrzeilen-Strings.")
        rc = max(rc, WARN)

    if "try:" in src and not any(x in src for x in ("except", "finally")):
        meldungen.append(f"[WARN] {label}: try ohne except/finally gefunden.")
        rc = max(rc, WARN)

    # Syntax prüfen
    try:
        compile(src, label, "exec")
    except SyntaxError as e:
        meldungen.append(f"[FAIL] {label}: SyntaxError in Zeile {e.lineno}: {e.msg}")
        rc = FAIL
    except Exception as e:
        meldungen.append(f"[FAIL] {label}: {e}")
        rc = FAIL

    return rc, meldungen

def check_datei(pfad: str) -> tuple[int, list[str]]:
    if not os.path.exists(pfad):
        return FAIL, [f"[FAIL] Datei fehlt: {pfad}"]
    text = lese_text(pfad)
    return check_text(text, pfad)

# ------------------------------------------------------------
# 🔹 Runner ausführen und Änderungen prüfen
# ------------------------------------------------------------
def fuehre_runner_aus(runner_pfad: str) -> tuple[int, list[str], list[str]]:
    meldungen = [f"[Guard] Starte Runner: {runner_pfad}"]
    vorher = snapshot(MODULES)

    proc = subprocess.run([PYTHON, "-3", runner_pfad],
                          cwd=ROOT, capture_output=True, text=True)

    if proc.stdout.strip():
        meldungen.append("---- Runner-Ausgabe ----")
        meldungen.append(proc.stdout.strip())
    if proc.stderr.strip():
        meldungen.append("---- Runner-Fehler ----")
        meldungen.append(proc.stderr.strip())

    nachher = snapshot(MODULES)
    geaendert = diff(vorher, nachher)
    meldungen.append(f"[Guard] {len(geaendert)} Datei(en) geändert.")
    return proc.returncode, meldungen, geaendert

# ------------------------------------------------------------
# 🔹 Hauptfunktion
# ------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", help="Pfad zur Python-Datei")
    parser.add_argument("--check-text", help="Temporäre Textdatei mit Runner-Code")
    parser.add_argument("--run", help="Runner ausführen und geänderte Module prüfen")
    args = parser.parse_args()

    gesamt_rc, log = OK, []

    # 1️⃣ Nur Text prüfen (aktueller Runner im Editor)
    if args.check_text:
        try:
            src = lese_text(args.check_text)
            rc, meld = check_text(src, args.check_text)
            log.extend(meld)
            gesamt_rc = max(gesamt_rc, rc)
        except Exception as e:
            log.append(f"[FAIL] Fehler beim Lesen: {e}")
            gesamt_rc = FAIL

    # 2️⃣ Einzelne Datei prüfen
    if args.check:
        rc, meld = check_datei(args.check)
        log.extend(meld)
        gesamt_rc = max(gesamt_rc, rc)

    # 3️⃣ Runner ausführen und geänderte Module prüfen
    if args.run:
        rc, meld, changed = fuehre_runner_aus(args.run)
        log.extend(meld)
        if not changed:
            log.append("[Guard] Keine Änderungen erkannt.")
        for datei in changed:
            rc2, meld2 = check_datei(datei)
            log.extend(meld2)
            gesamt_rc = max(gesamt_rc, rc2)
            if rc2 == FAIL:
                try:
                    backup_datei(datei)
                except Exception as e:
                    log.append(f"[WARN] Backup fehlgeschlagen: {e}")

    # Ausgabe
    print("\n".join(log))
    return gesamt_rc

if __name__ == "__main__":
    sys.exit(main())
