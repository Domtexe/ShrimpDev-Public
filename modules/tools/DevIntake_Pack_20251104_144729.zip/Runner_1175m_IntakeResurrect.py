# -*- coding: utf-8 -*-
"""
[1175m] IntakeResurrect
A) Entfernt den defekt/duplizierten "def nb.add(__mount_intake_tab_shim(...))"-Block aus main_gui.py
B) Stellt modules\module_code_intake.py aus dem neuesten kompilierbaren Backup in _Archiv wieder her
C) Syntax-Smoketests
Idempotent und vorsichtig gemäß Master-Regeln.
"""
from __future__ import annotations
import os, re, sys, shutil, py_compile, glob, io

ROOT = r"D:\ShrimpDev"
MODS = os.path.join(ROOT, "modules")
ARCH = os.path.join(ROOT, "_Archiv")
MAIN = os.path.join(ROOT, "main_gui.py")
INTAKE = os.path.join(MODS, "module_code_intake.py")
DBG = os.path.join(ROOT, "debug_output.txt")

def log(msg):
    print(msg)
    try:
        with open(DBG, "a", encoding="utf-8") as f:
            f.write(msg + "\n")
    except Exception:
        pass

def _compile_ok(path: str) -> bool:
    try:
        py_compile.compile(path, doraise=True)
        return True
    except Exception as e:
        log(f"[1175m] COMPILE_FAIL {os.path.basename(path)}: {e}")
        return False

def fix_main_gui() -> None:
    """Entfernt den ungültigen def-Block 'def nb.add(__mount_intake_tab_shim...' falls vorhanden."""
    with open(MAIN, "r", encoding="utf-8") as f:
        src = f.read()

    # Pattern: def nb.add(__mount_intake_tab_shim(nb), text="Code Intake"):
    # Bis zum nächsten "^\w" auf gleicher oder linker Einrückung (oder EOF)
    pat = re.compile(
        r"\n[ \t]*def[ \t]+nb\.add\(\s*__mount_intake_tab_shim\(nb\)\s*,\s*text\s*=\s*\"Code Intake\"\s*\)\s*:\s*"
        r"(?:\n[ \t]+.*?)+?(?=\n[^\s]|\n[ \t]*def[ \t]+\w|\Z)",
        re.DOTALL
    )
    if not pat.search(src):
        log("[1175m] MainGui: defekter nb.add-Block nicht gefunden (OK).")
        return

    new = pat.sub("\n# [1175m] Entfernt: fehlerhafter nb.add-Defintionsblock (Duplikat)\n", src)
    if new == src:
        log("[1175m] MainGui: Ersetzung ergab keine Änderung (OK).")
    else:
        # Sicherheits-Backup ist bereits in der BAT passiert
        with open(MAIN + ".tmp", "w", encoding="utf-8", newline="\n") as f:
            f.write(new)
        if not _compile_ok(MAIN + ".tmp"):
            raise SystemExit("[1175m] FEHLER: main_gui.py.tmp kompiliert nicht – Abbruch.")
        shutil.move(MAIN + ".tmp", MAIN)
        log("[1175m] MainGui: defekter Block entfernt.")

def restore_intake_from_archiv() -> None:
    """Nimmt das neueste kompilierbare _Archiv-Backup und stellt module_code_intake.py wieder her."""
    # Wenn aktuelle Datei bereits ok, nichts tun
    if os.path.exists(INTAKE) and _compile_ok(INTAKE):
        log("[1175m] Intake: aktuelle Datei ist kompilierbar – keine Wiederherstellung nötig.")
        return

    candidates = sorted(
        glob.glob(os.path.join(ARCH, "module_code_intake.py.*.bak")),
        key=os.path.getmtime,
        reverse=True
    )
    if not candidates:
        raise SystemExit("[1175m] FEHLER: Keine Backups in _Archiv gefunden.")

    for bak in candidates:
        # in temp kompilieren
        tmp = INTAKE + ".1175m.tmp"
        shutil.copyfile(bak, tmp)
        # Normalize endings defensiv
        with open(tmp, "rb") as f:
            data = f.read()
        try:
            txt = data.decode("utf-8", errors="replace")
        except Exception:
            txt = data.decode("latin-1", errors="replace")
        # Keine destruktiven Reparaturen – nur CRLF vereinheitlichen
        txt = txt.replace("\r\n", "\n").replace("\r", "\n")
        with open(tmp, "w", encoding="utf-8", newline="\n") as f:
            f.write(txt)
        if _compile_ok(tmp):
            shutil.move(tmp, INTAKE)
            log(f"[1175m] Intake: Wiederhergestellt aus {os.path.basename(bak)}.")
            return
        else:
            try:
                os.remove(tmp)
            except Exception:
                pass
            continue

    raise SystemExit("[1175m] FEHLER: Kein kompilierbares Intake-Backup gefunden.")

def main():
    fix_main_gui()
    restore_intake_from_archiv()
    # Finaler Syntax-Smoketest (beide)
    if not _compile_ok(MAIN) or not _compile_ok(INTAKE):
        raise SystemExit(10)
    log("[1175m] Fertig (Syntax OK).")

if __name__ == "__main__":
    main()
