# -*- coding: utf-8 -*-
"""
R1163h3 FixPythonHeadRegex DirectReplace
Ersetzt die fehlerhafte Regex-Zeile in _guess_ext_from_text durch eine geprüfte, balancierte Version.
"""
import time, shutil, io, py_compile, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
LOGF = ROOT / "debug_output.txt"

BAD_SNIPPET = 'if re.search(r"(?m)^\\s*(from\\s+\\w+\\s+import|import\\s+\\w+|def\\s+\\w+\\(|class\\s+\\w+\\(|if\\s+__name__\\s*==\\s*[\'\\"]__main__[\'\\"])", " "+head): return ".py"'
GOOD_SNIPPET = 'if re.search(r"(?m)^\\s*(?:from\\s+\\w+\\s+import|import\\s+\\w+|def\\s+\\w+\\s*\\(|class\\s+\\w+\\s*\\(|if\\s+__name__\\s*==\\s*[\\\'\\"]__main__[\\\'\\"])", " "+head): return ".py"'

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1163h3] {ts} {msg}\n"
    with open(LOGF, "a", encoding="utf-8") as f: f.write(line)
    print(line, end="")

def backup(p):
    ARCH.mkdir(exist_ok=True)
    dst = ARCH / f"{p.name}.{int(time.time())}.bak"
    shutil.copy2(p, dst)
    log(f"Backup: {p} -> {dst}")
    return dst

def main():
    try:
        text = MOD.read_text(encoding="utf-8")
        bak = backup(MOD)
        if BAD_SNIPPET not in text:
            log("Warnung: exakter BAD_SNIPPET nicht gefunden – Suche nach re.search(…) wird erweitert.")
            import re
            text_new, n = re.subn(
                r'if\s+re\.search\([^)]*__main__[^)]*\)\s*:\s*return\s*["\']\.py["\']',
                GOOD_SNIPPET,
                text,
            )
        else:
            text_new = text.replace(BAD_SNIPPET, GOOD_SNIPPET)
            n = 1

        if n == 0:
            log("Keine Übereinstimmung gefunden. Kein Patch angewendet.")
            return 0

        MOD.write_text(text_new, encoding="utf-8", newline="\n")
        py_compile.compile(str(MOD), doraise=True)
        log("Syntax-Check: OK")
        log("R1163h3 completed successfully.")
        return 0

    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
