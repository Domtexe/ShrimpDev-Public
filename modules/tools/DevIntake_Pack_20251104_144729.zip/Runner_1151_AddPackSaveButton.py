# -*- coding: utf-8 -*-
"""
Runner_1151_AddPackSaveButton
Mastermodus-konformer Patch:
- Ergänzt im IntakeFrame einen Toolbar-Button '📦 Pack speichern' (btn_pack)
- Implementiert Methode: _on_click_pack(self, dest_dir: str|None=None)
  -> erstellt ZIP-Pack unter _Packs/pack_YYYYMMDD_HHMMSS.zip (default)
  -> Inhalte: main_gui.py, tools/, modules/, debug_output.txt, _Reports/ (falls vorhanden)
  -> robust: Existenz-/Schreibrechte-Checks, Fallbacks, Ping-Status
- Keine invasiven Änderungen. Backup, Syntaxcheck, Headless-Smoke, Rollback bei Fehler.

Report: _Reports/Runner_1151_AddPackSaveButton_report.txt
"""
from __future__ import annotations
import io, os, sys, time, shutil, ast, importlib.util, types, re
from pathlib import Path
import py_compile
from datetime import datetime

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1151_AddPackSaveButton_report.txt"

def w(s=""):
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(s.rstrip()+"\n")
    print(s)

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time()*1000)}.bak"
    shutil.copy2(p, dst)
    return dst

NEW_PACK_METHOD = r'''
def _on_click_pack(self, dest_dir: str|None=None):
    """
    Erzeugt ein Support-Pack als ZIP.
    Default: <ROOT>/_Packs/pack_YYYYMMDD_HHMMSS.zip
    Inhalte: main_gui.py, tools/, modules/, debug_output.txt, _Reports/ (falls vorhanden)
    """
    import os, shutil, time, zipfile
    from pathlib import Path
    try:
        root = Path(__file__).resolve().parents[1]
    except Exception:
        self._ping("Pack: Root nicht bestimmbar."); return
    packs_dir = Path(dest_dir) if dest_dir else (root / "_Packs")
    try:
        packs_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        self._ping("Pack: Zielordner nicht schreibbar."); return
    ts = time.strftime("%Y%m%d_%H%M%S")
    out_zip = packs_dir / f"pack_{ts}.zip"

    include = []
    # Kernteile
    for rel in ("main_gui.py", "modules", "tools"):
        p = root / rel
        if p.exists():
            include.append(p)

    # Logs/Reports optional
    for rel in ("debug_output.txt", "_Reports"):
        p = root / rel
        if p.exists():
            include.append(p)

    # Erzeuge ZIP
    try:
        with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for item in include:
                item = Path(item)
                if item.is_dir():
                    for sub in item.rglob("*"):
                        if sub.is_file():
                            try:
                                zf.write(sub, arcname=sub.relative_to(root))
                            except Exception:
                                pass
                else:
                    try:
                        zf.write(item, arcname=item.relative_to(root))
                    except Exception:
                        pass
        self._ping(f"Pack erstellt: {out_zip.name}")
    except Exception as ex:
        try:
            self._ping(f"Pack-Fehler: {ex}")
        except Exception:
            pass
'''

def load_txt() -> str:
    return io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

def save_txt(txt: str) -> None:
    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(txt)

def patch_intake(txt: str) -> tuple[str, list[str]]:
    """
    - Sucht class IntakeFrame
    - Fügt _on_click_pack hinzu (falls nicht vorhanden)
    - Fügt Button btn_pack in Toolbar ein + grid-Position rechts von Run
    """
    changes: list[str] = []
    tree = ast.parse(txt)
    cls: ast.ClassDef | None = None
    for n in tree.body:
        if isinstance(n, ast.ClassDef) and n.name == "IntakeFrame":
            cls = n; break
    if not cls: raise RuntimeError("class IntakeFrame nicht gefunden.")

    lines = txt.splitlines()
    start = cls.lineno - 1
    end = getattr(cls, "end_lineno", None) or len(lines)
    cls_src = "\n".join(lines[start:end])

    # 1) Methode _on_click_pack: ersetzen/anhängen
    rx_method = re.compile(r'(?ms)^\s*def\s+_on_click_pack\s*\([^)]*\):\s*(?:\n\s+.+?)(?=^\s*def\s+\w+\s*\(|\Z)')
    if rx_method.search(cls_src):
        cls_src = rx_method.sub("\n    " + NEW_PACK_METHOD.replace("\n", "\n    ") + "\n", cls_src, count=1)
        changes.append("replaced:_on_click_pack")
    else:
        if not cls_src.endswith("\n"): cls_src += "\n"
        cls_src += "\n    " + NEW_PACK_METHOD.replace("\n", "\n    ") + "\n"
        changes.append("added:_on_click_pack")

    # 2) Button in Toolbar ergänzen (Erstellung + Grid)
    if "btn_pack" not in cls_src:
        # Erstellung: nach btn_run definieren
        cls_src = cls_src.replace(
            '        self.btn_run    = ttk.Button(bar, text="Run (F5)",           command=self._on_click_run)',
            '        self.btn_run    = ttk.Button(bar, text="Run (F5)",           command=self._on_click_run)\n'
            '        self.btn_pack   = ttk.Button(bar, text="📦 Pack speichern",  command=self._on_click_pack)'
        )
        # Grid: rechts neben Run
        if 'self.btn_refresh' in cls_src:
            # Falls Refresh existiert, setze Pack als letzte Spalte rechts davon
            cls_src = cls_src.replace(
                '        self.btn_refresh.grid(row=0, column=102, padx=(6,0), sticky="w")',
                '        self.btn_refresh.grid(row=0, column=102, padx=(6,0), sticky="w")\n'
                '        self.btn_pack.grid(   row=0, column=103, padx=(12,0), sticky="w")'
            )
        else:
            cls_src = cls_src.replace(
                '        self.btn_run.grid(   row=0, column=101, padx=(6,0), sticky="w")',
                '        self.btn_run.grid(   row=0, column=101, padx=(6,0), sticky="w")\n'
                '        self.btn_pack.grid(  row=0, column=102, padx=(12,0), sticky="w")'
            )
        changes.append("added:btn_pack")

    new_txt = "\n".join(lines[:start]) + ("\n" if start else "") + cls_src + ("\n" if end < len(lines) else "") + "\n".join(lines[end:])
    return new_txt, changes

# ---- Live-Test (headless): Import, Instanz, _on_click_pack(tempdir)
def import_intake_for_test():
    sys.path.insert(0, str(ROOT))
    # Shim für module_runner_exec
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules")
        mod = types.ModuleType("modules.module_runner_exec")
        mod.run = lambda *a, **k: 0
        mod._log = lambda *a, **k: None
        sys.modules.setdefault("modules", pkg)
        sys.modules["modules.module_runner_exec"] = mod

    spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
    m = importlib.util.module_from_spec(spec); assert spec and spec.loader
    spec.loader.exec_module(m)  # type: ignore[attr-defined]
    return m

def headless_probe()->tuple[bool,str]:
    try:
        import tkinter as tk, tempfile
        m = import_intake_for_test()
        r = tk.Tk(); r.withdraw()
        fr = m.IntakeFrame(r)
        # Test-Pack in temporärem Ordner erzeugen
        tmpdir = Path(tempfile.gettempdir()) / ("_packs_test_" + datetime.now().strftime("%H%M%S"))
        tmpdir.mkdir(parents=True, exist_ok=True)
        fr._on_click_pack(str(tmpdir))
        # prüfen, ob ZIP entstanden ist
        created = list(tmpdir.glob("pack_*.zip"))
        r.destroy()
        if created:
            return True, f"Pack OK: {created[0].name}"
        return False, "Kein ZIP erzeugt."
    except Exception as e:
        return False, str(e)

def main()->int:
    # Report neu
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass

    w("[R1151] AddPackSaveButton – Start")
    if not MODFILE.exists():
        w(f"[ERR] Datei fehlt: {MODFILE}")
        return 1

    bak = backup(MODFILE); w(f"[Backup] {bak.name}")
    src = load_txt()

    try:
        new_src, changes = patch_intake(src)
    except Exception as e:
        w(f"[ERR] Patch-Vorbereitung: {e}")
        return 1

    save_txt(new_src)
    w("[Write] " + ", ".join(changes))

    # Syntaxcheck
    try:
        py_compile.compile(str(MODFILE), doraise=True)
        w("[Syntax] OK")
    except Exception as e:
        w(f"[Syntax] Fehler: {e} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    # Headless-Test
    ok, msg = headless_probe()
    if not ok:
        w(f"[Live] Probe-Fehler: {msg} -> Rollback"); shutil.copy2(bak, MODFILE); return 1
    w(f"[Live] {msg}")

    w("[SUM] Pack-Button + Funktion sind lauffähig.")
    w("[R1151] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
