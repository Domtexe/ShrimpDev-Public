"""
Runner_1000_IntakeActions:
- Intake: Kopieren/Löschen/Leeren + Hotkeys
- ConfigMgr: remove_history, clear_history
- GUI: Versionsbump auf v9.8.2
"""
from __future__ import annotations
import os, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1000] {ts} {msg}\n")
    print(msg, flush=True)

def safe_write(path: str, data: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        os.makedirs(ARCH, exist_ok=True)
        bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
        shutil.copy2(path, bck)
        log(f"Backup: {path} -> {bck}")
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

def patch():
    try:
        # --- config_mgr.py (add remove_history / clear_history) ---
        cfg_path = os.path.join(ROOT, "modules", "config_mgr.py")
        with open(cfg_path, "r", encoding="utf-8") as f:
            src = f.read()
        if "def remove_history(" not in src:
            src = src.rstrip() + CONFIG_MGR_APPEND
            safe_write(cfg_path, src)
            log("config_mgr.py erweitert: remove_history/clear_history")
        else:
            log("config_mgr.py bereits aktuell.")

        # --- module_code_intake.py (copy/delete/clear + hotkeys) ---
        mpath = os.path.join(ROOT, "modules", "module_code_intake.py")
        with open(mpath, "r", encoding="utf-8") as f:
            src = f.read()
        # Ersetze gesamte Datei durch aktuelle Referenz (vereinfachen)
        safe_write(mpath, MODULE_CODE_INTAKE_NEW)

        # --- main_gui.py Versionsstring aktualisieren ---
        gpath = os.path.join(ROOT, "main_gui.py")
        with open(gpath, "r", encoding="utf-8") as f:
            gui = f.read()
        gui = gui.replace("ShrimpDev – v9.8.1", "ShrimpDev – v9.8.2")
        safe_write(gpath, gui)

        # --- Version + Changelog ---
        safe_write(os.path.join(ROOT, "CURRENT_VERSION.txt"), "ShrimpDev v9.8.2\n")
        changelog = os.path.join(ROOT, "CHANGELOG.md")
        if os.path.exists(changelog):
            with open(changelog, "a", encoding="utf-8") as f:
                f.write(CHANGELOG_APPEND)
        else:
            safe_write(changelog, "# CHANGELOG\n" + CHANGELOG_APPEND)

        log("Patch erfolgreich.")
        return 0
    except Exception:
        tb = traceback.format_exc()
        log("FEHLER:\n" + tb)
        return 1

CONFIG_MGR_APPEND = r"""

    def remove_history(self, item: str) -> None:
        with _LOCK:
            items = self.get_history()
            if item in items:
                items.remove(item)
            if not self.cfg.has_section("history"):
                self.cfg.add_section("history")
            self.cfg.set("history", "items", "|".join(items))
            self.save()

    def clear_history(self) -> None:
        with _LOCK:
            if not self.cfg.has_section("history"):
                self.cfg.add_section("history")
            self.cfg.set("history", "items", "")
            self.save()
"""

MODULE_CODE_INTAKE_NEW = r'''"""Intake-UI + Logik (v9.8.2)
Neu:
- Kopieren aus History (Button + Ctrl+C)
- Löschen von Dateien (Button + Entf) – endgültig, mit Bestätigung + Fallback
- Intake leeren (Pfadfeld + Statusausgabe + LED)
"""
from __future__ import annotations
import os, shutil, tkinter as tk
from tkinter import ttk, messagebox, filedialog
from modules.snippets.logger_snippet import write_log
from modules.config_mgr import ConfigMgr
from modules.snippets.file_detect_snippet import split_name_ext, classify, is_supported

_TRASH_FALLBACK = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "_Archiv", "_Trash"))

class IntakeFrame(ttk.Frame):
    def __init__(self, master: tk.Misc, **kwargs):
        super().__init__(master, **kwargs)
        self.cfg = ConfigMgr()
        self._build_ui()
        self._load_history()
        write_log("INTAKE", "UI bereit (v9.8.2)")

    def _build_ui(self):
        self.columnconfigure(1, weight=1)
        self.rowconfigure(3, weight=1)

        # Row 0: Pfad + Browse
        ttk.Label(self, text="Datei/Plan:").grid(row=0, column=0, padx=6, pady=6, sticky="w")
        self.var_path = tk.StringVar(value=self.cfg.get_str("general", "default_path", "."))
        self.ent_path = ttk.Entry(self, textvariable=self.var_path)
        self.ent_path.grid(row=0, column=1, padx=6, pady=6, sticky="ew")
        ttk.Button(self, text="Browse…", command=self._browse).grid(row=0, column=2, padx=6, pady=6)

        # Row 1: Aktionen links
        btns = ttk.Frame(self)
        btns.grid(row=1, column=1, sticky="w", padx=6, pady=4)
        ttk.Button(btns, text="Erkennen", command=self._detect).pack(side="left", padx=(0,6))
        ttk.Button(btns, text="Speichern", command=self._save).pack(side="left", padx=(0,6))
        ttk.Button(btns, text="Intake leeren", command=self._clear_intake).pack(side="left")

        # LED + Statusfarbe
        self.led = tk.Canvas(self, width=14, height=14, highlightthickness=0)
        self.led.grid(row=1, column=0, padx=6, pady=4, sticky="w")
        self._set_led("yellow")

        # History rechts (mit Buttons)
        self.col_right = ttk.Frame(self)
        self.col_right.grid(row=2, column=2, rowspan=2, sticky="ns", padx=6, pady=6)
        ttk.Label(self.col_right, text="Gespeichert:").pack(anchor="w")

        self.lst = tk.Listbox(self.col_right, height=12, exportselection=False)
        self.lst.pack(fill="both", expand=True)
        sb = ttk.Scrollbar(self.col_right, command=self.lst.yview)
        self.lst.config(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")

        btn_row = ttk.Frame(self.col_right)
        btn_row.pack(fill="x", pady=(6,0))
        ttk.Button(btn_row, text="Kopieren", command=self._copy_from_history).pack(side="left")
        ttk.Button(btn_row, text="Löschen", command=self._delete_from_history).pack(side="left", padx=6)

        # Binds (Doppelklick=Erkennen; Ctrl+C=Kopieren; Entf=Löschen)
        self.lst.bind("<Double-Button-1>", self._load_from_history)
        self.lst.bind("<Control-c>", self._copy_from_history)
        self.lst.bind("<Delete>", self._delete_from_history)

        # Ausgabe unten
        self.txt = tk.Text(self, height=6)
        self.txt.grid(row=3, column=0, columnspan=2, padx=6, pady=6, sticky="nsew")

    # --- UI helpers ---
    def _set_led(self, color: str):
        self.led.delete("all")
        self.led.create_oval(2,2,12,12, fill=color, outline="")
        self.update_idletasks()

    def _browse(self):
        path = filedialog.askopenfilename(title="Datei wählen", initialdir=os.getcwd())
        if path:
            self.var_path.set(path)

    def _clear_intake(self):
        self.var_path.set("")
        self.txt.delete("1.0", "end")
        self._set_led("yellow")
        self._status("Intake geleert.")

    # --- Actions ---
    def _detect(self):
        path = self.var_path.get().strip()
        if not path:
            self._status("Kein Pfad angegeben.", err=True); return
        name, ext = split_name_ext(path)
        typ = classify(path)
        sup = is_supported(path)
        self._status(f"Name='{name}'  Ext='{ext}'  Typ={typ}  Supported={sup}")
        self._set_led("green" if sup else "yellow")

    def _save(self):
        path = self.var_path.get().strip()
        if not path:
            self._status("Nichts zu speichern.", err=True); return
        self.cfg.set_str("general", "default_path", os.path.dirname(path) or ".")
        self.cfg.append_history(path)
        self._load_history()
        self._status("Gespeichert.")
        self._set_led("green")

    # --- History ops ---
    def _load_history(self):
        self.lst.delete(0, "end")
        for item in self.cfg.get_history():
            self.lst.insert("end", item)

    def _load_from_history(self, _evt=None):
        sel = self.lst.curselection()
        if not sel: return
        path = self.lst.get(sel[0])
        self.var_path.set(path)
        self._detect()

    def _copy_from_history(self, _evt=None):
        sel = self.lst.curselection()
        if not sel:
            self._status("Nichts markiert zum Kopieren.", err=True); return
        path = self.lst.get(sel[0])
        try:
            self.clipboard_clear()
            self.clipboard_append(path)
            self._status("Pfad kopiert.")
        except Exception as ex:
            self._status(f"Kopieren fehlgeschlagen: {ex}", err=True)

    def _delete_from_history(self, _evt=None):
        sel = self.lst.curselection()
        if not sel:
            self._status("Nichts markiert zum Löschen.", err=True); return
        path = self.lst.get(sel[0])
        if not os.path.isfile(path):
            self._status("Nur Dateien werden gelöscht (kein Ordner / Datei fehlt).", err=True)
            # trotzdem History pflegen, wenn Datei nicht existiert
            self.cfg.remove_history(path)
            self._load_history()
            return
        if not messagebox.askyesno("Löschen bestätigen", f"Datei endgültig löschen?\n\n{path}"):
            return
        try:
            os.remove(path)
            self._status("Datei gelöscht.")
        except Exception as ex:
            # Fallback: verschieben nach _Archiv\_Trash
            try:
                os.makedirs(_TRASH_FALLBACK, exist_ok=True)
                base = os.path.basename(path)
                target = os.path.join(_TRASH_FALLBACK, f"{base}.{int(os.stat(path).st_mtime)}.del")
                shutil.move(path, target)
                self._status(f"Konnte nicht löschen – nach Trash verschoben: {target}")
            except Exception as ex2:
                self._status(f"Löschen fehlgeschlagen: {ex} / Trash-Fallback fehlgeschlagen: {ex2}", err=True)
                return
        # History updaten
        self.cfg.remove_history(path)
        self._load_history()
        self._set_led("green")

def run(**kwargs):
    write_log("INTAKE", "run() invoked")
    return True

if __name__ == "__main__":
    import tkinter as tk
    root = tk.Tk()
    root.title("Intake Test v9.8.2")
    frm = IntakeFrame(root)
    frm.pack(fill="both", expand=True)
    root.mainloop()
'''

CHANGELOG_APPEND = """
## v9.8.2 (2025-10-18)
- Intake: Kopierfunktion aus History (Button + Ctrl+C)
- Intake: Dateien aus History endgültig löschen (Button + Entf), mit Bestätigung und Trash-Fallback
- Intake: „Intake leeren“-Button (Pfad & Status zurücksetzen, LED neutral)
"""

if __name__ == "__main__":
    raise SystemExit(patch())
