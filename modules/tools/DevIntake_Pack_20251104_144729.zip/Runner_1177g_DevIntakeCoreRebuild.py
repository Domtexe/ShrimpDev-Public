# -*- coding: utf-8 -*-
"""
Runner_1177g_DevIntakeCoreRebuild
Ersetzt modules/module_code_intake.py durch eine stabile ShrimpDev-Variante
(Analyse/Logs/Runner), ohne ShrimpHub-Features. Backups -> _Archiv/, Logs -> debug_output.txt.
"""
from __future__ import annotations
import os, datetime, shutil

ROOT   = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
MODS   = os.path.join(ROOT, "modules")
ARCH   = os.path.join(ROOT, "_Archiv")
LOGF   = os.path.join(ROOT, "debug_output.txt")
TARGET = os.path.join(MODS, "module_code_intake.py")

def ts(): return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def log(msg: str):
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(f"[{ts()}] [R1177g] {msg}\n")
    except Exception:
        pass

PAYLOAD = r'''# -*- coding: utf-8 -*-
"""
module_code_intake – R1177g (ShrimpDev)
Dev-Intake: Toolbar + Tabs (Analyse / Logs / Runner), Live-Tail, Gate-Check.
Kein ShrimpHub-Mix. Keine DnD/Move/Preview.
"""
from __future__ import annotations
import os, re, sys, time, threading, subprocess, traceback
from typing import List, Tuple, Optional

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
LOG_FILE = os.path.join(ROOT, "debug_output.txt")
TOOLS_DIR = os.path.join(ROOT, "tools")
MODULES_DIR = os.path.join(ROOT, "modules")

# Optional: Toolbar-Snippet (falls vorhanden). Sonst bauen wir die Toolbar selbst.
try:
    from modules.snippets.snippet_dev_intake_toolbar import attach_toolbar as _snippet_attach_toolbar
except Exception:
    _snippet_attach_toolbar = None

def _log(msg: str) -> None:
    try:
        import datetime
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] [DevIntake] {msg}\\n")
    except Exception:
        pass

class IntakeFrame(ttk.Frame):
    """ShrimpDev Dev-Intake"""
    def __init__(self, master):
        super().__init__(master)
        # GUI-Basis
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)

        # Toolbar (direkt sichtbar)
        self._build_toolbar()

        # Notebook
        self.nb = ttk.Notebook(self)
        self.nb.grid(row=1, column=0, sticky="nsew")

        # Analyse-Tab
        self.pg_an = ttk.Frame(self.nb)
        self.nb.add(self.pg_an, text="🧠 Analyse")
        cols = ("file","status","detail")
        self.tree = ttk.Treeview(self.pg_an, columns=cols, show="headings", selectmode="browse")
        for c, w in zip(cols,(420,90,600)):
            self.tree.heading(c, text=c.title()); self.tree.column(c, width=w, anchor="w")
        ys = ttk.Scrollbar(self.pg_an, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscroll=ys.set)
        self.tree.pack(side="left", fill="both", expand=True); ys.pack(side="right", fill="y")

        # Logs-Tab
        self.pg_log = ttk.Frame(self.nb); self.nb.add(self.pg_log, text="📄 Logs")
        self.txt_log = tk.Text(self.pg_log, wrap="none", height=18)
        y2 = ttk.Scrollbar(self.pg_log, orient="vertical", command=self.txt_log.yview)
        self.txt_log.configure(yscroll=y2.set)
        self.txt_log.pack(side="left", fill="both", expand=True); y2.pack(side="right", fill="y")

        # Runner-Tab
        self.pg_run = ttk.Frame(self.nb); self.nb.add(self.pg_run, text="⚙️ Runner")
        self.lbl_latest = ttk.Label(self.pg_run, text="Neuester Runner wird ermittelt…")
        self.lbl_latest.pack(fill="x", padx=6, pady=6)
        self.txt_run = tk.Text(self.pg_run, wrap="none", height=16)
        y3 = ttk.Scrollbar(self.pg_run, orient="vertical", command=self.txt_run.yview)
        self.txt_run.configure(yscroll=y3.set)
        self.txt_run.pack(side="left", fill="both", expand=True); y3.pack(side="right", fill="y")

        # Statuszeile
        self.lbl_status = ttk.Label(self, text="Bereit (ShrimpDev-Intake).", anchor="w")
        self.lbl_status.grid(row=2, column=0, sticky="ew")

        # Tail starten, Runner-Label initialisieren
        self._stop_tail = threading.Event()
        self._tail_thread: Optional[threading.Thread] = None
        self._restart_tail()
        self._update_latest_runner_label()

    # ---------- Toolbar ----------
    def _build_toolbar(self):
        # Falls Snippet verfügbar: dort bauen lassen (grid-aware). Sonst lokal.
        if _snippet_attach_toolbar is not None:
            try:
                _snippet_attach_toolbar(self)
                return
            except Exception as e:
                _log(f"Toolbar-Snippet Fehler: {e}")

        # Fallback-Toolbar lokal bauen
        tb = ttk.Frame(self)
        tb.grid(row=0, column=0, sticky="ew")
        for text, cb in (
            ("Analyse jetzt", self._run_analysis),
            ("Master-Sanity", self._run_master_sanity),
            ("Gate-Check", self._gate_check),
            ("Logs aktualisieren", self._restart_tail),
            ("Runner starten (neuester)", self._run_latest_runner),
        ):
            ttk.Button(tb, text=text, command=cb).pack(side="left", padx=4, pady=4)

    # ---------- Analyse ----------
    def _gather_py(self) -> List[str]:
        targets = []
        for base in (MODULES_DIR, TOOLS_DIR):
            if not os.path.isdir(base): continue
            for root, _, files in os.walk(base):
                for fn in files:
                    if fn.lower().endswith(".py"):
                        targets.append(os.path.join(root, fn))
        return sorted(targets)

    def _compile_file(self, p: str) -> Tuple[str,str,str]:
        try:
            src = open(p, "r", encoding="utf-8").read()
        except Exception as e:
            return (p, "ERROR", f"read: {e}")
        try:
            compile(src, p, "exec")
            return (p, "OK", "")
        except SyntaxError as e:
            return (p, "SYNTAX", f\"{e.msg} @ {e.lineno}:{e.offset}\")
        except Exception as e:
            return (p, "ERROR", f\"{e}\")

    def _run_analysis(self):
        # Tabelle leeren
        try:
            self.tree.delete(*self.tree.get_children(""))
        except Exception:
            pass
        files = self._gather_py()
        ok = bad = 0
        for p in files:
            f, st, detail = self._compile_file(p)
            if st == "OK": ok += 1
            else: bad += 1
            self.tree.insert("", "end", values=(f, st, detail))
        self.lbl_status.config(text=f"Analyse: {ok} OK, {bad} Probleme in {len(files)} Dateien.")
        _log(f"Analyse done: {ok} ok, {bad} bad")

    def _run_master_sanity(self):
        # aktuell Alias auf Analyse – später erweiterbar
        self._run_analysis()
        try:
            messagebox.showinfo("Master-Sanity", "Master-Sanity ausgeführt (Basis: Syntax-Check).")
        except Exception:
            pass

    def _gate_check(self):
        try:
            from modules import module_shim_intake as shim
            ok = all(hasattr(shim, n) for n in ("mount_intake_tab","_mount_intake_tab_shim","_remount_intake_tab_shim"))
            txt = "OK – Shim API vollständig." if ok else "FEHLER – Shim API unvollständig."
            self.lbl_status.config(text="Gate: " + txt)
            _log("Gate " + txt)
        except Exception as e:
            self.lbl_status.config(text=f"Gate: FEHLER – {e}")
            _log(f"Gate exception: {e}")

    # ---------- Logs (Tail) ----------
    def _restart_tail(self):
        try:
            if self._tail_thread and self._tail_thread.is_alive():
                self._stop_tail.set()
                self._tail_thread.join(timeout=1.0)
        except Exception:
            pass
        self._stop_tail = threading.Event()
        self.txt_log.delete("1.0", "end")
        self._tail_thread = threading.Thread(target=self._tail_loop, daemon=True)
        self._tail_thread.start()
        self.lbl_status.config(text="Log-Tail läuft.")

    def _tail_loop(self):
        path = LOG_FILE
        pos = 0
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
        except Exception:
            pass
        while not self._stop_tail.is_set():
            try:
                with open(path, "r", encoding="utf-8") as f:
                    f.seek(pos)
                    chunk = f.read()
                    pos = f.tell()
                if chunk:
                    self.txt_log.insert("end", chunk)
                    self.txt_log.see("end")
            except FileNotFoundError:
                pass
            except Exception as e:
                _log(f"Tail error: {e}")
            time.sleep(0.3)

    # ---------- Runner ----------
    def _find_latest_runner_bat(self) -> Optional[str]:
        if not os.path.isdir(TOOLS_DIR):
            return None
        cands = []
        for fn in os.listdir(TOOLS_DIR):
            if re.match(r"Runner_\\d+.*\\.bat$", fn, flags=re.I):
                p = os.path.join(TOOLS_DIR, fn)
                cands.append((os.path.getmtime(p), p))
        if not cands:
            return None
        cands.sort(reverse=True)
        return cands[0][1]

    def _update_latest_runner_label(self):
        p = self._find_latest_runner_bat()
        self.lbl_latest.config(text=("Neuester Runner: " + p) if p else "Neuester Runner: (keiner gefunden)")

    def _run_latest_runner(self):
        p = self._find_latest_runner_bat()
        if not p:
            try:
                messagebox.showinfo("Runner", "Kein Runner_*.bat gefunden.")
            except Exception:
                pass
            return
        self._update_latest_runner_label()
        self.txt_run.insert("end", f"--- Starte: {p} ---\\n")
        self.txt_run.see("end")
        thr = threading.Thread(target=self._run_proc, args=(p,), daemon=True)
        thr.start()

    def _run_proc(self, bat_path: str):
        try:
            proc = subprocess.Popen(bat_path, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, shell=True)
            for line in proc.stdout:
                self.txt_run.insert("end", line)
                self.txt_run.see("end")
            rc = proc.wait()
            self.txt_run.insert("end", f"--- Runner Ende (rc={rc}) ---\\n")
            self.txt_run.see("end")
            _log(f"Runner finished rc={rc}: {bat_path}")
        except Exception as e:
            self.txt_run.insert("end", f"[ERROR] {e}\\n")
            self.txt_run.see("end")
            _log(f"Runner exec error: {e}")
'''

def ensure_dir(p): os.makedirs(p, exist_ok=True)

def backup(path: str):
    ensure_dir(ARCH)
    bak = os.path.join(ARCH, f"module_code_intake.py.{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.bak")
    if os.path.exists(path):
        shutil.copy2(path, bak)
        log(f"Backup: {bak}")

def main() -> int:
    ensure_dir(MODS)
    backup(TARGET)
    with open(TARGET, "w", encoding="utf-8") as f:
        f.write(PAYLOAD)
    log("module_code_intake.py written (R1177g Dev).")
    print("[R1177g] Dev-Intake core rebuilt.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
