from __future__ import annotations
from pathlib import Path
import time, re

ROOT = Path(r"D:\ShrimpDev")
TOOLS = ROOT / "tools"
MODS  = ROOT / "modules"
SNIP  = MODS / "snippets"
LOGF  = ROOT / "debug_output.txt"

def log(msg: str):
    try: LOGF.open("a", encoding="utf-8", errors="ignore").write(f"[R982] {msg}\n")
    except Exception: pass
    print(f"[R982] {msg}")

def w(p: Path, s: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        bak = p.with_suffix(p.suffix + "." + time.strftime("%Y%m%d_%H%M%S") + ".bak")
        p.replace(bak); log(f"backup {bak.name}")
    p.write_text(s, encoding="utf-8"); log(f"wrote {p.relative_to(ROOT)}")

def ui_helpers_py() -> str:
    return r'''from __future__ import annotations
import tkinter as tk
from tkinter import ttk

class AutoScrollbar(ttk.Scrollbar):
    """zeigt sich nur wenn nötig"""
    def set(self, lo, hi):
        if float(lo) <= 0.0 and float(hi) >= 1.0:
            self.grid_remove()
        else:
            self.grid()
        super().set(lo, hi)
    def pack(self, *a, **k):  # blockieren
        raise RuntimeError("use grid with AutoScrollbar")
    def place(self, *a, **k):
        raise RuntimeError("use grid with AutoScrollbar")

class Led(ttk.Frame):
    """kleine Status-LED (ok/warn/error/idle)"""
    COLORS = {
        "ok":   "#22c55e",
        "warn": "#f59e0b",
        "err":  "#ef4444",
        "idle": "#9ca3af",
    }
    def __init__(self, parent, size=12, state="idle", text=""):
        super().__init__(parent)
        self._size = size
        self._canvas = tk.Canvas(self, width=size, height=size, highlightthickness=0, bd=0)
        self._canvas.grid(row=0, column=0, padx=(0,6))
        self._lbl = ttk.Label(self, text=text)
        self._lbl.grid(row=0, column=1, sticky="w")
        self.set(state)
    def set(self, state: str, text: str|None=None):
        state = state if state in self.COLORS else "idle"
        self._canvas.delete("all")
        s = self._size
        self._canvas.create_oval(1,1,s-1,s-1, fill=self.COLORS[state], outline="")
        if text is not None:
            self._lbl.configure(text=text)
'''

def patch_agent_ui(txt: str) -> str:
    # Treeview mit Scrollbar
    if "AutoScrollbar" in txt:
        return txt
    txt = txt.replace(
        "self.tree=ttk.Treeview(self, columns=cols, show=\"headings\")",
        "from modules.snippets.ui_helpers import AutoScrollbar\n"
        "wrap = ttk.Frame(self); wrap.pack(fill=\"both\", expand=True)\n"
        "self.tree=ttk.Treeview(wrap, columns=cols, show=\"headings\")\n"
        "vs = AutoScrollbar(wrap, orient=\"vertical\"); hs = AutoScrollbar(wrap, orient=\"horizontal\")\n"
        "self.tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)\n"
        "self.tree.grid(row=0, column=0, sticky=\"nsew\"); vs.grid(row=0, column=1, sticky=\"ns\"); hs.grid(row=1, column=0, sticky=\"ew\")\n"
        "wrap.rowconfigure(0, weight=1); wrap.columnconfigure(0, weight=1)"
    )
    return txt

def patch_project_ui(txt: str) -> str:
    if "AutoScrollbar" in txt:
        return txt
    txt = txt.replace(
        "self.tree=ttk.Treeview(self, columns=cols, show=\"headings\")",
        "from modules.snippets.ui_helpers import AutoScrollbar\n"
        "wrap = ttk.Frame(self); wrap.pack(fill=\"both\", expand=True)\n"
        "self.tree=ttk.Treeview(wrap, columns=cols, show=\"headings\")\n"
        "vs = AutoScrollbar(wrap, orient=\"vertical\"); hs = AutoScrollbar(wrap, orient=\"horizontal\")\n"
        "self.tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)\n"
        "self.tree.grid(row=0, column=0, sticky=\"nsew\"); vs.grid(row=0, column=1, sticky=\"ns\"); hs.grid(row=1, column=0, sticky=\"ew\")\n"
        "wrap.rowconfigure(0, weight=1); wrap.columnconfigure(0, weight=1)"
    )
    return txt

def patch_runner_board(txt: str) -> str:
    if "AutoScrollbar" in txt:
        return txt
    txt = txt.replace(
        "self.tree = ttk.Treeview(self, columns=(\"file\",\"type\"), show=\"headings\")",
        "from modules.snippets.ui_helpers import AutoScrollbar\n"
        "wrap = ttk.Frame(self); wrap.pack(fill=\"both\", expand=True)\n"
        "self.tree = ttk.Treeview(wrap, columns=(\"file\",\"type\"), show=\"headings\")\n"
        "vs = AutoScrollbar(wrap, orient=\"vertical\"); hs = AutoScrollbar(wrap, orient=\"horizontal\")\n"
        "self.tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)\n"
        "self.tree.grid(row=0, column=0, sticky=\"nsew\"); vs.grid(row=0, column=1, sticky=\"ns\"); hs.grid(row=1, column=0, sticky=\"ew\")\n"
        "wrap.rowconfigure(0, weight=1); wrap.columnconfigure(0, weight=1)"
    )
    return txt

def patch_preflight(txt: str) -> str:
    if "AutoScrollbar" in txt:
        return txt
    txt = txt.replace(
        "self.tree=ttk.Treeview(self, columns=cols, show=\"headings\")",
        "from modules.snippets.ui_helpers import AutoScrollbar\n"
        "wrap = ttk.Frame(self); wrap.pack(fill=\"both\", expand=True)\n"
        "self.tree=ttk.Treeview(wrap, columns=cols, show=\"headings\")\n"
        "vs = AutoScrollbar(wrap, orient=\"vertical\"); hs = AutoScrollbar(wrap, orient=\"horizontal\")\n"
        "self.tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)\n"
        "self.tree.grid(row=0, column=0, sticky=\"nsew\"); vs.grid(row=0, column=1, sticky=\"ns\"); hs.grid(row=1, column=0, sticky=\"ew\")\n"
        "wrap.rowconfigure(0, weight=1); wrap.columnconfigure(0, weight=1)"
    )
    return txt

def module_code_intake_py() -> str:
    return r'''from __future__ import annotations
import re, tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from typing import Tuple, List, Dict
from .common_tabs import ensure_tab
from modules.snippets.ui_helpers import AutoScrollbar, Led

# --- Config robust ------------------------------------------------------------
try:
    from modules.config_mgr import load_config, save_config
except Exception:
    def load_config() -> dict:
        return {"workspace_root": r"D:\ShrimpHub", "intake_silent_success": False}
    def save_config(_): pass

ROOT = Path(r"D:\ShrimpDev")

_PATTERNS = [
    r"(?im)^\s*(?:#|//|;|REM)\s*(?:file|filename|path|filepath)\s*:\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*$",
    r"(?im)^\s*@file\s*:\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*$",
    r"(?is)^---\s*.*?(?:^|\n)\s*(?:file|filename|path)\s*:\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*.*?---",
    r"(?is)^[`\"']{3}[^`\"'\n]*?(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)[^`\"']*?[`\"']{3}",
    r"(?is)^[`\"']{3}[^`\n]*?filename\s*=\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)[^`]*?[`\"']{3}",
    r"(?im)^\s*(?:#|//|;|REM)?\s*(?:file|filename)\s*(?:=|:)\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*$",
    r"(?i)\b(Runner_[\w\-]+\.(?:py|bat|cmd|vbs))\b",
    r"(?i)\b(module_[\w\-]+\.py)\b",
]

def _split_name_ext_to_fields(full: str) -> tuple[str, str]:
    """
    Name bis zum ERSTEN '.' (ohne Punkt) -> Feld 'Name'
    Rest (inkl. Punkt) -> Feld 'Endung'; falls kein Punkt: Endung leer.
    """
    if not full:
        return "", ""
    if "." in full:
        first = full.split(".", 1)
        name = first[0]
        ext  = "." + first[1] if first[1] else ""
    else:
        name, ext = full, ""
    return name, ext.lower()

def _detect_name_ext(code: str) -> tuple[str|None, str|None]:
    head = code[:12000]
    for pat in _PATTERNS:
        m = re.search(pat, head)
        if m:
            p = m.group("p") if "p" in m.groupdict() else m.group(1)
            name = Path(p).name
            # Split nach deiner Regel (erster Punkt)
            nm, ex = _split_name_ext_to_fields(name)
            # falls dennoch keine Endung, klassisch extrahieren
            if not ex and "." in name:
                ex = "." + name.split(".")[-1]
            return nm, ex.lower() if ex else None
    # Fallback-Heuristiken
    if re.search(r"(?m)^\s*def\s+main\s*\(", head): 
        nm, ex = _split_name_ext_to_fields(f"module_auto_{int(time.time())}.py")
        return nm, ex
    if re.search(r"(?im)^\s*@echo\s+off\b", head):
        nm, ex = _split_name_ext_to_fields(f"Runner_auto_{int(time.time())}.bat")
        return nm, ex
    nm, ex = _split_name_ext_to_fields(f"snippet_{int(time.time())}.txt")
    return nm, ex

def _map_target(ws: Path, name_field: str, ext: str) -> Path:
    n = (name_field or "").lower()
    if ext == ".py" and n.startswith("runner_"): return ws / "tools"
    if ext in {".bat", ".cmd", ".vbs", ".ps1"}:  return ws / "tools"
    if ext == ".py" and n.startswith("module_"): return ws / "modules"
    if ext == ".py":                              return ws / "modules" / "snippets"
    if ext in {".md", ".json", ".txt"}:          return ws
    return ws

class _State:
    def __init__(self):
        self.conf = load_config()
        self.ws = Path(self.conf.get("workspace_root", r"D:\ShrimpHub"))
        self.silent = bool(self.conf.get("intake_silent_success", False))
        self.items: list[dict] = []   # gespeicherte Dateien (Name, Ext, Subfolder)

def _build_tab(parent):
    st = _State()
    frm = ttk.Frame(parent)

    # --- Top: Workspace + LEDs ----------------------------------------------
    top = ttk.Frame(frm); top.pack(fill="x", pady=6)
    ttk.Label(top, text="Workspace:").pack(side="left")
    var_ws = tk.StringVar(value=str(st.ws))
    ttk.Entry(top, textvariable=var_ws, width=60).pack(side="left", padx=6)
    ttk.Button(top, text="…", command=lambda: _pick_ws(var_ws)).pack(side="left")
    led_det = Led(top, text="Erkennung"); led_det.grid(row=0, column=99, padx=10)  # rechts

    # --- Middle: Links Editor + Rechts Liste --------------------------------
    mid = ttk.Frame(frm); mid.pack(fill="both", expand=True)

    # Links: Eingabebereich + Overrides
    left = ttk.Frame(mid); left.grid(row=0, column=0, sticky="nsew")
    bar = ttk.Frame(left); bar.pack(fill="x", pady=4)
    var_name = tk.StringVar(); var_ext = tk.StringVar(); var_target = tk.StringVar()
    for lbl, var, w in (("Dateiname:", var_name, 40), ("Endung:", var_ext, 8), ("Zielordner:", var_target, 50)):
        ttk.Label(bar, text=lbl).pack(side="left"); ttk.Entry(bar, textvariable=var, width=w).pack(side="left", padx=6)

    # Text + Scrollbars
    text_wrap = ttk.Frame(left); text_wrap.pack(fill="both", expand=True)
    txt = tk.Text(text_wrap, wrap="none", undo=True)
    from modules.snippets.ui_helpers import AutoScrollbar
    vs = AutoScrollbar(text_wrap, orient="vertical"); hs = AutoScrollbar(text_wrap, orient="horizontal")
    txt.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
    txt.grid(row=0, column=0, sticky="nsew"); vs.grid(row=0, column=1, sticky="ns"); hs.grid(row=1, column=0, sticky="ew")
    text_wrap.rowconfigure(0, weight=1); text_wrap.columnconfigure(0, weight=1)

    # Rechts: Liste gespeicherter Dateien
    right = ttk.Frame(mid); right.grid(row=0, column=1, sticky="nsew", padx=(10,0))
    ttk.Label(right, text="Gespeicherte Dateien").pack(anchor="w")
    cols=("name","ext","subfolder")
    table_wrap = ttk.Frame(right); table_wrap.pack(fill="both", expand=True)
    tree = ttk.Treeview(table_wrap, columns=cols, show="headings")
    for c,w in zip(cols,(240,80,220)):
        tree.heading(c, text=c); tree.column(c, width=w, anchor="w")
    vs2 = AutoScrollbar(table_wrap, orient="vertical"); hs2 = AutoScrollbar(table_wrap, orient="horizontal")
    tree.configure(yscrollcommand=vs2.set, xscrollcommand=hs2.set)
    tree.grid(row=0, column=0, sticky="nsew"); vs2.grid(row=0, column=1, sticky="ns"); hs2.grid(row=1, column=0, sticky="ew")
    table_wrap.rowconfigure(0, weight=1); table_wrap.columnconfigure(0, weight=1)

    mid.rowconfigure(0, weight=1); mid.columnconfigure(0, weight=3); mid.columnconfigure(1, weight=2)

    # --- Bottom: Status + Buttons + Silent-Checkbox + Save-LED --------------
    btm = ttk.Frame(frm); btm.pack(fill="x", pady=6)
    status = tk.StringVar(value="Bereit.")
    ttk.Label(btm, textvariable=status, anchor="w").pack(side="left")
    var_silent = tk.BooleanVar(value=st.silent)
    def _toggle_silent():
        st.silent = bool(var_silent.get())
        st.conf["intake_silent_success"] = st.silent
        save_config(st.conf)
    ttk.Checkbutton(btm, text="Nicht wieder anzeigen (Speicher-OK)", variable=var_silent,
                    command=_toggle_silent).pack(side="left", padx=12)
    led_save = Led(btm, text="Speichern"); led_save.pack(side="left", padx=10)

    ttk.Button(btm, text="Erkennen (Ctrl+I)",
               command=lambda: _detect(txt, var_name, var_ext, var_target, var_ws, status, led_det)).pack(side="right", padx=6)
    ttk.Button(btm, text="Speichern (Ctrl+S)",
               command=lambda: _save(txt, var_name, var_ext, var_target, status, st, tree, led_save)).pack(side="right")

    # Bindings & Auto-Detect
    frm.bind_all("<Control-i>", lambda e: _detect(txt, var_name, var_ext, var_target, var_ws, status, led_det))
    frm.bind_all("<Control-s>", lambda e: _save(txt, var_name, var_ext, var_target, status, st, tree, led_save))
    txt.bind("<<Paste>>", lambda e: _after_paste_detect(frm, txt, var_name, var_ext, var_target, var_ws, status, led_det))
    txt.bind("<Control-v>", lambda e: _after_paste_detect(frm, txt, var_name, var_ext, var_target, var_ws, status, led_det))
    def _on_mod(_=None):
        txt.edit_modified(0)
        if not var_name.get() or not var_ext.get():
            _detect(txt, var_name, var_ext, var_target, var_ws, status, led_det, auto=True)
    txt.bind("<<Modified>>", _on_mod)

    return frm

def _after_paste_detect(root, txt, var_name, var_ext, var_target, var_ws, status, led_det):
    root.after(20, lambda: _detect(txt, var_name, var_ext, var_target, var_ws, status, led_det, auto=True))

def _pick_ws(var_ws: tk.StringVar):
    d = filedialog.askdirectory(title="Workspace wählen", initialdir=var_ws.get() or r"D:\ShrimpHub")
    if d: var_ws.set(d)

def _detect(txt, var_name, var_ext, var_target, var_ws, status, led_det, auto: bool=False):
    code = txt.get("1.0", "end-1c")
    nm, ex = _detect_name_ext(code)
    if nm: var_name.set(nm)
    if (not ex) and nm:
        # falls keine Endung via Pattern: aus erkanntem Namen erzeugen
        if "." in nm:
            nm2, ex2 = nm.split(".", 1)
            var_name.set(nm2)
            ex = "." + ex2 if ex2 else ""
    if ex:  var_ext.set(ex)
    name_field, ext = var_name.get().strip(), var_ext.get().strip().lower()
    if name_field and ext:
        ws = Path(var_ws.get() or r"D:\ShrimpHub")
        var_target.set(str(_map_target(ws, name_field, ext)))
        led_det.set("ok", "Erkennung OK")
    else:
        led_det.set("warn", "unvollständig")
    if not auto:
        status.set(f"Erkannt: name={name_field!r}, ext={ext!r}, target={var_target.get()!r}")

def _append_item(tree, name_field: str, ext: str, ws: Path, out: Path):
    # subfolder relativ (ohne Root)
    try:
        sub = out.parent.relative_to(ws).as_posix()
    except Exception:
        sub = out.parent.name
    tree.insert("", "end", values=(name_field, ext, sub))

def _save(txt, var_name, var_ext, var_target, status, st, tree, led_save):
    name_field, ext, target = var_name.get().strip(), var_ext.get().strip().lower(), var_target.get().strip()
    code = txt.get("1.0", "end-1c")
    if not name_field or not ext or not target:
        led_save.set("err", "unvollständig")
        messagebox.showwarning("ShrimpDev", "Bitte Name/Endung/Target prüfen.")
        return
    # finaler Dateiname: Name + Endung (Endung enthält führenden Punkt)
    final = Path(name_field).stem + (ext if ext.startswith(".") else f".{ext}")
    out_dir = Path(target); out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / final
    # Rotations-Backups
    if out.exists():
        for i in range(4,0,-1):
            pi = out.with_name(out.name + f".{i}.bak"); pj = out.with_name(out.name + f".{i+1}.bak")
            if pi.exists(): pi.replace(pj)
        try: out.with_name(out.name + ".bak").replace(out.with_name(out.name + ".1.bak"))
        except Exception: pass
    out.write_text(code, encoding="utf-8")
    if not st.silent:
        try: messagebox.showinfo("ShrimpDev", f"Gespeichert:\n{out}")
        except Exception: pass
    status.set(f"Gespeichert: {out}")
    led_save.set("ok", "gespeichert")
    # Liste aktualisieren – neue Datei unten anhängen
    _append_item(tree, name_field, ext, st.ws, out)

def open_intake(app: tk.Tk) -> bool:
    try:
        return ensure_tab(app, "intake", "Code Intake", _build_tab)
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Intake Fehler:\n{ex}")
        except Exception: pass
        return False
'''

def main():
    # helper
    w(SNIP / "ui_helpers.py", ui_helpers_py())
    # intake
    w(MODS / "module_code_intake.py", module_code_intake_py())
    # patch scrollbars in weiteren Modulen (wenn vorhanden)
    for fn, patcher in [
        (MODS/"module_agent_ui.py", patch_agent_ui),
        (MODS/"module_project_ui.py", patch_project_ui),
        (MODS/"module_runner_board.py", patch_runner_board),
        (MODS/"module_preflight.py", patch_preflight),
    ]:
        if fn.exists():
            txt = fn.read_text(encoding="utf-8", errors="ignore")
            new = patcher(txt)
            if new != txt:
                w(fn, new)
            else:
                log(f"keep {fn.relative_to(ROOT)}")
        else:
            log(f"skip (missing) {fn.relative_to(ROOT)}")
    print("[R982] Intake-UI erweitert: Liste rechts, LEDs, Scrollbars, Name/Endung-Split.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
