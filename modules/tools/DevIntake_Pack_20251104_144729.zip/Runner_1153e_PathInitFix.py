# -*- coding: utf-8 -*-
"""
Runner_1153e_PathInitFix
Zweck:
- Paketmarker anlegen: modules/__init__.py, modules/snippets/__init__.py
- sys.path-Absicherung: Projekt-Root für Import hinzufügen
- Danach automatisch tools/Runner_1153d_RegexHyphenFix.py starten

Nicht-destruktiv, idempotent.
"""
from __future__ import annotations
import os, sys, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ROOT / "tools"
MODULES = ROOT / "modules"
SNIPPETS = MODULES / "snippets"

def ensure_init(p: Path) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        p.write_text("", encoding="utf-8")

def main() -> int:
    print("[R1153e] PathInitFix – Start")
    # 1) Paketmarker
    ensure_init(MODULES / "__init__.py")
    ensure_init(SNIPPETS / "__init__.py")
    print("[R1153e] __init__.py geprüft/angelegt.")

    # 2) sys.path-Absicherung (für den Subprozess)
    env = os.environ.copy()
    py = sys.executable
    fixer = TOOLS / "Runner_1153d_RegexHyphenFix.py"
    if not fixer.exists():
        print("[R1153e] Fehler: Runner_1153d_RegexHyphenFix.py nicht gefunden.")
        return 2

    # Wir rufen python mit -c auf, damit ROOT auf sys.path sicher steht,
    # und importieren dann das Script via runpy.
    cmd = [
        py, "-X", "utf8", "-u", "-c",
        (
            "import sys,runpy,os;"
            f"p=r'{str(ROOT)}';"
            "sys.path.insert(0,p) if p not in sys.path else None;"
            f"runpy.run_path(r'{str(fixer)}', run_name='__main__')"
        )
    ]
    print(f"[R1153e] Starte RegexHyphenFix unter gesichertem sys.path …")
    rc = subprocess.call(cmd, cwd=str(ROOT), env=env)
    print(f"[R1153e] RegexHyphenFix RC={rc}")
    return rc

if __name__ == "__main__":
    raise SystemExit(main())
