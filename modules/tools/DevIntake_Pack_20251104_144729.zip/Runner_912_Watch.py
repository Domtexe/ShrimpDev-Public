import time, os
from modules.module_project_scan import scan
from modules.snippets.agent_client import send_event
def main():
    send_event({"runner":"Runner_912_Watch","level":"INFO","msg":"start"})
    last=0
    while True:
        try:
            d=scan()
            now=len(d.get("files",[]))
            if now!=last:
                send_event({"runner":"Runner_912_Watch","level":"OK","msg":f"files={now}"})
                last=now
        except Exception as ex:
            send_event({"runner":"Runner_912_Watch","level":"ERROR","msg":str(ex)})
        time.sleep(5)
if __name__=="__main__": main()
