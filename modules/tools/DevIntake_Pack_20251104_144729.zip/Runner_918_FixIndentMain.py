from __future__ import annotations
from pathlib import Path
import re, shutil, time

ROOT = Path(r"D:\ShrimpDev")
MAIN = ROOT / "main_gui.py"

def ts(): return time.strftime("%Y%m%d_%H%M%S")
def backup(p: Path) -> Path:
    b = p.with_suffix(p.suffix + f".{ts()}.bak")
    shutil.copy2(p, b)
    return b

def main():
    if not MAIN.exists():
        print("[R918] main_gui.py fehlt!")
        return 2

    txt = MAIN.read_text(encoding="utf-8", errors="ignore").splitlines()
    fixed = []
    inside_init = False
    inside_toggle = False

    for ln in txt:
        # Reparatur __init__:
        if re.match(r"\s*def\s+__init__\(self\):", ln):
            inside_init = True
            fixed.append("    " + ln.strip())  # 4 spaces für class
            continue
        if inside_init and re.match(r"\s*def\s+\w+\(", ln):
            inside_init = False

        # Reparatur toggle_quiet:
        if re.match(r"\s*def\s+toggle_quiet\(self\):", ln):
            inside_toggle = True
            fixed.append("    " + ln.strip())
            continue
        if inside_toggle and re.match(r"\s*if\s+__name__", ln):
            inside_toggle = False

        # Im __init__ oder toggle_quiet → immer 8 Spaces
        if inside_init or inside_toggle:
            if not ln.strip():
                fixed.append("")
            else:
                fixed.append("        " + ln.strip())
            continue

        fixed.append(ln)

    b = backup(MAIN)
    MAIN.write_text("\n".join(fixed), encoding="utf-8")
    print(f"[R918] Einrückung korrigiert. Backup: {b.name}")
    return 0

if __name__ == "__main__":
    main()
