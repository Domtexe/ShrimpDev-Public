# tools/Runner_1100_FixIntake_ReindentAll.py
# -*- coding: utf-8 -*-
"""
Reindents & repairs D:\ShrimpDev\modules\module_code_intake.py
- Moves stray class methods back into their classes (Tooltip, IntakeFrame)
- Repairs indentation of _send_to_recycle_bin() body (incl. SHFILEOPSTRUCTW)
- Normalizes method indents to 4 spaces
- Sanity-checks with ast.parse before writing
"""

from __future__ import annotations
import os, re, ast, shutil, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"

INTAKE_METHODS = {
    "_build_ui","_bind_shortcuts","_popup_menu","_update_led","_ping",
    "_prepare_new_intake","_clear_editor_and_fields","_copy_text",
    "_paste_name","_pick_ws","_pick_target","_on_ext_changed",
    "_normalize_ext","_on_name_edited","_guess_name_from_text",
    "_guess_ext_from_text","_apply_ext_to_name","_detect","_on_editor_paste",
    "_on_click_clear_code","_on_click_delete_selected","_run_py",
    "_path_from_selection_or_fields","_after_paste_refresh",
}

def log(msg): print(f"[R1100] {msg}")

def backup():
    ARCH.mkdir(exist_ok=True)
    dst = ARCH / f"{MOD.name}.{int(__import__('time').time())}.bak"
    shutil.copy2(MOD, dst)
    log(f"Backup: {MOD} -> {dst}")

def indent_block(lines:list[str], start:int, stop:int, spaces:int=4):
    pad = " " * spaces
    for i in range(start, stop):
        if lines[i].strip():
            lines[i] = pad + lines[i]
    return lines

def dedent_to_4(lines:list[str], start:int, stop:int):
    # Falls ein Block doppelt/zu tief eingerückt ist, auf genau 4 normalisieren
    for i in range(start, stop):
        s = lines[i]
        if not s.strip(): 
            continue
        # zähle führende Spaces
        n = len(s) - len(s.lstrip(" "))
        if n >= 8:  # zu tief → auf 4
            lines[i] = " " * 4 + s.lstrip(" ")
    return lines

def find_block_end(lines:list[str], start:int):
    # Ende eines zusammenhängenden Code-Blocks: nächste leere Zeile gefolgt von def/cls/import auf Top-Level
    i = start
    n = len(lines)
    while i < n:
        s = lines[i]
        if re.match(r"^(class|def|from |import )", s) and (len(s) - len(s.lstrip(" ")) == 0):
            break
        i += 1
    return i

def ensure_methods_in_class(lines:list[str], cls_name:str, method_names:set[str]):
    # Finde class-Zeile
    pat_cls = re.compile(rf"^class\s+{re.escape(cls_name)}\b")
    try:
        cls_idx = next(i for i,l in enumerate(lines) if pat_cls.match(l))
    except StopIteration:
        return lines
    # Position hinter class-Kopf
    i = cls_idx + 1
    n = len(lines)
    while i < n and (lines[i].strip()=="" or lines[i].lstrip().startswith("#")):
        i += 1
    # Wir erlauben ein 'pass' als Wächter und merken uns Anfang des Klassenrumpfs
    class_body_start = i
    # Alle Top-Level 'def <name>(' die zu dieser Klasse gehören, einsammeln und einrücken
    i = class_body_start
    while i < n:
        s = lines[i]
        # Stop-Kriterium (nächste top-level class def)
        if re.match(r"^class\s+\w+", s) and (len(s) - len(s.lstrip(" ")) == 0) and i != cls_idx:
            break
        # Kandidat: top-level def
        if re.match(r"^def\s+(\w+)\s*\(", s):
            m = re.match(r"^def\s+(\w+)\s*\(", s)
            name = m.group(1)
            if name in method_names:
                # Blockgrenze suchen & einrücken
                block_end = find_block_end(lines, i+1)
                indent_block(lines, i, block_end, 4)
                # Falls der Block zu tief geraten ist → auf 4 normalisieren
                dedent_to_4(lines, i, block_end)
                # nach Einrücken nicht springen – i inkrementieren
        i += 1
    # Sicherheit: erste echte Methode im Klassenrumpf mindestens 4 Spaces
    # (falls __init__ schon da ist, aber mit 12 Spaces → normalisieren)
    j = cls_idx+1
    while j < n:
        if lines[j].strip().startswith("def "):
            dedent_to_4(lines, j, find_block_end(lines, j+1))
            break
        if re.match(r"^class\s+\w+", lines[j]) and j!=cls_idx:
            break
        j+=1
    return lines

def fix_tooltip(lines:list[str]):
    # _show/_hide unter Tooltip einrücken
    return ensure_methods_in_class(lines, "Tooltip", {"_show","_hide"})

def fix_intakeframe(lines:list[str]):
    lines = ensure_methods_in_class(lines, "IntakeFrame", INTAKE_METHODS)
    # Falls nach 'class IntakeFrame' nur 'pass' kam: sicherstellen, dass __init__ auf 4 Spaces steht
    pat_cls = re.compile(r"^class\s+IntakeFrame\b")
    try:
        cls_idx = next(i for i,l in enumerate(lines) if pat_cls.match(l))
    except StopIteration:
        return lines
    # suche __init__ in den nächsten 400 Zeilen
    for k in range(cls_idx+1, min(len(lines), cls_idx+400)):
        if re.match(r"^\s*def\s+__init__\s*\(", lines[k]):
            dedent_to_4(lines, k, find_block_end(lines, k+1))
            break
    return lines

def fix_recycle_bin_body(lines:list[str]):
    # kompletten Body von _send_to_recycle_bin einrücken (inkl. class SHFILEOPSTRUCTW und return)
    # finde def-Zeile:
    try:
        start = next(i for i,l in enumerate(lines) if re.match(r"^def\s+_send_to_recycle_bin\s*\(", l))
    except StopIteration:
        return lines
    body_start = start+1
    # bis zum nächsten top-level def/class/import
    body_end = find_block_end(lines, body_start)
    indent_block(lines, body_start, body_end, 4)
    # innerhalb des Bodies: class SHFILEOPSTRUCTW + Folgezeilen ggf. normalisieren (mind. 8 → 8 oder 4 reicht)
    # (bereits 4 eingerückt, die class-Zeile bleibt bei 8+ OK)
    return lines

def sanity_compile(txt:str):
    try:
        ast.parse(txt)
        return True, ""
    except SyntaxError as e:
        # etwas Kontext ausgeben
        ln = e.lineno or 0
        ctx = "\n".join(f"{i+1:04d}: {line.rstrip()}" for i,line in enumerate(txt.splitlines()[max(0,ln-4):ln+3]))
        return False, f"SyntaxError in line {ln}: {e.msg}\n--- context ---\n{ctx}\n--------------"

def main():
    if not MOD.exists():
        log(f"Datei nicht gefunden: {MOD}")
        return 2
    src = MOD.read_text(encoding="utf-8", errors="replace").splitlines(True)

    # 1) Tooltip reparieren
    src = fix_tooltip(src)
    # 2) IntakeFrame-Methoden in die Klasse
    src = fix_intakeframe(src)
    # 3) Recycle-Bin-Body reparieren
    src = fix_recycle_bin_body(src)

    new_txt = "".join(src)
    ok, err = sanity_compile(new_txt)
    if not ok:
        log("Sanity-Check FEHLGESCHLAGEN – Datei wurde NICHT überschrieben.")
        print(err)
        return 1

    backup()
    MOD.write_text(new_txt, encoding="utf-8")
    log("Reparaturen geschrieben. Syntax OK.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
