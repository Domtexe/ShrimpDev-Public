from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
TOOLS = ROOT/"tools"
MODS  = ROOT/"modules"
TOOLS.mkdir(parents=True, exist_ok=True)
MODS.mkdir(parents=True, exist_ok=True)

def w(p: Path, s: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(s.replace("\r\n","\n"), encoding="utf-8")
    print(f"[R903] wrote {p.relative_to(ROOT)}")

# --- fix start_quiet.vbs: vermeide %PY% und set-Ballet ---
vbs = r'''Dim sh, cmd
Set sh = CreateObject("WScript.Shell")
sh.CurrentDirectory = "D:\ShrimpDev"
' Erst py -3 versuchen, sonst python
cmd = "cmd /c (where py >nul 2>nul && py -3 -u main_gui.py >> debug_output.txt 2>&1) || python -u main_gui.py >> debug_output.txt 2>&1"
sh.Run cmd, 0, False
'''
w(TOOLS/"start_quiet.vbs", vbs)

# --- robustes main_gui.py mit korrekt gebautem Menü + Project-Map-Stub ---
main_gui = r'''from __future__ import annotations
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

from modules import module_agent as agent
from modules import module_agent_ui as agent_ui
from modules import module_code_intake as intake

# Project-Map optional (Stub wenn Modul fehlt)
try:
    from modules import module_project_ui as project_ui
    _HAS_PM = True
except Exception:
    _HAS_PM = False
    class _PM_Stub:
        @staticmethod
        def open_project_map(app: tk.Tk) -> bool:
            try:
                messagebox.showinfo("ShrimpDev", "Project Map (Stub) – Modul noch nicht implementiert.")
                return True
            except Exception:
                return False
    project_ui = _PM_Stub()  # type: ignore

ROOT = Path(r"D:\ShrimpDev")

def log(msg: str) -> None:
    try:
        (ROOT/"debug_output.txt").open("a", encoding="utf-8", errors="ignore").write(f"[MAIN] {msg}\n")
    except Exception:
        pass

class ShrimpDevApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("🦐 ShrimpDev")
        self.geometry("1100x720+80+60")
        self.nb = ttk.Notebook(self); self.nb.pack(fill="both", expand=True)
        self.status = tk.StringVar(value="Bereit.")
        ttk.Label(self, textvariable=self.status, anchor="w").pack(fill="x")

        self._mk_menu()

        # Info-Tab
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="Info")
        ttk.Label(tab, text="ShrimpDev – Standalone Dev-Umgebung für ShrimpHub", font=("Segoe UI", 12)).pack(pady=12)

        # Agent starten
        agent.AGENT.start()
        log("GUI ready")

    def _mk_menu(self):
        menubar = tk.Menu(self); self.config(menu=menubar)
        m_file = tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="File", menu=m_file)
        m_tools= tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="Tools", menu=m_tools)
        m_view = tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="View",  menu=m_view)

        # File
        m_file.add_command(label="Exit", command=self._on_exit)

        # Tools
        m_tools.add_command(label="Code Intake (Ctrl+I)", command=lambda: intake.open_intake(self))
        self.bind_all("<Control-i>", lambda e: intake.open_intake(self))

        # View
        m_view.add_command(label="Agent Monitor (Ctrl+M)", command=lambda: agent_ui.open_agent_monitor(self))
        self.bind_all("<Control-m>", lambda e: agent_ui.open_agent_monitor(self))
        m_view.add_command(label="Project Map", command=lambda: project_ui.open_project_map(self))

    def _on_exit(self):
        try: agent.AGENT.stop()
        except Exception: pass
        self.after(150, self.destroy)

if __name__ == "__main__":
    try:
        app = ShrimpDevApp()
        app.mainloop()
    except Exception as ex:
        log(f"FATAL: {ex}")
        try: messagebox.showerror("ShrimpDev", f"Fataler Fehler:\n{ex}")
        except Exception: pass
'''
w(ROOT/"main_gui.py", main_gui)

# --- sehr kleiner Project-Map-Stub (sauber ersetzbar) ---
pm = r'''from __future__ import annotations
import tkinter as tk
from tkinter import ttk
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")

def open_project_map(app: tk.Tk) -> bool:
    win = tk.Toplevel(app)
    win.title("🧭 Project Map (Stub)")
    win.geometry("700x480+140+140")
    ttk.Label(win, text=f"Workspace: {ROOT}", anchor="w").pack(fill="x", padx=10, pady=10)
    ttk.Label(win, text="Dies ist ein Stub. Später: Scanner, Dependency-Graph, File-Map …").pack(padx=10, pady=10)
    return True
'''
w(MODS/"module_project_ui.py", pm)

print("[R903] Fix applied. Start via tools\\start_visible.bat or tools\\start_quiet.bat")
