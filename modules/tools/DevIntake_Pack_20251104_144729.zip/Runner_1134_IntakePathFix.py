# -*- coding: utf-8 -*-
"""
Runner_1134_IntakePathFix
- Stellt sicher, dass D:\ShrimpDev im sys.path liegt.
- Legt Dummy module_runner_exec.py an, falls fehlt.
- Testet Import und Instanziierung von IntakeFrame.
"""
from __future__ import annotations
import sys, os, importlib.util, traceback
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parents[1]
MODS = ROOT / "modules"
TARGET = MODS / "module_code_intake.py"
DUMMY = MODS / "module_runner_exec.py"
REPORT = ROOT / "_Reports" / "Runner_1134_IntakePathFix_report.txt"
REPORT.parent.mkdir(exist_ok=True)

def w(msg: str):
    with open(REPORT, "a", encoding="utf-8") as f:
        f.write(msg.rstrip() + "\n")

def ensure_dummy():
    if not DUMMY.exists():
        DUMMY.write_text(
            "# Auto-created stub\n"
            "def subst(*a, **kw):\n"
            "    return a[0] if a else ''\n",
            encoding="utf-8",
        )
        w(f"[Stub] {DUMMY} erstellt.")

def main() -> int:
    w("Runner_1134_IntakePathFix – Start")
    if not TARGET.exists():
        w("[FEHLER] module_code_intake.py nicht gefunden.")
        return 2

    sys.path.insert(0, str(ROOT))
    w(f"[sys.path+]: {ROOT}")

    ensure_dummy()

    # Import testen
    try:
        spec = importlib.util.spec_from_file_location("modules.module_code_intake", TARGET)
        m = importlib.util.module_from_spec(spec)
        sys.modules["modules.module_code_intake"] = m
        spec.loader.exec_module(m)
        w("[Import] OK – module_code_intake geladen.")
    except Exception:
        w("[Import-Fehler]\n" + "".join(traceback.format_exc()))
        return 1

    # Instanziierungs-Test
    try:
        import tkinter as tk
        root = tk.Tk(); root.withdraw()
        host = tk.Frame(root)
        host.pack()
        f = m.IntakeFrame(host)
        root.destroy()
        w("[Ergebnis] IntakeFrame erfolgreich instanziiert.")
        print("[R1134] IntakeFrame OK.")
        return 0
    except Exception:
        w("[Fehler bei Instanziierung]\n" + "".join(traceback.format_exc()))
        print("[R1134] Intake weiterhin defekt – siehe Report.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
