# -*- coding: utf-8 -*-
"""
Runner 1174d – MainGui Intake Cleanup
Entfernt alte/defekte Intake-Helper-Blöcke (#1129) und korrigiert Einrückungen.
Beibehaltung der gültigen [1173f]-Definition am Dateiende.
"""
import os, re, time, shutil, py_compile, traceback

ROOT = r"D:\ShrimpDev"
TARGET = os.path.join(ROOT, "main_gui.py")
ARCHIV = os.path.join(ROOT, "_Archiv")
os.makedirs(ARCHIV, exist_ok=True)

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"[1174d {ts}] {msg}")
    with open(os.path.join(ROOT, "debug_output.txt"), "a", encoding="utf-8") as f:
        f.write(f"[1174d {ts}] {msg}\n")

def backup(src):
    ts = str(int(time.time()))
    dst = os.path.join(ARCHIV, f"main_gui.py.{ts}.bak")
    shutil.copy2(src, dst)
    log(f"Backup erstellt: {dst}")
    return dst

def read(path): return open(path, "r", encoding="utf-8").read()
def write(path, data): open(path, "w", encoding="utf-8", newline="\n").write(data)

def main():
    if not os.path.exists(TARGET):
        log("FEHLER: main_gui.py nicht gefunden.")
        return 2

    src = read(TARGET)
    bak = backup(TARGET)

    # 1️⃣ Oberen fehlerhaften Intake-Block (#1129) komplett entfernen
    cleaned = re.sub(
        r"# === 1129 Intake Load Guard.*?# === /1129 ===",
        "# === 1129 Intake Load Guard (entfernt durch 1174d) ===",
        src,
        flags=re.S
    )

    # 2️⃣ Fehlende oder eingerückte Triple-Quotes am Anfang korrigieren
    cleaned = re.sub(r"^[ \t]+(\"\"\"ShrimpDev", r"\1", cleaned)

    # 3️⃣ Doppelte _mount_intake_tab_safe oder _safe_add_intake_tab eliminieren (nur untere behalten)
    blocks = re.findall(r"def\s+_(?:mount|safe)_intake_tab_[\s\S]+?(?=\n\S)", cleaned)
    if len(blocks) > 2:
        log(f"Mehrere Intake-Helper gefunden ({len(blocks)}), nur letzte 2 bleiben.")
        cleaned = re.sub(
            r"def\s+_(?:mount|safe)_intake_tab_[\s\S]+?(?=\n\S)",
            "",
            cleaned,
            count=len(blocks) - 2
        )

    tmp = TARGET + ".1174d.tmp"
    write(tmp, cleaned)
    try:
        py_compile.compile(tmp, doraise=True)
    except Exception as ex:
        log("Syntaxfehler -> Rollback.")
        log("".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        shutil.copy2(bak, TARGET)
        os.remove(tmp)
        return 1

    write(TARGET, cleaned)
    os.remove(tmp)
    log("Patch übernommen, Syntax OK.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
