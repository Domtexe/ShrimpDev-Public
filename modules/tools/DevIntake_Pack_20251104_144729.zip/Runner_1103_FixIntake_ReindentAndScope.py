# tools/Runner_1103_FixIntake_ReindentAndScope.py
# Reindents Tooltip/IntakeFrame methods back into their classes and sanity-checks.

from __future__ import annotations
import io, os, re, sys, time
from pathlib import Path

ROOT   = Path(__file__).resolve().parents[1]
MOD    = ROOT / "modules" / "module_code_intake.py"
ARCH   = ROOT / "_Archiv"
ENC    = "utf-8"

MARK_STOP = re.compile(r"^(?:# ---|import\s+re\s+as\s+_re1089\b)", re.M)

def read_text(p: Path) -> str:
    with p.open("rb") as f:
        raw = f.read()
    # tolerant decode
    for enc in (ENC, "utf-8-sig", "latin-1"):
        try:
            return raw.decode(enc)
        except Exception:
            pass
    return raw.decode("utf-8", "replace")

def write_text(p: Path, s: str) -> None:
    with p.open("w", encoding=ENC, newline="") as f:
        f.write(s)

def backup(p: Path) -> Path:
    ARCH.mkdir(exist_ok=True)
    ts = int(time.time())
    b = ARCH / f"{p.name}.{ts}.bak"
    b.write_bytes(p.read_bytes())
    return b

def indent_block(lines: list[str], start: int, indent: str = "    ") -> int:
    """
    Indent from `start` (def at col 0) until next top-level def/class/marker/import
    Returns index of the first line AFTER the indented block.
    """
    i = start
    n = len(lines)
    i += 1
    while i < n:
        s = lines[i]
        if s.startswith("def ") or s.startswith("class ") or MARK_STOP.match(s) or s.startswith("from ") or s.startswith("import "):
            break
        # keep blank lines, comments, etc. Just indent one level
        if s.strip():
            lines[i] = indent + s
        else:
            lines[i] = indent + s  # keep structure consistent
        i += 1
    # also indent the def line itself:
    lines[start] = indent + lines[start]
    return i

def reindent_methods_into_class(src: str, class_name: str, start_after: str | None = None) -> str:
    """
    Within class `<class_name>`, indent any top-level 'def name(self, ...):' that
    should be methods but accidentally live at col 0.
    If start_after is given, begin scanning after that substring occurrence.
    """
    # Find class header
    m = re.search(rf"^class\s+{re.escape(class_name)}\s*\([^)]*\)\s*:\s*$", src, re.M)
    if not m:
        return src
    cls_line_idx = src[:m.start()].count("\n")
    lines = src.splitlines(True)

    # Determine scan window:
    scan_start = cls_line_idx + 1
    if start_after:
        pos = src.find(start_after, m.end())
        if pos != -1:
            scan_start = src[:pos].count("\n") + 1

    i = scan_start
    while i < len(lines):
        s = lines[i]
        if s.startswith("class ") and i != scan_start:
            # next class reached -> stop
            break
        if MARK_STOP.match(s):
            break
        # Only catch lost methods that clearly look like methods of the class (self as first arg)
        if re.match(r"^def\s+[A-Za-z_][A-Za-z0-9_]*\s*\(\s*self\b", s):
            i = indent_block(lines, i, indent="    ")
            continue
        i += 1
    return "".join(lines)

def indent_tooltip_methods(src: str) -> str:
    # Class Tooltip header
    m = re.search(r"^class\s+Tooltip\s*:\s*$", src, re.M)
    if not m:
        return src
    cls_line_idx = src[:m.start()].count("\n")
    lines = src.splitlines(True)

    i = cls_line_idx + 1
    while i < len(lines):
        s = lines[i]
        if s.startswith("class ") and i != cls_line_idx + 1:
            break
        if MARK_STOP.match(s):
            break
        # pick only _show/_hide that accidentally sit at col 0
        if re.match(r"^def\s+_(show|hide)\s*\(\s*self\b", s):
            i = indent_block(lines, i, indent="    ")
            continue
        i += 1
    return "".join(lines)

def sanity_compile(code: str) -> None:
    # quick syntax check
    compile(code, str(MOD), "exec")

def main() -> int:
    dry = ("--dry" in sys.argv)
    if not MOD.exists():
        print(f"[R1103] Datei fehlt: {MOD}")
        return 1

    src0 = read_text(MOD)

    # 1) Tooltip._show/_hide in Klasse schieben
    src1 = indent_tooltip_methods(src0)

    # 2) IntakeFrame-Methoden zurück in die Klasse
    #    wir beginnen NACH dem __init__-Bereich/GUI-Aufbau, aber VOR den Marker-Sektionen
    src2 = reindent_methods_into_class(src1, "IntakeFrame")

    # Wenn nichts verändert wurde – trotzdem Syntax prüfen
    if src2 == src0:
        try:
            sanity_compile(src2)
            print("[R1103] Keine Änderungen nötig. Syntax OK.")
            return 0
        except Exception as ex:
            print("[R1103] SyntaxError trotz keiner Änderungen – versuche trotzdem zu retten …")
            # fällt unten in den Schreibpfad, damit wir Feedback bekommen

    # Syntaxprobe VOR dem Schreiben
    try:
        sanity_compile(src2)
    except Exception as ex:
        # Kontext ausgeben
        print(f"[R1103] SyntaxError nach Fix: {ex.__class__.__name__}: {ex}")
        # zeige ein paar Zeilen um die Fehlerstelle (falls verfügbar)
        try:
            import traceback
            tb = traceback.format_exception_only(type(ex), ex)[-1]
            print(tb)
        except Exception:
            pass
        print("[R1103] Datei bleibt unverändert.")
        return 2

    if dry:
        print("[R1103] Dry-Run: Änderungen würden geschrieben (kein Schreibvorgang ausgeführt).")
        return 0

    b = backup(MOD)
    write_text(MOD, src2)
    print(f"[R1103] Backup: {MOD} -> {b}")
    print("[R1103] Reparatur geschrieben. Syntax OK.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
