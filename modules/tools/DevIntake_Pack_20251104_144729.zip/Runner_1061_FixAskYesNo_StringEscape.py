"""
Runner_1061_FixAskYesNo_StringEscape
Behebt SyntaxError: 'unterminated string literal' im Delete-Handler.
Korrigiert Escape-Sequenzen (\n) im msg-String und erzwingt CRLF + 4-Space-Indent.

Version: v9.9.51
"""
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

CANON_DELETE = (
    "    def _on_click_delete(self, _evt=None):\n"
    "        \"\"\"Gewählte Datei nach Bestätigung löschen und UI zurücksetzen.\"\"\"\n"
    "        path = \"\"\n"
    "        try:\n"
    "            sel = self.tree_right.selection()\n"
    "            if sel and hasattr(self, 'path_of_item'):\n"
    "                path = self.path_of_item(sel[0])\n"
    "        except Exception:\n"
    "            path = \"\"\n"
    "        if not path:\n"
    "            self._ping(\"Keine Datei gewählt.\")\n"
    "            return\n"
    "        # Sichere String-Konkatenation mit explizitem \\n\\n\n"
    "        msg = \"Datei endgültig löschen?\\\\n\\\\n\" + str(path)\n"
    "        if not messagebox.askyesno(\"Löschen bestätigen\", msg):\n"
    "            return\n"
    "        try:\n"
    "            os.remove(path)\n"
    "        except Exception as ex:\n"
    "            self._ping(\"Fehler beim Löschen: \" + str(ex))\n"
    "            return\n"
    "        self._load_table()\n"
    "        try:\n"
    "            self._clear_editor_and_fields()\n"
    "        except Exception:\n"
    "            pass\n"
    "        self._ping(\"Gelöscht.\")\n"
    "\n"
)

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1061] {ts} {msg}\n")
    except Exception:
        pass

def read_file(p):
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def write_backup(p, data):
    os.makedirs(ARCH, exist_ok=True)
    b = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, b)
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {p} -> {b}")

def ensure_import(src):
    if "from tkinter import messagebox" in src:
        return src
    ins = re.search(r"import\s+tkinter\s+as\s+tk", src)
    if ins:
        return src[:ins.end()] + "\nfrom tkinter import messagebox" + src[ins.end():]
    return "from tkinter import messagebox\n" + src

def patch():
    src = read_file(MOD)
    src = ensure_import(src)

    m = re.search(r"(class\s+IntakeFrame\(ttk\.Frame\):)([\s\S]+)", src)
    if not m:
        log("IntakeFrame nicht gefunden")
        return 1
    head, body = src[:m.start(2)], m.group(2).replace("\t", "    ")

    pat = re.compile(r"\n\s*def\s+_on_click_delete\([^\)]*\):[\s\S]*?(?=\n\s*def\s+|\Z)")
    if pat.search(body):
        body = pat.sub("\n" + CANON_DELETE, body, count=1)
        log("_on_click_delete() ersetzt.")
    else:
        body += "\n" + CANON_DELETE
        log("_on_click_delete() hinzugefügt.")

    new_src = head + body
    if new_src != src:
        write_backup(MOD, new_src)
        log("Patch angewendet.")
    else:
        log("Keine Änderungen nötig.")
    return 0

if __name__ == "__main__":
    raise SystemExit(patch())
