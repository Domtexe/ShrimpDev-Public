# -*- coding: utf-8 -*-
"""
Runner_1171q_IntakeToolbarReflowSafe.py
Ziel: Keinen riskanten Inline-Reflow mehr. Externen Helper schreiben + Lifecycle sauber verdrahten.
"""
import io, os, re, sys, time, shutil, py_compile
from datetime import datetime
ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD    = os.path.join(ROOT, "modules", "module_code_intake.py")
SNIP   = os.path.join(ROOT, "modules", "snippets", "intake_toolbar_reflow_helper.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOG    = os.path.join(ROOT, "debug_output.txt")

def _log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1171q {ts}] {msg}"
    print(line)
    try:
        with io.open(LOG, "a", encoding="utf-8") as f: f.write(line+"\n")
    except Exception:
        pass

def _backup() -> str:
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"module_code_intake.py.{int(time.time())}.bak")
    shutil.copy2(MOD, bak)
    _log(f"Backup erstellt: {bak}")
    return bak

def _write_helper():
    os.makedirs(os.path.dirname(SNIP), exist_ok=True)
    if not os.path.exists(SNIP):
        from textwrap import dedent
        with io.open(SNIP, "w", encoding="utf-8") as f:
            f.write(dedent(open(os.path.join(os.path.dirname(__file__), "..", "modules", "snippets", "intake_toolbar_reflow_helper.py"), "r", encoding="utf-8").read()
                           if False else """# -*- coding: utf-8 -*-
def intake_toolbar_reflow_helper(self):
    try:
        import tkinter as tk
        from tkinter import ttk
    except Exception:
        return
    try:
        bar = getattr(self, "toolbar", None) or getattr(self, "frm_actions", None)
        if not bar:
            return
        btn_names = ["btn_guard","btn_pack","btn_refresh","btn_repair","btn_run","btn_save","btn_open","btn_detect","btn_clear"]
        btns = [getattr(self, n, None) for n in btn_names]
        btns = [b for b in btns if b is not None]
        for i,b in enumerate(btns):
            try: b.grid_configure(row=0, column=i, padx=(6 if i else 0, 0), sticky="w")
            except Exception: pass
        try:
            for i in range(len(btns)):
                bar.grid_columnconfigure(i, minsize=96, weight=0)
        except Exception: pass
    except Exception:
        pass
"""))
        _log(f"Helper geschrieben: {SNIP}")
    else:
        _log("Helper existiert – keine Änderung.")

def _load() -> str:
    with io.open(MOD, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def _save(s: str):
    with io.open(MOD, "w", encoding="utf-8") as f:
        f.write(s)

def _inject_import_and_call(src: str) -> str:
    out = src

    # 1) Import (idempotent)
    if "intake_toolbar_reflow_helper" not in out:
        out = re.sub(r"(\n\s*#\s*-{3,}.*helpers.*\n)", r"\1\n    # R1171q: toolbar reflow import\n    try:\n        from modules.snippets.intake_toolbar_reflow_helper import intake_toolbar_reflow_helper\n    except Exception:\n        def intake_toolbar_reflow_helper(self):\n            pass\n", out, count=1, flags=re.IGNORECASE)

    # 2) Lifecycle-Wire: am Ende von _build_ui(self) → call
    pat = re.compile(r"(\n\s*def\s+_build_ui\(\s*self\s*\)\s*:[\s\S]*?)\n(\s*#|\s*def|\Z)", re.M)
    m = pat.search(out)
    if m:
        block = m.group(1)
        if "intake_toolbar_reflow_helper(self)" not in block:
            # call kurz vor Blockende auf gleicher Basisindent
            base_indent = re.search(r"\n(\s*)\w", block[::-1]).group(1)[::-1] if True else "    "
            call = f"\n{base_indent}    try:\n{base_indent}        intake_toolbar_reflow_helper(self)\n{base_indent}    except Exception:\n{base_indent}        pass\n"
            block = block + call
            out = out[:m.start(1)] + block + out[m.end(1):]
            _log("Lifecycle-Call injiziert.")
        else:
            _log("Lifecycle-Call bereits vorhanden.")
    else:
        _log("WARN: _build_ui(self) nicht gefunden – keine Verdrahtung.")
    return out

def _syntax_ok() -> bool:
    try:
        py_compile.compile(MOD, doraise=True)
        return True
    except Exception as ex:
        _log(f"Syntax-Check FEHLER: {ex}")
        return False

def main():
    _log("IntakeToolbarReflowSafe: starte Patch...")
    _write_helper()
    bak = _backup()
    src = _load()
    out = _inject_import_and_call(src)
    _save(out)
    if _syntax_ok():
        _log("Patch OK.")
        sys.exit(0)
    else:
        shutil.copy2(bak, MOD)
        _log("Rollback auf Backup (Syntax-Fehler).")
        sys.exit(2)

if __name__ == "__main__":
    main()
