# -*- coding: utf-8 -*-
"""
Runner 1174b – MainGui Intake Helpers Fix
-----------------------------------------
Repariert defekte oder fehlende Intake-Tab-Helfer in main_gui.py:
- entfernt alte _safe_add_intake_tab / _mount_intake_tab_safe-Blöcke
- fügt saubere, getestete Version vor dem __main__-Block ein
- Backup + Syntax-Check + Rollback + Log in debug_output.txt
"""
import os, io, re, sys, time, shutil, traceback, py_compile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "main_gui.py")
ARCHIV = os.path.join(ROOT, "_Archiv")
DBG = os.path.join(ROOT, "debug_output.txt")

os.makedirs(ARCHIV, exist_ok=True)

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with io.open(DBG, "a", encoding="utf-8", newline="\n") as f:
        f.write(f"[1174b {ts}] {msg}\n")
    print(msg)

def read(p): return io.open(p, "r", encoding="utf-8", errors="ignore").read()
def write(p, s): io.open(p, "w", encoding="utf-8", newline="\n").write(s)

def backup(src):
    ts = str(int(time.time()))
    dst = os.path.join(ARCHIV, f"main_gui.py.{ts}.bak")
    shutil.copy2(src, dst)
    log(f"Backup erstellt: {dst}")
    return dst

HELPER_BLOCK = """
# === Intake Tab Safe Helpers (auto, 1174b) ===
import traceback
try:
    import tkinter as tk
    from tkinter import ttk
except Exception:
    pass

def _mount_intake_tab_safe(parent):
    \"\"\"Baut den Intake-Frame sicher auf und gibt bei Fehlern neutralen Frame zurück.\"\"\"
    try:
        from modules.module_code_intake import IntakeFrame
        frame = IntakeFrame(parent)
        frame.pack(fill="both", expand=True)
        return frame
    except Exception as ex:
        try:
            from tkinter import ttk
            fallback = ttk.Frame(parent)
            ttk.Label(fallback, text="Fehler beim Laden des Intake-Tabs. Details siehe debug_output.txt").pack(padx=10,pady=10)
            try:
                with open(r"debug_output.txt","a",encoding="utf-8") as f:
                    f.write("[1174b] IntakeFrame-Fehler:\\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)) + "\\n")
            except Exception: pass
            fallback.pack(fill="both", expand=True)
            return fallback
        except Exception:
            return None

def _safe_add_intake_tab(nb):
    \"\"\"Hängt den Intake-Tab sicher ans Notebook an.\"\"\"
    try:
        tab = ttk.Frame(nb)
        nb.add(tab, text="Code Intake")
    except Exception:
        return None
    try:
        tab.after(50, lambda: _mount_intake_tab_safe(tab))
    except Exception:
        _mount_intake_tab_safe(tab)
    return tab
# === /Intake Tab Safe Helpers (1174b) ===
""".lstrip("\n")

PAT_REMOVE = re.compile(r"^\s*def\s+_safe_add_intake_tab\s*\([^)]*\)\s*:[\s\S]*?(?=^\s*def\s+|^if\s+__name__|$)", re.M)
PAT_REMOVE2= re.compile(r"^\s*def\s+_mount_intake_tab_safe\s*\([^)]*\)\s*:[\s\S]*?(?=^\s*def\s+|^if\s+__name__|$)", re.M)

def main():
    src = read(TARGET)
    bak = backup(TARGET)

    # Alte Blöcke entfernen
    new_src = PAT_REMOVE.sub("", src)
    new_src = PAT_REMOVE2.sub("", new_src)

    # Helper-Block vor __main__ einfügen, sonst ans Ende
    m = re.search(r"\nif\s+__name__\s*==\s*['\"]__main__['\"]\s*:", new_src)
    if m:
        pos = m.start()
        new_src = new_src[:pos] + "\n" + HELPER_BLOCK + new_src[pos:]
        log("Helper-Block vor __main__ eingefügt.")
    else:
        new_src = new_src.rstrip() + "\n\n" + HELPER_BLOCK
        log("__main__ nicht gefunden – Helper-Block ans Ende angehängt.")

    # Syntax-Check
    tmp = TARGET + ".1174b.tmp"
    write(tmp, new_src)
    try:
        py_compile.compile(tmp, doraise=True)
    except Exception as ex:
        log("Syntax-Fehler -> Rollback.")
        log("".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        shutil.copy2(bak, TARGET)
        sys.exit(1)
    else:
        write(TARGET, new_src)
        log("Patch übernommen, Syntax OK.")
        os.remove(tmp)
        sys.exit(0)

if __name__ == "__main__":
    main()
