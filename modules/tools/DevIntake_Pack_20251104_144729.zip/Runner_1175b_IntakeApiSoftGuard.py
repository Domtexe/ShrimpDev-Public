from __future__ import annotations
import os
from patchlib_guard import guarded_apply, has_function, upsert_function, ensure_import

ROOT = r"D:\ShrimpDev"
MODP = os.path.join(ROOT, "modules", "module_code_intake.py")

# Wir fügen NICHTS De-struktives ein – nur einen API-Wrapper, falls später gebraucht.
WRAPPER_NAME = "create_intake_tab"
WRAPPER_FUNC = r'''
def create_intake_tab(parent):
    """
    Einheitlicher Factory-Wrapper:
    Gibt ein Frame für den Intake-Tab zurück.
    Greift auf vorhandene Build-Funktionen/Objekte des Moduls zurück.
    """
    try:
        # 1) build_ui(parent)
        if "build_ui" in globals() and callable(build_ui):
            return build_ui(parent)

        # 2) Klasse mit .build(parent)
        if "CodeIntake" in globals():
            inst = CodeIntake()  # type: ignore
            if hasattr(inst, "build"):
                return inst.build(parent)

        # 3) Notfalls ein simples leeres Frame – besser als Crash
        try:
            from tkinter import ttk
            return ttk.Frame(parent)
        except Exception:
            return None
    except Exception:
        try:
            import traceback
            with open(r"D:\ShrimpDev\debug_output.txt","a",encoding="utf-8") as f:
                f.write("\n[INTAKE_API_WRAPPER_ERROR]\n")
                traceback.print_exc(file=f)
        except Exception:
            pass
        return None
'''

def _transform(ctx):
    # tkinter optional für Fallback
    ctx.modified = ensure_import(ctx.modified, "from tkinter import ttk")
    if not has_function(ctx.modified, WRAPPER_NAME):
        ctx.modified = upsert_function(ctx.modified, WRAPPER_FUNC, WRAPPER_NAME)

ok, msg = guarded_apply(MODP, _transform)
print(("[1175b] " + (msg or "")).strip())
raise SystemExit(0 if ok else 1)
