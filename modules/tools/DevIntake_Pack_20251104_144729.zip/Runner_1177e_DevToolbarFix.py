# -*- coding: utf-8 -*-
"""
Runner_1177e_DevToolbarFix
- Repariert die Sichtbarkeit der ShrimpDev-Intake-Toolbar.
- Aktualisiert snippet_dev_intake_toolbar.py auf Grid-Mount (mit automatischem Row-Shift).
- Erzwingt attach_toolbar(self) NACH _build_ui() in module_code_intake.py.
- Backups nach _Archiv/, Logging nach debug_output.txt.
"""
from __future__ import annotations
import os, re, datetime, shutil

ROOT   = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
MOD    = os.path.join(ROOT, "modules")
SNIP   = os.path.join(MOD, "snippets")
TOOLBAR = os.path.join(SNIP, "snippet_dev_intake_toolbar.py")
INTAKE  = os.path.join(MOD, "module_code_intake.py")
ARCH    = os.path.join(ROOT, "_Archiv")
LOGF    = os.path.join(ROOT, "debug_output.txt")

def ts(): return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def log(msg: str):
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(f"[{ts()}] [R1177e] {msg}\n")
    except Exception:
        pass

def backup(path: str):
    if not os.path.exists(path): return
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(path)}.{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.bak")
    shutil.copy2(path, bak)
    log(f"Backup: {bak}")

NEW_SNIPPET = r'''# -*- coding: utf-8 -*-
"""
snippet_dev_intake_toolbar – R1177e (ShrimpDev ONLY)
Toolbar sichtbar montieren:
- Erkennt vorhandenes Geometry-Management.
- Bei GRID: Toolbar in row=0, verschiebt existierende Grid-Widgets um +1 Zeile.
- Bei PACK/ohne Widgets: pack(side="top") als Fallback.
Buttons:
- Analyse jetzt / Master-Sanity / Gate-Check / Logs aktualisieren / Runner starten (neuester)
"""
from __future__ import annotations
import tkinter as tk
from tkinter import ttk, messagebox

def _bind_or_warn(frame, method_name, fallback_text):
    fn = getattr(frame, method_name, None)
    if callable(fn):
        return fn
    def _fallback():
        try:
            messagebox.showinfo("Nicht verfügbar", fallback_text)
        except Exception:
            pass
    return _fallback

def _uses_grid(w):
    try:
        for child in w.winfo_children():
            if child.winfo_manager() == "grid":
                return True
    except Exception:
        pass
    return False

def _shift_grid_rows_down(w):
    """Alle bestehenden Grid-Children in row >=0 um +1 verschieben."""
    try:
        for child in w.winfo_children():
            if child.winfo_manager() != "grid":
                continue
            info = child.grid_info()
            try:
                r = int(info.get("row", 0))
            except Exception:
                r = 0
            c = int(info.get("column", 0))
            child.grid_forget()
            child.grid(row=r+1, column=c, sticky=info.get("sticky",""))
    except Exception:
        pass

def attach_toolbar(frame) -> None:
    # doppelte Anlage vermeiden
    if getattr(frame, "_dev_toolbar_ready", False):
        return

    # Container erstellen
    tb = ttk.Frame(frame)

    # Buttons definieren
    btns = (
        ("Analyse jetzt",        "_run_analysis",       "Analyse-Handler fehlt in diesem Intake."),
        ("Master-Sanity",        "_run_master_sanity",  "Master-Sanity-Handler fehlt in diesem Intake."),
        ("Gate-Check",           "_gate_check",         "Gate-Check-Handler fehlt in diesem Intake."),
        ("Logs aktualisieren",   "_restart_tail",       "Log-Tail-Handler fehlt in diesem Intake."),
        ("Runner starten (neuester)", "_run_latest_runner", "Runner-Start-Handler fehlt in diesem Intake."),
    )
    for text, method, fb in btns:
        b = ttk.Button(tb, text=text, command=_bind_or_warn(frame, method, fb))
        b.pack(side="left", padx=4, pady=4)

    # Statuszeile nur anlegen, wenn nicht vorhanden
    if not hasattr(frame, "lbl_status"):
        frame.lbl_status = ttk.Label(frame, text="Bereit (Dev-Intake).", anchor="w")
        # Statuszeile wird unterhalb der Buttons platziert
        lbl = frame.lbl_status
        # Bei PACK-Fallback hängen wir sie später an

    # Sichtbar montieren
    try:
        if _uses_grid(frame):
            # existierende Grids eine Reihe nach unten schieben, dann Toolbar oben einfügen
            _shift_grid_rows_down(frame)
            frame.grid_columnconfigure(0, weight=1)
            tb.grid(row=0, column=0, sticky="ew")
            if hasattr(frame, "lbl_status"):
                frame.lbl_status.grid(row=9999, column=0, sticky="ew")  # ganz unten
        else:
            # Fallback: pack oben
            tb.pack(side="top", fill="x")
            if hasattr(frame, "lbl_status"):
                frame.lbl_status.pack(fill="x")
    except Exception:
        # letzter Fallback
        tb.pack(side="top", fill="x")
        if hasattr(frame, "lbl_status"):
            frame.lbl_status.pack(fill="x")

    frame._dev_toolbar_ready = True
'''

def patch_snippet() -> None:
    if not os.path.exists(TOOLBAR):
        raise FileNotFoundError("snippet_dev_intake_toolbar.py nicht gefunden")
    src = open(TOOLBAR, "r", encoding="utf-8").read()
    if "R1177e" in src:
        log("Snippet bereits auf R1177e-Stand.")
        return
    backup(TOOLBAR)
    with open(TOOLBAR, "w", encoding="utf-8") as f:
        f.write(NEW_SNIPPET)
    log("Snippet aktualisiert (Grid-Mount + Autoschieben).")

def patch_module_after_build_ui() -> None:
    if not os.path.exists(INTAKE):
        raise FileNotFoundError("module_code_intake.py nicht gefunden")
    src = open(INTAKE, "r", encoding="utf-8").read()
    orig = src

    # Falls attach_toolbar(self) bereits NACH _build_ui() vorhanden ist: fertig
    if re.search(r"_build_ui\(\)\s*\n\s*try:\s*attach_toolbar\(self\)", src):
        log("attach_toolbar bereits nach _build_ui() vorhanden.")
    else:
        # Nach dem ersten Aufruf von _build_ui() in __init__ einfügen
        src = re.sub(
            r"(def\s+__init__\s*\(\s*self[^)]*\)\s*:\s*[\s\S]*?_build_ui\(\)\s*)",
            r"\1\n        try:\n            attach_toolbar(self)\n        except Exception as _e:\n            try:\n                _log(f\"[R1177e] toolbar attach post-build failed: {_e}\")\n            except Exception:\n                pass\n",
            src, count=1
        )

    if src != orig:
        backup(INTAKE)
        with open(INTAKE, "w", encoding="utf-8") as f:
            f.write(src)
        log("module_code_intake.py gepatcht (Hook nach _build_ui()).")
    else:
        log("module_code_intake.py unverändert.")

def main() -> int:
    patch_snippet()
    patch_module_after_build_ui()
    print("[R1177e] Toolbar-Fix angewendet.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
