"""
Runner_1062_FutureAtTop
Bringt alle `from __future__ import ...`-Zeilen an den Dateianfang
(nach Shebang/Kommentare/Modul-Docstring), entfernt Dubletten und
schreibt CRLF. Sonst bleibt alles unverändert.

Version: v9.9.52
"""
from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

FUTURE_RX = re.compile(r"^[ \t]*from[ \t]+__future__[ \t]+import[ \t]+.+$", re.MULTILINE)

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S"); print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1062] {ts} {msg}\n")
    except Exception:
        pass

def rd(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def wr_backup(p: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    b = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, b)
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {p} -> {b}")

def find_docstring_end(s: str, start: int) -> int | None:
    # erwartet start auf Anführungszeichen
    q3 = s[start:start+3]
    if q3 not in ('"""', "'''"):
        return None
    i = start + 3
    while True:
        j = s.find(q3, i)
        if j < 0:
            return None
        # nicht-escaped Ende (''' oder """ innerhalb von Strings ist okay, wir nehmen das erste nächste Vorkommen)
        return j + 3

def insertion_point(src: str) -> int:
    """
    Liefert die Position NACH: optional BOM, Shebang, Encoding-Kommentar,
    Leerzeilen/Kommentare und optionalem Modul-Docstring.
    """
    i = 0
    # BOM
    if src.startswith("\ufeff"):
        i = 1
    # Shebang
    if src.startswith("#!", i):
        eol = src.find("\n", i)
        i = len(src) if eol < 0 else eol + 1
    # Encoding-Kommentar (PEP 263)
    m = re.match(r"[ \t]*#.*coding[:=][ \t]*[-_.a-zA-Z0-9]+.*\n", src[i:])
    if m:
        i += m.end()
    # Leere Zeilen/Kommentare
    while True:
        m = re.match(r"(?:[ \t]*#.*\n|[ \t]*\n)", src[i:])
        if not m: break
        i += m.end()
    # Modul-Docstring?
    if src[i:i+3] in ('"""', "'''"):
        j = find_docstring_end(src, i)
        if j:
            i = j
            # anschließend folgende Leer-/Kommentar-Zeilen ebenfalls überspringen
            while True:
                m = re.match(r"(?:[ \t]*#.*\n|[ \t]*\n)", src[i:])
                if not m: break
                i += m.end()
    return i

def patch() -> int:
    src = rd(MOD)
    fut_lines = FUTURE_RX.findall(src)
    if not fut_lines:
        log("Keine __future__-Imports gefunden – nichts zu tun.")
        return 0

    # Entfernen aller Future-Zeilen an alten Positionen
    src_wo_fut = FUTURE_RX.sub("", src)

    # Dubletten entfernen, Reihenfolge stabil halten
    seen = set(); fut_unique = []
    for ln in fut_lines:
        k = ln.strip()
        if k not in seen:
            seen.add(k); fut_unique.append(k)

    ins_pt = insertion_point(src_wo_fut)
    new_head = src_wo_fut[:ins_pt]
    new_tail = src_wo_fut[ins_pt:]

    # Sicherstellen, dass Kopf mit Zeilenumbruch endet
    if not new_head.endswith("\n") and new_head:
        new_head += "\n"

    fut_block = "\n".join(fut_unique) + "\n\n"
    new_src = new_head + fut_block + new_tail

    if new_src != src:
        wr_backup(MOD, new_src)
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.52\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.52 (2025-10-18)
- Intake: Alle `from __future__ import ...` automatisch an den Dateianfang verschoben.
""")
        log("Future-Imports neu positioniert.")
    else:
        log("Datei war bereits korrekt – keine Änderungen.")
    return 0

if __name__ == "__main__":
    raise SystemExit(patch())
