# -*- coding: utf-8 -*-
import io, os, re, time, shutil, py_compile, traceback

ROOT   = r"D:\ShrimpDev"
TARGET = os.path.join(ROOT, "main_gui.py")
ARCH   = os.path.join(ROOT, "_Archiv")
DBG    = os.path.join(ROOT, "debug_output.txt")

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with io.open(DBG, "a", encoding="utf-8") as f:
        f.write(f"[1174v {ts}] {msg}\n")

def rd(p):  return io.open(p, "r", encoding="utf-8").read()
def wr(p,s): io.open(p, "w", encoding="utf-8", newline="").write(s)

def backup(p):
    os.makedirs(ARCH, exist_ok=True)
    b = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, b); log(f"Backup: {b}"); return b

SAFE_IMPORT_BLOCK = (
    "def _intakeframe_import():\n"
    "    # lokaler, robuster Import ohne Global-Abhaengigkeiten\n"
    "    try:\n"
    "        from modules.module_code_intake import IntakeFrame\n"
    "        return IntakeFrame\n"
    "    except Exception:\n"
    "        import importlib\n"
    "        m = importlib.import_module('modules.module_code_intake')\n"
    "        return getattr(m, 'IntakeFrame')\n"
)

SAFE_ADD_BLOCK = (
    "def _safe_add_intake_tab(nb):\n"
    "    \"\"\"Direkter Mount von IntakeFrame; sicherer Fallback bei Fehlern.\n"
    "    Idempotent, ohne _Log, ohne globale ttk-Imports.\n"
    "    \"\"\"\n"
    "    try:\n"
    "        IntakeFrame = _intakeframe_import()\n"
    "        tab = IntakeFrame(nb)\n"
    "        nb.add(tab, text='Code Intake')\n"
    "        return\n"
    "    except Exception as e:\n"
    "        try:\n"
    "            import io, time\n"
    "            with io.open(r'D:\\ShrimpDev\\debug_output.txt','a',encoding='utf-8') as _f:\n"
    "                _f.write(f\"[1174v {time.strftime('%Y-%m-%d %H:%M:%S')}] Direct mount failed: {e!r}\\n\")\n"
    "        except Exception:\n"
    "            pass\n"
    "    import tkinter.ttk as ttk\n"
    "    tab = ttk.Frame(nb)\n"
    "    nb.add(tab, text='Code Intake')\n"
    "    body = ttk.Frame(tab)\n"
    "    body.pack(fill='both', expand=True)\n"
    "    try:\n"
    "        if '_mount_intake_tab_safe' in globals():\n"
    "            tab.after(120, lambda: _mount_intake_tab_safe(body))\n"
    "        else:\n"
    "            lbl = ttk.Label(body, text='Intake konnte nicht direkt geladen werden. Bitte Erkennen/Update ausfuehren.', foreground='red')\n"
    "            lbl.pack(padx=12, pady=12, anchor='w')\n"
    "    except Exception:\n"
    "        pass\n"
)

def insert_after_imports(src, block, marker_name):
    if marker_name in src:
        return src, False
    m = re.search(r"(?s)\A((?:from\s+\S+\s+import\s+.*\n|import\s+\S+(?:\s+as\s+\S+)?\n)+)", src)
    if m:
        pos = m.end()
        src = src[:pos] + "\n" + block + "\n" + src[pos:]
    else:
        src = block + "\n" + src
    return src, True

def upsert_safe_add(src):
    pat = re.compile(r"(?s)\ndef\s+_safe_add_intake_tab\s*\(\s*nb\s*\)\s*:\s*.*?(?=\n\s*def\s+|\Z)")
    if pat.search(src):
        src = pat.sub("\n"+SAFE_ADD_BLOCK+"\n", src, count=1)
        return src, True, "replaced"
    # vor __main__ einfügen, falls vorhanden, sonst ans Ende
    m = re.search(r"\nif\s+__name__\s*==\s*['\"]__main__['\"]\s*:\s*\n", src)
    pos = m.start() if m else len(src)
    src = src[:pos] + "\n"+SAFE_ADD_BLOCK+"\n" + src[pos:]
    return src, True, "added"

def compile_ok(path):
    try:
        py_compile.compile(path, doraise=True)
        return True
    except Exception as e:
        log("Syntax-Fehler:\n"+ "".join(traceback.format_exception(e)) )
        return False

def main():
    if not os.path.isfile(TARGET):
        print("[1174v] main_gui.py fehlt"); return 2
    bak = backup(TARGET)
    src = rd(TARGET); changed=False

    # 1) Import-Helper
    src, c1 = insert_after_imports(src, SAFE_IMPORT_BLOCK, "_intakeframe_import")
    changed |= c1
    if c1: log("Import-Helper eingefuegt.")

    # 2) _safe_add_intake_tab absichern
    src, c2, how = upsert_safe_add(src)
    changed |= c2
    if c2: log(f"_safe_add_intake_tab {how}.")

    if not changed:
        log("Keine Aenderung noetig."); return 0

    wr(TARGET, src)
    if not compile_ok(TARGET):
        # rollback
        shutil.copy2(bak, TARGET)
        log("Rollback auf Backup wegen Syntaxfehler.")
        return 1

    log("Patch uebernommen, Syntax OK.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
