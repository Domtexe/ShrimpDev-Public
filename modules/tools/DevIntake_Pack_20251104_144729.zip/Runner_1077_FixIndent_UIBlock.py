## -*- coding: utf-8 -*-
"""
Runner_1077_FixIndent_UIBlock
- Tabs -> 4 Spaces
- Ersetzt den wackeligen Bereich um R1076-UI-Bindings durch gültigen try/except
"""
from __future__ import annotations
import os, re, time, shutil, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")

CLEAN_BLOCK = r'''
# === R1076 END ===
try:
    # Events für Buttons
    try:
        self.btn_detect.bind("<ButtonRelease-1>", lambda e: self._on_click_detect())
    except Exception:
        pass
    try:
        self.btn_save.bind("<ButtonRelease-1>", lambda e: self._on_click_save())
    except Exception:
        pass
    try:
        self.btn_del.bind("<ButtonRelease-1>", lambda e: self._on_click_delete())
    except Exception:
        pass
    try:
        if hasattr(self, "btn_run"):
            self.btn_run.bind("<ButtonRelease-1>", lambda e: self._on_click_run())
    except Exception:
        pass
except Exception:
    pass
'''.strip("\n")

def rd(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def wr(p: str, s: str):
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(s)

def backup(p: str):
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bak)
    print(f"Backup: {p} -> {bak}")

def main() -> int:
    if not os.path.exists(MOD):
        print(f"FEHLT: {MOD}")
        return 2
    s = rd(MOD)

    # 1) Tabs -> 4 Spaces
    s = s.replace("\t", "    ")

    # 2) Bereich rund um R1076-Ende identifizieren und ersetzen
    #    Wir ersetzen von der Zeile mit "# === R1076 END ===" bis inklusive der
    #    nächsten 25 Zeilen, wenn dort Bindings/btn_detect/save/del vorkommen.
    pattern = r"(#\s*===\s*R1076 END\s*===)(?:.*\n){0,30}?"
    # Wir hängen danach den sauberen CLEAN_BLOCK an
    m = re.search(pattern, s)
    if m:
        start = m.start(1)
        # schneide ab ab start, bis zum Ende des gefundenen Fensters
        # und setze CLEAN_BLOCK an diese Stelle
        head = s[:start]
        tail_start = m.end(0)
        tail = s[tail_start:]
        s = head + CLEAN_BLOCK + "\n" + tail
    else:
        # Falls Marker fehlt: nichts kaputt machen
        pass

    backup(MOD)
    wr(MOD, s)
    print("UI-Block bereinigt (Indent + Bindings).")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
