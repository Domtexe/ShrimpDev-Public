# -*- coding: utf-8 -*-
"""
Runner_1146_FeatureGapAudit
Vergleicht vorhandene Intake-Features mit dem geplanten Umfang.
- Keine Änderungen, nur Diagnose.
- Prüft:
  * Buttons/Controls vorhanden & gebunden (Detect/Save/Delete/Guard/Repair/Run)
  * Editor-Bindings (Paste/Modified/F5)
  * Context-Menüs (Editor & Tabelle)
  * Tabellenspalten (name/ext/subfolder/date/time)
  * Erkennung von Code: Name/Endung aus Snippets (py/bat/json/yml)
  * Unterscheidung .py vs .bat (heuristisch)
  * Hinweise auf "Pack"-Funktionen (Buttons/Methoden/Strings)

Ergebnis: _Reports/Runner_1146_FeatureGapAudit_report.txt
RC=0: keine harten Lücken (nur Hinweise)
RC=1: fehlende Kern-Features
"""
from __future__ import annotations
import io, os, sys, time, importlib.util, types, re, traceback
from pathlib import Path
import ast

ROOT    = Path(__file__).resolve().parents[1]
MODPATH = ROOT / "modules" / "module_code_intake.py"
REPORTS = ROOT / "_Reports"; REPORTS.mkdir(exist_ok=True)
REPORT  = REPORTS / "Runner_1146_FeatureGapAudit_report.txt"

def w(line=""):
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(line.rstrip() + "\n")
    print(line)

def head(t):
    w("\n" + "="*78)
    w(t)
    w("="*78)

def load_src() -> str:
    return io.open(MODPATH, "r", encoding="utf-8", errors="ignore").read()

def import_module():
    sys.path.insert(0, str(ROOT))
    # minimaler Shim, falls module_runner_exec fehlt
    try:
        import modules.module_runner_exec  # type: ignore
    except Exception:
        shim_pkg = types.ModuleType("modules")
        shim_mod = types.ModuleType("modules.module_runner_exec")
        shim_mod.run = lambda *a, **k: 0
        shim_mod._log = lambda msg: None
        sys.modules.setdefault("modules", shim_pkg)
        sys.modules["modules.module_runner_exec"] = shim_mod

    spec = importlib.util.spec_from_file_location("module_code_intake", str(MODPATH))
    if not spec or not spec.loader:
        raise RuntimeError("Spec konnte nicht erstellt werden.")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore[attr-defined]
    return mod

def live_probe(mod):
    import tkinter as tk
    issues = []
    hints  = []

    root = tk.Tk(); root.withdraw()
    try:
        fr = mod.IntakeFrame(root)
    except Exception as e:
        issues.append(f"Instanziierung IntakeFrame fehlgeschlagen: {e}")
        root.destroy(); return issues, hints, None

    # --- Buttons
    want_buttons = [
        ("btn_detect", "Detect/Erkennen"),
        ("btn_save",   "Save/Speichern"),
        ("btn_del",    "Delete/Löschen"),
        ("btn_guard",  "Guard/Prüfen"),
        ("btn_repair", "Repair"),
        ("btn_run",    "Run/F5"),
    ]
    for attr, label in want_buttons:
        if not hasattr(fr, attr):
            issues.append(f"Button fehlt: {attr} ({label})")

    # --- Editor-Bindings
    try:
        txt = fr.txt
        for ev in ("<<Paste>>", "<Control-v>", "<<Modified>>", "<KeyRelease>", "<F5>"):
            if not (txt.bind(ev) or ""):
                issues.append(f"Binding fehlt am Editor: {ev}")
    except Exception:
        issues.append("Text-Widget fehlt (Bindings nicht prüfbar).")

    # --- Context-Menüs
    if not hasattr(fr, "menu_editor"):
        hints.append("Editor-Contextmenü fehlt.")
    if not hasattr(fr, "menu_tbl"):
        hints.append("Tabellen-Contextmenü fehlt.")

    # --- Tabelle/Spalten
    try:
        tbl = fr.tbl
        cols = tuple(tbl["columns"])
        for need in ("name", "ext", "subfolder", "date", "time"):
            if need not in cols:
                issues.append(f"Tabellenspalte fehlt: {need}")
    except Exception:
        issues.append("Tabelle nicht verfügbar.")

    return issues, hints, fr

def simulate_detection(fr, text: str):
    # Editor füllen + detect() anstoßen
    try:
        fr.txt.delete("1.0", "end")
        fr.txt.insert("1.0", text)
        fr.var_name_manual = False
        fr.var_ext_manual  = False
        ok = fr._detect()
        name = fr.var_name.get()
        ext  = fr.var_ext.get()
        return ok, name, ext
    except Exception as e:
        return False, f"ERR({e})", ""

def main() -> int:
    # Report reset
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass

    head("[R1146] FeatureGapAudit – Start")
    if not MODPATH.exists():
        w(f"[FEHLER] Datei fehlt: {MODPATH}")
        return 1

    # AST – Hinweise zu Pack/Plan-Strings
    head("1) Statische Sicht / Strings")
    src = load_src()
    pack_mentions = re.findall(r"(?i)pack|bundle|zip|archive", src)
    if pack_mentions:
        w(f"[Info] Hinweise auf Pack/Bundling im Code: {len(pack_mentions)} Stelle(n).")
    else:
        w("[Info] Keine Hinweise auf 'Pack'-Funktionen im Code gefunden.")

    # Import + Live
    head("2) Live-UI/Bindings")
    try:
        mod = import_module()
    except Exception as e:
        w("[Import] Fehler: " + str(e))
        return 1

    issues, hints, fr = live_probe(mod)
    for s in issues: w("[Issue] " + s)
    for s in hints:  w("[Hint ] " + s)
    if not fr:
        head("4) Zusammenfassung")
        w("[SUM] Live-Probe fehlgeschlagen – harte Lücke.")
        return 1

    # Detection-Tests
    head("3) Erkennungs-Tests (py/bat/json/yml)")
    samples = [
        ("PY basic",           "import os\nprint('hi')\n", ".py"),
        ("PY runner call",     "py -3 tools\\Runner_9999_Test.py\n", ".py"),
        ("BAT basic",          "@echo off\nrem test\n", ".bat"),
        ("BAT runner call",    "call tools\\Runner_8888_Task.bat\n", ".bat"),
        ("JSON",               "{ \"k\": 1 }\n", ".json"),
        ("YML",                "name: x\nsteps:\n  - run\n", ".yml"),
    ]
    det_fails = 0
    for title, text, want_ext in samples:
        ok, name, ext = simulate_detection(fr, text)
        w(f"[Detect] {title:16s} -> ok={ok}  name='{name}' ext='{ext}'  (want {want_ext})")
        # Bewertung: ext soll want_ext enthalten (bei .yml akzeptieren wir .yml oder .yaml)
        if want_ext == ".yml":
            target_ok = ext in (".yml", ".yaml")
        else:
            target_ok = (ext == want_ext)
        if not target_ok:
            det_fails += 1

    # Pack/Bundle-Button vorhanden?
    want_pack_buttons = ("btn_pack", "btn_save_pack", "btn_bundle", "btn_zip")
    pack_btn_found = any(hasattr(fr, b) for b in want_pack_buttons)
    if not pack_btn_found:
        w("[Gap] Kein Button für 'Pack speichern/Bundle' gefunden.")
    else:
        w("[OK ] Pack/Bundle-Button vorhanden.")

    # Ergebnis
    head("4) Zusammenfassung")
    rc = 0
    if issues:
        w("[SUM] Harte Lücken: " + "; ".join(issues)); rc = 1
    if det_fails:
        w(f"[SUM] Erkennung: {det_fails}/ {len(samples)} Tests weichen ab."); rc = 1
    if not pack_btn_found:
        w("[SUM] 'Pack speichern' fehlt (UI/Hook)."); rc = 1

    if rc == 0:
        w("[OK] Intake deckt die geprüften Features ab. (Details siehe oben)")
    else:
        w("[NEXT] Ich kann gezielte Fix-/Erweiterungs-Runner liefern (modular):")
        w("       – R1147_AddPackSaveButton (UI + Hook, ohne Seiteneffekte)")
        w("       – R1148_ImproveDetection (py/bat/json/yml-Heuristiken)")
        w("       – R1149_AddTablePopulate (Auto-Scan & Anzeige vorhandener Runner)")

    return rc

if __name__ == "__main__":
    sys.exit(main())
