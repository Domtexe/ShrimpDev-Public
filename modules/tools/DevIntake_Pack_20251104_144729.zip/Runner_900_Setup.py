from __future__ import annotations
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
TOOLS = ROOT/"tools"
MODS  = ROOT/"modules"
SNIP  = MODS/"snippets"
REPORT = ROOT/"_Reports"/"Agent"

def w(p: Path, s: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(s, encoding="utf-8")
    print(f"[R900] Wrote {p.relative_to(ROOT)}")

def main():
    # --- quiet starter ---
    vbs = r'''Dim sh, cmd
Set sh = CreateObject("WScript.Shell")
cmd = "cmd /c py -3 -u main_gui.py >> debug_output.txt 2^>^&1"
sh.Run cmd, 0, False
'''
    bat = r'''@echo off
cd /d "D:\ShrimpDev"
cscript //nologo tools\start_quiet.vbs
'''
    w(TOOLS/"start_quiet.vbs", vbs)
    w(TOOLS/"start_quiet.bat", bat)

    # --- optional build ---
    build = r'''@echo off
cd /d "D:\ShrimpDev"
where pyinstaller >nul 2>nul || (echo [BUILD] Installiere pyinstaller... & py -3 -m pip install --upgrade pyinstaller)
py -3 -m PyInstaller --noconsole --onefile --name ShrimpDev main_gui.py
echo [BUILD] Fertig: dist\ShrimpDev.exe
'''
    w(TOOLS/"build_exe.bat", build)

    # --- modules/config_mgr.py ---
    cfg = r'''from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict

ROOT = Path(r"D:\ShrimpDev")
CFG  = ROOT / "config.json"
DEFAULTS: Dict[str, Any] = {"workspace_root": r"D:\ShrimpHub"}

def _log(msg: str) -> None:
    try:
        (ROOT/"debug_output.txt").open("a", encoding="utf-8", errors="ignore").write(f"[CONFIG] {msg}\n")
    except Exception:
        pass

def load_config() -> Dict[str, Any]:
    if not CFG.exists():
        save_config(DEFAULTS)
        return DEFAULTS.copy()
    try:
        data = json.loads(CFG.read_text(encoding="utf-8", errors="ignore") or "{}")
        merged = DEFAULTS.copy(); merged.update(data or {})
        return merged
    except Exception as ex:
        _log(f"Error loading config: {ex}")
        return DEFAULTS.copy()

def save_config(conf: Dict[str, Any]) -> None:
    try:
        CFG.write_text(json.dumps(conf, ensure_ascii=False, indent=2), encoding="utf-8")
        _log("Config saved")
    except Exception as ex:
        _log(f"Error saving config: {ex}")
'''
    w(MODS/"config_mgr.py", cfg)

    # --- modules/module_agent.py ---
    agent = r'''from __future__ import annotations
import json, socket, select, threading, time
from pathlib import Path
from typing import Optional, Dict, Any

ROOT = Path(r"D:\ShrimpDev")
OUT_DIR = ROOT / "_Reports" / "Agent"
INBOX   = OUT_DIR / "inbox"
EVENTS  = OUT_DIR / "events.jsonl"
STATUS  = OUT_DIR / "agent_status.html"
ADDR    = ("127.0.0.1", 9477)

def _log(s: str) -> None:
    try: (ROOT/"debug_output.txt").open("a", encoding="utf-8", errors="ignore").write(f"[AGENT] {s}\n")
    except Exception: pass

def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

def _ensure() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True); INBOX.mkdir(parents=True, exist_ok=True)

def _rotate() -> None:
    try:
        if EVENTS.exists() and EVENTS.stat().st_size > 2_000_000:
            EVENTS.rename(EVENTS.with_name(f"events_{int(time.time())}.jsonl"))
    except Exception: pass

def _append(ev: Dict[str, Any]) -> None:
    _rotate()
    ev.setdefault("ts", _now())
    try: EVENTS.open("a", encoding="utf-8").write(json.dumps(ev, ensure_ascii=False) + "\n")
    except Exception: pass

def _render() -> None:
    try:
        if not EVENTS.exists(): return
        lines = EVENTS.read_text(encoding="utf-8", errors="ignore").splitlines()[-200:]
        rows = []
        import html as _h
        for ln in lines:
            try: e = json.loads(ln)
            except Exception: e = {"ts":"", "runner":"?", "level":"INFO", "msg": ln}
            rows.append(f"<tr><td>{_h.escape(str(e.get('ts','')))}</td><td>{_h.escape(str(e.get('runner','')))}</td><td>{_h.escape(str(e.get('level','')))}</td><td>{_h.escape(str(e.get('msg','')))}</td></tr>")
        STATUS.write_text(
            "<meta charset='utf-8'><style>table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:4px 6px;font:12px Segoe UI}</style>"
            "<h3>ShrimpDev Agent</h3><table><tr><th>ts</th><th>runner</th><th>level</th><th>msg</th></tr>"
            + "\n".join(rows) + "</table>", encoding="utf-8")
    except Exception: pass

class AgentService:
    def __init__(self) -> None:
        self._thr: Optional[threading.Thread] = None
        self._stop = threading.Event()

    def start(self) -> None:
        if self._thr and self._thr.is_alive(): return
        self._stop.clear()
        self._thr = threading.Thread(target=self._run, name="ShrimpDevAgent", daemon=True)
        self._thr.start()
        _log("Agent started")

    def stop(self) -> None:
        self._stop.set()
        _log("Agent stop requested")

    def _run(self) -> None:
        _ensure()
        t = threading.Thread(target=self._inbox_loop, daemon=True); t.start()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); sock.setblocking(False)
        try: sock.bind(ADDR)
        except Exception: sock = None
        while not self._stop.is_set():
            try:
                if sock:
                    r,_,_ = select.select([sock],[],[],0.3)
                    if r:
                        data,_ = sock.recvfrom(65535)
                        try: ev = json.loads(data.decode("utf-8", errors="ignore"))
                        except Exception: ev = {"runner":"UDP","level":"INFO","msg":data.decode("utf-8","ignore")}
                        _append(ev); _render()
                else:
                    time.sleep(0.3)
            except Exception:
                time.sleep(0.2)

    def _inbox_loop(self) -> None:
        while not self._stop.is_set():
            try:
                for p in list(INBOX.glob("*.jsonl")):
                    for ln in p.read_text(encoding="utf-8", errors="ignore").splitlines():
                        if not ln.strip(): continue
                        try: ev = json.loads(ln)
                        except Exception: ev = {"runner":"INBOX","level":"INFO","msg":ln}
                        _append(ev)
                    p.unlink(missing_ok=True)
                _render(); time.sleep(0.5)
            except Exception:
                time.sleep(0.5)

AGENT = AgentService()
'''
    w(MODS/"module_agent.py", agent)

    # --- modules/module_agent_ui.py ---
    agent_ui = r'''from __future__ import annotations
import json, tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
EVENTS = ROOT / "_Reports" / "Agent" / "events.jsonl"

def _log(s: str) -> None:
    try: (ROOT/"debug_output.txt").open("a", encoding="utf-8", errors="ignore").write(f"[AGENT_UI] {s}\n")
    except Exception: pass

def _tail(n: int = 300):
    out=[]
    try:
        if not EVENTS.exists(): return out
        lines = EVENTS.read_text(encoding="utf-8", errors="ignore").splitlines()[-n:]
        for ln in lines:
            try: out.append(json.loads(ln))
            except Exception: out.append({"ts":"", "runner":"?", "level":"INFO", "msg": ln})
    except Exception as ex:
        _log(f"tail error: {ex}")
    return out

class AgentWindow(tk.Toplevel):
    def __init__(self, app: tk.Tk):
        super().__init__(app)
        self.title("🦐 Agent Monitor")
        self.geometry("980x540+140+140")
        self.resizable(True, True)
        bar = ttk.Frame(self); bar.pack(fill="x", pady=6)
        ttk.Label(bar, text="Level:").pack(side="left")
        self.var_level = tk.StringVar(value="ALL")
        ttk.Combobox(bar, textvariable=self.var_level, values=["ALL","OK","INFO","WARN","ERROR","FAIL"], width=8, state="readonly").pack(side="left", padx=6)
        ttk.Button(bar, text="Refresh", command=self.refresh).pack(side="left")
        self.var_auto = tk.BooleanVar(value=True)
        ttk.Checkbutton(bar, text="Auto (2s)", variable=self.var_auto).pack(side="right")
        cols=("ts","runner","level","msg"); self.tree=ttk.Treeview(self, columns=cols, show="headings")
        for c,w in zip(cols,(160,180,90,520)): self.tree.heading(c, text=c); self.tree.column(c, width=w, anchor="w")
        self.tree.pack(fill="both", expand=True)
        self.after_id=None; self.refresh()

    def _f(self, rows):
        lv = self.var_level.get().upper()
        if lv=="ALL": return rows
        return [r for r in rows if str(r.get("level","")).upper()==lv]

    def refresh(self):
        try:
            if self.after_id: self.after_cancel(self.after_id)
        except Exception: pass
        rows = self._f(_tail())
        for i in self.tree.get_children(): self.tree.delete(i)
        for r in rows: self.tree.insert("", "end", values=(r.get("ts",""), r.get("runner",""), r.get("level",""), r.get("msg","")))
        if self.var_auto.get(): self.after_id = self.after(2000, self.refresh)

def open_agent_monitor(app: tk.Tk) -> bool:
    try: AgentWindow(app); return True
    except Exception as ex:
        _log(f"open error: {ex}")
        try: messagebox.showerror("ShrimpDev", f"Agent Monitor Fehler:\n{ex}")
        except Exception: pass
        return False
'''
    w(MODS/"module_agent_ui.py", agent_ui)

    # --- modules/snippets/agent_client.py ---
    client = r'''from __future__ import annotations
import json, os, socket, time
from pathlib import Path

ADDR = ("127.0.0.1", 9477)
ROOT = Path(r"D:\ShrimpDev")
INBOX = ROOT / "_Reports" / "Agent" / "inbox"

def send_event(ev: dict) -> None:
    ev = dict(ev or {}); ev.setdefault("ts", time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
    data = json.dumps(ev, ensure_ascii=False).encode("utf-8")
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.sendto(data, ADDR); s.close()
    except Exception:
        try:
            INBOX.mkdir(parents=True, exist_ok=True)
            (INBOX / f"{int(time.time())}_{os.getpid()}.jsonl").open("a", encoding="utf-8").write(json.dumps(ev, ensure_ascii=False)+"\n")
        except Exception:
            pass
'''
    w(SNIP/"agent_client.py", client)

    # --- modules/module_code_intake.py ---
    intake = r'''from __future__ import annotations
import re
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from modules.config_mgr import load_config, save_config
from modules.snippets.agent_client import send_event

ROOT = Path(r"D:\ShrimpDev")

def _log(s: str) -> None:
    try: (ROOT/"debug_output.txt").open("a", encoding="utf-8", errors="ignore").write(f"[INTAKE] {s}\n")
    except Exception: pass

def _extract(code: str):
    head = code[:2000]
    pats = [
        r"(?im)^\s*#\s*(?P<p>[\w\-/\\\. ]+\.(py|bat|vbs|cmd|ps1|md|json|txt))\s*$",
        r"(?im)^\s*//\s*(?P<p>[\w\-/\\\. ]+\.(py|bat|vbs|cmd|ps1|md|json|txt))\s*$",
        r"(?im)^\s*;\s*(?P<p>[\w\-/\\\. ]+\.(py|bat|vbs|cmd|ps1|md|json|txt))\s*$",
        r"(?im)^\s*[-#/* ]*file(name)?\s*:\s*(?P<p>[\w\-/\\\. ]+\.(py|bat|vbs|cmd|ps1|md|json|txt))\s*$",
        r"(?ism)^\s*[`\"']{3}[^`\"']{0,200}?(?P<p>[\w\-/\\\. ]+\.(py|bat|vbs|cmd|ps1|md|json|txt))[^`\"']{0,200}?[`\"']{3}",
        r"(?im)^\s*###\s*(?P<p>[\w\-/\\\. ]+\.(py|bat|vbs|cmd|ps1|md|json|txt))\s*$",
        r"(?i)\b(Runner_\d{3,}\.(py|bat|cmd|vbs))\b",
        r"(?i)\b(module_[\w\-]+\.py)\b"
    ]
    for pat in pats:
        m = re.search(pat, head)
        if m:
            p = m.group("p") if "p" in m.groupdict() else m.group(0)
            name = Path(p).name
            ext  = Path(name).suffix.lower()
            return name, ext
    return None, None

def _map_target(workspace: Path, name: str, ext: str) -> Path:
    n = name.lower()
    if ext==".py" and n.startswith("runner_"):   return workspace/"tools"
    if ext in {".bat",".cmd",".vbs",".ps1"}:     return workspace/"tools"
    if ext==".py" and n.startswith("module_"):   return workspace/"modules"
    if ext==".py":                               return workspace/"modules"/"snippets"
    if ext in {".md",".json",".txt"}:            return workspace
    return workspace

class IntakeWindow(tk.Toplevel):
    def __init__(self, app: tk.Tk):
        super().__init__(app)
        self.title("🦐 ShrimpDev – Code Intake")
        self.geometry("960x680+120+120")
        self.resizable(True, True)

        self.conf = load_config()
        self.workspace = Path(self.conf.get("workspace_root", r"D:\ShrimpHub")).resolve()

        top = ttk.Frame(self); top.pack(fill="x", pady=6)
        self.var_ws = tk.StringVar(value=str(self.workspace))
        ttk.Label(top, text="Workspace:").pack(side="left")
        ttk.Entry(top, textvariable=self.var_ws, width=60).pack(side="left", padx=6)
        ttk.Button(top, text="…", command=self._pick_ws).pack(side="left")

        bar = ttk.Frame(self); bar.pack(fill="x", pady=4)
        self.var_name = tk.StringVar(); self.var_ext = tk.StringVar(); self.var_target = tk.StringVar()
        for lbl, var, w in (("Dateiname:", self.var_name, 40), ("Endung:", self.var_ext, 8), ("Zielordner:", self.var_target, 50)):
            ttk.Label(bar, text=lbl).pack(side="left"); ttk.Entry(bar, textvariable=var, width=w).pack(side="left", padx=6)

        self.txt = tk.Text(self, wrap="none", undo=True); self.txt.pack(fill="both", expand=True)
        self.txt.bind("<<Modified>>", self._on_modified)

        b = ttk.Frame(self); b.pack(fill="x", pady=6)
        ttk.Button(b, text="Erkennen (Ctrl+I)", command=self._detect).pack(side="left")
        ttk.Button(b, text="Speichern (Ctrl+S)", command=self._save).pack(side="right")

        self.status = tk.StringVar(value="Bereit."); ttk.Label(self, textvariable=self.status, anchor="w").pack(fill="x")

        self.bind_all("<Control-i>", lambda e: self._detect())
        self.bind_all("<Control-s>", lambda e: self._save())

    def _pick_ws(self):
        try:
            d = filedialog.askdirectory(title="Workspace wählen", initialdir=str(self.workspace))
            if d:
                self.workspace = Path(d).resolve()
                self.var_ws.set(str(self.workspace))
                self.conf["workspace_root"] = str(self.workspace)
                save_config(self.conf)
        except Exception: pass

    def _on_modified(self, _=None):
        try:
            self.txt.edit_modified(0)
            if not self.var_name.get() or not self.var_ext.get(): self._detect(auto=True)
        except Exception: pass

    def _detect(self, auto: bool=False):
        code = self.txt.get("1.0", "end-1c")
        name, ext = _extract(code)
        if name: self.var_name.set(name)
        if ext:  self.var_ext.set(ext)
        nm, ex = self.var_name.get().strip(), self.var_ext.get().strip().lower()
        if nm and ex: self.var_target.set(str(_map_target(self.workspace, nm, ex)))
        if not auto: self.status.set(f"Erkannt: name={nm!r}, ext={ex!r}, target={self.var_target.get()!r}")

    def _save(self):
        nm, ex, target = self.var_name.get().strip(), self.var_ext.get().strip().lower(), self.var_target.get().strip()
        code = self.txt.get("1.0", "end-1c")
        if not nm or not ex or not target:
            messagebox.showwarning("ShrimpDev", "Bitte Name/Endung/Target prüfen."); return
        if not nm.lower().endswith(ex): nm = Path(nm).stem + ex; self.var_name.set(nm)
        out_dir = Path(target).resolve(); out_dir.mkdir(parents=True, exist_ok=True)
        out = (out_dir / nm).resolve()
        try:
            if out.exists():
                # Mini-Rotation: .bak1..bak4
                for i in range(4, 0, -1):
                    pi = out.with_suffix(out.suffix + f".bak{i}")
                    pj = out.with_suffix(out.suffix + f".bak{i+1}")
                    if pi.exists(): pi.replace(pj)
                bak1 = out.with_suffix(out.suffix + ".bak1")
                try: out.with_suffix(out.suffix + ".bak").replace(bak1)
                except Exception: pass
            out.write_text(code, encoding="utf-8")
            _log(f"Saved {out}")
            send_event({"runner":"CodeIntake","level":"OK","msg": f"Saved {out.name}","path": str(out)})
            messagebox.showinfo("ShrimpDev", f"Gespeichert:\n{out}")
            self.status.set(f"Gespeichert: {out}")
        except Exception as ex:
            _log(f"Save error {out}: {ex}")
            try: messagebox.showerror("ShrimpDev", f"Fehler beim Speichern:\n{ex}")
            except Exception: pass

def open_intake(app: tk.Tk) -> bool:
    try: IntakeWindow(app); return True
    except Exception as ex:
        _log(f"open error: {ex}")
        try: messagebox.showerror("ShrimpDev", f"Intake Fehler:\n{ex}")
        except Exception: pass
        return False
'''
    w(MODS/"module_code_intake.py", intake)

    # --- main_gui.py ---
    main_py = r'''from __future__ import annotations
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from modules import module_agent as agent
from modules import module_agent_ui as agent_ui
from modules import module_code_intake as intake

ROOT = Path(r"D:\ShrimpDev")

def log(msg: str) -> None:
    try: (ROOT/"debug_output.txt").open("a", encoding="utf-8", errors="ignore").write(f"[MAIN] {msg}\n")
    except Exception: pass

class ShrimpDevApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("🦐 ShrimpDev")
        self.geometry("1100x720+80+60")
        self.nb = ttk.Notebook(self); self.nb.pack(fill="both", expand=True)
        self.status = tk.StringVar(value="Bereit.")
        ttk.Label(self, textvariable=self.status, anchor="w").pack(fill="x")
        self._mk_menu()
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="Info")
        ttk.Label(tab, text="ShrimpDev – Standalone Dev-Umgebung für ShrimpHub", font=("Segoe UI", 12)).pack(pady=12)
        agent.AGENT.start()

    def _mk_menu(self):
        menubar = tk.Menu(self); self.config(menu=menubar)
        m_file = tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="File", menu=m_file)
        m_tools= tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="Tools", menu=m_tools)
        m_view = tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="View",  menu=m_view)
        m_file.add_command(label="Exit", command=self._on_exit)
        m_tools.add_command(label="Code Intake (Ctrl+I)", command=lambda: intake.open_intake(self))
        self.bind_all("<Control-i>", lambda e: intake.open_intake(self))
        m_view.add_command(label="Agent Monitor (Ctrl+M)", command=lambda: agent_ui.open_agent_monitor(self))
        self.bind_all("<Control-m>", lambda e: agent_ui.open_agent_monitor(self))

    def _on_exit(self):
        try: agent.AGENT.stop()
        except Exception: pass
        self.after(150, self.destroy)

if __name__ == "__main__":
    try:
        app = ShrimpDevApp()
        app.mainloop()
    except Exception as ex:
        log(f"FATAL: {ex}")
        try: messagebox.showerror("ShrimpDev", f"Fataler Fehler:\n{ex}")
        except Exception: pass
'''
    w(ROOT/"main_gui.py", main_py)

    # prepare log
    (ROOT/"debug_output.txt").write_text("", encoding="utf-8")
    print("[R900] DONE. Start: tools\\start_quiet.bat")

if __name__ == "__main__":
    main()
