# -*- coding: utf-8 -*-
"""
R1177n_GatePanelUpdate
- Aktualisiert module_gate_panel.py:
  * do_reload_intake(): nutzt nur noch mount_intake_tab(nb)
  * entfernt veraltete _remount/_mount-Shim-Calls
Backups -> _Archiv/, Log -> debug_output.txt
"""
from __future__ import annotations
import os, re, shutil, datetime

ROOT   = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
ARCH   = os.path.join(ROOT, "_Archiv")
LOGF   = os.path.join(ROOT, "debug_output.txt")
TARGET = os.path.join(ROOT, "modules", "module_gate_panel.py")

def ts(): return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def log(msg: str):
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(f"[{ts()}] [R1177n] {msg}\n")
    except Exception:
        pass

NEW_RELOAD = r'''
    def do_reload_intake():
        try:
            from modules.module_shim_intake import mount_intake_tab
        except Exception:
            messagebox.showwarning("Reload Intake", "Shim-API nicht verfügbar (mount_intake_tab).")
            return
        try:
            mount_intake_tab(nb)
            messagebox.showinfo("Reload Intake", "Intake-Tab neu geladen.")
        except Exception as e:
            messagebox.showerror("Reload Intake", str(e))
'''

def backup(p: str):
    if not os.path.exists(p): return
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(p)}.{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.bak")
    shutil.copy2(p, bak); log(f"Backup: {bak}")

def patch_gate(src: str) -> str:
    # Ersetze die gesamte do_reload_intake-Definition
    src = re.sub(r"\n\s*def\s+do_reload_intake\s*\([\s\S]*?\n\s*ttk\.Button\(btn_row, text=\"Refresh Status\"", "\n" + NEW_RELOAD + r"\n    ttk.Button(btn_row, text=\"Refresh Status\"", src, count=1)
    # Sicherheitsersatz: entferne alte Imports, falls noch vorhanden
    src = src.replace("_remount_intake_tab_shim", "mount_intake_tab")
    src = src.replace("_mount_intake_tab_shim", "mount_intake_tab")
    return src

def main() -> int:
    if not os.path.exists(TARGET):
        print("[R1177n] module_gate_panel.py nicht gefunden."); return 2
    src = open(TARGET, "r", encoding="utf-8").read()
    orig = src
    src = patch_gate(src)
    if src != orig:
        backup(TARGET)
        with open(TARGET, "w", encoding="utf-8") as f: f.write(src)
        log("module_gate_panel.py aktualisiert (do_reload_intake -> mount_intake_tab).")
    else:
        log("module_gate_panel.py unverändert (Patch nicht notwendig).")
    print("[R1177n] GatePanelUpdate applied.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
