# -*- coding: utf-8 -*-
"""
[R1116g] FixToolbarBlock
- Ersetzt den kompletten Toolbar-Block (bar = ttk.Frame(self) ... vor body = ttk.Panedwindow)
  durch eine saubere, syntaktisch geprüfte Version inkl. Reparieren/Run/Guard/Save/Delete/Detect.
- Backup in _Archiv, danach Syntax-Check.
"""

import os, re, time, sys

TAG   = "[R1116g]"
ROOT  = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD   = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH  = os.path.join(ROOT, "_Archiv")

def rd(p):
    with open(p, "rb") as f:
        return f.read().decode("utf-8", "replace")

def wr(p, s):
    with open(p, "wb") as f:
        f.write(s.encode("utf-8"))

NEW_BLOCK = r'''
bar = ttk.Frame(self)
bar.grid(row=0, column=0, sticky="ew", padx=_PADX, pady=(0, _PADY))
bar.columnconfigure(4, weight=1)

self.btn_detect = ttk.Button(bar, text="Erkennen (Ctrl+I)",  command=self._on_click_detect)
self.btn_save   = ttk.Button(bar, text="Speichern (Ctrl+S)", command=self._on_click_save)
self.btn_guard  = ttk.Button(bar, text="Prüfen (Guard)",     command=self._on_click_guard)
self.btn_run    = ttk.Button(bar, text="Run (F5)",           command=self._on_click_run)
self.btn_del    = ttk.Button(bar, text="Löschen (Entf)",     command=self._on_click_delete)
self.btn_repair = ttk.Button(bar, text="Reparieren (Tief)",  command=self._on_click_repair_deep)

self.btn_detect.grid(row=0, column=0,   padx=(0, 6), sticky="w")
self.btn_save.grid(  row=0, column=1,   padx=(0, 6), sticky="w")
self.btn_guard.grid( row=0, column=2,   padx=(0, 6), sticky="w")
self.btn_repair.grid(row=0, column=3,   padx=(4, 0), sticky="w")
self.btn_run.grid(   row=0, column=100, padx=(6, 0))
self.btn_del.grid(   row=0, column=101, padx=(6, 0))

self.lbl_ping = ttk.Label(bar, text="", anchor="w")
self.lbl_ping.grid(row=0, column=4, sticky="ew", padx=(12, 0))
'''.strip()

# Regex, der den gesamten Toolbar-Block einfängt:
# Start:  bar = ttk.Frame(self)
# Ende:   Zeile, die mit "body = ttk.Panedwindow(" beginnt (diese bleibt erhalten)
PAT = re.compile(
    r'(bar\s*=\s*ttk\.Frame\(self\).*?)'          # begin toolbar
    r'(?=^\s*body\s*=\s*ttk\.Panedwindow\()',     # lookahead bis body=...
    re.DOTALL | re.MULTILINE
)

def main():
    if not os.path.isfile(MOD):
        print(TAG, "Zieldatei fehlt:", MOD); sys.exit(2)

    src0 = rd(MOD)

    m = PAT.search(src0)
    if not m:
        print(TAG, "Toolbar-Block nicht gefunden – Abbruch (keine Änderung).")
        sys.exit(3)

    start, end = m.span()
    src1 = src0[:start] + NEW_BLOCK + "\n\n" + src0[end:]

    # Backup
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"module_code_intake.py.{int(time.time())}.bak")
    wr(bak, src0)
    print(TAG, "Backup:", bak)

    # Schreiben
    wr(MOD, src1)

    # Syntax-Check
    try:
        compile(src1, MOD, "exec")
        print(TAG, "Toolbar ersetzt & Syntax OK.")
    except SyntaxError as e:
        # Bei Fehler wiederherstellen
        wr(MOD, src0)
        print(TAG, f"SyntaxError nach Patch in Zeile {e.lineno}: {e.msg}")
        print(TAG, "Datei wiederhergestellt.")
        sys.exit(1)

if __name__ == "__main__":
    main()
