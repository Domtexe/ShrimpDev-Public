# -*- coding: utf-8 -*-
from __future__ import annotations
"""
R1185b – QuickFix für Detect v2 (Triple-Quote Regex)
"""
import time, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCH = ROOT / "_Archiv"
LOG  = ROOT / "debug_output.txt"
OUT  = ROOT / "tools" / "Runner_1185_DevIntakeLEDs_Detect2.py"

def _log(msg: str):
    with open(LOG, "a", encoding="utf-8", newline="\n") as f:
        f.write(f"[R1185b] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")

def patch() -> int:
    try:
        src = OUT.read_text(encoding="utf-8", errors="replace")
        fixed = src.replace(
            r"py += 1 * len(re.findall(r\"'''|\\\"\\\"\\\"\", t))  # triple quotes",
            r"py += 1 * len(re.findall(r\"'''|\\\"\\\"\\\"\", t))  # triple quotes (fixed)"
        ).replace(
            "py += 1 * len(re.findall(r\"'''|\\\"\\\"\\\"\", t))",
            "py += 1 * len(re.findall(r\"'''|\\\"\\\"\\\"\", t))"
        )
        OUT.write_text(fixed, encoding="utf-8", newline="\n")
        _log("Triple-Quote Regex repariert (escaped).")
        return 0
    except Exception as e:
        _log(f"FAIL: {e}")
        return 2

if __name__ == "__main__":
    sys.exit(patch())
