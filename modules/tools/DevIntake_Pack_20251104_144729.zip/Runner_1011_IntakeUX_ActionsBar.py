# -*- coding: utf-8 -*-
"""
Runner_1157_FixDetectPatterns
- Repariert defekte Regexe und LED-Canvas in modules/module_code_intake.py
- Backup nach _Archiv/
- Syntax-Check via py_compile
- Logging nach debug_output.txt

Kanon nach Meistermodus:
- Keine Platzhalter, robuste Regex-Patches mit count=1..n (wo sinnvoll)
- Nur gezielte Änderungen, kein "weiterfrickeln"
"""
from __future__ import annotations
import os, re, time, io, shutil, traceback, py_compile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOGF = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    line  = f"[R1157] {stamp} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    ts = str(int(time.time()))
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    shutil.copy2(path, dst)
    log(f"Backup: {path} -> {dst}")
    return dst

def patch_text(src: str) -> tuple[str, list[str]]:
    changelog: list[str] = []

    # 1) Name-Regex: kaputte Artefakte „...Runner_“ + unbalancierte Gruppe
    # Ziel: (?im)^[;#:\-\s]+\s*name\s*[:=]\s*(Runner_12345_xxx)(?:\.(py|bat|cmd))?\s*$
    pat_name = re.compile(
        r"""re\.search\(\s*r(?P<q>['"])          # re.search(r"..."
            (?P<body>[^"']*?)
            Runner_\[?0-9\]\{3,5\}[^"']*?        # sehr grobe Erkennung der alten Stelle
            (?P= q)                               # selbes Quote
            \s*,\s*t\s*\|\|\s*""",               # seltene alte Schreibweise (fallback)
        re.VERBOSE
    )
    # Das obige ist zu riskant; stattdessen gezielte Ersetzung bekannt fehlerhafter Fragmente:
    # a) Entferne "..." vor Runner_
    src_new = re.sub(
        r"(?im)(name\s*[:=]\s*)\.\.\.(Runner_[0-9]{3,5}[_A-Za-z0-9\-]+)",
        r"\1\2",
        src,
        count=0,
    )
    if src_new != src:
        changelog.append("Removed '...' artifact in name line")
    src = src_new

    # b) Balancierte Gruppe um Runner_... sicherstellen – wir ersetzen bekannte fehlerhafte Pattern komplett
    src_new = re.sub(
        r"""re\.search\(\s*r(?P<q>['"])
             \(\?im\)\^\[;#:\\\-\s\]\+\\s\*name\\s\*[:=]\\s\*.*?Runner_\[0-9\]\{3,5\}.*?
             (?P=q)\s*,\s*t\s*\|\|\s*""",
        r"""re.search(r"(?im)^[;#:\-\s]+\s*name\s*[:=]\s*(Runner_[0-9]{3,5}[_A-Za-z0-9\-]+)(?:\.(py|bat|cmd))?\s*$", t or "") or """"",
        src,
        flags=re.VERBOSE
    )
    if src_new != src:
        changelog.append("Rewrote name detection regex")
    src = src_new

    # 2) Python-Heuristik: ersetze defektes 'impo...name__'
    src_new = re.sub(
        r"""re\.search\(\s*r(?P<q>['"])
             \(?\?m\)?\\s*\*\(from\\s\+\\w\+\\s\+import\|impo\.\.\.name__\\s\*==\\s\*.\_main__.\)
             (?P=q)\s*,\s*["\s\+]*head""",
        r"""re.search(r"(?m)^\s*(from\s+\w+\s+import|import\s+\w+|if\s+__name__\s*==\s*['\"]__main__['\"])", " " + (head or ""))""",
        src,
        flags=re.VERBOSE
    )
    if src_new != src:
        changelog.append("Rewrote python heuristic regex")
    src = src_new

    # 3) INI-Header: [^[\-]] -> [^\]]
    src_new = re.sub(
        r"(?m)\[\^\-]\]",  # konservativ: korrumpierte Klasse
        r"[^\]]]",
        src
    )
    if src_new != src:
        changelog.append("Fixed INI header character class")
    src = src_new

    # 4) LED-Canvas: width/height reparieren auf kleine, aber sichtbare LEDs
    # Korrigiere Zeilen, in denen Canvas mit width=1..5 vorkommt oder defekte Fragmente enthalten sind
    def fix_canvas_line(m: re.Match) -> str:
        line = m.group(0)
        # Normiere Parameter
        # ensure width
        line = re.sub(r"width\s*=\s*\d+", "width=14", line)
        if "width=" not in line:
            line = line.replace("tk.Canvas(", "tk.Canvas(" + "width=14, ")
        # ensure height
        if "height=" in line:
            line = re.sub(r"height\s*=\s*\d+", "height=14", line)
        else:
            line = line.replace("width=14", "width=14, height=14")
        # ensure highlightthickness
        if "highlightthickness" in line:
            line = re.sub(r"highlightthickness\s*=\s*\d+", "highlightthickness=0", line)
        else:
            # füge als letztes Argument ein
            line = line.rstrip().rstrip(")")
            line += ", highlightthickness=0)"
        return line

    src_new = re.sub(
        r"^(\s*self\.\w+\s*=\s*tk\.Canvas\([^\n]*\))",
        fix_canvas_line,
        src,
        flags=re.MULTILINE
    )
    if src_new != src:
        changelog.append("Normalized LED Canvas parameters (width/height/highlightthickness)")
    src = src_new

    return src, changelog

def main() -> int:
    try:
        if not os.path.isfile(MOD):
            log(f"[ERR] File not found: {MOD}")
            return 2

        with io.open(MOD, "r", encoding="utf-8") as f:
            src = f.read()

        bak = backup(MOD)
        new, changes = patch_text(src)

        if not changes:
            log("No changes applied (module already healthy or patterns not found).")
        else:
            with io.open(MOD, "w", encoding="utf-8", newline="\n") as f:
                f.write(new)
            for c in changes:
                log(f"Change: {c}")

        # Syntax-Check
        try:
            py_compile.compile(MOD, doraise=True)
            log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}")
            # Restore backup
            shutil.copy2(bak, MOD)
            log("Restored from backup due to syntax error.")
            return 3

        log("R1157 completed successfully.")
        return 0

    except Exception as e:
        tb = traceback.format_exc()
        log(f"[EXC] {e}\n{tb}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
