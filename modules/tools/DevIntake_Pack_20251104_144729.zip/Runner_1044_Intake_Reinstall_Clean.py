"""
Runner_1044_Intake_Reinstall_Clean
Setzt modules/module_code_intake.py komplett neu & stabil auf:
- Keine Type-Hints, keine akustischen Signale
- Auto-Erkennung (Paste/Tippen/Start, debounced)
- Buttons (Erkennen/Speichern/Löschen) fest verdrahtet (command + MouseUp)
- Kontextmenüs, Tooltips, Resizing-fest
- Rechte Liste: History oder Zielordner-Scan (Fallback)
"""
from __future__ import annotations
import os, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
OUT  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1044] {ts} {msg}\n")
    except Exception:
        pass

SRC = r'''"""
ShrimpDev Code Intake – Clean Reinstall (v9.9.34)
- Keine Type-Hints, keine Sounds
- Auto-Erkennung Name/Endung bei Paste/Tippen/Start
- Buttons hart verdrahtet, Kontextmenüs, Tooltips
- Liste rechts via History oder Zielordner-Scan
"""
from __future__ import annotations
import os, re, json, shutil, tkinter as tk
from tkinter import ttk, filedialog, messagebox
from modules.config_mgr import ConfigMgr

_PADX = 8
_PADY = 6

class Tooltip:
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tip = None
        widget.bind("<Enter>", self._show)
        widget.bind("<Leave>", self._hide)
    def _show(self, _=None):
        if self.tip or not self.text:
            return
        x = self.widget.winfo_rootx() + 10
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 4
        self.tip = tk.Toplevel(self.widget)
        self.tip.wm_overrideredirect(True)
        self.tip.wm_geometry("+%d+%d" % (x, y))
        ttk.Label(self.tip, text=self.text, relief="solid", borderwidth=1, padding=(6,3)).pack()
    def _hide(self, _=None):
        if self.tip:
            self.tip.destroy()
            self.tip = None

def _open_explorer_select(path):
    try:
        if os.path.exists(path):
            os.system('explorer /select,"%s"' % path)
        else:
            os.system('explorer "%s"' % (os.path.dirname(path) or "."))
    except Exception:
        pass

class IntakeFrame(ttk.Frame):
    def __init__(self, master):
        ttk.Frame.__init__(self, master)
        self.cfg = ConfigMgr()
        self.var_ext_manual = False
        self.var_name_manual = False
        self._build_ui()
        self._load_table()
        self._update_led(self.led_detect, "yellow")
        self._update_led(self.led_target, "green" if os.path.isdir(self.var_target.get()) else "red")
        self._bind_shortcuts()
        # initiale Auto-Erkennung
        self.after(200, self._auto_detect_if_needed)

    # ---------- UI ----------
    def _build_ui(self):
        self.columnconfigure(0, weight=1)
        self.rowconfigure(3, weight=1)

        head = ttk.Frame(self)
        head.grid(row=0, column=0, sticky="ew", padx=_PADX, pady=(_PADY,4))
        for c in (1,3,7,9):
            head.columnconfigure(c, weight=1)

        ttk.Label(head, text="Workspace:").grid(row=0, column=0, sticky="w")
        self.var_ws = tk.StringVar(value=self.cfg.get_str("general","default_path", os.getcwd()))
        ent_ws = ttk.Entry(head, textvariable=self.var_ws)
        ent_ws.grid(row=0, column=1, sticky="ew", padx=(4,4))
        ttk.Button(head, text="...", width=3, command=self._pick_ws).grid(row=0, column=2, padx=(0,12))
        Tooltip(ent_ws, "Arbeitsverzeichnis")

        ttk.Label(head, text="Name:").grid(row=0, column=3, sticky="w")
        self.var_name = tk.StringVar(value="")
        ent_name = ttk.Entry(head, textvariable=self.var_name)
        ent_name.grid(row=0, column=4, sticky="ew", padx=(4,4))
        ent_name.bind("<KeyRelease>", self._on_name_edited)
        ttk.Button(head, text="Einfügen", width=8, command=self._paste_name).grid(row=0, column=5, padx=(0,12))
        Tooltip(ent_name, "Dateiname (ohne Pfad). Per Kontextmenü in der Liste kopierbar.")

        ttk.Label(head, text="Endung:").grid(row=0, column=6, sticky="w")
        self.var_ext = tk.StringVar(value="")
        ent_ext = ttk.Entry(head, textvariable=self.var_ext, width=7)
        ent_ext.grid(row=0, column=7, sticky="ew", padx=(4,12))
        ent_ext.bind("<KeyRelease>", self._on_ext_changed)
        ent_ext.bind("<FocusOut>", self._normalize_ext)
        Tooltip(ent_ext, "Endung (.py/.bat/...). Manuelle Eingabe wird respektiert.")

        ttk.Label(head, text="Zielordner:").grid(row=0, column=8, sticky="w")
        self.var_target = tk.StringVar(value=self.cfg.get_str("general","target_folder", os.path.join(os.getcwd(),"tools")))
        ent_tgt = ttk.Entry(head, textvariable=self.var_target)
        ent_tgt.grid(row=0, column=9, sticky="ew", padx=(4,4))
        ttk.Button(head, text="...", width=3, command=self._pick_target).grid(row=0, column=10)
        cm_tgt = tk.Menu(self, tearoff=0)
        cm_tgt.add_command(label="Öffnen im Explorer", command=lambda:_open_explorer_select(self.var_target.get()))
        cm_tgt.add_command(label="Pfad kopieren", command=lambda:self._copy_text(self.var_target.get()))
        ent_tgt.bind("<Button-3>", lambda e:self._popup_menu(cm_tgt,e))
        Tooltip(ent_tgt, "Ablagepfad für gespeicherte Dateien")

        # LEDs
        leds = ttk.Frame(self)
        leds.grid(row=1, column=0, sticky="ew", padx=_PADX, pady=(0,4))
        self.led_target = tk.Canvas(leds, width=14, height=14, highlightthickness=0); self.led_target.grid(row=0, column=0, padx=(0,4))
        ttk.Label(leds, text="Ziel").grid(row=0, column=1, padx=(0,16))
        self.led_detect = tk.Canvas(leds, width=14, height=14, highlightthickness=0); self.led_detect.grid(row=0, column=2, padx=(0,4))
        ttk.Label(leds, text="Erkennung").grid(row=0, column=3, padx=(0,16))
        self.led_save = tk.Canvas(leds, width=14, height=14, highlightthickness=0); self.led_save.grid(row=0, column=4, padx=(0,4))
        ttk.Label(leds, text="Speichern").grid(row=0, column=5)

        # Toolbar
        bar = ttk.Frame(self); bar.grid(row=2, column=0, sticky="ew", padx=_PADX, pady=(0,4))
        for c in (0,1,2): bar.columnconfigure(c, weight=0)
        bar.columnconfigure(3, weight=1)
        self.btn_detect = ttk.Button(bar, text="Erkennen (Ctrl+I)", command=self._on_click_detect)
        self.btn_save   = ttk.Button(bar, text="Speichern (Ctrl+S)", command=self._on_click_save)
        self.btn_del    = ttk.Button(bar, text="Löschen (Entf)",    command=self._on_click_delete)
        self.btn_detect.grid(row=0, column=0, padx=(0,6), sticky="w")
        self.btn_save.grid(  row=0, column=1, padx=(0,6), sticky="w")
        self.btn_del.grid(   row=0, column=2, padx=(0,0), sticky="w")
        self.lbl_ping = ttk.Label(bar, text="", anchor="w"); self.lbl_ping.grid(row=0, column=3, sticky="ew", padx=(12,0))
        # zusätzliche MouseUp-Binds
        try:
            self.btn_detect.bind("<ButtonRelease-1>", lambda e:self._on_click_detect())
            self.btn_save.bind(  "<ButtonRelease-1>", lambda e:self._on_click_save())
            self.btn_del.bind(   "<ButtonRelease-1>", lambda e:self._on_click_delete())
        except Exception:
            pass
        Tooltip(self.btn_detect, "Erkennt Name+Endung (respektiert manuelle Eingaben)")
        Tooltip(self.btn_save,   "Speichert Editor-Inhalt als Datei im Zielordner")
        Tooltip(self.btn_del,    "Löscht die ausgewählte Datei endgültig")

        # Body
        body = ttk.Panedwindow(self, orient="horizontal")
        body.grid(row=3, column=0, sticky="nsew", padx=_PADX, pady=(0,_PADY))

        # Editor links
        left = ttk.Frame(body); left.rowconfigure(0,weight=1); left.columnconfigure(0,weight=1)
        self.txt = tk.Text(left, wrap="none", undo=True, font=("Consolas",10))
        # Auto-Detect Bindings
        self._detect_job = None
        self.txt.bind("<<Paste>>", self._on_editor_paste)
        self.txt.bind("<Control-v>", self._on_editor_paste)
        self.txt.bind("<<Modified>>", self._on_editor_modified)
        self.txt.bind("<KeyRelease>", self._on_editor_key)
        y1 = ttk.Scrollbar(left, orient="vertical",   command=self.txt.yview)
        x1 = ttk.Scrollbar(left, orient="horizontal", command=self.txt.xview)
        self.txt.configure(yscrollcommand=y1.set, xscrollcommand=x1.set)
        self.txt.grid(row=0,column=0,sticky="nsew"); y1.grid(row=0,column=1,sticky="ns"); x1.grid(row=1,column=0,sticky="ew")
        self.menu_editor = tk.Menu(self, tearoff=0)
        self.menu_editor.add_command(label="Kopieren", command=lambda:self.txt.event_generate("<<Copy>>"))
        self.menu_editor.add_command(label="Einfügen", command=lambda:self.txt.event_generate("<<Paste>>"))
        self.txt.bind("<Button-3>", lambda e:self._popup_menu(self.menu_editor,e))
        Tooltip(self.txt, "Editor – der Inhalt wird gespeichert.")

        body.add(left, weight=3)

        # Tabelle rechts
        right = ttk.Frame(body); right.rowconfigure(0,weight=1); right.columnconfigure(0,weight=1)
        cols=("name","ext","subfolder")
        self.tbl = ttk.Treeview(right, columns=cols, show="headings", selectmode="browse")
        for c,w,a in (("name",240,"w"),("ext",70,"center"),("subfolder",180,"w")):
            self.tbl.heading(c,text=c); self.tbl.column(c,anchor=a,width=w,stretch=(c!="ext"))
        y2 = ttk.Scrollbar(right, orient="vertical",   command=self.tbl.yview)
        x2 = ttk.Scrollbar(right, orient="horizontal", command=self.tbl.xview)
        self.tbl.configure(yscrollcommand=y2.set, xscrollcommand=x2.set)
        self.tbl.grid(row=0,column=0,sticky="nsew"); y2.grid(row=0,column=1,sticky="ns"); x2.grid(row=1,column=0,sticky="ew")
        self.menu_tbl = tk.Menu(self, tearoff=0)
        self.menu_tbl.add_command(label="Name kopieren", command=self._copy_name_selected)
        self.menu_tbl.add_command(label="Pfad kopieren",  command=self._copy_selected)
        self.menu_tbl.add_command(label="Öffnen im Explorer", command=self._open_selected)
        self.menu_tbl.add_separator()
        self.menu_tbl.add_command(label="Löschen", command=self._on_click_delete)
        self.tbl.bind("<Button-3>", lambda e:self._popup_menu(self.menu_tbl,e))
        self.tbl.bind("<Double-Button-1>", self._dbl_open)
        body.add(right, weight=2)

    # ---------- helpers ----------
    def _bind_shortcuts(self):
        root = self.winfo_toplevel()
        try:
            root.unbind_all("<Control-s>")
            root.unbind_all("<Control-i>")
        except Exception:
            pass
        root.bind_all("<Control-s>", lambda e:self._on_click_save())
        root.bind_all("<Control-i>", lambda e:self._on_click_detect())
        self.tbl.bind("<Control-c>", lambda e:self._copy_selected())
        self.tbl.bind("<Delete>",    lambda e:self._on_click_delete())

    def _popup_menu(self, menu, evt):
        try:
            row = self.tbl.identify_row(evt.y) if menu is self.menu_tbl else None
            if row:
                self.tbl.selection_set(row)
            menu.tk_popup(evt.x_root, evt.y_root)
        finally:
            menu.grab_release()

    def _update_led(self, canvas, color):
        canvas.delete("all")
        canvas.create_oval(2,2,12,12, fill=color, outline="")

    def _ping(self, text):
        try:
            self.lbl_ping.configure(text=text)
        except Exception:
            pass

    def _copy_text(self, text):
        try:
            self.clipboard_clear()
            self.clipboard_append(text)
        except Exception:
            pass

    def _paste_name(self):
        try:
            val = self.clipboard_get()
        except Exception:
            val = ""
        val = (val or "").strip()
        if val:
            self.var_name.set(val)
            self._on_name_edited()

    def _pick_ws(self):
        d = filedialog.askdirectory(title="Workspace wählen", initialdir=self.var_ws.get() or os.getcwd())
        if d:
            self.var_ws.set(d)
            self.cfg.set_str("general","default_path", d)

    def _pick_target(self):
        d = filedialog.askdirectory(title="Zielordner wählen", initialdir=self.var_target.get() or os.getcwd())
        if d:
            self.var_target.set(d)
            self.cfg.set_str("general","target_folder", d)
            self._update_led(self.led_target, "green" if os.path.isdir(d) else "red")

    # Flags/Normalisierung
    def _on_ext_changed(self, _evt=None):
        self.var_ext_manual = True
    def _normalize_ext(self, _evt=None):
        ext = (self.var_ext.get() or "").strip().lower()
        if ext and not ext.startswith("."):
            ext = "."+ext
        self.var_ext.set(ext)
    def _on_name_edited(self, _evt=None):
        self.var_name_manual = True
        self._update_led(self.led_detect, "yellow")

    # ---------- detection ----------
    def _guess_name_from_text(self, text):
        t = text or ""
        m = re.search(r'(?i)tools[\\/](Runner_[0-9]{3,4}[_A-Za-z0-9\-]+)\.(py|bat|cmd)', t)
        if m: return m.group(1), "."+m.group(2).lower()
        m = re.search(r'(?i)\b(Runner_[0-9]{3,4}[_A-Za-z0-9\-]+)\.(py|bat|cmd)\b', t)
        if m: return m.group(1), "."+m.group(2).lower()
        m = re.search(r'(?i)\bpy(?:\s+-3)?\s+tools[\\/](Runner_[^ \r\n\t]+)\.(py)\b', t)
        if m: return m.group(1), ".py"
        m = re.search(r'(?i)\bcall\s+tools[\\/](Runner_[^ \r\n\t]+)\.(bat|cmd)\b', t)
        if m: return m.group(1), "."+m.group(2).lower()
        m = re.search(r'(?im)^[;#:\- ]+\s*name\s*[:=]\s*(Runner_[0-9]{3,4}[_A-Za-z0-9\-]+)\.(py|bat|cmd)\s*$', t)
        if m: return m.group(1), "."+m.group(2).lower()
        m = re.search(r'(?im)^\s*set\s+name\s*=\s*(Runner_[0-9]{3,4}[_A-Za-z0-9\-]+)\.(py|bat|cmd)\s*$', t)
        if m: return m.group(1), "."+m.group(2).lower()
        return "", ""

    def _guess_ext_from_text(self, text):
        head = (text or "").lstrip()[:4000]
        if re.search(r"(?im)^\s*@echo\s+off\b", head) or re.search(r"(?im)^\s*rem\s", head):
            return ".bat"
        if re.search(r"(?im)^#!.*python", head):
            return ".py"
        if re.search(r"(?m)^\s*(from\s+\w+\s+import|import\s+\w+|def\s+\w+\(|class\s+\w+\(|if\s+__name__\s*==\s*['\"]__main__['\"])"," "+head):
            return ".py"
        try:
            if head and head.strip()[0] in "{[":
                json.loads(head)
                return ".json"
        except Exception:
            pass
        if re.search(r"(?m)^\s*-\s+\w+", head) or re.search(r"(?m)^\s*\w+:\s+.+", head):
            return ".yml"
        if re.search(r"(?m)^\s*\[[^\]]+\]\s*$", head) and re.search(r"(?m)^\s*\w+\s*=", head):
            return ".ini"
        if re.search(r"(?m)^\s*#\s+\w+", head):
            return ".md"
        return ""

    def _apply_ext_to_name(self, name, ext):
        ext = (ext or "").strip().lower()
        if ext and not ext.startswith("."):
            ext = "."+ext
        base, cur = os.path.splitext(name)
        if not ext:
            return name if cur else (name + ".txt")
        if (cur or "").lower() == ext:
            return name
        return (base or name) + ext

    def _detect(self):
        name = (self.var_name.get() or "").strip()
        nm, ext_from_name = os.path.splitext(name) if name else ("","")
        ext = (ext_from_name or "").lower()

        try:
            content = self.txt.get("1.0","end-1c")
        except Exception:
            content = ""

        if not self.var_name_manual:
            nm_guess, ext_guess = self._guess_name_from_text(content)
            if nm_guess:
                self.var_name.set(nm_guess + (ext_guess or ""))
                if not self.var_ext_manual and not ext:
                    ext = (ext_guess or "").lower()

        if not ext:
            ext = self._guess_ext_from_text(content) or ""

        if not self.var_ext_manual:
            self.var_ext.set(ext)
        else:
            self._normalize_ext()
            ext = (self.var_ext.get() or "").lower()

        allowed = {".py",".bat",".cmd",".json",".txt",".yml",".yaml",".ini",".md",".shcut"}
        ok = bool(ext) and (ext in allowed or (ext == "" and not self.var_ext_manual))
        self._update_led(self.led_detect, "green" if ok else "yellow")
        self._ping("Erkennung: " + (ext or "(keine)"))
        return ok

    # --- Auto-Detect Support ---
    def _on_editor_paste(self, _evt=None):
        self._schedule_detect(200)
    def _on_editor_key(self, _evt=None):
        if not (self.var_name.get() or "").strip():
            self._schedule_detect(250)
    def _on_editor_modified(self, _evt=None):
        try:
            self.txt.edit_modified(False)
        except Exception:
            pass
        if not (self.var_name.get() or "").strip():
            self._schedule_detect(300)
    def _schedule_detect(self, delay_ms=300):
        try:
            if getattr(self, "_detect_job", None):
                self.after_cancel(self._detect_job)
        except Exception:
            pass
        self._detect_job = self.after(delay_ms, self._auto_detect_if_needed)
    def _auto_detect_if_needed(self):
        try:
            name_empty = not (self.var_name.get() or "").strip()
            if name_empty or not self.var_ext_manual:
                self._ping("Auto-Erkennung…")
                self._detect()
        except Exception:
            pass

    # ---------- actions ----------
    def _save(self):
        tgt_dir = self.var_target.get().strip() or "."
        os.makedirs(tgt_dir, exist_ok=True)
        name = (self.var_name.get() or "").strip() or "snippet"
        name = self._apply_ext_to_name(name, self.var_ext.get())
        target_path = os.path.join(tgt_dir, name)
        data = self.txt.get("1.0","end-1c").encode("utf-8")
        try:
            with open(target_path, "wb") as f:
                f.write(data)
            self.cfg.append_history(target_path)
            self._load_table()
            self._update_led(self.led_save, "green")
            self._ping("Gespeichert.")
        except Exception:
            messagebox.showerror("Fehler", "Konnte nicht speichern.")
            self._update_led(self.led_save, "red")

    def _load_table(self):
        for i in self.tbl.get_children():
            self.tbl.delete(i)
        tgt = os.path.abspath(self.var_target.get() or ".")
        entries = []
        try:
            for p in self.cfg.get_history():
                entries.append(p)
        except Exception:
            pass
        if not entries:
            try:
                for root, dirs, files in os.walk(tgt):
                    for fn in files:
                        if os.path.splitext(fn)[1].lower() in (".py",".bat",".cmd",".json",".txt",".yml",".yaml",".ini",".md",".shcut"):
                            entries.append(os.path.join(root, fn))
                    break
            except Exception:
                pass
        for p in entries:
            base = os.path.basename(p)
            name, ext = os.path.splitext(base)
            try:
                rel = os.path.relpath(os.path.dirname(os.path.abspath(p)), tgt)
                sub = "" if rel in (".","") else rel
            except Exception:
                sub = ""
            self.tbl.insert("", "end", values=(name, (ext or "").lower(), sub))

    def _path_of_item(self, item_id):
        vals = self.tbl.item(item_id, "values")
        if not vals:
            return ""
        name, ext, sub = vals
        folder = self.var_target.get() or "."
        if sub:
            folder = os.path.join(folder, sub)
        return os.path.join(folder, "%s%s" % (name, ext))

    def _dbl_open(self, _evt=None):
        sel = self.tbl.selection()
        if not sel:
            return
        path = self._path_of_item(sel[0])
        if not os.path.isfile(path):
            return
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                self.txt.delete("1.0","end")
                self.txt.insert("1.0", f.read())
            self.var_name.set(os.path.basename(path))
            self.var_name_manual = False
            self._detect()
        except Exception:
            pass

    def _copy_name_selected(self):
        sel = self.tbl.selection()
        if not sel:
            return
        vals = self.tbl.item(sel[0], "values")
        if not vals:
            return
        self._copy_text(str(vals[0]))

    def _copy_selected(self):
        sel = self.tbl.selection()
        if not sel:
            return
        self._copy_text(self._path_of_item(sel[0]))

    def _open_selected(self):
        sel = self.tbl.selection()
        if not sel:
            return
        path = self._path_of_item(sel[0])
        _open_explorer_select(path)

    def _on_click_detect(self):
        self._ping("Erkennung…")
        self._detect()

    def _on_click_save(self):
        self._ping("Speichern…")
        self._save()

    def _on_click_delete(self):
        sel = self.tbl.selection()
        if not sel:
            return
        path = self._path_of_item(sel[0])
        if not os.path.isfile(path):
            self.cfg.remove_history(path)
            self._load_table()
            return
        if not messagebox.askyesno("Löschen bestätigen", "Datei endgültig löschen?\n\n%s" % path):
            return
        try:
            os.remove(path)
        except Exception:
            try:
                trash = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "_Archiv", "_Trash"))
                os.makedirs(trash, exist_ok=True)
                shutil.move(path, os.path.join(trash, os.path.basename(path) + ".del"))
            except Exception:
                messagebox.showerror("Fehler", "Löschen fehlgeschlagen.")
                return
        self.cfg.remove_history(path)
        self._load_table()
        self._ping("Gelöscht.")
'''

def main():
    # Backup und schreiben
    if os.path.exists(OUT):
        os.makedirs(ARCH, exist_ok=True)
        bck = os.path.join(ARCH, f"module_code_intake.py.{int(time.time())}.bak")
        shutil.copy2(OUT, bck)
        log(f"Backup: {OUT} -> {bck}")
    with open(OUT, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(SRC)
    # Meta
    with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
        f.write("ShrimpDev v9.9.34\n")
    with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
        f.write("""
## v9.9.34 (2025-10-18)
- module_code_intake.py sauber neu installiert (ohne Type-Hints & Sounds).
- Auto-Erkennung (Paste/Key/Start), Buttons fest verdrahtet, Listenscan-Fallback.
""")
    log("module_code_intake.py neu installiert (v9.9.34).")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
