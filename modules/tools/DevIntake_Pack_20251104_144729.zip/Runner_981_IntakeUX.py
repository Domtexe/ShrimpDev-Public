from __future__ import annotations
from pathlib import Path
import time

ROOT = Path(r"D:\ShrimpDev")
MOD  = ROOT / "modules"
LOGF = ROOT / "debug_output.txt"

def log(msg: str):
    try: LOGF.open("a", encoding="utf-8", errors="ignore").write(f"[R981] {msg}\n")
    except Exception: pass
    print(f"[R981] {msg}")

def w(p: Path, s: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        bak = p.with_suffix(p.suffix + "." + time.strftime("%Y%m%d_%H%M%S") + ".bak")
        p.replace(bak); log(f"backup {bak.name}")
    p.write_text(s, encoding="utf-8"); log(f"wrote {p.relative_to(ROOT)}")

def intake_py() -> str:
    return r'''from __future__ import annotations
import re, tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from typing import Tuple

# --- Config-Loader (robust) ---------------------------------------------------
try:
    from modules.config_mgr import load_config, save_config
except Exception:
    def load_config() -> dict:
        return {"workspace_root": r"D:\ShrimpHub", "intake_silent_success": False}
    def save_config(_conf: dict) -> None:
        pass

ROOT = Path(r"D:\ShrimpDev")

# --- Erkennung Name/Endung ----------------------------------------------------
_PATTERNS = [
    # explizite Marker (höchste Priorität)
    r"(?im)^\s*(?:#|//|;|REM)\s*(?:file|filename|path|filepath)\s*:\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*$",
    r"(?im)^\s*@file\s*:\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*$",
    r"(?im)^\s*#\s*filepath\s*:\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*$",
    # YAML front matter
    r"(?is)^---\s*.*?(?:^|\n)\s*(?:file|filename|path)\s*:\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*.*?---",
    # fenced code inkl. filename=
    r"(?is)^[`\"']{3}[^`\"'\n]*?(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)[^`\"']*?[`\"']{3}",
    r"(?is)^[`\"']{3}[^`\n]*?filename\s*=\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)[^`]*?[`\"']{3}",
    # frühe Zeilen mit file:/filename=
    r"(?im)^\s*(?:#|//|;|REM)?\s*(?:file|filename)\s*(?:=|:)\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*$",
    # Heuristik: Runner_/module_
    r"(?i)\b(Runner_[\w\-]+\.(?:py|bat|cmd|vbs))\b",
    r"(?i)\b(module_[\w\-]+\.py)\b",
]

def _detect_name_ext(code: str) -> Tuple[str|None, str|None]:
    head = code[:12000]
    for pat in _PATTERNS:
        m = re.search(pat, head)
        if m:
            p = m.group("p") if "p" in m.groupdict() else m.group(1)
            name = Path(p).name
            ext  = Path(name).suffix.lower()
            return name, ext
    # Fallback: wenn gar nichts, generiere sinnvollen Namen
    # Heuristik: enthält 'def main' → .py / enthält '@echo off' → .bat
    if re.search(r"(?m)^\s*def\s+main\s*\(", head): return f"module_auto_{int(time.time())}.py", ".py"
    if re.search(r"(?im)^\s*@echo\s+off\b", head):  return f"Runner_auto_{int(time.time())}.bat", ".bat"
    # Allgemeiner Fallback
    return f"snippet_{int(time.time())}.txt", ".txt"

def _map_target(ws: Path, name: str, ext: str) -> Path:
    n = (name or "").lower()
    if ext == ".py" and n.startswith("runner_"): return ws / "tools"
    if ext in {".bat", ".cmd", ".vbs", ".ps1"}: return ws / "tools"
    if ext == ".py" and n.startswith("module_"): return ws / "modules"
    if ext == ".py": return ws / "modules" / "snippets"
    if ext in {".md", ".json", ".txt"}: return ws
    return ws

# --- GUI (Tab) ----------------------------------------------------------------
from .common_tabs import ensure_tab

class _IntakeState:
    def __init__(self):
        self.conf = load_config()
        self.ws = Path(self.conf.get("workspace_root", r"D:\ShrimpHub"))
        self.silent = bool(self.conf.get("intake_silent_success", False))

def _build_tab(parent):
    st = _IntakeState()
    frm = ttk.Frame(parent)

    # Workspace-Zeile
    top = ttk.Frame(frm); top.pack(fill="x", pady=6)
    ttk.Label(top, text="Workspace:").pack(side="left")
    var_ws = tk.StringVar(value=str(st.ws))
    ttk.Entry(top, textvariable=var_ws, width=60).pack(side="left", padx=6)
    ttk.Button(top, text="…", command=lambda: _pick_ws(var_ws)).pack(side="left")

    # Override-Zeile (Name/Ext/Target)
    bar = ttk.Frame(frm); bar.pack(fill="x", pady=4)
    var_name = tk.StringVar(); var_ext = tk.StringVar(); var_target = tk.StringVar()
    for lbl, var, w in (("Dateiname:", var_name, 40), ("Endung:", var_ext, 8), ("Zielordner:", var_target, 50)):
        ttk.Label(bar, text=lbl).pack(side="left")
        ttk.Entry(bar, textvariable=var, width=w).pack(side="left", padx=6)

    # Text-Editor
    txt = tk.Text(frm, wrap="none", undo=True)
    txt.pack(fill="both", expand=True)

    # Status + Buttons + "Nicht wieder anzeigen"
    btm = ttk.Frame(frm); btm.pack(fill="x", pady=6)
    status = tk.StringVar(value="Bereit.")
    ttk.Label(btm, textvariable=status, anchor="w").pack(side="left")

    var_silent = tk.BooleanVar(value=st.silent)
    def _toggle_silent():
        st.silent = bool(var_silent.get())
        st.conf["intake_silent_success"] = st.silent
        save_config(st.conf)
    ttk.Checkbutton(btm, text="Nicht wieder anzeigen (Speicher-OK)", variable=var_silent,
                    command=_toggle_silent).pack(side="left", padx=12)

    ttk.Button(btm, text="Erkennen (Ctrl+I)",
               command=lambda: _detect(txt, var_name, var_ext, var_target, var_ws, status)).pack(side="right", padx=6)
    ttk.Button(btm, text="Speichern (Ctrl+S)",
               command=lambda: _save(txt, var_name, var_ext, var_target, status, st)).pack(side="right")

    # Bindings
    frm.bind_all("<Control-i>", lambda e: _detect(txt, var_name, var_ext, var_target, var_ws, status))
    frm.bind_all("<Control-s>", lambda e: _save(txt, var_name, var_ext, var_target, status, st))
    # Auto-Detect: bei Paste/Änderung
    txt.bind("<<Paste>>", lambda e: _after_paste_detect(frm, txt, var_name, var_ext, var_target, var_ws, status))
    txt.bind("<Control-v>", lambda e: _after_paste_detect(frm, txt, var_name, var_ext, var_target, var_ws, status))
    def _on_mod(_=None):
        txt.edit_modified(0)
        # Nur automatische Füllung, wenn noch leer
        if not var_name.get() or not var_ext.get():
            _detect(txt, var_name, var_ext, var_target, var_ws, status, auto=True)
    txt.bind("<<Modified>>", _on_mod)

    return frm

def _after_paste_detect(root, txt, var_name, var_ext, var_target, var_ws, status):
    # Nach dem Paste kurz warten bis der Inhalt wirklich drin ist
    root.after(20, lambda: _detect(txt, var_name, var_ext, var_target, var_ws, status, auto=True))

def _pick_ws(var_ws: tk.StringVar):
    d = filedialog.askdirectory(title="Workspace wählen", initialdir=var_ws.get() or r"D:\ShrimpHub")
    if d: var_ws.set(d)

def _detect(txt, var_name, var_ext, var_target, var_ws, status, auto: bool=False):
    code = txt.get("1.0", "end-1c")
    name, ext = _detect_name_ext(code)
    # Endung ggf. aus Name extrahieren
    if (not ext) and name:
        ext = Path(name).suffix.lower()
    if name: var_name.set(name)
    if ext:  var_ext.set(ext)
    nm, ex = var_name.get().strip(), var_ext.get().strip().lower()
    if nm and ex:
        ws = Path(var_ws.get() or r"D:\ShrimpHub")
        var_target.set(str(_map_target(ws, nm, ex)))
    if not auto:
        status.set(f"Erkannt: name={nm!r}, ext={ex!r}, target={var_target.get()!r}")

def _save(txt, var_name, var_ext, var_target, status, st):
    nm, ex, target = var_name.get().strip(), var_ext.get().strip().lower(), var_target.get().strip()
    code = txt.get("1.0", "end-1c")
    if not nm or not ex or not target:
        messagebox.showwarning("ShrimpDev", "Bitte Name/Endung/Target prüfen."); return
    if not nm.lower().endswith(ex):
        nm = Path(nm).stem + ex
        var_name.set(nm)
    out_dir = Path(target); out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / nm
    # Rotations-Backups
    if out.exists():
        for i in range(4,0,-1):
            pi = out.with_name(out.name + f".{i}.bak"); pj = out.with_name(out.name + f".{i+1}.bak")
            if pi.exists(): pi.replace(pj)
        try: out.with_name(out.name + ".bak").replace(out.with_name(out.name + ".1.bak"))
        except Exception: pass
    out.write_text(code, encoding="utf-8")
    # Erfolgsmeldung – unterdrückbar
    if not st.silent:
        try: messagebox.showinfo("ShrimpDev", f"Gespeichert:\n{out}")
        except Exception: pass
    status.set(f"Gespeichert: {out}")

def open_intake(app: tk.Tk) -> bool:
    try:
        return ensure_tab(app, "intake", "Code Intake", _build_tab)
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Intake Fehler:\n{ex}")
        except Exception: pass
        return False
'''
    return intake_py()

def main() -> int:
    w(MOD / "module_code_intake.py", intake_py())
    print("[R981] Intake-UX aktualisiert (Auto-Detect, Popup-OptOut, robuste Erkennung).")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
