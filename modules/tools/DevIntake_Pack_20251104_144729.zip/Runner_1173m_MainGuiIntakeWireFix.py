# -*- coding: utf-8 -*-
"""
Runner_1173m_MainGuiIntakeWireFix
- Ergänzt fehlende _safe_add_intake_tab(nb)
- Härtet/ersetzt _mount_intake_tab_safe(...)
- Backup + Syntax-Check + Rollback
"""

import io, os, re, sys, time, traceback, py_compile

ROOT_MARK = "ShrimpDev"
MAIN = "main_gui.py"
ARCH = "_Archiv"
TS = str(int(time.time()))

def _root_dir():
    # gehe von /tools/ aus nach oben bis main_gui.py gefunden
    here = os.path.abspath(os.path.dirname(__file__))
    cur = here
    for _ in range(6):
        cand = os.path.join(cur, MAIN)
        if os.path.isfile(cand):
            return cur
        nxt = os.path.dirname(cur)
        if nxt == cur:
            break
        cur = nxt
    raise FileNotFoundError("main_gui.py nicht gefunden (Aufwärtssuche).")

def _read(p):
    with io.open(p, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def _write(p, s):
    with io.open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)

def _log(root, msg):
    try:
        dp = os.path.join(root, "debug_output.txt")
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        with io.open(dp, "a", encoding="utf-8", newline="\n") as f:
            f.write(f"[1173m {ts}] {msg}\n")
    except Exception:
        pass

def _backup(root, src):
    os.makedirs(os.path.join(root, ARCH), exist_ok=True)
    bak = os.path.join(root, ARCH, f"{os.path.basename(src)}.{TS}.bak")
    data = _read(src)
    _write(bak, data)
    return bak

def _ensure_safe_add_intake_tab(text):
    # Existiert bereits?
    if re.search(r"^\s*def\s+_safe_add_intake_tab\s*\(", text, re.M):
        return text, False

    # vor _safe_main einfügen (oder am Dateiende als Fallback)
    helper = r'''
def _safe_add_intake_tab(nb):
    """
    Fügt den Code-Intake-Tab robust hinzu.
    """
    try:
        tab = IntakeFrame(nb)
    except Exception as ex:
        write_log("GUI", "INTAKE_INIT_ERROR\\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        tab = ttk.Frame(nb)
        ttk.Label(tab, text="Fehler beim Laden des Intake-Tabs. Details siehe debug_output.txt").pack(padx=10, pady=10)
    try:
        nb.add(tab, text="Code Intake")
    except Exception as ex:
        write_log("GUI", f"INTAKE_TAB_ADD_ERR: {ex}")
'''.lstrip("\n")

    m = re.search(r"^\s*def\s+_safe_main\s*\(", text, re.M)
    if m:
        i = m.start()
        return text[:i] + helper + "\n" + text[i:], True
    else:
        return text + "\n\n" + helper, True

def _fix_mount_helper(text):
    """
    Ersetzt fehlerhafte Fassungen von _mount_intake_tab_safe(...) (z.B. Referenz auf self)
    durch eine saubere Version, die einen Container entgegennimmt.
    """
    pat = re.compile(r"^\s*def\s+_mount_intake_tab_safe\s*\([^\)]*\)\s*:(?:\n[^\n]*)*", re.M)
    if not re.search(r"^\s*def\s+_mount_intake_tab_safe\s*\(", text, re.M):
        # Kein Helper vorhanden -> wir fügen einen hinzu (vor _safe_main)
        clean = r'''
def _mount_intake_tab_safe(container):
    """
    Mountet IntakeFrame in den gegebenen Container. Keine Self-Abhängigkeit.
    """
    try:
        inner = IntakeFrame(container)
    except Exception as ex:
        write_log("GUI", "INTAKE_INIT_ERROR\\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        inner = ttk.Frame(container)
        ttk.Label(inner, text="Fehler beim Laden des Intake-Tabs. Details siehe debug_output.txt").pack(padx=10, pady=10)
    try:
        inner.pack(fill="both", expand=True)
    except Exception as ex:
        write_log("GUI", f"INTAKE_MOUNT_ERR: {ex}")
'''.lstrip("\n")
        m = re.search(r"^\s*def\s+_safe_main\s*\(", text, re.M)
        if m:
            i = m.start()
            return text[:i] + clean + "\n" + text[i:], True
        else:
            return text + "\n\n" + clean, True

    # Helper vorhanden -> durch saubere Version ersetzen
    clean = r'''
def _mount_intake_tab_safe(container):
    """
    Mountet IntakeFrame in den gegebenen Container. Keine Self-Abhängigkeit.
    """
    try:
        inner = IntakeFrame(container)
    except Exception as ex:
        write_log("GUI", "INTAKE_INIT_ERROR\\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        inner = ttk.Frame(container)
        ttk.Label(inner, text="Fehler beim Laden des Intake-Tabs. Details siehe debug_output.txt").pack(padx=10, pady=10)
    try:
        inner.pack(fill="both", expand=True)
    except Exception as ex:
        write_log("GUI", f"INTAKE_MOUNT_ERR: {ex}")
'''.lstrip("\n")
    # Einfach: ersetze Signatur + Block grob per Regex auf Funktionskopf bis zur nächsten def/class auf gleicher Spaltenlage
    repl_pat = re.compile(
        r"^\s*def\s+_mount_intake_tab_safe\s*\([^\)]*\)\s*:\n(?:[ \t].*\n)+",
        re.M
    )
    new_text, n = repl_pat.subn(clean, text, count=1)
    if n == 0:
        # Fallback: anhängen
        new_text = text + "\n\n" + clean
        return new_text, True
    return new_text, True

def main():
    root = _root_dir()
    src = os.path.join(root, MAIN)
    bak = _backup(root, src)
    _log(root, f"Backup erstellt: {bak}")

    text = _read(src)
    changed = False

    text, ch1 = _ensure_safe_add_intake_tab(text)
    changed = changed or ch1

    text, ch2 = _fix_mount_helper(text)
    changed = changed or ch2

    if not changed:
        _log(root, "Keine Änderung notwendig (Helper bereits vorhanden/sauber).")
        return 0

    tmp = src + ".1173m.tmp"
    _write(tmp, text)

    try:
        py_compile.compile(tmp, doraise=True)
    except Exception as ex:
        _log(root, "Syntax-Check FEHLER -> Rollback auf Backup.\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        # Rollback = Original belassen, tmp verwerfen
        try:
            os.remove(tmp)
        except Exception:
            pass
        return 1

    # syntax ok -> übernehmen
    _write(src, text)
    try:
        os.remove(tmp)
    except Exception:
        pass
    _log(root, "Patch angewendet, Syntax OK.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
