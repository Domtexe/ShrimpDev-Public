# -*- coding: utf-8 -*-
"""
Runner_1162_DetectRegexScanner
- Rein diagnostisch: scannt modules/module_code_intake.py nach re.*-Aufrufen.
- Nutzt AST, um Call-Nodes re.(search|match|fullmatch|findall|finditer|split|sub|subn|compile)
  zu finden, extrahiert Pattern-String (inkl. String-Konkatenation / f-Strings ohne Variablen),
  versucht re.compile(pattern, flags) und loggt Ergebnis.
- Keine Codeänderung. 0 Risiko.

Log-Format: [R1162] line=<n> op=<op> OK | FAIL error=<msg> pos=<i> snippet=«...»
Zusammenfassung am Ende.
"""
from __future__ import annotations
import ast, io, os, re, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOGF = os.path.join(ROOT, "debug_output.txt")

OPS = {"search","match","fullmatch","findall","finditer","split","sub","subn","compile"}

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1162] {ts} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def _const_str_from(node: ast.AST) -> tuple[bool, str]:
    """
    Versucht, aus einem AST-Knoten einen reinen Stringwert zu gewinnen:
    - Constant(str)
    - JoinedStr ohne Variablen (nur konstante Teile)
    - BinOp(Add) aus Stringkonstanten
    Gibt (ok, value) zurück.
    """
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return True, node.value

    if isinstance(node, ast.JoinedStr):
        parts = []
        for v in node.values:
            if isinstance(v, ast.Constant) and isinstance(v.value, str):
                parts.append(v.value)
            else:
                return False, ""
        return True, "".join(parts)

    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        ok_l, s_l = _const_str_from(node.left)
        ok_r, s_r = _const_str_from(node.right)
        if ok_l and ok_r:
            return True, s_l + s_r
        return False, ""

    return False, ""

def _eval_re_flags(node: ast.AST) -> tuple[bool, int]:
    """
    Ermittelt Flags aus Ausdrücken wie:
      re.I | re.M | re.S
    Nur erlaubte Namen: re.<FLAG>. Kein Eval unsicherer Ausdrücke.
    """
    def extract(n: ast.AST) -> tuple[bool, int]:
        if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id == "re":
            name = n.attr
            if hasattr(re, name):
                val = getattr(re, name)
                if isinstance(val, int):
                    return True, val
        return False, 0

    if isinstance(node, ast.Attribute):
        return extract(node)

    if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.BitOr, ast.BitAnd)):
        ok_l, v_l = _eval_re_flags(node.left)
        ok_r, v_r = _eval_re_flags(node.right)
        if ok_l and ok_r:
            if isinstance(node.op, ast.BitOr):
                return True, v_l | v_r
            else:
                return True, v_l & v_r
        return False, 0

    return False, 0

def main() -> int:
    if not os.path.isfile(MOD):
        log(f"[ERR] Not found: {MOD}")
        return 2

    with io.open(MOD, "r", encoding="utf-8") as f:
        src = f.read()

    try:
        tree = ast.parse(src, filename=MOD)
    except SyntaxError as se:
        log(f"[ERR] Cannot parse module_code_intake.py: {se}")
        return 3

    total = 0
    tested = 0
    ok = 0
    failed = 0
    suspect = 0

    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if isinstance(node.func.value, ast.Name) and node.func.value.id == "re":
                op = node.func.attr
                if op not in OPS:
                    continue
                total += 1
                lineno = getattr(node, "lineno", -1)

                # Muster-Argument
                if not node.args:
                    log(f"line={lineno} op={op} SUSPECT: missing pattern arg")
                    suspect += 1
                    continue

                pat_node = node.args[0]
                ok_pat, pattern = _const_str_from(pat_node)
                flags_val = 0
                if len(node.args) >= 2:
                    ok_flags, flags_val = _eval_re_flags(node.args[1])
                    # auch kwarg 'flags=' zulassen
                for kw in node.keywords or []:
                    if kw.arg == "flags":
                        ok_kf, kf_val = _eval_re_flags(kw.value)
                        if ok_kf:
                            flags_val |= kf_val

                if not ok_pat:
                    # Kein reines Literal -> potentiell dynamisch/ungeescaped
                    # kurze Vorschau hilft bei der Suche
                    preview = src.splitlines()[lineno-1].strip() if lineno > 0 else "<unknown>"
                    log(f"line={lineno} op={op} SUSPECT non-literal pattern: {preview[:160]}")
                    suspect += 1
                    continue

                # Compile testen
                tested += 1
                try:
                    re.compile(pattern, flags=flags_val)
                    ok += 1
                    log(f"line={lineno} op={op} OK")
                except re.error as ex:
                    failed += 1
                    pos = getattr(ex, "pos", None)
                    snip = ""
                    if pos is not None:
                        s = max(0, pos-25); e = min(len(pattern), pos+25)
                        snip = pattern[s:e]
                    log(f"line={lineno} op={op} FAIL error={ex} pos={pos} snippet=«{snip}»")

    log(f"Summary: calls={total}, tested_literals={tested}, ok={ok}, failed={failed}, suspect_nonliterals={suspect}")
    if failed == 0 and suspect == 0:
        log("All detected regex literals compile. Remaining DetectWarn likely comes from runtime-built patterns; guard with re.escape and try/except.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
