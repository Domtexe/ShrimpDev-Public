import os, sys, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC = os.path.join(ROOT, "modules", "module_gate_panel.py")
LOG = os.path.join(ROOT, "debug_output.txt")

NEW = r'''# -*- coding: utf-8 -*-
from __future__ import annotations
import os, webbrowser, traceback
import tkinter as tk
from tkinter import ttk

DEBUG_LOG = os.path.join(os.path.dirname(os.path.dirname(__file__)), "debug_output.txt")

def _log(msg: str) -> None:
    try:
        from time import strftime
        with open(DEBUG_LOG, "a", encoding="utf-8", newline="\n") as f:
            f.write(f"[GATE] {strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    except Exception:
        pass

def _safe_call(fn, *a, **kw):
    try:
        return fn(*a, **kw)
    except Exception as ex:
        _log("ERR\\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))

def _open_debug_log():
    try:
        if os.path.exists(DEBUG_LOG):
            _log("Open debug_output.txt")
            webbrowser.open("file:///" + DEBUG_LOG.replace("\\\\", "/"))
        else:
            _log("debug_output.txt not found")
    except Exception as ex:
        _log(f"OpenLog ERR: {ex}")

def _refresh_status(var_status: tk.StringVar):
    try:
        var_status.set("Refreshing …")
        var_status.set("OK")
        _log("Status refreshed")
    except Exception as ex:
        var_status.set("Error")
        _log(f"Refresh ERR: {ex}")

def build_gate_panel_tab(nb: ttk.Notebook, root_dir: str | None = None) -> ttk.Frame:
    frm = ttk.Frame(nb)
    row = ttk.Frame(frm)
    row.pack(side="top", anchor="w", padx=8, pady=(8, 4))

    status_var = tk.StringVar(value="Ready")

    ttk.Button(row, text="Refresh Status",
               command=lambda: _safe_call(_refresh_status, status_var)
               ).pack(side="left", padx=(0, 8))

    ttk.Button(row, text="Open debug_output.txt",
               command=_open_debug_log
               ).pack(side="left", padx=(0, 8))

    ttk.Label(row, textvariable=status_var).pack(side="left", padx=(16, 0))

    info = ttk.Frame(frm)
    info.pack(fill="both", expand=True, padx=8, pady=8)
    ttk.Label(info, text="Dev Gates – einfache Status- und Log-Helfer für ShrimpDev.",
              anchor="w", justify="left").pack(anchor="w")
    return frm
'''

def write_log(msg: str):
    try:
        with open(LOG, "a", encoding="utf-8", newline="\n") as f:
            f.write("[R1178m] " + msg + "\n")
    except Exception:
        pass

def main():
    os.makedirs(os.path.dirname(SRC), exist_ok=True)
    with open(SRC, "w", encoding="utf-8", newline="\n") as f:
        f.write(NEW)
    write_log("GatePanel fixed.")
    # Syntaxprobe
    import py_compile
    py_compile.compile(SRC, doraise=True)
    write_log("GatePanel syntax OK.")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit as e:
        raise
    except Exception as ex:
        write_log("ERR\n" + repr(ex))
        raise
