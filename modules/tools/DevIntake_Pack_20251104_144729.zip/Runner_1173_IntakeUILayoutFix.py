# -*- coding: utf-8 -*-
"""
Runner_1173_IntakeUILayoutFix
Ziel (rein Layout, keine Logik!):
- Klare UI-Zonen im Intake: LED -> Toolbar -> Status -> Body
- Buttons über ihrem Zielbereich, keine Überschneidungen
- Status-/Erkennungstext NICHT in Buttons, sondern in dedizierten Labels
- Idempotent, Backup, Syntax-Check, Rollback, Logging

Master-Standards:
- Backups nach _Archiv/
- Pfade relativ (Root = Projekt-Root, wo main_gui.py liegt)
- robust gegen doppelte Ausführung
"""
from __future__ import annotations
import os, re, time, shutil, traceback, py_compile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOGF   = os.path.join(ROOT, "debug_output.txt")

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1173 {ts}] {msg}\n"
    print(line, end="")
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, dst)
    return dst

def syntax_ok(path: str) -> bool:
    try:
        py_compile.compile(path, doraise=True)
        return True
    except Exception as e:
        log("Syntax-Fehler:\n" + "".join(traceback.format_exception_only(type(e), e)))
        return False

def ensure_grid_scaffold(code: str) -> str:
    """
    Erzwingt in _build_ui(self) ein klares Raster und dedizierte Frames:
      row0: (falls vorhanden) bestehende Topinfos
      row1: frm_led (LED/Info-Zeile)
      row2: frm_toolbar (Buttons)
      row3: lbl_status_mid (Status-Text)
      row4: frm_body (Rest/Listen/Editoren)
    Fügt idempotente Marker-Kommentare ein: [1173]
    """
    # Wir arbeiten nur im _build_ui-Body
    m = re.search(r"(\n\s*def\s+_build_ui\s*\(\s*self\s*\)\s*:\s*\n)(?P<body>(?:\s+.+\n)+)", code)
    if not m:
        log("WARN: _build_ui(self) nicht gefunden — keine Änderung.")
        return code
    head, body = m.group(1), m.group("body")

    # 1) grid_columnconfigure 0..3
    if "[1173] grid cfg" not in body:
        ins = (
            "        # [1173] grid cfg\n"
            "        self.grid_columnconfigure(0, weight=1)\n"
            "        self.grid_columnconfigure(1, weight=1)\n"
            "        self.grid_columnconfigure(2, weight=1)\n"
            "        self.grid_columnconfigure(3, weight=1)\n"
        )
        body = head + ins + body[len(head):] if body.startswith(head) else ins + body

    # 2) Frames/Labels sicherstellen
    want_blocks = []

    if "self.frm_led" not in body:
        want_blocks.append(
            "        # [1173] LED-Zeile\n"
            "        from tkinter import ttk\n"
            "        self.frm_led = ttk.Frame(self)\n"
            "        self.frm_led.grid(row=1, column=0, columnspan=4, sticky='we', padx=6, pady=(2,2))\n"
        )
    if "self.frm_toolbar" not in body:
        want_blocks.append(
            "        # [1173] Toolbar\n"
            "        from tkinter import ttk\n"
            "        self.frm_toolbar = ttk.Frame(self)\n"
            "        self.frm_toolbar.grid(row=2, column=0, columnspan=4, sticky='we', padx=6, pady=(2,2))\n"
        )
    if "self.lbl_status_mid" not in body:
        want_blocks.append(
            "        # [1173] Statuszeile (unter Toolbar)\n"
            "        from tkinter import ttk\n"
            "        self.lbl_status_mid = ttk.Label(self, text='', anchor='w')\n"
            "        self.lbl_status_mid.grid(row=3, column=0, columnspan=4, sticky='we', padx=6, pady=(0,6))\n"
        )
    if "self.frm_body" not in body:
        want_blocks.append(
            "        # [1173] Body-Container\n"
            "        from tkinter import ttk\n"
            "        self.frm_body = ttk.Frame(self)\n"
            "        self.frm_body.grid(row=4, column=0, columnspan=4, sticky='nsew', padx=6, pady=(0,6))\n"
            "        self.grid_rowconfigure(4, weight=1)\n"
        )

    if want_blocks:
        # Direkt nach Funktionskopf einfügen
        body = re.sub(r"(^\s*def\s+_build_ui\s*\(\s*self\s*\)\s*:\s*\n)", r"\1" + "".join(want_blocks), code, count=1, flags=re.M)
        # body wurde im Gesamtcode ersetzt → kompletten code updaten:
        return body

    # Wenn keine Blöcke nötig waren, geben wir den Originalcode zurück
    return code

def reparent_buttons_to_toolbar(code: str) -> str:
    """
    Hängt bekannte Buttons an self.frm_toolbar, idempotent.
    """
    if "self.frm_toolbar" not in code:
        return code
    names = [
        "btn_guard","btn_pack","btn_refresh","btn_repair","btn_run","btn_save",
        "btn_open","btn_clear","btn_detect"
    ]
    for n in names:
        # parent-Argument auf self.frm_toolbar setzen (nur wenn noch nicht so)
        code = re.sub(
            rf"(self\.{n}\s*=\s*ttk\.Button\()\s*self\s*(,)",
            rf"\1self.frm_toolbar\2",
            code
        )
    return code

def move_detection_status_to_label(code: str) -> str:
    """
    Entfernt Status-/Erkennungstext aus Buttons (lassen Funktions-Buttons unverändert),
    und lenkt Statusausgaben auf lbl_status_mid (nur Kommentar-Hinweis + Label sicherstellen).
    (Konservativ: wir ändern keine Button-Texte; wir stellen nur sicher, dass lbl_status_mid existiert.)
    """
    # Bereits in ensure_grid_scaffold angelegt
    # Hier nur ein kleiner Hinweis-Kommentar in Nähe typischer Status-Updates
    code = re.sub(
        r"(#\s*Status:.*\n)",
        r"\1        # [1173] Hinweis: Status bitte in self.lbl_status_mid.config(text=...) schreiben.\n",
        code
    )
    return code

def ensure_body_children_parent(code: str) -> str:
    """
    Konservativ: Pane/Editor/Tree in frm_body reparenten, falls direkt an self erstellt.
    Gängige Namen: tv, tree, editor, txt, paned, body_frame
    """
    if "self.frm_body" not in code:
        return code
    targets = ["ttk\\.Treeview", "ttk\\.Panedwindow", "ttk\\.Notebook", "ttk\\.Frame", "tk\\.Text", "ttk\\.Scrollbar"]
    for cls in targets:
        code = re.sub(
            rf"(=\s*{cls}\()\s*self\s*(,)",
            rf"=\ \g<1>self.frm_body\2",
            code
        )
    return code

def patch(code: str) -> str:
    before = code
    code = ensure_grid_scaffold(code)
    code = reparent_buttons_to_toolbar(code)
    code = move_detection_status_to_label(code)
    code = ensure_body_children_parent(code)
    return code if code != before else before

def main() -> int:
    if not os.path.exists(TARGET):
        log(f"Zieldatei nicht gefunden: {TARGET}")
        return 2

    bak = backup(TARGET)
    log(f"Backup erstellt: {bak}")

    with open(TARGET, "r", encoding="utf-8") as f:
        src = f.read()

    new_src = patch(src)

    if new_src == src:
        log("Keine Layout-Änderung erforderlich (idempotent).")
        return 0

    tmp = TARGET + ".1173.tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(new_src)

    if not syntax_ok(tmp):
        log("Rollback: Syntax-Check fehlgeschlagen.")
        os.remove(tmp)
        shutil.copy2(bak, TARGET)
        return 1

    shutil.move(tmp, TARGET)
    if not syntax_ok(TARGET):
        log("Rollback: End-Syntax-Check fehlgeschlagen.")
        shutil.copy2(bak, TARGET)
        return 1

    log("Patch erfolgreich, Syntax OK.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
