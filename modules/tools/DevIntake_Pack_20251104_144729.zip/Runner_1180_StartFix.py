# -*- coding: utf-8 -*-
"""
Erzeugt robuste Starter:
- tools/Start_MainGui.bat
- tools/Start_MainGui_debug.bat
Eigenschaften:
- konsistentes Arbeitsverzeichnis (Projektroot)
- Python-Erkennung (venv bevorzugt, sonst 'py -3')
- -u (unbuffered), Exitcode-Handling, Logging nach debug_output.txt
"""
from __future__ import annotations
import os, textwrap, shutil, sys, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TOOLS = os.path.join(ROOT, "tools")
LOGF = os.path.join(ROOT, "debug_output.txt")

def write(path: str, content: str) -> None:
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(content)

def main() -> int:
    os.makedirs(TOOLS, exist_ok=True)

    # Python-Resolver (Batch nutzt diese Logik)
    starter = r"""@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
cd ..
set "ROOT=%CD%"
set "LOG=%ROOT%\debug_output.txt"

rem --- Python ermitteln ---
set "PY_EXE="
if exist "%ROOT%\venv\Scripts\python.exe" set "PY_EXE=%ROOT%\venv\Scripts\python.exe"
if not defined PY_EXE set "PY_EXE=py"

rem --- Flags ---
set "PY_FLAGS=-u"
rem Wenn 'py' genutzt wird, nimm explizit 3 + unbuffered
for %%I in ("%PY_EXE%") do (
  if /I "%%~nxI"=="py.exe" set "PY_FLAGS=-3 -u"
  if /I "%%~nxI"=="py"     set "PY_FLAGS=-3 -u"
)

echo [Start] Using: "%PY_EXE%" %PY_FLAGS% main_gui.py
pushd "%ROOT%"
"%PY_EXE%" %PY_FLAGS% "main_gui.py"
set RC=%ERRORLEVEL%
if %RC% NEQ 0 (
  echo [Start] main_gui.py failed (rc=%RC%)
  >nul 2>&1 (
    echo [%%date%% %%time%%] [Start_MainGui] rc=%RC% >> "%LOG%"
  )
)
popd
exit /b %RC%
"""
    debug_starter = starter + "\r\n" + "echo.\r\npause\r\n"

    write(os.path.join(TOOLS, "Start_MainGui.bat"), starter)
    write(os.path.join(TOOLS, "Start_MainGui_debug.bat"), debug_starter)

    # kleines Log
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] [1180] Safe starters written.\n")
    except Exception:
        pass

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
