from __future__ import annotations
from pathlib import Path
import re, time, shutil

ROOT = Path(r"D:\ShrimpDev")
MOD  = ROOT/"modules"/"module_code_intake.py"

def ts(): return time.strftime("%Y%m%d_%H%M%S")
def backup(p: Path):
    if p.exists():
        b = p.with_suffix(p.suffix + f".{ts()}.bak")
        shutil.copy2(p, b)
        print(f"[R948] Backup: {b.name}")

PATCH = r'''
# === R948 Intake UX: Buttons + robuste Save-Pipeline ===
import re, json, time
from pathlib import Path
from tkinter import ttk, messagebox

def _intake_sanitize(name: str) -> str:
    name = name.strip().replace("\\", "/")
    name = re.sub(r'[^A-Za-z0-9_\-./]', "_", name)
    name = re.sub(r'/+', "/", name).lstrip("./")
    if ".." in name or name.startswith(("/", "~")):
        return ""
    return name

def _intake_suggest_name(code: str, target_dir: Path, ext_hint: str|None) -> str:
    # Wenn bereits Marker vorhanden, nichts tun – _extract liefert Name
    n, e = _extract(code)
    if n:
        return n
    # Heuristik: Runner/Module
    base = "snippet_" + time.strftime("%Y%m%d_%H%M%S")
    ext = (ext_hint or _guess_ext_from_content(code) or ".py").lower()
    td  = str(target_dir).replace("\\", "/").lower()
    if "tools" in td and ext in {".py",".bat",".cmd",".vbs"}:
        # Runner-Nummer aus Code? falls vorhanden
        m = re.search(r'Runner[_\s\-]*(\d{3,5})', code, re.I)
        if m: return f"Runner_{m.group(1)}{ext}"
        return f"Runner_{time.strftime('%H%M%S')}{ext}"
    if "modules/snippets" in td and ext==".py":
        return f"{base}.py"
    if "modules" in td and ext==".py":
        # Funktions-Name als Hinweis
        m = re.search(r'\bdef\s+([A-Za-z_]\w*)\s*\(', code)
        if m: return f"module_{m.group(1)}.py"
        return f"module_new.py"
    if ext in {".md",".json",".txt"}:
        return f"{base}{ext}"
    return f"{base}{ext}"

def _insert_marker(text_widget, target_dir: Path, name: str, ext: str):
    # Fügt oben eine # file:-Zeile ein (Batch: REM FILE)
    hdr = f"# file: {str(target_dir).replace('\\','/')}/{name}\n" if ext != ".bat" and ext != ".cmd" else f"REM FILE {str(target_dir)}\\{name}\n"
    try:
        text_widget.insert("1.0", hdr)
    except Exception:
        pass

# --- Patch IntakeWindow: Buttons + Save-Härtung ---
_old_IntakeWindow___init__ = getattr(IntakeWindow, "__init__", None)
def _patched_IntakeWindow___init__(self, app):
    _old_IntakeWindow___init__(self, app)  # ruft Originalaufbau
    # Button-Leiste ergänzen
    try:
        # Oberste drei Eingabefelder existieren bereits:
        # self.var_name, self.var_ext, self.var_target
        bar2 = ttk.Frame(self); bar2.pack(fill="x", pady=4)
        ttk.Button(bar2, text="Name vorschlagen", command=lambda: _on_suggest(self)).pack(side="left")
        ttk.Button(bar2, text="Marker einfügen",  command=lambda: _on_insert_marker(self)).pack(side="left", padx=6)
        # History-Anzeige (letzte 5 Saves)
        self._history = []
        self._hist_var = tk.StringVar(value="")
        ttk.Label(self, textvariable=self._hist_var, foreground="#555").pack(anchor="w", padx=6)
    except Exception:
        pass

def _on_suggest(self):
    try:
        code = self.txt.get("1.0","end-1c")
        nm, ex = self.var_name.get().strip(), self.var_ext.get().strip().lower()
        target = Path(self.var_target.get().strip() or str(self.workspace))
        if not ex:
            _, ex = _extract(code)
        name = _intake_suggest_name(code, target, ex or None)
        if name:
            self.var_name.set(name)
            if not self.var_ext.get().strip():
                self.var_ext.set(Path(name).suffix.lower())
            if not self.var_target.get().strip():
                self.var_target.set(str(_map_target(self.workspace, name, self.var_ext.get().strip().lower())))
            self.status.set(f"Vorschlag: {name}")
    except Exception:
        pass

def _on_insert_marker(self):
    try:
        nm = self.var_name.get().strip()
        ex = (self.var_ext.get().strip().lower() or (Path(nm).suffix.lower() if nm else ".py"))
        target = Path(self.var_target.get().strip() or str(self.workspace))
        if not nm:
            _on_suggest(self)
            nm = self.var_name.get().strip()
            ex = (self.var_ext.get().strip().lower() or (Path(nm).suffix.lower() if nm else ".py"))
        _insert_marker(self.txt, target, nm, ex)
        self.status.set("Marker eingefügt.")
    except Exception:
        pass

# Save-Pipeline härten (Backups rotierend + History)
_old_save = getattr(IntakeWindow, "_save", None)
def _patched_save(self):
    nm, ex, target = self.var_name.get().strip(), self.var_ext.get().strip().lower(), self.var_target.get().strip()
    code = self.txt.get("1.0", "end-1c")

    # 1) Sanitize/Validate
    nm = _intake_sanitize(nm)
    if not nm:
        messagebox.showwarning("ShrimpDev", "Ungültiger Dateiname."); return
    if not ex:
        _, ex = _extract(code)
        ex = ex or ".py"
        self.var_ext.set(ex)
    if not target:
        target = str(_map_target(self.workspace, nm, ex))
        self.var_target.set(target)

    out_dir = Path(target).resolve(); out_dir.mkdir(parents=True, exist_ok=True)
    out = (out_dir / nm).resolve()

    # 2) Rotierende Backups (.1.bak … .4.bak)
    try:
        if out.exists():
            for i in range(4, 0, -1):
                pi = out.with_name(out.name + f".{i}.bak")
                pj = out.with_name(out.name + f".{i+1}.bak")
                if pi.exists():
                    try: pi.replace(pj)
                    except Exception: pass
            bak0 = out.with_name(out.name + ".bak")
            bak1 = out.with_name(out.name + ".1.bak")
            try:
                if bak0.exists(): bak0.replace(bak1)
            except Exception:
                pass
    except Exception:
        pass

    # 3) Schreiben
    try:
        out.write_text(code, encoding="utf-8")
        try:
            from modules.snippets.agent_client import send_event
            send_event({"runner":"CodeIntake","level":"OK","msg":f"Saved {out.name}","path":str(out)})
        except Exception:
            pass
        # History
        try:
            self._history = ([str(out)] + self._history)[:5]
            self._hist_var.set("Zuletzt: " + "  •  ".join(Path(p).name for p in self._history))
        except Exception:
            pass
        if not getattr(self, "quiet", False):
            messagebox.showinfo("ShrimpDev", f"Gespeichert:\n{out}")
        self.status.set(f"Gespeichert: {out}")
    except Exception as ex:
        try:
            from modules.snippets.agent_client import send_event
            send_event({"runner":"CodeIntake","level":"ERROR","msg":f"Save error {out}: {ex}"})
        except Exception:
            pass
        try: messagebox.showerror("ShrimpDev", f"Fehler beim Speichern:\n{ex}")
        except Exception: pass

# Monkey-Patch anwenden
try:
    IntakeWindow.__init__ = _patched_IntakeWindow___init__
    IntakeWindow._save     = _patched_save
except Exception:
    pass
'''

def main():
    if not MOD.exists():
        print(f"[R948] FEHLT: {MOD}"); return 2
    backup(MOD)
    txt = MOD.read_text(encoding="utf-8", errors="ignore")
    if "R948 Intake UX" not in txt:
        txt += "\n" + PATCH + "\n"
        MOD.write_text(txt, encoding="utf-8")
        print("[R948] Intake UX ergänzt (Buttons + Save-Härtung).")
    else:
        print("[R948] Bereits gepatcht.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
