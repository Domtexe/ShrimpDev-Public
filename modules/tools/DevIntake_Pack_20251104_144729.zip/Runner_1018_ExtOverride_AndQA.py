"""
Runner_1018_ExtOverride_AndQA
- Macht Endung im Intake editierbar + Override-Logik
- "Erkennen" überschreibt manuelle Endung nicht
- "Speichern" erzwingt Endung konsistent am Dateinamen
- "Löschen" robust (kein Crash ohne Auswahl)
- QA: statische Prüfungen auf Methoden/Bindungen
- Version -> v9.9.9
"""
from __future__ import annotations
import os, re, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1018] {ts} {msg}\n")
    print(msg, flush=True)

def backup_write(path: str, data: str):
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    log(f"Backup: {path} -> {bck}")
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

def patch():
    with open(MOD, "r", encoding="utf-8") as f:
        src = f.read()

    # 1) Endung editierbar machen (state="readonly" entfernen)
    src2 = re.sub(r'state\s*=\s*"readonly"\s*,?\s*', "", src)

    # 2) Override-Flag & Bindings einbauen
    if "self.var_ext_manual" not in src2:
        src2 = src2.replace(
            "self.var_ext = tk.StringVar(value=\"\")",
            "self.var_ext = tk.StringVar(value=\"\")\n        self.var_ext_manual = False"
        )
    # Entnahme der Entry-Variable
    # füge KeyRelease/FocusOut Bindings und Normalizer hinzu
    if "def _on_ext_changed(" not in src2:
        src2 = src2.replace(
            "ent_ext = ttk.Entry(head, textvariable=self.var_ext, width=7)",
            "ent_ext = ttk.Entry(head, textvariable=self.var_ext, width=7)\n"
            "        ent_ext.bind(\"<KeyRelease>\", self._on_ext_changed)\n"
            "        ent_ext.bind(\"<FocusOut>\", self._normalize_ext)"
        )
        # Methoden hinzufügen (nach _update_led)
        src2 = src2.replace(
            "def _update_led(self, canvas: tk.Canvas, color: str):",
            "def _update_led(self, canvas: tk.Canvas, color: str):"
        )
        # vor erster Action-Methode einen Block einfügen
        ins_point = src2.find("\n    # ---------- actions ----------")
        if ins_point != -1:
            extra = r'''
    # --- ext override helpers ---
    def _on_ext_changed(self, _evt=None):
        """Merkt, dass der Nutzer die Endung manuell editiert hat."""
        self.var_ext_manual = True

    def _normalize_ext(self, _evt=None):
        """Normalisiert Endung: führenden Punkt ergänzen; Kleinbuchstaben."""
        ext = (self.var_ext.get() or "").strip()
        if ext and not ext.startswith("."):
            ext = "." + ext
        self.var_ext.set(ext.lower())
'''
            src2 = src2[:ins_point] + extra + src2[ins_point:]

    # 3) Detect: respektiert manuelle Endung
    src2 = re.sub(
        r"def _detect\([\s\S]+?self\.var_ext\.set\([^\)]*\)\n",
        lambda m: re.sub(
            r"self\.var_ext\.set\([^\)]*\)\n",
            "        if not self.var_ext_manual:\n"
            "            self.var_ext.set(ext.lower())\n",
            m.group(0)
        ),
        src2,
        count=1
    )

    # 4) Save: erzwingt Endung konsistent am Namen
    if "_apply_ext_to_name" not in src2:
        hook = "def _save(self):"
        idx = src2.find(hook)
        if idx != -1:
            # Hilfsfunktion vor _save einfügen
            helper = r'''
    def _apply_ext_to_name(self, name: str, ext: str) -> str:
        """Erzwingt, dass name mit ext endet (ext inkl. führendem Punkt)."""
        ext = (ext or "").strip().lower()
        if ext and not ext.startswith("."):
            ext = "." + ext
        base, cur = os.path.splitext(name)
        if not ext:
            # falls keine Ext definiert, bestehende beibehalten oder .txt
            return name if cur else (name + ".txt")
        if cur.lower() == ext:
            return name  # bereits korrekt
        return (base or name) + ext
'''
            src2 = src2[:idx] + helper + src2[idx:]

    src2 = re.sub(
        r"def _save\([\s\S]+?target_path = [^\n]+\n",
        lambda m: re.sub(
            r"target_path = [^\n]+\n",
            "        name = self._apply_ext_to_name(name, self.var_ext.get())\n"
            "        target_path = os.path.join(tgt_dir, name)\n",
            m.group(0)
        ),
        src2,
        count=1
    )

    # 5) Löschen: ohne Auswahl kein Fehler
    src2 = src2.replace(
        "sel = self.tbl.selection()\n        if not sel: return",
        "sel = self.tbl.selection()\n        if not sel:\n            try: self.bell()\n            except Exception: pass\n            return"
    )

    if src2 != src:
        backup_write(MOD, src2)
        log("module_code_intake.py gepatcht: Ext-Override + Buttons-Verhalten.")
        return True
    else:
        log("module_code_intake.py bereits aktuell.")
        return True

def qa():
    """Statische Mini-QA: prüft, ob Methoden/Bindungen vorhanden sind."""
    with open(MOD, "r", encoding="utf-8") as f:
        s = f.read()

    checks = {
        "Ext editierbar": ("state=\"readonly\"" not in s),
        "_on_ext_changed vorhanden": ("def _on_ext_changed" in s),
        "_normalize_ext vorhanden": ("def _normalize_ext" in s),
        "_apply_ext_to_name vorhanden": ("def _apply_ext_to_name" in s),
        "Detect respektiert Override": ("if not self.var_ext_manual" in s),
        "Save nutzt apply_ext": ("_apply_ext_to_name(name" in s),
        "Buttons vorhanden": (
            "Erkennen (Ctrl+I)" in s and "Speichern (Ctrl+S)" in s and "Löschen (Entf)" in s
        ),
        "Kontext Name kopieren": ("Name kopieren" in s),
    }
    ok = True
    for k, v in checks.items():
        line = f"[QA] {k}: {'OK' if v else 'FEHLT'}"
        log(line)
        ok = ok and v
    return ok

def main():
    try:
        if not os.path.exists(MOD):
            log(f"FEHLT: {MOD}")
            return 1
        if not patch():
            return 1
        qa_ok = qa()
        # Meta
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.9\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.9 (2025-10-18)
- Intake: Endung editierbar (Override), Detect überschreibt manuelle Eingabe nicht
- Save: setzt/ersetzt Endung konsistent; Delete ohne Auswahl bleibt folgenlos
- QA: Statische Checks für Verkabelung
""")
        log("Patch + QA abgeschlossen.")
        return 0 if qa_ok else 1
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
