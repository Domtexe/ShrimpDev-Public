# -*- coding: utf-8 -*-
import sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"

PAYLOAD = r'''# -*- coding: utf-8 -*-
"""
ShrimpDev Dev-Intake – R1194
- Klare Anordnung: Header, LED-Bar (mit Labels), linke Toolbar (Intake/Editor), rechte Toolbar (Dateiliste)
- Kein Filter
- Robuste Erkennung (.py/.bat) + Runner-Name
- Syntaxcheck mit Fehler-Markierung
- Ausschließlich grid(); UTF-8; keine stillen Fehler
"""
from __future__ import annotations
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import time, re, traceback, zipfile, subprocess

ROOT = Path(__file__).resolve().parents[1]

def _log(tag, msg):
    try:
        with (ROOT/"debug_output.txt").open("a", encoding="utf-8", newline="\n") as f:
            ts=time.strftime("%Y-%m-%d %H:%M:%S")
            f.write(f"[DevIntake] {ts} [{tag}] {msg}\n")
    except Exception:
        pass

def _detect_ext(text: str) -> str:
    t = (text or "").lstrip()
    tl = t.lower()
    if tl.startswith("@echo off") or any(m in tl for m in ("\nrem ","\r\nrem ","\n::","\r\n::"," goto "," set ")):
        return ".bat"
    if any(k in t for k in ("import ","from ","def ","class ","print(","__name__")):
        return ".py"
    return ".txt"

class LED(ttk.Frame):
    def __init__(self, master, text, *, width=14, tip=""):
        super().__init__(master)
        self._tip = tip
        self._tw = None
        self.txt = ttk.Label(self, text=text)
        self.txt.grid(row=0,column=1, padx=(4,0))
        bg = self._bg(master)
        self.c = tk.Canvas(self, width=width, height=width, highlightthickness=0, bg=bg)
        self.c.grid(row=0,column=0)
        self.o = self.c.create_oval(2,2,width-2,width-2, fill="#9e9e9e", outline="#555")
        for w in (self.c,self.txt):
            w.bind("<Enter>", self._show); w.bind("<Leave>", self._hide)

    @staticmethod
    def _bg(w):
        try: return w.cget("background")
        except: return "#f0f0f0"

    def set(self, ok, tip=None):
        color = "#4caf50" if ok is True else ("#e53935" if ok is False else str(ok))
        self.c.itemconfig(self.o, fill=color)
        if tip is not None: self._tip = tip

    def _show(self, *_):
        if not self._tip or self._tw: return
        x = self.winfo_rootx()+16
        y = self.winfo_rooty()+self.winfo_height()+6
        self._tw = tw = tk.Toplevel(self)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        tk.Label(tw, text=self._tip, bg="#ffffe0", relief="solid", bd=1).pack(ipadx=3, ipady=1)

    def _hide(self, *_):
        if self._tw: self._tw.destroy(); self._tw = None

class DevIntake(ttk.Frame):
    def __init__(self, nb: ttk.Notebook):
        super().__init__(nb)
        self.current: Path|None = None
        self.dirty      = False
        self.syntax_ok  = True

        self.var_ws   = tk.StringVar(value=str(ROOT))
        self.var_tgt  = tk.StringVar(value=str(ROOT/"tools"))
        self.var_ext  = tk.StringVar(value=".py")
        self.var_name = tk.StringVar(value=f"snippet_{time.strftime('%Y%m%d_%H%M%S')}")

        self._build_ui()
        self._refresh()

    # ---------- UI ----------
    def _build_ui(self):
        PADX,PADY=8,6

        # Header: Pfade/Name/Ext
        hdr=ttk.Frame(self); hdr.grid(row=0,column=0,columnspan=2,sticky="we",padx=PADX,pady=(PADY,4))
        ttk.Label(hdr,text="Workspace:").grid(row=0,column=0,sticky="e")
        ttk.Entry(hdr,textvariable=self.var_ws).grid(row=0,column=1,sticky="we",padx=(4,4))
        ttk.Button(hdr,text="…",width=3,command=self._pick_ws).grid(row=0,column=2,padx=(0,12))

        ttk.Label(hdr,text="Name:").grid(row=0,column=3,sticky="e")
        ttk.Entry(hdr,textvariable=self.var_name,width=28).grid(row=0,column=4,sticky="we",padx=(4,12))

        ttk.Label(hdr,text="Endung:").grid(row=0,column=5,sticky="e")
        ttk.Combobox(hdr,textvariable=self.var_ext,values=[".py",".bat",".txt"],width=6,state="readonly").grid(row=0,column=6,sticky="w",padx=(4,12))

        ttk.Label(hdr,text="Zielordner:").grid(row=0,column=7,sticky="e")
        ttk.Entry(hdr,textvariable=self.var_tgt).grid(row=0,column=8,sticky="we",padx=(4,4))
        ttk.Button(hdr,text="…",width=3,command=self._pick_tgt).grid(row=0,column=9)
        hdr.columnconfigure(1,weight=1); hdr.columnconfigure(4,weight=1); hdr.columnconfigure(8,weight=1)

        # LED-Bar (mit Beschriftung)
        ledbar=ttk.Frame(self); ledbar.grid(row=1,column=0,columnspan=2,sticky="we",padx=PADX,pady=(0,4))
        self.led_dirty=LED(ledbar,"Geändert");         self.led_dirty.grid(row=0,column=0,padx=6)
        self.led_syn  =LED(ledbar,"Syntax");           self.led_syn.grid(row=0,column=1,padx=6)
        self.led_name =LED(ledbar,"Name");             self.led_name.grid(row=0,column=2,padx=6)
        self.led_ext  =LED(ledbar,"Endung");           self.led_ext.grid(row=0,column=3,padx=6)
        self.led_ok   =LED(ledbar,"Gesamt-OK");        self.led_ok.grid(row=0,column=4,padx=6)

        # Main-Split: links Editor, rechts Liste
        split=ttk.Panedwindow(self,orient="horizontal"); split.grid(row=3,column=0,columnspan=2,sticky="nsew",padx=PADX,pady=(0,PADY))

        left=ttk.Frame(split); right=ttk.Frame(split)
        split.add(left,weight=60); split.add(right,weight=40)

        # Linke Toolbar (für Intake/Editor)
        lt=ttk.Frame(left); lt.grid(row=0,column=0,sticky="we",pady=(0,4))
        ttk.Button(lt,text="Neu",width=11,command=self._new).grid(row=0,column=0,padx=2,pady=4)
        ttk.Button(lt,text="Einfügen",width=11,command=self._insert).grid(row=0,column=1,padx=2)
        ttk.Button(lt,text="Speichern",width=11,command=self._save).grid(row=0,column=2,padx=2)
        ttk.Button(lt,text="Speichern als…",width=14,command=self._save_as).grid(row=0,column=3,padx=6)
        ttk.Button(lt,text="Erkennen (Strg+I)",width=18,command=self._detect).grid(row=1,column=0,padx=2,pady=2,sticky="w")
        ttk.Button(lt,text="Guard",width=11,command=self._guard).grid(row=1,column=1,padx=2,pady=2)
        ttk.Button(lt,text="Repair",width=11,command=self._repair).grid(row=1,column=2,padx=2,pady=2)
        ttk.Button(lt,text="Run (F5)",width=11,command=self._run).grid(row=1,column=3,padx=6,pady=2,sticky="e")
        lt.columnconfigure(0,weight=1); lt.columnconfigure(3,weight=1)

        # Editor
        self.editor=tk.Text(left,wrap="none",undo=True)
        self.editor.grid(row=1,column=0,sticky="nsew")
        ysb=ttk.Scrollbar(left,orient="vertical",command=self.editor.yview); ysb.grid(row=1,column=1,sticky="ns")
        xsb=ttk.Scrollbar(left,orient="horizontal",command=self.editor.xview); xsb.grid(row=2,column=0,sticky="we")
        self.editor.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
        left.rowconfigure(1,weight=1); left.columnconfigure(0,weight=1)
        self.editor.bind("<<Modified>>",self._on_mod)

        # Rechte Toolbar (für Dateiliste)
        rt=ttk.Frame(right); rt.grid(row=0,column=0,sticky="we",pady=(0,4))
        ttk.Button(rt,text="Aktualisieren",width=14,command=self._refresh).grid(row=0,column=0,padx=2,pady=4,sticky="w")
        ttk.Button(rt,text="Ordner öffnen",width=14,command=self._open_target).grid(row=0,column=1,padx=2)
        ttk.Button(rt,text="Pack speichern",width=14,command=self._pack).grid(row=0,column=2,padx=2)
        ttk.Button(rt,text="Löschen",width=12,command=self._delete).grid(row=0,column=3,padx=2,sticky="e")
        rt.columnconfigure(0,weight=1); rt.columnconfigure(3,weight=1)

        # Dateiliste
        cols=("name","ext","subfolder","date","time")
        self.tree=ttk.Treeview(right,columns=cols,show="headings",selectmode="browse")
        for c,w in zip(cols,(280,70,180,110,90)):
            self.tree.heading(c,text=c)
            self.tree.column(c,width=w,anchor="w")
        self.tree.grid(row=1,column=0,sticky="nsew")
        scry=ttk.Scrollbar(right,orient="vertical",command=self.tree.yview); scry.grid(row=1,column=1,sticky="ns")
        self.tree.configure(yscrollcommand=scry.set)
        right.rowconfigure(1,weight=1); right.columnconfigure(0,weight=1)
        self.tree.bind("<<TreeviewSelect>>",self._on_select)
        self.tree.bind("<Double-1>",lambda e:self._on_select())

        # Statuszeile
        self.var_stat=tk.StringVar(value="Bereit.")
        ttk.Label(self,textvariable=self.var_stat,anchor="w").grid(row=4,column=0,columnspan=2,sticky="we",padx=PADX)

        self.grid_rowconfigure(3,weight=1); self.grid_columnconfigure(0,weight=1); self.grid_columnconfigure(1,weight=1)
        self.bind_all("<Control-s>",lambda e:self._save())
        self.bind_all("<Control-i>",lambda e:self._detect())
        self.bind_all("<F5>",       lambda e:self._run())
        self._update_leds()

    # ---------- helpers ----------
    def _pick_ws(self):
        d=filedialog.askdirectory(title="Workspace wählen",initialdir=self.var_ws.get())
        if d: self.var_ws.set(d)

    def _pick_tgt(self):
        d=filedialog.askdirectory(title="Zielordner wählen",initialdir=self.var_tgt.get())
        if d: self.var_tgt.set(d); self._refresh()

    def _path(self)->Path:
        tgt=Path(self.var_tgt.get() or (ROOT/"tools"))
        tgt.mkdir(parents=True,exist_ok=True)
        return tgt / f"{(self.var_name.get() or 'snippet')}{(self.var_ext.get() or '.py')}"

    def _on_mod(self,_=None):
        if self.editor.edit_modified():
            self.dirty=True
            self.editor.edit_modified(False)
            self._update_leds()

    def _hilite_err(self,line:int|None):
        try: self.editor.tag_delete("errline")
        except: pass
        if not line: return
        self.editor.tag_configure("errline",background="#ffd6d6")
        self.editor.tag_add("errline",f"{line}.0",f"{line}.0 lineend")
        self.editor.see(f"{line}.0")

    # ---------- actions ----------
    def _new(self):
        self.editor.delete("1.0","end")
        self.var_name.set(f"snippet_{time.strftime('%Y%m%d_%H%M%S')}")
        self.dirty=False; self.syntax_ok=True; self._update_leds()
        self.var_stat.set("Editor geleert.")

    def _detect(self):
        src=self.editor.get("1.0","end-1c")
        if not src.strip():
            self.var_stat.set("Nichts zu erkennen."); return
        ext=_detect_ext(src)
        name=None
        for line in src.splitlines():
            s=line.strip()
            if not s or s.startswith("#") or s.lower().startswith(("rem","::")): continue
            m=re.search(r"(Runner_[0-9]{3,5}_[A-Za-z0-9_]+)", s)
            if m: name=m.group(1); break
        if not name: name=f"snippet_{time.strftime('%Y%m%d_%H%M%S')}"
        self.syntax_ok=True
        if ext==".py":
            try:
                compile(src,"<intake>","exec")
            except Exception as e:
                self.syntax_ok=False
                self._hilite_err(getattr(e,"lineno",None))
        self.var_ext.set(ext)
        self.var_name.set(name)
        self._update_leds()
        self.var_stat.set(f"Erkannt: {name}{ext}")

    def _insert(self):
        p=self._path()
        if p.exists() and not messagebox.askyesno("Überschreiben?", f"{p.name} existiert. Überschreiben?"): return
        try:
            p.write_text(self.editor.get("1.0","end-1c"),encoding="utf-8",newline="\n")
            self.current=p; self.dirty=False; self._refresh(select=p); self._update_leds()
            self.var_stat.set(f"Eingefügt: {p.name}")
        except Exception as e:
            messagebox.showerror("Einfügen", str(e)); _log("INSERT_FAIL", str(e))

    def _save(self):
        if self.current is None: self._insert(); return
        try:
            self.current.write_text(self.editor.get("1.0","end-1c"),encoding="utf-8",newline="\n")
            self.dirty=False; self._refresh(select=self.current); self._update_leds()
            self.var_stat.set(f"Gespeichert: {self.current.name}")
        except Exception as e:
            messagebox.showerror("Speichern", str(e)); _log("SAVE_FAIL", str(e))

    def _save_as(self):
        p=self._path()
        try:
            p.write_text(self.editor.get("1.0","end-1c"),encoding="utf-8",newline="\n")
            self.current=p; self.dirty=False; self._refresh(select=p); self._update_leds()
            self.var_stat.set(f"Gespeichert als: {p.name}")
        except Exception as e:
            messagebox.showerror("Speichern als", str(e)); _log("SAVEAS_FAIL", str(e))

    def _refresh(self, select:Path|None=None):
        self.tree.delete(*self.tree.get_children())
        root=Path(self.var_tgt.get() or (ROOT/"tools")); root.mkdir(parents=True,exist_ok=True)
        items=[]
        for p in root.rglob("*"):
            if not p.is_file(): continue
            sub=str(p.parent.relative_to(root)) if p.parent!=root else ""
            dt=time.localtime(p.stat().st_mtime)
            date=time.strftime("%Y-%m-%d",dt); tm=time.strftime("%H:%M:%S",dt)
            items.append((p, p.stem, p.suffix, sub, date, tm))
        items.sort(key=lambda t: (t[2], t[1]))  # erst nach Endung, dann Name
        for (p,stem,ext,sub,date,tm) in items:
            self.tree.insert("", "end", iid=str(p), values=(stem,ext,sub,date,tm))
        if select and self.tree.exists(str(select)): self.tree.selection_set(str(select))
        self.var_stat.set(f"{len(items)} Datei(en) in {root}")

    def _on_select(self,_=None):
        sel=self.tree.selection()
        if not sel: return
        p=Path(sel[0])
        try:
            txt=p.read_text(encoding="utf-8",errors="replace")
            self.editor.delete("1.0","end"); self.editor.insert("1.0",txt)
            self.current=p; self.var_name.set(p.stem); self.var_ext.set(p.suffix or ".txt"); self.var_tgt.set(str(p.parent))
            self.dirty=False; self.syntax_ok=True; self._update_leds()
            self.var_stat.set(f"Geladen: {p}")
        except Exception as e:
            messagebox.showerror("Laden", str(e)); _log("LOAD_FAIL", str(e))

    def _open_target(self):
        try:
            subprocess.Popen(["explorer", str(Path(self.var_tgt.get()))])
        except Exception as e:
            messagebox.showerror("Explorer", str(e))

    def _pack(self):
        try:
            tgt=Path(self.var_tgt.get() or (ROOT/"tools"))
            z= tgt / f"DevIntake_Pack_{time.strftime('%Y%m%d_%H%M%S')}.zip"
            with zipfile.ZipFile(z,"w",zipfile.ZIP_STORED) as zp:
                for p in tgt.rglob("*"):
                    if p.is_file(): zp.write(p, p.relative_to(tgt))
            messagebox.showinfo("Pack", f"Pack gespeichert:\n{z}")
        except Exception as e:
            messagebox.showerror("Pack", str(e)); _log("PACK_FAIL", str(e))

    def _delete(self):
        if not self.current or not self.current.exists():
            messagebox.showinfo("Löschen","Keine Datei ausgewählt."); return
        if not messagebox.askyesno("Löschen", f"{self.current.name} wirklich löschen?"): return
        try:
            self.current.unlink()
            self.current=None; self.editor.delete("1.0","end")
            self._refresh(); self.dirty=False; self._update_leds()
            self.var_stat.set("Datei gelöscht.")
        except Exception as e:
            messagebox.showerror("Löschen", str(e)); _log("DELETE_FAIL", str(e))

    def _guard(self):
        p=self.current
        if not p or p.suffix!=".py":
            messagebox.showinfo("Guard","Guard prüft nur .py"); return
        src=self.editor.get("1.0","end-1c")
        try:
            compile(src, p.name, "exec")
            self.syntax_ok=True; self._hilite_err(None)
            messagebox.showinfo("Guard","Syntax OK.")
        except SyntaxError as e:
            self.syntax_ok=False; self._hilite_err(getattr(e,"lineno",None))
            messagebox.showerror("Guard", f"Syntaxfehler in Zeile {getattr(e,'lineno','?')}\n{e.msg}")
        except Exception as e:
            self.syntax_ok=False; messagebox.showerror("Guard", str(e))
        self._update_leds()

    def _repair(self):
        try:
            txt=self.editor.get("1.0","end-1c")
            txt2=txt.replace("\r\r\n","\r\n")
            if txt2!=txt:
                self.editor.delete("1.0","end"); self.editor.insert("1.0",txt2)
            messagebox.showinfo("Repair","Normalisierung angewendet.")
        except Exception as e:
            messagebox.showerror("Repair", str(e))

    def _run(self):
        p=self.current
        if not p or not p.exists():
            messagebox.showinfo("Run","Keine Datei ausgewählt."); return
        try:
            if p.suffix==".py": subprocess.Popen(["py","-3","-u",str(p)])
            elif p.suffix==".bat": subprocess.Popen([str(p)])
            else: messagebox.showinfo("Run","Nur .py/.bat werden ausgeführt.")
        except Exception as e:
            messagebox.showerror("Run", str(e))

    def _update_leds(self):
        name_ok=bool((self.var_name.get() or "").strip())
        ext_ok =bool((self.var_ext.get()  or "").strip())
        all_ok =bool(name_ok and ext_ok and self.syntax_ok and (not self.dirty))
        self.led_dirty.set(self.dirty,   "Geändert" if self.dirty else "Unverändert")
        self.led_syn.set(self.syntax_ok, "Syntax OK" if self.syntax_ok else "Syntaxfehler")
        self.led_name.set(name_ok, "Name OK" if name_ok else "Name fehlt")
        self.led_ext.set(ext_ok,  "Endung OK" if ext_ok else "Endung fehlt")
        self.led_ok.set(all_ok,   "Alles OK" if all_ok else "Nicht OK")

def create_intake_tab(nb: ttk.Notebook) -> None:
    try:
        nb.add(DevIntake(nb), text="Intake")
    except Exception:
        f=ttk.Frame(nb)
        ttk.Label(f,text="Intake – Fehler beim Laden. Log prüfen.",foreground="red").grid(padx=12,pady=12,sticky="w")
        nb.add(f, text="Intake")
        traceback.print_exc()
'''

def main():
    MOD.parent.mkdir(parents=True, exist_ok=True)
    MOD.write_text(PAYLOAD, encoding="utf-8", newline="\n")
    print("[R1194] module_code_intake.py written.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
