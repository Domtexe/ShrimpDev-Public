# -*- coding: utf-8 -*-
from __future__ import annotations
import io, os, re, sys, time, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
LOG  = ROOT / "debug_output.txt"

def log(msg: str) -> None:
    try:
        with io.open(LOG, "a", encoding="utf-8", newline="\n") as f:
            f.write(f"[R1189] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    except Exception:
        pass

def backup(p: Path) -> Path:
    ARCH.mkdir(exist_ok=True)
    bak = ARCH / (p.name + "." + time.strftime("%Y%m%d_%H%M%S") + ".bak")
    shutil.copy2(str(p), str(bak))
    log(f"Backup: {bak}")
    return bak

def ensure_imports(src: str) -> str:
    add = []
    if not re.search(r"(?m)^\s*import\s+tkinter\s+as\s+tk\s*$", src):
        add.append("import tkinter as tk")
    if not re.search(r"(?m)^\s*from\s+tkinter\s+import\s+ttk,\s*messagebox\s*$", src):
        # deckt auch Fälle ab, wo ttk separat importiert wurde
        if "from tkinter import ttk" in src and "messagebox" not in src:
            src = re.sub(r"(?m)^from\s+tkinter\s+import\s+ttk\s*$",
                         "from tkinter import ttk, messagebox", src, count=1)
        else:
            add.append("from tkinter import ttk, messagebox")
    if add:
        src = "\n".join(add) + "\n" + src
    return src

def strip_broken_defs(src: str) -> str:
    before = src
    # Entfernt Zeilen wie: def  " in tlo, "class " ...
    src = re.sub(r"(?m)^\s*def\s*['\"].*$", r"# R1189: removed broken def line", src)
    # Gelegentliche abgerissene Triple-Quote-Kommentare am Ende eines Fortsetzungssatzes
    src = re.sub(r"(?m)^\s*py\s*\+=\s*1\s*\*\s*len\(.+\\\s*$", r"# R1189: removed broken continuation", src)
    if src != before:
        log("Broken def/continuation cleaned.")
    return src

STATUS_LED_CLASS = r"""
class StatusLED(ttk.Frame):
    """ + r'"""Kleine LED mit Tooltip und bool/int/str-Unterstützung."""' + r"""
    def __init__(self, master, label):
        super().__init__(master)
        self._label = label
        self._tip = ""
        self._c = tk.Canvas(self, width=14, height=14, highlightthickness=0,
                            bg=(master.cget("background") if hasattr(master,"cget") else "#f0f0f0"))
        self._c.pack()
        self._oval = self._c.create_oval(2,2,12,12, fill="#9e9e9e", outline="#555")
        self._c.bind("<Enter>", self._on_enter); self._c.bind("<Leave>", self._on_leave)
        self._tw = None
    def set(self, v, tip=None):
        col = "#9e9e9e"
        if isinstance(v, bool): col = "#4caf50" if v else "#e53935"
        elif isinstance(v, str):
            col = v
        elif isinstance(v, (int, float)):
            col = "#4caf50" if v else "#e53935"
        self._c.itemconfig(self._oval, fill=col)
        if tip is not None: self._tip = tip
    def _on_enter(self, _=None):
        if not self._tip: return
        if self._tw: return
        x = self._c.winfo_rootx()+16; y = self._c.winfo_rooty()+self._c.winfo_height()+6
        tw = tk.Toplevel(self._c); tw.wm_overrideredirect(True); tw.wm_geometry(f"+{x}+{y}")
        tk.Label(tw, text=self._tip, background="#ffffe0", relief="solid", borderwidth=1).pack(ipadx=3, ipady=1)
        self._tw = tw
    def _on_leave(self, _=None):
        if self._tw:
            self._tw.destroy(); self._tw = None
"""

LED_BAR_BLOCK = r"""
        # R1189: LED-Bar rechts außen
        try:
            led_bar = ttk.Frame(bar)
            led_bar.pack(side="right", padx=6)
            self.led_dirty  = StatusLED(led_bar, "Dirty")   # geändert?
            self.led_syntax = StatusLED(led_bar, "Syntax")  # py-syntax ok?
            self.led_name   = StatusLED(led_bar, "Name")    # name gefüllt?
            self.led_ext    = StatusLED(led_bar, "Ext")     # endung gültig?
            self.led_ok     = StatusLED(led_bar, "OK")      # alles grün?
            for _x in (self.led_dirty, self.led_syntax, self.led_name, self.led_ext, self.led_ok):
                _x.pack(side="left")
        except Exception as _e:
            # UI muss in jedem Fall starten, LEDs sind optional
            pass

        # Selektion besser sichtbar
        try:
            self.editor.configure(selectbackground="#cfe8ff", selectforeground="#000")
        except Exception:
            pass

        # Erstupdate
        try:
            if hasattr(self, "_update_leds"):
                self._update_leds()
        except Exception:
            pass
"""

def ensure_status_led(src: str) -> str:
    if "class StatusLED(" in src:
        return src
    # Vor der ersten Klasse einfügen
    return re.sub(r"(?m)^(class\s+\w+\s*\(.*\)\s*:)",
                  STATUS_LED_CLASS + r"\n\1", src, count=1)

def inject_led_bar_in_build_ui(src: str) -> str:
    # Finde die Stelle 'bar = ttk.Frame(self)' ... 'bar.pack(...)' in _build_ui
    pattern = r"(def\s+_build_ui\s*\(self[^\)]*\)\s*:[\s\S]*?bar\s*=\s*ttk\.Frame\(self\)[^\n]*\n[\s\S]*?bar\.pack\([^\n]*\)\s*\n)"
    def repl(m):
        block = m.group(1)
        if "R1189: LED-Bar" in block or "self.led_ok" in block:
            return m.group(0)  # schon da
        # gleiche Einrückung wie 'bar = ...' Zeile ermitteln
        lines = block.splitlines(True)
        indent = re.match(r"(\s*)", lines[-1]).group(1)
        inj = "".join(indent + ln for ln in LED_BAR_BLOCK.strip("\n").splitlines(True))
        return block + inj
    out, n = re.subn(pattern, repl, src, count=1)
    if n:
        log("LED-Bar in _build_ui injiziert.")
    return out

def ensure_editor_bind_and_fields(src: str) -> str:
    # _dirty/_syntax_ok Felder bei __init__
    if "_dirty" not in src or "_syntax_ok" not in src:
        src = re.sub(r"(def\s+__init__\s*\(self[^\)]*\)\s*:[^\n]*\n)",
                     r"\1        self._dirty = False\n        self._syntax_ok = True\n",
                     src, count=1)
    # <<Modified>> binden nach der Editor-Erzeugung
    if "<<Modified>>" not in src:
        src = re.sub(r"(self\.editor\s*=\s*tk\.[^\n]+\n)",
                     r"\1        self.editor.bind('<<Modified>>', self._on_modified)\n",
                     src, count=1)
    return src

def get_intake_class_name(src: str) -> str | None:
    # finde die Klasse, die _build_ui enthält
    for m in re.finditer(r"class\s+([A-Za-z_]\w*)\s*\([^)]*\)\s*:\s*", src):
        cls = m.group(1)
        # liegt eine _build_ui innerhalb dieser Klasse?
        start = m.end()
        next_class = re.search(r"\nclass\s+[A-Za-z_]\w*\s*\(", src[start:])
        end = start + (next_class.start() if next_class else len(src)-start)
        if re.search(r"(?m)^\s+def\s+_build_ui\s*\(", src[start:end]):
            return cls
    return None

PATCH_METHODS = r"""
# ===== R1189 monkey-patch methods =====
try:
    _R1189_CLS = {CLS}
except Exception:
    _R1189_CLS = None

if _R1189_CLS is not None:
    if not hasattr(_R1189_CLS, "_on_modified"):
        def _r1189_on_modified(self, _evt=None):
            try:
                if self.editor.edit_modified():
                    self._dirty = True
                    self.editor.edit_modified(False)
                    if hasattr(self, "_update_leds"):
                        self._update_leds()
            except Exception:
                pass
        _R1189_CLS._on_modified = _r1189_on_modified

    if not hasattr(_R1189_CLS, "_detect_name_ext"):
        def _r1189_detect_name_ext(self):
            import re
            src = self.editor.get("1.0","end-1c")
            txt = src.strip()
            # Syntax nur für Python einschätzen
            self._syntax_ok = True
            try:
                compile(src, "<intake>", "exec")
            except Exception:
                self._syntax_ok = False
            # Endung festlegen
            ext = (self.ext_var.get() or "").strip().lower()
            if not ext:
                if txt.startswith("@echo off") or "%%~" in txt or " set " in (" "+txt.lower()+" "):
                    ext = ".bat"
                else:
                    ext = ".py"
            if ext not in (".py", ".bat"):
                ext = ".py"
            # Name abschätzen
            name = (self.name_var.get() or "").strip()
            if not name:
                m = re.search(r"(?im)^\s*(Runner_[0-9]{3,5}_[A-Za-z0-9_]+)", txt)
                name = m.group(1) if m else "Runner_XXXX_DetectFix"
            self.ext_var.set(ext)
            self.name_var.set(name)
            if hasattr(self, "_update_leds"):
                self._update_leds()
        _R1189_CLS._detect_name_ext = _r1189_detect_name_ext

    if not hasattr(_R1189_CLS, "_update_leds"):
        def _r1189_update_leds(self):
            try:
                name_ok = bool((self.name_var.get() or "").strip())
                ext_ok  = bool((self.ext_var.get() or "").strip())
                ok_all  = bool(name_ok and ext_ok and self._syntax_ok and (not self._dirty))
                if hasattr(self, "led_dirty"):  self.led_dirty.set(self._dirty,  "Datei geändert" if self._dirty else "Datei unverändert")
                if hasattr(self, "led_syntax"): self.led_syntax.set(self._syntax_ok, "Syntax OK" if self._syntax_ok else "Syntaxfehler")
                if hasattr(self, "led_name"):   self.led_name.set(name_ok,  "Name OK" if name_ok else "Name fehlt")
                if hasattr(self, "led_ext"):    self.led_ext.set(ext_ok,   "Endung OK" if ext_ok else "Endung fehlt")
                if hasattr(self, "led_ok"):     self.led_ok.set(ok_all,   "Alles OK" if ok_all else "Nicht OK")
            except Exception:
                pass
        _R1189_CLS._update_leds = _r1189_update_leds
# ===== end R1189 =====
"""

def append_patch_methods(src: str) -> str:
    cls = get_intake_class_name(src) or "None"
    block = PATCH_METHODS.replace("{CLS}", cls)
    if "===== R1189 monkey-patch methods =====" not in src:
        src = src.rstrip() + "\n\n" + block
        log(f"Monkey-patch methods angehängt für Klasse: {cls}")
    return src

def main() -> int:
    if not SRC.exists():
        log("module_code_intake.py nicht gefunden.")
        return 2

    bak = backup(SRC)
    src = SRC.read_text(encoding="utf-8", errors="replace")

    # 1) offensichtliche Syntaxbrüche bereinigen
    src = strip_broken_defs(src)

    # 2) Imports sicherstellen
    src = ensure_imports(src)

    # 3) StatusLED-Klasse einfügen (falls fehlt)
    src = ensure_status_led(src)

    # 4) LED-Bar in _build_ui injizieren (idempotent)
    src = inject_led_bar_in_build_ui(src)

    # 5) Dirty-Tracking & Binding ergänzen
    src = ensure_editor_bind_and_fields(src)

    # 6) Patch-Methoden anhängen (falls in der Klasse selbst defekt/fehlend)
    src = append_patch_methods(src)

    # schreiben
    SRC.write_text(src, encoding="utf-8", newline="\n")
    log("Repair + LEDs + Detect fertig.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
