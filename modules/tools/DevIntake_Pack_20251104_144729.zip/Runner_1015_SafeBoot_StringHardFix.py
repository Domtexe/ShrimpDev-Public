"""
Runner_1015_SafeBoot_StringHardFix
- Schreibt eine saubere, syntaktisch korrekte main_gui.py (v9.9.6)
- Behält Safe-Boot (Frames mit Fallback), schlankes Menü, globale Shortcuts
- Entfernt alle defekten String-Literale aus vorherigen Patches
"""
from __future__ import annotations
import os, time, shutil, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
GUI  = os.path.join(ROOT, "main_gui.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

MAIN_GUI = r'''"""ShrimpDev main_gui (v9.9.6)
- Notebook: Code Intake / Agent / Project
- Safe-Boot: Fallback-Tabs bei Import-/Init-Fehlern
- Schlankes Menü (Topmost, Beenden), globale Shortcuts
"""
from __future__ import annotations
import os, sys, traceback, tkinter as tk
from tkinter import ttk, messagebox

# sys.path Safeguard
ROOT = os.path.abspath(os.path.dirname(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# Logger-Fallback
try:
    from modules.snippets.logger_snippet import write_log
except Exception:
    def write_log(p: str, m: str) -> None:
        try:
            with open(os.path.join(ROOT, "debug_output.txt"), "a", encoding="utf-8") as f:
                import time; ts = time.strftime("%Y-%m-%d %H:%M:%S")
                f.write(f"[{p}] {ts} {m}\n")
        except Exception:
            pass

# ---- Safe imports for frames (with fallbacks) ----
try:
    from modules.module_code_intake import IntakeFrame
except Exception as _ex:
    def IntakeFrame(master):
        import tkinter as tk, tkinter.ttk as ttk, traceback
        frm = ttk.Frame(master)
        txt = tk.Text(frm, height=12, wrap="word")
        txt.pack(fill="both", expand=True, padx=8, pady=8)
        msg = "Fehler: IntakeFrame konnte nicht geladen werden.\\n\\n" + "".join(
            traceback.format_exception_only(type(_ex), _ex)
        )
        txt.insert("end", msg)
        return frm

try:
    from modules.module_agent_ui import AgentFrame
except Exception as _ex:
    def AgentFrame(master):
        import tkinter as tk, tkinter.ttk as ttk, traceback
        frm = ttk.Frame(master)
        ttk.Label(frm, text="Agent-UI konnte nicht geladen werden.").pack(padx=10, pady=10)
        tk.Message(frm, text="".join(traceback.format_exception_only(type(_ex), _ex)), width=900).pack(padx=10, pady=4)
        return frm

try:
    from modules.module_project_ui import ProjectFrame
except Exception as _ex:
    def ProjectFrame(master):
        import tkinter as tk, tkinter.ttk as ttk, traceback
        frm = ttk.Frame(master)
        ttk.Label(frm, text="Project-UI konnte nicht geladen werden.").pack(padx=10, pady=10)
        tk.Message(frm, text="".join(traceback.format_exception_only(type(_ex), _ex)), width=900).pack(padx=10, pady=4)
        return frm
# -----------------------------------------------

from modules.config_mgr import ConfigMgr

def _safe_main() -> None:
    root = tk.Tk()
    root.title("ShrimpDev – v9.9.6")
    root.geometry("1100x740")

    # Styles
    style = ttk.Style()
    try:
        style.theme_use("clam")
    except Exception:
        pass
    style.configure("TButton", padding=(8,4))
    style.configure("TLabel",  padding=(2,0))

    cfg = ConfigMgr()

    # Always-on-Top Setting
    var_top = tk.BooleanVar(value=cfg.get_bool("general", "always_on_top", False))
    def _apply_top():
        try:
            root.attributes("-topmost", bool(var_top.get()))
            cfg.set_str("general", "always_on_top", "true" if var_top.get() else "false")
        except Exception as ex:
            write_log("GUI", f"TOPMOST_ERR: {ex}")

    # Notebook
    nb = ttk.Notebook(root)
    nb.pack(fill="both", expand=True)

    # Tabs (Safe)
    try:
        tab_intake = IntakeFrame(nb)
    except Exception as ex:
        write_log("GUI", "INTAKE_INIT_ERROR\\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        tab_intake = ttk.Frame(nb)
        ttk.Label(tab_intake, text="Fehler beim Laden des Intake-Tabs. Details siehe debug_output.txt").pack(padx=10, pady=10)

    try:
        tab_agent  = AgentFrame(nb)
    except Exception as ex:
        write_log("GUI", "AGENT_INIT_ERROR\\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        tab_agent = ttk.Frame(nb)
        ttk.Label(tab_agent, text="Fehler beim Laden des Agent-Tabs.").pack(padx=10, pady=10)

    try:
        tab_proj   = ProjectFrame(nb)
    except Exception as ex:
        write_log("GUI", "PROJECT_INIT_ERROR\\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        tab_proj = ttk.Frame(nb)
        ttk.Label(tab_proj, text="Fehler beim Laden des Project-Tabs.").pack(padx=10, pady=10)

    nb.add(tab_intake, text="Code Intake")
    nb.add(tab_agent,  text="Agent")
    nb.add(tab_proj,   text="Project")
    nb.select(0)

    # Menü (schlank)
    menubar = tk.Menu(root)
    m_file = tk.Menu(menubar, tearoff=0)
    m_file.add_checkbutton(label="Always on Top", onvalue=True, offvalue=False,
                           variable=var_top, command=_apply_top)
    m_file.add_separator()
    m_file.add_command(label="Beenden", command=root.destroy)
    menubar.add_cascade(label="File", menu=m_file)

    m_help = tk.Menu(menubar, tearoff=0)
    m_help.add_command(label="Info", command=lambda: messagebox.showinfo("ShrimpDev","Standalone Dev-Umgebung für ShrimpHub"))
    menubar.add_cascade(label="Help", menu=m_help)
    root.config(menu=menubar)

    # Shortcuts (global)
    root.bind_all("<Control-t>", lambda e: (var_top.set(not var_top.get()), _apply_top()))

    # Statusbar
    status = tk.StringVar(value="Bereit.")
    bar = ttk.Label(root, textvariable=status, anchor="w")
    bar.pack(side="bottom", fill="x")

    def report_callback_exception(*exc):
        msg = "".join(traceback.format_exception(*exc))
        write_log("GUI", "CRASH\\n" + msg)
        if os.environ.get("SHRIMPDEV_DEBUG") == "1":
            print("--- Tk callback exception ---")
            print(msg, flush=True)
        status.set(f"Fehler: {exc[-1]}")
    root.report_callback_exception = report_callback_exception

    _apply_top()
    root.mainloop()

if __name__ == "__main__":
    try:
        _safe_main()
    except Exception:
        tb = traceback.format_exc()
        write_log("GUI", "CRASH\\n" + tb)
        print(tb, flush=True)
        # Safe exit bei abgefangenen Startfehlern (kein RC=1 erzwingen)
        pass
'''

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1015] {ts} {msg}\n")
    print(msg, flush=True)

def safe_write(path: str, data: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        os.makedirs(ARCH, exist_ok=True)
        bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
        shutil.copy2(path, bck)
        log(f"Backup: {path} -> {bck}")
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

def patch() -> int:
    try:
        safe_write(GUI, MAIN_GUI)
        safe_write(os.path.join(ROOT, "CURRENT_VERSION.txt"), "ShrimpDev v9.9.6\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.6 (2025-10-18)
- FIX: main_gui.py vollständig neu geschrieben; alle Safe-Boot Strings korrekt escaped
- Beibehaltener Funktionsumfang: Safe-Boot, schlankes Menü, globale Shortcuts
""")
        log("main_gui.py neu geschrieben (v9.9.6).")
        return 0
    except Exception:
        log("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(patch())
