# -*- coding: utf-8 -*-
"""
Runner_1116_ReentrantBindGuard.py

Ziel:
- Reentrancy-Guard (@_reentrant_guard) in modules/module_code_intake.py integrieren.
- Click-Handler mit @... versehen.
- ButtonRelease-1-Binds an Buttons entfernen, stattdessen command=... am ttk.Button sicherstellen.
- Idempotent & mit Syntax-Check.
"""
from __future__ import annotations
import os, re, io, time, shutil, ast

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(BASE, "modules", "module_code_intake.py")
ARCH = os.path.join(BASE, "_Archiv")
os.makedirs(ARCH, exist_ok=True)

def read_text(p:str)->str:
    with open(p, "rb") as f:
        b = f.read()
    try:
        return b.decode("utf-8")
    except:
        return b.decode("utf-8", "replace")

def write_text(p:str, s:str)->None:
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)

def backup(p:str)->str:
    ts = int(time.time())
    q = os.path.join(ARCH, f"{os.path.basename(p)}.{ts}.bak")
    shutil.copy2(p, q)
    return q

def syntax_ok(code:str)->bool:
    try:
        ast.parse(code)
        return True
    except Exception as ex:
        print("[R1116] SyntaxError nach Patch:", ex)
        return False

src = read_text(MOD)
orig = src

print("[R1116] Prüfe:", MOD)

# 1) Reentrancy-Decorator einfügen (falls fehlt)
if "_reentrant_guard" not in src:
    # nach Imports einfügen
    m = re.search(r"(?ms)^from __future__.*?\n", src) or re.search(r"(?m)^(import .+|from .+ import .+)\n", src)
    insert_at = m.end() if m else 0
    guard_code = r'''

def _reentrant_guard(fn):
    """Verhindert re-entrante Aufrufe desselben Handlers; setzt Flag nach idle zurück."""
    name = getattr(fn, "__name__", "handler")
    flag_attr = f"_busy__{name}"
    def _wrap(self, *a, **kw):
        try:
            if getattr(self, flag_attr, False):
                return
        except Exception:
            # falls self kein Attribut zulässt
            return fn(self, *a, **kw)
        setattr(self, flag_attr, True)
        try:
            return fn(self, *a, **kw)
        finally:
            try:
                # nach idle freigeben, um sofortige Rückkopplung zu vermeiden
                self.after_idle(lambda: setattr(self, flag_attr, False))
            except Exception:
                setattr(self, flag_attr, False)
    return _wrap
'''
    src = src[:insert_at] + guard_code + src[insert_at:]

# 2) Handler mit Decorator versehen (falls vorhanden)
handlers = [
    "_on_click_detect",
    "_on_click_save",
    "_on_click_delete",
    "_on_click_guard",
    "_on_click_run",
]
for h in handlers:
    # Wenn def vorhanden, aber noch kein Decorator darüber -> einfügen
    patt = rf"(?ms)^\s*def\s+{h}\s*\("
    if re.search(patt, src) and not re.search(rf"(?ms)^\s*@_reentrant_guard\s*\n\s*def\s+{h}\s*\(", src):
        src = re.sub(patt, f"@_reentrant_guard\ndef {h}(", src, count=1)

# 3) ButtonRelease-1 Binds entfernen und command= am Button sicherstellen
#    Wir kennen typische Button-Namen:
btn_map = {
    "btn_detect": "_on_click_detect",
    "btn_save":   "_on_click_save",
    "btn_del":    "_on_click_delete",
    "btn_guard":  "_on_click_guard",
    "btn_run":    "_on_click_run",
}

# 3a) Bind-Zeilen killen
for btn, handler in btn_map.items():
    # kill z.B.: self.btn_detect.bind("<ButtonRelease-1>", lambda e: self._on_click_detect())
    bind_rx = rf'^\s*self\.{btn}\.bind\(\s*["\']<ButtonRelease-1>["\']\s*,.*?\)\s*$'
    src = re.sub(bind_rx, "", src, flags=re.M)

# 3b) Button-Konstruktoren patchen -> command=handler ergänzen, falls fehlt
for btn, handler in btn_map.items():
    # Suche Konstruktion: self.btn_xyz = ttk.Button( bar, ... )
    rx = rf'(?ms)(self\.{btn}\s*=\s*ttk\.Button\((?P<args>.*?)\))'
    def _add_command(m):
        call = m.group(0)
        args = m.group("args")
        if "command=" in args:
            return call  # schon vorhanden
        # elegante Einfügung: vor der schließenden Klammer ", command=self._on_click_*"
        # dabei Kommas in den args beachten – wir hängen sicher an:
        new_call = call[:-1] + f', command=self.{handler})'
        return new_call
    src = re.sub(rx, _add_command, src)

# 4) Aufräumen: leere, doppelte Leerzeilen reduzieren
src = re.sub(r"\n{3,}", "\n\n", src)

if src == orig:
    print("[R1116] Keine Änderungen nötig.")
else:
    if syntax_ok(src):
        bak = backup(MOD)
        write_text(MOD, src)
        print(f"[R1116] Änderungen geschrieben. Backup: {bak}")
        print("[R1116] Fertig – Reentrancy-Guard aktiv, doppelte Binds entfernt.")
    else:
        print("[R1116] Schreibvorgang abgebrochen (Syntax). Datei bleibt unverändert.")
