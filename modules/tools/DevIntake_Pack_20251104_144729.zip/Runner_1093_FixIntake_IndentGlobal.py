# -*- coding: utf-8 -*-
"""
Runner_1093_FixIntake_IndentGlobal
Repariert fehlerhafte Top-Level-Einrückungen in modules/module_code_intake.py,
die 'IndentationError' bei Import von IntakeFrame verursachen.
"""

from __future__ import annotations
import os, time, shutil, re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MOD = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
ARCH.mkdir(exist_ok=True)

def backup(path: Path) -> Path:
    bak = ARCH / f"{path.name}.{int(time.time())}.bak"
    shutil.copy2(path, bak)
    print(f"[R1093] Backup: {path} -> {bak}")
    return bak

def normalize_global_defs(src: str) -> str:
    lines = src.splitlines()
    out = []
    for line in lines:
        # Entferne 4 führende Spaces bei def/class auf Top-Level
        if re.match(r"^\s{4}def\s+", line):
            out.append(re.sub(r"^\s{4}", "", line))
        elif re.match(r"^\s{4}class\s+", line):
            out.append(re.sub(r"^\s{4}", "", line))
        else:
            out.append(line)
    return "\n".join(out)

def fix_open_explorer(src: str) -> str:
    """sorgt dafür, dass def _open_explorer_select korrekt eingerückt ist"""
    pat = re.compile(r"^\s*def\s+_open_explorer_select", re.M)
    if pat.search(src):
        src = re.sub(r"^\s*def\s+_open_explorer_select", "def _open_explorer_select", src, flags=re.M)
    return src

def main():
    if not MOD.exists():
        print("[R1093] module_code_intake.py nicht gefunden.")
        return 1
    backup(MOD)
    src = MOD.read_text(encoding="utf-8", errors="ignore")
    src2 = fix_open_explorer(normalize_global_defs(src))
    if src2 != src:
        MOD.write_text(src2, encoding="utf-8", newline="\n")
        print("[R1093] Einrückungen globaler defs repariert.")
    else:
        print("[R1093] Keine Änderungen nötig.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
