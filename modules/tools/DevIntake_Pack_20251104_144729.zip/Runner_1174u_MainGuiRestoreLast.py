# -*- coding: utf-8 -*-
import os, glob, shutil

ROOT = r"D:\ShrimpDev"
ARCH = os.path.join(ROOT, "_Archiv")
TARGET = os.path.join(ROOT, "main_gui.py")

def main():
    files = sorted(glob.glob(os.path.join(ARCH, "main_gui.py.*.bak")), key=os.path.getmtime, reverse=True)
    if not files:
        print("[1174u] Kein Backup gefunden."); return 2
    src = files[0]
    shutil.copy2(src, TARGET)
    print("[1174u] Wiederhergestellt aus:", src)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
