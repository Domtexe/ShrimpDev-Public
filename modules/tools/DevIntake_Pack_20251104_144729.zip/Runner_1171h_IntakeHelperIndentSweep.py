# -*- coding: utf-8 -*-
"""
R1171h_IntakeHelperIndentSweep
- Findet alle falsch eingerückten Helper "def _intake_...(…):"
- Schneidet jeden Block aus, dedentiert ihn auf Spalte 0 und hängt ihn am Datei-Ende an.
- Markiert jeden Move mit '# R1171h: moved to top-level'.
- Idempotent, mit Backup + Syntax-Check + Rollback.
Exitcodes: 0 OK, 1 Fehler
"""
from __future__ import annotations
import os, re, time, py_compile, traceback

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOG    = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1171h {ts}] {msg}\n"
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "r", encoding="utf-8") as fi, open(dst, "w", encoding="utf-8", newline="") as fo:
        fo.write(fi.read())
    return dst

def find_helper_blocks(src: str):
    """
    Liefert Liste von (start, end, indent, name) für ALLE Helper, die NICHT top-level sind.
    Blockende = nächste top-level 'def'/'class' oder EOF.
    """
    results = []
    # falsch eingerückte 'def _intake_*(' (mind. 1 führendes Whitespace)
    rx = re.compile(r"(?m)^(?P<indent>[ \t]+)def[ \t]+(?P<name>_intake_[A-Za-z0-9_]+)\s*\(", re.UNICODE)
    # nächste top-level def/class
    rx_end = re.compile(r"(?m)^(def|class)\b")
    for m in rx.finditer(src):
        indent = m.group("indent")
        name   = m.group("name")
        start  = m.start()
        # bis nächste top-level def/class oder EOF
        m_end = rx_end.search(src, m.end())
        end = m_end.start() if m_end else len(src)
        results.append((start, end, indent, name))
    return results

def dedent_block(block: str, indent: str) -> str:
    """Entfernt die führende Einrückung 'indent' aus allen Zeilen des Blocks."""
    lines = block.splitlines(True)
    # Anzahl Zeichen der indent-Sequenz (Tabs bleiben Tabs)
    k = len(indent)
    out = []
    for ln in lines:
        if ln.startswith(indent):
            out.append(ln[k:])
        else:
            # Leere/kurze Zeilen: führende Whitespaces vollständig entfernen
            stripped = ln.lstrip(" \t")
            # aber behalte reine \r\n:
            if stripped == "" and (ln.endswith("\n") or ln.endswith("\r")):
                out.append("\n")
            else:
                out.append(stripped if stripped else ln)
    return "".join(out)

def main() -> int:
    try:
        if not os.path.exists(TARGET):
            log(f"Zieldatei fehlt: {TARGET}")
            return 1

        src = open(TARGET, "r", encoding="utf-8").read()
        blocks = find_helper_blocks(src)
        if not blocks:
            log("Keine falsch eingerückten _intake_-Helper gefunden – keine Änderung nötig.")
            return 0

        # Von hinten nach vorne ausschneiden, damit Indizes stabil bleiben
        moved_snippets = []
        for start, end, indent, name in sorted(blocks, key=lambda t: t[0], reverse=True):
            raw = src[start:end]
            ded = dedent_block(raw, indent)
            snippet = f"# R1171h: moved to top-level ({name})\n" + ded.lstrip("\n")
            moved_snippets.append(snippet)
            src = src[:start] + src[end:]
            log(f"Helper '{name}' ausgeschnitten (Indent-Länge {len(indent)})")

        # Am Dateiende anhängen
        append_blob = "\n\n" + "\n\n".join(reversed(moved_snippets)) + "\n"
        new_src = src.rstrip() + append_blob

        # Backup + Schreiben + Syntax-Check
        bak = backup(TARGET); log(f"Backup erstellt: {bak}")
        with open(TARGET, "w", encoding="utf-8", newline="\n") as f:
            f.write(new_src)

        try:
            py_compile.compile(TARGET, doraise=True)
        except Exception as e:
            # Rollback
            with open(bak, "r", encoding="utf-8") as fi, open(TARGET, "w", encoding="utf-8", newline="\n") as fo:
                fo.write(fi.read())
            log("Syntax-Check FEHLER -> Rollback auf Backup.")
            log("Traceback:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 1

        log(f"{len(moved_snippets)} Helper erfolgreich dedentiert & ans Datei-Ende verschoben. Syntax-Check OK.")
        return 0

    except Exception as e:
        log("UNERWARTETER FEHLER:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
