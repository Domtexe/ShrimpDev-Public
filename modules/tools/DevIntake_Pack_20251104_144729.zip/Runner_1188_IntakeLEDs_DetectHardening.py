# Runner_1188_IntakeLEDs_DetectHardening.py
import re, sys, time, os, shutil
ROOT = r"D:\ShrimpDev"
FILE = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
os.makedirs(ARCH, exist_ok=True)

def backup(path):
    ts = time.strftime("%Y%m%d_%H%M%S")
    dst = os.path.join(ARCH, os.path.basename(path) + "." + ts + ".bak")
    shutil.copy2(path, dst)
    return dst

def patch(src):
    out = src
    # 1) _dirty Feld
    if "_dirty" not in out:
        out = re.sub(r"(class\s+CodeIntake[\s\S]*?__init__\s*\([^)]*\)\s*:\s*\n)",
                     r"\1    self._dirty = False\n    self._current_path = None\n    self._syntax_ok = True\n",
                     out, count=1)
    # 2) LED-Bar einbauen am Ende von _build_ui
    if "StatusLED(led_bar" not in out:
        out = re.sub(r"(def\s+_build_ui\([\s\S]*?bar\.pack\([^\n]*\)\n)",
                     r"\1    led_bar = ttk.Frame(bar)\n"
                     r"    led_bar.pack(side='right', padx=6)\n"
                     r"    self.led_dirty  = StatusLED(led_bar, 'Dirty')\n"
                     r"    self.led_syntax = StatusLED(led_bar, 'Syntax')\n"
                     r"    self.led_name   = StatusLED(led_bar, 'Name')\n"
                     r"    self.led_ext    = StatusLED(led_bar, 'Ext')\n"
                     r"    self.led_ok     = StatusLED(led_bar, 'OK')\n"
                     r"    [x].pack(side='left')\n".replace("[x]","self.led_dirty") +
                     r"    self.led_syntax.pack(side='left')\n"
                     r"    self.led_name.pack(side='left')\n"
                     r"    self.led_ext.pack(side='left')\n"
                     r"    self.led_ok.pack(side='left')\n"
                     r"    self.editor.configure(selectbackground='#cfe8ff', selectforeground='#000')\n"
                     r"    self._update_leds()\n",
                     out, count=1)

    # 3) <<Modified>> Binding
    if "def _on_modified(" not in out:
        out += ("\n\ndef _on_modified(self, _evt=None):\n"
                "    if self.editor.edit_modified():\n"
                "        self._dirty = True\n"
                "        self.editor.edit_modified(False)\n"
                "        self._update_leds()\n")
    if "<<Modified>>" not in out:
        out = re.sub(r"(self\.editor\s*=\s*tk\.Text[\s\S]*?\)\n)",
                     r"\1    self.editor.bind('<<Modified>>', self._on_modified)\n",
                     out, count=1)

    # 4) _update_leds robust
    if re.search(r"def\s+_update_leds\s*\(", out) and "self.led_dirty.set" not in out:
        out = re.sub(r"def\s+_update_leds\s*\([\s\S]*?def", 
                     ("def _update_leds(self):\n"
                      "    if not hasattr(self, 'led_dirty'):\n"
                      "        return\n"
                      "    name_ok = bool(self.name_var.get().strip())\n"
                      "    ext_ok  = bool(self.ext_var.get().strip())\n"
                      "    ok_all  = (name_ok and ext_ok and self._syntax_ok and not self._dirty)\n"
                      "    self.led_dirty.set(self._dirty)\n"
                      "    self.led_syntax.set(self._syntax_ok)\n"
                      "    self.led_name.set(name_ok)\n"
                      "    self.led_ext.set(ext_ok)\n"
                      "    self.led_ok.set(ok_all)\n\n"
                      "def "), out, count=1)

    # 5) Detect härten / falls nicht vorhanden, anhängen
    if "def _detect_name_ext(" not in out:
        out += ("\n\ndef _detect_name_ext(self):\n"
                "    import re\n"
                "    src = self.editor.get('1.0', 'end-1c')\n"
                "    txt = src.strip()\n"
                "    self._syntax_ok = True\n"
                "    try:\n"
                "        compile(src, '<intake-snippet>', 'exec')\n"
                "    except Exception:\n"
                "        self._syntax_ok = False\n"
                "    ext = self.ext_var.get().strip().lower()\n"
                "    if not ext:\n"
                "        if txt.startswith('@echo off') or '%%~' in txt or '.bat' in txt[:100]:\n"
                "            ext = '.bat'\n"
                "        else:\n"
                "            ext = '.py'\n"
                "    elif ext not in ('.py', '.bat'):\n"
                "        ext = '.py'\n"
                "    name = self.name_var.get().strip()\n"
                "    if not name:\n"
                "        m = re.search(r'(?im)^\\s*(Runner_[0-9]{3,5}_[A-Za-z0-9_]+)', txt)\n"
                "        name = m.group(1) if m else 'Runner_XXXX_DetectFix'\n"
                "    self.ext_var.set(ext)\n"
                "    self.name_var.set(name)\n"
                "    self._update_leds()\n")
    return out

def main():
    if not os.path.isfile(FILE):
        print("[R1188] module_code_intake.py nicht gefunden.")
        sys.exit(2)
    bak = backup(FILE)
    with open(FILE, "r", encoding="utf-8") as f:
        src = f.read()
    out = patch(src)
    if out == src:
        print("[R1188] Keine Änderungen nötig.")
    else:
        with open(FILE, "w", encoding="utf-8", newline="\n") as f:
            f.write(out)
        print(f"[R1188] Gepatcht. Backup: {bak}")

if __name__ == "__main__":
    main()
