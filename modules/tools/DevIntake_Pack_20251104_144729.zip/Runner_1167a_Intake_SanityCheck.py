# -*- coding: utf-8 -*-
"""
Runner_1167a_Intake_SanityCheck
Prüft das Intake-Modul in drei Stufen:
  1) Statisch: Helpers-Marker + zwei Folgezeilen -> Basisindent 4 Spaces
  2) Syntax:   py_compile
  3) Dynamik:  Import des Moduls + Prüfung erwarteter Attribute (z. B. IntakeFrame / _build_ui)
Ergebnisse in debug_output.txt (rotierend), Exitcode !=0 bei Fehler.
"""
from __future__ import annotations

import io
import os
import re
import sys
import time
import traceback
import py_compile
from typing import List, Tuple

LOGFILE = os.path.join(os.path.dirname(__file__), "..", "debug_output.txt")
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
INTAKE_PATH = os.path.join(PROJECT_ROOT, "modules", "module_code_intake.py")

# --- Logging (einfach, rotierend) ------------------------------------------------
def _rotate_log_if_needed(path: str, max_bytes: int = 1_000_000) -> None:
    try:
        if os.path.exists(path) and os.path.getsize(path) > max_bytes:
            ts = int(time.time())
            os.rename(path, f"{path}.{ts}.old")
    except Exception:
        # Logrotation darf nie scheitern
        pass

def _log(msg: str) -> None:
    os.makedirs(os.path.dirname(LOGFILE), exist_ok=True)
    _rotate_log_if_needed(LOGFILE)
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1167a {stamp}] {msg}\n"
    with open(LOGFILE, "a", encoding="utf-8", newline="") as f:
        f.write(line)
    print(line, end="")

# --- Hilfen ----------------------------------------------------------------------
def _read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def _leading_spaces(s: str) -> int:
    return len(s) - len(s.lstrip(" "))

def _find_helpers_and_following(src: str) -> Tuple[int, List[str]]:
    """
    Sucht die Zeile mit dem Helpers-Marker '# ---------- helpers ----------'
    und gibt deren Index sowie die nächsten zwei nicht-leeren physischen Zeilen zurück.
    """
    lines = src.splitlines()
    marker_idx = -1
    for i, line in enumerate(lines):
        if re.search(r"#\s*-{2,}\s*helpers\s*-{2,}\s*$", line.strip(), flags=re.I):
            marker_idx = i
            break
    if marker_idx < 0:
        raise ValueError("Helpers-Marker wurde nicht gefunden.")

    following: List[str] = []
    j = marker_idx + 1
    while j < len(lines) and len(following) < 2:
        if lines[j].strip() != "":
            following.append(lines[j])
        j += 1
    if len(following) < 2:
        raise ValueError("Weniger als zwei Folgezeilen nach Helpers-Marker gefunden.")
    return marker_idx, following

def _check_indent_rule(src: str) -> None:
    """
    Regel §12.5: Helpers-Marker und die zwei Folgezeilen müssen Basisindent 4 Spaces haben.
    """
    marker_idx, following = _find_helpers_and_following(src)
    lines = src.splitlines()

    marker_line = lines[marker_idx]
    marker_indent = _leading_spaces(marker_line)

    if marker_indent != 4:
        raise AssertionError(f"Helpers-Marker hat {marker_indent} führende Spaces, erwartet 4.")

    for k, fl in enumerate(following, start=1):
        ind = _leading_spaces(fl)
        if ind != 4:
            raise AssertionError(
                f"Folgezeile {k} nach Helpers-Marker hat {ind} führende Spaces, erwartet 4."
            )

def _syntax_check(path: str) -> None:
    py_compile.compile(path, doraise=True)

def _dynamic_check() -> None:
    """
    Minimal-invasiver Modulcheck:
    - Modul importieren
    - Existenz typischer Intake-Symbole prüfen (robust gegen Varianten)
    Kein GUI-Start, kein Tk-Mainloop.
    """
    sys.path.insert(0, PROJECT_ROOT)
    try:
        mod = __import__("modules.module_code_intake", fromlist=["*"])
    except Exception as e:
        raise RuntimeError(f"Import von modules.module_code_intake fehlgeschlagen: {e}")

    candidates = ["IntakeFrame", "_build_ui", "build_ui", "run"]
    found = [name for name in candidates if hasattr(mod, name)]

    if not found:
        raise AssertionError(
            "Keines der erwarteten Intake-Symbole gefunden: "
            + ", ".join(candidates)
        )

# --- Main ------------------------------------------------------------------------
def main() -> int:
    os.chdir(PROJECT_ROOT)
    _log("=== Intake Sanity-Check (R1167a) START ===")
    _log(f"Root: {PROJECT_ROOT}")
    _log(f"Zieldatei: {INTAKE_PATH}")

    try:
        if not os.path.exists(INTAKE_PATH):
            raise FileNotFoundError("modules/module_code_intake.py nicht gefunden.")

        src = _read_text(INTAKE_PATH)

        # 1) Statisch: Indent-Regel §12.5
        try:
            _check_indent_rule(src)
            _log("Indent-Regel §12.5: OK (Helpers + 2 Folgezeilen = 4 Spaces).")
        except Exception as e:
            _log(f"Indent-Regel §12.5: FEHLER -> {e}")
            return 2

        # 2) Syntax
        try:
            _syntax_check(INTAKE_PATH)
            _log("Syntax-Check: OK")
        except Exception as e:
            _log(f"Syntax-Check: FEHLER -> {e}")
            tb = traceback.format_exc()
            _log(tb)
            return 3

        # 3) Dynamik (Import + Symbole)
        try:
            _dynamic_check()
            _log("Dynamik-Check (Import + Symbole): OK")
        except Exception as e:
            _log(f"Dynamik-Check: FEHLER -> {e}")
            tb = traceback.format_exc()
            _log(tb)
            return 4

        _log("GESAMT: OK – Intake sollte im GUI wieder laden.")
        _log("=== Intake Sanity-Check (R1167a) ENDE ===")
        return 0

    except Exception as e:
        _log(f"UNERWARTETER FEHLER: {e}")
        _log(traceback.format_exc())
        return 1

if __name__ == "__main__":
    rc = main()
    sys.exit(rc)
