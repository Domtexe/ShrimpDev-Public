# tools/Runner_1107_AutoRepair_Intake_BindsAndTry.py
import re, sys, shutil, pathlib

ROOT   = pathlib.Path(__file__).resolve().parents[1]
TARGET = ROOT / "modules" / "module_code_intake.py"

def patch(text: str) -> str:
    orig = text

    # 1) Doppelte ButtonRelease-Bindings (Detect/Save/Delete) entfernen
    text = re.sub(
        r'\s*self\.btn_detect\.bind\("<ButtonRelease-1>".*?\)\s*\n', "", text)
    text = re.sub(
        r'\s*self\.btn_save\.bind\("<ButtonRelease-1>".*?\)\s*\n', "", text)
    text = re.sub(
        r'\s*self\.btn_del\.bind\("<ButtonRelease-1>".*?\)\s*\n', "", text)

    # 2) Doppelt verschachteltes try: bereinigen – nur EIN try + except zulassen
    #    a) „try:“ direkt vor den Button-Bindings behalten …
    text = re.sub(r'(\n\s*try:\s*\n)(\s*try:\s*\n)', r'\1', text)
    #    b) Falls nach dem ersten try kein except folgt, eines nachschieben
    text = re.sub(
        r'(self\.lbl_ping\.grid\([^\n]*\)\s*\n\s*try:\s*\n)'
        r'((?:(?!\n\s*except\b|\n\s*finally\b).)*?)'   # Block-Inhalt
        r'(?=\n\s*body\s*=)',                          # bis vor body = ttk.Panedwindow
        lambda m: m.group(1) + m.group(2) + "\n        except Exception:\n            pass\n",
        text,
        flags=re.DOTALL
    )

    # 3) Guard-Button auf 'bar' umstellen (falls noch frm_actions benutzt wird)
    text = re.sub(
        r'(self\.btn_guard\s*=\s*ttk\.Button\()\s*self\.frm_actions(\s*,)',
        r'\1bar\2',
        text
    )

    # leichte Aufräumung mehrfacher Leerzeilen
    text = re.sub(r'\n{3,}', '\n\n', text)

    return text if text != orig else orig

def main():
    if not TARGET.exists():
        print(f"[R1107] Datei fehlt: {TARGET}")
        sys.exit(1)

    src  = TARGET.read_text(encoding="utf-8")
    new  = patch(src)

    if new == src:
        print("[R1107] Keine Änderungen nötig.")
        sys.exit(0)

    bk = ROOT / "_Archiv" / (TARGET.name + ".r1107.bak")
    bk.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(TARGET, bk)
    TARGET.write_text(new, encoding="utf-8")
    print(f"[R1107] Backup: {TARGET} -> {bk}")
    print("[R1107] Patch angewendet.")

    # Sanity-Check – lässt Syntaxfehler sofort auffliegen
    import py_compile
    try:
        py_compile.compile(str(TARGET), doraise=True)
        print("[R1107] Syntax OK.")
    except Exception as ex:
        print(f"[R1107] SyntaxError nach Patch: {ex!s}")
        print("[R1107] Datei bleibt aber gepatcht (Backup vorhanden).")

if __name__ == "__main__":
    main()
