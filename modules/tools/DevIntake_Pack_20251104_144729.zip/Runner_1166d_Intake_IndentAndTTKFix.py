# -*- coding: utf-8 -*-
"""
R1166d Intake Indent & TTK Fix
- Fix für "Intake lädt nicht" + "IndentationError" in module_code_intake.py.
- Idempotent, minimal-invasiv, einrückungssicher.

Änderungen in _build_ui():
  1) Entfernt Zeile(n): 'global ttk'
  2) Nach 'bar = ttk.Frame(self)' fügt ein (falls fehlend, exakt gleiche Einrückung):
       self.toolbar = bar
       self.frm_actions = bar
  3) Ersetzt lokalen R1154g-Block (lokale ttk-Imports) durch ttk-neutrale Version
     ohne Funktions-Imports/Zuweisungen (verhindert ttk-Schatteneffekt).
  4) Behebt IndentationError: dedentiert
       'self._intake_post_build_bind_clear()'
     auf die Basisindentation der Funktion (gleiche Zeile auch für den Kommentar davor).

Sicherheit:
  - Backup -> _Archiv
  - Syntax-Check via py_compile, Rollback bei Fehler
"""
from __future__ import annotations
import io, re, time, shutil, py_compile, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
DOCS = ROOT / "docs"
RULE = DOCS / "MASTERREGELN_ADDENDUM_2025-10-23.md"
LOGF = ROOT / "debug_output.txt"

RULES = """# Masterregeln – Addendum (2025-10-23)

## 1.4 GUI-Imports (verbindlich)
- GUI-Toolkit-Imports (`tkinter`, `ttk`, `messagebox`, `filedialog`) **nur im Modulkopf**.
- In Funktionen **keine** lokalen Re-Imports/Zuweisungen dieser Namen.
- Motivation: verhindert `UnboundLocalError`/Shadowing in UI-Build-Pfaden.

## 1.5 Toolbar-Referenzen (verbindlich)
- Toolbarcontainer zentral referenzieren: `self.toolbar = bar`.
- Legacy-Aliase (z. B. `self.frm_actions`) dürfen als **Alias auf dieselbe Instanz** gesetzt werden.

## 12.4 Patch-Sorgfalt & Einrückungen (NEU)
- Patches sind **einrückungssicher** (Tabs/Spaces unverändert übernehmen).
- Minimalprinzip: nur notwendige Zeilen ändern; große Blöcke nur, wenn zwingend.
- Idempotenz: Mehrfachausführung darf nicht zu Doppel-Injektionen führen.
"""

R1154G_CLEAN = (
    "# R1154g: zusätzliche Toolbar-Buttons (ttk-neutral, idempotent)\n"
    "parent = bar if 'bar' in locals() else getattr(self, 'toolbar', None)\n"
    "if parent:\n"
    "    # Editor leeren (links)\n"
    "    try:\n"
    "        if not hasattr(self, 'btn_clear_editor'):\n"
    "            self.btn_clear_editor = ttk.Button(parent, text='Editor leeren', command=self._on_clear_editor)\n"
    "            self.btn_clear_editor.grid(row=0, column=0, padx=(12,0), sticky='w')\n"
    "    except Exception:\n"
    "        pass\n"
    "    # Datei löschen (rechts)\n"
    "    try:\n"
    "        if not hasattr(self, 'btn_delete_file'):\n"
    "            self.btn_delete_file = ttk.Button(parent, text='Datei löschen', command=self._on_delete_selected_file)\n"
    "            self.btn_delete_file.grid(row=0, column=121, padx=(6,0), sticky='w')\n"
    "    except Exception:\n"
    "        pass\n"
)

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1166d] {ts} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f: f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(p: Path) -> Path:
    ARCH.mkdir(parents=True, exist_ok=True)
    dst = ARCH / f"{p.name}.{int(time.time())}.bak"
    shutil.copy2(p, dst)
    log(f"Backup: {p} -> {dst}")
    return dst

def _indent_block(text: str, indent: str) -> str:
    out = []
    for ln in text.splitlines(True):
        if ln.strip():
            out.append(indent + ln)
        else:
            out.append(ln)
    return "".join(out)

def patch_source(src: str) -> tuple[str, list[str]]:
    changes: list[str] = []

    m_def = re.search(r"^(\s*)def\s+_build_ui\s*\(\s*self[^\)]*\)\s*:\s*$", src, re.M)
    if not m_def:
        return src, changes
    func_indent = m_def.group(1)
    start = m_def.end()
    m_next = re.search(r"^\s*def\s+\w+\s*\(", src[start:], re.M)
    end = start + (m_next.start() if m_next else len(src)-start)
    block = src[start:end]

    # 1) 'global ttk' Zeilen entfernen
    new_block = re.sub(r"^\s*global\s+ttk\s*\r?\n", "", block, flags=re.M)
    if new_block != block:
        changes.append("Removed 'global ttk'")
        block = new_block

    # 2) Nach 'bar = ttk.Frame(self' Aliase einfügen (exakte Einrückung)
    m_bar = re.search(r"^(\s*)bar\s*=\s*ttk\.Frame\(\s*self\s*\)\s*$", block, re.M)
    if m_bar:
        bar_indent = m_bar.group(1)
        insert_pos = m_bar.end()
        tail = block[insert_pos: insert_pos+400]  # wenige Zeilen danach
        add = []
        if "self.toolbar = bar" not in tail:
            add.append(f"{bar_indent}self.toolbar = bar  # R1166d")
        if "self.frm_actions = bar" not in tail:
            add.append(f"{bar_indent}self.frm_actions = bar  # R1166d (compat)")
        if add:
            block = block[:insert_pos] + "\n" + "\n".join(add) + "\n" + block[insert_pos:]
            if "self.toolbar = bar  # R1166d" in add[0]:
                changes.append("Inserted 'self.toolbar = bar'")
            if any("self.frm_actions" in a for a in add):
                changes.append("Inserted 'self.frm_actions = bar'")

    # 3) Lokalen R1154g-Bereich finden und ersetzen (ttk-neutral, gleiche Indent)
    #    Tolerant für 'zusätzliche' / 'zusaetzliche', deutsch/ohne Umlaute.
    m_r = re.search(r"^(\s*)#\s*R1154g:.*Toolbar-Buttons.*$", block, re.M | re.I)
    if m_r:
        r_indent = m_r.group(1)
        rest = block[m_r.end():]
        # Bereichsende: bis zum nächsten dedizierten Abschnitt oder dedent/eof
        m_end = re.search(r"^\s*#\s*-{2,}\s*helpers\s*-{2,}\s*$", rest, re.M)
        if not m_end:
            # ansonsten: bis zum nächsten dedent auf Funktionsindent oder EOF
            m_end = re.search(rf"^{func_indent}\S", rest, re.M)
        end_off = m_end.start() if m_end else len(rest)
        block = block[:m_r.start()] + _indent_block(R1154G_CLEAN, r_indent) + rest[end_off:]
        changes.append("Replaced R1154g block with ttk-neutral version")

    # 4) IndentationError fix: dedent Kommentar + Funktionsaufruf auf Basisindent
    #    Wir suchen explizit die beiden Zeilen und setzen sie auf func_indent + 4 Spaces.
    #    (Innerhalb einer Methode ist Basisindent meist 4 Spaces.)
    # Kommentar-Zeile:
    block = re.sub(
        r"^\s*#\s*-{2,}\s*helpers\s*-{2,}\s*$",
        f"{func_indent}    # ---------- helpers ----------",
        block, flags=re.M
    )
    # Aufruf-Zeile(n):
    block = re.sub(
        r"^\s{8}self\._intake_post_build_bind_clear\(\)\s*$",  # exakt 8 Spaces (wie in deiner Datei)
        f"{func_indent}    self._intake_post_build_bind_clear()",
        block, flags=re.M
    )

    new_src = src[:start] + block + src[end:]
    return new_src, changes

def write_rules():
    DOCS.mkdir(parents=True, exist_ok=True)
    RULE.write_text(RULES, encoding="utf-8")

def main() -> int:
    try:
        if not MOD.exists():
            log(f"[ERR] Not found: {MOD}"); return 2
        src = MOD.read_text(encoding="utf-8")
        bak = backup(MOD)
        new_src, changes = patch_source(src)
        if changes:
            MOD.write_text(new_src, encoding="utf-8", newline="\n")
            for c in changes: log(f"Change: {c}")
            try:
                py_compile.compile(str(MOD), doraise=True)
                log("Syntax-Check: OK")
            except Exception as ex:
                log(f"[ERR] Syntax-Check failed: {ex}")
                shutil.copy2(bak, MOD)
                log("Restored from backup.")
                return 3
        else:
            log("No changes applied (already healthy).")

        try:
            write_rules(); log(f"Wrote rules addendum: {RULE}")
        except Exception as ex:
            log(f"[WARN] Could not write rules addendum: {ex}")

        log("R1166d completed successfully.")
        return 0
    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
