# -*- coding: utf-8 -*-
"""
R1181c – Indent-Fix v2
- Sucht alle 'try:' Zeilen.
- Wenn direkt danach keine eingerückte Codezeile folgt (oder sofort 'except/finally' kommt),
  wird ein korrekt eingerücktes 'pass  # auto-fix: empty try' eingefügt.
- Entfernt zuvor fälschlich an Spalte 0 eingefügte 'pass  # auto-fix' Zeilen.
- Backup + Syntax-Check + Logging.
"""
from __future__ import annotations
import os, re, time, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")
MAIN = os.path.join(ROOT, "main_gui.py")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(LOG, "a", encoding="utf-8", newline="\n") as f:
            f.write(f"[R1181c] {ts} {msg}\n")
    except Exception:
        pass
    print(f"[R1181c] {msg}")

def backup(path: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{stamp}.bak")
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        src = f.read()
    with open(dst, "w", encoding="utf-8") as f:
        f.write(src)
    log(f"Backup: {dst}")

def fix_indents(src: str) -> str:
    lines = src.splitlines()
    out: list[str] = []
    i = 0

    # 0) Aufräumen: falsch platzierte 'pass  # auto-fix' an Spalte 0
    #    (lassen wir implizit weg, indem wir nicht einfach übernehmen, wenn der Kontext falsch ist)
    #    Wir entfernen NUR, wenn VORHER eine try:-Zeile kam.
    prev_was_try = False

    while i < len(lines):
        ln = lines[i]

        # Entferne altes falsches 'pass  # auto-fix' in Spalte 0 nach try:
        if prev_was_try and re.match(r"^pass\s+#\s*auto-fix", ln):
            # nicht übernehmen; wir setzen gleich korrekt eingerückt ein
            ln = ""  # fällt gleich durch, wir überschreiben per Logik unten

        if re.match(r"^\s*try:\s*$", ln):
            out.append(ln)
            # Indent der try-Zeile bestimmen
            indent = re.match(r"^(\s*)", ln).group(1)  # type: ignore
            next_line = lines[i+1] if i+1 < len(lines) else ""

            # Fall A: nächste Zeile hat KEINE Einrückung (oder EOF) -> wir fügen ein korrekt eingerücktes pass ein
            if not next_line or re.match(r"^[^\s]", next_line):
                out.append(f"{indent}    pass  # auto-fix: empty try")
                prev_was_try = False
                i += 1
                continue

            # Fall B: nächste sinnvolle Zeile ist 'except'/'finally' mit gleicher Einrückung -> vorher 'pass' einfügen
            # (d. h. Zeilen mit nur Leerzeichen/Kommentar überspringen)
            j = i + 1
            while j < len(lines) and (lines[j].strip() == "" or re.match(r"^\s*#.*$", lines[j])):
                out.append(lines[j])
                j += 1
            if j < len(lines):
                nl = lines[j]
                same_indent = re.match(r"^(\s*)", nl).group(1) == indent  # type: ignore
                if same_indent and re.match(r"^\s*(except|finally)\b", nl):
                    out.append(f"{indent}    pass  # auto-fix: empty try")
            # jetzt normalen Cursor fortsetzen (i wird unten erhöht),
            prev_was_try = False
            i += 1
            continue

        else:
            out.append(ln)
            prev_was_try = False

        i += 1

    return "\n".join(out)

def main() -> int:
    if not os.path.isfile(MAIN):
        log("main_gui.py nicht gefunden.")
        return 2

    with open(MAIN, "r", encoding="utf-8", errors="replace") as f:
        src = f.read()

    fixed = fix_indents(src)

    if fixed != src:
        backup(MAIN)
        with open(MAIN, "w", encoding="utf-8", newline="\n") as f:
            f.write(fixed)
        log("Indent-Fix angewendet.")
    else:
        log("Keine Änderungen erforderlich.")

    # Syntax-Check
    try:
        compile(fixed, MAIN, "exec")
        log("SyntaxCheck OK.")
        return 0
    except SyntaxError as e:
        log(f"SyntaxError: line {e.lineno} col {e.offset} {e.msg}")
        return 3

if __name__ == "__main__":
    sys.exit(main())
