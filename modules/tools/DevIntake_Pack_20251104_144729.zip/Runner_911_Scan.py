from modules.module_project_scan import scan
from modules.snippets.agent_client import send_event
try:
    d = scan()
    send_event({"runner":"Runner_911_Scan","level":"OK","msg":f"files={len(d['files'])}"})
    print("[R911] OK")
except Exception as ex:
    send_event({"runner":"Runner_911_Scan","level":"ERROR","msg":str(ex)})
    print("[R911] ERROR:", ex)
