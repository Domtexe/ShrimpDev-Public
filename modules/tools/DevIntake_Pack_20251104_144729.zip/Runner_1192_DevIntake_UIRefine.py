# -*- coding: utf-8 -*-
"""
R1192: DevIntake UI Refine (ShrimpDev)
- Facelift: klare Gruppen, LED-Bar, Anti-Flackern
- Multi-Sort, Persistenz, Filter-Tokens
- Erkennung (.py/.bat + Runner_####_Name), Syntaxhighlight bei Fehler
"""
import sys, time, traceback, configparser, subprocess, re, zipfile
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
INI  = "dev_intake.ini"

# ---------- Hilfen ----------
def _log(tag: str, msg: str) -> None:
    try:
        with (ROOT / "debug_output.txt").open("a", encoding="utf-8", newline="\n") as f:
            f.write(f"[DevIntake] {time.strftime('%Y-%m-%d %H:%M:%S')} [{tag}] {msg}\n")
    except Exception:
        pass

def _fmt(ts: float):
    lt = time.localtime(ts)
    return time.strftime("%Y-%m-%d", lt), time.strftime("%H:%M:%S", lt)

def _detect_ext(text: str) -> str:
    t = (text or "").lstrip()
    tl = t.lower()
    if tl.startswith("@echo off") or any(m in tl for m in ("\nrem ","\r\nrem ","\n::","\r\n::","\n:","\r\n:"," set "," goto ")):
        return ".bat"
    if any(k in t for k in ("import ","from ","def ","class ","print(","__name__")):
        return ".py"
    return ".txt"

def _open_explorer(p: Path) -> None:
    try:
        if p.is_dir():
            subprocess.Popen(["explorer", str(p)])
        else:
            subprocess.Popen(["explorer", "/select,", str(p)])
    except Exception as e:
        messagebox.showerror("Explorer", str(e))
        _log("EXPLORER_FAIL", str(e))

def _run_console(cmd: list[str]) -> None:
    try:
        subprocess.Popen(cmd, creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
    except Exception as e:
        messagebox.showerror("Run", f"Start fehlgeschlagen:\n{e}")
        _log("RUN_FAIL", str(e))

# ---------- LED ----------
class StatusLED(ttk.Frame):
    def __init__(self, master, tooltip=""):
        super().__init__(master)
        self._tip = tooltip
        self._tw = None
        bg = self._bg(master)
        self.cnv = tk.Canvas(self, width=14, height=14, highlightthickness=0, bg=bg)
        self.cnv.pack()
        self.oval = self.cnv.create_oval(2,2,12,12, fill="#9e9e9e", outline="#555")
        self.cnv.bind("<Enter>", self._show_tip)
        self.cnv.bind("<Leave>", self._hide_tip)

    @staticmethod
    def _bg(w):
        try: return w.cget("background")
        except: return "#f0f0f0"

    def set(self, ok: bool|str, tip: str|None=None):
        color = "#4caf50" if ok is True else ("#e53935" if ok is False else str(ok))
        self.cnv.itemconfig(self.oval, fill=color)
        if tip is not None: self._tip = tip

    def _show_tip(self, *_):
        if not self._tip or self._tw: return
        x = self.cnv.winfo_rootx() + 16
        y = self.cnv.winfo_rooty() + self.cnv.winfo_height() + 6
        self._tw = tw = tk.Toplevel(self.cnv); tw.wm_overrideredirect(True); tw.wm_geometry(f"+{x}+{y}")
        tk.Label(tw, text=self._tip, background="#ffffe0", relief="solid", borderwidth=1).pack(ipadx=3, ipady=1)

    def _hide_tip(self, *_):
        if self._tw: self._tw.destroy(); self._tw = None

# ---------- Intake-UI ----------
class DevIntake(ttk.Frame):
    _STYLE = False
    def __init__(self, nb: ttk.Notebook):
        super().__init__(nb)
        self.after_id = None
        self.current: Path|None = None
        self._dirty = False
        self._syntax_ok = True
        self.sort = ("ext", True, "name", True)  # multi-sort: ext↑, name↑

        cfg = self._load()
        self.workspace = tk.StringVar(value=cfg.get("workspace", str(ROOT)))
        self.target    = tk.StringVar(value=cfg.get("target",   str(ROOT/"tools")))
        self.ext       = tk.StringVar(value=cfg.get("ext", ".py"))
        self.name      = tk.StringVar(value=cfg.get("name", f"snippet_{time.strftime('%Y%m%d_%H%M%S')}"))
        self.filter    = tk.StringVar(value=cfg.get("filter", ""))
        self.status    = tk.StringVar(value="Bereit.")
        self.split     = float(cfg.get("split", "0.60"))
        self.colw      = cfg.get("colw", "280,70,180,110,90")

        self._style()
        self._build()
        self._refresh()

    # ---- cfg ----
    def _load(self)->dict:
        p = Path.cwd()/INI
        if p.exists():
            try:
                c=configparser.ConfigParser(); c.read(p, encoding="utf-8")
                return dict(c.items("dev")) if c.has_section("dev") else {}
            except Exception: _log("INI_READ_FAIL","")
        return {}
    def _save(self):
        try:
            cols = ("name","ext","subfolder","date","time")
            c=configparser.ConfigParser()
            c["dev"]={
                "workspace": self.workspace.get(),
                "target":    self.target.get(),
                "ext":       self.ext.get(),
                "name":      self.name.get(),
                "filter":    self.filter.get(),
                "split":     f"{self.split:.2f}",
                "colw":      ",".join(str(self.tree.column(x, option="width")) for x in cols),
                "sort":      ",".join(map(str,self.sort)),
            }
            with (Path.cwd()/INI).open("w",encoding="utf-8",newline="\n") as f: c.write(f)
        except Exception as e: _log("INI_WRITE_FAIL",str(e))

    # ---- style ----
    def _style(self):
        if DevIntake._STYLE: return
        st=ttk.Style()
        st.configure("DevToolbar.TButton", padding=4)
        st.map("DevToolbar.TButton", background=[("active", st.lookup("TButton","background"))])
        st.configure("DevEntry.TEntry", fieldbackground="#fff")
        DevIntake._STYLE=True

    # ---- UI ----
    def _build(self):
        PADX,PADY=8,6

        top=ttk.Frame(self); top.grid(row=0,column=0,sticky="we",padx=PADX,pady=(PADY,4))
        ttk.Label(top,text="Workspace:").grid(row=0,column=0,sticky="w")
        ttk.Entry(top,textvariable=self.workspace, width=40, style="DevEntry.TEntry").grid(row=0,column=1,sticky="we",padx=(4,4))
        ttk.Button(top,text="…",width=3,style="DevToolbar.TButton",command=self._pick_ws).grid(row=0,column=2,padx=(0,12))
        ttk.Label(top,text="Name:").grid(row=0,column=3,sticky="w")
        ttk.Entry(top,textvariable=self.name,width=28,style="DevEntry.TEntry").grid(row=0,column=4,sticky="we",padx=(4,12))
        ttk.Label(top,text="Endung:").grid(row=0,column=5,sticky="w")
        ttk.Combobox(top,textvariable=self.ext,values=[".py",".bat",".txt"],width=6,state="readonly").grid(row=0,column=6,sticky="w",padx=(4,12))
        ttk.Label(top,text="Zielordner:").grid(row=0,column=7,sticky="e")
        ttk.Entry(top,textvariable=self.target,width=36,style="DevEntry.TEntry").grid(row=0,column=8,sticky="we",padx=(4,4))
        ttk.Button(top,text="…",width=3,style="DevToolbar.TButton",command=self._pick_target).grid(row=0,column=9)
        for c in (1,4,8): top.columnconfigure(c,weight=1,minsize=120)

        bar=ttk.Frame(self); bar.grid(row=1,column=0,sticky="we",padx=PADX,pady=(0,4))
        for i in range(5): bar.columnconfigure(i,weight=1)
        def group(col,text):
            frm=ttk.Labelframe(bar,text=text); frm.grid(row=0,column=col,sticky="we",padx=(0 if col==0 else 8,8))
            return frm

        g1=group(0,"Datei")
        ttk.Button(g1,text="Neu",            width=12,style="DevToolbar.TButton",command=self._new).grid(row=0,column=0,padx=2,pady=6)
        ttk.Button(g1,text="Einfügen",       width=12,style="DevToolbar.TButton",command=self._insert).grid(row=0,column=1,padx=2,pady=6)
        ttk.Button(g1,text="Speichern",      width=12,style="DevToolbar.TButton",command=self._save).grid(row=0,column=2,padx=2,pady=6)
        ttk.Button(g1,text="Speichern als…", width=14,style="DevToolbar.TButton",command=self._save_as).grid(row=0,column=3,padx=2,pady=6)

        g2=group(1,"Analyse")
        ttk.Button(g2,text="Erkennen (Strg+I)",width=18,style="DevToolbar.TButton",command=self._detect).grid(row=0,column=0,padx=2,pady=6)
        ttk.Button(g2,text="Guard",           width=10,style="DevToolbar.TButton",command=self._guard).grid(row=0,column=1,padx=2,pady=6)
        ttk.Button(g2,text="Repair",          width=10,style="DevToolbar.TButton",command=self._repair).grid(row=0,column=2,padx=2,pady=6)

        g3=group(2,"Ausführen")
        ttk.Button(g3,text="Run (F5)",      width=12,style="DevToolbar.TButton",command=self._run).grid(row=0,column=0,padx=2,pady=6)
        ttk.Button(g3,text="Ordner öffnen", width=16,style="DevToolbar.TButton",command=self._open_target).grid(row=0,column=1,padx=2,pady=6)
        ttk.Button(g3,text="Explorer",      width=12,style="DevToolbar.TButton",command=lambda:_open_explorer(Path(self.target.get()))).grid(row=0,column=2,padx=2,pady=6)

        g4=group(3,"Verwaltung")
        ttk.Button(g4,text="Aktualisieren",  width=14,style="DevToolbar.TButton",command=self._refresh).grid(row=0,column=0,padx=2,pady=6)
        ttk.Button(g4,text="Pack speichern", width=16,style="DevToolbar.TButton",command=self._pack).grid(row=0,column=1,padx=2,pady=6)
        ttk.Button(g4,text="Löschen",        width=10,style="DevToolbar.TButton",command=self._delete).grid(row=0,column=2,padx=2,pady=6)

        leds=ttk.Frame(bar); leds.grid(row=0,column=4,sticky="e",padx=(8,0))
        self.led_dirty  = StatusLED(leds,"Änderungsstatus");  self.led_dirty.pack(side="left",padx=2)
        self.led_syntax = StatusLED(leds,"Syntaxstatus");     self.led_syntax.pack(side="left",padx=2)
        self.led_name   = StatusLED(leds,"Name erkannt");     self.led_name.pack(side="left",padx=2)
        self.led_ext    = StatusLED(leds,"Endung erkannt");   self.led_ext.pack(side="left",padx=2)
        self.led_ok     = StatusLED(leds,"Alles OK");         self.led_ok.pack(side="left",padx=2)

        fl=ttk.Frame(self); fl.grid(row=2,column=0,sticky="we",padx=PADX,pady=(0,4))
        ttk.Label(fl,text="Filter (z. B. name:runner ext:py):").grid(row=0,column=0,sticky="w")
        ttk.Entry(fl,textvariable=self.filter,width=46,style="DevEntry.TEntry").grid(row=0,column=1,sticky="we",padx=(4,10))
        ttk.Button(fl,text="Anwenden",style="DevToolbar.TButton",command=self._refresh).grid(row=0,column=2)
        fl.columnconfigure(1,weight=1)

        split=ttk.Panedwindow(self,orient="horizontal"); split.grid(row=3,column=0,sticky="nsew",padx=PADX,pady=(0,PADY))
        self.left=ttk.Frame(split); self.right=ttk.Frame(split)
        split.add(self.left,weight=int(self.split*100)); split.add(self.right,weight=int((1-self.split)*100))
        self.splitw=split

        self.editor=tk.Text(self.left,wrap="none",undo=True)
        self.editor.pack(fill="both",expand=True)
        self.editor.bind("<<Modified>>",self._on_mod)
        ttk.Scrollbar(self.left,orient="vertical",command=self.editor.yview).pack(side="right",fill="y")
        ttk.Scrollbar(self.left,orient="horizontal",command=self.editor.xview).pack(side="bottom",fill="x")
        self.editor.configure(yscrollcommand=lambda *a: None, xscrollcommand=lambda *a: None, selectbackground="#cfe8ff",selectforeground="#000")

        cols=("name","ext","subfolder","date","time")
        widths=[int(x) for x in self.colw.split(",")] if self.colw else [280,70,180,110,90]
        self.tree=ttk.Treeview(self.right,columns=cols,show="headings",selectmode="browse")
        for c,w in zip(cols,widths):
            self.tree.heading(c,text=c,command=lambda col=c: self._sort_toggle(col))
            self.tree.column(c,width=w,anchor="w")
        self.tree.tag_configure("even",background="#f6f6f6")
        self.tree.tag_configure("odd", background="#ffffff")
        self.tree.pack(fill="both",expand=True)
        self.tree.bind("<<TreeviewSelect>>",self._on_select)
        self.tree.bind("<Double-1>",self._open_current)
        self.tree.bind("<F2>",lambda e:self._rename())
        self.tree.bind("<Button-3>",self._popup)

        self.menu=tk.Menu(self,tearoff=0)
        self.menu.add_command(label="Run",command=self._run)
        self.menu.add_command(label="Rename (F2)",command=self._rename)
        self.menu.add_command(label="Delete",command=self._delete)
        self.menu.add_separator()
        self.menu.add_command(label="Explorer",command=self._open_target)

        ttk.Label(self,textvariable=self.status,anchor="w").grid(row=4,column=0,sticky="we",padx=PADX)
        self.grid_rowconfigure(3,weight=1); self.grid_columnconfigure(0,weight=1)

        self.bind_all("<Control-s>",lambda e:self._save())
        self.bind_all("<Control-i>",lambda e:self._detect())
        self.bind_all("<F5>",       lambda e:self._run())
        self.after(200,self._capture_split)
        self._update_leds()

    # ---- Events/Helper ----
    def _capture_split(self):
        try:
            total=self.splitw.winfo_width() or 1
            self.split=max(0.2,min(0.8,self.left.winfo_width()/total))
        finally:
            self.after(800,self._capture_split)

    def _popup(self,e):
        iid=self.tree.identify_row(e.y)
        if iid: self.tree.selection_set(iid)
        self.menu.tk_popup(e.x_root,e.y_root); self.menu.grab_release()

    def _on_mod(self,_=None):
        if self.editor.edit_modified():
            self._dirty=True; self.editor.edit_modified(False); self._update_leds()

    def _pick_ws(self):
        d=filedialog.askdirectory(title="Workspace wählen",initialdir=self.workspace.get())
        if d: self.workspace.set(d); self._save()

    def _pick_target(self):
        d=filedialog.askdirectory(title="Zielordner wählen",initialdir=self.target.get())
        if d: self.target.set(d); self._save(); self._refresh()

    def _open_target(self): _open_explorer(Path(self.target.get()))
    def _open_current(self,_=None): self._on_select()

    def _new(self):
        self.editor.delete("1.0","end")
        self.name.set(f"snippet_{time.strftime('%Y%m%d_%H%M%S')}")
        self._dirty=False; self._update_leds(); self.status.set("Editor geleert.")

    def _detect(self):
        src=self.editor.get("1.0","end-1c")
        if not src.strip(): self.status.set("Nichts zu erkennen."); return
        ext=_detect_ext(src)
        nm=None
        for line in src.splitlines():
            s=line.strip()
            if not s or s.startswith("#") or s.lower().startswith(("rem","::")): continue
            m=re.search(r"(Runner_[0-9]{3,5}_[A-Za-z0-9_]+)", s)
            if m: nm=m.group(1); break
        if not nm: nm=f"snippet_{time.strftime('%Y%m%d_%H%M%S')}"
        self._syntax_ok=True
        if ext==".py":
            try: compile(src,"<intake>","exec")
            except Exception as e:
                self._syntax_ok=False
                line=getattr(e,"lineno",None); self._hilite_err(line)
        self.ext.set(ext); self.name.set(nm); self._update_leds()
        self.status.set(f"Erkannt: {nm}{ext}")

    def _path(self)->Path:
        d=Path(self.target.get() or (ROOT/"tools")); d.mkdir(parents=True,exist_ok=True)
        return d / f"{(self.name.get() or 'snippet')}{(self.ext.get() or '.py')}"

    def _hilite_err(self,line:int|None):
        try: self.editor.tag_delete("errline")
        except: pass
        if not line: return
        self.editor.tag_configure("errline",background="#ffd6d6")
        self.editor.tag_add("errline",f"{line}.0",f"{line}.0 lineend")
        self.editor.see(f"{line}.0")

    def _insert(self):
        p=self._path()
        if p.exists() and not messagebox.askyesno("Überschreiben?", f"{p.name} existiert. Überschreiben?"): return
        try:
            p.write_text(self.editor.get("1.0","end-1c"),encoding="utf-8")
            self.current=p; self._dirty=False; self._refresh(select=p); self._update_leds()
            self.status.set(f"Eingefügt: {p.name}")
        except Exception as e:
            messagebox.showerror("Einfügen",str(e)); _log("INSERT_FAIL",str(e))

    def _save(self):
        if self.current is None: self._insert(); return
        try:
            self.current.write_text(self.editor.get("1.0","end-1c"),encoding="utf-8")
            self._dirty=False; self._refresh(select=self.current); self._update_leds()
            self.status.set(f"Gespeichert: {self.current.name}")
        except Exception as e:
            messagebox.showerror("Speichern",str(e)); _log("SAVE_FAIL",str(e))

    def _save_as(self):
        p=self._path()
        try:
            p.write_text(self.editor.get("1.0","end-1c"),encoding="utf-8")
            self.current=p; self._dirty=False; self._refresh(select=p); self._update_leds()
            self.status.set(f"Gespeichert als: {p.name}")
        except Exception as e:
            messagebox.showerror("Speichern als",str(e)); _log("SAVEAS_FAIL",str(e))

    def _parse_filter(self,s:str):
        d={'name':None,'ext':None,'sub':None}; raw=[]
        for tok in (s or '').split():
            if ":" in tok:
                k,v=tok.split(":",1)
                if k in d: d[k]=v.lower(); continue
            raw.append(tok.lower())
        return d,raw

    def _refresh(self, select:Path|None=None):
        self.tree.delete(*self.tree.get_children())
        root=Path(self.target.get() or (ROOT/"tools")); root.mkdir(parents=True,exist_ok=True)
        fdict,raw=self._parse_filter(self.filter.get())
        items=[]
        for p in root.rglob("*"):
            if not p.is_file(): continue
            name_l=p.name.lower(); sub_l=(str(p.parent.relative_to(root)).lower() if p.parent!=root else "")
            if fdict['name'] and fdict['name'] not in name_l: continue
            if fdict['ext'] and fdict['ext']!=(p.suffix.lower().lstrip('.') or ''): continue
            if fdict['sub'] and fdict['sub'] not in sub_l: continue
            if raw and not all(any(t in x for x in (name_l, sub_l)) for t in raw): continue
            sub=str(p.parent.relative_to(root)) if p.parent!=root else ""
            date,tm=_fmt(p.stat().st_mtime)
            items.append((p, p.stem, p.suffix, sub, date, tm))
        # Multi-Sort
        def keyfun(t):
            mapping={"name":1,"ext":2,"subfolder":3,"date":4,"time":5}
            k1,asc1,k2,asc2=self.sort
            a=t[mapping[k1]] or ""; b=t[mapping[k2]] or ""
            return (a if asc1 else ("\xff"+a)), (b if asc2 else ("\xff"+b))
        items.sort(key=keyfun)
        for i,(p,stem,ext,sub,date,tm) in enumerate(items):
            tag="even" if i%2==0 else "odd"
            self.tree.insert("", "end", iid=str(p), values=(stem,ext,sub,date,tm), tags=(tag,))
        if select and self.tree.exists(str(select)): self.tree.selection_set(str(select))
        self.status.set(f"{len(items)} Datei(en) in {root}")
        self._save()

    def _sort_toggle(self,col:str):
        # toggle primary key; keep secondary = name
        cur1,asc1,cur2,asc2=self.sort
        if col==cur1: self.sort=(cur1, not asc1, cur2, asc2)
        else: self.sort=(col, True, "name", True)
        self._refresh(select=self.current)

    def _on_select(self,_=None):
        sel=self.tree.selection()
        if not sel: return
        p=Path(sel[0])
        try:
            txt=p.read_text(encoding="utf-8",errors="replace")
            self.editor.delete("1.0","end"); self.editor.insert("1.0",txt)
            self.current=p; self.name.set(p.stem); self.ext.set(p.suffix or ".txt"); self.target.set(str(p.parent))
            self._dirty=False; self._save(); self._update_leds()
            self.status.set(f"Geladen: {p}")
        except Exception as e:
            messagebox.showerror("Laden",str(e)); _log("LOAD_FAIL",str(e))

    def _rename(self):
        if not self.current or not self.current.exists():
            messagebox.showinfo("Rename","Keine Datei ausgewählt."); return
        p=self.current
        new=simpledialog.askstring("Rename", f"Neuer Name ohne Endung ({p.suffix} bleibt):", initialvalue=p.stem)
        if not new: return
        target=p.with_name(new + (p.suffix or ""))
        try:
            if target.exists() and not messagebox.askyesno("Überschreiben?", f"{target.name} existiert. Überschreiben?"): return
            p.rename(target); self.current=target; self.name.set(target.stem)
            self._refresh(select=target); self.status.set(f"Umbenannt: {target.name}")
        except Exception as e:
            messagebox.showerror("Rename",str(e)); _log("RENAME_FAIL",str(e))

    def _run(self):
        p=self.current
        if not p or not p.exists(): messagebox.showinfo("Run","Keine Datei ausgewählt."); return
        if p.suffix==".py": _run_console(["py","-3","-u",str(p)])
        elif p.suffix==".bat": _run_console([str(p)])
        else: messagebox.showinfo("Run","Nur .py/.bat werden ausgeführt.")

    def _guard(self):
        p=self.current
        if not p or not p.exists(): messagebox.showinfo("Guard","Keine Datei ausgewählt."); return
        if p.suffix!=".py": messagebox.showinfo("Guard","Guard prüft nur .py"); return
        src=self.editor.get("1.0","end-1c")
        try:
            compile(src,p.name,"exec")
            self._syntax_ok=True; self._hilite_err(None)
            messagebox.showinfo("Guard","Syntax OK.")
        except SyntaxError as e:
            self._syntax_ok=False; self._hilite_err(getattr(e,"lineno",None))
            messagebox.showerror("Guard", f"Syntaxfehler: Zeile {getattr(e,'lineno', '?')}\n{e.msg}")
        except Exception as e:
            self._syntax_ok=False; messagebox.showerror("Guard", str(e))
        self._update_leds()

    def _repair(self):
        p=self.current
        if not p or not p.exists(): return
        try:
            txt=p.read_text(encoding="utf-8",errors="replace")
            txt2=txt.replace("\r\r\n","\r\n")
            if txt2!=txt: p.write_text(txt2,encoding="utf-8",newline="\r\n")
            messagebox.showinfo("Repair","Normalisierung angewendet.")
        except Exception as e:
            messagebox.showerror("Repair",str(e))

    def _delete(self):
        p=self.current
        if not p or not p.exists(): messagebox.showinfo("Löschen","Keine Datei ausgewählt."); return
        if not messagebox.askyesno("Löschen",f"{p.name} wirklich löschen?"): return
        try:
            p.unlink(); self.current=None; self.editor.delete("1.0","end")
            self._refresh(); self._dirty=False; self._update_leds(); self.status.set("Datei gelöscht.")
        except Exception as e:
            messagebox.showerror("Löschen",str(e)); _log("DELETE_FAIL",str(e))

    def _update_leds(self):
        name_ok=bool((self.name.get() or "").strip())
        ext_ok =bool((self.ext.get()  or "").strip())
        ok_all=bool(name_ok and ext_ok and self._syntax_ok and (not self._dirty))
        self.led_dirty.set(self._dirty,  "Geändert" if self._dirty else "Unverändert")
        self.led_syntax.set(self._syntax_ok, "Syntax OK" if self._syntax_ok else "Syntaxfehler")
        self.led_name.set(name_ok, "Name OK" if name_ok else "Name fehlt")
        self.led_ext.set(ext_ok,  "Endung OK" if ext_ok else "Endung fehlt")
        self.led_ok.set(ok_all,   "Alles OK" if ok_all else "Nicht OK")

# ---- Shim-Entry ----
def create_intake_tab(nb: ttk.Notebook) -> None:
    try:
        frame=DevIntake(nb); nb.add(frame,text="Intake")
    except Exception:
        f=ttk.Frame(nb)
        ttk.Label(f,text="Intake – Fehler beim Laden. Log prüfen.",foreground="red").pack(padx=12,pady=12,anchor="w")
        nb.add(f,text="Intake")
        traceback.print_exc()

# -------- Writer --------
def write():
    MOD.parent.mkdir(parents=True,exist_ok=True)
    MOD.write_text(Path(__file__).read_text(encoding="utf-8").split("'''",2)[2], encoding="utf-8", newline="\n")
    print("[R1192] module_code_intake.py written.")
    return 0

if __name__=="__main__":
    sys.exit(write())
