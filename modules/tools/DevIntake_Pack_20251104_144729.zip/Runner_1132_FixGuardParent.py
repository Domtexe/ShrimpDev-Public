#!/usr/bin/env python3
"""
Runner_1132_FixGuardParent
- Repariert den Parent des Guard-Buttons im Intake-Toolbar-Bereich.
- Setzt Parent auf 'bar' (vorhandenes Toolbar-Frame).
- Legt Button bei Bedarf an.
- Fallback: fügt _on_click_guard() Dummy hinzu, falls Methode fehlt.
- Backup + Syntaxprüfung + Ergebnisbericht.

Konform zu ShrimpHub-Standard:
- Keine globalen Seiteneffekte außerhalb Patch.
- Backups nach _Archiv\module_code_intake.py.<ts>.bak
- Logs nach _Reports\
"""
from __future__ import annotations
import re
import time
import os
import sys
import pathlib
import traceback
import importlib.util
import ast

ROOT = pathlib.Path(__file__).resolve().parents[1]
MOD_PATH = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
REPO = ROOT / "_Reports"
ARCH.mkdir(exist_ok=True)
REPO.mkdir(exist_ok=True)
REPORT = REPO / "Runner_1132_FixGuardParent_report.txt"

def write_report(text: str) -> None:
    REPORT.parent.mkdir(exist_ok=True)
    with open(REPORT, "a", encoding="utf-8") as f:
        f.write(text.rstrip() + "\n")

def backup(src: pathlib.Path) -> pathlib.Path:
    ts = str(int(time.time()))
    dst = ARCH / f"{src.name}.{ts}.bak"
    dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    write_report(f"[Backup] {src} -> {dst}")
    return dst

def syntax_ok(code: str) -> tuple[bool, str]:
    try:
        ast.parse(code, filename=str(MOD_PATH))
        return True, ""
    except SyntaxError as e:
        return False, f"{e.__class__.__name__}: {e.msg} (line {e.lineno}, col {e.offset})"

def ensure_guard_method(code: str) -> tuple[str, bool]:
    """
    Prüft, ob innerhalb class IntakeFrame eine Methode _on_click_guard(self, *_)
    existiert. Wenn nicht, fügt sie am Klassenende (vor letzter Klasse/EOF) eine
    minimal-funktionale Variante ein.
    """
    # Grob die Klasse IntakeFrame abgrenzen
    cls_pat = re.compile(r"(?ms)class\s+IntakeFrame\([^)]*\)\s*:(?P<body>.*?)(?=^\s*class\s+|\Z)")
    m = cls_pat.search(code)
    if not m:
        raise RuntimeError("class IntakeFrame nicht gefunden – Abbruch.")
    body = m.group("body")
    if re.search(r"(?m)^\s*def\s+_on_click_guard\s*\(", body):
        return code, False

    # Einfache Logger-Hilfe suchen
    has_ping = re.search(r"(?m)^\s*def\s+_ping\s*\(", body) is not None

    # Einrückung der Klasse bestimmen
    # Wir hängen die Methode am Ende des Klassenkörpers an (vor Match-Ende).
    indent = " " * 4  # IntakeFrame benutzt in deinen Files 4er Spaces
    stub = [
        "",
        f"{indent}def _on_click_guard(self, _evt=None):",
        f"{indent*2}\"\"\"Fallback-Guard: Nur Ping/No-Op, damit die UI lädt.\"\"\"",
    ]
    if has_ping:
        stub.append(f"{indent*2}try:")
        stub.append(f"{indent*3}self._ping('Guard ausgefuehrt (Fallback)')")
        stub.append(f"{indent*2}except Exception:")
        stub.append(f"{indent*3}pass")
    else:
        stub.append(f"{indent*2}pass")
    stub.append("")

    new_body = body + "\n" + "\n".join(stub)
    new_code = code[:m.start("body")] + new_body + code[m.end("body"):]
    write_report("[Patch] _on_click_guard hinzugefügt (Fallback).")
    return new_code, True

def patch_guard_parent(code: str) -> tuple[str, bool, str]:
    """
    Sucht innerhalb _build_ui() nach Guard-Button:
        self.btn_guard = ttk.Button(self.frm_actions, ...)
    und ersetzt Parent 'self.frm_actions' durch 'bar'.
    Falls der Button fehlt, wird er nach lbl_ping angelegt.
    """
    # Klasse/Build-Bereich finden
    class_pat = re.compile(r"(?ms)class\s+IntakeFrame\([^)]*\)\s*:(?P<body>.*?)(?=^\s*class\s+|\Z)")
    mclass = class_pat.search(code)
    if not mclass:
        raise RuntimeError("class IntakeFrame nicht gefunden – Abbruch.")
    body = mclass.group("body")

    build_pat = re.compile(r"(?ms)def\s+_build_ui\s*\([^)]*\)\s*:(?P<build>.*?)(?=^\s*def\s+|\Z)")
    mb = build_pat.search(body)
    if not mb:
        raise RuntimeError("def _build_ui(...) nicht gefunden – Abbruch.")
    build = mb.group("build")

    changed = False
    msg = ""

    # 1) Parent-Tausch, falls vorhanden
    before = build
    build = re.sub(
        r"(self\.btn_guard\s*=\s*ttk\.Button\()\s*self\.frm_actions(\s*,)",
        r"\1bar\2",
        build
    )
    if build != before:
        changed = True
        msg += "[Patch] Parent self.frm_actions -> bar\n"

    # 2) Button anlegen, falls nicht vorhanden
    if "self.btn_guard" not in build:
        # Suche sinnvolle Insert-Position: nach lbl_ping.grid(...) in Toolbar
        anchor_pat = re.compile(r"(?m)^\s*self\.lbl_ping\s*=\s*ttk\.Label\(.*\)\s*;?\s*self\.lbl_ping\.grid\(.*\)\s*$")
        ma = anchor_pat.search(build)
        if not ma:
            # alternative: nach self.btn_del.grid(...):
            anchor_pat = re.compile(r"(?m)^\s*self\.btn_del\.grid\(.*\)\s*$")
            ma = anchor_pat.search(build)
        if ma:
            indent = re.match(r"^\s*", ma.group(0)).group(0)
            inject = (
                f"\n{indent}# Guard-Button (zentral auf Toolbar)\n"
                f"{indent}self.btn_guard = ttk.Button(bar, text=\"Prüfen (Guard)\", command=self._on_click_guard)\n"
                f"{indent}self.btn_guard.grid(row=0, column=99, padx=(4,0))\n"
            )
            build = build[:ma.end()] + inject + build[ma.end():]
            changed = True
            msg += "[Patch] Guard-Button hinzugefügt (Parent=bar)\n"
        else:
            msg += "[Hinweis] Keine geeignete Insert-Position gefunden – Button existiert evtl. bereits an anderer Stelle.\n"

    # 3) Zusammenfügen
    new_body = body[:mb.start("build")] + build + body[mb.end("build"):]
    new_code = code[:mclass.start("body")] + new_body + code[mclass.end("body"):]
    return new_code, changed, msg or "[Info] Keine Änderungen nötig."

def main() -> int:
    try:
        if not MOD_PATH.exists():
            write_report(f"[FEHLER] Datei fehlt: {MOD_PATH}")
            print("[R1132] Modul nicht gefunden.")
            return 2

        src = MOD_PATH.read_text(encoding="utf-8")

        # Sicherung
        backup(MOD_PATH)

        # Guard-Methode sicherstellen (nur falls fehlt)
        code1, added_guard = ensure_guard_method(src)

        # Parent/Einfügung patchen
        code2, changed, note = patch_guard_parent(code1)

        # Nur schreiben, wenn sich etwas geändert hat
        if (code2 != src):
            ok, err = syntax_ok(code2)
            if not ok:
                write_report(f"[FEHLER] Syntax nach Patch: {err}")
                print("[R1132] SyntaxError nach Patch – Rollback.")
                return 1
            MOD_PATH.write_text(code2, encoding="utf-8")
            write_report(note.strip())
            if added_guard:
                write_report("[Info] Fallback-Methode _on_click_guard ist jetzt vorhanden.")
            write_report("[OK] Patch geschrieben und Syntax geprüft.")
            print("[R1132] Patch OK.")
            return 0
        else:
            write_report("[OK] Keine Änderungen nötig (bereits korrigiert).")
            print("[R1132] Keine Änderungen nötig.")
            return 0

    except Exception as ex:
        tb = traceback.format_exc()
        write_report("[CRASH]\n" + tb)
        print("[R1132] Laufzeitfehler – Details im Report.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
