# -*- coding: utf-8 -*-
"""
Runner_1098_FixIntake_ReindentClassBlocks.py
Repariert verrutschte Einrückungen in modules/module_code_intake.py:
 - _show/_hide in class Tooltip
 - alle IntakeFrame-Methoden bis vor den R1089-Helper-Marker
Safe: schreibt nur, wenn Syntax-Check OK ist. Backup wird angelegt.
"""

import io, os, sys, time, re

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")

def log(msg): print(f"[R1098] {msg}")

def backup(path):
    os.makedirs(ARCH, exist_ok=True)
    b = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "rb") as fsrc, open(b, "wb") as fdst:
        fdst.write(fsrc.read())
    log(f"Backup: {path} -> {b}")
    return b

def compile_sanity(src_text):
    import builtins
    code = compile(src_text, MOD, "exec")
    return code  # just to prove it compiles

def add_indent_block(lines, start_idx, end_idx, add="    "):
    """Indent every non-empty line between start_idx (inclusive) and end_idx (exclusive) by 'add'."""
    for i in range(start_idx, end_idx):
        ln = lines[i]
        if ln.strip():  # keep blank lines as-is
            lines[i] = add + ln
    return lines

def find_index(lines, pattern, start=0):
    rx = re.compile(pattern)
    for i in range(start, len(lines)):
        if rx.search(lines[i]):
            return i
    return -1

def fix_tooltip(lines):
    """Ensure def _show/_hide are indented inside class Tooltip."""
    i_cls = find_index(lines, r'^\s*class\s+Tooltip\s*:')
    if i_cls < 0:
        return False
    # Block endet vor nächster class/def auf Spalte 0 oder vor _open_explorer_select
    i_after = i_cls + 1
    changed = False
    while i_after < len(lines):
        s = lines[i_after]
        if re.match(r'^\s*def\s+_open_explorer_select\(', s):  # nächster Block
            break
        if re.match(r'^\s*def\s+_(show|hide)\s*\(', s):  # auf Spalte 0? -> einrücken
            if not s.startswith("    "):
                lines[i_after] = "    " + s
                changed = True
        elif s.strip() and not s.startswith(" "):  # irgendwas Nicht-Leeres auf Spalte 0 -> rücke ein
            # hier sind meist die method bodies der Tooltip-Methoden
            lines[i_after] = "    " + s
            changed = True
        i_after += 1
    return changed

def fix_intakeframe(lines):
    """Indent everything between 'class IntakeFrame' and first '# --- R1089' marker by 4 spaces, preserving relative indent."""
    i_cls = find_index(lines, r'^\s*class\s+IntakeFrame\b')
    if i_cls < 0:
        return False, "IntakeFrame nicht gefunden."
    i_start = i_cls + 1

    # Ende = erster R1089-Marker ODER Recycle-Bin-Header, was zuerst kommt
    i_end = find_index(lines, r'^\s*#\s*---\s*R1089\b', start=i_start)
    if i_end < 0:
        i_end = find_index(lines, r'^\s*#\s*---\s*R10\d{2}:\s*Windows\s+Recycle\s+Bin', start=i_start)
    if i_end < 0:
        # wenn kein Marker existiert: bis vor 'def _send_to_recycle_bin' oder Dateiende
        i_rb = find_index(lines, r'^\s*def\s+_send_to_recycle_bin\(', start=i_start)
        i_end = i_rb if i_rb >= 0 else len(lines)

    if i_end <= i_start:
        return False, "Markerbereich nicht gefunden."

    # Prüfe, ob bereits eingerückt ist (heuristisch: ob mind. 1 def in dem Bereich auf Spalte 0 steht)
    needs = any(re.match(r'^def\s+\w', lines[i]) for i in range(i_start, i_end))
    if not needs:
        return False, "Bereich wirkt bereits eingerückt."

    add_indent_block(lines, i_start, i_end, add="    ")
    return True, None

def main():
    if not os.path.exists(MOD):
        log(f"Datei nicht gefunden: {MOD}")
        return 2

    with io.open(MOD, "r", encoding="utf-8") as f:
        src0 = f.read()
    lines = src0.splitlines(True)

    changed = False
    if fix_tooltip(lines):
        changed = True
        log("Tooltip-Methoden (_show/_hide) eingerückt.")

    ok, why = fix_intakeframe(lines)
    if ok:
        changed = True
        log("IntakeFrame-Block eingerückt (bis vor R1089-Helper).")
    else:
        log(f"IntakeFrame: kein Einrückbedarf erkannt ({why}).")

    if not changed:
        log("Keine Änderungen nötig.")
        return 0

    new_src = "".join(lines)

    # Sanity-Compile vor dem Schreiben
    try:
        compile_sanity(new_src)
    except Exception as ex:
        log(f"SyntaxError nach Fix: {ex.__class__.__name__}: {ex}")
        log("Syntaxprüfung fehlgeschlagen – Datei bleibt unverändert.")
        return 1

    backup(MOD)
    with io.open(MOD, "w", encoding="utf-8", newline="") as f:
        f.write(new_src)
    log("Reindent angewendet und gespeichert.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
