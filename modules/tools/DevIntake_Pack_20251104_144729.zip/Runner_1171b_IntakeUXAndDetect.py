# -*- coding: utf-8 -*-
"""
Runner_1171b_IntakeUXAndDetect
– Fix für 1171a: keine f-Strings im Helper-Block -> keine { }-Interpolation.
– Fügt UX-/Detect-Helper in modules/module_code_intake.py ein
– Aktiviert sie am Ende von _build_ui(self)
– Idempotent, Backup + Syntax-Check + Rollback
Exit: 0 OK, 1 Fehler
"""
from __future__ import annotations
import os, re, time, py_compile, traceback

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOG    = os.path.join(ROOT, "debug_output.txt")

MARK_BLOCK   = "# R1171a: helpers (UX & detect)"
MARK_LIFECYC = "# R1171a: lifecycle enable"

# --- Helper-Code als PLAIN-String (keine f-Strings!) ---
HELPERS = """
__MARK_BLOCK__
def _r1171a__strip_shortcut_suffix(txt: str) -> str:
    import re
    return re.sub(r"\\s*\\([^)]*\\)\\s*$", "", txt or "")

def _r1171a__tooltip(widget, text: str):
    try:
        import tkinter as tk
        from tkinter import Toplevel, Label
        def on_enter(_):
            try:
                w = Toplevel(widget); w.wm_overrideredirect(True)
                x = widget.winfo_rootx() + 10
                y = widget.winfo_rooty() + widget.winfo_height() + 6
                w.geometry(f"+{x}+{y}")
                lbl = Label(w, text=text, background="#ffffe0", relief="solid", borderwidth=1)
                lbl.pack(ipadx=6, ipady=3)
                widget._r1171a_tip = w
            except Exception:
                pass
        def on_leave(_):
            try:
                w = getattr(widget, "_r1171a_tip", None)
                if w: w.destroy()
            except Exception:
                pass
            widget._r1171a_tip = None
        widget.bind("<Enter>", on_enter); widget.bind("<Leave>", on_leave)
    except Exception:
        pass

def _intake_actions_bar_polish(self):
    \"\"\"Ordnet Buttons sauber; Status rechts; Tooltips mit Shortcuts.\"\"\"
    try:
        from tkinter import ttk
    except Exception:
        return
    try:
        btn_names = [n for n in dir(self) if n.startswith("btn_")]
        buttons = []
        parent = None
        for n in sorted(btn_names):
            try:
                b = getattr(self, n)
                if hasattr(b, "winfo_exists") and b.winfo_exists():
                    buttons.append((n, b))
                    if parent is None:
                        parent = b.nametowidget(b.winfo_parent())
            except Exception:
                pass
        if not parent and hasattr(self, "frm_actions"):
            parent = getattr(self, "frm_actions", None)
        if not parent:
            return
        try:
            for i in range(0, 20):
                try: parent.columnconfigure(i, weight=0)
                except Exception: pass
            parent.columnconfigure(19, weight=1)
        except Exception:
            pass
        col = 0
        for n, b in buttons:
            try:
                try:
                    b.configure(text=_r1171a__strip_shortcut_suffix(b.cget("text")))
                except Exception:
                    pass
                try:
                    b.grid(row=0, column=col, padx=(0, 6), sticky="w")
                except Exception:
                    pass
                col += 1
            except Exception:
                pass
        lbl = getattr(self, "lbl_ping", None)
        if lbl is None:
            try:
                lbl = ttk.Label(parent, text="", anchor="w")
                self.lbl_ping = lbl
            except Exception:
                lbl = None
        if lbl:
            try:
                lbl.grid(row=0, column=19, sticky="ew", padx=(12, 0))
            except Exception:
                pass
        try:
            style = ttk.Style()
            style.configure("TButton", padding=(10, 4))
        except Exception:
            pass
        try:
            if hasattr(self, "txt"): self.txt.grid_configure(sticky="nsew")
        except Exception: pass
        try:
            if hasattr(self, "tbl"):
                tbl = self.tbl
                try:
                    cols = tbl["columns"] if "columns" in tbl.keys() else ()
                    for c in cols:
                        try: tbl.column(c, stretch=True, minwidth=80, width=120)
                        except Exception: pass
                    tbl.grid_configure(sticky="nsew")
                except Exception:
                    pass
        except Exception:
            pass
        try:
            m = {
                "btn_save"  : "Speichern (Ctrl+S)",
                "btn_detect": "Erkennen  (Ctrl+I)",
                "btn_open"  : "Öffnen    (Ctrl+O)",
                "btn_del"   : "Löschen   (Entf)",
                "btn_clear" : "Löschen   (Entf)",
            }
            for name, tip in m.items():
                b = getattr(self, name, None)
                if b: _r1171a__tooltip(b, tip)
        except Exception:
            pass
    except Exception:
        pass

def _intake_bind_shortcuts(self):
    \"\"\"Bindet Ctrl+S/Ctrl+I/Ctrl+O/Delete ohne Doppeltrigger.\"\""
    try:
        target = getattr(self, "txt", self)
        def _pick(*names):
            for n in names:
                f = getattr(self, n, None)
                if callable(f): return f
            return None
        def _bind(seq, fn):
            try: self.bind(seq,  (lambda e, h=fn: (h(), "break")))
            except Exception: pass
            try: target.bind(seq, (lambda e, h=fn: (h(), "break")))
            except Exception: pass
        save   = _pick("_on_save_clicked", "on_save", "save")
        detect = _pick("_on_detect_clicked", "on_detect", "detect")
        openf  = _pick("_on_open_clicked", "on_open", "open")
        clear  = _pick("_on_clear_clicked", "on_clear", "clear", "_intake_on_clear_editor_clicked")
        if save:   _bind("<Control-s>", save)
        if detect: _bind("<Control-i>", detect)
        if openf:  _bind("<Control-o>", openf)
        if clear:  _bind("<Delete>",    clear)
    except Exception:
        pass

def _intake_setup_detection(self):
    \"\"\"Entprellte Auto-Erkennung; Heuristiken für Endung.\"\""
    try:
        import time
        self._r1171a_detect_job = None
        self._allowed_ext = getattr(self, "_allowed_ext", {".py",".bat",".cmd",".json",".txt",".yml",".yaml",".ini",".md",".shcut"})
        def schedule(ms=250):
            try:
                if self._r1171a_detect_job:
                    self.after_cancel(self._r1171a_detect_job)
            except Exception:
                pass
            self._r1171a_detect_job = self.after(ms, do_detect)
        def do_detect():
            try:
                name = (self.var_name.get() if hasattr(self,"var_name") else "") or ""
                text = self.txt.get("1.0","end-1c") if hasattr(self,"txt") else ""
                ext  = (self.var_ext.get() if hasattr(self,"var_ext") else "").strip().lower()
                manual = bool(getattr(self,"var_ext_manual", False))
                def norm(e):
                    e = (e or "").strip().lower()
                    if not e: return ""
                    return e if e.startswith(".") else "."+e
                ext = norm(ext)
                if not manual:
                    if not ext and "." in name:
                        ext = "." + name.rsplit(".",1)[-1].lower()
                    if not ext:
                        head  = (text or "")[:2000].lower()
                        first = (text.splitlines()[:2] or [""])[0].lower()
                        if first.startswith("#!") and "python" in first:
                            ext = ".py"
                        elif "@echo off" in head or (" %%" in head):
                            ext = ".bat"
                        elif head.strip().startswith(("{","[")):
                            ext = ".json"
                        elif "[section" in head or "=" in head[:200]:
                            ext = ".ini"
                        elif "name:" in head and "jobs:" in head:
                            ext = ".yml"
                        elif "param(" in head and "-join" in head:
                            ext = ".ps1"
                        elif head.startswith("# ") or head.startswith("## "):
                            ext = ".md"
                ok = bool(ext) and (ext in self._allowed_ext)
                if hasattr(self, "var_ext"): self.var_ext.set(ext or "")
                if not getattr(self, "var_name_manual", False) and not (name or "").strip():
                    ts = time.strftime("%Y%m%d_%H%M%S"); base = f"snippet_{ts}"
                    if ext: base += ext
                    if hasattr(self,"var_name"): self.var_name.set(base)
                if hasattr(self, "_update_led"):
                    try: self._update_led(self.led_detect, "green" if ok else "yellow")
                    except Exception: pass
                if hasattr(self, "_ping"):
                    try: self._ping("Erkennung: " + (ext or "(keine)"))
                    except Exception: pass
            except Exception:
                pass
        try:
            if hasattr(self,"txt"):
                self.txt.bind("<<Paste>>",   lambda e: (schedule(150), "break"))
                self.txt.bind("<Key>",       lambda e: (schedule(250), None))
                self.txt.bind("<<Modified>>",lambda e: (self.txt.edit_modified(False), schedule(300)))
        except Exception:
            pass
        schedule(0)
    except Exception:
        pass
"""

LIFECYCLE = """
__MARK_LIFECYC__
    try:
        _intake_actions_bar_polish(self)
    except Exception:
        pass
    try:
        _intake_bind_shortcuts(self)
    except Exception:
        pass
    try:
        _intake_setup_detection(self)
    except Exception:
        pass
"""

def _log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1171b {ts}] {msg}\n"
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def _backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "r", encoding="utf-8") as fi, open(dst, "w", encoding="utf-8", newline="") as fo:
        fo.write(fi.read())
    return dst

def main() -> int:
    try:
        if not os.path.exists(TARGET):
            _log(f"Zieldatei fehlt: {TARGET}")
            return 1
        src = open(TARGET, "r", encoding="utf-8").read()
        changed = False

        # 1) Helper-Blöcke einfügen
        if MARK_BLOCK not in src:
            code = HELPERS.replace("__MARK_BLOCK__", MARK_BLOCK)
            m = re.search(r"(?m)^\\s*#\\s*-{2,}\\s*helpers\\s*-{2,}\\s*$", src)
            insert_at = m.end() if m else len(src)
            src = src[:insert_at] + "\n" + code + src[insert_at:]
            changed = True

        # 2) Lifecycle am Ende von _build_ui(self) anhängen
        if MARK_LIFECYC not in src:
            m = re.search(r"(?m)^([ \\t]*)def[ \\t]+_build_ui[ \\t]*\\(\\s*self[^)]*\\)\\s*:\\s*$", src)
            if not m:
                _log("Konnte 'def _build_ui(self):' nicht finden – Abbruch ohne Änderung.")
                return 1
            base_indent = m.group(1)
            start = m.end()
            pat_end = re.compile(r"(?m)^(%s)(def|class)\\b" % re.escape(base_indent))
            m_end = pat_end.search(src, start)
            end = m_end.start() if m_end else len(src)
            block = ("\n" + base_indent + LIFECYCLE.replace("__MARK_LIFECYC__", MARK_LIFECYC)
                     .replace("\n", "\n"+base_indent))
            new_src = src[:end].rstrip("\n") + block + src[end:]
            src = new_src
            changed = True

        if not changed:
            _log("Keine Änderung notwendig (bereits gepatcht).")
            return 0

        bak = _backup(TARGET)
        _log(f"Backup erstellt: {bak}")
        with open(TARGET, "w", encoding="utf-8", newline="\n") as f:
            f.write(src)

        try:
            py_compile.compile(TARGET, doraise=True)
        except Exception as e:
            with open(bak, "r", encoding="utf-8") as fi, open(TARGET, "w", encoding="utf-8", newline="\n") as fo:
                fo.write(fi.read())
            _log("Syntax-Check FEHLER -> Rollback auf Backup.")
            _log("Traceback:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 1

        _log("Patch erfolgreich eingefügt und Syntax-Check OK.")
        return 0

    except Exception as e:
        _log("UNERWARTETER FEHLER:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
