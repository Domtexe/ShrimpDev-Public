# -*- coding: utf-8 -*-
"""
Runner_1174g_IntakeClassRebind.py
- Verschiebt versehentlich auf Top-Level liegende Intake-Helper (def _intake_*) zurück
  in die Klasse IntakeFrame (Einrückung fix).
- Entfernt "global ttk" Artefakte.
- Fügt bei Bedarf "from tkinter import ttk" innerhalb der Methode ein, falls darin ttk genutzt wird
  und kein Import im Methodentext existiert.
- Macht Backup wurde bereits in der .bat erledigt.
- Syntax-Check + Rollback bei Fehler.
"""
import io, os, re, sys, shutil, py_compile, tempfile, traceback

ROOT = r"D:\ShrimpDev"
MOD  = os.path.join(ROOT, r"modules\module_code_intake.py")
ARCH = os.path.join(ROOT, r"_Archiv")
DBG  = os.path.join(ROOT, "debug_output.txt")

def log(msg):
    print(msg)
    try:
        with open(DBG, "a", encoding="utf-8") as f:
            f.write("[1174g] " + msg + "\n")
    except Exception:
        pass

def read(p):
    with open(p, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def write(p, txt):
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(txt)

def syntax_ok(text):
    tmp = MOD + ".1174g.tmp"
    write(tmp, text)
    try:
        py_compile.compile(tmp, doraise=True)
        return True, None
    except Exception as e:
        return False, traceback.format_exc()
    finally:
        try: os.remove(tmp)
        except: pass

src = read(MOD)
orig = src

# 1) Finde Klasse IntakeFrame
cls_pat = re.compile(r'(?m)^(class\s+IntakeFrame\s*\([^)]*\)\s*:\s*\n)')
m_cls = cls_pat.search(src)
if not m_cls:
    log("WARN: Klasse IntakeFrame nicht gefunden – keine Änderung.")
    sys.exit(0)

cls_start = m_cls.end()  # Position hinter Klassenkopf
# Grob das Ende der Klasse bestimmen: bis zur nächsten 'class ' am Zeilenanfang oder EOF
next_class = re.search(r'(?m)^\s*class\s+[A-Za-z_]\w*\s*\(', src[cls_start:])
cls_end = cls_start + next_class.start() if next_class else len(src)

pre  = src[:cls_start]
body = src[cls_start:cls_end]
post = src[cls_end:]

# 2) Top-Level Intake-Methoden sammeln (self-Methoden, die auf Top-Level stehen)
# Wir erkennen Top-Level über Zeilenanfang ohne Einrückung.
top_def_pat = re.compile(
    r'(?ms)^(def\s+(_intake_[A-Za-z0-9_]+)\s*\(\s*self\b[^)]*\)\s*:\s*\n(?:.+?\n)(?=(?:^\S)|\Z))'
)
top_defs = list(top_def_pat.finditer(src))
moved = []

# Wir ignorieren Methoden, die bereits innerhalb der Klasse liegen (innerhalb body-Range).
def is_inside_class(pos):
    return cls_start <= pos < cls_end

# 3) Entferne "global ttk" in Kandidaten, ggf. Import ergänzen
def fix_method_text(text):
    # global ttk entfernen
    text = re.sub(r'(?m)^\s*global\s+ttk\s*\n', '', text)
    # wenn ttk.* verwendet wird und kein lokaler Import enthalten ist, import hinzufügen
    uses_ttk = re.search(r'\bttk\.', text) is not None
    has_import = re.search(r'(?m)^\s*from\s+tkinter\s+import\s+ttk\b', text) or re.search(r'(?m)^\s*import\s+tkinter\b', text)
    if uses_ttk and not has_import:
        # direkt nach der def-Zeile einen Import einfügen
        text = re.sub(r'(^def[^\n]*\n)', r'\1    from tkinter import ttk\n', text, count=1, flags=re.M)
    return text

# 4) Kandidaten extrahieren, die außerhalb der Klasse liegen
extracts = []
for m in top_defs:
    start = m.start()
    if is_inside_class(start):
        continue
    block = m.group(1)
    name  = m.group(2)
    extracts.append((start, start+len(block), name, block))

# Nichts zu verschieben?
if not extracts:
    log("Keine Top-Level Intake-Methoden mit self gefunden – nichts zu tun.")
    sys.exit(0)

# 5) Aus src entfernen (von hinten nach vorn, um Offsets stabil zu halten)
extracts.sort(key=lambda t: t[0], reverse=True)
for s, e, name, block in extracts:
    src = src[:s] + src[e:]
    moved.append(name)

# 6) Die Blöcke in die Klasse am Ende des body einfügen – sauber eingerückt (4 Leerzeichen)
indented_blocks = []
for _, _, name, block in reversed(extracts):
    fixed = fix_method_text(block)
    # Sicherstellen, dass jede Zeile +4 Spaces bekommt
    lines = fixed.splitlines(True)
    if not lines: 
        continue
    # erste Zeile bleibt (def ...), aber mit 4 Spaces voran
    lines[0] = "    " + lines[0]
    for i in range(1, len(lines)):
        # Zeilen, die leer sind, trotzdem mit Einzug versehen damit Struktur konsistent ist
        if lines[i].strip():
            lines[i] = "    " + lines[i]
        else:
            lines[i] = "    " + lines[i]
    indented_blocks.append("".join(lines) + ("\n" if not lines[-1].endswith("\n") else ""))

# 7) Klasse neu zusammensetzen
new_body = body
# vor dem Klassenteilende einfügen
new_body = new_body.rstrip() + "\n\n" + "\n".join(indented_blocks) + "\n"
new_src = pre + new_body + post

# 8) Syntax-Check – bei Fehler Rollback
ok, err = syntax_ok(new_src)
if not ok:
    log("Syntax-Check FEHLER -> Rollback.")
    log(err or "Unknown error")
    # Wiederherstellen der Originaldatei
    write(MOD, orig)
    sys.exit(2)

# 9) Schreiben
write(MOD, new_src)
log("Verschobene Methoden: " + ", ".join(moved))
log("Erfolg: Intake-Helper in Klasse eingebettet.")
sys.exit(0)
