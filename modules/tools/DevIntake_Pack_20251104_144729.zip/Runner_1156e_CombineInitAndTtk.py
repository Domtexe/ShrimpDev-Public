# -*- coding: utf-8 -*-
"""
Runner_1156e_CombineInitAndTtk
- Kombi-Fix: globaler ttk-Guard, lokale ttk-Schatten -> 'global ttk', __init__ anheben.
- Signatur wird auf (self, master, ctx=None, **kwargs) gehoben (idempotent).
- Backup, Syntax-Check, Import+Instanziierung (zwei Versuche), Rollback bei Fehlern.
"""
from __future__ import annotations
import io, sys, time, shutil, re, ast, importlib.util, types, py_compile
from pathlib import Path

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1156e_CombineInitAndTtk_report.txt"

def log(s=""):
    print(s)
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(s.rstrip()+"\n")

def backup(p: Path) -> Path:
    dst = ARCH / (p.name + "." + str(int(time.time()*1000)) + ".bak")
    shutil.copy2(p, dst); return dst

def import_smoke()->tuple[bool,str]:
    if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
    # Notfall-Stub
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules"); sys.modules.setdefault("modules", pkg)
        mod = types.ModuleType("modules.module_runner_exec")
        mod.run = lambda *a, **k: 0
        mod._log = lambda *a, **k: None
        sys.modules["modules.module_runner_exec"] = mod
    try:
        spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
        m = importlib.util.module_from_spec(spec); assert spec and spec.loader
        spec.loader.exec_module(m)  # type: ignore[attr-defined]
        import tkinter as tk
        root = tk.Tk(); root.withdraw()
        try:
            cls = getattr(m, "IntakeFrame", None)
            if not isinstance(cls, type):
                return False, "IntakeFrame-Klasse fehlt"
            # robust: erst root, dann root + None probieren
            try:
                _ = cls(root)
            except TypeError:
                _ = cls(root, None)
        finally:
            root.destroy()
        return True, "Import & Instanziierung OK"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"

def ensure_global_ttk_guard(src:str)->tuple[str,bool]:
    if re.search(r'(?m)^\s*import\s+tkinter\.ttk\s+as\s+ttk\b', src):
        return src, False
    guard = (
        "# R1156e: globaler ttk-Import-Guard\n"
        "try:\n"
        "    import tkinter as tk  # noqa: F401\n"
        "    import tkinter.ttk as ttk  # noqa: F401\n"
        "except Exception:\n"
        "    ttk = None  # type: ignore\n\n"
    )
    lines = src.splitlines(True)
    insert_at = 0
    for i in range(min(5, len(lines))):
        if lines[i].startswith("#!") or "coding" in lines[i]:
            insert_at = i+1
        else:
            break
    lines.insert(insert_at, guard)
    return "".join(lines), True

class _TtkGlobalizer(ast.NodeVisitor):
    def __init__(self): self.bad: set[int] = set()
    def visit_FunctionDef(self, node: ast.FunctionDef):
        local = False
        for n in ast.walk(node):
            if isinstance(n, ast.Assign):
                for t in n.targets:
                    if isinstance(t, ast.Name) and t.id == "ttk":
                        local = True
            elif isinstance(n, ast.AnnAssign):
                if isinstance(n.target, ast.Name) and n.target.id == "ttk":
                    local = True
            elif isinstance(n, ast.Import):
                for a in n.names:
                    if a.name == "tkinter.ttk" and (a.asname == "ttk" or a.asname is None):
                        local = True
            elif isinstance(n, ast.ImportFrom):
                if n.module in ("tkinter.ttk", "tkinter"):
                    for a in n.names:
                        if a.asname == "ttk" or a.name == "ttk":
                            local = True
        if local: self.bad.add(node.lineno)

def find_class_span(lines:list[str], class_name:str="IntakeFrame")->tuple[int,int]:
    start=None
    for i,l in enumerate(lines):
        if re.match(rf'^\s*class\s+{class_name}\b', l):
            start=i; break
    if start is None: raise RuntimeError("class IntakeFrame nicht gefunden")
    for j in range(start+1,len(lines)):
        if re.match(r'^\S', lines[j]) and not lines[j].lstrip().startswith("#"):
            return start, j
    return start, len(lines)

def inject_global_ttk(src:str)->tuple[str,int]:
    tree = ast.parse(src)
    glob = _TtkGlobalizer(); glob.visit(tree)
    if not glob.bad: return src, 0
    lines = src.splitlines(True); added = 0
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.lineno in glob.bad:
            start = node.lineno - 1
            insert_at = start + 1
            if node.body and isinstance(node.body[0], ast.Expr) and isinstance(getattr(node.body[0], "value", None), ast.Constant) and isinstance(node.body[0].value.value, str):
                insert_at = node.body[0].lineno
            # Bereits vorhanden?
            body_start = node.body[0].lineno-1 if node.body else insert_at
            window_end = min(len(lines), body_start+5)
            snippet = "".join(lines[start:window_end])
            if re.search(r'(?m)^\s*global\s+ttk\b', snippet): continue
            indent = re.match(r'^(\s*)def\b', lines[start]).group(1) + "    "
            lines.insert(insert_at, indent + "global ttk\n")
            added += 1
    return "".join(lines), added

def patch_init_signature(src:str)->tuple[str,bool]:
    """
    Hebt __init__ in IntakeFrame auf (self, master, ctx=None, **kwargs),
    idempotent (falls schon vorhanden: keine Änderung).
    """
    tree = ast.parse(src)
    cls = next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name=="IntakeFrame"), None)
    if not cls: raise RuntimeError("IntakeFrame nicht gefunden")
    fn  = next((b for b in cls.body if isinstance(b, ast.FunctionDef) and b.name=="__init__"), None)
    if not fn: return src, False

    # Bereits ok?
    argnames = [a.arg for a in fn.args.args]  # inkl. self
    var_kw   = fn.args.kwarg.arg if fn.args.kwarg else None
    if "ctx" in argnames and var_kw == "kwargs":
        return src, False

    lines = src.splitlines(True)
    s = fn.lineno-1
    header = lines[s]

    # robuste Kopf-Ersetzung: alles in den Klammern durch 'self, master, ctx=None, **kwargs'
    new_header = re.sub(
        r'^\s*def\s+__init__\s*\([^)]*\)\s*:',
        lambda m: "    def __init__(self, master, ctx=None, **kwargs):",
        header
    )
    if new_header == header:
        # Fallback
        new_header = "    def __init__(self, master, ctx=None, **kwargs):\n"
    lines[s] = new_header
    return "".join(lines), True

def main()->int:
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass
    log("[R1156e] Start CombineInitAndTtk")

    if not MODFILE.exists():
        log("[ERR] modules/module_code_intake.py fehlt."); return 1

    bak = backup(MODFILE); log(f"[Backup] {bak.name}")
    src0 = io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

    # 1) globaler ttk-Guard
    src1, guard_added = ensure_global_ttk_guard(src0)
    # 2) lokale Schattierungen globalisieren
    src2, injected = inject_global_ttk(src1)
    # 3) __init__-Signatur robust anheben
    try:
        src3, changed_init = patch_init_signature(src2)
    except Exception as ex:
        log(f"[ERR] __init__-Analyse/Rewrite: {ex}"); return 1

    if any([guard_added, injected, changed_init]):
        io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(src3)
    else:
        log("[Info] Keine Änderungen erforderlich.")

    # Syntax-Check
    try:
        py_compile.compile(MODFILE, doraise=True)
        log("[Syntax] OK")
    except Exception as e:
        log(f"[Syntax] Fehler: {e} -> Rollback")
        shutil.copy2(bak, MODFILE)
        return 1

    # Import+Instanziierung (robust)
    ok, msg = import_smoke()
    if not ok:
        log(f"[Live] Import-Fehler: {msg} -> Rollback")
        shutil.copy2(bak, MODFILE)
        return 1
    log(f"[Live] {msg}")

    log(f"[SUM] guard_added={guard_added}, global_injected={injected}, changed_init={changed_init}")
    log("[R1156e] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
