# -*- coding: utf-8 -*-
"""
Runner_1167f_RunnerExecSafeImport2
Ersetzt _log() in module_runner_exec.py durch robuste, crashfreie Variante.
Backup + Syntaxcheck + Rollback. Idempotent.
"""
from __future__ import annotations
import os, re, time, py_compile, traceback

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_runner_exec.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOG    = os.path.join(ROOT, "debug_output.txt")

PATCH_MARK = "# R1167f: safe _log (GUI-import-proof)"

SAFE_LOG_IMPL = f"""
def _log(msg: str) -> None:
    {PATCH_MARK}
    try:
        try:
            os.makedirs(os.path.dirname(LOGFILE), exist_ok=True)
        except Exception:
            pass
        try:
            with open(LOGFILE, "a", encoding="utf-8", newline="") as f:
                f.write((msg or "").rstrip() + "\\n")
        except Exception:
            pass
    except Exception:
        pass
"""

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG, "a", encoding="utf-8", newline="") as f:
        f.write(f"[1167f {ts}] {msg}\n")
    print(f"[1167f] {msg}")

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    ts = int(time.time())
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    with open(path, "r", encoding="utf-8") as fsrc, open(dst, "w", encoding="utf-8", newline="") as fdst:
        fdst.write(fsrc.read())
    return dst

def main() -> int:
    try:
        if not os.path.exists(TARGET):
            log(f"Zieldatei fehlt: {TARGET}")
            return 1
        src = open(TARGET, "r", encoding="utf-8").read()

        if PATCH_MARK in src:
            log("Patch bereits vorhanden – keine Änderung notwendig.")
            return 0

        # robustes Pattern, erlaubt Datei-Start ohne Newline
        pat = r"(?s)(^|\n)def\s+_log\s*\(.*?\):\s*.*?(?=(\n\s*def\s+|\Z))"
        if not re.search(pat, src):
            log("Konnte def _log(...) nicht finden – Abbruch ohne Änderung.")
            return 1

        new_src = re.sub(pat, "\n" + SAFE_LOG_IMPL.strip() + "\n", src, count=1)

        bak = backup(TARGET)
        log(f"Backup erstellt: {bak}")
        open(TARGET, "w", encoding="utf-8", newline="").write(new_src)

        try:
            py_compile.compile(TARGET, doraise=True)
        except Exception as e:
            open(TARGET, "w", encoding="utf-8").write(open(bak, "r", encoding="utf-8").read())
            log("Syntax-Check FEHLER -> Rollback auf Backup.")
            log("Traceback:\\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 1

        log("Patch erfolgreich eingefügt und Syntax-Check OK.")
        return 0

    except Exception as e:
        log("UNERWARTETER FEHLER:\\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
