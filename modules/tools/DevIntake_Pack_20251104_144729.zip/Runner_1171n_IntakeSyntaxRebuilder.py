# -*- coding: utf-8 -*-
"""
R1171n_IntakeSyntaxRebuilder
Repariert kaputte try-Blöcke in module_code_intake.py
"""
from __future__ import annotations
import os, re, time, shutil, py_compile, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TARGET = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
ARCH.mkdir(exist_ok=True, parents=True)
LOG = ROOT / "debug_output.txt"

def log(msg: str):
    line = f"[1171n {time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n"
    print(line, end="")
    with open(LOG, "a", encoding="utf-8") as f: f.write(line)

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time())}.bak"
    shutil.copy2(p, dst)
    return dst

def rebuild_try_blocks(text: str) -> str:
    """Fügt bei nackten try:-Zeilen fehlende excepts hinzu"""
    lines = text.splitlines(True)
    out = []
    for i, line in enumerate(lines):
        if re.match(r'^\s*try:\s*$', line):
            # prüfen, ob direkt danach except/finally folgt
            nxt = ""
            if i + 1 < len(lines):
                nxt = lines[i + 1].lstrip()
            if not nxt.startswith(("except", "finally")):
                indent = line[:len(line) - len(line.lstrip())]
                out.append(line)
                out.append(f"{indent}    pass\n")
                out.append(f"{indent}except Exception:\n{indent}    pass\n")
                log(f"Fehlenden except-block nach try: in Zeile {i+1} ergänzt.")
                continue
        out.append(line)
    return "".join(out)

def syntax_ok(p: Path) -> bool:
    try:
        py_compile.compile(str(p), doraise=True)
        return True
    except Exception as e:
        log("Syntaxcheck FEHLER: " + str(e))
        return False

def main():
    if not TARGET.exists():
        log(f"Zieldatei fehlt: {TARGET}")
        return 1
    backup_path = backup(TARGET)
    txt = TARGET.read_text(encoding="utf-8")
    new_txt = rebuild_try_blocks(txt)
    if new_txt == txt:
        log("Keine kaputten try:-Blöcke gefunden.")
        return 0
    TARGET.write_text(new_txt, encoding="utf-8", newline="\n")
    if syntax_ok(TARGET):
        log("Syntax wiederhergestellt ✅")
        return 0
    else:
        shutil.copy2(backup_path, TARGET)
        log("Rollback auf Backup ❌")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
