"""
Runner_1035_DetectWire_All
- Fix: Name-Änderung setzt var_ext_manual=False (Erkennung wirkt wieder)
- Bindings: ent_name <KeyRelease> -> _on_name_changed (LED auf gelb)
- _detect: robuste Logik Name->Endung, sonst Text-Heuristik; respektiert manuelle Endung
- Version -> v9.9.25
"""
from __future__ import annotations
import os, re, time, shutil, json, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1035] {ts} {msg}\n")
    except Exception:
        pass
    print(msg, flush=True)

def read_text(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def backup_write(path: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

GUESS_HELPER = r'''
    def _guess_ext_from_text(self, text: str) -> str:
        """Rate Endung aus Text (.bat/.py/.json/.yml/.ini/.md) – oder ''."""
        import re, json
        t = (text or "").lstrip()
        head = t[:4000]
        if re.search(r"(?im)^\s*@echo\s+off\b", head) or re.search(r"(?im)^\s*rem\s", head):
            return ".bat"
        if re.search(r"(?im)^#!.*python", head):
            return ".py"
        if re.search(r"(?m)^\s*(from\s+\w+\s+import|import\s+\w+|def\s+\w+\(|class\s+\w+\(|if\s+__name__\s*==\s*['\"]__main__['\"])"," "+head):
            return ".py"
        try:
            if head and head.strip()[0] in "{[":
                json.loads(head)
                return ".json"
        except Exception:
            pass
        if re.search(r"(?m)^\s*-\s+\w+", head) or re.search(r"(?m)^\s*\w+:\s+.+", head):
            return ".yml"
        if re.search(r"(?m)^\s*\[[^\]]+\]\s*$", head) and re.search(r"(?m)^\s*\w+\s*=", head):
            return ".ini"
        if re.search(r"(?m)^\s*#\s+\w+", head):
            return ".md"
        return ""
'''

DETECT_IMPL = r'''
    def _detect(self):
        """
        Erkennung der Endung:
        1) Aus dem Namensfeld
        2) Falls leer: aus dem Editor-Text heuristisch
        Achtung: Manuelle Endung (var_ext_manual) wird NICHT überschrieben.
        """
        name = (self.var_name.get() or "").strip()
        nm, ext_from_name = os.path.splitext(name) if name else ("", "")
        ext_from_name = (ext_from_name or "").lower()

        ext = ext_from_name
        if not ext:
            try:
                content = self.txt.get("1.0","end-1c")
            except Exception:
                content = ""
            ext = self._guess_ext_from_text(content)

        if not getattr(self, "var_ext_manual", False):
            self.var_ext.set(ext)
        else:
            self._normalize_ext()
            ext = (self.var_ext.get() or "").lower()

        allowed = {".py",".bat",".cmd",".json",".txt",".yml",".yaml",".ini",".md",".shcut"}
        ok = bool(ext) and (ext in allowed or (ext == "" and not self.var_ext_manual))

        self._update_led(self.led_detect, "green" if ok else "yellow")
        try:
            self._ping(f"Erkennung: {(ext or '(keine)')}")
        except Exception:
            pass
        return ok
'''

NAME_CHANGED = r'''
    def _on_name_changed(self, _evt=None):
        """Name wurde editiert -> manuelle Endung zurücksetzen, LED gelb."""
        self.var_ext_manual = False
        name = (self.var_name.get() or "").strip()
        nm, ext = os.path.splitext(name) if name else ("", "")
        if ext and not self.var_ext.get():
            self.var_ext.set(ext.lower())
        try:
            self._update_led(self.led_detect, "yellow")
        except Exception:
            pass
'''

def ensure_bindings(src: str) -> str:
    # Name-Entry Binding hinzufügen
    if re.search(r"ent_name\s*=\s*ttk\.Entry\([^)]*textvariable=self\.var_name", src):
        src = re.sub(
            r'(ent_name\s*=\s*ttk\.Entry\([^)]*textvariable=self\.var_name[^)]*\))',
            r'\1\n        ent_name.bind("<KeyRelease>", self._on_name_changed)',
            src
        )
    # Methode einfügen, falls fehlt
    if "def _on_name_changed(" not in src:
        ins = src.find("\n    # ---------- actions ----------")
        src = src[:ins] + NAME_CHANGED + src[ins:]
    return src

def ensure_detect(src: str) -> str:
    # Helper einfügen
    if "def _guess_ext_from_text(" not in src:
        ins = src.find("\n    # ---------- actions ----------")
        src = src[:ins] + GUESS_HELPER + src[ins:]
    # _detect ersetzen
    src = re.sub(
        r"def\s+_detect\([\s\S]+?^\s*return\s+ok\s*$",
        DETECT_IMPL.strip(),
        src,
        flags=re.MULTILINE
    )
    return src

def main() -> int:
    try:
        src = read_text(MOD)
        new = ensure_bindings(ensure_detect(src))
        if new != src:
            backup_write(MOD, new)
            log("Detect-Logik & Name-Bindings gesetzt.")
        else:
            log("Keine Änderung nötig (Detect & Bindings bereits korrekt).")

        # Version/Changelog
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.25\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.25 (2025-10-18)
- Detect final: Name-Änderung hebt manuellen Override auf; LED gelb.
- Erkennung: Name -> Endung, sonst Text-Heuristiken; manuelle Endung bleibt unberührt.
""")
        return 0
    except Exception:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write("[R1035] FEHLER:\n" + traceback.format_exc() + "\n")
        print("FEHLER:\n" + traceback.format_exc())
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
