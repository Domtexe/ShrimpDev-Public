# -*- coding: utf-8 -*-
"""
Runner_1099_FixIntake_RepairIndentPass2.py
Repariert verschobene Einrückungen in modules\module_code_intake.py
 - Fix für Tooltip-Methoden (_show/_hide)
 - Fix für IntakeFrame-Block (bis zu den Helpers)
 - Tabs->Spaces, CRLF
 - Sanity-Compile vor dem Schreiben
"""

import os, re, sys, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    bk = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "rb") as fsrc, open(bk, "wb") as fdst:
        fdst.write(fsrc.read())
    return bk

def read_text(path: str) -> str:
    with open(path, "rb") as f:
        data = f.read()
    # tolerant decodes
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("latin-1", errors="replace")

def write_text(path: str, text: str) -> None:
    # CRLF
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\n", "\r\n")
    with open(path, "wb") as f:
        f.write(text.encode("utf-8"))

def ensure_min_indent(lines, start_idx, end_idx, min_spaces=8):
    """Sorgt dafür, dass jede nicht-leere Zeile im Bereich mindestens min_spaces vorn hat."""
    for i in range(start_idx, end_idx):
        s = lines[i]
        if not s.strip():  # leer
            continue
        # schon Kommentar/Code, aber zu weit links?
        # Tabs zu Spaces
        s = s.replace("\t", "    ")
        # tatsächliche linke Breite bestimmen
        left = len(s) - len(s.lstrip(" "))
        if left < min_spaces and not s.lstrip().startswith("#") or left < min_spaces and s.lstrip().startswith(("#", "ttk.", "tk.", "self.", "pass", "try:", "except", "finally:", "return", "for ", "if ", "elif ", "else:", "with ", "raise", "class ", "def ", "from ", "import ", "os.", "re.", "json.", "subprocess", "ConfigMgr(", "_open_explorer_select", "Tooltip(")):
            lines[i] = (" " * min_spaces) + s.lstrip(" ")
        else:
            lines[i] = s
    return lines

def find_block(lines, pat, start=0):
    for i in range(start, len(lines)):
        if pat.match(lines[i]):
            return i
    return -1

def main() -> int:
    if not os.path.exists(MOD):
        print(f"[R1099] Datei nicht gefunden: {MOD}")
        return 1

    src0 = read_text(MOD)
    # normalize tabs in the working copy (keine CRLF-Änderung hier)
    src = src0.replace("\t", "    ").replace("\r\n", "\n").replace("\r", "\n")
    lines = src.split("\n")

    changed = False

    # --- 1) Tooltip-Block aufräumen -----------------------------------------
    # Finde "class Tooltip"
    rx_class_tooltip = re.compile(r'^\s*class\s+Tooltip\b.*:$')
    i_tip = find_block(lines, rx_class_tooltip, 0)
    if i_tip >= 0:
        # Ende des Klassenblocks = nächster top-level class/def oder Datei-Ende
        rx_next_top = re.compile(r'^(class|def)\s+\w|\s*class\s+\w|\s*def\s+\w')
        end_tip = len(lines)
        for j in range(i_tip + 1, len(lines)):
            # Top-Level def/class beginnt ganz links oder mit <= 3 Spaces (def/class)
            if re.match(r'^\s{0,3}(class|def)\s+\w', lines[j]):
                # aber nur beenden, wenn dieser top-level NICHT mehr zur Tooltip gehört.
                # Da Tooltip der erste Block ist, reicht das hier:
                end_tip = j
                break
        # Minimum-Indent innerhalb der Klasse: 4 Spaces (oder besser 8 für Methode + Rumpf)
        # Wir heben ALLE nicht-leeren Zeilen im Tooltip-Block auf >= 4 an.
        # Und speziell def-Zeilen auf >= 4, Rümpfe bekommen es unten über IntakeFrame-Funktion ebenfalls.
        for k in range(i_tip + 1, end_tip):
            if not lines[k].strip():
                continue
            if not lines[k].startswith("    "):  # < 4 Spaces
                lines[k] = "    " + lines[k].lstrip(" ")
        changed = True

    # --- 2) IntakeFrame-Block reparieren -------------------------------------
    rx_class_intake = re.compile(r'^\s*class\s+IntakeFrame\b.*:$')
    i_cls = find_block(lines, rx_class_intake, 0)
    if i_cls >= 0:
        # Wir suchen das Ende des "Kernblocks": bis zu einem typischen Helper-Marker
        rx_end_mark = re.compile(r'^\s*#\s*-{2,}\s*helpers|^\s*#\s*---\s*R\d+', re.IGNORECASE)
        end_cls = len(lines)
        for j in range(i_cls + 1, len(lines)):
            if rx_end_mark.match(lines[j]):
                end_cls = j
                break
        # Minimum-Indent im Klassenbereich: 8 Spaces
        lines = ensure_min_indent(lines, i_cls + 1, end_cls, min_spaces=8)
        changed = True

    # --- 3) Tabs->Spaces in gesamter Datei (schon oben getan) ----------------

    # --- 4) Sanity-Compile ----------------------------------------------------
    new_src = "\n".join(lines)
    try:
        compile(new_src, MOD, "exec")
    except SyntaxError as ex:
        # Zeigen, wo es klemmt
        ln = ex.lineno or 0
        ctx = range(max(0, ln-5), min(len(lines), ln+5))
        print("[R1099] SyntaxError nach Fix:")
        for n in ctx:
            mark = ">>" if (n+1)==ln else "  "
            print(f"{mark} {n+1:04d}: {lines[n]}")
        print(f"[R1099] {ex.__class__.__name__}: {ex}")
        print("[R1099] Syntaxprüfung fehlgeschlagen – Datei bleibt unverändert.")
        return 2

    # --- 5) Backup & Write ----------------------------------------------------
    bk = backup(MOD)
    write_text(MOD, new_src)
    print(f"[R1099] Backup: {MOD} -> {bk}")
    print("[R1099] Einrückungen repariert und Syntax geprüft.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
