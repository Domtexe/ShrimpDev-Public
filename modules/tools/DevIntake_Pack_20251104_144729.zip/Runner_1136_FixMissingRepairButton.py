# -*- coding: utf-8 -*-
"""
Runner_1136_FixMissingRepairButton
Fügt self.btn_repair = ttk.Button(...) ein, falls in _build_ui() aufgerufen,
aber nicht deklariert wurde.
"""
from __future__ import annotations
import re, time, traceback, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD_PATH = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"; ARCH.mkdir(exist_ok=True)
REPORT = ROOT / "_Reports" / "Runner_1136_FixMissingRepairButton_report.txt"
REPORT.parent.mkdir(exist_ok=True)

def w(msg: str):
    with open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip() + "\n")

def main() -> int:
    w("Runner_1136_FixMissingRepairButton – Start")
    if not MOD_PATH.exists():
        w("[FEHLER] module_code_intake.py fehlt.")
        print("[R1136] Datei fehlt.")
        return 2

    src = MOD_PATH.read_text(encoding="utf-8", errors="ignore")
    if "self.btn_repair.grid" not in src:
        w("[Info] Kein Hinweis auf btn_repair.grid – keine Änderung.")
        print("[R1136] Keine Änderung nötig.")
        return 0

    # prüfen, ob btn_repair bereits deklariert
    if "self.btn_repair =" in src:
        w("[Info] btn_repair bereits definiert – nichts zu tun.")
        print("[R1136] btn_repair existiert.")
        return 0

    backup = ARCH / f"module_code_intake.py.{int(time.time())}.bak"
    backup.write_text(src, encoding="utf-8")
    w(f"[Backup] {backup}")

    # vor grid()-Aufruf einsetzen
    pat = re.compile(r'^[ \t]*self\.btn_repair\.grid\(.*$', re.MULTILINE)
    repl = (
        '        # Repair-Button automatisch ergänzt\n'
        '        self.btn_repair = ttk.Button(bar, text="Repair", command=self._on_click_repair_safe)\n'
        '\\g<0>'
    )
    new, n = pat.subn(repl, src, count=1)

    if n == 0:
        w("[WARN] grid()-Zeile nicht gefunden – kein Patch angewendet.")
        return 1

    # Falls _on_click_repair_safe fehlt, Dummy ergänzen
    if "_on_click_repair_safe" not in new:
        safe_stub = (
            "\n    def _on_click_repair_safe(self, *_):\n"
            "        \"\"\"Fallback-Repair-Handler (no-op).\"\"\"\n"
            "        try:\n"
            "            print('[Intake] Repair-Button clicked (safe stub)')\n"
            "        except Exception:\n"
            "            pass\n"
        )
        new += safe_stub
        w("[Add] Dummy-Methode _on_click_repair_safe ergänzt.")

    MOD_PATH.write_text(new, encoding="utf-8", newline="\n")
    w("[OK] Repair-Button und Safe-Handler eingefügt.")
    print("[R1136] Patch erfolgreich.")
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        with open(REPORT, "a", encoding="utf-8") as f:
            f.write("[CRASH]\n" + traceback.format_exc())
        print("[R1136] Crash – siehe Report.")
        sys.exit(1)
