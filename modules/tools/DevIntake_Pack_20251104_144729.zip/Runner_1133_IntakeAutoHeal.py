# -*- coding: utf-8 -*-
"""
Runner_1133_IntakeAutoHeal
- Diagnostiziert module_code_intake.IntakeFrame via Import-by-Path (ohne Paketabh.)
- Bei Fehler-Mustern patcht er den Code:
    * Guard-Button-Parent: self.frm_actions -> bar
    * Doppeltes/leerens try nach Bindings entfernen -> korrektes try/except
    * Verklebte bind-Zeilen (F7/F5) trennen; F7 auf lambda(normalisieren)
    * Editor-Bindings einmalig sicherstellen (nach self.txt = tk.Text(...))
- Backup -> _Archiv; Report -> _Reports/Runner_1133_IntakeAutoHeal_report.txt
- Syntax-Check & zweiter Instanzierungsversuch; Ergebnis in Report.

Exitcodes:
  0 = OK (Instanzierung gelungen)
  1 = Patch/Syntax fehlgeschlagen (Rollback bereits erfolgt)
  2 = Datei fehlt / Import grundsätzlich gescheitert
"""
from __future__ import annotations
import sys, os, re, time, shutil, traceback, importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"; ARCH.mkdir(exist_ok=True)
REPO = ROOT / "_Reports"; REPO.mkdir(exist_ok=True)
REPORT = REPO / "Runner_1133_IntakeAutoHeal_report.txt"

def w(msg: str) -> None:
    with open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip() + "\n")

def read() -> str:
    return MOD.read_text(encoding="utf-8", errors="ignore")

def write(txt: str) -> None:
    MOD.write_text(txt, encoding="utf-8", newline="\n")

def backup() -> Path:
    dst = ARCH / f"{MOD.name}.{int(time.time())}.bak"
    shutil.copy2(MOD, dst); w(f"[Backup] {MOD} -> {dst}")
    return dst

def import_by_path(pyfile: Path):
    spec = importlib.util.spec_from_file_location("module_code_intake", pyfile)
    if not spec or not spec.loader:
        raise ImportError("spec_from_file_location failed")
    m = importlib.util.module_from_spec(spec)
    sys.modules["module_code_intake"] = m
    spec.loader.exec_module(m)
    return m

def try_instantiate() -> tuple[bool,str]:
    """Versucht IntakeFrame zu instanziieren; gibt (ok, trace/diagnose) zurück."""
    try:
        m = import_by_path(MOD)
    except Exception:
        return False, "[Import]\n" + "".join(traceback.format_exc())

    IntakeFrame = getattr(m, "IntakeFrame", None)
    if IntakeFrame is None:
        return False, "[Diagnose] IntakeFrame nicht gefunden."

    try:
        import tkinter as tk
        root = tk.Tk(); root.withdraw()
        host = tk.Frame(root); host.pack()
        IntakeFrame(host)  # __init__ kann werfen
        root.destroy()
        return True, "[OK] IntakeFrame instanziiert."
    except Exception:
        tr = "".join(traceback.format_exc())
        try:
            root.destroy()
        except Exception:
            pass
        return False, "[Instantiate]\n" + tr

# ---------------- Patcher ----------------

def patch_guard_parent(src: str) -> tuple[str, int]:
    """self.frm_actions -> bar beim Guard-Button."""
    pat = r'(self\.btn_guard\s*=\s*ttk\.Button\()\s*self\.frm_actions(\s*,\s*text\s*=\s*"Prüfen\s*\(Guard\)"\s*,\s*command\s*=\s*self\._on_click_guard\s*\))'
    new, n = re.subn(pat, r"\1bar\2", src)
    return new, n

def patch_double_try(src: str) -> tuple[str, int]:
    """
    Leeren verschachtelten try-Block direkt NACH den drei Button-Bindings entfernen.
    """
    pat = (
        r'(\n[ \t]*try:\n'                                   # der gueltige try
        r'(?:[ \t]*self\.btn_detect\.bind[^\n]*\n)'
        r'(?:[ \t]*self\.btn_save\.bind[^\n]*\n)'
        r'(?:[ \t]*self\.btn_del\.bind[^\n]*\n))'
        r'[ \t]*try:\n[ \t]*pass\n[ \t]*except\s+Exception:\s*\n[ \t]*pass'
    )
    def fix(m): return m.group(1) + "        except Exception:\n            pass"
    new, n = re.subn(pat, fix, src)
    return new, n

def patch_glued_binds(src: str) -> tuple[str, int]:
    """Verklebte bind-Zeilen trennen: ...F7...)self.txt.bind("<F5>",...)"""
    cnt = 0
    new = re.sub(
        r'(^[ \t]*self\.txt\.bind\(\s*"<F7>"\s*,\s*self\._on_click_repair_deep\)\s*)'
        r'(self\.txt\.bind\(\s*"<F5>"\s*,\s*lambda[^\n]*\))',
        lambda m: (m.group(1) + "\n        " + m.group(2), setattr(sys.modules[__name__], "_c", 1)) or (m.group(1) + "\n        " + m.group(2)),
        src,
        flags=re.MULTILINE
    )
    if "_c" in globals():
        cnt += 1; del globals()["_c"]
    # F7 ohne lambda auf lambda normalisieren
    new2, n2 = re.subn(
        r'^[ \t]*self\.txt\.bind\(\s*"<F7>"\s*,\s*self\._on_click_repair_deep\s*\)\s*$',
        r'        self.txt.bind("<F7>", lambda _e: self._on_click_repair_deep())',
        new, flags=re.MULTILINE
    )
    return new2, cnt + n2

def ensure_editor_bind_injection(src: str) -> tuple[str, int]:
    """
    Nach self.txt = tk.Text(...) einmalig:
        self._detect_job = None
        self._ensure_editor_bindings()
    """
    if "self._ensure_editor_bindings()" in src:
        return src, 0
    new, n = re.subn(
        r'(\bself\.txt\s*=\s*tk\.Text\([^)]*\)\s*\n)',
        r'\1        self._detect_job = None\n        self._ensure_editor_bindings()\n',
        src, count=1
    )
    return new, n

def heal_once(src: str) -> tuple[str, int]:
    total = 0
    src, n = patch_guard_parent(src);          total += n
    src, n = patch_double_try(src);            total += n
    src, n = patch_glued_binds(src);           total += n
    src, n = ensure_editor_bind_injection(src);total += n
    return src, total

# ---------------- Main ----------------

def main() -> int:
    with open(REPORT, "w", encoding="utf-8", newline="\n") as f:
        f.write("Runner_1133_IntakeAutoHeal – Start\n")

    if not MOD.exists():
        w(f"[FEHLER] Datei fehlt: {MOD}"); return 2

    # 1) Erstdiagnose
    ok, info = try_instantiate()
    w("[Diagnose 1] " + info)
    if ok:
        w("[Ergebnis] Intake ok – kein Patch notwendig.")
        print("[R1133] Intake OK (keine Aktion)."); return 0

    # 2) Heilen
    original = read()
    backup()
    healed, count = heal_once(original)
    if count == 0:
        w("[Info] Kein bekanntes Fehler-Muster gefunden – keine Änderungen.")
    else:
        w(f"[Patch] angewendet: {count} Stellen geändert.")

    # 3) Syntaxprobe
    try:
        compile(healed, str(MOD), "exec")
    except Exception as ex:
        w("[FEHLER] Syntax nach Patch:\n" + "".join(traceback.format_exception_only(type(ex), ex)))
        write(original)
        return 1

    if healed != original:
        write(healed)

    # 4) Zweitdiagnose
    ok2, info2 = try_instantiate()
    w("[Diagnose 2] " + info2)
    if ok2:
        w("[Ergebnis] Intake repariert.")
        print("[R1133] Intake repariert."); return 0
    else:
        w("[Ergebnis] Intake weiterhin defekt. Bitte Report prüfen.")
        print("[R1133] Intake weiterhin defekt – siehe Report."); return 1

if __name__ == "__main__":
    raise SystemExit(main())
