# [1174m] IntakeFrameRebuild – stellt sicher, dass IntakeFrame ein gültiges ttk.Frame ist
# Mastermodus: Backup, sicherer Patch, Syntax-Check, Rollback bei Fehlern, keine Zerstörung.

import os, re, sys, io, time, shutil, py_compile

TAG = "[1174m]"
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD_PATH = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCHIV = os.path.join(ROOT, "_Archiv")
os.makedirs(ARCHIV, exist_ok=True)

def log(msg):
    print(f"{TAG} {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}")

def read_text(path):
    with io.open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()

def write_text(path, text):
    with io.open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

def backup(path):
    ts = str(int(time.time()))
    bak = os.path.join(ARCHIV, os.path.basename(path) + f".{ts}.bak")
    shutil.copy2(path, bak)
    log(f"Backup erstellt: {bak}")
    return bak

def syntax_check(path):
    try:
        py_compile.compile(path, doraise=True)
        return True, None
    except py_compile.PyCompileError as e:
        return False, str(e)

def ensure_imports(src):
    """Sichert 'import tkinter as tk' und 'from tkinter import ttk' am Kopfbereich."""
    changed = False
    # Stelle die Imports unmittelbar NACH eventuellen Shebang/Future-Imports her
    lines = src.splitlines()
    # find first non-empty, non-comment line to inject before custom code if missing
    has_tk = any(re.match(r"^\s*import\s+tkinter\s+as\s+tk\s*$", l) for l in lines)
    has_ttk = any(re.match(r"^\s*from\s+tkinter\s+import\s+ttk\s*$", l) for l in lines)

    insert_idx = 0
    for i, l in enumerate(lines[:50]):  # nur Kopf durchsuchen
        if l.strip().startswith("#!") or l.strip().startswith("#"):
            insert_idx = i + 1
            continue
        if re.match(r"^\s*from\s+__future__\s+import\s+", l):
            insert_idx = i + 1
            continue
        # Beim ersten "echten" Code anhalten
        if l.strip():
            break

    ins = []
    if not has_tk:
        ins.append("import tkinter as tk")
    if not has_ttk:
        ins.append("from tkinter import ttk")

    if ins:
        lines[insert_idx:insert_idx] = ins + [""]
        changed = True

    return "\n".join(lines), changed

def normalize_class_header(src):
    """
    Erzwingt, dass IntakeFrame von ttk.Frame erbt.
    Akzeptiert diverse existierende Header-Varianten und setzt sie hart auf: class IntakeFrame(ttk.Frame):
    """
    pattern = re.compile(r"^\s*class\s+IntakeFrame\s*\([^\)]*\)\s*:\s*$", re.M)
    if not pattern.search(src):
        # Falls gar keine Klammern vorhanden sind (class IntakeFrame:)
        alt = re.compile(r"^\s*class\s+IntakeFrame\s*:\s*$", re.M)
        if alt.search(src):
            src = alt.sub("class IntakeFrame(ttk.Frame):", src)
            return src, True
        else:
            # Es existiert evtl. eine falsche Definition – vereinheitlichen:
            src = re.sub(r"^\s*class\s+IntakeFrame[^\n]*\n",
                         "class IntakeFrame(ttk.Frame):\n",
                         src, flags=re.M)
            return src, True
    else:
        src = pattern.sub("class IntakeFrame(ttk.Frame):", src)
        return src, True

def rebuild_init(src):
    """
    Sorgt dafür, dass __init__(self, parent) existiert, super().__init__(parent) aufruft
    und _build_ui() (falls vorhanden) startet.
    """
    # Finde Klassenblock
    cls_pat = re.compile(r"(^\s*class\s+IntakeFrame\s*\([^\)]*\)\s*:\s*\n)([\s\S]*?)(?=^\s*class\s+|\Z)", re.M)
    m = cls_pat.search(src)
    if not m:
        return src, False

    header, body = m.group(1), m.group(2)

    # Prüfe ob __init__ existiert
    init_pat = re.compile(r"^\s*def\s+__init__\s*\(\s*self\s*,\s*parent\s*\)\s*:\s*\n", re.M)
    has_correct_sig = bool(init_pat.search(body))

    if not has_correct_sig:
        # Entferne evtl. kaputte/alte __init__-Signaturen
        body = re.sub(r"^\s*def\s+__init__\s*\([^\)]*\)\s*:\s*\n(?:^\s+.*\n)*", "", body, flags=re.M)

        # Erzeuge sauberes __init__
        init_block = (
            "    def __init__(self, parent):\n"
            "        super().__init__(parent)\n"
            "        try:\n"
            "            builder = getattr(self, '_build_ui', None)\n"
            "            if callable(builder):\n"
            "                builder()\n"
            "        except Exception:\n"
            "            # Intake-UI darf das Hauptfenster nicht killen – Fehler landen im debug_output\n"
            "            pass\n"
            "\n"
        )
        body = init_block + body
        changed = True
    else:
        changed = False
        # Stelle sicher, dass super().__init__(parent) in __init__ vorkommt
        # Greife den __init__-Block ab
        init_block_pat = re.compile(
            r"(^\s*def\s+__init__\s*\(\s*self\s*,\s*parent\s*\)\s*:\s*\n)(\s+(?:.+\n)+?)(?=^\s*\S|\Z)",
            re.M
        )
        mi = init_block_pat.search(body)
        if mi:
            init_head, init_body = mi.group(1), mi.group(2)
            if "super().__init__(parent)" not in init_body:
                init_body = "        super().__init__(parent)\n" + init_body
                changed = True
            # _build_ui()-Aufruf sicherstellen (optional)
            if "_build_ui" not in init_body:
                add = (
                    "        try:\n"
                    "            builder = getattr(self, '_build_ui', None)\n"
                    "            if callable(builder):\n"
                    "                builder()\n"
                    "        except Exception:\n"
                    "            pass\n"
                )
                init_body = init_body + add
                changed = True

            new_init = init_head + init_body
            body = body[:mi.start()] + new_init + body[mi.end():]

    new_src = src[:m.start()] + header + body + src[m.end():]
    return new_src, changed

def main():
    print(f"{TAG} IntakeFrameRebuild: starte Patch...")
    print(f"{TAG} Root    : {ROOT}")

    if not os.path.isfile(MOD_PATH):
        print(f"{TAG} FEHLER: Modul nicht gefunden: {MOD_PATH}")
        sys.exit(10)

    src = read_text(MOD_PATH)
    bak = backup(MOD_PATH)

    changed_any = False

    # 1) Imports sicherstellen
    src2, ch = ensure_imports(src)
    changed_any |= ch
    if ch:
        log("tk/ttk-Imports ergänzt oder vereinheitlicht.")

    # 2) Klassen-Header normalisieren: IntakeFrame(ttk.Frame)
    src3, ch = normalize_class_header(src2)
    changed_any |= ch
    if ch:
        log("Klassendefinition IntakeFrame -> ttk.Frame vereinheitlicht.")

    # 3) __init__(self, parent) rekonstruiert und abgesichert
    src4, ch = rebuild_init(src3)
    changed_any |= ch
    if ch:
        log("__init__(self, parent) re-initialisiert (super().__init__ + _build_ui).")

    if not changed_any:
        log("Keine Änderung notwendig – Struktur bereits korrekt.")
    # trotzdem schreiben wir die (evtl. nur normalisierten) Inhalte zurück:
    write_text(MOD_PATH, src4)

    ok, err = syntax_check(MOD_PATH)
    if not ok:
        print(f"{TAG} Syntax-Check FEHLER -> Rollback.")
        # Rollback
        shutil.copy2(bak, MOD_PATH)
        print(err)
        sys.exit(2)

    print(f"{TAG} Patch übernommen, Syntax OK.")
    sys.exit(0)

if __name__ == "__main__":
    main()
