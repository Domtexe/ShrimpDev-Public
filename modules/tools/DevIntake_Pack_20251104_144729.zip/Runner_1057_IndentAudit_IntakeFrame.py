"""
Runner_1057_IndentAudit_IntakeFrame
- Diagnostiziert Zeilen rund um die gemeldete Stelle (±20 um Zeile 360) und schreibt
  eine gut lesbare Ausgabe in debug_output.txt (Spaces=·, Tabs=→).
- Ersetzt _on_editor_modified() robust:
  * Tabs->Spaces im Klassenblock
  * sorgt für eine Leerzeile davor
  * setzt die Funktion mit korrektem 4-Space-Indent exakt neu
  * beendet mit einer Leerzeile
Version v9.9.47
"""
from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

CANON = (
    "    def _on_editor_modified(self, _evt=None):\n"
    "        \"\"\"Editor-Änderung: Modified-Flag zurücksetzen und Detect planen.\"\"\"\n"
    "        try:\n"
    "            self.txt.edit_modified(False)\n"
    "        except Exception:\n"
    "            pass\n"
    "        self._schedule_detect(300)\n"
    "\n"
)

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1057] {ts} {msg}\n")
    except Exception:
        pass

def dump_around(lines: list[str], center: int, radius: int = 20) -> None:
    a = max(1, center - radius)
    b = min(len(lines), center + radius)
    log(f"--- DUMP LINES {a}..{b} (center={center}) ---")
    for i in range(a, b + 1):
        s = lines[i - 1].rstrip("\n")
        vis = s.replace("\t", "→").replace(" ", "·")
        log(f"{i:04d}: {vis}")
    log("--- END DUMP ---")

def read_file(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def write_backup(p: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    b = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, b)
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {p} -> {b}")

def patch() -> int:
    src = read_file(MOD)
    lines = src.splitlines(True)

    # Diagnose: Zeile 360 +- 20 dumpen
    dump_around(lines, 360, 20)

    # Klassenblock IntakeFrame isolieren und Tabs->Spaces im Block
    m_cls = re.search(r"(class\s+IntakeFrame\(ttk\.Frame\):)([\s\S]*)", src)
    if not m_cls:
        log("Klasse IntakeFrame nicht gefunden – Abbruch.")
        return 1

    head = src[:m_cls.start(2)]
    body = m_cls.group(2).replace("\t", "    ")

    # Stelle der zu ersetzenden Funktion finden (unabhängig vom aktuellen Indent)
    pat_func = re.compile(r"\n[ \t]*def\s+_on_editor_modified\([^\)]*\):[\s\S]*?(?=\n[ \t]*def\s+|\Z)", re.MULTILINE)
    if pat_func.search(body):
        body = pat_func.sub("\n\n" + CANON, body, count=1)
        log("Vorhandene _on_editor_modified() ersetzt.")
    else:
        # hinter _on_editor_key() einsetzen, sonst hinter _on_editor_paste(), sonst ans Ende
        pat_key   = re.compile(r"\n[ \t]*def\s+_on_editor_key\([^\)]*\):[\s\S]*?(?=\n[ \t]*def\s+|\Z)", re.MULTILINE)
        pat_paste = re.compile(r"\n[ \t]*def\s+_on_editor_paste\([^\)]*\):[\s\S]*?(?=\n[ \t]*def\s+|\Z)", re.MULTILINE)
        m = pat_key.search(body) or pat_paste.search(body)
        if m:
            ins = m.end()
            body = body[:ins] + "\n\n" + CANON + body[ins:]
            log("Neue _on_editor_modified() eingefügt (nach Key/Paste).")
        else:
            if not body.endswith("\n"):
                body += "\n"
            body += "\n" + CANON
            log("Neue _on_editor_modified() am Klassenende eingefügt.")

    new_src = head + body
    if new_src != src:
        write_backup(MOD, new_src)
        # Version + Changelog
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.47\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.47 (2025-10-18)
- Intake: Indentation-Audit + robuste Ersetzung von _on_editor_modified(); Tabs→Spaces im Klassenblock.
""")
        log("Patch angewendet.")
    else:
        log("Keine Änderungen nötig.")

    return 0

if __name__ == "__main__":
    raise SystemExit(patch())
