# -*- coding: utf-8 -*-
"""
Runner_1129_IntakeLoadGuard
- Patcht main_gui.py so, dass Intake-Tab stets angezeigt wird:
  * Lazy-Mount-Funktion _mount_intake_tab_safe(parent)
  * try/except um Import+Instanzierung; Fehler -> rotes Label im Tab
  * zentrales Logging (write_log), Fallback auf debug_output.txt
- Idempotent; Backup in _Archiv; Syntax-Check; Rollback bei Fehler
"""
from __future__ import annotations
import os, re, time, shutil, traceback
from pathlib import Path

ROOT   = Path(__file__).resolve().parents[1]
MAIN   = ROOT / "main_gui.py"
ARCH   = ROOT / "_Archiv"
REPO   = ROOT / "_Reports"
ARCH.mkdir(exist_ok=True); REPO.mkdir(exist_ok=True)
REPORT = REPO / "Runner_1129_IntakeLoadGuard_report.txt"

def rep(msg: str) -> None:
    with REPORT.open("a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip() + "\n")

GUARD_SNIPPET = r'''
# === 1129 Intake Load Guard (auto) ===
def _mount_intake_tab_safe(parent):
    """
    Mountet den Intake-Tab sicher. Bei Fehler: rotes Label mit Erläuterung,
    Logging über zentralen Logger (Fallback: debug_output.txt).
    """
    try:
        try:
            from modules.snippets.logger_snippet import write_log as _log
        except Exception:
            import time, os
            def _log(prefix, message):
                try:
                    p = os.path.join(os.path.dirname(__file__), "debug_output.txt")
                    ts = time.strftime("%Y-%m-%d %H:%M:%S")
                    with open(p, "a", encoding="utf-8", newline="\n") as f:
                        f.write(f"[{prefix}] {ts} {message}\n")
                except Exception:
                    pass

        try:
            from modules import module_code_intake as _intake
            frame = _intake.IntakeFrame(parent)
            frame.pack(fill="both", expand=True)
            _log("MAIN", "Intake geladen.")
        except Exception as ex:
            import tkinter as tk, traceback
            msg = "".join(traceback.format_exception(type(ex), ex, ex.__traceback__))
            _log("MAIN", "Intake-Load-ERR:\n" + msg)
            lbl = tk.Label(parent, text="Intake konnte nicht geladen werden.\nSiehe debug_output.txt",
                           fg="red", justify="left", anchor="w")
            lbl.pack(fill="both", expand=True, padx=12, pady=12)
    except Exception:
        pass
# === /1129 ===
'''.lstrip("\n")

def insert_guard(src: str) -> str:
    # Entferne alten Block, falls vorhanden
    src = re.sub(r'\n# === 1129 Intake Load Guard \(auto\) ===[\s\S]*?# === /1129 ===\n', "\n", src)

    # Einfügeposition: direkt nach from __future__ Importblock
    m = re.match(r'^(?:\s*from\s+__future__\s+import[^\n]*\n)+', src, flags=re.MULTILINE)
    pos = m.end() if m else 0
    return src[:pos] + GUARD_SNIPPET + src[pos:]

def ensure_tab_mount(src: str) -> str:
    """
    Sucht im ShrimpApp.__init__ oder _build_ui die Intake-Tab-Erstellung und
    ersetzt direkten Import/Mount durch after(50, _mount_intake_tab_safe(container)).
    Wir machen das tolerant: wir fangen die häufigsten Muster ab.
    """
    # 1) Container-Zeile erkennen: ttk.Frame(self.nb) -> self.nb.add(...,"Intake")
    pattern = (
        r'(\bself\.tab_intake(?:_container)?\s*=\s*ttk\.Frame\(\s*self\.nb\s*\)\s*\n'  # container
        r'\s*self\.nb\.add\(\s*self\.tab_intake(?:_container)?,\s*text\s*=\s*["\']Intake["\']\s*\)\s*\n)'
    )
    repl = r'\1        self.after(50, lambda: _mount_intake_tab_safe(self.tab_intake_container))\n'
    new, n = re.subn(pattern, repl, src)
    if n:
        return new

    # 2) Fallback: wenn _mount_intake_tab oder direkter Import existiert -> ersetzen
    new = re.sub(
        r'from\s+modules\s+import\s+module_code_intake\s+as\s+_intake[^\n]*\n\s*frame\s*=\s*_intake\.IntakeFrame\([^\n]*\)\s*\n\s*frame\.pack[^\n]*\n',
        r'self.after(50, lambda: _mount_intake_tab_safe(self.tab_intake_container))\n',
        src
    )
    return new

def main() -> int:
    with REPORT.open("w", encoding="utf-8", newline="\n") as f:
        f.write("Runner_1129_IntakeLoadGuard – Start\n")

    if not MAIN.exists():
        rep("[FEHLER] main_gui.py fehlt.")
        return 2

    original = MAIN.read_text(encoding="utf-8", errors="ignore")
    backup = (ARCH / f"main_gui.py.{int(time.time())}.bak")
    shutil.copy2(MAIN, backup); rep(f"[Backup] {MAIN} -> {backup}")

    try:
        s = insert_guard(original)
        s = ensure_tab_mount(s)
        compile(s, str(MAIN), "exec")
        MAIN.write_text(s, encoding="utf-8", newline="\n")
        rep("[OK] Patch OK (Syntax).")
        return 0
    except Exception as ex:
        rep("[FEHLER] Patch fehlgeschlagen – Rollback.")
        MAIN.write_text(original, encoding="utf-8", newline="\n")
        rep("TRACE:\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
