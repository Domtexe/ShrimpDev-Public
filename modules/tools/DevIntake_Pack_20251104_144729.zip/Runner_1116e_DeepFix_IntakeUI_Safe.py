# -*- coding: utf-8 -*-
"""
[R1116e] DeepFix_IntakeUI_Safe
- Repariert pFrom-Nullterminierung in modules/module_code_intake.py
- Ohne Regex; nur String-Replacements.
- Mit Backup + Syntax-Check (compile()).
"""
import os, time, shutil, sys

TAG   = "[R1116e]"
ROOT  = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD   = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH  = os.path.join(ROOT, "_Archiv")

def norm_newlines(s: str) -> str:
    return s.replace("\r\n", "\n").replace("\r", "\n")

def read_text(p: str) -> str:
    with open(p, "rb") as f:
        return norm_newlines(f.read().decode("utf-8", "replace"))

def write_text(p: str, s: str) -> None:
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)

def sanity_compile(s: str) -> None:
    # bricht mit SyntaxError ab, falls kaputt
    compile(s, MOD, "exec")

def fix_recycle_bin_helper(src: str) -> str:
    """
    Korrigiert pFrom-Zeichenkette auf "\x00\x00".
    Deckt typische Alt-Varianten ab, arbeitet bewusst ohne regex.
    """
    new = src
    # doppelt ge-escapte Nullbytes -> einmal ge-escapt
    new = new.replace('"\\\\x00\\\\x00"', '"\\x00\\x00"')
    new = new.replace("'\\\\x00\\\\x00'", "'\\x00\\x00'")
    # Varianten mit "\\0\\0" -> "\x00\x00"
    new = new.replace('"\\\\0\\\\0"', '"\\x00\\x00"')
    new = new.replace("'\\\\0\\\\0'", "'\\x00\\x00'")
    return new

def main():
    if not os.path.isfile(MOD):
        print(TAG, "Zieldatei nicht gefunden:", MOD)
        sys.exit(2)

    os.makedirs(ARCH, exist_ok=True)
    ts  = str(int(time.time()))
    bak = os.path.join(ARCH, f"module_code_intake.py.{ts}.bak")
    shutil.copy2(MOD, bak)
    print(TAG, "Backup:", bak)

    src = read_text(MOD)
    new = fix_recycle_bin_helper(src)

    if new == src:
        print(TAG, "Keine Änderungen nötig.")
        # trotzdem Syntax prüfen:
        sanity_compile(src)
        print(TAG, "Syntax OK.")
        return

    # Syntax-Check vor Schreiben (optional, hier nach dem Fix)
    sanity_compile(new)

    write_text(MOD, new)
    print(TAG, "Reparatur gespeichert.")
    print(TAG, "Fertig.")

if __name__ == "__main__":
    try:
        main()
    except SyntaxError as e:
        print(TAG, "SyntaxError nach Patch:", e)
        print(TAG, "Schreibvorgang abgebrochen – Datei bleibt unverändert.")
        sys.exit(1)
