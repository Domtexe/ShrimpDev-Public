# -*- coding: utf-8 -*-
"""
Runner_1094_FixRecycleBinIndentFinal
Repariert Einrückung der Klasse SHFILEOPSTRUCTW innerhalb _send_to_recycle_bin()
in modules/module_code_intake.py und validiert Syntax via ast.
"""

from __future__ import annotations
import os, time, shutil, re, ast
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
ARCH.mkdir(exist_ok=True)

def backup(path: Path) -> Path:
    bak = ARCH / f"{path.name}.{int(time.time())}.bak"
    shutil.copy2(path, bak)
    print(f"[R1094] Backup: {path} -> {bak}")
    return bak

def fix_indent(src: str) -> tuple[str,bool]:
    lines = src.splitlines()
    fixed = []
    inside_func = False
    changed = False

    for i, line in enumerate(lines):
        if line.startswith("def _send_to_recycle_bin("):
            inside_func = True
        if inside_func and line.strip().startswith("class SHFILEOPSTRUCTW"):
            # class muss eingerückt werden
            fixed.append("    " + line)
            changed = True
            continue
        # Nachfolgende Zeilen der Klasse
        if inside_func and (
            line.strip().startswith("_fields_ =") or
            line.strip().startswith("pFrom =") or
            line.strip().startswith("sh =") or
            line.strip().startswith("rc =") or
            line.strip().startswith("return ")
        ):
            if not line.startswith("    "):
                fixed.append("    " + line)
                changed = True
            else:
                fixed.append(line)
            continue
        fixed.append(line)
    return "\n".join(fixed), changed

def validate_syntax(src: str) -> bool:
    try:
        ast.parse(src)
        return True
    except SyntaxError as ex:
        print(f"[R1094] SyntaxError nach Patch: {ex}")
        return False

def main():
    if not MOD.exists():
        print("[R1094] Datei nicht gefunden.")
        return 1
    backup(MOD)
    src = MOD.read_text(encoding="utf-8", errors="ignore")
    new, changed = fix_indent(src)
    if not changed:
        print("[R1094] Keine Änderungen nötig.")
        return 0
    if not validate_syntax(new):
        print("[R1094] Syntaxprüfung fehlgeschlagen – Datei bleibt unverändert.")
        return 2
    MOD.write_text(new, encoding="utf-8", newline="\n")
    print("[R1094] SHFILEOPSTRUCTW-Block korrekt eingerückt und Syntax geprüft.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
