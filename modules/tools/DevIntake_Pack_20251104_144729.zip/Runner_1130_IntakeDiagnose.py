# -*- coding: utf-8 -*-
"""
Runner_1130_IntakeDiagnose (v2)
- Importiert module_code_intake.py robust per Dateipfad (ohne Paketabh.)
- Prüft das Vorhandensein und die Instanzierbarkeit von IntakeFrame.
- Schreibt alles nach _Reports/IntakeDiagnose_report.txt
"""
from __future__ import annotations
import sys, traceback, importlib.util, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "_Reports"; REPORTS.mkdir(exist_ok=True)
REPORT = REPORTS / "IntakeDiagnose_report.txt"
MOD_PATH = ROOT / "modules" / "module_code_intake.py"

def w(msg: str) -> None:
    REPORT.parent.mkdir(exist_ok=True)
    REPORT.write_text("", encoding="utf-8") if not REPORT.exists() else None
    with REPORT.open("a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip() + "\n")

def import_by_path(pyfile: Path):
    spec = importlib.util.spec_from_file_location("module_code_intake", pyfile)
    if spec is None or spec.loader is None:
        raise ImportError("spec_from_file_location failed")
    m = importlib.util.module_from_spec(spec)
    sys.modules["module_code_intake"] = m
    spec.loader.exec_module(m)
    return m

def main() -> int:
    with REPORT.open("w", encoding="utf-8", newline="\n") as f:
        f.write(f"IntakeDiagnose {time.strftime('%Y-%m-%d %H:%M:%S')}\n")

    if not MOD_PATH.exists():
        w(f"[FAIL] Datei fehlt: {MOD_PATH}")
        return 2

    try:
        w(f"[Step] Import per Dateipfad: {MOD_PATH}")
        m = import_by_path(MOD_PATH)
        w("[OK] Import erfolgreich.")
    except SyntaxError as sx:
        w("[SYNTAX] SyntaxError beim Import:")
        w("".join(traceback.format_exception_only(type(sx), sx)))
        return 3
    except Exception:
        w("[EXC] Fehler beim Import:")
        w("".join(traceback.format_exc()))
        return 2

    IntakeFrame = getattr(m, "IntakeFrame", None)
    if IntakeFrame is None:
        w("[FAIL] 'IntakeFrame' nicht gefunden.")
        return 4

    try:
        import tkinter as tk
        root = tk.Tk(); root.withdraw()
        host = tk.Frame(root); host.pack()
        w("[Step] Erzeuge IntakeFrame(host)…")
        obj = IntakeFrame(host)  # kann im __init__ Fehler werfen
        del obj
        w("[OK] IntakeFrame instanziiert.")
        root.destroy()
        return 0
    except Exception:
        w("[EXC] Fehler beim Instanzieren:")
        w("".join(traceback.format_exc()))
        try:
            root.destroy()
        except Exception:
            pass
        return 5

if __name__ == "__main__":
    raise SystemExit(main())
