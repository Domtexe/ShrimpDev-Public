# -*- coding: utf-8 -*-
from __future__ import annotations
import re, time, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
LOG  = ROOT / "debug_output.txt"

def log(msg: str) -> None:
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG, "a", encoding="utf-8", newline="\n") as f:
        f.write(f"[R1187] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")

LED_CLASS = r'''
class StatusLED(ttk.Frame):
    """Kleine farbige LED mit Tooltip."""
    def __init__(self, master, color="#9e9e9e", tooltip=""):
        super().__init__(master)
        self._tip = tooltip
        self._c = tk.Canvas(self, width=14, height=14, highlightthickness=0, bg=self._bg(master))
        self._c.pack()
        self._oval = self._c.create_oval(2,2,12,12, fill=color, outline="#555")
        self._c.bind("<Enter>", self._show_tip); self._c.bind("<Leave>", self._hide_tip)
        self._tw = None
    @staticmethod
    def _bg(w):
        try: return w.cget("background")
        except Exception: return "#f0f0f0"
    def set(self, color, tooltip=None):
        self._c.itemconfig(self._oval, fill=color)
        if tooltip is not None: self._tip = tooltip
    def _show_tip(self, *_):
        if not self._tip or self._tw: return
        x = self._c.winfo_rootx()+16; y = self._c.winfo_rooty()+self._c.winfo_height()+6
        self._tw = tw = tk.Toplevel(self._c); tw.wm_overrideredirect(True); tw.wm_geometry(f"+{x}+{y}")
        lbl = tk.Label(tw, text=self._tip, background="#ffffe0", relief="solid", borderwidth=1, justify="left")
        lbl.pack(ipadx=3, ipady=1)
    def _hide_tip(self, *_):
        if self._tw: self._tw.destroy(); self._tw = None
'''

UPDATE_FN = r'''
    def _update_leds(self):
        """Aktualisiert LED-Status (Workspace/Ziel/Datei/Syntax/Detect)."""
        try:
            # WS
            ws_ok = Path(self.workspace.get()).exists()
            self.led_ws.set("#4caf50" if ws_ok else "#e53935", f"Workspace: {'OK' if ws_ok else 'nicht gefunden'}")

            # Ziel
            td = Path(self.target_dir.get() or "")
            wr = td.exists() and td.is_dir()
            # Schreibtest nur, wenn existiert
            if wr:
                try:
                    test = td / "__led_write_test.tmp"
                    test.write_text("ok", encoding="utf-8"); test.unlink(missing_ok=True)
                    wr = True
                except Exception:
                    wr = False
            self.led_ziel.set("#4caf50" if wr else "#e53935", f"Zielordner: {'schreibbar' if wr else 'nicht schreibbar/fehlt'}")

            # Datei (dirty)
            self.led_file.set("#ffc107" if self._dirty else "#90a4ae", "Datei geändert" if self._dirty else "Datei unverändert")

            # Syntax (nur .py)
            syn_col, syn_tip = "#90a4ae", "Syntax: n/a"
            p = getattr(self, "current_path", None)
            if p and p.suffix == ".py" and p.exists():
                try:
                    src = p.read_text(encoding="utf-8", errors="replace")
                    compile(src, p.name, "exec")
                    syn_col, syn_tip = "#4caf50", "Syntax OK"
                except Exception as e:
                    syn_col, syn_tip = "#e53935", f"Syntaxfehler: {e}"
            self.led_syn.set(syn_col, syn_tip)

            # Detect (aus Editorinhalt)
            txt = self.editor.get("1.0", "end-1c")
            det = ".txt"
            # simple, robuste Heuristik
            tlo = txt.lower()
            py_s = sum(bool(x) for x in [
                "import " in tlo, "def " in tlo, "class " in tlo, "__name__" in tlo, "print(" in txt
            ])
            bat_s = sum(bool(x) for x in [
                tlo.strip().startswith("@echo off"), " rem " in f" {tlo} ", "%" in txt, " set " in f" {tlo} ", " goto " in f" {tlo} "
            ])
            if py_s==0 and bat_s==0: det = ".txt"
            elif py_s>=bat_s: det = ".py"
            else: det = ".bat"
            self.led_det.set({".py":"#4caf50",".bat":"#1e88e5",".txt":"#90a4ae"}[det], f"Erkannt: {det}")
        except Exception as e:
            from tkinter import messagebox
            messagebox.showerror("LED-Update", str(e))
'''

LED_BAR_INJECT = r'''
        # --- LED-Bar rechts außen ---
        led_bar = ttk.Frame(bar)
        led_bar.pack(side="right")
        self.led_ws   = StatusLED(led_bar, "#9e9e9e", "Workspace")
        self.led_ziel = StatusLED(led_bar, "#9e9e9e", "Zielordner")
        self.led_file = StatusLED(led_bar, "#9e9e9e", "Datei-Zustand")
        self.led_syn  = StatusLED(led_bar, "#9e9e9e", "Syntax")
        self.led_det  = StatusLED(led_bar, "#9e9e9e", "Detect")
        for _led in (self.led_ws, self.led_ziel, self.led_file, self.led_syn, self.led_det):
            _led.pack(side="right", padx=6, pady=6)
'''

def ensure_led_class(src: str) -> str:
    if "class StatusLED(" in src:
        return src
    # vor der DevIntake-Klasse einfügen
    src = re.sub(r"(class\s+DevIntake\([^)]*\)\s*:\s*)", LED_CLASS + r"\n\1", src, count=1, flags=re.M)
    return src

def inject_led_bar(src: str) -> str:
    if "self.led_ws" in src and "self.led_det" in src:
        return src  # schon vorhanden
    # nach der Toolbar-Erstellung einfügen: Suche 'bar = ttk.Frame(self)'
    src = re.sub(r"(bar\s*=\s*ttk\.Frame\(self\)[^\n]*\n[^\n]*bar\.pack\(.*\)\s*)",
                 r"\1" + LED_BAR_INJECT + "\n", src, count=1)
    return src

def ensure_update_fn(src: str) -> str:
    if "def _update_leds(self):" in src:
        return src
    # in Klasse DevIntake am Ende einfügen
    src = re.sub(r"(class\s+DevIntake\([^)]*\)\s*:\s*\n)", r"\1" + "    # LED-Update\n" + UPDATE_FN + "\n", src, count=1)
    return src

def hook_live_updates(src: str) -> str:
    # _build_ui: am Ende _update_leds() aufrufen
    if "_update_leds()" not in src:
        src = re.sub(r"(def\s+_build_ui\(self\)\s*:[\s\S]*?)(\n\s*#|\n\s*self\.bind_all|\n\s*ttk\.Label|\n\s*return|\Z)",
                     lambda m: m.group(1) + "\n        self._update_leds()\n" + m.group(2),
                     src, count=1)
    # <<Modified>> Handler: _update_leds
    if "def _on_modified" in src and "self._update_leds()" not in re.findall(r"def\s+_on_modified[\s\S]*", src):
        src = re.sub(r"(def\s+_on_modified\(self.*\):\s*\n\s*if\s+self\.editor\.edit_modified\(\)\s*:\s*\n\s*self\.editor\.edit_modified\(False\)\s*)",
                     r"\1\n            self._update_leds()\n", src, count=1)
    return src

def main() -> int:
    try:
        if not MOD.exists():
            log("module_code_intake.py nicht gefunden."); return 2
        ARCH.mkdir(exist_ok=True)
        src = MOD.read_text(encoding="utf-8", errors="replace")

        new = src
        new = ensure_led_class(new)
        new = ensure_update_fn(new)
        new = inject_led_bar(new)
        new = hook_live_updates(new)

        if new == src:
            log("Keine Änderungen erforderlich (LEDs bereits vorhanden).")
            return 0

        bak = ARCH / f"module_code_intake.py.{time.strftime('%Y%m%d_%H%M%S')}.bak"
        bak.write_text(src, encoding="utf-8")
        MOD.write_text(new, encoding="utf-8", newline="\n")
        log(f"LED-Bar injiziert. Backup: {bak.name}")
        return 0
    except Exception as e:
        log(f"FAIL: {e}")
        return 2

if __name__ == "__main__":
    sys.exit(main())
