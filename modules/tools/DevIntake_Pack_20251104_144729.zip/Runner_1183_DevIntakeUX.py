# -*- coding: ascii -*-
from __future__ import annotations
"""
R1183 - schreibt ein refaktoriertes Dev-Intake (ShrimpDev) mit Facelifting + Features.
ASCII-only, Backups in _Archiv, Syntax-Check, Logging.
"""
import time, os, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCH = ROOT / "_Archiv"
LOG  = ROOT / "debug_output.txt"
OUT  = ROOT / "modules" / "module_code_intake.py"

DEV_INTAKE_CODE = r'''# -*- coding: utf-8 -*-
from __future__ import annotations
"""
ShrimpDev - Dev-Intake Pro (facelift, classic features, pure ShrimpDev)
- Editor (left), file list (right) with columns: name, ext, subfolder, date, time
- Toolbar groups: File, Analyze, Run, Manage
- Filter/search, column sort, double click load, F2 rename, context menu
- INI persistence (workspace/target/last_ext) in dev_intake.ini
- Logging to debug_output.txt
"""
import os, sys, time, shutil, zipfile, traceback, subprocess, configparser
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

INI_FILE = "dev_intake.ini"

# ---------- logging ----------
def _log(tag: str, msg: str) -> None:
    try:
        root = Path(__file__).resolve().parents[1]
        with open(root / "debug_output.txt", "a", encoding="utf-8", newline="\n") as f:
            f.write(f"[DevIntake] {time.strftime('%Y-%m-%d %H:%M:%S')} [{tag}] {msg}\n")
    except Exception:
        pass

# ---------- small utils ----------
def _fmt_time(ts: float):
    lt = time.localtime(ts)
    return time.strftime("%Y-%m-%d", lt), time.strftime("%H:%M:%S", lt)

def _detect_ext_from_text(text: str) -> str:
    t = text.lstrip()
    if t.startswith("#!") or "import " in t or "def " in t or "print(" in t:
        return ".py"
    return ".txt"

def _open_explorer(path: Path) -> None:
    try:
        if path.is_dir():
            subprocess.Popen(["explorer", str(path)])
        else:
            subprocess.Popen(["explorer", "/select,", str(path)])
    except Exception as e:
        messagebox.showerror("Explorer", str(e))
        _log("EXPLORER_FAIL", str(e))

def _safe_run(cmd: list[str]) -> None:
    try:
        subprocess.Popen(cmd, cwd=os.getcwd(), creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
    except Exception as e:
        messagebox.showerror("Run", f"Start failed:\n{e}")
        _log("RUN_FAIL", str(e))

# ---------- main widget ----------
class DevIntake(ttk.Frame):
    def __init__(self, nb: ttk.Notebook) -> None:
        super().__init__(nb)
        # ini
        ini = self._load_ini()
        self.workspace = tk.StringVar(value=ini.get("workspace", os.getcwd()))
        self.target_dir = tk.StringVar(value=ini.get("target_dir", str(Path(os.getcwd())/"tools")))
        self.ext_var = tk.StringVar(value=ini.get("last_ext", ".py"))
        # state
        self.name_var = tk.StringVar(value=f"snippet_{time.strftime('%Y%m%d_%H%M%S')}")
        self.status = tk.StringVar(value="Bereit.")
        self.filter_var = tk.StringVar(value="")
        self.current_path: Path | None = None
        self.sort_state = ("name", True)  # col, ascending
        self._build_ui()
        self._refresh_list()

    # ---------- ini ----------
    def _load_ini(self) -> dict:
        cfg = configparser.ConfigParser()
        p = Path(os.getcwd())/INI_FILE
        if p.exists():
            try:
                cfg.read(p, encoding="utf-8")
                return dict(cfg.items("dev")) if cfg.has_section("dev") else {}
            except Exception:
                _log("INI_READ_FAIL", "fallback to defaults")
        return {}

    def _save_ini(self) -> None:
        try:
            cfg = configparser.ConfigParser()
            cfg["dev"] = {
                "workspace": self.workspace.get(),
                "target_dir": self.target_dir.get(),
                "last_ext": self.ext_var.get(),
            }
            with open(Path(os.getcwd())/INI_FILE, "w", encoding="utf-8", newline="\n") as f:
                cfg.write(f)
        except Exception as e:
            _log("INI_WRITE_FAIL", str(e))

    # ---------- ui ----------
    def _build_ui(self) -> None:
        # header line
        top = ttk.Frame(self); top.pack(fill="x", padx=8, pady=6)
        ttk.Label(top, text="Workspace:").grid(row=0, column=0, sticky="w")
        ttk.Entry(top, textvariable=self.workspace, width=44).grid(row=0, column=1, sticky="we", padx=(4,4))
        ttk.Button(top, text="...", width=3, command=self._pick_workspace).grid(row=0, column=2, padx=(2,12))
        ttk.Label(top, text="Name:").grid(row=0, column=3, sticky="w")
        ttk.Entry(top, textvariable=self.name_var, width=28).grid(row=0, column=4, sticky="we", padx=(4,12))
        ttk.Label(top, text="Ext:").grid(row=0, column=5, sticky="w")
        ttk.Combobox(top, textvariable=self.ext_var, values=[".py",".bat",".txt"], width=6, state="readonly").grid(row=0, column=6, sticky="w")
        ttk.Label(top, text="Ziel:").grid(row=0, column=7, sticky="e")
        ttk.Entry(top, textvariable=self.target_dir, width=38).grid(row=0, column=8, sticky="we", padx=(4,4))
        ttk.Button(top, text="...", width=3, command=self._pick_target).grid(row=0, column=9)
        for c in (1,4,8):
            top.columnconfigure(c, weight=1)

        # toolbar grouped
        bar = ttk.Frame(self); bar.pack(fill="x", padx=8, pady=(0,6))
        def group(label: str) -> ttk.Frame:
            frm = ttk.Labelframe(bar, text=label)
            frm.pack(side="left", padx=(0,8))
            return frm

        g_file = group("Datei")
        ttk.Button(g_file, text="Neu", command=self._editor_clear).pack(side="left", padx=2, pady=4)
        ttk.Button(g_file, text="Einfügen", command=self._insert_as_new).pack(side="left", padx=2, pady=4)
        ttk.Button(g_file, text="Speichern", command=self._save_current).pack(side="left", padx=2, pady=4)
        ttk.Button(g_file, text="Speichern als…", command=self._save_as).pack(side="left", padx=2, pady=4)

        g_an = group("Analyse")
        ttk.Button(g_an, text="Erkennen (Ctrl-I)", command=self._detect_name_ext).pack(side="left", padx=2, pady=4)
        ttk.Button(g_an, text="Guard", command=self._guard_check).pack(side="left", padx=2, pady=4)
        ttk.Button(g_an, text="Repair", command=self._repair).pack(side="left", padx=2, pady=4)

        g_run = group("Ausführen")
        ttk.Button(g_run, text="Run (F5)", command=self._run_current).pack(side="left", padx=2, pady=4)
        ttk.Button(g_run, text="Ordner öffnen", command=self._open_target).pack(side="left", padx=2, pady=4)
        ttk.Button(g_run, text="Explorer", command=lambda: _open_explorer(Path(self.target_dir.get()))).pack(side="left", padx=2, pady=4)

        g_mgmt = group("Verwaltung")
        ttk.Button(g_mgmt, text="Aktualisieren", command=self._refresh_list).pack(side="left", padx=2, pady=4)
        ttk.Button(g_mgmt, text="Pack speichern", command=self._save_pack).pack(side="left", padx=2, pady=4)
        ttk.Button(g_mgmt, text="Löschen", command=self._delete_current).pack(side="left", padx=2, pady=4)

        # filter/search
        fl = ttk.Frame(self); fl.pack(fill="x", padx=8, pady=(0,4))
        ttk.Label(fl, text="Filter:").pack(side="left")
        ent = ttk.Entry(fl, textvariable=self.filter_var, width=40)
        ent.pack(side="left", padx=(4,10))
        ttk.Button(fl, text="Anwenden", command=self._refresh_list).pack(side="left")

        # split
        split = ttk.Panedwindow(self, orient="horizontal"); split.pack(fill="both", expand=True, padx=8, pady=(0,8))
        left = ttk.Frame(split); right = ttk.Frame(split)
        split.add(left, weight=3); split.add(right, weight=2)

        self.editor = tk.Text(left, wrap="none", undo=True)
        self.editor.pack(fill="both", expand=True)
        vsb = ttk.Scrollbar(left, orient="vertical", command=self.editor.yview)
        hsb = ttk.Scrollbar(left, orient="horizontal", command=self.editor.xview)
        self.editor.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        vsb.pack(side="right", fill="y"); hsb.pack(side="bottom", fill="x")

        cols = ("name","ext","subfolder","date","time")
        self.tree = ttk.Treeview(right, columns=cols, show="headings", selectmode="browse")
        widths = (260,60,160,100,80)
        for c,w in zip(cols, widths):
            self.tree.heading(c, text=c, command=lambda col=c: self._sort_by(col))
            self.tree.column(c, width=w, anchor="w")
        self.tree.pack(fill="both", expand=True)

        # events
        self.tree.bind("<<TreeviewSelect>>", self._on_select)
        self.tree.bind("<Double-1>", self._on_double)
        self.tree.bind("<F2>", lambda e: self._rename_current())

        # context menu
        self.menu = tk.Menu(self, tearoff=0)
        self.menu.add_command(label="Run", command=self._run_current)
        self.menu.add_command(label="Rename (F2)", command=self._rename_current)
        self.menu.add_command(label="Delete", command=self._delete_current)
        self.menu.add_separator()
        self.menu.add_command(label="Explorer", command=lambda: self._open_target())
        self.tree.bind("<Button-3>", self._popup_menu)

        ttk.Label(self, textvariable=self.status, anchor="w").pack(side="bottom", fill="x")

        # shortcuts
        self.bind_all("<Control-s>", lambda e: self._save_current())
        self.bind_all("<Control-S>", lambda e: self._save_current())
        self.bind_all("<Control-i>", lambda e: self._detect_name_ext())
        self.bind_all("<F5>", lambda e: self._run_current())

    # ---------- UI helpers/actions ----------
    def _popup_menu(self, event):
        try:
            iid = self.tree.identify_row(event.y)
            if iid:
                self.tree.selection_set(iid)
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()

    def _pick_workspace(self):
        d = filedialog.askdirectory(title="Workspace waehlen", initialdir=self.workspace.get())
        if d: self.workspace.set(d); self._save_ini()

    def _pick_target(self):
        d = filedialog.askdirectory(title="Zielordner waehlen", initialdir=self.target_dir.get())
        if d: self.target_dir.set(d); self._save_ini(); self._refresh_list()

    def _open_target(self):
        try:
            _open_explorer(Path(self.target_dir.get()))
        except Exception as e:
            messagebox.showerror("Ordner", str(e))

    def _editor_clear(self):
        self.editor.delete("1.0","end")
        self.name_var.set(f"snippet_{time.strftime('%Y%m%d_%H%M%S')}")
        self.status.set("Editor geleert.")

    def _detect_name_ext(self):
        txt = self.editor.get("1.0","end-1c")
        if not txt.strip():
            self.status.set("Nichts zu erkennen."); return
        ext = _detect_ext_from_text(txt)
        base = f"snippet_{time.strftime('%Y%m%d_%H%M%S')}"
        self.name_var.set(base); self.ext_var.set(ext)
        self._save_ini()
        self.status.set(f"Erkannt: {base}{ext}")

    def _path_from_ui(self) -> Path:
        base = self.name_var.get().strip() or f"snippet_{time.strftime('%Y%m%d_%H%M%S')}"
        ext  = self.ext_var.get().strip() or ".py"
        d    = Path(self.target_dir.get().strip() or (Path(os.getcwd()) / "tools"))
        d.mkdir(parents=True, exist_ok=True)
        return d / f"{base}{ext}"

    def _insert_as_new(self):
        p = self._path_from_ui()
        if p.exists() and not messagebox.askyesno("Ueberschreiben?", f"{p.name} existiert. Ueberschreiben?"):
            return
        txt = self.editor.get("1.0","end-1c")
        try:
            p.write_text(txt, encoding="utf-8")
            self.current_path = p
            self._refresh_list(select=p)
            self.status.set(f"Eingefuegt: {p.name}")
        except Exception as e:
            messagebox.showerror("Einfügen", f"{e}")
            _log("INSERT_FAIL", str(e))

    def _save_current(self):
        if self.current_path is None:
            self._insert_as_new(); return
        try:
            txt = self.editor.get("1.0","end-1c")
            self.current_path.write_text(txt, encoding="utf-8")
            self._refresh_list(select=self.current_path)
            self.status.set(f"Gespeichert: {self.current_path.name}")
        except Exception as e:
            messagebox.showerror("Speichern", f"{e}")
            _log("SAVE_FAIL", str(e))

    def _save_as(self):
        p = self._path_from_ui()
        try:
            txt = self.editor.get("1.0","end-1c")
            p.write_text(txt, encoding="utf-8")
            self.current_path = p
            self._refresh_list(select=p)
            self.status.set(f"Gespeichert als: {p.name}")
        except Exception as e:
            messagebox.showerror("Speichern als", f"{e}")
            _log("SAVEAS_FAIL", str(e))

    def _refresh_list(self, select: Path | None=None):
        self.tree.delete(*self.tree.get_children())
        root = Path(self.target_dir.get() or (Path(os.getcwd()) / "tools"))
        root.mkdir(parents=True, exist_ok=True)
        flt = self.filter_var.get().strip().lower()
        items = []
        for p in root.rglob("*"):
            if not p.is_file(): continue
            if flt:
                if flt not in p.name.lower() and flt not in str(p.parent.relative_to(root)).lower():
                    continue
            sub = str(p.parent.relative_to(root)) if p.parent != root else ""
            date, tm = _fmt_time(p.stat().st_mtime)
            items.append((p, p.stem, p.suffix, sub, date, tm))

        # sort
        key, asc = self.sort_state
        idx = {"name":1,"ext":2,"subfolder":3,"date":4,"time":5}[key]
        items.sort(key=lambda t: t[idx] or "", reverse=not asc)

        for p, stem, ext, sub, date, tm in items:
            self.tree.insert("", "end", iid=str(p), values=(stem, ext, sub, date, tm))
        if select and self.tree.exists(str(select)):
            self.tree.selection_set(str(select))
        self.status.set(f"{len(items)} Datei(en) in {root}")

    def _sort_by(self, col: str):
        cur_col, cur_asc = self.sort_state
        asc = not cur_asc if col == cur_col else True
        self.sort_state = (col, asc)
        self._refresh_list(select=self.current_path)

    def _on_select(self, _evt=None):
        sel = self.tree.selection()
        if not sel: return
        p = Path(sel[0])
        try:
            txt = p.read_text(encoding="utf-8", errors="replace")
            self.editor.delete("1.0","end"); self.editor.insert("1.0", txt)
            self.current_path = p
            self.name_var.set(p.stem); self.ext_var.set(p.suffix or ".txt")
            self.target_dir.set(str(p.parent))
            self._save_ini()
            self.status.set(f"Geladen: {p}")
        except Exception as e:
            messagebox.showerror("Laden", f"{e}")
            _log("LOAD_FAIL", str(e))

    def _on_double(self, _evt=None):
        self._on_select()

    def _rename_current(self):
        if not self.current_path or not self.current_path.exists():
            messagebox.showinfo("Rename", "Keine Datei ausgewaehlt."); return
        p = self.current_path
        new = tk.simpledialog.askstring("Rename", f"Neuer Name ohne Ext ({p.suffix} bleibt):", initialvalue=p.stem)
        if not new: return
        target = p.with_name(new + (p.suffix or ""))
        try:
            if target.exists() and not messagebox.askyesno("Ueberschreiben?", f"{target.name} existiert. Ueberschreiben?"):
                return
            p.rename(target)
            self.current_path = target
            self.name_var.set(target.stem)
            self._refresh_list(select=target)
            self.status.set(f"Umbenannt zu: {target.name}")
        except Exception as e:
            messagebox.showerror("Rename", f"{e}")
            _log("RENAME_FAIL", str(e))

    def _run_current(self):
        p = self.current_path
        if not p or not p.exists():
            messagebox.showinfo("Run", "Keine Datei ausgewaehlt."); return
        if p.suffix == ".py":
            _safe_run(["py","-3","-u",str(p)])
        elif p.suffix == ".bat":
            _safe_run([str(p)])
        else:
            messagebox.showinfo("Run", "Nur .py oder .bat werden ausgefuehrt.")

    def _guard_check(self):
        p = self.current_path
        if not p or not p.exists():
            messagebox.showinfo("Guard", "Keine Datei ausgewaehlt."); return
        if p.suffix == ".py":
            try:
                src = p.read_text(encoding="utf-8")
                compile(src, p.name, "exec")
                messagebox.showinfo("Guard", "Syntax OK.")
            except Exception as e:
                messagebox.showerror("Guard", f"Syntaxfehler:\n{e}")
        else:
            messagebox.showinfo("Guard", "Guard prueft nur .py")

    def _repair(self):
        p = self.current_path
        if not p or not p.exists(): return
        try:
            txt = p.read_text(encoding="utf-8", errors="replace")
            txt2 = txt.replace("\r\r\n","\r\n")
            if txt2 != txt:
                p.write_text(txt2, encoding="utf-8", newline="\r\n")
            messagebox.showinfo("Repair", "Kleiner Normalizer angewendet.")
        except Exception as e:
            messagebox.showerror("Repair", f"{e}")

    def _save_pack(self):
        root = Path(self.target_dir.get())
        if not root.exists(): return
        ts = time.strftime("%Y%m%d_%H%M%S")
        zf = Path(os.getcwd())/f"DevIntake_Pack_{ts}.zip"
        try:
            with zipfile.ZipFile(zf, "w", zipfile.ZIP_DEFLATED) as z:
                for p in root.rglob("*"):
                    if p.is_file():
                        z.write(p, p.relative_to(root))
            messagebox.showinfo("Pack", f"Pack gespeichert:\n{zf}")
            self.status.set(f"Pack: {zf.name}")
        except Exception as e:
            messagebox.showerror("Pack", f"{e}")
            _log("PACK_FAIL", str(e))

    def _delete_current(self):
        p = self.current_path
        if not p or not p.exists():
            messagebox.showinfo("Loeschen", "Keine Datei ausgewaehlt."); return
        if not messagebox.askyesno("Loeschen", f"{p.name} wirklich loeschen?"):
            return
        try:
            p.unlink()
            self.current_path = None
            self.editor.delete("1.0","end")
            self._refresh_list()
            self.status.set("Datei geloescht.")
        except Exception as e:
            messagebox.showerror("Loeschen", f"{e}")
            _log("DELETE_FAIL", str(e))

# ---------- Shim API ----------
def create_intake_tab(nb: ttk.Notebook) -> None:
    try:
        frame = DevIntake(nb)
        nb.add(frame, text="Intake")
    except Exception:
        f = ttk.Frame(nb)
        ttk.Label(f, text="Intake - Fehler beim Laden. Log pruefen.", foreground="red").pack(padx=12, pady=12, anchor="w")
        nb.add(f, text="Intake")
        traceback.print_exc()
'''

def _log(msg: str) -> None:
    with open(LOG, "a", encoding="utf-8", newline="\n") as f:
        f.write(f"[R1183] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")

def main() -> int:
    try:
        ARCH.mkdir(exist_ok=True)
        OUT.parent.mkdir(parents=True, exist_ok=True)
        if OUT.exists():
            bak = ARCH / f"module_code_intake.py.{time.strftime('%Y%m%d_%H%M%S')}.bak"
            bak.write_text(OUT.read_text(encoding="utf-8"), encoding="utf-8")
            _log(f"Backup: {bak}")
        OUT.write_text(DEV_INTAKE_CODE, encoding="utf-8", newline="\n")
        compile(DEV_INTAKE_CODE, "module_code_intake.py", "exec")
        _log("Dev-Intake UX installed.")
        return 0
    except Exception as e:
        _log(f"FAIL: {e}")
        return 2

if __name__ == "__main__":
    sys.exit(main())
