from __future__ import annotations
from pathlib import Path
import re, time, shutil, py_compile, sys

ROOT = Path(r"D:\ShrimpDev")
MAIN = ROOT / "main_gui.py"

def ts(): return time.strftime("%Y%m%d_%H%M%S")
def backup(p: Path):
    if p.exists():
        b = p.with_suffix(p.suffix + f".%s.bak" % ts())
        shutil.copy2(p, b)
        print(f"[R953] Backup: {b.name}")

CLAUSE = re.compile(r'^(?P<indent>[ \t]*)(?P<kw>try|except|finally|else)\s*:\s*$')
ONLY_WS_OR_COMMENT = re.compile(r'^\s*(#.*|"""|\'\'\')?\s*$')

def indent_of(s: str) -> int:
    return len(s) - len(s.lstrip(" "))

def find_block_end(lines: list[str], start_idx: int, base_indent: int) -> int:
    """
    Finde das Ende des Blocks, der mit lines[start_idx] beginnt (try:-Suite).
    Liefert Index der ersten Zeile NACH dem Block (oder len(lines)).
    """
    i = start_idx + 1
    n = len(lines)
    # Suite beginnt bei indent = base_indent + 4 (Python Standard-Indent)
    while i < n:
        s = lines[i]
        if not s.strip():
            i += 1; continue
        ind = indent_of(s)
        if ind <= base_indent:
            break
        i += 1
    return i

def has_following_clause(lines: list[str], after_idx: int, base_indent: int) -> bool:
    """
    Gibt True, falls nach der Suite (ab after_idx) ein except/finally/else mit indent==base_indent folgt.
    """
    i = after_idx
    n = len(lines)
    while i < n:
        s = lines[i]
        if not s.strip():  # leere Zeilen überspringen
            i += 1; continue
        if indent_of(s) < base_indent:  # Block höherer Ebene – vorbei
            return False
        if indent_of(s) > base_indent:  # innerer Block – überspringen
            i += 1; continue
        m = CLAUSE.match(s)
        if m:
            kw = m.group("kw")
            if kw in ("except", "finally", "else"):
                return True
        # andere Zeile auf gleicher Ebene -> keine nachfolgende Klausel
        return False
    return False

def fix_lone_try(lines: list[str]) -> tuple[list[str], int]:
    """
    Sucht try:-Klauseln mit Suite, aber OHNE nachfolgendes except/finally/else,
    und fügt
        except Exception:
            pass
    an korrekter Stelle ein.
    """
    i = 0
    n = len(lines)
    out: list[str] = []
    fixes = 0

    while i < n:
        line = lines[i]
        m = CLAUSE.match(line)
        if not m or m.group("kw") != "try":
            out.append(line)
            i += 1
            continue

        base_indent = indent_of(line)
        # prüfe, ob die nächste sinnvolle Zeile eine Suite ist (tiefer eingerückt)
        j = i + 1
        while j < n and ONLY_WS_OR_COMMENT.match(lines[j]):
            out.append(lines[j]); j += 1  # Kommentare/Leere mitnehmen

        if j >= n:
            # try am Ende – wir machen minimal gültig
            out.append(" " * (base_indent + 4) + "pass  # [R953 add @EOF]")
            out.append(" " * base_indent + "except Exception:\n")
            out.append(" " * (base_indent + 4) + "pass  # [R953 add]")
            fixes += 2
            break

        next_line = lines[j]
        next_indent = indent_of(next_line)
        out.append(line)  # die try:-Zeile selbst

        if next_indent <= base_indent:
            # Keine Suite – setzen minimalen Body + except
            out.append(" " * (base_indent + 4) + "pass  # [R953 add]")
            out.append(" " * base_indent + "except Exception:\n")
            out.append(" " * (base_indent + 4) + "pass  # [R953 add]")
            fixes += 2
            i = j  # weiter hinter eingefügten Zeilen
            continue

        # Es gibt eine Suite – kopiere Suite durch bis Blockende
        suite_start = j
        k = suite_start
        while k < n:
            out.append(lines[k])
            if k + 1 >= n:
                k += 1
                break
            if lines[k+1].strip() and indent_of(lines[k+1]) <= base_indent:
                k += 1
                break
            k += 1

        # k ist die erste Zeile NACH der Suite
        if not has_following_clause(lines, k, base_indent):
            # Es folgt KEIN except/finally/else – jetzt einfügen
            out.append(" " * base_indent + "except Exception:\n")
            out.append(" " * (base_indent + 4) + "pass  # [R953 add]")
            fixes += 1

        # setze i an die Stelle k (wir haben alles bis k bereits in out)
        i = k
        # Kopiere evtl. direkt folgende Zeile (falls nicht schon kopiert) in der nächsten Schleifenrunde
    # Rest (falls i<n) anhängen
    while i < n:
        out.append(lines[i]); i += 1

    return out, fixes

def compile_ok(p: Path) -> tuple[bool,str]:
    try:
        py_compile.compile(str(p), doraise=True)
        return True, ""
    except Exception as ex:
        return False, str(ex)

def main() -> int:
    if not MAIN.exists():
        print("[R953] FEHLT: main_gui.py"); return 2

    backup(MAIN)
    txt = MAIN.read_text(encoding="utf-8", errors="ignore")
    lines = txt.splitlines()

    for pass_no in range(1, 6):
        ok, err = compile_ok(MAIN)
        if ok:
            print("[R953] Syntax OK – keine Lone-try-Fixes nötig.")
            return 0
        # Reparieren
        new_lines, count = fix_lone_try(lines)
        if count == 0:
            print(f"[R953] PASS {pass_no}: Kein lone-try gefunden. Fehler bleibt: {err}")
            break
        MAIN.write_text("\n".join(new_lines), encoding="utf-8")
        lines = new_lines
        print(f"[R953] PASS {pass_no}: Fixes angewendet = {count}")

    ok, err = compile_ok(MAIN)
    if ok:
        print("[R953] Syntax OK nach Fix.")
        return 0
    print(f"[R953] FEHLER bleibt: {err}")
    return 1

if __name__ == "__main__":
    sys.exit(main())
