# tools/Runner_1089_ApplyNameDetect_GuardRun_Delete.py
# -*- coding: utf-8 -*-
"""
Patcht D:\ShrimpDev\modules\module_code_intake.py:
- _guess_name_ext_from_text() einfügen (robuste Name/Ext-Erkennung aus Code)
- Editor-Paste-Flow so erweitern, dass Name/Ext gesetzt und Detect rescheduled wird
- Guard/Run/Delete-Handler hinzufügen (inkl. Papierkorb)
- Fallbacks _run_py / _path_from_selection_or_fields einfügen, falls nicht vorhanden
"""

from __future__ import annotations
import os, re, time, shutil, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent  # D:\ShrimpDev
MOD = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
ARCH.mkdir(exist_ok=True)

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"[R1089] {ts} {msg}", flush=True)

def backup() -> Path:
    dst = ARCH / f"{MOD.name}.{int(time.time())}.bak"
    shutil.copy2(MOD, dst)
    log(f"Backup: {MOD} -> {dst}")
    return dst

def read_src() -> str:
    with open(MOD, "rb") as f:
        return f.read().decode("utf-8", "replace")

def write_src(s: str) -> None:
    with open(MOD, "wb") as f:
        f.write(s.encode("utf-8"))

def ensure_block(src: str, marker: str, block: str) -> tuple[str,bool]:
    """Fügt block NACH marker ein, wenn marker nicht schon existiert."""
    if marker in src:
        return src, False
    return src + "\n\n" + block.rstrip() + "\n", True

def insert_into_class(src: str, class_name: str, method_name: str, method_code: str) -> tuple[str,bool]:
    if method_name in src:
        return src, False
    # naive Klasse finden: class IntakeFrame(
    m = re.search(rf"(?ms)^class\s+{re.escape(class_name)}\b.*?:", src)
    if not m:
        # kein Klassenkopf gefunden -> hinten anhängen (best effort)
        return ensure_block(src, f"# --- {method_name} ---", method_code)
    start = m.end()
    # Einfügepunkt: vor dem Ende der Klasse (wir hängen am Ende der Datei an, falls wir Ende schwer finden)
    # Heuristik: suche nächsten "^\S" auf gleicher/geringerer Einrückung als "class"-Zeile -> Ende der Klasse
    class_indent = re.match(r"^(\s*)class", m.group(0)).group(1)
    tail = src[start:]
    end_rel = re.search(rf"(?m)^\S", tail)
    insert_pos = len(src)  # Default: ganz am Ende
    if end_rel:
        insert_pos = start + end_rel.start()
    # Wir hängen vor insert_pos ein
    patched = src[:insert_pos] + "\n\n" + method_code.rstrip() + "\n\n" + src[insert_pos:]
    return patched, True

def replace_or_add_method_body(src: str, class_name: str, def_name: str, new_body_lines: list[str]) -> tuple[str,bool]:
    """
    Ersetzt den Body einer vorhandenen Methode (im selben Einrückungslevel),
    sonst fügt sie neu in die Klasse ein.
    """
    pat = rf"(?ms)^class\s+{re.escape(class_name)}\b.*?:"
    m_class = re.search(pat, src)
    if not m_class:
        # Klasse nicht gefunden -> addieren
        return insert_into_class(src, class_name, def_name, "\n".join(new_body_lines))
    class_start = m_class.start()
    class_end = len(src)
    m_next = re.search(r"(?m)^class\s+\w", src[m_class.end():])
    if m_next:
        class_end = m_class.end() + m_next.start()
    block = src[class_start:class_end]

    m_def = re.search(rf"(?ms)^(\s*)def\s+{re.escape(def_name)}\b\(.*?\):\s*(?:\r?\n)", block)
    if not m_def:
        # neu einfügen
        add = "\n".join(new_body_lines)
        patched = src[:class_end] + "\n\n" + add + "\n" + src[class_end:]
        return patched, True
    indent = m_def.group(1)
    def_start = m_class.start() + m_def.start()
    body_start = m_class.start() + m_def.end()
    # Body läuft bis zur nächsten def auf gleichem oder schlechterem Indent
    body_rel_end = re.search(rf"(?m)^{indent}def\s+\w", src[body_start:class_end])
    body_end = class_end if not body_rel_end else body_start + body_rel_end.start()
    # Neuen Body mit korrektem indent zusammenbauen
    body_code = "\n".join(new_body_lines)
    patched = src[:def_start] + body_code + src[body_end:]
    return patched, True

# --- Codeblöcke ---

BLOCK_GUESS = r'''
# --- R1089: name/ext guess ----------------------------------------------------
import re as _re1089
from typing import Optional as _Opt1089, Tuple as _Tup1089

RUN_PATTERNS_1089: tuple[tuple[str, _re1089.Pattern], ...] = (
    ("call_tools", _re1089.compile(r"(?im)\btools[\\/](Runner_[0-9]{4}[_A-Za-z0-9\-]+)\.(py|bat|cmd)\b")),
    ("comment_head", _re1089.compile(r"(?im)^(rem|::|#)\s*Runner[_\s-]?([0-9]{4}[_A-Za-z0-9\-]+)")),
    ("inline_runner", _re1089.compile(r"(?im)\bRunner[_-]?([0-9]{4}[_A-Za-z0-9\-]+)\b")),
    ("title", _re1089.compile(r"(?im)^\s*(title|echo)\s+.*?(Runner_[0-9]{4}[_A-Za-z0-9\-]+)\b")),
)

EXT_PATTERNS_1089: tuple[_re1089.Pattern, ...] = (
    _re1089.compile(r"(?im)\bRunner_[0-9]{4}[_A-Za-z0-9\-]+\.py\b"),
    _re1089.compile(r"(?im)\.py\b"),
    _re1089.compile(r"(?im)\.bat\b"),
    _re1089.compile(r"(?im)\.cmd\b"),
)

def _guess_name_ext_from_text(text: str, fallback_name: str = "") -> _Tup1089[str, str]:
    head = text[:4000]
    name: _Opt1089[str] = None
    for tag, pat in RUN_PATTERNS_1089:
        m = pat.search(head)
        if not m:
            continue
        if tag == "call_tools":
            name = m.group(1)
        elif tag in ("comment_head", "inline_runner"):
            grp = m.group(2) if (m.lastindex and m.lastindex >= 2) else m.group(1)
            name = f"Runner_{grp}"
        elif tag == "title":
            name = m.group(2)
        if name:
            break

    if not name:
        name = fallback_name or "snippet_"

    name = _re1089.sub(r"[^A-Za-z0-9_\-]", "_", name).strip("_-")
    if not name.startswith("Runner_") and name != "snippet_":
        name = f"Runner_{name}"
    if name == "snippet_":
        import time as _t
        name = f"snippet_{_t.strftime('%Y%m%d_%H%M%S')}"

    ext = ".py"
    for p in EXT_PATTERNS_1089:
        if p.search(head):
            if "bat" in p.pattern or "cmd" in p.pattern:
                ext = ".bat"
            else:
                ext = ".py"
            break
    return name, ext
# -----------------------------------------------------------------------------'''.strip()

BLOCK_RECYCLE = r'''
# --- R1089: Windows Recycle Bin helper ---------------------------------------
def _send_to_recycle_bin(path: str) -> bool:
    try:
        import ctypes
        from ctypes import wintypes
    except Exception:
        return False
    if not os.path.exists(path):
        return False
    FO_DELETE = 3
    FOF_ALLOWUNDO = 0x0040
    FOF_NOCONFIRMATION = 0x0010
    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [
            ("hwnd", wintypes.HWND),
            ("wFunc", wintypes.UINT),
            ("pFrom", wintypes.LPCWSTR),
            ("pTo", wintypes.LPCWSTR),
            ("fFlags", ctypes.c_uint16),
            ("fAnyOperationsAborted", wintypes.BOOL),
            ("hNameMappings", ctypes.c_void_p),
            ("lpszProgressTitle", wintypes.LPCWSTR),
        ]
    pFrom = path + "\x00\x00"
    sh = SHFILEOPSTRUCTW(
        hwnd=None, wFunc=FO_DELETE, pFrom=pFrom, pTo=None,
        fFlags=FOF_ALLOWUNDO | FOF_NOCONFIRMATION,
        fAnyOperationsAborted=False, hNameMappings=None, lpszProgressTitle=None,
    )
    rc = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(sh))
    return rc == 0 and not sh.fAnyOperationsAborted
# -----------------------------------------------------------------------------'''.strip()

METHOD_AFTER_PASTE = r'''
    # --- R1089: paste refresh -------------------------------------------------
    def _after_paste_refresh(self) -> None:
        try:
            text = self.txt.get("1.0", "end")
            name, ext = _guess_name_ext_from_text(text, getattr(self, "var_name", None).get() if hasattr(self, "var_name") else "")
            if hasattr(self, "var_name"):
                self.var_name.set(name)
            if hasattr(self, "var_ext"):
                self.var_ext.set(ext)
            # reschedule detect (sanft)
            try:
                if getattr(self, "_detect_job", None):
                    self.after_cancel(self._detect_job)
            except Exception:
                pass
            try:
                self._detect_job = self.after(250, getattr(self, "_auto_detect_if_needed", lambda: None))
            except Exception:
                pass
        except Exception:
            pass
    # -------------------------------------------------------------------------'''.strip()

METHOD_ON_PASTE = r'''
    def _on_editor_paste(self, *_):
        try:
            self.txt.event_generate("<<Paste>>")
        finally:
            try:
                self._after_paste_refresh()
            except Exception:
                pass
'''.rstrip()

METHOD_RUN_HELPERS = r'''
    # --- R1089: helpers for run/guard ----------------------------------------
    def _run_py(self, argv: list[str]) -> tuple[int, str]:
        try:
            import subprocess
            p = subprocess.run([sys.executable, *argv], capture_output=True, text=True, cwd=str(Path(__file__).resolve().parents[1]))
            out = (p.stdout or "") + (p.stderr or "")
            return p.returncode, out
        except Exception as ex:
            return 1, f"SUBPROCESS-ERR: {ex!s}"

    def _path_from_selection_or_fields(self) -> str:
        # Best effort: wenn Liste eine Auswahl liefert, nutze diese, sonst Felder
        try:
            if hasattr(self, "tree") and self.tree.selection():
                iid = self.tree.selection()[0]
                vals = self.tree.item(iid, "values")
                # values = (name, ext, subfolder, date, time) – so wurde es aufgebaut
                name, ext, subfolder = vals[0], vals[1], vals[2]
                base = self.var_target.get() if hasattr(self, "var_target") else ""
                folder = (base or "") + (("" if not subfolder else os.sep + subfolder))
                return os.path.normpath(os.path.join(folder, f"{name}{ext}"))
        except Exception:
            pass
        # Felder
        try:
            base = self.var_target.get() if hasattr(self, "var_target") else ""
            name = self.var_name.get() if hasattr(self, "var_name") else ""
            ext = self.var_ext.get() if hasattr(self, "var_ext") else ".py"
            if not name:
                return ""
            return os.path.normpath(os.path.join(base, f"{name}{ext}"))
        except Exception:
            return ""
    # -------------------------------------------------------------------------'''.strip()

METHOD_GUARD = r'''
    def _on_click_guard(self, *_):
        try:
            path = self._path_from_selection_or_fields()
            if not path or not os.path.exists(path):
                self._ping("Ziel nicht gefunden.") if hasattr(self, "_ping") else None
                return
            guard = os.path.join(Path(__file__).resolve().parents[1], "tools", "Runner_1063_Intake_SanityGuard.py")
            if not os.path.exists(guard):
                self._ping("Guard fehlt.") if hasattr(self, "_ping") else None
                return
            rc, out = self._run_py([guard, "--check", path])
            ok = (rc == 0)
            try:
                self._mark_row_checked(path, ok, out)  # falls vorhanden
            except Exception:
                pass
            self._ping("OK" if ok else "Guard meldet Fehler (RC!=0).") if hasattr(self, "_ping") else None
        except Exception as ex:
            self._ping(f"Guard-Fehler: {ex!s}") if hasattr(self, "_ping") else None
'''.rstrip()

METHOD_RUN = r'''
    def _on_click_run(self, *_):
        try:
            path = self._path_from_selection_or_fields()
            if not path or not os.path.isfile(path):
                self._ping("Keine Datei zum Ausführen.") if hasattr(self, "_ping") else None
                return
            if not path.lower().endswith(".py"):
                self._ping("Nur .py Runner direkt ausführbar.") if hasattr(self, "_ping") else None
                return
            rc, out = self._run_py([path])
            # Versuch: aus Output ein evtl. gepatchtes Ziel extrahieren und direkt prüfen
            try:
                m = re.search(r"Backup:\s+(.+?)\s+->\s+(.+?)\.", out, re.IGNORECASE)
                patched = m.group(1) if m else None
                if patched and os.path.exists(patched):
                    guard = os.path.join(Path(__file__).resolve().parents[1], "tools", "Runner_1063_Intake_SanityGuard.py")
                    if os.path.exists(guard):
                        self._run_py([guard, "--check", patched])
            except Exception:
                pass
            self._ping(f"Runner RC={rc}") if hasattr(self, "_ping") else None
        except Exception as ex:
            self._ping(f"Run-Fehler: {ex!s}") if hasattr(self, "_ping") else None
'''.rstrip()

METHOD_DELETE_CODE = r'''
    def _on_click_clear_code(self, *_):
        try:
            self.txt.delete("1.0", "end")
            if hasattr(self, "var_name"):
                self.var_name.set("")
            if hasattr(self, "var_ext"):
                self.var_ext.set(".py")
            self._ping("Editor geleert.") if hasattr(self, "_ping") else None
        except Exception:
            pass
'''.rstrip()

METHOD_DELETE_SELECTED = r'''
    def _on_click_delete_selected(self, *_):
        try:
            from tkinter import messagebox
            path = self._path_from_selection_or_fields()
            if not path or not os.path.exists(path):
                self._ping("Nichts ausgewählt.") if hasattr(self, "_ping") else None
                return
            if not messagebox.askyesno("Löschen bestätigen", f"Datei in den Papierkorb verschieben?\n\n{path}"):
                return
            ok = _send_to_recycle_bin(path)
            self._ping("Gelöscht." if ok else "Löschen fehlgeschlagen.") if hasattr(self, "_ping") else None
            try:
                self._refresh_file_list()  # falls vorhanden
            except Exception:
                pass
        except Exception:
            pass
'''.rstrip()

def main() -> int:
    if not MOD.exists():
        print(f"{MOD} nicht gefunden.", file=sys.stderr)
        return 1
    backup()

    src = read_src()
    changed = 0

    # 1) _guess_name_ext_from_text (Modul)
    if "_guess_name_ext_from_text(" not in src:
        src, did = ensure_block(src, "# --- R1089: name/ext guess", BLOCK_GUESS)
        if did:
            changed += 1
            log("Name/Ext-Erkennung ergänzt.")

    # 2) RecycleBin-Helfer (Modul)
    if "_send_to_recycle_bin(" not in src:
        src, did = ensure_block(src, "# --- R1089: Windows Recycle Bin helper", BLOCK_RECYCLE)
        if did:
            changed += 1
            log("RecycleBin-Helper ergänzt.")

    # 3) _after_paste_refresh in class IntakeFrame
    src, did = insert_into_class(src, "IntakeFrame", "_after_paste_refresh", METHOD_AFTER_PASTE)
    if did:
        changed += 1
        log("_after_paste_refresh() ergänzt.")

    # 4) _on_editor_paste ersetzen/ergänzen
    new_paste = METHOD_ON_PASTE.splitlines()
    src, did = replace_or_add_method_body(src, "IntakeFrame", "_on_editor_paste", new_paste)
    if did:
        changed += 1
        log("_on_editor_paste() gepatcht/ergänzt.")

    # 5) Run/Guard-Helpers
    src, did = insert_into_class(src, "IntakeFrame", "_run_py", METHOD_RUN_HELPERS)
    if did:
        changed += 1
        log("Run/Guard-Helper ergänzt (_run_py/_path_from_selection_or_fields).")

    # 6) Guard/Run/Delete-Handler
    for name, code in (
        ("_on_click_guard", METHOD_GUARD),
        ("_on_click_run", METHOD_RUN),
        ("_on_click_clear_code", METHOD_DELETE_CODE),
        ("_on_click_delete_selected", METHOD_DELETE_SELECTED),
    ):
        src, did = insert_into_class(src, "IntakeFrame", name, code)
        if did:
            changed += 1
            log(f"{name} ergänzt.")

    # Schreiben
    if changed:
        write_src(src)
        log(f"Patch gespeichert. Änderungen: {changed}")
    else:
        log("Keine Änderungen nötig.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
