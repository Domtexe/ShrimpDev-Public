# file: tools/Runner_997_Intake_BatAndDefault.py
# Fix: robustere BAT-Erkennung im Intake + "Code Intake" als Default-Tab setzen.

from __future__ import annotations
from pathlib import Path
import re, sys

ROOT = Path(r"D:\ShrimpDev")
MOD_INTAKE = ROOT / "modules" / "module_code_intake.py"
MAIN_GUI   = ROOT / "main_gui.py"

EXTRACT_NEW = r'''
def _extract(code: str) -> tuple[str|None, str|None]:
    """
    Liefert (name_ohne_ext, .ext) oder (None, None).
    Priorität: explizite Marker > Heuristik (BAT/PTY).
    """
    import re
    from pathlib import Path

    def _split_name(n: str) -> tuple[str, str]:
        n = Path(n).name.strip()
        if '.' in n:
            stem, ext = n.rsplit('.', 1)
            return stem, '.' + ext.lower()
        return n, ''

    head = code[:6000]

    # 1) Explizite Marker (Dateiname)
    markers = [
        r'(?im)^\s*#\s*file\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        r'(?im)^\s*//\s*file\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        r'(?im)^\s*;\s*file\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        r'(?im)^\s*[-#/* ]*filename\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        r'(?ism)^---\s*\n.*?\nfile\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt)).*?\n---\s*',
        r'(?ism)^[`]{3,}.*?\n(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))[^`]{0,200}?\n[`]{3,}',
        r'(?im)^\s*###\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
    ]
    for rx in markers:
        m = re.search(rx, head)
        if m and m.group('p'):
            stem, ext = _split_name(m.group('p'))
            return (stem or None, ext or None)

    # 2) BAT/Batch-Heuristik (sehr großzügig, aber stabil)
    bat_hits = 0
    tests = [
        r'(?im)^\s*@?echo\s+off\b',
        r'(?im)^\s*(?:rem\b|::)\b',
        r'(?im)\bgoto\s+\w+\b',
        r'(?im)\bif\s+(?:not\s+)?exist\b',
        r'(?im)\bset(?:local|)\b',
        r'(?im)\bendlocal\b',
        r'(?im)\bcall\b',
        r'(?im)\bfor\s+/?[flr]\b',
        r'(?im)\bpause\b',
    ]
    for rx in tests:
        if re.search(rx, head):
            bat_hits += 1

    py_hits = 0
    if re.search(r'(?m)^#!.*\bpython[0-9.]*\b', head): py_hits += 2
    if re.search(r'(?m)^\s*from\s+\w+', head): py_hits += 1
    if re.search(r'(?m)^\s*import\s+\w+', head): py_hits += 1
    if re.search(r'(?m)^\s*def\s+\w+\s*\(', head): py_hits += 2
    if re.search(r'(?m)^\s*class\s+\w+\s*\(', head): py_hits += 1

    ext = None
    if bat_hits >= 2 and py_hits == 0:
        ext = '.bat'
    elif py_hits >= 2 and bat_hits == 0:
        ext = '.py'

    # 3) Namensheuristik
    m = re.search(r'(?i)\bRunner_(\d{3,6})(?:[_\-]([A-Za-z0-9]+))?', head)
    if m:
        suffix = m.group(2) or 'Script'
        stem = f"Runner_{m.group(1)}{('_' + suffix) if suffix else ''}"
        return stem, (ext or '.bat' if bat_hits >= 2 else ext or '.py' if py_hits else None)

    m = re.search(r'(?i)\bmodule_([A-Za-z0-9_]+)\b', head)
    if m:
        stem = f"module_{m.group(1)}"
        return stem, (ext or '.py')

    return (None, ext)
'''

DETECT_NEW = r'''
def _detect(self, auto: bool=False):
    code = self.txt.get("1.0", "end-1c")
    name, ext = _extract(code)

    if name: self.var_name.set(str(name))
    if ext:  self.var_ext.set(ext)

    # LED & Zielordner
    ok_name = bool(self.var_name.get().strip())
    ok_ext  = bool(self.var_ext.get().strip())
    if ok_name and ok_ext:
        self._set_led(self.led_detect, "green", "Erkennung OK")
    elif ok_ext:
        self._set_led(self.led_detect, "yellow", "Nur Endung erkannt – Name prüfen")
    else:
        self._set_led(self.led_detect, "red", "Keine sichere Erkennung")

    nm = self.var_name.get().strip()
    ex = self.var_ext.get().strip().lower()
    if nm and ex:
        self.var_target.set(str(_map_target(self.workspace, nm + ex, ex)))

    if not auto:
        self.status.set(f"Erkannt: name={nm or '-'} ext={ex or '-'} → {self.var_target.get() or '-'}")
'''

LED_HELPER = r'''
    def _set_led(self, lbl, color: str, text: str=""):
        try:
            colors = {"green":"#27ae60","yellow":"#e2b93d","red":"#e74c3c","grey":"#808080"}
            lbl.config(background=colors.get(color,"#808080"))
            if text:
                try: self.lbl_detect_text.config(text=text)
                except Exception: pass
        except Exception:
            pass
'''

def replace_block(src: str, pattern: str, body: str) -> tuple[str, bool]:
    m = re.search(pattern, src, flags=re.S)
    if not m:
        return src, False
    return src[:m.start()] + body + src[m.end():], True

def patch_intake() -> bool:
    if not MOD_INTAKE.exists():
        print("[R997] Intake-Modul fehlt.")
        return False
    src = MOD_INTAKE.read_text(encoding="utf-8", errors="ignore")
    MOD_INTAKE.with_suffix(".py.r997.bak").write_text(src, encoding="utf-8")

    src, ok1 = replace_block(src, r"def\s+_extract\(\s*code\s*:\s*str\s*\)[\s\S]*?(?=\n\s*def\s+|$)", EXTRACT_NEW)
    src, ok2 = replace_block(src, r"def\s+_detect\(\s*self,\s*auto\s*:\s*bool\s*=\s*False\s*\)[\s\S]*?(?=\n\s*def\s+|$)", DETECT_NEW)

    if "_set_led(self, lbl" not in src:
        # Versuche gleich nach "class IntakeWindow" einzufügen
        m = re.search(r"class\s+IntakeWindow\s*\([^\)]*\)\s*:\s*", src)
        if m:
            src = src[:m.end()] + LED_HELPER + src[m.end():]

    MOD_INTAKE.write_text(src, encoding="utf-8")
    compile(src, str(MOD_INTAKE), "exec")
    print("[R997] Intake: BAT-Erkennung + Detect-Logik aktualisiert.")
    return True

def patch_default_tab() -> bool:
    if not MAIN_GUI.exists():
        print("[R997] main_gui.py fehlt.")
        return False
    src = MAIN_GUI.read_text(encoding="utf-8", errors="ignore")
    MAIN_GUI.with_suffix(".py.r997.bak").write_text(src, encoding="utf-8")

    # Robuster Fallback: nach Erstellen der Tabs per after_idle Tabs nach Titel durchsuchen.
    if "Code Intake" not in src:
        print("[R997] Hinweis: Kein 'Code Intake'-Tab gefunden (Titel fehlt).")
        return True

    if "R997_DEFAULT_INTAKE" in src:
        print("[R997] Default-Tab bereits gepatcht.")
        return True

    inject = (
        "\n        # [R997_DEFAULT_INTAKE] Intake als Default auswählen\n"
        "        try:\n"
        "            def __r997_select():\n"
        "                try:\n"
        "                    for t in self.nb.tabs():\n"
        "                        if self.nb.tab(t, 'text') == 'Code Intake':\n"
        "                            self.nb.select(t)\n"
        "                            break\n"
        "                except Exception:\n"
        "                    pass\n"
        "            self.after_idle(__r997_select)\n"
        "        except Exception:\n"
        "            pass\n"
    )

    # In __init__ am Ende einfügen
    m = re.search(r"class\s+\w+\(tk\.Tk\)\s*:\s*[\s\S]*?def\s+__init__\s*\([\s\S]*?\):", src)
    if not m:
        print("[R997] Konnte __init__ nicht finden.")
        return False
    # Einfügen kurz vor dem Ende des __init__-Blocks – heuristisch: vor dem ersten 'status set' oder 'pack' der Statusbar
    insert_pos = src.find("self.status", m.end())
    if insert_pos == -1:
        insert_pos = m.end()
    src = src[:insert_pos] + inject + src[insert_pos:]
    MAIN_GUI.write_text(src, encoding="utf-8")
    compile(src, str(MAIN_GUI), "exec")
    print("[R997] Default-Tab auf 'Code Intake' gesetzt.")
    return True

def main():
    ok1 = patch_intake()
    ok2 = patch_default_tab()
    return 0 if (ok1 and ok2) else 1

if __name__ == "__main__":
    raise SystemExit(main())
