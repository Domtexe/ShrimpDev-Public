# -*- coding: utf-8 -*-
"""
Runner_1153f_SafeDetectRegex
Ziel: Regex-Crashes in IntakeFrame._guess_ext_from_text vermeiden.
Vorgehen:
- _re_search(self, pat, text): sicherer Wrapper mit try/except re.error
- innerhalb _guess_ext_from_text: re.search( -> self._re_search(
- Backup, Syntax-Check, Headless-Smoke, Rollback bei Fehlern.
"""
from __future__ import annotations
import io, os, sys, time, shutil, ast, importlib.util, types, re
from pathlib import Path
import py_compile

ROOT    = Path(__file__).resolve().parents[1]
MODFILE = ROOT / "modules" / "module_code_intake.py"
ARCH    = ROOT / "_Archiv";  ARCH.mkdir(exist_ok=True)
REPDIR  = ROOT / "_Reports"; REPDIR.mkdir(exist_ok=True)
REPORT  = REPDIR / "Runner_1153f_SafeDetectRegex_report.txt"

def w(s=""):
    with io.open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(s.rstrip()+"\n")
    print(s)

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time()*1000)}.bak"
    shutil.copy2(p, dst)
    return dst

SAFE_SEARCH_METHOD = r'''
def _re_search(self, pat, text):
    """
    Sichere Regex-Suche: verhindert Crashs durch defekte Patterns.
    Bei re.error -> Meldung, None.
    """
    try:
        import re
        return re.search(pat, text)
    except re.error as ex:
        try:
            self._ping(f"RegexWarn: {ex}")
        except Exception:
            pass
        return None
'''.strip("\n")

def load() -> str:
    return io.open(MODFILE, "r", encoding="utf-8", errors="ignore").read()

def save(txt: str) -> None:
    io.open(MODFILE, "w", encoding="utf-8", newline="\n").write(txt)

def patch_safe_search(txt: str) -> tuple[str, list[str]]:
    """
    - class IntakeFrame finden
    - _re_search einfügen (falls fehlt)
    - in _guess_ext_from_text 're.search(' -> 'self._re_search(' ersetzen
    """
    changes = []
    tree = ast.parse(txt)
    cls = None
    for n in tree.body:
        if isinstance(n, ast.ClassDef) and n.name == "IntakeFrame":
            cls = n; break
    if not cls:
        raise RuntimeError("class IntakeFrame nicht gefunden.")

    lines = txt.splitlines()
    start = cls.lineno - 1
    end   = getattr(cls, "end_lineno", None) or len(lines)
    cls_src = "\n".join(lines[start:end])

    # 1) _re_search einfügen/ersetzen
    rx_method = re.compile(r'(?ms)^\s*def\s+_re_search\s*\([^)]*\):\s*(?:\n\s+.+?)(?=^\s*def\s+\w+\s*\(|\Z)')
    if rx_method.search(cls_src):
        cls_src = rx_method.sub("\n    " + SAFE_SEARCH_METHOD.replace("\n","\n    ") + "\n", cls_src, count=1)
        changes.append("replaced:_re_search")
    else:
        if not cls_src.endswith("\n"): cls_src += "\n"
        cls_src += "\n    " + SAFE_SEARCH_METHOD.replace("\n","\n    ") + "\n"
        changes.append("added:_re_search")

    # 2) _guess_ext_from_text ermitteln
    rx_guess = re.compile(r'(?ms)^\s*def\s+_guess_ext_from_text\s*\([^)]*\):\s*\n(.*?)^\s*def\s+', re.DOTALL)
    m = rx_guess.search(cls_src)
    if not m:
        raise RuntimeError("_guess_ext_from_text nicht gefunden.")

    body = m.group(1)
    if "self._re_search(" not in body and "re.search(" in body:
        body2 = body.replace("re.search(", "self._re_search(")
        cls_src = cls_src[:m.start(1)] + body2 + cls_src[m.end(1):]
        changes.append("patched:_guess_ext_from_text_safe_search")

    new_txt = "\n".join(lines[:start]) + ("\n" if start else "") + cls_src + ("\n" if end < len(lines) else "") + "\n".join(lines[end:])
    return new_txt, changes

# ---- Headless-Smoke: Import + _detect() auf Beispieltexten
def import_intake_for_test():
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    # Shim für modules.module_runner_exec
    try:
        import modules.module_runner_exec  # noqa
    except Exception:
        pkg = types.ModuleType("modules")
        mod = types.ModuleType("modules.module_runner_exec")
        mod.run = lambda *a, **k: 0
        mod._log = lambda *a, **k: None
        sys.modules.setdefault("modules", pkg)
        sys.modules["modules.module_runner_exec"] = mod

    spec = importlib.util.spec_from_file_location("module_code_intake", str(MODFILE))
    m = importlib.util.module_from_spec(spec); assert spec and spec.loader
    spec.loader.exec_module(m)  # type: ignore[attr-defined]
    return m

def smoke()->tuple[bool,str]:
    import tkinter as tk
    try:
        m = import_intake_for_test()
        r = tk.Tk(); r.withdraw()
        fr = m.IntakeFrame(r)
        samples = [
            "@echo off\nrem t\n",                    # bat
            '{ "k": 1 }\n',                          # json
            "name: x\nsteps:\n  - run\n",            # yml
            "[x]\na=b\n",                            # ini
            "# h1\n- item\n",                        # md
            "import os\nif __name__=='__main__':\n"  # py
        ]
        for s in samples:
            fr.txt.delete("1.0","end"); fr.txt.insert("1.0", s)
            fr.var_name_manual = False; fr.var_ext_manual = False
            fr._detect()
        r.destroy()
        return True, "Smoke OK"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"

def main()->int:
    if REPORT.exists():
        try: REPORT.unlink()
        except Exception: pass
    w("[R1153f] SafeDetectRegex – Start")

    if not MODFILE.exists():
        w(f"[ERR] Datei fehlt: {MODFILE}")
        return 1

    bak = backup(MODFILE); w(f"[Backup] {bak.name}")
    src = load()

    try:
        new_src, changes = patch_safe_search(src)
    except Exception as e:
        w(f"[ERR] Patch-Vorbereitung: {e}")
        return 1

    save(new_src)
    w("[Write] " + ", ".join(changes) if changes else "[Write] keine Änderungen")

    # Syntax
    try:
        py_compile.compile(str(MODFILE), doraise=True); w("[Syntax] OK")
    except Exception as e:
        w(f"[Syntax] Fehler: {e} -> Rollback"); shutil.copy2(bak, MODFILE); return 1

    # Smoke
    ok, msg = smoke()
    if not ok:
        w(f"[Live] Probe-Fehler: {msg} -> Rollback"); shutil.copy2(bak, MODFILE); return 1
    w(f"[Live] {msg}")

    w("[SUM] Safe-Search aktiviert, Detection crasht nicht mehr durch Regex-Fehler.")
    w("[R1153f] Erfolgreich abgeschlossen.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
