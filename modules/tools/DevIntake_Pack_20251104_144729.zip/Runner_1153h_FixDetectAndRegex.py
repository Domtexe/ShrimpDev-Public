# -*- coding: utf-8 -*-
"""
Runner_1153h_FixDetectAndRegex
Ziele:
- Sicheres Einfügen von `_guess_ext_from_text()` in modules/module_code_intake.py falls fehlend.
- Sanierung problematischer Regex-Zeichenklassen (bindender '-').
- Optionalen Safe-Wrapper `_safe_re_search()` bereitstellen (ohne globale Ersetzungen).
- Backup + Syntaxprobe + Auto-Rollback.

Kein Global-Rewrite von re.search -> vermeidet Rekursion.
"""
from __future__ import annotations
import io, os, re, sys, time, traceback, tempfile, importlib.util

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MODULE_PATH  = os.path.join(PROJECT_ROOT, "modules", "module_code_intake.py")
ARCHIVE_DIR  = os.path.join(PROJECT_ROOT, "_Archiv")

PATCH_TAG_A  = "# [R1153h]_guess_ext_from_text"
PATCH_TAG_B  = "# [R1153h]_safe_re_search"

def _nowstamp() -> str:
    return str(int(time.time()*1000))

def backup(path: str) -> str:
    os.makedirs(ARCHIVE_DIR, exist_ok=True)
    dst = os.path.join(ARCHIVE_DIR, os.path.basename(path) + "." + _nowstamp() + ".bak")
    with open(path, "rb") as r, open(dst, "wb") as w:
        w.write(r.read())
    return dst

def read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8", newline="") as f:
        return f.read()

def write_text(path: str, text: str) -> None:
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

def has_function(src: str, name: str) -> bool:
    pat = rf"^\s*def\s+{re.escape(name)}\s*\("
    return re.search(pat, src, re.M) is not None

def insert_after_imports(src: str, snippet: str) -> str:
    # finde oberste Import-Sektion / __future__ + Imports
    lines = src.splitlines()
    insert_idx = 0
    while insert_idx < len(lines):
        line = lines.insert if False else lines[insert_idx]  # keep mypy calm
        line = lines[insert_idx]
        if line.startswith("from __future__ import"):
            insert_idx += 1
            continue
        if line.startswith(("import ", "from ")) or line.strip().startswith("#") or not line.strip():
            insert_idx += 1
            continue
        break
    lines.insert(insert_idx, snippet.rstrip())
    return "\n".join(lines) + ("\n" if not src.endswith("\n") else "")

def sanitize_charclasses(pattern: str) -> str:
    """
    Bringt '-' in Zeichenklassen an den Rand oder escaped ihn.
    Beispiel: r"[A-Z\-_]" -> ok; r"[A-Z_-]" -> ok; r"[A-Z_-0-9]" ok.
    Heuristisch per Regex: finde Klasseninhalte und reordne '-'.
    """
    def _fix_class(m: re.Match) -> str:
        content = m.group(1)
        # nichts tun, wenn kein '-'
        if "-" not in content:
            return m.group(0)
        # ersetze bereits escaptete \- nicht
        # wir schieben alle ungeescapten '-' ans Ende
        new = []
        hyphens = 0
        i = 0
        while i < len(content):
            ch = content[i]
            if ch == "\\" and i+1 < len(content):
                new.append(ch); new.append(content[i+1]); i += 2; continue
            if ch == "-":
                hyphens += 1
            else:
                new.append(ch)
            i += 1
        if hyphens:
            new.append(r"\-" * hyphens)
        return "[" + "".join(new) + "]"

    # Finde einfache Klassen ohne verschachtelte [] (reicht hier)
    return re.sub(r"\[([^\]\[]+)\]", _fix_class, pattern)

def patch_regex_classes(src: str) -> tuple[str, int]:
    # finde String-Regex Literale: r"..." oder r'...'
    # wir bearbeiten nur einfache Literale im Code (Heuristik, sicher genug)
    count = 0
    def _fix(m: re.Match) -> str:
        nonlocal count
        quote = m.group(2)
        body  = m.group(3)
        fixed = sanitize_charclasses(body)
        if fixed != body:
            count += 1
        return f"{m.group(1)}{quote}{fixed}{quote}"
    # r"...", r'...'
    pat = r"(\br(?:(?:aw)?|))([\"'])(.+?)\2"
    new_src = re.sub(pat, _fix, src, flags=re.S)
    return new_src, count

GUESS_FN_SNIPPET = f"""
{PATCH_TAG_A}
def _guess_ext_from_text(text: str) -> str:
    \"\"\"Heuristik: leitet gewünschte Extension aus dem Quelltext ab.
    Rückgabe: '.py' | '.bat' | '.json' | '.yml' (Default: '.py')
    \"\"\"
    t = text.lstrip()
    # Batch-Indizien
    batch_signals = ("@echo off", "setlocal", "goto ", "call ")
    if any(sig in text.lower() for sig in batch_signals):
        return ".bat"
    # JSON sehr früh: beginnt häufig mit {{ oder [
    if t.startswith("{{") or t.startswith("["):
        return ".json"
    # YAML: Schlüssel: Wert-Struktur (Heuristik)
    if re.search(r"^\\s*\\w+\\s*:\\s*.+", text, re.M):
        # JSON hat auch :, daher bereits oben geprüft
        if ".json" not in text[:50]:
            return ".yml"
    # Python: def/if/import etc.
    if re.search(r"\\b(def |class |import |from )", text):
        return ".py"
    # Fallback
    return ".py"
""".strip("\n")

SAFE_RE_SNIPPET = f"""
{PATCH_TAG_B}
def _safe_re_search(pattern: str, text: str, flags: int = 0):
    \"\"\"Sichere Variante von re.search, die bei Zeichenklassenproblemen
    (bindendes '-') einen zweiten Versuch mit sanierter Klasse macht.
    Keinerlei globale Ersetzungen – keine Rekursionsgefahr.
    \"\"\"
    import re as _re  # lokaler Alias -> kein globaler Rewrite
    try:
        return _re.search(pattern, text, flags)
    except _re.error:
        try:
            fixed = {sanitize_charclasses.__name__}(pattern)
            return _re.search(fixed, text, flags)
        except Exception:
            return None
""".strip("\n")

def ensure_snippets(src: str) -> tuple[str, list[str]]:
    added = []
    if not has_function(src, "_guess_ext_from_text"):
        src = insert_after_imports(src, "\n" + GUESS_FN_SNIPPET + "\n")
        added.append("_guess_ext_from_text")
    if "_safe_re_search(" not in src:
        # füge den Helper + die Sanitizer-Funktion ein, falls nicht oben erreichbar
        if sanitize_charclasses.__name__ not in src:
            # kleine Kopie der Sanitizer-Funktion im Modul bereitstellen
            helper = """
# [R1153h]_sanitize_charclasses
def _r1153h_sanitize_charclasses(pattern: str) -> str:
    import re as _re
    def _fix_class(m):
        content = m.group(1)
        if "-" not in content:
            return m.group(0)
        new = []
        hyphens = 0
        i = 0
        while i < len(content):
            ch = content[i]
            if ch == "\\" and i+1 < len(content):
                new.append(ch); new.append(content[i+1]); i += 2; continue
            if ch == "-":
                hyphens += 1
            else:
                new.append(ch)
            i += 1
        if hyphens:
            new.append("\\-" * hyphens)
        return "[" + "".join(new) + "]"
    return _re.sub(r"\\[([^\\]\\[]+)\\]", _fix_class, pattern)
"""
            src = insert_after_imports(src, "\n" + helper.strip("\n") + "\n")
            local_sanitizer_name = "_r1153h_sanitize_charclasses"
        else:
            local_sanitizer_name = "sanitize_charclasses"
        src = insert_after_imports(
            src,
            "\n" + SAFE_RE_SNIPPET.replace("sanitize_charclasses", local_sanitizer_name) + "\n"
        )
        added.append("_safe_re_search")
    return src, added

def syntax_ok(temp_path: str) -> bool:
    try:
        compile(read_text(temp_path), temp_path, "exec")
        return True
    except SyntaxError as e:
        sys.stderr.write(f"[Syntax] {e}\n")
        return False

def mini_probe() -> bool:
    """Headless-Miniprobe: importiert das Modul via spec (ohne GUI-Start)."""
    try:
        spec = importlib.util.spec_from_file_location("module_code_intake_probe", MODULE_PATH)
        mod  = importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        spec.loader.exec_module(mod)  # type: ignore
        # Soft-Probe: Falls vorhanden, die Guess-Funktion testen
        if hasattr(mod, "_guess_ext_from_text"):
            assert mod._guess_ext_from_text("@echo off\n") == ".bat"
            assert mod._guess_ext_from_text('{"a":1}') == ".json"
            assert mod._guess_ext_from_text("def x():\n    pass\n") == ".py"
        return True
    except Exception:
        traceback.print_exc()
        return False

def main() -> int:
    print("[R1153h] FixDetectAndRegex – Start")
    if not os.path.isfile(MODULE_PATH):
        print("[R1153h][ERR] Modul nicht gefunden:", MODULE_PATH)
        return 2
    backup_path = backup(MODULE_PATH)
    print("[Backup]", os.path.relpath(backup_path, PROJECT_ROOT))

    src = read_text(MODULE_PATH)
    # 1) Snippets sicherstellen
    src, added = ensure_snippets(src)

    # 2) Regex-Literale sanieren (nur im Quelltext; kein Overkill)
    src_fixed, changed = patch_regex_classes(src)

    # 3) Schreiben in Temp, Syntax prüfen, dann final schreiben
    tmp = MODULE_PATH + ".tmp"
    write_text(tmp, src_fixed)
    if not syntax_ok(tmp):
        print("[R1153h] Syntax-Fehler -> Rollback.")
        try: os.remove(tmp)
        except OSError: pass
        return 1

    # 4) Mini-Probe (Import-only); bei Fehler -> Rollback
    write_text(MODULE_PATH, src_fixed)
    ok = mini_probe()
    if not ok:
        print("[Live] Probe-Fehler -> Rollback")
        # Restore
        with open(backup_path, "rb") as r, open(MODULE_PATH, "wb") as w:
            w.write(r.read())
        return 1

    print(f"[Write] added:{','.join(added) if added else '-'}  regex_fixes:{changed}")
    print("[Syntax] OK")
    print("[Live] Probe OK")
    try: os.remove(tmp)
    except OSError: pass
    return 0

if __name__ == "__main__":
    sys.exit(main())
