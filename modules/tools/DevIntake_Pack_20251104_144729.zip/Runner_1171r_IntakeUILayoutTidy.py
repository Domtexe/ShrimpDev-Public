# -*- coding: utf-8 -*-
"""
Runner_1171r_IntakeUILayoutTidy.py
Ziel: Status-Text/LEDs an die markierten Stellen rücken, Buttons oberhalb ihrer Ziel-Widgets ausrichten.
Implementiert einen Laufzeit-Helper _intake_ux_tidy(self) + Lifecycle-Wire; keine riskanten Quell-Umbaus.
"""
import io, os, re, sys, time, shutil, py_compile
from datetime import datetime
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

UX_HELPER = r'''
# R1171r: UX-Tidy (nur zur Laufzeit, idempotent)
def _intake_ux_tidy(self):
    try:
        import tkinter as tk
        from tkinter import ttk
    except Exception:
        return
    try:
        # LEDs / Status-Text links (Ziel/Erkennung/Speichern)
        led_target = getattr(self, "led_target", None)
        led_detect = getattr(self, "led_detect", None)
        led_save   = getattr(self, "led_save", None)
        lbl_detect = getattr(self, "lbl_detect", None)
        lbl_target = getattr(self, "lbl_target", None)
        lbl_save   = getattr(self, "lbl_save", None)
        top = getattr(self, "toolbar", None) or getattr(self, "frm_actions", None) or self

        # Kleine Statusleiste
        x = 0
        for w in [led_target, lbl_target, led_detect, lbl_detect, led_save, lbl_save]:
            if w:
                try: w.grid_configure(row=1, column=x, padx=(8 if x else 0,2), sticky="w")
                except Exception: pass
                x += 1

        # Bedien-Buttons in Zeile 0 – oberhalb Editor/Tabellenbereich
        btns = [getattr(self, n, None) for n in ("btn_guard","btn_pack","btn_refresh",
                                                 "btn_repair","btn_run","btn_save",
                                                 "btn_open","btn_detect","btn_clear")]
        btns = [b for b in btns if b is not None]
        for i, b in enumerate(btns):
            try: b.grid_configure(row=0, column=i, padx=(6 if i else 0, 0), sticky="w")
            except Exception: pass

        # Spaltenbreiten angenehmer
        try:
            for i in range(max(6, len(btns))):
                top.grid_columnconfigure(i, minsize=96, weight=0)
        except Exception: pass
    except Exception:
        pass
'''

def _log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1171r {ts}] {msg}"
    print(line)
    try:
        with io.open(LOG, "a", encoding="utf-8") as f: f.write(line+"\n")
    except Exception:
        pass

def _backup() -> str:
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"module_code_intake.py.{int(time.time())}.bak")
    shutil.copy2(MOD, bak)
    _log(f"Backup erstellt: {bak}")
    return bak

def _load() -> str:
    with io.open(MOD, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def _save(s: str):
    with io.open(MOD, "w", encoding="utf-8") as f:
        f.write(s)

def _ensure_helper(src: str) -> str:
    if "_intake_ux_tidy(self)" in src:
        return src
    return src + ("\n\n" + UX_HELPER)

def _wire_lifecycle(src: str) -> str:
    if re.search(r"_intake_ux_tidy\(\s*self\s*\)", src):
        return src
    pat = re.compile(r"(\n\s*def\s+_build_ui\(\s*self\s*\)\s*:[\s\S]*?)\n(\s*#|\s*def|\Z)", re.M)
    m = pat.search(src)
    if not m:
        _log("WARN: _build_ui(self) nicht gefunden – keine Verdrahtung.")
        return src
    block = m.group(1)
    base_indent = "    "  # Module hält 4er Basis
    call = f"\n{base_indent}    try:\n{base_indent}        _intake_ux_tidy(self)\n{base_indent}    except Exception:\n{base_indent}        pass\n"
    block2 = block + call
    return src[:m.start(1)] + block2 + src[m.end(1):]

def _syntax_ok() -> bool:
    try:
        py_compile.compile(MOD, doraise=True)
        return True
    except Exception as ex:
        _log(f"Syntax-Check FEHLER: {ex}")
        return False

def main():
    _log("IntakeUILayoutTidy: starte Patch (laufzeitbasiert)...")
    bak  = _backup()
    src  = _load()
    src1 = _ensure_helper(src)
    src2 = _wire_lifecycle(src1)
    _save(src2)
    if _syntax_ok():
        _log("UX-Tidy Patch OK.")
        sys.exit(0)
    else:
        shutil.copy2(bak, MOD)
        _log("Rollback auf Backup (Syntax-Fehler).")
        sys.exit(2)

if __name__ == "__main__":
    main()
