# -*- coding: utf-8 -*-
"""
R1171c_IntakeDetectClean
- Fügt fehlende Helper hinzu:
    * _intake_setup_detection(self)  (Auto-Detect, entprellt)
    * _intake_actions_bar_polish(self)  (Button-Text säubern, lbl_ping rechts mit Stretch)
- Aktualisiert vorhandenen '# R1170e: lifecycle wire' Block um fehlende Aufrufe.
- Idempotent, mit Backup + Syntax-Check + Rollback.
"""
from __future__ import annotations
import os, re, time, py_compile, traceback

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOG    = os.path.join(ROOT, "debug_output.txt")

MARK_HELPERS  = "# R1171c: helpers (detect+clean)"
MARK_DETECT   = "def _intake_setup_detection(self):"
MARK_POLISH   = "def _intake_actions_bar_polish(self):"
MARK_LIFE1170 = "# R1170e: lifecycle wire"

HELPERS = """
# R1171c: helpers (detect+clean)
def _r1171c__strip_shortcut_suffix(txt: str) -> str:
    import re
    return re.sub(r"\\s*\\([^)]*\\)\\s*$", "", txt or "")

def _intake_actions_bar_polish(self):
    \"\"\"Kürzt Buttontexte (ohne '(Ctrl+...)') und platziert lbl_ping rechts mit Stretch.\"\"\"
    try:
        from tkinter import ttk
    except Exception:
        return
    try:
        # Buttons einsammeln und Texte säubern
        for name in sorted([n for n in dir(self) if n.startswith("btn_")]):
            try:
                b = getattr(self, name, None)
                if not b: 
                    continue
                try:
                    b.configure(text=_r1171c__strip_shortcut_suffix(b.cget("text")))
                except Exception:
                    pass
            except Exception:
                pass
        # Status-Label: existiert? sonst anlegen
        parent = None
        # nimm Parent vom ersten Button
        for name in sorted([n for n in dir(self) if n.startswith("btn_")]):
            try:
                b = getattr(self, name, None)
                if b and hasattr(b, "winfo_parent"):
                    parent = b.nametowidget(b.winfo_parent())
                    break
            except Exception:
                pass
        if parent is None:
            parent = getattr(self, "frm_actions", None)
        if parent is None:
            return
        # Spaltengewicht: letzte Spalte stretch
        try:
            for i in range(0, 20):
                try: parent.columnconfigure(i, weight=0)
                except Exception: pass
            parent.columnconfigure(19, weight=1)
        except Exception:
            pass
        # lbl_ping rechts strecken
        lbl = getattr(self, "lbl_ping", None)
        if lbl is None:
            try:
                lbl = ttk.Label(parent, text="", anchor="w")
                self.lbl_ping = lbl
            except Exception:
                lbl = None
        if lbl:
            try:
                lbl.grid(row=0, column=19, sticky="ew", padx=(12, 0))
            except Exception:
                pass
        # Editor/Tabelle strecken (falls grid)
        try:
            if hasattr(self, "txt"): self.txt.grid_configure(sticky="nsew")
        except Exception: pass
        try:
            if hasattr(self, "tbl"):
                tbl = self.tbl
                try:
                    cols = tbl["columns"] if "columns" in tbl.keys() else ()
                    for c in cols:
                        try: tbl.column(c, stretch=True, minwidth=80, width=120)
                        except Exception: pass
                    tbl.grid_configure(sticky="nsew")
                except Exception:
                    pass
        except Exception:
            pass
    except Exception:
        pass

def _intake_setup_detection(self):
    \"\"\"Entprellte Auto-Erkennung; robuste Heuristiken; respektiert Overrides.\"\"\"
    try:
        import time
        self._r1171c_detect_job = None
        if not hasattr(self, "_allowed_ext"):
            self._allowed_ext = {".py",".bat",".cmd",".json",".txt",".yml",".yaml",".ini",".md",".ps1",".shcut"}
        def schedule(ms=250):
            try:
                if self._r1171c_detect_job:
                    self.after_cancel(self._r1171c_detect_job)
            except Exception:
                pass
            self._r1171c_detect_job = self.after(ms, do_detect)
        def do_detect():
            try:
                name = (self.var_name.get() if hasattr(self,"var_name") else "") or ""
                text = self.txt.get("1.0","end-1c") if hasattr(self,"txt") else ""
                ext  = (self.var_ext.get() if hasattr(self,"var_ext") else "").strip().lower()
                manual = bool(getattr(self,"var_ext_manual", False))
                def norm(e):
                    e = (e or "").strip().lower()
                    if not e: return ""
                    return e if e.startswith(".") else "."+e
                ext = norm(ext)
                if not manual:
                    if not ext and "." in name:
                        ext = "." + name.rsplit(".",1)[-1].lower()
                    if not ext:
                        head  = (text or "")[:2000].lower()
                        first = (text.splitlines()[:2] or [""])[0].lower()
                        if first.startswith("#!") and "python" in first: ext = ".py"
                        elif "@echo off" in head or (" %%" in head):     ext = ".bat"
                        elif head.strip().startswith("{") or head.strip().startswith("["): ext = ".json"
                        elif "[section" in head or "=" in head[:200]:     ext = ".ini"
                        elif "name:" in head and "jobs:" in head:         ext = ".yml"
                        elif "param(" in head and "-join" in head:        ext = ".ps1"
                        elif head.startswith("# ") or head.startswith("## "): ext = ".md"
                ok = bool(ext) and (ext in self._allowed_ext)
                if hasattr(self, "var_ext"): self.var_ext.set(ext or "")
                if not getattr(self, "var_name_manual", False) and not (name or "").strip():
                    ts = time.strftime("%Y%m%d_%H%M%S")
                    base = "snippet_" + ts + (ext or "")
                    if hasattr(self,"var_name"): self.var_name.set(base)
                if hasattr(self, "_update_led"):
                    try: self._update_led(self.led_detect, "green" if ok else "yellow")
                    except Exception: pass
                if hasattr(self, "_ping"):
                    try: self._ping("Erkennung: " + (ext or "(keine)"))
                    except Exception: pass
            except Exception:
                pass
        try:
            if hasattr(self,"txt"):
                self.txt.bind("<<Paste>>",   lambda e: (schedule(150), "break"))
                self.txt.bind("<Key>",       lambda e: (schedule(250), None))
                self.txt.bind("<<Modified>>",lambda e: (self.txt.edit_modified(False), schedule(300)))
        except Exception:
            pass
        schedule(0)
    except Exception:
        pass
"""

def _log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1171c {ts}] {msg}\n"
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def _backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "r", encoding="utf-8") as fi, open(dst, "w", encoding="utf-8", newline="") as fo:
        fo.write(fi.read())
    return dst

def _inject_helpers(src: str) -> tuple[str, bool]:
    if MARK_HELPERS in src:
        return src, False
    # nach helpers-Marker, sonst EOF
    m = re.search(r"(?m)^\s*#\s*-{2,}\s*helpers\s*-{2,}\s*$", src)
    pos = m.end() if m else len(src)
    return src[:pos] + "\n" + HELPERS + src[pos:], True

def _ensure_lifecycle_calls(src: str) -> tuple[str, bool]:
    """Hängt _intake_actions_bar_polish(self) und _intake_setup_detection(self) in den
       bestehenden R1170e-Lifecycle-Block, wenn sie dort noch fehlen."""
    if MARK_LIFE1170 not in src:
        _log("Warnung: R1170e-Lifecycle-Block nicht gefunden – keine Lifecycle-Aktualisierung.")
        return src, False
    # Extrahiere den Block-Bereich (von Marker bis vor nächste def/class mit gleicher Einrückung)
    m = re.search(r"(?m)^([ \t]*)" + re.escape(MARK_LIFE1170) + r"\s*$", src)
    base = m.group(1)
    start = m.end()
    pat_end = re.compile(r"(?m)^(%s)(def|class)\b" % re.escape(base))
    m_end = pat_end.search(src, start)
    end = m_end.start() if m_end else len(src)
    block = src[start:end]

    changed = False
    if "_intake_actions_bar_polish(self)" not in block:
        block = block.rstrip() + "\n" + base + "    _intake_actions_bar_polish(self)\n"
        changed = True
    if "_intake_setup_detection(self)" not in block:
        block = block.rstrip() + "\n" + base + "    _intake_setup_detection(self)\n"
        changed = True
    if not changed:
        return src, False
    return src[:start] + block + src[end:], True

def main() -> int:
    try:
        if not os.path.exists(TARGET):
            _log(f"Zieldatei fehlt: {TARGET}")
            return 1
        src = open(TARGET, "r", encoding="utf-8").read()
        changed = False

        # 1) Helper einfügen (unabhängig von _build_ui)
        src, ch = _inject_helpers(src); changed = changed or ch

        # 2) Lifecycle-Block erweitern (auf Basis R1170e)
        src, ch = _ensure_lifecycle_calls(src); changed = changed or ch

        if not changed:
            _log("Keine Änderung notwendig (bereits gepatcht).")
            return 0

        bak = _backup(TARGET); _log(f"Backup erstellt: {bak}")
        with open(TARGET, "w", encoding="utf-8", newline="\n") as f:
            f.write(src)

        # 3) Syntax-Check
        try:
            py_compile.compile(TARGET, doraise=True)
        except Exception as e:
            with open(bak, "r", encoding="utf-8") as fi, open(TARGET, "w", encoding="utf-8", newline="\n") as fo:
                fo.write(fi.read())
            _log("Syntax-Check FEHLER -> Rollback auf Backup.")
            _log("Traceback:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 1

        _log("Patch erfolgreich eingefügt und Syntax-Check OK.")
        return 0
    except Exception as e:
        _log("UNERWARTETER FEHLER:\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
