# -*- coding: utf-8 -*-
import io, os, py_compile, time, traceback

ROOT = r"D:\ShrimpDev"
DBG  = os.path.join(ROOT, "debug_output.txt")
FILES = [os.path.join(ROOT, "main_gui.py"),
         os.path.join(ROOT, "modules", "module_code_intake.py")]

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with io.open(DBG, "a", encoding="utf-8") as f:
        f.write(f"[1174w {ts}] {msg}\n")

def main():
    log("\n===== 1174w SyntaxSmoke =====")
    bad = 0
    for p in FILES:
        if not os.path.isfile(p):
            log(f"SKIP (fehlend): {p}")
            continue
        try:
            py_compile.compile(p, doraise=True)
            log(f"OK: {p}")
        except Exception as e:
            bad += 1
            log(f"FEHLER: {p}\n{''.join(traceback.format_exception(e))}")
    return 1 if bad else 0

if __name__ == "__main__":
    raise SystemExit(main())
