"""
Runner_1065_IntakeRescueAndRollback
- Prüft module_code_intake.py mit AST (Syntax).
- Führt Sanity-Guard gezielt aus.
- Wenn weiterhin Fehler: auto-Rollback auf das jüngste _Archiv-Backup,
  das syntaktisch gültig ist.
- Danach erneut Guard + Launch.

Kein inhaltlicher Umbau, nur Reparatur & Wiederherstellung.
"""
from __future__ import annotations
import os, re, ast, time, shutil, subprocess, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")
GUARD = os.path.join(ROOT, "tools", "Runner_1063_Intake_SanityGuard.py")

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1065] {ts} {msg}\n")
    except Exception:
        pass

def read_text(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def is_ast_ok(text: str) -> tuple[bool, str]:
    try:
        ast.parse(text)
        return True, ""
    except SyntaxError as e:
        return False, f"SyntaxError: {e.msg} (line {e.lineno}, col {e.offset})"

def run_guard_on(path: str) -> int:
    if not os.path.exists(GUARD):
        log("Guard nicht gefunden – übersprungen.")
        return 0
    py = sys.executable or "py"
    return subprocess.call([py, GUARD, "--file", path], cwd=ROOT)

def try_rollback() -> bool:
    """Suche jüngstes syntaktisch gültiges Backup und stelle es wieder her."""
    if not os.path.isdir(ARCH):
        log("Kein _Archiv-Ordner vorhanden.")
        return False
    pattern = re.compile(r"^module_code_intake\.py\.\d+\.bak$")
    candidates = []
    for fn in os.listdir(ARCH):
        if pattern.match(fn):
            full = os.path.join(ARCH, fn)
            candidates.append((os.path.getmtime(full), full))
    candidates.sort(reverse=True)  # jüngste zuerst
    for _, bak in candidates:
        try:
            txt = read_text(bak)
            ok, _ = is_ast_ok(txt)
            if ok:
                shutil.copy2(bak, MOD)
                log(f"Rollback auf {os.path.basename(bak)} durchgeführt.")
                return True
        except Exception as ex:
            log(f"Backup {bak} konnte nicht geprüft werden: {ex}")
    return False

def main() -> int:
    if not os.path.exists(MOD):
        log("module_code_intake.py fehlt – Abbruch.")
        return 2

    txt = read_text(MOD)
    ok, info = is_ast_ok(txt)
    if ok:
        log("AST ok. Führe Guard aus …")
        rc = run_guard_on(MOD)
        if rc != 0:
            log(f"Guard meldet Fehler (RC={rc}).")
            return rc
        # Nach Guard erneut prüfen
        txt = read_text(MOD)
        ok, info = is_ast_ok(txt)
        if ok:
            log("Intake repariert/ok.")
            return 0
        log(f"Nach Guard weiterhin Fehler: {info}")

    else:
        log(f"AST Fehler: {info}")

    # Rollback versuchen
    log("Versuche Rollback auf gültiges Backup …")
    if try_rollback():
        # Guard nach Rollback
        rc = run_guard_on(MOD)
        if rc != 0:
            log(f"Guard nach Rollback meldet Fehler (RC={rc}).")
            return rc
        txt = read_text(MOD)
        ok, info = is_ast_ok(txt)
        if ok:
            log("Rollback erfolgreich. Intake wieder startfähig.")
            return 0
        log(f"Rollback-Datei weiterhin fehlerhaft: {info}")

    log("Kein lauffähiges Backup gefunden. Manuelle Prüfung nötig.")
    return 1

if __name__ == "__main__":
    raise SystemExit(main())
