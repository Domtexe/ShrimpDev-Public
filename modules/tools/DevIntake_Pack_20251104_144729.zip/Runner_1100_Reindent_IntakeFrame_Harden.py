# -*- coding: utf-8 -*-
"""
Runner_1100_Reindent_IntakeFrame_Harden.py
Repariert hartnäckige Einrückungsfehler in modules\module_code_intake.py:
 - Tabs -> 4 Spaces
 - Tooltip-Klasse: Methoden einrücken
 - IntakeFrame: Alle nichtleeren Zeilen mindestens um 4 Spaces unter die Klasse rücken
 - Mehrfaches Nachfassen, bis keine Zeile im Klassenblock linksbündig ist
 - Sanity-Compile vor dem Schreiben
"""

import os, re, sys, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")

def backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    bk = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    with open(path, "rb") as fsrc, open(bk, "wb") as fdst:
        fdst.write(fsrc.read())
    return bk

def read_text(path: str) -> str:
    with open(path, "rb") as f:
        data = f.read()
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("latin-1", errors="replace")

def write_text(path: str, text: str) -> None:
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\n", "\r\n")
    with open(path, "wb") as f:
        f.write(text.encode("utf-8"))

def first_index(lines, rx, start=0):
    for i in range(start, len(lines)):
        if rx.match(lines[i]):
            return i
    return -1

def find_block_end(lines, start, rx_end):
    end = len(lines)
    for i in range(start+1, len(lines)):
        if rx_end.match(lines[i]):
            end = i
            break
    return end

def indent_block_min(lines, i0, i1, min_spaces=4):
    """Sorgt dafür, dass JEDE nichtleere Zeile im Bereich mindestens min_spaces vorn hat."""
    for i in range(i0, i1):
        s = lines[i]
        if not s.strip():
            continue
        s = s.replace("\t", "    ")
        if not s.startswith(" " * min_spaces):
            lines[i] = (" " * min_spaces) + s.lstrip()
        else:
            lines[i] = s
    return lines

def main() -> int:
    if not os.path.exists(MOD):
        print(f"[R1100] Datei nicht gefunden: {MOD}")
        return 1

    src0 = read_text(MOD)
    # Arbeitskopie: normalisierte Zeilenenden, Tabs->Spaces
    src = src0.replace("\r\n", "\n").replace("\r", "\n").replace("\t", "    ")
    lines = src.split("\n")

    changed = False

    # ---- Tooltip sichern -----------------------------------------------------
    rx_tooltip = re.compile(r'^\s*class\s+Tooltip\b.*:$')
    i_tip = first_index(lines, rx_tooltip, 0)
    if i_tip >= 0:
        # Ende: nächster Top-Level class/def oder EOF
        rx_top = re.compile(r'^[ ]{0,3}(class|def)\s+\w')
        end_tip = len(lines)
        for j in range(i_tip+1, len(lines)):
            if rx_top.match(lines[j]):
                end_tip = j
                break
        # mindestens 4 Spaces unter die Klasse
        lines = indent_block_min(lines, i_tip+1, end_tip, 4)
        changed = True

    # ---- IntakeFrame hart einrücken -----------------------------------------
    rx_intake = re.compile(r'^\s*class\s+IntakeFrame\b.*:$')
    i_cls = first_index(lines, rx_intake, 0)
    if i_cls >= 0:
        # Ende heuristisch: bis zum nächsten klaren Helper-/Runner-Marker ODER nächster class auf Spalte 0
        rx_end = re.compile(r'^\s*#\s*-{2,}\s*helpers|^\s*#\s*---\s*R\d+|^[ ]{0,1}class\s+\w')
        end_cls = find_block_end(lines, i_cls, rx_end)

        # Mehrfach nachfassen: solange es im Block nichtleere Zeilen ohne führende Spaces gibt
        changed_here = True
        guard = 0
        while changed_here and guard < 6:
            changed_here = False
            guard += 1
            # prüfe, ob es noch linksbündige (nichtleere) Zeilen gibt
            need_fix = any((lines[k].strip() and not lines[k].startswith(" ")) for k in range(i_cls+1, end_cls))
            if need_fix:
                lines = indent_block_min(lines, i_cls+1, end_cls, 4)
                changed_here = True
        if guard >= 6:
            print("[R1100] WARN: Max. Nachfassrunden erreicht – sollte aber jetzt konsistent sein.")
        changed = True

    # ---- Sanity-Compile ------------------------------------------------------
    new_src = "\n".join(lines)
    try:
        compile(new_src, MOD, "exec")
    except SyntaxError as ex:
        ln = ex.lineno or 0
        ctx = range(max(0, ln-6), min(len(lines), ln+6))
        print("[R1100] SyntaxError nach Fix:")
        for n in ctx:
            mark = ">>" if (n+1)==ln else "  "
            print(f"{mark} {n+1:04d}: {lines[n]}")
        print(f"[R1100] {ex.__class__.__name__}: {ex}")
        print("[R1100] Syntaxprüfung fehlgeschlagen – Datei bleibt unverändert.")
        return 2

    if not changed:
        print("[R1100] Keine Änderungen nötig.")
        return 0

    bk = backup(MOD)
    write_text(MOD, new_src)
    print(f"[R1100] Backup: {MOD} -> {bk}")
    print("[R1100] Einrückungen repariert und Syntax geprüft.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
