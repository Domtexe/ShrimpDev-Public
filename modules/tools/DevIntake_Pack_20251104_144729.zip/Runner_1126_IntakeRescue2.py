# -*- coding: utf-8 -*-
"""
Runner_1126_IntakeRescue2
Robuster Intake-Fix:
- findet die Klasse IntakeFrame zuverlässig (auch bei CRLF/Mischformaten),
- entfernt alte Editor-Guard-Segmente (1123/1124/1125) überall,
- injiziert stabile Editor-Guards (Paste/Key/Modified + Debounce) INSIDE der Klasse,
- setzt Bindings einmalig (Unbind + Rebind),
- zentral loggend (write_log), mit schluckendem Fallback,
- Backup + Report + Syntax-Check + Rollback.
"""
from __future__ import annotations

import os, re, time, shutil, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
REPO = ROOT / "_Reports"
ARCH.mkdir(exist_ok=True)
REPO.mkdir(exist_ok=True)
REPORT = REPO / "Runner_1126_IntakeRescue2_report.txt"

def rep(msg: str) -> None:
    with open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip() + "\n")

def backup(p: Path) -> Path:
    dst = ARCH / f"{p.name}.{int(time.time())}.bak"
    shutil.copy2(p, dst)
    rep(f"[Backup] {p} -> {dst}")
    return dst

# -------- robust class locator ------------------------------------------------
def find_intake_class_bounds(src: str) -> tuple[int, int]:
    """
    Findet Start/Ende des Klassenblocks 'IntakeFrame'.
    Start = Beginn der Class-Zeile; Ende = Beginn der nächsten Top-Level 'class ' Zeile oder Dateiende.
    """
    # tolerantes Match (Kommentare/Decorator denkbar):
    m = re.search(r'^[ \t]*class[ \t]+IntakeFrame\b[^\n]*:\s*\n', src, flags=re.MULTILINE)
    if not m:
        raise RuntimeError("IntakeFrame-Klasse nicht gefunden.")
    start = m.start()

    # Nächste Top-Level-Class (Spalte 0/whitespace + 'class ')
    m2 = re.search(r'^[ \t]*class[ \t]+\w+[^\n]*:\s*\n', src[m.end():], flags=re.MULTILINE)
    end = (m.end() + m2.start()) if m2 else len(src)
    return start, end

# -------- patch helpers -------------------------------------------------------
GUARD_BLOCK_PATTERNS = [
    # ganze markierte Blöcke entfernen (frühere Runner)
    (r'#\s*---\s*Editor-Event-Guards\s*\(1123\)[\s\S]*?#\s*---\s*/Editor-Event-Guards\s*\(1123\)\s*', ""),
    (r'#\s*---\s*Editor-Event-Guards\s*\(1124\)[\s\S]*?#\s*---\s*/Editor-Event-Guards\s*\(1124\)\s*', ""),
    (r'#\s*---\s*Editor-Event-Guards\s*\(1125\)[\s\S]*?#\s*---\s*/Editor-Event-Guards\s*\(1125\)\s*', ""),
]

METHOD_NAMES = [
    "_safe_write","_ensure_editor_bindings","_on_editor_paste",
    "_on_editor_key","_on_editor_modified","_schedule_detect",
    "_auto_detect_if_needed","_safe_detect",
]

def remove_old_methods(block: str) -> str:
    # Entfernt frühere Methodendefinitionen (nur innerhalb Klassenblock)
    for name in METHOD_NAMES:
        pat = rf'\n[ \t]*def[ \t]+{name}\s*\([^)]*\)\s*:[\s\S]*?(?=\n[ \t]*def[ \t]+|\n[ \t]*#\s*---|\Z)'
        block = re.sub(pat, "\n", block, flags=re.MULTILINE)
    return block

GUARDS_RAW = r'''
# --- Editor-Event-Guards (1126) -----------------------------------------
def _safe_write(self, prefix: str, message: str) -> None:
    """Zentral loggen; bei Problemen stiller Datei-Fallback."""
    try:
        from modules.snippets.logger_snippet import write_log as _w
        _w(prefix, message)
    except Exception:
        try:
            import time, os
            p = os.path.join(os.path.dirname(os.path.dirname(__file__)), "debug_output.txt")
            ts = time.strftime("%Y-%m-%d %H:%M:%S")
            with open(p, "a", encoding="utf-8", newline="\n") as f:
                f.write(f"[{prefix}] {ts} {message}\n")
        except Exception:
            pass

def _ensure_editor_bindings(self) -> None:
    """Einmalige Bindings: alte lösen, neu binden."""
    try:
        self.txt.unbind("<<Paste>>")
        self.txt.unbind("<Control-v>")
        self.txt.unbind("<<Modified>>")
        self.txt.unbind("<KeyRelease>")
    except Exception:
        pass
    self.txt.bind("<<Paste>>", self._on_editor_paste)
    self.txt.bind("<Control-v>", self._on_editor_paste)
    self.txt.bind("<<Modified>>", self._on_editor_modified)
    self.txt.bind("<KeyRelease>", self._on_editor_key)

def _on_editor_paste(self, _evt=None):
    """Beim Einfügen KEINE Events retriggern; nur Detect debouncen."""
    try:
        self._schedule_detect(220)
    except Exception as ex:
        self._safe_write("INTAKE", f"PASTE_ERR: {ex!r}")

def _on_editor_key(self, _evt=None):
    try:
        self._schedule_detect(250)
    except Exception as ex:
        self._safe_write("INTAKE", f"KEY_ERR: {ex!r}")

def _on_editor_modified(self, _evt=None):
    try:
        try:
            self.txt.edit_modified(False)
        except Exception:
            pass
        self._schedule_detect(300)
    except Exception as ex:
        self._safe_write("INTAKE", f"MODIFIED_ERR: {ex!r}")

def _schedule_detect(self, delay_ms: int = 250):
    """Debounce: vorherige Jobs abbrechen und neuen planen."""
    try:
        if getattr(self, "_detect_job", None):
            try:
                self.after_cancel(self._detect_job)
            except Exception:
                pass
        self._detect_job = self.after(delay_ms, self._auto_detect_if_needed)
    except Exception as ex:
        self._safe_write("INTAKE", f"SCHED_ERR: {ex!r}")

def _auto_detect_if_needed(self):
    try:
        self._ping("Auto-Erkennung…")
    except Exception:
        pass
    self._safe_detect()

def _safe_detect(self):
    try:
        if hasattr(self, "_detect"):
            self._detect()
    except Exception as ex:
        import traceback
        self._safe_write("INTAKE", "DETECT_ERR\n" + "".join(
            traceback.format_exception(type(ex), ex, ex.__traceback__)))
        try:
            self._update_led(self.led_detect, "yellow")
        except Exception:
            pass
# --- /Editor-Event-Guards (1126) ----------------------------------------
'''.lstrip("\n")

def indent_block(block: str, spaces: int = 4) -> str:
    pad = " " * spaces
    return "\n".join((pad + ln) if ln.strip() else ln for ln in block.splitlines())

def patch_source(src: str) -> str:
    # 1) Globale alte Guard-Blöcke (1123/1124/1125) entfernen
    for pat, repl in GUARD_BLOCK_PATTERNS:
        src, _ = re.subn(pat, repl, src, flags=re.DOTALL)

    # 2) Klassenbereich bestimmen
    c_start, c_end = find_intake_class_bounds(src)
    pre, cls_block, post = src[:c_start], src[c_start:c_end], src[c_end:]

    # 3) Innerhalb des Klassenblocks alte Methoden entfernen
    cls_block = remove_old_methods(cls_block)

    # 4) Nach der Erstellung des Textwidgets einmalig Bindings setzen
    cls_block = re.sub(
        r'(\bself\.txt\s*=\s*tk\.Text\([^)]*\)\s*\n)',
        r'\1        self._detect_job = None\n        self._ensure_editor_bindings()\n',
        cls_block, count=1
    )

    # 5) Guards anhängen (einmalig)
    if "Editor-Event-Guards (1126)" not in cls_block:
        cls_block = cls_block.rstrip() + "\n" + indent_block(GUARDS_RAW, 4) + "\n"

    return pre + cls_block + post

def main():
    with open(REPORT, "w", encoding="utf-8", newline="\n") as f:
        f.write("Runner_1126_IntakeRescue2 – Start\n")
    if not TARGET.exists():
        rep(f"[FEHLER] Datei fehlt: {TARGET}")
        return 2

    original = TARGET.read_text(encoding="utf-8")
    try:
        backup(TARGET)
        new_src = patch_source(original)
        # Syntaxprobe
        compile(new_src, str(TARGET), "exec")
        TARGET.write_text(new_src, encoding="utf-8", newline="\n")
        rep("[OK] Patch angewendet und Syntax OK.")
        return 0
    except Exception as ex:
        rep("[FEHLER] Patch fehlgeschlagen, Rollback …")
        TARGET.write_text(original, encoding="utf-8", newline="\n")
        rep("TRACE:\n" + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
