# -*- coding: utf-8 -*-
"""
Runner_1074b_DeleteButtons_WithRecycleBin_Fix
- Repariert unvollständige send_to_recycle_bin()
- Prüft und korrigiert def-Blöcke mit offener try-Struktur
- Wiederholt den Delete-Button-Patch falls nötig
"""

from __future__ import annotations
import os, re, time, shutil, ast

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
LOG  = os.path.join(ROOT, "debug_output.txt")

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1074b] {ts} {msg}\n")
    except Exception:
        pass

def rd(p):
    with open(p, "r", encoding="utf-8") as f: return f.read()

def wr_with_backup(p, data):
    os.makedirs(ARCH, exist_ok=True)
    bak = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bak)
    log(f"Backup: {p} -> {bak}")
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)

# ----------------------------------------------------------

def fix_recycle_bin_func(src: str) -> tuple[str, int]:
    """
    Prüft ob send_to_recycle_bin() unvollständig ist und ersetzt sie ggf. vollständig.
    """
    m = re.search(r'^\s*def\s+send_to_recycle_bin\s*\(.*?\):', src, re.MULTILINE)
    if not m:
        log("send_to_recycle_bin() nicht vorhanden – füge neue Version hinzu.")
    else:
        log("Unvollständige send_to_recycle_bin() wird ersetzt.")
        # gesamte def bis nächste def/class löschen
        start = m.start()
        m_next = re.search(r'^\s*(def|class)\s+\w+', src[m.end():], re.MULTILINE)
        end = m.end() + (m_next.start() if m_next else 0)
        src = src[:start] + src[end:]

    code = (
        "\n"
        "def send_to_recycle_bin(path: str) -> bool:\n"
        "    \"\"\"Verschiebt Datei/Ordner unter Windows in den Papierkorb (Recycle Bin).\"\"\"\n"
        "    try:\n"
        "        import ctypes, ctypes.wintypes as wt\n"
        "        FO_DELETE = 3\n"
        "        FOF_ALLOWUNDO = 0x0040\n"
        "        FOF_NOCONFIRMATION = 0x0010\n"
        "        class SHFILEOPSTRUCTW(ctypes.Structure):\n"
        "            _fields_ = [\n"
        "                (\"hwnd\", wt.HWND), (\"wFunc\", wt.UINT),\n"
        "                (\"pFrom\", wt.LPCWSTR), (\"pTo\", wt.LPCWSTR),\n"
        "                (\"fFlags\", wt.USHORT), (\"fAnyOperationsAborted\", wt.BOOL),\n"
        "                (\"hNameMappings\", wt.LPVOID), (\"lpszProgressTitle\", wt.LPCWSTR),\n"
        "            ]\n"
        "        op = SHFILEOPSTRUCTW()\n"
        "        op.hwnd = None\n"
        "        op.wFunc = FO_DELETE\n"
        "        op.pFrom = path + \"\\x00\\x00\"\n"
        "        op.pTo = None\n"
        "        op.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION\n"
        "        res = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))\n"
        "        return res == 0 and not bool(op.fAnyOperationsAborted)\n"
        "    except Exception:\n"
        "        return False\n"
    )
    src += "\n" + code + "\n"
    return src, 1

# ----------------------------------------------------------

def fix_open_try_blocks(src: str) -> tuple[str, int]:
    """
    Sucht nach 'try:'-Blöcken ohne except/finally und schließt sie defensiv mit 'except: pass'.
    """
    lines = src.splitlines()
    new_lines = []
    open_try = False
    changed = 0

    for i, ln in enumerate(lines):
        stripped = ln.strip()
        if stripped.startswith("try:"):
            open_try = True
            new_lines.append(ln)
            continue

        if open_try and (stripped.startswith("except") or stripped.startswith("finally")):
            open_try = False
            new_lines.append(ln)
            continue

        # Blockende erkannt – try wurde nie geschlossen
        if open_try and (stripped.startswith("def ") or stripped.startswith("class ") or stripped.startswith("return ") or stripped.startswith("#")):
            new_lines.append("        except Exception:\n            pass")
            changed += 1
            open_try = False

        new_lines.append(ln)

    if open_try:
        new_lines.append("        except Exception:\n            pass")
        changed += 1

    return "\n".join(new_lines), changed

# ----------------------------------------------------------

def main():
    if not os.path.exists(MOD):
        log(f"Datei fehlt: {MOD}")
        return 2

    s0 = rd(MOD)
    s = s0

    total = 0
    s, n = fix_open_try_blocks(s); total += n
    s, n = fix_recycle_bin_func(s); total += n

    try:
        ast.parse(s)
    except SyntaxError as e:
        log(f"SyntaxError nach Fix: {e}")
        lines = s.split("\n")
        for i in range(max(1, e.lineno - 5), min(len(lines), e.lineno + 5)):
            log(f"{i:04d}: {lines[i-1]}")
        return 3

    wr_with_backup(MOD, s)
    log(f"Syntax-Fix abgeschlossen. Änderungen: {total}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
