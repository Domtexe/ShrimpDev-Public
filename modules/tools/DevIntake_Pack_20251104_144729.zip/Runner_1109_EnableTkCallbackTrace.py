# -*- coding: utf-8 -*-
"""
Runner_1109_EnableTkCallbackTrace
- Patcht main_gui.py so, dass Tkinter-Callback-Ausnahmen
  vollständig nach debug_output.txt geschrieben werden.
"""
from __future__ import annotations
import os, re, time, io, traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MAIN = os.path.join(ROOT, "main_gui.py")
ARCH = os.path.join(ROOT, "_Archiv")

def backup(src):
    ts = int(time.time())
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, f"{os.path.basename(src)}.{ts}.bak")
    with open(src, "rb") as f, open(dst, "wb") as g:
        g.write(f.read())
    print(f"[R1109] Backup: {src} -> {dst}")
    return dst

def read(p):
    with open(p, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def write(p, t):
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(t)

TRACE_SNIPPET = r'''
# === R1109: Tk Callback Trace ===
def _install_tk_trace(root):
    import traceback, sys
    def _report_callback_exception(exc, val, tb):
        try:
            with open("debug_output.txt", "a", encoding="utf-8") as f:
                f.write("\n--- Tk-Callback-Exception ---\n")
                traceback.print_exception(exc, val, tb, file=f)
        except Exception:
            pass
    try:
        root.report_callback_exception = _report_callback_exception
    except Exception:
        pass
# === R1109 END ===
'''

def main():
    if not os.path.exists(MAIN):
        print("[R1109] main_gui.py nicht gefunden.")
        return 1

    src = read(MAIN)
    if "_install_tk_trace(" in src:
        print("[R1109] Tk-Trace bereits vorhanden – nichts zu tun.")
        return 0

    # Wir versuchen, nach der Root-Erstellung einzuhängen.
    # Heuristik: Suche nach 'root = tk.Tk()' und rufe danach _install_tk_trace(root) auf.
    m = re.search(r'^(?P<indent>\s*)root\s*=\s*tk\.Tk\(\)\s*$', src, re.M)
    if not m:
        print("[R1109] WARN: 'root = tk.Tk()' nicht gefunden – Patch übersprungen.")
        return 0

    indent = m.group("indent")
    injected = src[:m.end()] + "\n" + indent + "_install_tk_trace(root)\n" + src[m.end():]
    injected = TRACE_SNIPPET + "\n" + injected

    try:
        compile(injected, MAIN, "exec")
    except SyntaxError as e:
        print(f"[R1109] SyntaxError nach Patch (Zeile {e.lineno}): {e.msg}")
        print("[R1109] Datei bleibt UNVERÄNDERT.")
        return 2

    backup(MAIN)
    write(MAIN, injected)
    print("[R1109] Tk-Callback-Trace aktiviert (siehe debug_output.txt bei Fehlern).")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
