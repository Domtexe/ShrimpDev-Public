from __future__ import annotations
from pathlib import Path
import re, time, shutil

ROOT = Path(r"D:\ShrimpDev")
MOD  = ROOT/"modules"/"module_code_intake.py"
GUIDE= ROOT/"docs"/"Intake_Paste_Guide.md"

def ts(): return time.strftime("%Y%m%d_%H%M%S")

def backup(p: Path):
    if p.exists():
        b = p.with_suffix(p.suffix + f".{ts()}.bak")
        shutil.copy2(p, b)
        print(f"[R946] Backup: {b.name}")

SMART_EXTRACT = r'''
# === R946 Smart Extract: robust filename detection ===
import re
from pathlib import Path

_ALLOWED_EXT = {".py",".bat",".cmd",".vbs",".ps1",".md",".json",".txt"}
def _sanitize_name(name: str) -> str:
    name = name.strip().replace("\\", "/")
    name = re.sub(r'[^A-Za-z0-9_\-./]', "_", name)
    name = re.sub(r'/+', "/", name)
    name = name.lstrip("./")
    if ".." in name or name.startswith(("/", "~")):
        return ""
    return name

def _guess_ext_from_content(code: str) -> str|None:
    head = code[:800].lower()
    if head.startswith("@echo off") or " set " in head or " goto " in head:
        return ".bat"
    if "import " in head or "def " in head or "class " in head:
        return ".py"
    if head.strip().startswith("{"):
        return ".json"
    if "# " in head or "## " in head:
        return ".md"
    return None

def _map_target(workspace: Path, name: str, ext: str) -> Path:
    n = name.lower()
    if ext in {".bat",".cmd",".vbs",".ps1"}:     return workspace/"tools"
    if n.startswith("runner_") and ext==".py":    return workspace/"tools"
    if n.startswith("module_") and ext==".py":    return workspace/"modules"
    if ext==".py":                                return workspace/"modules"/"snippets"
    if ext in {".md",".json",".txt"}:            return workspace
    return workspace

def _extract(code: str) -> tuple[str|None, str|None]:
    head = code[:4000]  # großzügig
    # 1) file/path header (sprachneutral)
    pats = [
        r'(?im)^\s*[#;/]*\s*(?:file|filename|path)\s*:\s*(?P<p>[\w\-/\\\. ]+\.(py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        # 2) fenced code with filename=
        r'(?is)```[^`\n]*?\bfilename\s*=\s*(?P<p>[\w\-/\\\.]+)\s*```',
        # 3) YAML front matter
        r'(?is)^---\s*?\n(?:(?:.*?\n)*?)filename\s*:\s*(?P<p>[\w\-/\\\.]+)\n(?:.*?\n)*?---',
        # 4) JSON header
        r'(?is)^\{\s*"(?:file|filename|path)"\s*:\s*"(?P<p>[\w\-/\\\.]+)"\s*[,}]',
        # 5) inline compact marker
        r'(?i)@@file\s*=\s*(?P<p>[\w\-/\\\.]+)@@',
        # 6) pragmas
        r'(?im)^\s*(?:REM|::|;|//|\#)\s*FILE\s+(?P<p>[\w\-/\\\.]+)\s*$',
        # 7) hint by runner/module name in content
        r'(?i)\b(Runner_\d{3,}\.(?:py|bat|cmd|vbs))\b',
        r'(?i)\b(module_[\w\-]+\.py)\b',
    ]
    for pat in pats:
        m = re.search(pat, head)
        if m:
            p = m.group("p") if "p" in m.groupdict() else m.group(0)
            p = _sanitize_name(p)
            if not p: continue
            name = Path(p).name
            ext  = Path(name).suffix.lower()
            if ext and ext in _ALLOWED_EXT:
                return name, ext

    # 8) fallback: nur Endung raten
    ext = _guess_ext_from_content(code) or ".py"
    return None, ext
'''

GUIDE_MD = r'''# ShrimpDev – Code-Intake Schnellstart

**So erkennt der Intake den Dateinamen (beste Variante zuerst):**

1. Header-Kommentar:
   - `# file: tools/Runner_960.py`
   - `// path: modules/module_shcut_mapper.py`

2. Fenced Code-Block:
   - ``` ```python filename=tools/Runner_960.py ``` ```

3. Front-Matter:
   - YAML
     ```
     ---
     filename: tools/Runner_960.py
     ---
     ```
   - JSON
     ```json
     { "filename": "modules/module_xyz.py" }
     ```

4. Inline-Marker:
   - `@@file=tools/Runner_960.py@@`

5. Pragmas:
   - `REM FILE tools\Runner_960.bat`
   - `; FILE tools/Runner_960.cmd`

6. Heuristik:
   - `Runner_*` ⇒ `tools\`
   - `module_*` ⇒ `modules\`
   - sonst `.py` ⇒ `modules\snippets\`
   - Endungen aus Inhalt (py/bat/json/md)

> Tipp: Immer **Variante 1** benutzen – die ist am klarsten.
'''

def patch_intake():
    if not MOD.exists():
        print(f"[R946] FEHLT: {MOD}"); return 2
    backup(MOD)
    txt = MOD.read_text(encoding="utf-8", errors="ignore")
    # Ersetze nur die _extract / Mapping / Sanitize Sektion idempotent:
    # Entferne alte _extract-Def (falls vorhanden)
    txt = re.sub(r'\n\s*def\s+_extract\s*\(code:.*?\)\s*->\s*.*?\n\s*return\s+None,\s*None\s*\n', '\n', txt, flags=re.S)
    # Hänge neuen Block ans Ende (import-sicher, _extract wird von GUI genutzt)
    if "R946 Smart Extract" not in txt:
        txt += "\n" + SMART_EXTRACT + "\n"
        # Hook: falls IntakeWindow._detect existiert, nutzt sie _extract bereits;
        # ansonsten kein weiterer Eingriff nötig.
    MOD.write_text(txt, encoding="utf-8")
    GUIDE.parent.mkdir(parents=True, exist_ok=True)
    GUIDE.write_text(GUIDE_MD, encoding="utf-8")
    print("[R946] Intake smart-extract installiert + Guide erstellt.")
    return 0

if __name__ == "__main__":
    raise SystemExit(patch_intake())
