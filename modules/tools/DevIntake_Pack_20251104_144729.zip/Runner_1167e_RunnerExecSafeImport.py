# -*- coding: utf-8 -*-
"""
Runner_1167e_RunnerExecSafeImport
- Macht module_runner_exec._log() 100% robust (kein Crash beim GUI-Import).
- Idempotent, mit Backup, Syntax-Check und Rollback.
Exitcodes:
 0 = OK / bereits gepatcht
 1 = Fehler (Details in debug_output.txt)
"""
from __future__ import annotations
import os, re, time, py_compile, traceback

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TARGET = os.path.join(ROOT, "modules", "module_runner_exec.py")
ARCH   = os.path.join(ROOT, "_Archiv")
LOG    = os.path.join(ROOT, "debug_output.txt")

PATCH_MARK = "# R1167e: safe _log (no-crash on GUI import)"

SAFE_LOG_IMPL = f"""
def _log(msg: str) -> None:
    {PATCH_MARK}
    try:
        # Verzeichnisse sicherstellen (auch wenn ROOT/Datei während GUI-Start noch nicht da ist)
        try:
            os.makedirs(os.path.dirname(LOGFILE), exist_ok=True)
        except Exception:
            pass
        # Versuche zu schreiben; bei Problemen leise abbrechen, damit der Import nie scheitert
        try:
            with open(LOGFILE, "a", encoding="utf-8", newline="") as f:
                f.write((msg or "").rstrip() + "\\n")
        except Exception:
            pass
    except Exception:
        # Letzte Verteidigungslinie – niemals Exceptions aus _log() blubbern lassen
        pass
"""

def _log_local(s: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[1167e {ts}] {s}\n"
    try:
        with open(LOG, "a", encoding="utf-8", newline="") as f:
            f.write(line)
    except Exception:
        pass
    print(line, end="")

def _backup(path: str) -> str:
    os.makedirs(ARCH, exist_ok=True)
    ts = int(time.time())
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    with open(path, "r", encoding="utf-8") as fsrc, open(dst, "w", encoding="utf-8", newline="") as fdst:
        fdst.write(fsrc.read())
    return dst

def main() -> int:
    try:
        if not os.path.exists(TARGET):
            _log_local(f"Zieldatei fehlt: {TARGET}")
            return 1

        with open(TARGET, "r", encoding="utf-8") as f:
            src = f.read()

        # Bereits gepatcht?
        if PATCH_MARK in src:
            _log_local("Patch bereits vorhanden – keine Änderung notwendig.")
            return 0

        # Ersetze die bestehende _log()-Definition robust per Regex
        # Greife die erste def _log(...): bis zur nächsten def/EOF
        pat = r"(?s)\\ndef\\s+_log\\s*\\(.*?\\)\\s*:\\s*.*?(?=\\n\\s*def\\s+|\\Z)"
        if not re.search(pat, src):
            _log_local("Konnte def _log(...) nicht finden – Abbruch ohne Änderung.")
            return 1

        new_src = re.sub(pat, "\n" + SAFE_LOG_IMPL.strip() + "\n", src, count=1)

        # Backup + Schreiben
        bak = _backup(TARGET)
        _log_local(f"Backup erstellt: {bak}")

        with open(TARGET, "w", encoding="utf-8", newline="") as f:
            f.write(new_src)

        # Syntaxcheck
        try:
            py_compile.compile(TARGET, doraise=True)
        except Exception as e:
            # Rollback
            with open(bak, "r", encoding="utf-8") as fb, open(TARGET, "w", encoding="utf-8", newline="") as fw:
                fw.write(fb.read())
            _log_local("Syntax-Check FEHLER -> Rollback auf Backup.")
            _log_local("Traceback:\\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            return 1

        _log_local("Patch erfolgreich eingefügt und Syntax-Check OK.")
        return 0

    except Exception as e:
        _log_local("UNERWARTETER FEHLER:\\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
