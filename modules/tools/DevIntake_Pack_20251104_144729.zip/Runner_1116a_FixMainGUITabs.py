# -*- coding: utf-8 -*-
"""
Runner_1116a_FixMainGUITabs.py

Repariert main_gui.py:
- Sorgt dafür, dass für den "Code Intake"-Tab garantiert ein echter ttk.Frame
  als Notebook-Child existiert.
- Falls nur eine Klasse (z.B. IntakeFrame) instantiiert wird, wird sie in
  den Frame hineingebaut, und der Frame dem Notebook hinzugefügt.
- Idempotent + Syntax-Check + Backup.
"""
from __future__ import annotations
import os, re, ast, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MAIN = os.path.join(ROOT, "main_gui.py")
ARCH = os.path.join(ROOT, "_Archiv")
os.makedirs(ARCH, exist_ok=True)

def read(p): 
    with open(p,"r",encoding="utf-8") as f: return f.read()
def write(p,s):
    with open(p,"w",encoding="utf-8",newline="\n") as f: f.write(s)
def backup(p):
    q=os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak"); shutil.copy2(p,q); return q
def syntax_ok(code): 
    try: ast.parse(code); return True
    except Exception as ex: print("[R1116a] SyntaxError:", ex); return False

src = read(MAIN)
orig = src

# 1) Stelle sicher, dass ttk importiert ist
if not re.search(r"(?m)^from\s+tkinter\s+import\s+ttk\b", src):
    # wenn alternative Imports existieren, nicht doppeln
    if "ttk" not in src:
        src = src.replace("\nimport tkinter as tk\n", "\nimport tkinter as tk\nfrom tkinter import ttk\n")

# 2) Heuristisch die Stelle mit nb.add(..., text="Code Intake") finden
m = re.search(r'(?ms)^\s*nb\.add\(\s*(?P<child>\w+)\s*,\s*text\s*=\s*["\']Code Intake["\']\s*\)', src)
if m:
    child = m.group("child")
    # Prüfen, ob vor dieser Stelle ein Frame für child erzeugt wird
    head = src[:m.start()]
    if not re.search(rf'(?m)^\s*{child}\s*=\s*ttk\.Frame\(\s*nb\s*\)', head) and not re.search(rf'(?m)^\s*{child}\s*=\s*tk\.Frame\(\s*nb\s*\)', head):
        # Erzeuge vor nb.add den Frame + integriere IntakeFrame in diesen Container (falls sichtbar)
        inject = (
            f"\n# -- auto: robuster Tab-Container für Code Intake --\n"
            f"{child} = ttk.Frame(nb)\n"
            f"try:\n"
            f"    IntakeFrame({child})  # UI in den Tab-Frame bauen\n"
            f"except Exception:\n"
            f"    pass\n"
        )
        # Einfügen direkt vor nb.add-Zeile
        line_start = src.rfind("\n", 0, m.start()) + 1
        src = src[:line_start] + inject + src[line_start:]

if src != orig:
    if syntax_ok(src):
        bak = backup(MAIN)
        write(MAIN, src)
        print(f"[R1116a] Tabs repariert. Backup: {bak}")
    else:
        print("[R1116a] Abgebrochen (Syntax). Datei unverändert.")
else:
    print("[R1116a] Keine Änderungen nötig. (Tabs wirken bereits korrekt)")
