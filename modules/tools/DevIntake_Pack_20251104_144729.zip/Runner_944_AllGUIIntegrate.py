from __future__ import annotations
from pathlib import Path
import re, shutil, time

ROOT = Path(r"D:\ShrimpDev")
MAIN = ROOT / "main_gui.py"
AGENT = ROOT / "modules" / "module_agent.py"

def ts(): return time.strftime("%Y%m%d_%H%M%S")

def backup(p: Path):
    if p.exists():
        b = p.with_suffix(p.suffix + f".{ts()}.bak")
        shutil.copy2(p, b)
        print(f"[R944] Backup: {b.name}")

def patch_agent_idempotent():
    """Make agent start/stop idempotent."""
    if not AGENT.exists():
        print("[R944] WARN: module_agent.py fehlt – Agent-Patch übersprungen")
        return
    src = AGENT.read_text(encoding="utf-8", errors="ignore")
    changed = False

    # 1) AgentService: _started-Flag + Schutz in start/stop
    if "class AgentService" in src and "_started" not in src:
        src = re.sub(
            r"(class\s+AgentService\s*:\s*\n\s*def\s+__init__\(self\):\s*\n)",
            r"\1        self._started = False\n",
            src,
            flags=re.S
        )
        changed = True

    if "def start(self)" in src and "self._started" in src:
        pass
    elif "def start(self)" in src:
        src = re.sub(
            r"(def\s+start\(\s*self\s*\)\s*:\s*\n)",
            r"\1        if getattr(self, '_started', False): return\n        self._started = True\n",
            src
        )
        changed = True

    if "def stop(self)" in src and "self._started" in src:
        pass
    elif "def stop(self)" in src:
        src = re.sub(
            r"(def\s+stop\(\s*self\s*\)\s*:\s*\n)",
            r"\1        if not getattr(self, '_started', False): return\n        self._started = False\n",
            src
        )
        changed = True

    # 2) Globale Helfer (optional): start/stop Funktionen idempotent
    if "def start_agent(" not in src:
        src += (
            "\n\ndef start_agent():\n"
            "    try:\n"
            "        if not getattr(AGENT, '_started', False):\n"
            "            AGENT.start(); setattr(AGENT, '_started', True)\n"
            "    except Exception:\n"
            "        pass\n"
        )
        changed = True
    if "def stop_agent(" not in src:
        src += (
            "\n\ndef stop_agent():\n"
            "    try:\n"
            "        if getattr(AGENT, '_started', False):\n"
            "            AGENT.stop(); setattr(AGENT, '_started', False)\n"
            "    except Exception:\n"
            "        pass\n"
        )
        changed = True

    if changed:
        backup(AGENT)
        AGENT.write_text(src, encoding="utf-8")
        print("[R944] Agent idempotent gepatcht.")
    else:
        print("[R944] Agent-Patch nicht nötig (bereits idempotent).")

def patch_main_menu_and_agent_guard():
    """Add menu items + ensure single agent start; add dialogs for generators."""
    if not MAIN.exists():
        print("[R944] FEHLT: main_gui.py")
        return 2
    txt = MAIN.read_text(encoding="utf-8", errors="ignore")
    changed = False

    # 0) Importe für Dialoge/Subprocess
    if "import subprocess" not in txt:
        txt = txt.replace("from tkinter import ttk, messagebox",
                          "from tkinter import ttk, messagebox, simpledialog\nimport subprocess")
        changed = True
    elif "simpledialog" not in txt:
        txt = txt.replace("from tkinter import ttk, messagebox",
                          "from tkinter import ttk, messagebox, simpledialog")
        changed = True

    # 1) Agent-Start in __init__: gegen Mehrfachstart schützen
    # Suche Stelle "agent.AGENT.start()"
    if "agent.AGENT.start()" in txt and "getattr(agent.AGENT, '_started'" not in txt:
        txt = txt.replace(
            "agent.AGENT.start()",
            "    # R944 guard\n        try:\n"
            "            if not getattr(agent.AGENT, '_started', False):\n"
            "                agent.AGENT.start(); setattr(agent.AGENT, '_started', True)\n"
            "        except Exception:\n"
            "            pass"
        )
        changed = True

    # 2) Tools-Menü: Preflight (falls fehlt), New Module, New Runner
    if 'm_tools.add_command(label="Preflight Checks"' not in txt:
        txt = txt.replace(
            'm_tools.add_command(label="Code Intake (Ctrl+I)", command=lambda: open_intake(self))',
            'm_tools.add_command(label="Code Intake (Ctrl+I)", command=lambda: open_intake(self))\n'
            '        m_tools.add_command(label="Preflight Checks", command=lambda: open_preflight(self))'
        )
        changed = True

    if "New Module" not in txt:
        txt = txt.replace(
            'm_tools.add_command(label="Make Patch/Export", command=lambda: open_patch_release(self))',
            'm_tools.add_command(label="Make Patch/Export", command=lambda: open_patch_release(self))\n'
            '        m_tools.add_command(label="New Module…", command=self._new_module_dialog)\n'
            '        m_tools.add_command(label="New Runner…", command=self._new_runner_dialog)'
        )
        changed = True

    # 3) Methoden _new_module_dialog / _new_runner_dialog hinzufügen
    if "_new_module_dialog" not in txt:
        txt = txt.replace(
            "def _on_exit(self):",
            "def _new_module_dialog(self):\n"
            "        name = simpledialog.askstring('New Module', 'Modulname (ohne .py, mit/ohne module_):', parent=self)\n"
            "        if not name: return\n"
            "        desc = simpledialog.askstring('New Module', 'Beschreibung:', parent=self) or 'New module'\n"
            "        ver  = simpledialog.askstring('New Module', 'Version (SemVer):', parent=self) or '0.1.0'\n"
            "        try:\n"
            "            subprocess.run(['py','-3','-u','tools/Runner_942_NewModule.py', name, desc, ver], check=False)\n"
            "            self.status.set(f'New Module erstellt: {name}')\n"
            "        except Exception:\n"
            "            messagebox.showerror('ShrimpDev','New Module fehlgeschlagen.')\n\n"
            "    def _new_runner_dialog(self):\n"
            "        rid = simpledialog.askinteger('New Runner', 'Runner-ID (Zahl):', parent=self, minvalue=100, maxvalue=9999)\n"
            "        if not rid: return\n"
            "        desc = simpledialog.askstring('New Runner', 'Beschreibung:', parent=self) or 'New Runner'\n"
            "        try:\n"
            "            subprocess.run(['py','-3','-u','tools/Runner_943_NewRunner.py', str(rid), desc], check=False)\n"
            "            self.status.set(f'New Runner erstellt: {rid}')\n"
            "        except Exception:\n"
            "            messagebox.showerror('ShrimpDev','New Runner fehlgeschlagen.')\n\n"
            "    def _on_exit(self):"
        )
        changed = True

    if changed:
        backup(MAIN)
        MAIN.write_text(txt, encoding="utf-8")
        print("[R944] main_gui.py Menü/Hooks aktualisiert.")
    else:
        print("[R944] main_gui.py unverändert (bereits integriert).")
    return 0

def main():
    patch_agent_idempotent()
    rc = patch_main_menu_and_agent_guard()
    return rc or 0

if __name__ == "__main__":
    raise SystemExit(main())
