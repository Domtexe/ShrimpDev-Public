# -*- coding: utf-8 -*-
"""
Runner_1101a_FixReplace_RecycleBin.py
- Ersetzt den R1089-Recycle-Bin-Helper sicher (ohne re.sub-Template-Falle)
- Sanity-Compile prüft Syntax; bei Fehler bleibt die Datei unangetastet
"""

from __future__ import annotations
import os, re, time, io

ROOT = os.path.dirname(os.path.abspath(__file__))
MOD  = os.path.normpath(os.path.join(ROOT, "..", "modules", "module_code_intake.py"))
ARCH = os.path.normpath(os.path.join(ROOT, "..", "_Archiv"))

def _read(p):  # -> str
    with open(p, "rb") as f:
        return f.read().decode("utf-8", "replace")

def _write(p, s: str) -> None:
    with open(p, "wb") as f:
        f.write(s.encode("utf-8"))

def _backup(p) -> str:
    os.makedirs(ARCH, exist_ok=True)
    b = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    _write(b, _read(p))
    return b

def _sanity_compile(src: str):
    try:
        compile(src, MOD, "exec")
        return True, ""
    except SyntaxError as ex:
        ln = ex.lineno or 0
        lines = src.splitlines()
        lo = max(1, ln - 10); hi = min(len(lines), ln + 10)
        buf = io.StringIO()
        print(f"SyntaxError: {ex.msg} (line {ln})", file=buf)
        print("---- context ----", file=buf)
        for n in range(lo, hi + 1):
            print(f"{n:04d}: {lines[n-1]}", file=buf)
        print("--------------", file=buf)
        return False, buf.getvalue()

def main():
    src0 = _read(MOD)

    # Block durch Regex finden (Markerzeile beginnt mit R1089)
    rx_bin = re.compile(r"(?ms)^#\s*---\s*R1089:[^\n]*\n.*?\n#\s*-{5,}.*?$")
    repl = (
        "# --- R1089: Windows Recycle Bin helper ---------------------------------------\n"
        "def _send_to_recycle_bin(path: str) -> bool:\n"
        "    try:\n"
        "        import ctypes\n"
        "        from ctypes import wintypes\n"
        "    except Exception:\n"
        "        return False\n"
        "    if not os.path.exists(path):\n"
        "        return False\n"
        "    FO_DELETE = 3\n"
        "    FOF_ALLOWUNDO = 0x0040\n"
        "    FOF_NOCONFIRMATION = 0x0010\n"
        "\n"
        "    class SHFILEOPSTRUCTW(ctypes.Structure):\n"
        "        _fields_ = [\n"
        "            (\"hwnd\", wintypes.HWND),\n"
        "            (\"wFunc\", wintypes.UINT),\n"
        "            (\"pFrom\", wintypes.LPCWSTR),\n"
        "            (\"pTo\", wintypes.LPCWSTR),\n"
        "            (\"fFlags\", ctypes.c_uint16),\n"
        "            (\"fAnyOperationsAborted\", wintypes.BOOL),\n"
        "            (\"hNameMappings\", ctypes.c_void_p),\n"
        "            (\"lpszProgressTitle\", wintypes.LPCWSTR),\n"
        "        ]\n"
        "\n"
        "    # doppelt nullterminiert laut SHFileOperationW-Doku\n"
        "    pFrom = path + \"\\x00\\x00\"\n"
        "    sh = SHFILEOPSTRUCTW(\n"
        "        hwnd=None, wFunc=FO_DELETE, pFrom=pFrom, pTo=None,\n"
        "        fFlags=FOF_ALLOWUNDO | FOF_NOCONFIRMATION,\n"
        "        fAnyOperationsAborted=False, hNameMappings=None, lpszProgressTitle=None,\n"
        "    )\n"
        "    rc = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(sh))\n"
        "    return rc == 0 and not sh.fAnyOperationsAborted\n"
        "# -----------------------------------------------------------------------------\n"
    )

    if not rx_bin.search(src0):
        print("[R1101a] R1089-Block nicht gefunden – keine Änderungen nötig.")
        return 0

    # WICHTIG: Funktion als Replacement, damit Backslashes *nicht* als Template geparst werden
    src1 = rx_bin.sub(lambda m: repl, src0)

    if src1 == src0:
        print("[R1101a] Keine Änderungen durchgeführt.")
        return 0

    ok, info = _sanity_compile(src1)
    bkp = _backup(MOD)
    print(f"[R1101a] Backup: {MOD} -> {bkp}")
    if not ok:
        print("[R1101a] Syntaxprüfung FEHLGESCHLAGEN – Datei bleibt unverändert.")
        print(info)
        return 2

    _write(MOD, src1)
    print("[R1101a] Recycle-Bin-Block ersetzt und Syntax geprüft.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
