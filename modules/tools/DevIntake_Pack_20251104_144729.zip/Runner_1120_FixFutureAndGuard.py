# -*- coding: utf-8 -*-
r"""
Runner_1120_FixFutureAndGuard
Repariert main_gui.py:
  1) Sammelt alle `from __future__ import ...`-Zeilen und verschiebt sie
     direkt an den Dateibeginn (nach Shebang/Encoding/Leitkommentaren).
  2) Entfernt evtl. vorherige 1118/1119-Guard-Snippets.
  3) Fügt den Top-Level-Tk-Guard NACH den __future__-Imports wieder ein.
     (Idempotent, keine Duplikate.)
Backups in _Archiv/, Report in _Reports/.
"""

from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
REPO = os.path.join(ROOT, "_Reports")
os.makedirs(ARCH, exist_ok=True)
os.makedirs(REPO, exist_ok=True)

REPORT = os.path.join(REPO, "Runner_1120_FixFutureAndGuard_report.txt")

def rep(msg: str) -> None:
    with open(REPORT, "a", encoding="utf-8", newline="\n") as f:
        f.write(msg.rstrip() + "\n")

def backup(path: str) -> str:
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, dst)
    rep(f"[Backup] {path} -> {dst}")
    return dst

GUARD_TAG_1119 = "# === 1119 TopLevel Tk Guard (auto) ==="
GUARD_END_1119 = "# === /1119 ==="
GUARD_TAG_1118B = "def _install_global_tk_guard():"
GUARD_TAG_1118  = "def _install_safe_tk_handler(root):"

def make_guard_snippet() -> str:
    return (
        f"\n{GUARD_TAG_1119}\n"
        "def __install_toplevel_tk_guard__():\n"
        "    import tkinter as _tk, sys, traceback, time, os\n"
        "    LOG = os.path.join(os.path.dirname(__file__), 'debug_output.txt')\n"
        "    busy = {'v': False}\n"
        "    def _safe_write(txt: str):\n"
        "        try:\n"
        "            with open(LOG, 'a', encoding='utf-8') as f:\n"
        "                f.write(txt)\n"
        "        except Exception:\n"
        "            pass\n"
        "    def _handler(exc, val, tb):\n"
        "        if busy['v']:\n"
        "            return\n"
        "        busy['v'] = True\n"
        "        try:\n"
        "            ts = time.strftime('%Y-%m-%d %H:%M:%S')\n"
        "            lines = ''.join(traceback.format_exception(exc, val, tb))\n"
        "            _safe_write(f\"[TK-EXC] {ts}\\n\" + lines + \"\\n\")\n"
        "        finally:\n"
        "            busy['v'] = False\n"
        "    try:\n"
        "        _tk.Misc.report_callback_exception = _handler  # type: ignore[attr-defined]\n"
        "    except Exception:\n"
        "        pass\n"
        "    try:\n"
        "        def _safe__report_exception(self):\n"
        "            et, ev, tb = sys.exc_info()\n"
        "            if et is not None:\n"
        "                _handler(et, ev, tb)\n"
        "        _tk.BaseWidget._report_exception = _safe__report_exception  # type: ignore[attr-defined]\n"
        "    except Exception:\n"
        "        pass\n"
        "    try:\n"
        "        from tkinter import messagebox as _mb\n"
        "        def _silent(*_a, **_k):\n"
        "            return None\n"
        "        for _n in ('showerror','showwarning','showinfo','askyesno','askokcancel'):\n"
        "            if hasattr(_mb, _n):\n"
        "                setattr(_mb, _n, _silent)\n"
        "    except Exception:\n"
        "        pass\n"
        "\n"
        "__install_toplevel_tk_guard__()\n"
        f"{GUARD_END_1119}\n"
    )

def extract_header_block(src: str) -> tuple[int, int]:
    """
    Liefert Start/Ende des erlaubten Headerbereichs (Shebang/Encoding/Leitkommentare).
    """
    lines = src.splitlines(True)
    i = 0
    # Shebang / coding / leere Zeilen / reine Kommentarzeilen zulassen
    while i < len(lines):
        s = lines[i]
        if s.startswith("#!") or re.match(r"#.*coding[:=]", s) or s.strip() == "" or s.lstrip().startswith("#"):
            i += 1
            continue
        break
    return (0, sum(len(x) for x in lines[:i]))

def collect_future_imports(src: str) -> tuple[str, str]:
    """
    Sammelt alle from __future__ import ...-Zeilen überall im File.
    Entfernt sie an den Originalstellen und gibt (future_block, remaining_src) zurück.
    """
    future_lines = []
    remaining = []
    for line in src.splitlines(True):
        if re.match(r"\s*from\s+__future__\s+import\s+.+", line):
            # normalisieren: am Zeilenanfang, keine führenden Spaces
            future_lines.append(re.sub(r"^\s+", "", line))
        else:
            remaining.append(line)
    # eindeutige Reihenfolge beibehalten
    seen = set()
    uniq = []
    for l in future_lines:
        if l not in seen:
            uniq.append(l)
            seen.add(l)
    return ("".join(uniq), "".join(remaining))

def remove_old_guards(src: str) -> tuple[str, bool]:
    changed = False
    # 1119 Block entfernen (tagged)
    src2, n = re.subn(
        re.escape(GUARD_TAG_1119) + r"[\s\S]*?" + re.escape(GUARD_END_1119),
        "",
        src,
        flags=re.MULTILINE
    )
    if n:
        changed = True
    src = src2
    # 1118b / 1118 Reste konservativ tilgen (Funktionsdefs)
    for pat in (GUARD_TAG_1118B, GUARD_TAG_1118):
        src2, n = re.subn(rf"\n?^[ \t]*def[ \t]+{re.escape(pat.split()[1])}[\s\S]*?(?=\n^[^\s]|$\Z)",
                          "\n", src, flags=re.MULTILINE)
        if n:
            changed = True
            src = src2
    return src, changed

def patch_main_gui() -> None:
    p = os.path.join(ROOT, "main_gui.py")
    if not os.path.exists(p):
        rep("[main_gui] nicht gefunden – Abbruch.")
        return

    src = open(p, "r", encoding="utf-8").read()

    # 1) EVTL. alte Guards entfernen
    src, removed = remove_old_guards(src)
    if removed:
        rep("[main_gui] Alte Guard-Snippets entfernt.")

    # 2) Future-Imports einsammeln
    futures, remaining = collect_future_imports(src)
    if not futures:
        rep("[main_gui] Keine __future__-Imports gefunden – weiter.")
    else:
        rep(f"[main_gui] {len(futures.splitlines())} __future__-Zeile(n) eingesammelt.")

    # 3) Header-Bereich bestimmen
    h0, h1 = extract_header_block(remaining)
    header = remaining[h0:h1]
    body   = remaining[h1:]

    # 4) Zusammenbauen: Header + Future + Guard + Body
    guard = make_guard_snippet()
    new_src = header + futures + ("\n" if futures and not futures.endswith("\n") else "") + guard + body

    # 5) Schreiben (Backup vorher)
    backup(p)
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(new_src)
    rep("[main_gui] Future-Imports nach oben verschoben und Guard danach eingefügt.")

def main():
    with open(REPORT, "w", encoding="utf-8", newline="\n") as f:
        f.write("Runner_1120_FixFutureAndGuard – Start\n")
    try:
        patch_main_gui()
        rep("OK – Runner abgeschlossen.")
    except Exception as ex:
        rep("FEHLER: " + repr(ex))

if __name__ == "__main__":
    main()
