# -*- coding: utf-8 -*-
"""
Runner_1106b_IntegrateGuard_UI
- Fügt einen Toolbar-Button "Prüfen (Guard)" ein
- Ergänzt den Handler _on_click_guard(), der den integrierten Guard ausführt
- Sucht robuste Einfügepunkte; macht Backup; schreibt Änderungen nur, wenn nötig
"""

from __future__ import annotations
import os, re, time, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
ARCH = os.path.join(ROOT, "_Archiv")
GUARD = os.path.join(ROOT, "tools", "Runner_1106_ShrimpGuard_Integriert.py")

def backup(path: str) -> str:
    ts = int(time.time())
    dst = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    os.makedirs(ARCH, exist_ok=True)
    with open(path, "rb") as fsrc, open(dst, "wb") as fdst:
        fdst.write(fsrc.read())
    print(f"[R1106b] Backup: {path} -> {dst}")
    return dst

def read(path: str) -> str:
    with open(path, "rb") as f:
        raw = f.read()
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("latin-1", errors="replace")

def write(path: str, txt: str) -> None:
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(txt)

def ensure_imports(src: str) -> tuple[str, bool]:
    need = ["import tempfile", "import subprocess", "import sys", "import os"]
    changed = False
    head = src.splitlines()
    # finde erste sinnvolle Insert-Position nach from __future__/coding und Standardimports
    ins_idx = 0
    for i, line in enumerate(head[:60]):
        if line.strip().startswith("import ") or line.strip().startswith("from "):
            ins_idx = i + 1
    new_imps = []
    for imp in need:
        if imp not in src:
            new_imps.append(imp)
    if new_imps:
        block = "\n" + "\n".join(new_imps) + "\n"
        src = src[:src.find("\n", 0, len("\n".join(head[:max(ins_idx,1)])))+1] + block + src[src.find("\n", 0, len("\n".join(head[:max(ins_idx,1)])))+1:]
        changed = True
    return src, changed

def inject_button(src: str) -> tuple[str, bool]:
    """
    Sucht die Toolbar-Zeile (bar = ttk.Frame(self)) und fügt Button + grid ein,
    falls noch nicht vorhanden.
    """
    if "Prüfen (Guard)" in src or "_on_click_guard" in src:
        return src, False

    # 1) Stelle finden, an der Buttons erzeugt werden
    m_bar = re.search(r"(?m)^\s*bar\s*=\s*ttk\.Frame\(self\).*?$", src)
    if not m_bar:
        print("[R1106b] WARN: Keine Toolbar-Zeile 'bar = ttk.Frame(self)' gefunden – Button wird nicht gesetzt.")
        return src, False

    insert_at = m_bar.end()
    # 2) Versuche, ein grid-Segment für Buttons zu finden, um den Button nahe bei Detect/Save/Delete einzufügen.
    #    Fallback: einfügen direkt nach 'bar = ttk.Frame(self)'.
    grid_block_pat = re.compile(r"(?ms)"                             
                                r"(^\s*#\s*Guard-Button.*?$.*?^)\s*#", 
                                re.MULTILINE)
    # Falls es schon einen Guard-Block gibt, nichts tun.
    if re.search(r"(?m)^\s*self\.btn_guard\b", src):
        return src, False

    btn_block = (
        "\n"
        "        # Guard-Button\n"
        "        self.btn_guard = ttk.Button(bar, text='Prüfen (Guard)', command=self._on_click_guard)\n"
        "        try:\n"
        "            self.btn_guard.grid(row=0, column=2, padx=(4,0), sticky='w')\n"
        "        except Exception:\n"
        "            pass\n"
    )

    # Füge hinter der Toolbar-Zeile ein
    new_src = src[:insert_at] + "\n" + btn_block + src[insert_at:]
    return new_src, True

def inject_handler(src: str) -> tuple[str, bool]:
    if "_on_click_guard(" in src:
        return src, False

    # Einfügepunkt: innerhalb der IntakeFrame-Klasse, möglichst vor andere Handler.
    m_cls = re.search(r"(?ms)^\s*class\s+IntakeFrame\b.*?:\s*$", src)
    if not m_cls:
        print("[R1106b] WARN: class IntakeFrame nicht gefunden – Handler wird ans Ende des Files gehängt.")
        indent = ""
        anchor = len(src)
    else:
        anchor = m_cls.end()
        indent = "    "  # 4 Spaces innerhalb Klasse

    handler = (
        f"\n{indent}def _on_click_guard(self, _evt=None):\n"
        f"{indent}    \"\"\"Führt den integrierten Guard aus und zeigt Status in lbl_ping an.\"\"\"\n"
        f"{indent}    try:\n"
        f"{indent}        import tempfile, subprocess, sys, os\n"
        f"{indent}        guard = os.path.join('tools', 'Runner_1106_ShrimpGuard_Integriert.py')\n"
        f"{indent}        tmp = tempfile.NamedTemporaryFile(prefix='shrimp_runner_', suffix='.txt', delete=False)\n"
        f"{indent}        tmp.write(self.txt.get('1.0', 'end-1c').encode('utf-8'))\n"
        f"{indent}        tmp.close()\n"
        f"{indent}        cmd = [sys.executable, '-3', guard, '--check-text', tmp.name]\n"
        f"{indent}        # Runner-Dateiname (falls gesetzt) zusätzlich prüfen/ausführen\n"
        f"{indent}        try:\n"
        f"{indent}            rn = getattr(self, 'var_name', None)\n"
        f"{indent}            if rn is not None:\n"
        f"{indent}                name = rn.get().strip()\n"
        f"{indent}                if name and name.startswith('Runner_'):\n"
        f"{indent}                    rpath = os.path.join('tools', f\"{name}.py\")\n"
        f"{indent}                    if os.path.exists(rpath):\n"
        f"{indent}                        cmd += ['--run', rpath]\n"
        f"{indent}        except Exception:\n"
        f"{indent}            pass\n"
        f"{indent}        proc = subprocess.run(cmd, capture_output=True, text=True)\n"
        f"{indent}        out = (proc.stdout or '') + (proc.stderr or '')\n"
        f"{indent}        with open('debug_output.txt', 'w', encoding='utf-8') as f:\n"
        f"{indent}            f.write(out)\n"
        f"{indent}        if proc.returncode == 0:\n"
        f"{indent}            self.lbl_ping.configure(text='✅ Guard OK')\n"
        f"{indent}        elif proc.returncode == 1:\n"
        f"{indent}            self.lbl_ping.configure(text='⚠️ Guard: Warnungen')\n"
        f"{indent}        else:\n"
        f"{indent}            self.lbl_ping.configure(text='❌ Guard: Fehler – siehe debug_output.txt')\n"
        f"{indent}    except Exception as ex:\n"
        f"{indent}        try:\n"
        f"{indent}            self.lbl_ping.configure(text=f'❌ Guard-Fehler: {{ex}}')\n"
        f"{indent}        except Exception:\n"
        f"{indent}            pass\n"
    )
    new_src = src[:anchor] + handler + src[anchor:]
    return new_src, True

def main():
    if not os.path.exists(MOD):
        print(f"[R1106b] ERROR: nicht gefunden: {MOD}")
        return 1
    src = read(MOD)
    orig = src

    changed_any = False
    src, ch = ensure_imports(src); changed_any |= ch
    src, ch = inject_button(src);   changed_any |= ch
    src, ch = inject_handler(src);  changed_any |= ch

    if not changed_any:
        print("[R1106b] Keine Änderungen nötig.")
        return 0

    backup(MOD)
    # Sanity-Compile nur wenn möglich
    try:
        compile(src, MOD, "exec")
    except SyntaxError as e:
        print(f"[R1106b] SyntaxError nach Patch in Zeile {e.lineno}: {e.msg}")
        print("[R1106b] Datei bleibt UNVERÄNDERT.")
        return 2

    write(MOD, src)
    print("[R1106b] Guard-UI integriert.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
