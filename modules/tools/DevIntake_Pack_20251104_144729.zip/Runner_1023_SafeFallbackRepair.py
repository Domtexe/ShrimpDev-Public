"""
Runner_1023_SafeFallbackRepair
Repariert defekte Fallback-Funktionen in main_gui.py (NameError: ex not defined)
Version -> v9.9.14
"""
import os, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
GUI  = os.path.join(ROOT, "main_gui.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

SAFE_FALLBACKS = r'''
# ---- Safe imports for frames (with fallbacks) ----
try:
    from modules.module_code_intake import IntakeFrame
except Exception:
    def IntakeFrame(master):
        import tkinter as tk, tkinter.ttk as ttk, traceback
        frm = ttk.Frame(master)
        txt = tk.Text(frm, height=12, wrap="word")
        txt.pack(fill="both", expand=True, padx=8, pady=8)
        msg = "Fehler: IntakeFrame konnte nicht geladen werden.\\n\\n" + traceback.format_exc()
        txt.insert("end", msg)
        return frm

try:
    from modules.module_agent_ui import AgentFrame
except Exception:
    def AgentFrame(master):
        import tkinter as tk, tkinter.ttk as ttk, traceback
        frm = ttk.Frame(master)
        ttk.Label(frm, text="Agent-UI konnte nicht geladen werden.").pack(padx=10, pady=10)
        tk.Message(frm, text=traceback.format_exc(), width=900).pack(padx=10, pady=4)
        return frm

try:
    from modules.module_project_ui import ProjectFrame
except Exception:
    def ProjectFrame(master):
        import tkinter as tk, tkinter.ttk as ttk, traceback
        frm = ttk.Frame(master)
        ttk.Label(frm, text="Project-UI konnte nicht geladen werden.").pack(padx=10, pady=10)
        tk.Message(frm, text=traceback.format_exc(), width=900).pack(padx=10, pady=4)
        return frm
# -----------------------------------------------
'''

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[R1023] {ts} {msg}\n")
    print(msg)

def backup_write(path, data):
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(path)}.{int(time.time())}.bak")
    shutil.copy2(path, bck)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    log(f"Backup: {path} -> {bck}")

def patch():
    with open(GUI, "r", encoding="utf-8") as f:
        src = f.read()

    start = src.find("# ---- Safe imports for frames")
    end   = src.find("# -----------------------------------------------", start)
    if start == -1 or end == -1:
        raise RuntimeError("Kein erkennbarer Safe-Import-Block gefunden.")
    new_src = src[:start] + SAFE_FALLBACKS + src[end+len("# -----------------------------------------------"):]
    backup_write(GUI, new_src)
    with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
        f.write("ShrimpDev v9.9.14\n")
    with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
        f.write("""
## v9.9.14 (2025-10-18)
- main_gui: Fallback-Frames komplett neu geschrieben (keine 'ex not defined'-Fehler mehr)
""")
    log("Patch erfolgreich.")
    return 0

if __name__ == "__main__":
    raise SystemExit(patch())
