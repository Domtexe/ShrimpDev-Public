from __future__ import annotations
from pathlib import Path
import re, time, shutil, py_compile, sys

ROOT = Path(r"D:\ShrimpDev")
MAIN = ROOT / "main_gui.py"

TEMPLATE = (
    'if __name__ == "__main__":\n'
    '    try:\n'
    '        log("[BOOT] launching")\n'
    '        app = ShrimpDevApp()\n'
    '        app.mainloop()\n'
    '    except Exception as ex:\n'
    '        try:\n'
    '            log(f"[FATAL] {ex}")\n'
    '        except Exception:\n'
    '            pass\n'
)

def ts(): return time.strftime("%Y%m%d_%H%M%S")

def backup(p: Path):
    if p.exists():
        b = p.with_suffix(p.suffix + f".{ts()}.bak")
        shutil.copy2(p, b)
        print(f"[R957] Backup: {b.name}")

def patch_main_block(txt: str) -> tuple[str,bool]:
    """
    Ersetze den gesamten __main__-Block durch das saubere TEMPLATE.
    Falls kein __main__ vorhanden, hänge ihn am Ende an.
    """
    # finde Beginn von __main__
    pat_start = re.compile(r'(?m)^\s*if __name__\s*==\s*[\'"]__main__[\'"]\s*:\s*$')
    m = pat_start.search(txt)
    if not m:
        # Kein Block: einfach anhängen
        if not txt.endswith("\n"):
            txt += "\n"
        txt += "\n" + TEMPLATE
        return txt, True

    start = m.start()
    # Ende des Files = Ende des Blocks (robust genug)
    new = txt[:start] + TEMPLATE + ("\n" if not txt.endswith("\n") else "")
    return new, True

def compile_ok(p: Path) -> tuple[bool,str]:
    try:
        py_compile.compile(str(p), doraise=True)
        return True, ""
    except Exception as ex:
        return False, str(ex)

def main() -> int:
    if not MAIN.exists():
        print("[R957] FEHLT: main_gui.py"); return 2
    backup(MAIN)
    txt = MAIN.read_text(encoding="utf-8", errors="ignore")
    new, changed = patch_main_block(txt)
    if changed:
        MAIN.write_text(new, encoding="utf-8")
        print("[R957] __main__-Block ersetzt.")
    else:
        print("[R957] Keine Änderung vorgenommen.")

    ok, err = compile_ok(MAIN)
    if ok:
        print("[R957] Syntax OK – main_gui.py kompiliert.")
        return 0
    else:
        print(f"[R957] FEHLER bleibt: {err}")
        # Fehlerkontext grob ausgeben
        m = re.search(r'\(main_gui\.py,\s*line\s*(\d+)\)', err)
        if m:
            ln = int(m.group(1))
            lines = MAIN.read_text(encoding="utf-8", errors="ignore").splitlines()
            lo, hi = max(0, ln-4), min(len(lines), ln+3)
            print("[R957] Kontext:")
            for i in range(lo, hi):
                mark = ">>" if (i+1)==ln else "  "
                print(f"{mark} {i+1:4d}: {lines[i]}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
