# -*- coding: utf-8 -*-
"""
Runner_1177j_IntakeShimHardFix
Ersetzt modules/module_shim_intake.py durch einen robusten Adapter:
- Einheitliche API: mount_intake_tab(), _mount_intake_tab_shim(), _remount_intake_tab_shim()
- Importiert strikt 'from modules import module_code_intake as intake'
- Montiert echten IntakeFrame in das übergebene Notebook
- Fallback-Frame mit sichtbarer Fehlermeldung + Log in debug_output.txt
"""
from __future__ import annotations
import os, datetime, shutil

ROOT = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
MODS = os.path.join(ROOT, "modules")
ARCH = os.path.join(ROOT, "_Archiv")
LOGF = os.path.join(ROOT, "debug_output.txt")
TARGET = os.path.join(MODS, "module_shim_intake.py")

def ts(): return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def log(msg: str):
    try:
        with open(LOGF, "a", encoding="utf-8") as f:
            f.write(f"[{ts()}] [R1177j] {msg}\n")
    except Exception:
        pass

PAYLOAD = r'''# -*- coding: utf-8 -*-
"""
module_shim_intake – R1177j
Robuster Intake-Adapter für ShrimpDev.

Öffentliche API (Masterregel-konform):
- mount_intake_tab(nb)
- _mount_intake_tab_shim(nb)
- _remount_intake_tab_shim(nb)

Verhalten:
- Versucht, 'modules.module_code_intake.IntakeFrame' zu importieren
- Montiert Tab "Intake" in übergebenes ttk.Notebook nb
- Loggt jeden Fehler in debug_output.txt und zeigt eine sichtbare Meldung im Tab
"""
from __future__ import annotations
import os, traceback
import tkinter as tk
from tkinter import ttk

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
LOG_FILE = os.path.join(ROOT, "debug_output.txt")

_TAB_NAME = "Intake"
_TAG = "[IntakeShim]"

def _log(msg: str) -> None:
    try:
        import datetime
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] {_TAG} {msg}\n")
    except Exception:
        pass

def _find_tab_index(nb: ttk.Notebook, text: str) -> int | None:
    try:
        for i in range(len(nb.tabs())):
            if nb.tab(i, "text") == text:
                return i
    except Exception:
        pass
    return None

def _build_fallback_frame(parent: ttk.Notebook, message: str) -> ttk.Frame:
    frm = ttk.Frame(parent)
    lbl = ttk.Label(frm, text=message, foreground="#b33")
    lbl.place(relx=0.5, rely=0.5, anchor="center")
    return frm

def _mount(nb: ttk.Notebook) -> ttk.Frame:
    """Mountet Intake (oder Fallback) und gibt das Frame zurück."""
    try:
        # WICHTIG: paketierter Import
        from modules import module_code_intake as intake
        _log("Import OK: modules.module_code_intake")
        FrameCls = getattr(intake, "IntakeFrame", None)
        if FrameCls is None:
            raise AttributeError("IntakeFrame not found in module_code_intake")
        frm = FrameCls(nb)
        _log("IntakeFrame instance created.")
    except Exception as e:
        _log(f"ERROR while importing/instantiating IntakeFrame: {e}")
        _log(traceback.format_exc(limit=3).strip())
        frm = _build_fallback_frame(nb, "Intake – Fehler beim Laden (Details im Log).")

    # Tab einhängen (neu oder ersetzen)
    try:
        idx = _find_tab_index(nb, _TAB_NAME)
        if idx is None:
            nb.add(frm, text=_TAB_NAME)
            _log("Tab added.")
        else:
            old_tab = nb.tabs()[idx]
            try:
                # vorhandenes Tab-Frame zerstören
                old_widget = nb.nametowidget(old_tab)
                old_widget.destroy()
            except Exception:
                pass
            nb.insert(idx, frm)
            nb.tab(idx, text=_TAB_NAME)
            _log("Tab replaced.")
        nb.select(frm)
    except Exception as e:
        _log(f"ERROR while mounting tab: {e}")
    return frm

# Öffentliche API
def mount_intake_tab(nb: ttk.Notebook) -> None:
    _log("mount_intake_tab called.")
    _mount(nb)

def _mount_intake_tab_shim(nb: ttk.Notebook) -> None:
    _log("_mount_intake_tab_shim called.")
    _mount(nb)

def _remount_intake_tab_shim(nb: ttk.Notebook) -> None:
    _log("_remount_intake_tab_shim called.")
    _mount(nb)
'''

def backup(path: str):
    if os.path.exists(path):
        os.makedirs(ARCH, exist_ok=True)
        bak = os.path.join(ARCH, f"{os.path.basename(path)}.{ts().replace(':','').replace(' ','_')}.bak")
        shutil.copy2(path, bak)
        log(f"Backup: {bak}")

def main() -> int:
    os.makedirs(MODS, exist_ok=True)
    backup(TARGET)
    with open(TARGET, "w", encoding="utf-8") as f:
        f.write(PAYLOAD)
    log("module_shim_intake.py written (R1177j).")
    print("[R1177j] Intake Shim HardFix applied.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
