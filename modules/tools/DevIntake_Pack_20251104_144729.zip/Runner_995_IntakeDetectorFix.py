# file: tools/Runner_995_IntakeDetectorFix.py
# Zweck: Intake-Detektion für Name/Endung verbessern + LED-Logik anpassen
from __future__ import annotations
import re, sys
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
MOD  = ROOT / "modules" / "module_code_intake.py"

def patch_extract(src: str) -> str:
    pat = r"def\s+_extract\(\s*code\s*:\s*str\s*\)\s*->\s*tuple\[.*?\]\s*:\s*(?:\n\s+.*?)+?(?=\n\s*def\s+|$)"
    if not re.search(pat, src, flags=re.S):
        # Fallback: alte Signatur
        pat = r"def\s+_extract\(\s*code\s*\)\s*:\s*(?:\n\s+.*?)+?(?=\n\s*def\s+|$)"
    body = r'''
def _extract(code: str) -> tuple[str|None, str|None]:
    """
    Liefert (name_ohne_ext, ext_mit_punkt) oder (None, None).
    1) Explizite Marker (# file:, // file:, ; file:, ###, fenced, YAML front matter)
    2) Heuristik:
       - Batch/Command: @echo off, REM/::, setlocal, if exist, goto, call, .bat/.cmd Zeilen
       - Python: import/def/class/from, shebang python
    """
    def _split_name(n: str) -> tuple[str, str]:
        n = Path(n).name
        stem = n.rsplit('.', 1)[0] if '.' in n else n
        ext  = '.' + n.rsplit('.', 1)[1].lower() if '.' in n else ''
        return stem, ext

    head = code[:4000]

    # 1) Explizite Marker (mit Named Group 'p' = Pfad/Datei)
    markers = [
        r'(?im)^\s*#\s*file\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        r'(?im)^\s*//\s*file\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        r'(?im)^\s*;\s*file\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        r'(?im)^\s*[-#/* ]*filename\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
        r'(?ism)^---\s*\n.*?\nfile\s*:\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt)).*?\n---\s*',
        r'(?ism)^[`]{3,}.*?\n(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt)).{0,200}?\n[`]{3,}',
        r'(?im)^\s*###\s*(?P<p>[\w\-/\\\. ]+\.(?:py|bat|cmd|vbs|ps1|md|json|txt))\s*$',
    ]
    for rx in markers:
        m = re.search(rx, head)
        if m and m.group('p'):
            stem, ext = _split_name(m.group('p'))
            return (stem, ext or None)

    # 2) Heuristik für Endung
    bat_like = any([
        re.search(r'(?im)^\s*@?echo\s+off\b', head),
        re.search(r'(?im)^\s*(?:rem\b|::)', head),
        re.search(r'(?im)\bsetlocal\b|\bendlocal\b|\bgoto\s+\w+|\bif\s+exist\b|\bcall\s+', head),
        re.search(r'(?im)\.(?:bat|cmd)\b', head),
    ])
    py_like = any([
        re.search(r'(?m)^#!.*\bpython[0-9.]*\b', head),
        re.search(r'(?m)^\s*(?:from\s+\w+|import\s+\w+|def\s+\w+\(|class\s+\w+\()', head),
    ])

    ext = None
    if bat_like and not py_like:
        ext = '.bat'
    elif py_like and not bat_like:
        ext = '.py'
    # unentschieden bleibt None (LED: gelb)

    # 3) Einen plausiblen Namen versuchen
    #    (Runner_####…), Module (module_*.py), sonst None
    name = None
    m = re.search(r'(?i)\bRunner_(\d{3,5})[_-]?([A-Za-z0-9]*)', head)
    if m:
        suffix = m.group(2) or 'Script'
        cand = f"Runner_{m.group(1)}{('_' + suffix) if suffix else ''}{ext or ''}"
        stem, _ext = _split_name(cand)
        return stem, (ext or _ext or None)
    m = re.search(r'(?i)\bmodule_([A-Za-z0-9_]+)\.?(py)?\b', head)
    if m:
        cand = f"module_{m.group(1)}{ext or '.py'}"
        stem, _ext = _split_name(cand)
        return stem, (ext or _ext or None)

    return (None, ext)
'''
    return re.sub(pat, body, src, flags=re.S)

def patch_ui_led_and_split(src: str) -> str:
    # LED-Setzung und Name/Endung-Splitting in IntakeWindow._detect()
    pat = r"def\s+_detect\(\s*self,\s*auto:\s*bool\s*=\s*False\s*\)\s*:\s*(?:\n\s+.*?)+?(?=\n\s*def\s+|$)"
    def_body = r'''
def _detect(self, auto: bool=False):
    code = self.txt.get("1.0", "end-1c")
    name, ext = _extract(code)
    # Split-Logik: Name ohne Endung ins Namensfeld
    if name:
        self.var_name.set(str(name))
    if ext:
        self.var_ext.set(ext)
    # LED-Logik
    ok_name = bool(self.var_name.get().strip())
    ok_ext  = bool(self.var_ext.get().strip())
    if ok_name and ok_ext:
        self._set_led(self.led_detect, "green", "Erkennung OK")
    elif ok_ext:
        self._set_led(self.led_detect, "yellow", "Nur Endung erkannt – Name prüfen")
    else:
        self._set_led(self.led_detect, "red", "Keine sichere Erkennung")
    # Zielordner vorschlagen
    nm = self.var_name.get().strip()
    ex = self.var_ext.get().strip().lower()
    if nm and ex:
        self.var_target.set(str(_map_target(self.workspace, nm + ex, ex)))
    if not auto:
        self.status.set(f"Erkannt: name={nm or '-'} ext={ex or '-'} → {self.var_target.get() or '-'}")
'''
    return re.sub(pat, def_body, src, flags=re.S)

def patch_set_led_helper(src: str) -> str:
    if "_set_led(" in src:
        return src
    inject_after = r"class\s+IntakeWindow\(.*?\):"
    helper = r'''
    def _set_led(self, lbl, color: str, text: str=""):
        try:
            colors = {"green":"#27ae60","yellow":"#e2b93d","red":"#e74c3c","grey":"#808080"}
            lbl.config(background=colors.get(color,"#808080"))
            if text: 
                try: lbl_t = getattr(self, "lbl_detect_text", None)
                except Exception: lbl_t = None
                if lbl_t: lbl_t.config(text=text)
        except Exception:
            pass
'''
    return re.sub(inject_after, lambda m: m.group(0)+helper, src, count=1, flags=re.S)

def main():
    if not MOD.exists():
        print("[R995] ERROR: module_code_intake.py nicht gefunden.")
        return 1
    src = MOD.read_text(encoding="utf-8", errors="ignore")
    bak = MOD.with_suffix(".py.r995.bak")
    bak.write_text(src, encoding="utf-8")
    src1 = patch_extract(src)
    src2 = patch_ui_led_and_split(src1)
    src3 = patch_set_led_helper(src2)
    MOD.write_text(src3, encoding="utf-8")
    try:
        compile(src3, str(MOD), "exec")
        print("[R995] Patch OK – Detektoren & LED-Logik aktualisiert.")
        return 0
    except Exception as ex:
        bak.replace(MOD)  # Rollback
        print(f"[R995] FEHLER: Syntax nach Patch. Rollback. {ex}")
        return 2

if __name__ == "__main__":
    raise SystemExit(main())
