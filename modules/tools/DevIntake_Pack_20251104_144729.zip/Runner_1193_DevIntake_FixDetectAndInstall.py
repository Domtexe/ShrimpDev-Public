# -*- coding: utf-8 -*-
import sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
LOG  = ROOT / "debug_output.txt"

PAYLOAD = r'''# -*- coding: utf-8 -*-
"""
ShrimpDev Dev-Intake – R1193
- Saubere grid()-UI (kein pack/grid-Mix)
- Robuste Erkennung fuer .py/.bat + Runner_####_Name
- Syntaxcheck fuer .py (markiert Fehlerzeile)
- LED-Status (dirty, syntax, name, ext, ok)
- Sortierbare Liste, Token-Filter
"""
from __future__ import annotations
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import time, re, configparser, traceback

ROOT = Path(__file__).resolve().parents[1]
INI  = "dev_intake.ini"

def _log(tag, msg):
    try:
        with (ROOT/"debug_output.txt").open("a", encoding="utf-8", newline="\n") as f:
            ts=time.strftime("%Y-%m-%d %H:%M:%S")
            f.write(f"[DevIntake] {ts} [{tag}] {msg}\n")
    except Exception:
        pass

def _detect_ext(text: str) -> str:
    t = (text or "").lstrip()
    tl = t.lower()
    if tl.startswith("@echo off") or any(m in tl for m in ("\nrem ","\r\nrem ","\n::","\r\n::","\n:","\r\n:"," goto "," set ")):
        return ".bat"
    if any(k in t for k in ("import ","from ","def ","class ","print(","__name__")):
        return ".py"
    return ".txt"

class LED(ttk.Frame):
    def __init__(self, master, tip=""):
        super().__init__(master)
        self._tip = tip
        self._tw = None
        bg = self._bg(master)
        self.c = tk.Canvas(self, width=14, height=14, highlightthickness=0, bg=bg)
        self.c.grid()
        self.o = self.c.create_oval(2,2,12,12, fill="#9e9e9e", outline="#555")
        self.c.bind("<Enter>", self._show)
        self.c.bind("<Leave>", self._hide)

    @staticmethod
    def _bg(w):
        try: return w.cget("background")
        except: return "#f0f0f0"

    def set(self, ok, tip=None):
        color = "#4caf50" if ok is True else ("#e53935" if ok is False else str(ok))
        self.c.itemconfig(self.o, fill=color)
        if tip is not None: self._tip = tip

    def _show(self, *_):
        if not self._tip or self._tw: return
        x = self.c.winfo_rootx()+16
        y = self.c.winfo_rooty()+self.c.winfo_height()+6
        self._tw = tw = tk.Toplevel(self.c)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        tk.Label(tw, text=self._tip, bg="#ffffe0", relief="solid", bd=1).pack(ipadx=3, ipady=1)

    def _hide(self, *_):
        if self._tw: self._tw.destroy(); self._tw = None

class DevIntake(ttk.Frame):
    def __init__(self, nb: ttk.Notebook):
        super().__init__(nb)
        self.current: Path|None = None
        self.dirty = False
        self.syntax_ok = True
        self.sort = ("ext", True, "name", True)

        cfg = self._load_cfg()
        self.var_ws   = tk.StringVar(value=cfg.get("workspace", str(ROOT)))
        self.var_tgt  = tk.StringVar(value=cfg.get("target",    str(ROOT/"tools")))
        self.var_ext  = tk.StringVar(value=cfg.get("ext", ".py"))
        self.var_name = tk.StringVar(value=cfg.get("name", f"snippet_{time.strftime('%Y%m%d_%H%M%S')}"))
        self.var_flt  = tk.StringVar(value=cfg.get("filter",""))
        self.var_stat = tk.StringVar(value="Bereit.")

        self._build_ui()
        self._refresh()

    # ---------- cfg ----------
    def _load_cfg(self):
        p = Path.cwd()/INI
        if not p.exists(): return {}
        try:
            c=configparser.ConfigParser(); c.read(p, encoding="utf-8")
            return dict(c.items("dev")) if c.has_section("dev") else {}
        except Exception: return {}

    def _save_cfg(self):
        try:
            c=configparser.ConfigParser()
            c["dev"] = {
                "workspace": self.var_ws.get(),
                "target":    self.var_tgt.get(),
                "ext":       self.var_ext.get(),
                "name":      self.var_name.get(),
                "filter":    self.var_flt.get(),
                "sort":      ",".join(map(str,self.sort)),
            }
            with (Path.cwd()/INI).open("w",encoding="utf-8",newline="\n") as f:
                c.write(f)
        except Exception as e:
            _log("INI_WRITE_FAIL", str(e))

    # ---------- UI ----------
    def _build_ui(self):
        PADX,PADY=8,6

        top=ttk.Frame(self); top.grid(row=0,column=0,sticky="we",padx=PADX,pady=(PADY,4))
        ttk.Label(top,text="Workspace:").grid(row=0,column=0,sticky="w")
        ttk.Entry(top,textvariable=self.var_ws,width=42).grid(row=0,column=1,sticky="we",padx=(4,4))
        ttk.Button(top,text="…",width=3,command=self._pick_ws).grid(row=0,column=2,padx=(0,12))

        ttk.Label(top,text="Name:").grid(row=0,column=3,sticky="e")
        ttk.Entry(top,textvariable=self.var_name,width=28).grid(row=0,column=4,sticky="we",padx=(4,12))

        ttk.Label(top,text="Endung:").grid(row=0,column=5,sticky="e")
        ttk.Combobox(top,textvariable=self.var_ext,values=[".py",".bat",".txt"],width=6,state="readonly").grid(row=0,column=6,sticky="w",padx=(4,12))

        ttk.Label(top,text="Zielordner:").grid(row=0,column=7,sticky="e")
        ttk.Entry(top,textvariable=self.var_tgt,width=36).grid(row=0,column=8,sticky="we",padx=(4,4))
        ttk.Button(top,text="…",width=3,command=self._pick_tgt).grid(row=0,column=9)
        for c in (1,4,8): top.columnconfigure(c,weight=1,minsize=120)

        bar=ttk.Frame(self); bar.grid(row=1,column=0,sticky="we",padx=PADX,pady=(0,4))
        def grp(col,text):
            lf=ttk.Labelframe(bar,text=text); lf.grid(row=0,column=col,sticky="we",padx=(0 if col==0 else 8,8))
            return lf

        g1=grp(0,"Datei")
        ttk.Button(g1,text="Neu",width=12,command=self._new).grid(row=0,column=0,padx=2,pady=6)
        ttk.Button(g1,text="Einfügen",width=12,command=self._insert).grid(row=0,column=1,padx=2,pady=6)
        ttk.Button(g1,text="Speichern",width=12,command=self._save).grid(row=0,column=2,padx=2,pady=6)
        ttk.Button(g1,text="Speichern als…",width=14,command=self._save_as).grid(row=0,column=3,padx=2,pady=6)

        g2=grp(1,"Analyse")
        ttk.Button(g2,text="Erkennen (Strg+I)",width=18,command=self._detect).grid(row=0,column=0,padx=2,pady=6)
        ttk.Button(g2,text="Guard",width=10,command=self._guard).grid(row=0,column=1,padx=2,pady=6)
        ttk.Button(g2,text="Repair",width=10,command=self._repair).grid(row=0,column=2,padx=2,pady=6)

        g3=grp(2,"Ausführen")
        ttk.Button(g3,text="Run (F5)",width=12,command=self._run).grid(row=0,column=0,padx=2,pady=6)
        ttk.Button(g3,text="Ordner öffnen",width=16,command=self._open_target).grid(row=0,column=1,padx=2,pady=6)

        g4=grp(3,"Verwaltung")
        ttk.Button(g4,text="Aktualisieren",width=14,command=self._refresh).grid(row=0,column=0,padx=2,pady=6)
        ttk.Button(g4,text="Pack speichern",width=16,command=self._pack).grid(row=0,column=1,padx=2,pady=6)
        ttk.Button(g4,text="Löschen",width=10,command=self._delete).grid(row=0,column=2,padx=2,pady=6)

        leds=ttk.Frame(bar); leds.grid(row=0,column=4,sticky="e",padx=(8,0))
        self.led_dirty=LED(leds,"Geaendert"); self.led_dirty.grid(row=0,column=0,padx=2)
        self.led_syn  =LED(leds,"Syntax");   self.led_syn.grid(row=0,column=1,padx=2)
        self.led_name =LED(leds,"Name");     self.led_name.grid(row=0,column=2,padx=2)
        self.led_ext  =LED(leds,"Endung");   self.led_ext.grid(row=0,column=3,padx=2)
        self.led_ok   =LED(leds,"OK");       self.led_ok.grid(row=0,column=4,padx=2)

        fl=ttk.Frame(self); fl.grid(row=2,column=0,sticky="we",padx=PADX,pady=(0,4))
        ttk.Label(fl,text="Filter (z. B. name:runner ext:py):").grid(row=0,column=0,sticky="w")
        ttk.Entry(fl,textvariable=self.var_flt).grid(row=0,column=1,sticky="we",padx=(4,10))
        ttk.Button(fl,text="Anwenden",command=self._refresh).grid(row=0,column=2)
        fl.columnconfigure(1,weight=1)

        split=ttk.Panedwindow(self,orient="horizontal"); split.grid(row=3,column=0,sticky="nsew",padx=PADX,pady=(0,PADY))
        left=ttk.Frame(split); right=ttk.Frame(split)
        split.add(left,weight=60); split.add(right,weight=40)

        self.editor=tk.Text(left,wrap="none",undo=True)
        self.editor.grid(row=0,column=0,sticky="nsew")
        ysb=ttk.Scrollbar(left,orient="vertical",command=self.editor.yview); ysb.grid(row=0,column=1,sticky="ns")
        xsb=ttk.Scrollbar(left,orient="horizontal",command=self.editor.xview); xsb.grid(row=1,column=0,sticky="we")
        self.editor.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
        left.rowconfigure(0,weight=1); left.columnconfigure(0,weight=1)
        self.editor.bind("<<Modified>>",self._on_mod)

        cols=("name","ext","subfolder","date","time")
        self.tree=ttk.Treeview(right,columns=cols,show="headings",selectmode="browse")
        for c,w in zip(cols,(280,70,180,110,90)):
            self.tree.heading(c,text=c,command=lambda col=c:self._sort_toggle(col))
            self.tree.column(c,width=w,anchor="w")
        self.tree.grid(row=0,column=0,sticky="nsew")
        scry=ttk.Scrollbar(right,orient="vertical",command=self.tree.yview); scry.grid(row=0,column=1,sticky="ns")
        self.tree.configure(yscrollcommand=scry.set)
        right.rowconfigure(0,weight=1); right.columnconfigure(0,weight=1)
        self.tree.bind("<<TreeviewSelect>>",self._on_select)
        self.tree.bind("<Double-1>",lambda e:self._on_select())

        ttk.Label(self,textvariable=self.var_stat,anchor="w").grid(row=4,column=0,sticky="we",padx=PADX)
        self.grid_rowconfigure(3,weight=1); self.grid_columnconfigure(0,weight=1)

        self.bind_all("<Control-s>",lambda e:self._save())
        self.bind_all("<Control-i>",lambda e:self._detect())
        self.bind_all("<F5>",       lambda e:self._run())
        self._update_leds()

    # ---------- helpers ----------
    def _pick_ws(self):
        d=filedialog.askdirectory(title="Workspace wählen",initialdir=self.var_ws.get())
        if d: self.var_ws.set(d); self._save_cfg()

    def _pick_tgt(self):
        d=filedialog.askdirectory(title="Zielordner wählen",initialdir=self.var_tgt.get())
        if d: self.var_tgt.set(d); self._save_cfg(); self._refresh()

    def _path(self)->Path:
        tgt=Path(self.var_tgt.get() or (ROOT/"tools"))
        tgt.mkdir(parents=True,exist_ok=True)
        return tgt / f"{(self.var_name.get() or 'snippet')}{(self.var_ext.get() or '.py')}"

    def _on_mod(self,_=None):
        if self.editor.edit_modified():
            self.dirty=True
            self.editor.edit_modified(False)
            self._update_leds()

    def _hilite_err(self,line:int|None):
        try: self.editor.tag_delete("errline")
        except: pass
        if not line: return
        self.editor.tag_configure("errline",background="#ffd6d6")
        self.editor.tag_add("errline",f"{line}.0",f"{line}.0 lineend")
        self.editor.see(f"{line}.0")

    # ---------- actions ----------
    def _new(self):
        self.editor.delete("1.0","end")
        self.var_name.set(f"snippet_{time.strftime('%Y%m%d_%H%M%S')}")
        self.dirty=False; self.syntax_ok=True; self._update_leds()
        self.var_stat.set("Editor geleert.")

    def _detect(self):
        src=self.editor.get("1.0","end-1c")
        if not src.strip():
            self.var_stat.set("Nichts zu erkennen."); return
        ext=_detect_ext(src)
        name=None
        for line in src.splitlines():
            s=line.strip()
            if not s or s.startswith("#") or s.lower().startswith(("rem","::")): continue
            m=re.search(r"(Runner_[0-9]{3,5}_[A-Za-z0-9_]+)", s)
            if m: name=m.group(1); break
        if not name: name=f"snippet_{time.strftime('%Y%m%d_%H%M%S')}"
        self.syntax_ok=True
        if ext==".py":
            try:
                compile(src,"<intake>","exec")
            except Exception as e:
                self.syntax_ok=False
                self._hilite_err(getattr(e,"lineno",None))
        self.var_ext.set(ext)
        self.var_name.set(name)
        self._update_leds()
        self.var_stat.set(f"Erkannt: {name}{ext}")

    def _insert(self):
        p=self._path()
        if p.exists() and not messagebox.askyesno("Überschreiben?", f"{p.name} existiert. Überschreiben?"): return
        try:
            p.write_text(self.editor.get("1.0","end-1c"),encoding="utf-8",newline="\n")
            self.current=p; self.dirty=False; self._refresh(select=p); self._update_leds()
            self.var_stat.set(f"Eingefuegt: {p.name}")
        except Exception as e:
            messagebox.showerror("Einfuegen", str(e)); _log("INSERT_FAIL", str(e))

    def _save(self):
        if self.current is None: self._insert(); return
        try:
            self.current.write_text(self.editor.get("1.0","end-1c"),encoding="utf-8",newline="\n")
            self.dirty=False; self._refresh(select=self.current); self._update_leds()
            self.var_stat.set(f"Gespeichert: {self.current.name}")
        except Exception as e:
            messagebox.showerror("Speichern", str(e)); _log("SAVE_FAIL", str(e))

    def _save_as(self):
        p=self._path()
        try:
            p.write_text(self.editor.get("1.0","end-1c"),encoding="utf-8",newline="\n")
            self.current=p; self.dirty=False; self._refresh(select=p); self._update_leds()
            self.var_stat.set(f"Gespeichert als: {p.name}")
        except Exception as e:
            messagebox.showerror("Speichern als", str(e)); _log("SAVEAS_FAIL", str(e))

    def _parse_filter(self,s:str):
        d={'name':None,'ext':None,'sub':None}; raw=[]
        for tok in (s or '').split():
            if ":" in tok:
                k,v=tok.split(":",1)
                if k in d: d[k]=v.lower(); continue
            raw.append(tok.lower())
        return d,raw

    def _refresh(self, select:Path|None=None):
        self.tree.delete(*self.tree.get_children())
        root=Path(self.var_tgt.get() or (ROOT/"tools")); root.mkdir(parents=True,exist_ok=True)
        fdict,raw=self._parse_filter(self.var_flt.get())
        items=[]
        for p in root.rglob("*"):
            if not p.is_file(): continue
            name_l=p.name.lower(); sub_l=(str(p.parent.relative_to(root)).lower() if p.parent!=root else "")
            if fdict['name'] and fdict['name'] not in name_l: continue
            if fdict['ext'] and fdict['ext']!=(p.suffix.lower().lstrip('.') or ''): continue
            if fdict['sub'] and fdict['sub'] not in sub_l: continue
            if raw and not all(any(t in x for x in (name_l, sub_l)) for t in raw): continue
            sub=str(p.parent.relative_to(root)) if p.parent!=root else ""
            dt=time.localtime(p.stat().st_mtime)
            date=time.strftime("%Y-%m-%d",dt); tm=time.strftime("%H:%M:%S",dt)
            items.append((p, p.stem, p.suffix, sub, date, tm))
        def keyfun(t):
            mp={"name":1,"ext":2,"subfolder":3,"date":4,"time":5}
            k1,a1,k2,a2=self.sort
            def norm(x,asc): return x if asc else ("\xff"+x)
            return (norm(t[mp[k1]] or "",a1), norm(t[mp[k2]] or "",a2))
        items.sort(key=keyfun)
        for (p,stem,ext,sub,date,tm) in items:
            self.tree.insert("", "end", iid=str(p), values=(stem,ext,sub,date,tm))
        if select and self.tree.exists(str(select)): self.tree.selection_set(str(select))
        self.var_stat.set(f"{len(items)} Datei(en) in {root}")
        self._save_cfg()

    def _sort_toggle(self,col:str):
        c1,a1,c2,a2 = self.sort
        if col==c1: self.sort=(c1,not a1,c2,a2)
        else: self.sort=(col,True,"name",True)
        self._refresh(select=self.current)

    def _on_select(self,_=None):
        sel=self.tree.selection()
        if not sel: return
        p=Path(sel[0])
        try:
            txt=p.read_text(encoding="utf-8",errors="replace")
            self.editor.delete("1.0","end"); self.editor.insert("1.0",txt)
            self.current=p; self.var_name.set(p.stem); self.var_ext.set(p.suffix or ".txt"); self.var_tgt.set(str(p.parent))
            self.dirty=False; self.syntax_ok=True; self._update_leds()
            self.var_stat.set(f"Geladen: {p}")
        except Exception as e:
            messagebox.showerror("Laden", str(e)); _log("LOAD_FAIL", str(e))

    def _open_target(self):
        try:
            import subprocess
            subprocess.Popen(["explorer", str(Path(self.var_tgt.get()))])
        except Exception as e:
            messagebox.showerror("Explorer", str(e))

    def _pack(self):
        try:
            import zipfile
            tgt=Path(self.var_tgt.get() or (ROOT/"tools"))
            z= tgt / f"DevIntake_Pack_{time.strftime('%Y%m%d_%H%M%S')}.zip"
            with zipfile.ZipFile(z,"w",zipfile.ZIP_STORED) as zp:
                for p in tgt.rglob("*"):
                    if p.is_file(): zp.write(p, p.relative_to(tgt))
            messagebox.showinfo("Pack", f"Pack gespeichert:\n{z}")
        except Exception as e:
            messagebox.showerror("Pack", str(e)); _log("PACK_FAIL", str(e))

    def _delete(self):
        if not self.current or not self.current.exists():
            messagebox.showinfo("Löschen","Keine Datei ausgewaehlt."); return
        if not messagebox.askyesno("Löschen", f"{self.current.name} wirklich loeschen?"): return
        try:
            self.current.unlink()
            self.current=None; self.editor.delete("1.0","end")
            self._refresh(); self.dirty=False; self._update_leds()
            self.var_stat.set("Datei geloescht.")
        except Exception as e:
            messagebox.showerror("Löschen", str(e)); _log("DELETE_FAIL", str(e))

    def _guard(self):
        p=self.current
        if not p or p.suffix!=".py":
            messagebox.showinfo("Guard","Guard prueft nur .py"); return
        src=self.editor.get("1.0","end-1c")
        try:
            compile(src, p.name, "exec")
            self.syntax_ok=True; self._hilite_err(None)
            messagebox.showinfo("Guard","Syntax OK.")
        except SyntaxError as e:
            self.syntax_ok=False; self._hilite_err(getattr(e,"lineno",None))
            messagebox.showerror("Guard", f"Syntaxfehler in Zeile {getattr(e,'lineno','?')}\n{e.msg}")
        except Exception as e:
            self.syntax_ok=False; messagebox.showerror("Guard", str(e))
        self._update_leds()

    def _repair(self):
        try:
            txt=self.editor.get("1.0","end-1c")
            txt2=txt.replace("\r\r\n","\r\n")
            if txt2!=txt:
                self.editor.delete("1.0","end"); self.editor.insert("1.0",txt2)
            messagebox.showinfo("Repair","Normalisierung angewendet.")
        except Exception as e:
            messagebox.showerror("Repair", str(e))

    def _run(self):
        p=self.current
        if not p or not p.exists():
            messagebox.showinfo("Run","Keine Datei ausgewaehlt."); return
        try:
            import subprocess
            if p.suffix==".py": subprocess.Popen(["py","-3","-u",str(p)])
            elif p.suffix==".bat": subprocess.Popen([str(p)])
            else: messagebox.showinfo("Run","Nur .py/.bat werden ausgefuehrt.")
        except Exception as e:
            messagebox.showerror("Run", str(e))

    def _update_leds(self):
        name_ok=bool((self.var_name.get() or "").strip())
        ext_ok =bool((self.var_ext.get()  or "").strip())
        all_ok =bool(name_ok and ext_ok and self.syntax_ok and (not self.dirty))
        self.led_dirty.set(self.dirty,   "Geaendert" if self.dirty else "Unveraendert")
        self.led_syn.set(self.syntax_ok, "Syntax OK" if self.syntax_ok else "Syntaxfehler")
        self.led_name.set(name_ok, "Name OK" if name_ok else "Name fehlt")
        self.led_ext.set(ext_ok,  "Endung OK" if ext_ok else "Endung fehlt")
        self.led_ok.set(all_ok,   "Alles OK" if all_ok else "Nicht OK")

def create_intake_tab(nb: ttk.Notebook) -> None:
    try:
        frame=DevIntake(nb)
        nb.add(frame, text="Intake")
    except Exception:
        f=ttk.Frame(nb)
        ttk.Label(f,text="Intake – Fehler beim Laden. Log pruefen.",foreground="red").grid(padx=12,pady=12,sticky="w")
        nb.add(f, text="Intake")
        traceback.print_exc()
'''

def main():
    MOD.parent.mkdir(parents=True, exist_ok=True)
    MOD.write_text(PAYLOAD, encoding="utf-8", newline="\n")
    print("[R1193] module_code_intake.py written.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
