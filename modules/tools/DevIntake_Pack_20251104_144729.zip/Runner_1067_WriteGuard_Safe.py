# -*- coding: utf-8 -*-
"""
Runner_1067_WriteGuard_Safe
Schreibt einen vollständigen Guard nach tools/Runner_1063_Intake_SanityGuard.py
(enthält alle Helper + --file Option). Robust gegen Quote/Indent-Probleme.
Version: v9.9.56
"""
from __future__ import annotations
import os, time, shutil

ROOT   = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TOOLS  = os.path.join(ROOT, "tools")
TARGET = os.path.join(TOOLS, "Runner_1063_Intake_SanityGuard.py")
ARCH   = os.path.join(ROOT, "_Archiv")

GUARD_SRC = """
# -*- coding: utf-8 -*-
'''
Runner_1063_Intake_SanityGuard (safe build by 1067)
- Normalisiert (CRLF, Tabs->Spaces, Trim)
- Verschiebt __future__-Imports an den Dateikopf (einfacher Insertion-Point)
- Reindented IntakeFrame vorsichtig
- Härtet Delete-Dialog
- ast.parse() Endkontrolle
CLI: --file <path> (optional)
Version: v9.9.56
'''
from __future__ import annotations
import ast, os, re, shutil, time, argparse, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
LOG  = os.path.join(ROOT, 'debug_output.txt')

def log(msg: str) -> None:
    ts = time.strftime('%Y-%m-%d %H:%M:%S')
    print(msg, flush=True)
    try:
        with open(LOG, 'a', encoding='utf-8') as f:
            f.write(f'[R1063] {ts} {msg}\\n')
    except Exception:
        pass

def dump_around(text: str, line: int, radius: int = 20) -> None:
    lines = text.splitlines()
    a, b = max(1, line - radius), min(len(lines), line + radius)
    log(f'--- DUMP {a}..{b} (center={line}) ---')
    for i in range(a, b + 1):
        s = lines[i-1]
        vis = s.replace('\\t', '→').replace(' ', '·')
        log(f'{i:04d}: {vis}')
    log('--- END DUMP ---')

# -------- Normalisierung --------
def ensure_crlf_tabs_spaces(src: str) -> str:
    src = src.replace('\\r\\n', '\\n').replace('\\r', '\\n')
    src = '\\n'.join(ln.rstrip(' \\t') for ln in src.split('\\n'))
    src = src.replace('\\t', '    ')
    if not src.endswith('\\n'):
        src += '\\n'
    return src

FUT_RX = re.compile(r'^[ \\t]*from[ \\t]+__future__[ \\t]+import[ \\t]+.+$', re.MULTILINE)

def insertion_point_simple(src: str) -> int:
    '''
    Einfache Einfügestelle:
    - überspringt BOM/Shebang/Coding-Kommentar und führende Leer-/Kommentarzeilen.
    - KEINE Docstring-Erkennung (absichtlich simpel & sicher).
    '''
    i = 0
    if src.startswith('\\ufeff'): i = 1
    if src.startswith('#!', i):
        j = src.find('\\n', i); i = len(src) if j < 0 else j+1
    m = re.match(r'[ \\t]*#.*coding[:=][ \\t]*[-_.a-zA-Z0-9]+.*\\n', src[i:])
    if m: i += m.end()
    # leere/kommentierte Zeilen am Anfang überspringen
    while True:
        m = re.match(r'(?:[ \\t]*#.*\\n|[ \\t]*\\n)', src[i:])
        if not m: break
        i += m.end()
    return i

def move_future_imports(src: str) -> str:
    futs = FUT_RX.findall(src)
    if not futs: return src
    src2 = FUT_RX.sub('', src)
    seen, uniq = set(), []
    for l in futs:
        l = l.strip()
        if l not in seen:
            seen.add(l); uniq.append(l)
    ins = insertion_point_simple(src2)
    head, tail = src2[:ins], src2[ins:]
    if head and not head.endswith('\\n'): head += '\\n'
    block = '\\n'.join(uniq) + '\\n\\n'
    return head + block + tail

# -------- IntakeFrame Reindent --------
def reindent_intakeframe(src: str) -> str:
    m = re.search(r'(class\\s+IntakeFrame\\(ttk\\.Frame\\):)([\\s\\S]+)', src)
    if not m:
        log('IntakeFrame nicht gefunden – Reindent übersprungen.')
        return src
    head, body = src[:m.start(2)], m.group(2)
    lines = body.splitlines(True)

    def ind(s: str) -> int: return len(s) - len(s.lstrip(' '))

    out, prev = [], ''
    for ln in lines:
        raw = ln.rstrip('\\r\\n')
        if not raw.strip():
            out.append(ln); prev = raw; continue
        cur = ind(raw)
        text = raw.lstrip(' ')
        if prev.rstrip().endswith(':'):
            base = ind(prev)
            cur = max(cur, base + 4)
        if text.startswith(('except', 'finally')) and 'try' not in prev:
            out.append(' ' * cur + 'try:\\n')
            out.append(' ' * (cur + 4) + 'pass\\n')
        out.append(' ' * cur + text + '\\n')
        prev = ' ' * cur + text

    # 'try:' ohne Body absichern
    def ind2(s: str) -> int: return len(s) - len(s.lstrip(' '))
    out2 = []
    for i, ln in enumerate(out):
        out2.append(ln)
        if ln.rstrip().endswith('try:'):
            cur = ind2(ln)
            j = i + 1
            while j < len(out) and not out[j].strip():
                j += 1
            need = (j >= len(out)) or (ind2(out[j]) <= cur)
            if need:
                out2.append(' ' * (cur + 4) + 'pass\\n')
    return head + ''.join(out2)

# -------- Delete-Dialog härten --------
def harden_delete_dialog(src: str) -> str:
    src = re.sub(
        r'messagebox\\.askyesno\\(\\s*\"Löschen bestätigen\"\\s*,\\s*f?\"[^\"]*\"\\s*\\+\\s*path\\s*\\)',
        'messagebox.askyesno(\"Löschen bestätigen\", \"Datei endgültig löschen?\\\\n\\\\n\" + str(path))',
        src
    )
    src = src.replace(
        'f\"Datei endgültig löschen?\\\\n\\\\n{path}\"',
        '\"Datei endgültig löschen?\\\\n\\\\n\" + str(path)'
    )
    return src

# -------- main --------
def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--file', dest='target', default=None, help='Zieldatei (optional)')
    args = parser.parse_args()

    default_mod = os.path.join(ROOT, 'modules', 'module_code_intake.py')
    target = os.path.abspath(args.target or default_mod)

    if not os.path.exists(target):
        print(f'[R1063] Datei nicht gefunden: {target}')
        return 3

    def rd(p: str) -> str:
        with open(p, 'r', encoding='utf-8') as f: return f.read()
    def wr(p: str, data: str) -> None:
        arch = os.path.join(ROOT, '_Archiv'); os.makedirs(arch, exist_ok=True)
        b = os.path.join(arch, f\"{os.path.basename(p)}.{int(time.time())}.bak\")
        shutil.copy2(p, b)
        with open(p, 'w', encoding='utf-8', newline='\\r\\n') as f: f.write(data)
        print(f'[R1063] Backup: {p} -> {b}')

    src0 = rd(target)
    src1 = ensure_crlf_tabs_spaces(src0)

    if os.path.basename(target) == 'module_code_intake.py':
        src1 = move_future_imports(src1)
        src1 = reindent_intakeframe(src1)
        src1 = harden_delete_dialog(src1)

    try:
        ast.parse(src1)
    except SyntaxError as e:
        print(f'[R1063] SyntaxError: {e.msg} (line {e.lineno}, col {e.offset})')
        dump_around(src1, e.lineno or 1, 20)
        fail = os.path.join(ROOT, '_Archiv',
                            f\"{os.path.basename(target)}.syntaxfail.{int(time.time())}.py\")
        with open(fail, 'w', encoding='utf-8', newline='\\r\\n') as f: f.write(src1)
        return 2

    if src1 != src0:
        wr(target, src1)
        print('[R1063] Sanity-Guard: Änderungen geschrieben.')
    else:
        print('[R1063] Sanity-Guard: Keine Änderungen nötig.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
"""

def main() -> int:
    os.makedirs(ARCH, exist_ok=True)
    if os.path.exists(TARGET):
        bak = os.path.join(ARCH, f"{os.path.basename(TARGET)}.{int(time.time())}.bak")
        shutil.copy2(TARGET, bak)
        print(f"Backup: {TARGET} -> {bak}")
    with open(TARGET, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(GUARD_SRC)
    print("Guard aktualisiert: Runner_1063_Intake_SanityGuard.py (v9.9.56)")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
