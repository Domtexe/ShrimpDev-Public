from __future__ import annotations
from pathlib import Path
import time

ROOT = Path(r"D:\ShrimpDev")
TOOLS = ROOT / "tools"
MODS  = ROOT / "modules"
SNIP  = MODS / "snippets"
LOGF  = ROOT / "debug_output.txt"

def log(msg: str):
    print(f"[R991] {msg}")
    try: LOGF.open("a", encoding="utf-8", errors="ignore").write(f"[R991] {msg}\n")
    except Exception: pass

def write_versioned(p: Path, content: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        bak = p.with_suffix(p.suffix + "." + time.strftime("%Y%m%d_%H%M%S") + ".bak")
        p.replace(bak)
        log(f"Backup: {bak.name}")
    p.write_text(content, encoding="utf-8")
    log(f"Wrote {p.relative_to(ROOT)}")

def common_tabs_py() -> str:
    return r'''from __future__ import annotations
import tkinter as tk
from tkinter import ttk

def ensure_tab(app: tk.Tk, key: str, title: str, builder):
    """
    Stellt sicher, dass es EINEN Tab (Notebook) mit Schlüssel `key` gibt.
    Falls kein Notebook existiert, wird ein Toplevel als Fallback genutzt.
    """
    if not hasattr(app, "nb") or app.nb is None:
        # Fallback – sollte bei dir nicht passieren, Notebook ist vorhanden
        win = tk.Toplevel(app); win.title(title)
        frame = builder(win)
        frame.pack(fill="both", expand=True)
        return True

    if not hasattr(app, "_tab_registry"): app._tab_registry = {}
    if key in app._tab_registry:
        app.nb.select(app._tab_registry[key]["index"])
        return True

    container = ttk.Frame(app.nb)
    frame = builder(container)
    frame.pack(fill="both", expand=True)
    app.nb.add(container, text=title)
    app._tab_registry[key] = {"frame": container, "index": app.nb.index("end") - 1}
    app.nb.select(app._tab_registry[key]["index"])
    return True
'''

def ui_helpers_py() -> str:
    return r'''from __future__ import annotations
import tkinter as tk
from tkinter import ttk

class AutoScrollbar(ttk.Scrollbar):
    """zeigt sich nur, wenn notwendig"""
    def set(self, lo, hi):
        if float(lo) <= 0.0 and float(hi) >= 1.0:
            self.pack_forget()
        else:
            if not str(self):  # dummy guard
                pass
        super().set(lo, hi)

class Led(ttk.Frame):
    """kleine Status-LED (ok/warn/err/idle)"""
    COLORS = {
        "ok":   "#22c55e",
        "warn": "#f59e0b",
        "err":  "#ef4444",
        "idle": "#9ca3af",
    }
    def __init__(self, parent, size=12, state="idle", text=""):
        super().__init__(parent)
        self._size = size
        self._canvas = tk.Canvas(self, width=size, height=size, highlightthickness=0, bd=0)
        self._canvas.pack(side="left", padx=(0,6))
        self._lbl = ttk.Label(self, text=text)
        self._lbl.pack(side="left")
        self.set(state, text)
    def set(self, state: str, text: str|None=None):
        state = state if state in self.COLORS else "idle"
        self._canvas.delete("all")
        s = self._size
        self._canvas.create_oval(1,1,s-1,s-1, fill=self.COLORS[state], outline="")
        if text is not None:
            self._lbl.configure(text=text)
'''

def module_code_intake_py() -> str:
    return r'''from __future__ import annotations
import re, json, tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from typing import Tuple
from modules.common_tabs import ensure_tab
from modules.snippets.ui_helpers import AutoScrollbar, Led

# --- Config robust ------------------------------------------------------------
try:
    from modules.config_mgr import load_config, save_config
except Exception:
    def load_config() -> dict:
        return {"workspace_root": r"D:\ShrimpHub", "intake_silent_success": True}
    def save_config(_): pass

ROOT = Path(r"D:\ShrimpDev")
REPORT = ROOT / "_Reports" / "Intake"
REPORT.mkdir(parents=True, exist_ok=True)
HIST = REPORT / "saved.jsonl"

# --- Erkennung: Name/Endung ---------------------------------------------------
_PATTERNS = [
    # explizit
    r"(?im)^\s*(?:#|//|;|REM)\s*(?:file|filename|path|filepath)\s*:\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*$",
    r"(?im)^\s*@file\s*:\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*$",
    # YAML front matter
    r"(?is)^---\s*.*?(?:^|\n)\s*(?:file|filename|path)\s*:\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*.*?---",
    # fenced code inkl. filename=
    r"(?is)^[`\"']{3}[^`\"'\n]*?(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)[^`\"']*?[`\"']{3}",
    r"(?is)^[`\"']{3}[^`\n]*?filename\s*=\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)[^`]*?[`\"']{3}",
    # frühe Zeilen
    r"(?im)^\s*(?:#|//|;|REM)?\s*(?:file|filename)\s*(?:=|:)\s*(?P<p>[\w\-/\\\. ]+\.[A-Za-z0-9]+)\s*$",
    # Heuristiken
    r"(?i)\b(Runner_[\w\-]+\.(?:py|bat|cmd|vbs))\b",
    r"(?i)\b(module_[\w\-]+\.py)\b",
]

def _split_name_ext_firstdot(filename: str) -> tuple[str, str]:
    """Name = bis erster '.', Endung = Rest mit führendem '.' (oder '')."""
    if not filename:
        return "", ""
    if "." in filename:
        left, right = filename.split(".", 1)
        return left, ("." + right) if right else ""
    return filename, ""

def _detect_name_ext(code: str) -> Tuple[str|None, str|None]:
    head = code[:12000]
    for pat in _PATTERNS:
        m = re.search(pat, head)
        if m:
            p = m.group("p") if "p" in m.groupdict() else m.group(1)
            nm, ex = _split_name_ext_firstdot(Path(p).name)
            return nm or None, (ex.lower() if ex else None)
    # fallback
    if re.search(r"(?m)^\s*def\s+main\s*\(", head):
        return f"module_auto_{int(Path.cwd().stat().st_mtime)}", ".py"
    if re.search(r"(?im)^\s*@echo\s+off\b", head):
        return f"Runner_auto_{int(Path.cwd().stat().st_mtime)}", ".bat"
    return f"snippet_{int(Path.cwd().stat().st_mtime)}", ".txt"

def _map_target(ws: Path, name_field: str, ext: str) -> Path:
    n = (name_field or "").lower()
    if ext == ".py" and n.startswith("runner_"): return ws / "tools"
    if ext in {".bat", ".cmd", ".vbs", ".ps1"}:  return ws / "tools"
    if ext == ".py" and n.startswith("module_"): return ws / "modules"
    if ext == ".py":                              return ws / "modules" / "snippets"
    if ext in {".md", ".json", ".txt"}:          return ws
    return ws

def _append_hist(rec: dict):
    try:
        HIST.open("a", encoding="utf-8").write(json.dumps(rec, ensure_ascii=False)+"\n")
    except Exception:
        pass

# --- GUI-Tab ------------------------------------------------------------------
def _build_tab(parent):
    conf = load_config()
    ws = Path(conf.get("workspace_root", r"D:\ShrimpHub"))

    root = ttk.Frame(parent)

    # Top: Workspace + LED Erkennung
    top = ttk.Frame(root); top.pack(fill="x", pady=6)
    ttk.Label(top, text="Workspace:").pack(side="left")
    var_ws = tk.StringVar(value=str(ws))
    ttk.Entry(top, textvariable=var_ws, width=58).pack(side="left", padx=6)
    ttk.Button(top, text="…", command=lambda: _pick_ws(var_ws)).pack(side="left")
    led_det = Led(top, text="Erkennung"); led_det.pack(side="right", padx=10)

    # Mittelteil: links Editor, rechts Liste
    mid = ttk.Frame(root); mid.pack(fill="both", expand=True)

    # links: Overrides + Text mit Scrollbars
    left = ttk.Frame(mid); left.pack(side="left", fill="both", expand=True)
    bar = ttk.Frame(left); bar.pack(fill="x", pady=4)
    var_name = tk.StringVar(); var_ext = tk.StringVar(); var_target = tk.StringVar()
    for lbl, var, w in (("Dateiname:", var_name, 40), ("Endung:", var_ext, 10), ("Zielordner:", var_target, 52)):
        f = ttk.Frame(bar); f.pack(side="left", padx=(0,8))
        ttk.Label(f, text=lbl).pack(side="top", anchor="w")
        ttk.Entry(f, textvariable=var, width=w).pack(side="top")

    text_wrap = ttk.Frame(left); text_wrap.pack(fill="both", expand=True)
    txt = tk.Text(text_wrap, wrap="none", undo=True)
    vs = AutoScrollbar(text_wrap, orient="vertical"); hs = AutoScrollbar(text_wrap, orient="horizontal")
    txt.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
    txt.pack(side="left", fill="both", expand=True)
    vs.pack(side="left", fill="y"); hs.pack(side="bottom", fill="x")

    # rechts: Liste gespeicherter Dateien (Name | Endung | Unterordner)
    right = ttk.Frame(mid); right.pack(side="left", fill="both", expand=False, padx=(10,0))
    ttk.Label(right, text="Gespeicherte Dateien").pack(anchor="w")
    cols=("name","ext","subfolder")
    table_wrap = ttk.Frame(right); table_wrap.pack(fill="both", expand=True)
    tree = ttk.Treeview(table_wrap, columns=cols, show="headings", height=18)
    for c,w in zip(cols,(240,80,240)):
        tree.heading(c, text=c); tree.column(c, width=w, anchor="w")
    vs2 = AutoScrollbar(table_wrap, orient="vertical"); hs2 = AutoScrollbar(table_wrap, orient="horizontal")
    tree.configure(yscrollcommand=vs2.set, xscrollcommand=hs2.set)
    tree.pack(side="left", fill="both", expand=True)
    vs2.pack(side="left", fill="y"); hs2.pack(side="bottom", fill="x")

    # Bottom: Status + Silent-Checkbox + Save-LED + Buttons
    btm = ttk.Frame(root); btm.pack(fill="x", pady=6)
    status = tk.StringVar(value="Bereit.")
    ttk.Label(btm, textvariable=status, anchor="w").pack(side="left")

    var_silent = tk.BooleanVar(value=bool(conf.get("intake_silent_success", True)))
    def _toggle_silent():
        conf["intake_silent_success"] = bool(var_silent.get())
        try: save_config(conf)
        except Exception: pass
    ttk.Checkbutton(btm, text="Nicht wieder anzeigen (Speicher-OK)", variable=var_silent,
                    command=_toggle_silent).pack(side="left", padx=12)
    led_save = Led(btm, text="Speichern"); led_save.pack(side="left", padx=10)

    ttk.Button(btm, text="Erkennen (Ctrl+I)",
               command=lambda: _detect(txt, var_name, var_ext, var_target, var_ws, status, led_det)).pack(side="right", padx=6)
    ttk.Button(btm, text="Speichern (Ctrl+S)",
               command=lambda: _save(txt, var_name, var_ext, var_target, status, var_ws, tree, led_save, var_silent)).pack(side="right")

    # Bindings & Auto-Detect
    root.bind_all("<Control-i>", lambda e: _detect(txt, var_name, var_ext, var_target, var_ws, status, led_det))
    root.bind_all("<Control-s>", lambda e: _save(txt, var_name, var_ext, var_target, status, var_ws, tree, led_save, var_silent))
    txt.bind("<<Paste>>", lambda e: root.after(20, lambda: _detect(txt, var_name, var_ext, var_target, var_ws, status, led_det, auto=True)))
    def _on_mod(_=None):
        txt.edit_modified(0)
        if not var_name.get() or not var_ext.get():
            _detect(txt, var_name, var_ext, var_target, var_ws, status, led_det, auto=True)
    txt.bind("<<Modified>>", _on_mod)

    return root

def _pick_ws(var_ws: tk.StringVar):
    d = filedialog.askdirectory(title="Workspace wählen", initialdir=var_ws.get() or r"D:\ShrimpHub")
    if d: var_ws.set(d)

def _detect(txt, var_name, var_ext, var_target, var_ws, status, led_det, auto: bool=False):
    code = txt.get("1.0", "end-1c")
    nm, ex = _detect_name_ext(code)
    if nm: var_name.set(nm)
    if (not ex) and nm and "." in nm:
        nm2, rest = nm.split(".", 1)
        var_name.set(nm2); ex = "." + rest if rest else ""
    if ex: var_ext.set(ex)
    name_field, ext = var_name.get().strip(), var_ext.get().strip().lower()
    if name_field and ext:
        ws = Path(var_ws.get() or r"D:\ShrimpHub")
        var_target.set(str(_map_target(ws, name_field, ext)))
        led_det.set("ok", "Erkennung OK")
    else:
        led_det.set("warn", "unvollständig")
    if not auto:
        status.set(f"Erkannt: name={name_field!r}, ext={ext!r}, target={var_target.get()!r}")

def _append_row(tree, ws: Path, out: Path, name_field: str, ext: str):
    try:
        sub = out.parent.relative_to(ws).as_posix()
    except Exception:
        sub = out.parent.name
    # neue Zeile am Ende: insert ohne iid → hängt unten an
    tree.insert("", "end", values=(name_field, ext, sub))

def _save(txt, var_name, var_ext, var_target, status, var_ws, tree, led_save, var_silent):
    name_field, ext, target = var_name.get().strip(), var_ext.get().strip().lower(), var_target.get().strip()
    code = txt.get("1.0", "end-1c")
    if not name_field or not ext or not target:
        led_save.set("err", "unvollständig")
        try: messagebox.showwarning("ShrimpDev", "Bitte Name/Endung/Target prüfen.")
        except Exception: pass
        return
    if not ext.startswith("."): ext = "." + ext
    final = Path(name_field).stem + ext
    out_dir = Path(target); out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / final
    # kleine Rotations-Backups
    if out.exists():
        for i in range(4,0,-1):
            pi = out.with_name(out.name + f".{i}.bak"); pj = out.with_name(out.name + f".{i+1}.bak")
            if pi.exists(): pi.replace(pj)
        try: out.with_name(out.name + ".bak").replace(out.with_name(out.name + ".1.bak"))
        except Exception: pass
    out.write_text(code, encoding="utf-8")

    # stilles Speichern (kein Popup) – Bestätigung via LED + Liste
    led_save.set("ok", "gespeichert")
    status.set(f"Gespeichert: {out}")
    _append_row(tree, Path(var_ws.get() or r"D:\ShrimpHub"), out, name_field, ext)

    # History persistieren
    try:
        rec = {"name": name_field, "ext": ext, "path": str(out), "ts": int(time.time())}
        HIST.open("a", encoding="utf-8").write(json.dumps(rec, ensure_ascii=False)+"\n")
    except Exception:
        pass

def open_intake(app) -> bool:
    try:
        return ensure_tab(app, "intake", "Code Intake", _build_tab)
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Intake Fehler:\n{ex}")
        except Exception: pass
        return False
'''

def main():
    write_versioned(MODS / "common_tabs.py", common_tabs_py())
    write_versioned(SNIP / "ui_helpers.py", ui_helpers_py())
    write_versioned(MODS / "module_code_intake.py", module_code_intake_py())
    print("[R991] DONE – Intake-Tab integriert, LED/Liste/Scrollbars aktiv.")
    print("[R991] Start: tools\\start_visible.bat → Tools → Code Intake")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
