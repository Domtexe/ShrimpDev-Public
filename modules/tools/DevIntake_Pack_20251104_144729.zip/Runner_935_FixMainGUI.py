from __future__ import annotations
import time, shutil, py_compile
from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
MAIN = ROOT / "main_gui.py"

CLEAN_MAIN = r'''from __future__ import annotations
import warnings
warnings.filterwarnings("ignore", category=SyntaxWarning)

import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

# ---- robuste (optionale) Imports mit Fallback-Stubs ----
try:
    from modules import module_agent as agent
except Exception:
    class _Agent:
        def start(self): pass
        def stop(self):  pass
    class _AG: 
        def __init__(self): self._svc=_Agent()
        def start(self): self._svc.start()
        def stop(self):  self._svc.stop()
    agent = type("agent", (), {"AGENT": _AG()})()  # type: ignore

def _safe_import(modpath: str, attr: str, fallback):
    try:
        mod = __import__(modpath, fromlist=[attr])
        return getattr(mod, attr)
    except Exception:
        return fallback

# Agent UI
def _fallback_agent_ui(app: tk.Tk) -> bool:
    try:
        messagebox.showinfo("ShrimpDev", "Agent Monitor nicht verfügbar.")
    except Exception:
        pass
    return False
open_agent_monitor = _safe_import("modules.module_agent_ui", "open_agent_monitor", _fallback_agent_ui)

# Project Map
def _fallback_project_map(app: tk.Tk) -> bool:
    win = tk.Toplevel(app); win.title("Project Map (Stub)")
    ttk.Label(win, text="Project Map Modul fehlt oder ist fehlerhaft.").pack(padx=12, pady=12)
    return True
open_project_map = _safe_import("modules.module_project_ui", "open_project_map", _fallback_project_map)

# Code Intake
def _fallback_intake(app: tk.Tk) -> bool:
    try:
        messagebox.showinfo("ShrimpDev", "Code Intake nicht verfügbar.")
    except Exception:
        pass
    return False
open_intake = _safe_import("modules.module_code_intake", "open_intake", _fallback_intake)

# Runner Board
def _fallback_runner_board(app: tk.Tk) -> bool:
    try:
        messagebox.showinfo("ShrimpDev", "Runner Board nicht verfügbar.")
    except Exception:
        pass
    return False
open_runner_board = _safe_import("modules.module_runner_board", "open_runner_board", _fallback_runner_board)

# Settings
def _fallback_settings(app: tk.Tk) -> bool:
    try:
        messagebox.showinfo("ShrimpDev", "Settings nicht verfügbar.")
    except Exception:
        pass
    return False
open_settings = _safe_import("modules.module_settings_ui", "open_settings", _fallback_settings)

# Preflight
def _fallback_preflight(app: tk.Tk) -> bool:
    try:
        messagebox.showinfo("ShrimpDev", "Preflight nicht verfügbar.")
    except Exception:
        pass
    return False
open_preflight = _safe_import("modules.module_preflight", "open_preflight", _fallback_preflight)

# Patch/Release
def _fallback_patch_release(app: tk.Tk) -> bool:
    try:
        messagebox.showinfo("ShrimpDev", "Patch/Release nicht verfügbar.")
    except Exception:
        pass
    return False
open_patch_release = _safe_import("modules.module_patch_release", "open_patch_release", _fallback_patch_release)

# Config (optional)
def _load_quiet() -> bool:
    try:
        from modules.config_mgr import load_config
        return bool(load_config().get("quiet_mode", True))
    except Exception:
        return True

ROOT = Path(r"D:\ShrimpDev")

def log(msg: str) -> None:
    try:
        (ROOT/"debug_output.txt").open("a", encoding="utf-8", errors="ignore").write(f"[MAIN] {msg}\n")
    except Exception:
        pass

class ShrimpDevApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("🦐 ShrimpDev")
        self.geometry("1100x720+80+60")

        self.nb = ttk.Notebook(self); self.nb.pack(fill="both", expand=True)
        self.status = tk.StringVar(value="Bereit.")
        ttk.Label(self, textvariable=self.status, anchor="w").pack(fill="x")

        self.quiet = _load_quiet()

        self._mk_menu()

        # Info-Tab
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="Info")
        ttk.Label(tab, text="ShrimpDev – Standalone Dev-Umgebung für ShrimpHub", font=("Segoe UI", 12)).pack(pady=12)

        # Agent starten
        try:
            agent.AGENT.start()
        except Exception:
            pass
        log("GUI ready")

    def _mk_menu(self):
        menubar = tk.Menu(self); self.config(menu=menubar)
        m_file = tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="File", menu=m_file)
        m_tools= tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="Tools", menu=m_tools)
        m_view = tk.Menu(menubar, tearoff=0); menubar.add_cascade(label="View",  menu=m_view)

        # File
        m_file.add_command(label="Exit", command=self._on_exit)

        # Tools
        m_tools.add_command(label="Code Intake (Ctrl+I)", command=lambda: open_intake(self))
        self.bind_all("<Control-i>", lambda e: open_intake(self))
        m_tools.add_command(label="Preflight Checks", command=lambda: open_preflight(self))
        m_tools.add_command(label="Make Patch/Export", command=lambda: open_patch_release(self))

        # View
        m_view.add_command(label="Agent Monitor (Ctrl+M)", command=lambda: open_agent_monitor(self))
        self.bind_all("<Control-m>", lambda e: open_agent_monitor(self))
        m_view.add_command(label="Runner Board",        command=lambda: open_runner_board(self))
        m_view.add_command(label="Project Map",         command=lambda: open_project_map(self))
        m_view.add_command(label="Settings…",           command=lambda: open_settings(self))

    def _on_exit(self):
        try: agent.AGENT.stop()
        except Exception: pass
        self.after(150, self.destroy)

if __name__ == "__main__":
    try:
        app = ShrimpDevApp()
        app.mainloop()
    except Exception as ex:
        log(f"FATAL: {ex}")
        try: messagebox.showerror("ShrimpDev", f"Fataler Fehler:\n{ex}")
        except Exception:
            pass
'''

def main():
    if MAIN.exists():
        bak = MAIN.with_name(f"{MAIN.stem}.{time.strftime('%Y%m%d_%H%M%S')}.fix.bak")
        shutil.copy2(MAIN, bak)
        print(f"[R935] Backup: {bak.name}")
    MAIN.write_text(CLEAN_MAIN, encoding="utf-8")
    try:
        py_compile.compile(str(MAIN), doraise=True)
        print("[R935] main_gui.py syntaktisch OK.")
        return 0
    except Exception as ex:
        print(f"[R935] SYNTAX-ERROR: {ex}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
