# -*- coding: utf-8 -*-
"""
R1166h Intake SafeDedent2
Fix: Dedentiert die ZWEI Folgezeilen nach '# ---------- helpers ----------' in _build_ui()
auf Basisindent (4 Spaces), auch wenn die Helpers-Zeile selbst bereits korrekt auf 4 steht.

Vorgehen:
- Backup -> _Archiv
- _build_ui-Block bestimmen
- Helpers-Zeile finden (egal welche Einrückung)
- Die nächsten zwei nicht-leeren Zeilen:
    - falls Einrückung > 4 Spaces: auf genau 4 Spaces setzen
- Syntax-Check; Rollback on error
- Masterregel §12.5 präzisiert: „Folgezeilen nach Helpers dedentieren“
"""
from __future__ import annotations
import io, re, time, shutil, py_compile, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
DOCS = ROOT / "docs"
RULE = DOCS / "MASTERREGELN_ADDENDUM_2025-10-23.md"
LOGF = ROOT / "debug_output.txt"

ADDENDUM = """# Masterregeln – Addendum (2025-10-23)

## §12.5 Indentation-Deduplikation (präzisiert)
- Der Marker `# ---------- helpers ----------` steht auf Basisindent (4 Spaces).
- **Die zwei Folgezeilen** (Kommentar/Call) sind ebenfalls auf **Basisindent (4)** zu halten.
- Dedentiere diese Folgezeilen, falls sie tiefer (>4) eingerückt sind.
- Nach jedem Patch: Syntax-Check + Log + Rollback on error.
"""

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1166h] {ts} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f: f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(p: Path) -> Path:
    ARCH.mkdir(parents=True, exist_ok=True)
    dst = ARCH / f"{p.name}.{int(time.time())}.bak"
    shutil.copy2(p, dst)
    log(f"Backup: {p} -> {dst}")
    return dst

def patch_source(src: str) -> tuple[str, list[str]]:
    changes = []

    # nur _build_ui analysieren
    m_def = re.search(r"^(\s*)def\s+_build_ui\s*\(", src, re.M)
    if not m_def:
        return src, changes
    func_indent = m_def.group(1)
    start = m_def.end()
    m_next = re.search(r"^\s*def\s+\w+\s*\(", src[start:], re.M)
    end = start + (m_next.start() if m_next else len(src)-start)
    block = src[start:end]

    # Helpers-Zeile finden (egal welche Einrückung)
    m_h = re.search(r"^(\s*)#\s*-{2,}\s*helpers\s*-{2,}\s*$", block, re.M)
    if not m_h:
        return src, changes

    base = func_indent + "    "  # 4 Spaces nach Funktionsindent
    lines = block.splitlines(True)  # keepends
    # Index der Helpers-Zeile
    helper_line_idx = None
    acc = 0
    for idx, ln in enumerate(lines):
        acc += len(ln)
        if m_h.start() < acc:
            helper_line_idx = idx
            break

    if helper_line_idx is None:
        return src, changes

    # Die nächsten ZWEI nicht-leeren Zeilen dedentieren
    modified = False
    count = 0
    i = helper_line_idx + 1
    while i < len(lines) and count < 2:
        ln = lines[i]
        if ln.strip() == "":
            i += 1
            continue
        # führende Whitespaces extrahieren
        m = re.match(r"^(\s*)(.*)$", ln)
        lead, rest = m.group(1), m.group(2)
        if len(lead.replace("\t", "    ")) > len(base):  # tiefer als Basisindent
            lines[i] = base + rest
            modified = True
        count += 1
        i += 1

    if modified:
        block = "".join(lines)
        changes.append("Dedented two lines after helpers marker to 4 spaces")

    new_src = src[:start] + block + src[end:]
    return new_src, changes

def write_rules():
    DOCS.mkdir(parents=True, exist_ok=True)
    RULE.write_text(ADDENDUM, encoding="utf-8")

def main() -> int:
    try:
        if not MOD.exists():
            log("[ERR] module_code_intake.py not found."); return 2
        src = MOD.read_text(encoding="utf-8")
        bak = backup(MOD)
        new_src, changes = patch_source(src)
        if not changes:
            log("No changes applied (pattern healthy or already fixed).")
            return 0
        MOD.write_text(new_src, encoding="utf-8", newline="\n")

        try:
            py_compile.compile(str(MOD), doraise=True)
            log("Syntax-Check: OK")
        except Exception as ex:
            log(f"[ERR] Syntax-Check failed: {ex}")
            shutil.copy2(bak, MOD); log("Restored from backup.")
            return 3

        write_rules(); log(f"Wrote rule addendum: {RULE}")
        log("R1166h completed successfully.")
        return 0
    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
