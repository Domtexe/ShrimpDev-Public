# -*- coding: utf-8 -*-
"""
R1166b IntakeScopeFix SafeIndent
- Repariert Intake-Init ohne manuelle Schritte.
- Idempotent, einrückungssicher, mit Rollback.

Änderungen:
1) Entfernt 'global ttk' im _build_ui().
2) Nach 'bar = ttk.Frame(...)' fügt es auf exakt derselben Einrückung 'self.toolbar = bar' ein (falls fehlend).
3) Ersetzt den 'R1154g: zusätzliche Toolbar-Buttons' Block durch eine ttk-neutrale Version und passt
   ALLE Zeilen auf die Einrückung des Originalblocks an.
4) Schreibt das Regel-Addendum.

Safety:
- Backup -> _Archiv
- Syntax-Check via py_compile
- Rollback on error
"""
from __future__ import annotations
import io, re, time, shutil, py_compile, traceback, os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD  = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
DOCS = ROOT / "docs"
RULE = DOCS / "MASTERREGELN_ADDENDUM_2025-10-23.md"
LOGF = ROOT / "debug_output.txt"

ADDENDUM = """# Masterregeln – Addendum (2025-10-23)

## 1.4 GUI-Imports (NEU)
- Alle GUI-Toolkit-Imports (`tkinter`, `ttk`, `messagebox`, `filedialog` etc.) erfolgen **nur im Modulkopf**.
- In Funktionen/Methoden werden **keine** lokalen Re-Imports oder Zuweisungen an diese Namen durchgeführt.
- Verhindert `UnboundLocalError` und Ladeabbrüche beim GUI-Aufbau.

## 1.5 Toolbar-Referenzen (NEU)
- Der Toolbar-Container wird zentral referenziert (z. B. `self.toolbar = bar`).
- Legacy-Attribute (z. B. `self.frm_actions`) dürfen als Alias auf **dieselbe Instanz** zeigen.

## 7.3 Log-Robustheit (Ergänzung)
- Logfiles dürfen Start nicht blockieren. Fallback/Retry statt Abbruch.

## 12.3 Safe-Patches (Ergänzung)
- Runner sind idempotent (mehrfach lauffähig ohne Doppel-Injektion).
- Vor Änderung: Backup. Nach Änderung: Syntax-Check. Bei Fehlern: Rollback.
"""

R1154G_CLEAN_BODY = (
    "# R1154g: zusätzliche Toolbar-Buttons (idempotent; innerhalb _build_ui)\n"
    "parent = bar if 'bar' in locals() else getattr(self, 'toolbar', None)\n"
    "if parent:\n"
    "    # Editor leeren (links)\n"
    "    try:\n"
    "        if not hasattr(self, 'btn_clear_editor'):\n"
    "            self.btn_clear_editor = ttk.Button(parent, text='Editor leeren', command=self._on_clear_editor)\n"
    "            self.btn_clear_editor.grid(row=0, column=0, padx=(12,0), sticky='w')\n"
    "    except Exception:\n"
    "        pass\n"
    "    # Datei löschen (rechts)\n"
    "    try:\n"
    "        if not hasattr(self, 'btn_delete_file'):\n"
    "            self.btn_delete_file = ttk.Button(parent, text='Datei löschen', command=self._on_delete_selected_file)\n"
    "            self.btn_delete_file.grid(row=0, column=121, padx=(6,0), sticky='w')\n"
    "    except Exception:\n"
    "        pass\n"
)

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[R1166b] {ts} {msg}\n"
    try:
        with io.open(LOGF, "a", encoding="utf-8") as f: f.write(line)
    except Exception:
        pass
    print(line, end="")

def backup(p: Path) -> Path:
    ARCH.mkdir(parents=True, exist_ok=True)
    dst = ARCH / f"{p.name}.{int(time.time())}.bak"
    shutil.copy2(p, dst)
    log(f"Backup: {p} -> {dst}")
    return dst

def indent_block(text: str, indent: str) -> str:
    """wende indent auf jeden Zeilenbeginn an (auch leere -> nur newline behalten)"""
    out_lines = []
    for ln in text.splitlines(True):
        if ln.strip():
            out_lines.append(indent + ln)
        else:
            out_lines.append(ln)
    return "".join(out_lines)

def patch_source(src: str) -> tuple[str, list[str]]:
    changes: list[str] = []

    # --- _build_ui lokalisieren
    m_def = re.search(r"^(\s*)def\s+_build_ui\s*\(\s*self[^\)]*\)\s*:\s*$", src, re.M)
    if not m_def:
        return src, changes
    func_indent = m_def.group(1)
    start = m_def.end()
    m_next = re.search(r"^\s*def\s+\w+\s*\(", src[start:], re.M)
    end = start + (m_next.start() if m_next else len(src) - start)
    block = src[start:end]

    # 1) 'global ttk' Zeile(n) raus
    new_block = re.sub(r"^\s*global\s+ttk\s*\r?\n", "", block, flags=re.M)
    if new_block != block:
        changes.append("Removed 'global ttk' from _build_ui")
        block = new_block

    # 2) nach 'bar = ttk.Frame(' -> self.toolbar = bar mit gleicher Einrückung
    m_bar = re.search(r"^(\s*)bar\s*=\s*ttk\.Frame\([^\)]*\)\s*$", block, re.M)
    if m_bar:
        bar_indent = m_bar.group(1)
        insert_pos = m_bar.end()
        tail_after_bar = block[insert_pos:insert_pos+200]
        if "self.toolbar = bar" not in tail_after_bar:
            fix_line = f"\n{bar_indent}self.toolbar = bar  # R1166b: zentrale Toolbar-Referenz\n"
            block = block[:insert_pos] + fix_line + block[insert_pos:]
            changes.append("Inserted 'self.toolbar = bar' after toolbar creation")

    # 3) R1154g-Block ersetzen, korrekt eingerückt
    # Startmarker tolerant (mit/ohne Umlaute)
    m_start = re.search(r"^(\s*)#\s*R1154g:\s*(zus[aä]tzliche|zusaetzliche)\s+Toolbar-Buttons.*$", block, re.M | re.I)
    if m_start:
        block_indent = m_start.group(1)
        # Ende: nächste dedizierte Helper-Sektion oder bis Funktionsende
        rest = block[m_start.end():]
        m_end = re.search(r"^\s*#\s*-{2,}\s*helpers\s*-{2,}\s*$", rest, re.M)
        if not m_end:
            # auch akzeptieren: Aufruf einer Helper-Funktion oder neue Button-Defs
            m_end = re.search(r"^\s*(self\._intake_post_build_bind_clear\(\)|def\s+\w+\()", rest, re.M)
        end_off = m_end.start() if m_end else len(rest)

        block = block[:m_start.start()] + indent_block(R1154G_CLEAN_BODY, block_indent) + rest[end_off:]
        changes.append("Replaced R1154g appendix with ttk-neutral block (safe indent)")

    new_src = src[:start] + block + src[end:]
    return new_src, changes

def write_rules():
    DOCS.mkdir(parents=True, exist_ok=True)
    RULE.write_text(ADDENDUM, encoding="utf-8")

def main() -> int:
    try:
        if not MOD.exists():
            log(f"[ERR] Not found: {MOD}"); return 2
        src = MOD.read_text(encoding="utf-8")
        bak = backup(MOD)

        new_src, changes = patch_source(src)

        if changes:
            MOD.write_text(new_src, encoding="utf-8", newline="\n")
            for c in changes: log(f"Change: {c}")
            try:
                py_compile.compile(str(MOD), doraise=True)
                log("Syntax-Check: OK")
            except Exception as ex:
                log(f"[ERR] Syntax-Check failed: {ex}")
                shutil.copy2(bak, MOD)
                log("Restored from backup.")
                return 3
        else:
            log("No changes applied (patterns not found).")

        # Regeln (immer) schreiben
        try:
            write_rules(); log(f"Wrote rules addendum: {RULE}")
        except Exception as ex:
            log(f"[WARN] Could not write rules addendum: {ex}")

        log("R1166b completed successfully.")
        return 0
    except Exception as e:
        log(f"[EXC] {e}\n{traceback.format_exc()}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
