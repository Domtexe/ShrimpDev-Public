from __future__ import annotations
from pathlib import Path
import re, shutil, time, json

ROOT = Path(r"D:\ShrimpDev")
UI   = ROOT / "modules" / "module_project_ui.py"
CFG  = ROOT / "config.json"

def ts(): return time.strftime("%Y%m%d_%H%M%S")
def backup(p: Path) -> Path:
    b = p.with_suffix(p.suffix + f".{ts()}.bak")
    shutil.copy2(p, b); return b

def load_quiet() -> bool:
    try:
        data = json.loads(CFG.read_text(encoding="utf-8") or "{}")
        return bool(data.get("quiet_mode", True))
    except Exception:
        return True

def patch_scan_finish():
    if not UI.exists():
        print("[R916] FEHLT:", UI); return 2
    txt = UI.read_text(encoding="utf-8", errors="ignore")

    # 1) jegliches „Scan abgeschlossen“-Popup entfernen (falls noch irgendwo)
    pop_patts = [
        r'messagebox\.showinfo\s*\(.*?Scan\s*abgeschlossen.*?\)',
        r'messagebox\.showinfo\s*\(\s*["\']ShrimpDev["\']\s*,\s*["\']Scan.*?["\']\s*\)'
    ]
    changed = False
    for p in pop_patts:
        if re.search(p, txt, re.I):
            txt = re.sub(p, "# [R916 removed: popup]", txt, flags=re.I)
            changed = True

    # 2) Nach Scan: Statusleiste + Agent-Event
    # Wir suchen eine Methode, die „Scan Now“ ausführt; typisch: run_scan / do_scan
    # und hängen dort nach Erfolg eine Statusmeldung an.
    if "def run_scan(" in txt:
        fun = "run_scan"
    elif "def do_scan(" in txt:
        fun = "do_scan"
    else:
        fun = None

    if fun:
        pat_fun = rf"(def\s+{fun}\(self.*?\):\s*)(.*?)(\n\s*# end\s+{fun}|$)"
        m = re.search(pat_fun, txt, flags=re.S)
        if m and "R916_status" not in m.group(0):
            body = m.group(2)
            add = (
                "\n        # [R916_status] quiet status & agent event\n"
                "        try:\n"
                "            from modules.config_mgr import load_config\n"
                "            q = bool(load_config().get('quiet_mode', True))\n"
                "        except Exception:\n"
                "            q = True\n"
                "        self.app.status.set('Scan abgeschlossen.')\n"
                "        try:\n"
                "            from modules.snippets.agent_client import send_event\n"
                "            send_event({'runner':'ProjectScan','level':'OK','msg':'Scan abgeschlossen'})\n"
                "        except Exception:\n"
                "            pass\n"
                "        # kein Popup im Quiet-Mode\n"
            )
            txt = txt.replace(body, body + add)
            changed = True

    if changed:
        b = backup(UI)
        UI.write_text(txt, encoding="utf-8")
        print(f"[R916] Scan-UX angepasst. Backup: {b.name}")
    else:
        print("[R916] Keine Änderungen nötig (bereits leise).")

def main():
    patch_scan_finish()
    return 0

if __name__ == "__main__":
    main()
