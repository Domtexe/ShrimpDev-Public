"""
Runner_1053_Intake_ClearOnDelete_RefreshOnPaste
- [Löschen]: leert Editor + Name + Endung und setzt Flags/LEDs sauber zurück.
- Paste: setzt Name/Endung zurück und triggert sofortige Auto-Erkennung,
         sodass die 3 Felder (Editor/Name/Endung) nach neuem Code korrekt befüllt sind.
Version: v9.9.43
"""
from __future__ import annotations
import os, re, time, shutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH = os.path.join(ROOT, "_Archiv")
MOD  = os.path.join(ROOT, "modules", "module_code_intake.py")
LOG  = os.path.join(ROOT, "debug_output.txt")

def _log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(msg, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[R1053] {ts} {msg}\n")
    except Exception:
        pass

def _read(p: str) -> str:
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def _write_backup(p: str, data: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    bck = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
    shutil.copy2(p, bck)
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(data)
    _log(f"Backup: {p} -> {bck}")

def patch() -> int:
    src = _read(MOD)
    changed = False

    # 1) Hilfsfunktionen in die Klasse einfügen: _prepare_new_intake() und _clear_editor_and_fields()
    if "_prepare_new_intake(" not in src:
        src = re.sub(
            r"(\n\s*def\s+_ping\([^\)]*\):[\s\S]+?\n\s*pass\s*\n)",
            r"""\1
    def _prepare_new_intake(self):
        """ + '"""Name/Ext zurücksetzen und LEDs/Flags neutralisieren."""' + r"""
        self.var_name_manual = False
        self.var_ext_manual = False
        try:
            self.var_name.set("")
            self.var_ext.set("")
        except Exception:
            pass
        try:
            self._update_led(self.led_detect, "yellow")
            self._update_led(self.led_save, "yellow")
        except Exception:
            pass

    def _clear_editor_and_fields(self):
        """ + '"""Editor leeren + _prepare_new_intake."""' + r"""
        try:
            self.txt.delete("1.0","end")
        except Exception:
            pass
        self._prepare_new_intake()
""",
            src, count=1, flags=re.MULTILINE
        )
        changed = True

    # 2) Paste-Handler anpassen: Felder zurücksetzen + Auto-Detect
    src2 = re.sub(
        r"def\s+_on_editor_paste\([^\)]*\):\s*\n\s*([^\n]*\n)*?\s*self\._schedule_detect\(\d+\)",
        'def _on_editor_paste(self, _evt=None):\n        self._prepare_new_intake()\n        self._schedule_detect(150)',
        src, count=1, flags=re.MULTILINE
    )
    if src2 != src:
        src = src2
        changed = True

    # 3) Delete-Handler erweitern: nach erfolgreichem Löschen UI-Felder nullen
    src2 = re.sub(
        r"(self\._load_table\(\)\s*\n\s*self\._ping\(\"Gelöscht\.\"\)\s*)",
        r"self._load_table()\n        self._clear_editor_and_fields()\n        self._ping(\"Gelöscht.\")\n",
        src, count=1, flags=re.MULTILINE
    )
    if src2 != src:
        src = src2
        changed = True
    else:
        # Falls ältere Variante ohne Ping-Text vorhanden ist – generischer Fallback
        src2 = re.sub(
            r"(self\._load_table\(\)\s*)\n",
            r"\1\n        self._clear_editor_and_fields()\n",
            src, count=1, flags=re.MULTILINE
        )
        if src2 != src:
            src = src2
            changed = True

    if changed:
        _write_backup(MOD, src)
        with open(os.path.join(ROOT, "CURRENT_VERSION.txt"), "w", encoding="utf-8") as f:
            f.write("ShrimpDev v9.9.43\n")
        with open(os.path.join(ROOT, "CHANGELOG.md"), "a", encoding="utf-8") as f:
            f.write("""
## v9.9.43 (2025-10-18)
- Intake: [Löschen] leert Editor + Name + Endung.
- Intake: Paste setzt Name/Endung zurück und triggert Auto-Erkennung neu.
""")
        _log("Patch angewendet.")
        return 0
    else:
        _log("Keine Änderungen nötig.")
        return 0

if __name__ == "__main__":
    raise SystemExit(patch())
