# -*- coding: utf-8 -*-
"""
Runner_1084_FixGuard_ArgParse
- Macht tools/Runner_1063_Intake_SanityGuard.py robuster:
  * Toleranteres Argument-Parsing (--check oder /check, Reihenfolge egal)
  * [GUARD] OK bei Erfolg, sonst klare Meldung + Exitcode 1
  * Usage nur noch, wenn wirklich keine valide Datei ermittelt wurde
- Idempotent: Kann mehrfach ausgeführt werden.
"""
from __future__ import annotations
import os, time, shutil, re

ROOT  = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ARCH  = os.path.join(ROOT, "_Archiv")
GUARD = os.path.join(ROOT, "tools", "Runner_1063_Intake_SanityGuard.py")

NEW_GUARD = r'''# -*- coding: utf-8 -*-
from __future__ import annotations
import sys, os, ast

def _read_crlf(path: str) -> str:
    with open(path, "rb") as f:
        raw = f.read()
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("latin-1", errors="replace")

def _has_unclosed_triple_quotes(s: str) -> bool:
    return (s.count('"""') % 2 != 0) or (s.count("'''") % 2 != 0)

def _norm(p: str) -> str:
    return os.path.normpath(os.path.abspath(p))

def check_file(path: str) -> bool:
    path = _norm(path)
    if not os.path.exists(path):
        print(f"[GUARD] Datei nicht gefunden: {path}")
        return False
    try:
        src = _read_crlf(path)
    except Exception as ex:
        print(f"[GUARD] Lesen fehlgeschlagen: {ex}")
        return False

    if _has_unclosed_triple_quotes(src):
        print("[GUARD] Unausgeglichenes Triple-Quote erkannt.")
        return False

    try:
        ast.parse(src)
    except SyntaxError as ex:
        where = f"(line {ex.lineno}, col {getattr(ex, 'offset', '?')})"
        print(f"[GUARD] SyntaxError: {ex.msg} {where}")
        return False
    except Exception as ex:
        print(f"[GUARD] Parser-Fehler: {ex}")
        return False

    print("[GUARD] OK")
    return True

def _pick_check_target(argv: list[str]) -> str | None:
    # robust: akzeptiert --check, /check, Groß/Klein egal, Reihenfolge egal
    if not argv:
        return None
    args = [a.strip() for a in argv if a.strip()]
    # wenn als erstes --check <file> oder /check <file>
    for i, a in enumerate(args):
        a_low = a.lower()
        if a_low in ("--check", "/check"):
            if i + 1 < len(args):
                return args[i+1]
            return None
    # fallback: wenn nur eine einzelne .py-Datei übergeben wurde
    py_args = [a for a in args if a.lower().endswith(".py")]
    return py_args[0] if len(py_args) == 1 else None

def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    target = _pick_check_target(argv)
    if target:
        ok = check_file(target)
        return 0 if ok else 1
    print("Usage: py -3 tools\\Runner_1063_Intake_SanityGuard.py --check <file.py>")
    return 2

if __name__ == "__main__":
    raise SystemExit(main())
'''

def _read(p: str) -> str:
    with open(p, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def _write(p: str, text: str) -> None:
    # Erzwinge CRLF für Konsistenz
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\n", "\r\n")
    with open(p, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(text)

def backup(p: str) -> None:
    os.makedirs(ARCH, exist_ok=True)
    if os.path.exists(p):
        bak = os.path.join(ARCH, f"{os.path.basename(p)}.{int(time.time())}.bak")
        shutil.copy2(p, bak)
        print(f"Backup: {p} -> {bak}")

def patch() -> int:
    if not os.path.exists(GUARD):
        print(f"[R1084] Guard nicht gefunden: {GUARD}")
        return 1

    src = _read(GUARD)

    # Erkennen wir bereits unsere robustere Version? Dann nichts tun.
    if "[GUARD] OK" in src and "_pick_check_target" in src:
        print("Guard ist bereits robust/verbos. Keine Änderungen nötig.")
        return 0

    backup(GUARD)
    _write(GUARD, NEW_GUARD)
    print(f"Guard aktualisiert: {GUARD}")
    return 0

if __name__ == "__main__":
    raise SystemExit(patch())
