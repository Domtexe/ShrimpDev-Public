# -*- coding: utf-8 -*-
"""
Runner_1114b_FixUnexpectedIndent_MainGUI.py
Behebt 'unexpected indent' in main_gui.py durch Indent-Normalisierung (4 Spaces).
"""
from __future__ import annotations
import os, re, time, shutil, ast

ROOT = os.path.abspath(os.path.dirname(__file__))
BASE = os.path.abspath(os.path.join(ROOT, ".."))
ARCH = os.path.join(BASE, "_Archiv")
os.makedirs(ARCH, exist_ok=True)

TARGET = os.path.join(BASE, "main_gui.py")

BLOCK_START = re.compile(r"^\s*(def|class|if|elif|else|for|while|try|except|finally|with)\b.*:\s*(#.*)?$")
NEEDS_DEDENT_AFTER = set()  # wir deduzieren dynamisch
DECORATOR = re.compile(r"^\s*@")
ONLY_COMMENT_OR_EMPTY = re.compile(r"^\s*(#.*)?$")

def backup(path: str) -> str:
    ts = int(time.time())
    bak = os.path.join(ARCH, f"{os.path.basename(path)}.{ts}.bak")
    shutil.copy2(path, bak)
    return bak

def read_text(p: str) -> str:
    with open(p, "rb") as f: raw = f.read()
    for enc in ("utf-8-sig","utf-8","latin-1"):
        try: return raw.decode(enc)
        except: pass
    return raw.decode("utf-8","replace")

def write_text(p: str, s: str) -> None:
    with open(p,"w",encoding="utf-8",newline="\n") as f: f.write(s)

def try_compile(p: str, s: str) -> tuple[bool,str]:
    try:
        ast.parse(s, filename=p)
        compile(s, p, "exec")
        return True, ""
    except SyntaxError as ex:
        return False, f"SyntaxError: {ex.msg} (line {ex.lineno})"
    except Exception as ex:
        return False, f"{type(ex).__name__}: {ex}"

def norm_newlines_tabs(s: str) -> str:
    return s.replace("\r\n","\n").replace("\r","\n").replace("\t","    ")

def normalize_indents(text: str) -> str:
    """
    Läuft Zeile für Zeile:
      - erlaubt sind 0,4,8,12,…
      - nach Blockstarter muss die nächste sinnvolle Code-Zeile > indent sein
      - wenn eine Zeile tiefer eingerückt ist, ohne dass vorher ein Blockstarter stand -> auf erlaubtes Level reduzieren
    """
    lines = text.split("\n")
    n = len(lines)

    # Hilfsstruktur: „erlaubte“ Indent-Levels (Stack) abhängig vom bisherigen Verlauf
    allowed = [0]
    expect_deeper = False   # nach Blockstarter
    last_code_indent = 0    # letztes nicht-leeres/nicht-Kommentar Indent

    def get_indent(s: str) -> int:
        return len(s) - len(s.lstrip(" "))

    def set_indent(s: str, new_i: int) -> str:
        return (" " * new_i) + s.lstrip(" ")

    i = 0
    while i < n:
        ln = lines[i]
        # Kommentare/Leerzeilen: nur merken, nichts erzwingen
        if ONLY_COMMENT_OR_EMPTY.match(ln):
            i += 1
            continue

        indent = get_indent(ln)
        is_decorator = DECORATOR.match(ln) is not None
        is_block = BLOCK_START.match(ln) is not None

        # erwartet tiefer, aber tatsächlicher indent ist nicht tiefer -> schiebe mindestens eine Stufe tiefer
        if expect_deeper and indent <= last_code_indent and not is_decorator:
            indent = last_code_indent + 4
            lines[i] = set_indent(ln, indent)

        # wenn unerwartet tiefer (ohne expect_deeper), reduziere auf das größte erlaubte ≤ indent
        if not expect_deeper and indent > last_code_indent and not is_decorator:
            # finde erlaubtes Ziel (größte erlaubte Stufe <= indent)
            target = max([lvl for lvl in allowed if lvl <= last_code_indent], default=0)
            lines[i] = set_indent(ln, target)
            indent = target

        # Begrenze auf Vielfache von 4
        if indent % 4 != 0:
            new_indent = indent - (indent % 4)
            lines[i] = set_indent(ln, new_indent)
            indent = new_indent

        # Stack/Erwartung pflegen
        if is_block:
            # nach block müssen wir tiefer erwarten (außer bei 'elif/else/except/finally:' zählt die aktuelle Tiefe)
            expect_deeper = True
        else:
            expect_deeper = False

        last_code_indent = indent
        # update erlaubte Level (einfach: alle bis last_code_indent)
        if last_code_indent not in allowed:
            allowed.append(last_code_indent)
        allowed = sorted(set(allowed))

        i += 1

    return "\n".join(lines)

def main():
    if not os.path.exists(TARGET):
        print(f"[R1114b] {TARGET} nicht gefunden.")
        return 1

    print(f"[R1114b] Prüfe {TARGET}")
    bak = backup(TARGET)
    print(f"[R1114b] Backup: {bak}")

    src = norm_newlines_tabs(read_text(TARGET))
    fixed = normalize_indents(src)

    if fixed != src:
        write_text(TARGET, fixed)
        ok, err = try_compile(TARGET, fixed)
        if ok:
            print("[R1114b] Repariert & Syntax OK.")
            return 0
        else:
            print(f"[R1114b] Nach Reparatur noch Fehler: {err}")
            # Rollback
            shutil.copy2(bak, TARGET)
            return 2
    else:
        ok, err = try_compile(TARGET, fixed)
        if ok:
            print("[R1114b] Keine Änderungen nötig, Syntax OK.")
            return 0
        else:
            print(f"[R1114b] Syntaxfehler bleibt bestehen: {err}")
            return 2

if __name__ == "__main__":
    raise SystemExit(main())
