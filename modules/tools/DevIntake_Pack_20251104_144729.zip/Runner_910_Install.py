from pathlib import Path

ROOT = Path(r"D:\ShrimpDev")
TOOLS = ROOT/"tools"; TOOLS.mkdir(parents=True, exist_ok=True)
MODS  = ROOT/"modules"; MODS.mkdir(parents=True, exist_ok=True)
SNIP  = MODS/"snippets"; SNIP.mkdir(parents=True, exist_ok=True)
REPORT= ROOT/"_Reports"/"ProjectMap"; REPORT.mkdir(parents=True, exist_ok=True)

def w(p: Path, s: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(s.replace("\r\n","\n"), encoding="utf-8")
    print(f"[R910] wrote {p.relative_to(ROOT)}")

# --- module_project_scan.py ---
scan_py = r'''from __future__ import annotations
import ast, json, os, re, time
from pathlib import Path
from typing import Any, Dict, List

HUB = Path(r"D:\ShrimpHub")
OUT = Path(r"D:\ShrimpDev\_Reports\ProjectMap")
OUT.mkdir(parents=True, exist_ok=True)
MAP_JSON = OUT/"project_map.json"
MAP_HTML = OUT/"project_map.html"
SCANS = OUT/"scans"; SCANS.mkdir(exist_ok=True)

def _log(msg: str):
    try: Path(r"D:\ShrimpDev\debug_output.txt").open("a", encoding="utf-8").write(f"[SCAN] {msg}\n")
    except Exception: pass

def _py_info(p: Path) -> Dict[str, Any]:
    info: Dict[str, Any] = {"path": str(p.relative_to(HUB)), "lang": "py"}
    try:
        src = p.read_text(encoding="utf-8", errors="ignore")
        tree = ast.parse(src)
    except Exception as ex:
        info["error"] = f"{type(ex).__name__}: {ex}"
        return info
    imps: List[str] = []
    defs: List[Dict[str, Any]] = []
    classes: List[Dict[str, Any]] = []
    globs: List[Dict[str, Any]] = []
    handlers: List[Dict[str, Any]] = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            imps.extend([a.name for a in n.names])
        elif isinstance(n, ast.ImportFrom):
            mod = n.module or ""
            imps.append(mod)
        elif isinstance(n, ast.FunctionDef):
            defs.append({"name": n.name, "args": [a.arg for a in n.args.args]})
        elif isinstance(n, ast.ClassDef):
            methods = [m.name for m in n.body if isinstance(m, ast.FunctionDef)]
            classes.append({"name": n.name, "methods": methods})
        elif isinstance(n, ast.Assign):
            for t in n.targets:
                if isinstance(t, ast.Name):
                    globs.append({"name": t.id})
    # rudimentäre Tkinter-Muster
    src = p.read_text(encoding="utf-8", errors="ignore")
    for m in re.finditer(r'command\s*=\s*(\w+)', src):
        handlers.append({"kind":"button","target":m.group(1)})
    for m in re.finditer(r'\.bind[_a-z]*\(\s*[^,]+,\s*[\'"]([^\'"]+)[\'"]\s*,\s*(\w+)', src):
        handlers.append({"kind":"bind","sequence":m.group(1),"target":m.group(2)})
    info["imports"]=sorted(set([i for i in imps if i]))
    info["defs"]=defs; info["classes"]=classes; info["globals"]=globs; info["handlers"]=handlers
    return info

def _bat_info(p: Path) -> Dict[str, Any]:
    txt = p.read_text(encoding="utf-8", errors="ignore")
    calls = re.findall(r'\b(?:call|py\s+-3\s+-u|python\s+-u)\s+([^\s&|>]+)', txt, re.I)
    sets  = re.findall(r'(?im)^\s*set\s+(\w+)=', txt)
    return {"path": str(p.relative_to(HUB)), "lang":"bat", "calls":calls, "sets":sets}

def scan() -> Dict[str, Any]:
    t0 = time.time()
    files: List[Dict[str, Any]]=[]
    for p in HUB.rglob("*"):
        if not p.is_file(): continue
        if any(seg in p.parts for seg in ("_Archiv","_Reports",".git","dist","build")): continue
        suf = p.suffix.lower()
        if suf==".py": files.append(_py_info(p))
        elif suf in (".bat",".cmd"): files.append(_bat_info(p))
    data = {
        "scanned_root": str(HUB),
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "files": files,
        "stats": {"py": sum(f["lang"]=="py" for f in files), "bat": sum(f["lang"]=="bat" for f in files)}
    }
    MAP_JSON.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    # HTML
    rows=[]
    for f in files:
        rows.append(
            f"<tr><td>{f.get('path','')}</td><td>{f.get('lang','')}</td>"
            f"<td>{len(f.get('defs',[]))}</td><td>{len(f.get('classes',[]))}</td>"
            f"<td>{len(f.get('handlers',[]))}</td></tr>"
        )
    MAP_HTML.write_text(
        "<meta charset='utf-8'><style>table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:4px 6px;font:12px Segoe UI}</style>"
        "<h3>ShrimpDev Project Map</h3><table><tr><th>Datei</th><th>Typ</th><th>Funktionen</th><th>Klassen</th><th>Handler</th></tr>"
        + "".join(rows) + "</table>", encoding="utf-8")
    # Snapshot
    snap = SCANS/f"scan_{int(time.time())}.jsonl"
    snap.write_text(json.dumps({"ts":time.time(),"count":len(files)}, ensure_ascii=False)+"\n", encoding="utf-8")
    _log(f"Scan OK: {len(files)} files in {time.time()-t0:.2f}s")
    return data

if __name__=="__main__":
    scan()
'''
w(MODS/"module_project_scan.py", scan_py)

# --- module_project_ui.py (vollwertiges Tab) ---
ui_py = r'''from __future__ import annotations
import json, tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from modules import module_project_scan as scanner
from modules.snippets.agent_client import send_event

ROOT = Path(r"D:\ShrimpDev")
REPORT = ROOT/"_Reports"/"ProjectMap"
MAP_JSON = REPORT/"project_map.json"

class ProjectMapTab(ttk.Frame):
    def __init__(self, app: tk.Tk):
        super().__init__(app.nb)
        self.app = app
        bar = ttk.Frame(self); bar.pack(fill="x", pady=4)
        ttk.Button(bar, text="Scan Now", command=self.run_scan).pack(side="left")
        self.var_auto = tk.BooleanVar(value=False)
        ttk.Checkbutton(bar, text="Watch On", variable=self.var_auto, command=self.toggle_watch).pack(side="left", padx=8)
        ttk.Button(bar, text="Reload", command=self.load_data).pack(side="left", padx=8)

        cols=("path","lang","defs","classes","handlers")
        self.tree = ttk.Treeview(self, columns=cols, show="headings")
        for c,w in zip(cols,(420,60,80,80,90)):
            self.tree.heading(c, text=c); self.tree.column(c, width=w, anchor="w")
        self.tree.pack(fill="both", expand=True)
        self.after_id=None
        self.load_data()

    def run_scan(self):
        try:
            data = scanner.scan()
            send_event({"runner":"ProjectScan","level":"OK","msg":f"files={len(data['files'])}"})
            self.load_data()
            messagebox.showinfo("ShrimpDev","Scan abgeschlossen.")
        except Exception as ex:
            send_event({"runner":"ProjectScan","level":"ERROR","msg":str(ex)})
            messagebox.showerror("ShrimpDev", f"Scan-Fehler:\n{ex}")

    def toggle_watch(self):
        if self.var_auto.get():
            self._schedule()
        else:
            try:
                if self.after_id: self.after_cancel(self.after_id)
            except Exception: pass
            self.after_id=None

    def _schedule(self):
        try:
            self.run_scan()
        except Exception: pass
        if self.var_auto.get():
            self.after_id = self.after(5000, self._schedule)

    def load_data(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        if not MAP_JSON.exists(): return
        try:
            data=json.loads(MAP_JSON.read_text(encoding="utf-8", errors="ignore"))
            for f in data.get("files",[]):
                self.tree.insert("", "end", values=(
                    f.get("path",""), f.get("lang",""),
                    len(f.get("defs",[])), len(f.get("classes",[])), len(f.get("handlers",[]))
                ))
        except Exception as ex:
            messagebox.showerror("ShrimpDev", f"Ladefehler:\n{ex}")

def open_project_map(app: tk.Tk) -> bool:
    try:
        tab = ProjectMapTab(app); app.nb.add(tab, text="Project Map"); app.nb.select(tab); return True
    except Exception as ex:
        try: messagebox.showerror("ShrimpDev", f"Tab-Fehler:\n{ex}")
        except Exception: pass
        return False
'''
w(MODS/"module_project_ui.py", ui_py)

# --- Headless Runner (Scan) ---
r911_py = r'''from modules.module_project_scan import scan
from modules.snippets.agent_client import send_event
try:
    d = scan()
    send_event({"runner":"Runner_911_Scan","level":"OK","msg":f"files={len(d['files'])}"})
    print("[R911] OK")
except Exception as ex:
    send_event({"runner":"Runner_911_Scan","level":"ERROR","msg":str(ex)})
    print("[R911] ERROR:", ex)
'''
w(TOOLS/"Runner_911_Scan.py", r911_py)
w(TOOLS/"Runner_911_Scan.bat", '@echo off\r\ncd /d "D:\\ShrimpDev"\r\npy -3 -u tools\\Runner_911_Scan.py\r\necho [END ] RC=%errorlevel%\r\npause\r\n')

# --- Watcher (polling, still) ---
r912_py = r'''import time, os
from modules.module_project_scan import scan
from modules.snippets.agent_client import send_event
def main():
    send_event({"runner":"Runner_912_Watch","level":"INFO","msg":"start"})
    last=0
    while True:
        try:
            d=scan()
            now=len(d.get("files",[]))
            if now!=last:
                send_event({"runner":"Runner_912_Watch","level":"OK","msg":f"files={now}"})
                last=now
        except Exception as ex:
            send_event({"runner":"Runner_912_Watch","level":"ERROR","msg":str(ex)})
        time.sleep(5)
if __name__=="__main__": main()
'''
w(TOOLS/"Runner_912_Watch.py", r912_py)
w(TOOLS/"Runner_912_Watch.bat", '@echo off\r\ncd /d "D:\\ShrimpDev"\r\npowershell -NoP -W Hidden -C "Start-Process -WindowStyle Hidden \'py\' -ArgumentList \'-3\',\'-u\',\'D:\\ShrimpDev\\tools\\Runner_912_Watch.py\'"\r\necho [R912] Watch gestartet (hidden)\r\npause\r\n')

print("[R910] DONE – open View > Project Map or run tools\\Runner_911_Scan.bat")
