from __future__ import annotations
import os, re, io
from patchlib_guard import guarded_apply, FileCtx

ROOT = r"D:\ShrimpDev"
MAIN = os.path.join(ROOT, "main_gui.py")

def _transform(ctx: FileCtx):
    src = ctx.modified

    # Entferne versehentlich generierte Funktionsdefinitionen def nb.add(...):
    src = re.sub(
        r'\ndef\s+nb\.add\s*\([^)]*\):\s*\n(?:\s+.+\n)*?',
        '\n',  # entfernt gesamte def-block
        src
    )

    # Falls der korrekte Aufruf noch nicht vorhanden ist, füge ihn ein
    if "nb.add(__mount_intake_tab_shim(nb)" not in src:
        src = re.sub(
            r'(tab_intake\s*=\s*IntakeFrame\(nb\)[^\n]*\n)',
            r'\1    nb.add(__mount_intake_tab_shim(nb), text="Code Intake")\n',
            src,
        )

    ctx.modified = src

ok, msg = guarded_apply(MAIN, _transform)
print(("[1175f] " + (msg or "")).strip())
raise SystemExit(0 if ok else 1)
