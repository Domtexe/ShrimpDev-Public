# -*- coding: utf-8 -*-
"""
Runner_1090_FixIntake_Indent
Repariert falsch eingerückte Methoden in modules/module_code_intake.py,
damit IntakeFrame wieder korrekt geladen wird.
"""

from __future__ import annotations
import os, time, shutil, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MOD = ROOT / "modules" / "module_code_intake.py"
ARCH = ROOT / "_Archiv"
ARCH.mkdir(exist_ok=True)

def backup():
    bak = ARCH / f"{MOD.name}.{int(time.time())}.bak"
    shutil.copy2(MOD, bak)
    print(f"[R1090] Backup: {MOD} -> {bak}")
    return bak

def patch(src: str) -> str:
    """Rückt alle def _*-Methoden, die nach Klassenende stehen, um 4 Leerzeichen ein."""
    lines = src.splitlines()
    fixed = []
    in_class = False
    indent = " " * 4

    for line in lines:
        if line.strip().startswith("class IntakeFrame("):
            in_class = True
            fixed.append(line)
            continue
        # Ende der Klasse, wenn neue top-level Funktion oder Kommentar
        if in_class and line.strip().startswith("# --- R1089: helpers"):
            in_class = False
        # Nach Klassende: def _on_click_..., _run_py etc. -> einrücken
        if not in_class and re.match(r"^def _", line):
            fixed.append(indent + line)
        elif not in_class and re.match(r"^    def _", line):
            fixed.append(line)
        else:
            fixed.append(line)
    return "\n".join(fixed)

def main():
    if not MOD.exists():
        print(f"{MOD} nicht gefunden.")
        return 1
    backup()
    src = MOD.read_text(encoding="utf-8", errors="ignore")
    new = patch(src)
    MOD.write_text(new, encoding="utf-8", newline="\n")
    print("[R1090] IntakeFrame-Methoden neu eingerückt.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
