# -*- coding: utf-8 -*-
"""
[1174x] IntakeRevive: Stellt eine kompilierfähige Intake-Version aus _Archiv wieder her,
hebt __future__ korrekt an den Dateianfang und verankert einen stabilen Mount in main_gui.py.
Master-Regeln:
- Nie ohne Backup schreiben
- Nur kompilierfähige Quellen übernehmen
- Atomare Writes
"""

import argparse, sys, os, re, shutil, tempfile, py_compile
from pathlib import Path

def log(msg): print(f"[1174x] {msg}", flush=True)

def compile_ok(p: Path) -> bool:
    try:
        py_compile.compile(str(p), doraise=True)
        return True
    except Exception as e:
        return False

def atomic_write(dst: Path, content: str):
    tmp = dst.with_suffix(dst.suffix + ".1174x.tmp")
    tmp.write_text(content, encoding="utf-8")
    shutil.copymode(dst, tmp) if dst.exists() else None
    tmp.replace(dst)

def normalize_newlines(text: str) -> str:
    # toleriert alte Backups mit \r\n / \r
    return text.replace("\r\n", "\n").replace("\r", "\n")

def lift_future_import(src: str) -> str:
    """
    Hebt `from __future__ import annotations` an den erlaubten Platz:
    - erlaubt davor: Encoding-Zeile, BOM, reine Kommentare/Leerzeilen, ein Modul-Docstring
    - danach: Rest
    """
    src = normalize_newlines(src)
    future_pat = re.compile(r"^\s*from\s+__future__\s+import\s+annotations\s*$", re.M)
    if not future_pat.search(src):
        # nichts zu tun, wenn nicht vorhanden (wir fügen nichts neu hinzu)
        return src

    # Modul-Docstring erkennen (erste Stringliteral-Zeile am Anfang)
    lines = src.split("\n")
    i = 0
    # encoding oder BOM/comment/blank
    while i < len(lines) and (
        lines[i].startswith("#") or lines[i].strip() == "" or "coding:" in lines[i] or "coding=" in lines[i]
    ):
        i += 1
    # Docstring block ("""...""" oder '''...''')
    def _is_doc_start(s): return s.lstrip().startswith(('"""',"'''"))
    if i < len(lines) and _is_doc_start(lines[i]):
        quote = '"""' if lines[i].lstrip().startswith('"""') else "'''"
        i += 1
        while i < len(lines):
            if quote in lines[i]:
                i += 1
                break
            i += 1

    # Aktuellen future-Block entfernen
    new_lines = []
    removed = False
    for ln in lines:
        if future_pat.fullmatch(ln.strip()):
            if not removed:
                removed = True
            else:
                # doppelte future Imports entsorgen
                continue
        else:
            new_lines.append(ln)

    # Future an Position i einfügen, wenn er entfernt wurde
    if removed:
        new_lines.insert(i, "from __future__ import annotations")

    return "\n".join(new_lines)

def restore_best_from_arch(arch_dir: Path, target: Path) -> Path:
    """
    Sucht im Archiv die neueste Intake-Kopie, die kompiliert.
    """
    backups = sorted(arch_dir.glob("module_code_intake.py.*.bak"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not backups:
        raise SystemExit("Kein Backup im _Archiv gefunden.")

    for cand in backups:
        try:
            raw = cand.read_text(encoding="utf-8", errors="ignore")
            fixed = lift_future_import(raw)
            # tmp prüfen
            with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False, encoding="utf-8") as tmp:
                tmp.write(fixed)
                tmp_path = Path(tmp.name)
            ok = compile_ok(tmp_path)
            tmp_path.unlink(missing_ok=True)
            if ok:
                log(f"Übernehme Backup: {cand.name}")
                # atomar schreiben
                target.parent.mkdir(parents=True, exist_ok=True)
                atomic_write(target, fixed)
                return cand
        except Exception:
            pass

    raise SystemExit("Kein kompilierfähiges Backup gefunden.")

def ensure_main_mount(main_file: Path):
    """
    Stellt den stabilen Mount sicher:
    - _safe_add_intake_tab(nb) vorhanden
    - Aufruf in _safe_main() vorhanden
    Greift nicht ein, wenn schon korrekt.
    """
    src = normalize_newlines(main_file.read_text(encoding="utf-8", errors="ignore"))

    # Helper-Block – defensiv, ohne import Seiteneffekte
    helper_id = "# [INTAKE_TAB_HELPER_1174x]"
    if helper_id not in src:
        helper = f"""
{helper_id}
def _safe_add_intake_tab(nb):
    try:
        from modules.module_code_intake import IntakeFrame
    except Exception as e:
        # hartes Logging in debug_output.txt (falls vorhanden)
        try:
            with open("D:\\ShrimpDev\\debug_output.txt","a",encoding="utf-8") as f:
                f.write("\\n[1174x] Importfehler IntakeFrame: %r\\n" % (e,))
        except Exception:
            pass
        return  # Intake hart deaktiviert

    try:
        tab = IntakeFrame(nb)
        nb.add(tab, text="Code Intake")
    except Exception as e:
        try:
            with open("D:\\ShrimpDev\\debug_output.txt","a",encoding="utf-8") as f:
                f.write("\\n[1174x] Aufbaufehler IntakeFrame: %r\\n" % (e,))
        except Exception:
            pass
        # Fallback: leeres Frame statt Crash
        import tkinter as tk, tkinter.ttk as ttk
        tab = ttk.Frame(nb)
        msg = tk.Label(tab, text="Fehler beim Laden des Intake-Tabs. Details siehe debug_output.txt", fg="red")
        msg.pack(anchor="w", padx=12, pady=12)
        nb.add(tab, text="Code Intake")
"""
        src = src + "\n" + helper

    # Aufruf in _safe_main()
    if "_safe_add_intake_tab(nb)" not in src:
        # sehr konservativ: direkt hinter Notebook-Erzeugung einsetzen
        src = re.sub(
            r"(\bnb\s*=\s*ttk\.Notebook\([^\n]*\)\s*\n)",
            r"\1    _safe_add_intake_tab(nb)\n",
            src,
            count=1,
        )

    atomic_write(main_file, src)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--restore-best-from-arch", dest="arch", type=str, required=True)
    ap.add_argument("--target", dest="target", type=str, required=True)
    ap.add_argument("--main", dest="main", type=str, required=True)
    args = ap.parse_args()

    arch = Path(args.arch)
    target = Path(args.target)
    main_file = Path(args.main)

    # 1) Wiederherstellen
    best = restore_best_from_arch(arch, target)
    log(f"Restored from: {best.name}")

    # 2) Zukunfts-Import anheben (nochmals – falls Ziel manuell verändert)
    fixed = lift_future_import(target.read_text(encoding="utf-8", errors="ignore"))
    atomic_write(target, fixed)
    if not compile_ok(target):
        raise SystemExit("Zieldatei kompiliert nach Fix nicht. Abbruch.")

    # 3) Mount in main_gui absichern
    ensure_main_mount(main_file)

    log("OK. Intake wiederhergestellt und Mount abgesichert.")

if __name__ == "__main__":
    try:
        main()
        sys.exit(0)
    except SystemExit as e:
        # repropagate SystemExit code
        raise
    except Exception as e:
        try:
            with open(r"D:\ShrimpDev\debug_output.txt","a",encoding="utf-8") as f:
                f.write("\n[1174x] Runner-Fehler: %r\n" % (e,))
        except Exception:
            pass
        print(f"[1174x] FEHLER: {e}", file=sys.stderr)
        sys.exit(10)
